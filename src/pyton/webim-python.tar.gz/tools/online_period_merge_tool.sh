BASEDIR=$(dirname $0)
cd $BASEDIR
PYTHONPATH="$PWD/.." python online_period_merge_tool.py
