# coding=UTF-8
import json
import re
import urllib2
import webim.wm_settings
import webim.wm_utils
import webim.db_utils

__author__ = 'mixey'

f = open('/home/mixey/offline_message_reqests')
lines = f.readlines()
f.close()

pattern = re.compile('track\.php\?(.+)\',')
pattern = re.compile('.+track.php\?(.+?)\',.+')
phone_to_messages = webim.wm_utils.DictExt(lambda key: [])
phone_to_name = {}
for l in lines:
    print
#    print l
    r = pattern.match(l)
#    if r:
    s = r.group(1)
#    print s
    params = {}
    for pair in s.split('&'):
        pair_split = pair.split('=')
        params[pair_split[0]] = urllib2.unquote(pair_split[1])
    visitor_fields = json.loads(params['visitor-fields'])
    print visitor_fields
    message = params['msg_text'].decode('utf-8')
    print message

    phone_to_messages.get(visitor_fields['phone']).append(message)
    phone_to_name[visitor_fields['phone']] = visitor_fields['name']

print '=' * 40
print phone_to_messages

c = webim.db_utils.get_connection('laredouteru')

s = 0
data = []
for phone, messages in phone_to_messages.items():
    print
    print phone
    print len(messages)
    s += len(messages)

    msg_rows = c.query("select m.* from chatmessage m join chatthread t on t.threadid = m.threadid "+
                       "where m.message like %s and date(m.created) >= date('2013-08-17') and t.offline = 1", '%' + phone + '%')
    print len(msg_rows)

    if len(msg_rows) != len(messages):
        print '##################'

    for i, r in enumerate(msg_rows):
        cnt_row = c.get('select count(*) cnt from chatmessage where threadid = %s and (kind!=3 and kind!=4)', r['threadid'])
        cnt = cnt_row['cnt']
#        print '  ' + str(cnt)
#        print '  ' + str(i)
        if cnt:
            print '##################'

        msg_data = (r['threadid'], 3, u'Посетитель оствил сообщение в отсутствие операторов', r['created'], '', None)
        msg_data_2 = (r['threadid'], 1, messages[i], r['created'], phone_to_name[phone], None)

        print msg_data
        print msg_data_2

        data.append(msg_data)
        data.append(msg_data_2)




print s
print '- ' * 30

insert_sql = "insert into chatmessage (threadid, kind, message, created, sendername, operatorid) values (%s, %s, %s, %s, %s, %s)"

for d in data:

#    print c.execute(insert_sql, *d)
    pass


c.close()
