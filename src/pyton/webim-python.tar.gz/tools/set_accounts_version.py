import logging
from webim import db_utils

__author__ = 'mixey'


connection = db_utils.get_connection()
#rows = connection.query("select accountname from account where accountname='mixey' or accountname='sportmasterru'")
rows = connection.query("select accountname from account where registertoken is null")
for row in rows:
    try:
        account_name = row['accountname']
        pro_connection = db_utils.get_connection(account_name)
        config_row = pro_connection.get("select configvalue from chatconfig where configkey='version'")
        version = config_row['configvalue']
        print account_name + ' ' + version
        connection.execute('update account set version = %s where accountname = %s', version, account_name)
        pro_connection.close()
    except:
        logging.error("version setting failed for account %s" % (row['accountname'] if 'accountname' in row else ''), exc_info=True)
connection.close()
