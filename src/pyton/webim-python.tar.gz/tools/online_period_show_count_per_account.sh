BASEDIR=$(dirname $0)
cd $BASEDIR
PYTHONPATH="$PWD/.." python online_period_show_count_by_account.py
