import base64
import json
import logging
import urllib
import urllib2
import urlparse
from webim import db_utils
# from webim.db_storage import MessageStorager

__author__ = 'mixey'


def external_request(full_url, post_data = None, timeout = 10):
    auth = None
    parse = urlparse.urlparse(full_url)
    #s = parse[1].split('@',1)
    #if len(s) == 2:
    #    a = s[0].split(':')
    #    if len(a) == 2:
    #        auth = {'user':a[0],'password':a[1]}
    if parse.username:
        auth = {'user':parse.username, 'password': parse.password}
    url = urlparse.urlunparse((parse.scheme, '%s:%s' %(parse.hostname,parse.port) if parse.port else parse.hostname, parse.path, parse.params, parse.query, parse.fragment))

    req = urllib2.Request(url)
    if post_data:
        if type(post_data) == dict:
            req.add_data(urllib.urlencode(post_data))
        else:
            req.add_data(post_data)
    if auth:
        req.add_header('Authorization', 'Basic ' + base64.urlsafe_b64encode("%s:%s" % (auth['user'], auth['password'])))
    try:
        return urllib2.urlopen(req, timeout=timeout).read()
    except urllib2.URLError as e:
        logging.error('Url %s is not available for reason: %s' % (url,str(e)))
        return None

def filter_4_byte_characters(unicode_string):
    return u''.join(uc if uc < u'\ud800' or u'\ue000' <= uc <= u'\uffff' else u'' for uc in unicode_string)

url = ''
# url = "_http://wadmin:megapass@webim.webim.ru/webim/service/monitor/tornado-monitor-proxy.php?_=1444692620050&port=8237&host=s2&subject=failed-to-store-objects&params=%7B%22mode%22%3A%22objects%22%2C%22account_name%22%3A%22playbetboxcom%22%2C%22class_name%22%3A%22Message%22%2C%22collector_name%22%3A%22failed_to_store%22%2C%22failed%22%3A%221%22%7D"
# url = "_http://wadmin:megapass@webim.webim.ru/webim/service/monitor/tornado-monitor-proxy.php?_=1447775495653&port=8241&host=s11&subject=failed-to-store-objects&params=%7B%22mode%22%3A%22objects%22%2C%22account_name%22%3A%22shoptimeru%22%2C%22class_name%22%3A%22Message%22%2C%22collector_name%22%3A%22failed_to_store%22%2C%22failed%22%3A%221%22%7D"

# connection = db_utils.get_connection('_playbetboxcom')
connection = db_utils.get_connection('mixey')
response = external_request(url)
print response
data = json.loads(response)
for row in data:
    # row[4] = filter_4_byte_characters(row[4])
    print row
    # sql = MessageStorager.insert_sql
    # sql = "insert into chatmessage (threadid, kind, message, created, sendername, operatorid, json, createdts, insertedts) values (%s, %s, %s, %s, %s, %s, %s, %s, %s)"
    sql = "insert into chatmessage (threadid, kind, message, created, sendername, operatorid, json) values (%s, %s, %s, %s, %s, %s, %s)" #8.12
    print connection.execute(sql, *row)

print len(data)
