# coding=utf-8
import hashlib
import json

__author__ = 'mixey'

private_key = 'kw7vpe9sn4lasm'
visitor_ext = '{"display_name": "Евгений", "phone": "+7 921 111 2233", "email": "support@webim.ru","crc": "add9df237d0016890cec3e12027711fa"}'

params = json.loads(visitor_ext)

for encoding in ['cp1251', 'koi8-r', 'utf-8']:
    s = ''
    for key in sorted(params.keys()):
        value = params[key]
        if key != 'crc':
            s += value.encode(encoding)
    s += private_key
    print s

    m = hashlib.md5()
    m.update(s)
    print m.hexdigest() + ' (' + encoding + ')'
