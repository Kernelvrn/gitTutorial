import json
from webim import db_utils
from webim.db_storage import SessionStorager

__author__ = 'mixey'
f = open('_bg_storager.bkp.1408114481.73.json')

#storager = SessionStorager()
connection = db_utils.get_connection('teztourcom000')
data = json.loads(f.read())
for s_data in data['failed_to_store']['VisitSession']:
    row = s_data['row']
    print row
    print connection.execute(SessionStorager.insert_sql, *row)

print len(data['failed_to_store']['VisitSession'])
