BASEDIR=$(dirname $0)
cd $BASEDIR
PYTHONPATH="$PWD/.." python response_time_monitor.py
