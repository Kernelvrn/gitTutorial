__author__ = 'mixey'

#insert into _pairs_for_merge
#select id1, min(id2) id2 from
#(select p1.id id1, p2.id id2 from chatonlineperiod p1 join chatonlineperiod p2
#on p1.id != p2.id
#and p1.operatorid = p2.operatorid
#and ifnull(p1.departmentid, 0) = ifnull(p2.departmentid, 0)
#and ifnull(p1.locale, 0) = ifnull(p2.locale, 0)
#                           and p1.dtmto <= p2.dtmfrom
#and p1.dtmto > p2.dtmfrom - interval 60 second) t
#group by id1 order by id1;

import webim.db_utils

c = webim.db_utils.get_connection('psboxru')

#print c.get('select count(*) from pairs_for_merge')
#exit()


query = 'select * from _pairs_for_merge order by id1'
rows = c.query(query)

mapping = {}
to_update = {}
to_del = set()

for row in rows:
    id1 = row['id1']
    id2 = row['id2']
    while id1 in mapping:
        id1 = mapping[id1]

    to_update[id1] = id2
    to_del.add(id2)
    mapping[id2] = id1

print "to_update %d" % len(to_update)
print "to_del %d" % len(to_del)

for i, (id1, id2) in enumerate(to_update.items()):
    if not i % 100:
        print "upd %d / %d" % (i, len(to_update))
    row = c.get('select dtmto from _chatonlineperiod where id=%s', id2)
    c.execute('update _chatonlineperiod set dtmto = %s where id=%s', row['dtmto'], id1)

query = 'delete from _chatonlineperiod where id in (select id2 from _pairs_for_merge)'
c.execute(query)
