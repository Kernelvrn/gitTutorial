import logging
import json
from webim import db_utils

__author__ = 'mixey'


connection = db_utils.get_connection()
rows = connection.query("select accountname from account where version <'6'")
#rows = connection.query("select accountname from account where accountname='mixey'")

result = []

for account_row in rows:
    try:
        account_name = account_row['accountname']
        pro_connection = db_utils.get_connection(account_name)
        max_row = pro_connection.get("select max(created) created from chatthread")
        result.append((account_name, max_row['created']))
        pro_connection.close()
    except:
        logging.error("###", exc_info=True)
connection.close()

result.sort(cmp = lambda r1, r2: 1 if r2[1] is None or r1[1] is not None and r1[1] > r2[1] else -1)

for r in result:
    print str(r[0]) + ' ' + str(r[1])

print "'" + "', '".join((r[0] for r in result[-30:])) + "'"