from operator import itemgetter

__author__ = 'mixey'


import webim.db_utils

c = webim.db_utils.get_connection()

#print c.get('select count(*) from pairs_for_merge')
#exit()


query = "select table_schema from information_schema.tables where table_name = 'chatonlineperiod'"
rows = c.query(query)

result = []
for row in rows:
    schema = row['table_schema']
    cnt = c.get('select count(*) cnt from %s.chatonlineperiod' % schema)['cnt']
    result.append((schema, cnt))

result.sort(key=itemgetter(1))
for i in result:
    print str(i[1]) + '\t' + i[0]
