import logging
import json
from webim import db_utils

__author__ = 'mixey'


def load_from_db_full_ainvite_data():
    full_ainvite_data = []
    connection = db_utils.get_connection()
#    rows = connection.query("select accountname from account where accountname='mixey'")
    #    rows = connection.query("select accountname from account where registertoken is null and server_ip='176.9.42.176'") #s1
    #    rows = connection.query("select accountname from account where registertoken is null and server_ip='213.239.200.202'") #s6
    #    rows = connection.query("select accountname from account where registertoken is null and server_ip='5.9.86.138'") #s7
    #    rows = connection.query("select accountname from account where registertoken is null and server_ip='46.4.68.132'") #s3
    #    rows = connection.query("select accountname from account where registertoken is null and server_ip='176.9.146.195'") #s5
    #    rows = connection.query("select accountname from account where registertoken is null and server_ip='5.9.59.210'") #s12

    #    rows = connection.query("select accountname from account where registertoken is null and server_ip='176.9.42.176'") #s1
    #    rows = connection.query("select accountname from account where registertoken is null and server_ip='46.4.68.132'") #s3
    #    rows = connection.query("select accountname from account where registertoken is null and server_ip='176.9.146.195'") #s5
    #    rows = connection.query("select accountname from account where registertoken is null and server_ip='213.239.200.202'") #s6
    #    rows = connection.query("select accountname from account where registertoken is null and server_ip='5.9.86.138'") #s7
    #    rows = connection.query("select accountname from account where registertoken is null and server_ip='5.9.59.210'") #s12

#    rows = connection.query("select accountname from account where registertoken is null and (1=2 " +
#                            " or server_ip='46.4.107.118'" + #s2
##                            " or server_ip='176.9.34.234'" + #s4
#                            " or server_ip='5.9.112.151'" + #s8
#                            " or server_ip='5.9.119.167'" + #s9
##                            " or server_ip='78.47.245.130'" + #s10
##                            " or server_ip='78.47.45.30'" + #s13
#                            ")")

    #rows = connection.query("select accountname from account where accountname in ('zeta', 'lima')")

    rows = connection.query("select accountname from account where registertoken is null")
    #rows = connection.query("select accountname from account where accountname in ('spectec', 'rosenergosnabru', 'rosenergosnabru', 'gasznakru', 'localhost002', 'butikn1ru', 'mirndvru', 'abscityru', 'stroyirkutskru', 'styl16ru', 'rapballru', 'wroomru', 'petek1855kz', 'blumenbumru', 'interfuraru', 'models5ru', 'vshokoladebiz', 'nanosemanticsru', 'ufabetoncom', 'zakazpaketaru', 'kleysamru', 'goldenkakadu', 'goldenkakadu', 'imasharu', 'examscheatwatchcomua', 'examscheatwatchcomua', 'examscheatwatchcomua', 'miltonsecurityru', 'miltonsecurityru', 'miltonsecurityru', 'kuhnivilenaru', 'belgorodgenserru', 'lvledru', 'goinstoreru', 'novoeecotonspbru', 'online', 'nout7ru', 'astoreby', 'astoreby', 'proteintutru001', 'royalbarbieru', 'royalbarbieru', 'culttelaru', 'culttelaru', 'kitkosru001', 'studiasilkru', 'studiasilkru', 'shishasiceru', 'funnytaoru', 'kreativismskru', 'yeswatchru', 'cvetyrostovaru', 'fasadmontaj31ru', 'ooozippyru', 'ustanovkamontazhrf', 'motofutbolkaru', 'motofutbolkaru', 'domdivru', 'domdivru', 'spykingru', 'rioteneriferu', 'rioteneriferu', 'olaportugalru', '5hby001', 'involightshopru', 'paketmanru', 'arenaproductru001', 'mfocloudru', 'archeagebankru', 'archeagebankru', 'expertyandexru', 'raybenru', 'nuznareklamaru001', 'navigatespbru', 'magazintelnyashekru', 'magazintelnyashekru', 'tepzeplru', 'tepzeplru', 'gsmarru', 'magiccleaningwebcom001', 'ziosabru', 'ziosabru', 'tronmskru', 'handywellru002', 'zoobagiracom', 'zoobagiracom', 'portaltransru', 'triptkartinaru', 'buhprofrf', 'svetovedcom', 'svetovedcom', 'svetovedcom', 'mirotonru', '25gusru', 'pododezhdoyru', 'pododezhdoyru', 'tdoneru', 'tdoneru', 'hfamilyshopru', 'chasiciru', 'chasiciru', 'qpdachucom', 'polotencaru')")
    #rows = connection.query("select accountname from account where accountname in ('allsoftru', 'allsoftru_bckup', 'bankliferu', 'ecotonspbru', 'komusru001', 'laredouteru', 'mediasaturncom001', 'teztourcom')") #ddb3

    for n, account_row in enumerate(rows):
        if n % 20 == 0:
            print "" + str(n) + " / " + str(len(rows)) + " " + str(100 * n / len(rows))
        try:
            account_name = account_row['accountname']
            pro_connection = db_utils.get_connection(account_name)
            ainvite_rows = pro_connection.query("select * from chatautoinvite")
            full_ainvite_data.append((account_name, ainvite_rows))
            pro_connection.close()
        except:
            logging.error("###", exc_info=True)
    connection.close()
    return full_ainvite_data

def process_full_ainvite_data(full_ainvite_data):
    actual_accounts = []
    for account_name, ainvite_rows in full_ainvite_data:
        for r in ainvite_rows:
            changed = False

            conditions_json = r['conditions']
            conditions = json.loads(conditions_json)
            number_of_pages = conditions.get('number_of_pages', None)
            time_on_site = conditions.get('time_on_site', None)
            if type(number_of_pages) in [str, unicode]:
                conditions['number_of_pages'] = int(number_of_pages) if number_of_pages != '' else None
                changed = True

            if 'visited_page' in conditions:
                pages = conditions.pop('visited_page')
                for page in pages:
                    if type(page['time']) in [str, unicode]:
                        page['time'] = int(page['time']) if page['time'] != '' else 0
                conditions['visited_pages'] = {
                    'urls': pages,
                    'order_matters': 0
                }
                changed = True

            if type(time_on_site) in [str, unicode]:
                time_on_site = int(time_on_site)
                conditions['time_on_site'] = time_on_site if time_on_site != 0 or conditions['number_of_pages'] is None and not ('visited_pages' in conditions) else None
                changed = True

            if changed:
                actual_accounts.append(account_name)

                print account_name + ' ' + str(r['autoinviteid'])
                print 'was:    ' + conditions_json
                print 'became: ' + json.dumps(conditions)

            try:
                pass
                #pro_connection = db_utils.get_connection(account_name)
                #pro_connection.execute("update chatautoinvite set conditions = %s where autoinviteid = %s", json.dumps(conditions), r['autoinviteid'])
                #pro_connection.close()
            except:
                logging.error("@@@ ", exc_info=True)

    print "', '".join(actual_accounts)

#from_file = True
from_file = False
fileName = '/home/mixey/full_ainvite_data.json'

if from_file:
    f = open(fileName, 'r')
    full_ainvite_data = json.loads(f.read())
    f.close()
else:
    full_ainvite_data = load_from_db_full_ainvite_data()
    f = open(fileName, 'w')
    f.write(json.dumps(full_ainvite_data))
    f.close()

process_full_ainvite_data(full_ainvite_data)


