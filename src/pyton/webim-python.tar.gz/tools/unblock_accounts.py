import urllib2
from webim import wm_settings

def request_php_service(account_name, uri, **params):
    params_str = '&'.join([name + '=' + str(value) for name, value in params.items()])
    params_str = '?' + params_str if len(params_str) else ''
    url = "http://" + account_name + '.pro-service.' + wm_settings.settings['base_domain'] + '/webim/service/' + uri + params_str
    password_mgr = urllib2.HTTPPasswordMgrWithDefaultRealm()
    password_mgr.add_password(None, url, wm_settings.settings.get('service_user'), wm_settings.settings.get('service_password'))
    handler = urllib2.HTTPBasicAuthHandler(password_mgr)
    response = urllib2.build_opener(handler).open(url).read()
    return response


f = open('accounts.txt')
for line in f:
    line = line.rstrip()
    if len(line):
        print line
        account_name = line
        request_php_service(account_name, 'set-account-status.php', enabled='true')
