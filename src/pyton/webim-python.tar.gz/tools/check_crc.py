# coding=utf-8
import hashlib
import json


def checkCrc(params, private_key, encoding):
    if not 'crc' in params:
        return False

    if not private_key:
        return False

    str = ''
    try:
        m = hashlib.md5()
        for key in sorted(params.keys()):
            value = params[key]
            if key != 'crc':
                #m.update(value.encode(encoding))
                str += value
        #m.update(private_key)
        str += private_key
        m.update(str.encode(encoding))
        crc = m.hexdigest()
        print encoding
        print crc
        print str
        return crc == params['crc'].lower()
    except:
        raise

#params = json.loads('{"display_name":"Eugeny","phone":"+7 812 3855337","email":"support@webim.ru","crc":"1f521d99ff446bc9a58bddf304a87c36"}')
#
#params = {
#    "crc": 'ffd68cfe56fe156c48685048ff983393',
#    "email": "Emparhimovich@gmail.com",
#    "display_name": u"\u041f\u0430\u0440\u0445\u0438\u043c\u043e\u0432\u0438\u0447 \u0415\u043b\u0435\u043d\u0430 \u041c\u0438\u0445\u0430\u0439\u043b\u043e\u0432\u043d\u0430",
#    "phone_no": "79671086594",
#    "id": "6531"
#}

#params = json.loads('{"display_name":"Пархимович Елена Михайловна","id":"6531","phone":"79671086594","email":"Emparhimovich@gmail.com","crc":"ffd68cfe56fe156c48685048ff983393"}')
#params = json.loads('{"display_name": "4000000003", "login": "4000000003", "crc": "a1530238499822f472f9ca050adc9424"}')
#params = json.loads('{"display_name": "4000000003", "login": "4000000003", "crc": "a1530238499822f472f9ca050adc9424"}')
# params = json.loads('{"crc":"9a98e9a2c69b9f71fc9473883b69a891","email":"superdudlik@gmail.com","display_name":"Гладких Мария Никитична","phone":"79636440177"}')
params = json.loads('{"id":"12345","display_name": "Евгений","phone": "+7 812 3855337","email": "support@webim.ru","crc": "ccbb082afba5022de58d8eeb7d5599ac"}')
print params
private_key = '69e75f91995662f8471e6d8c4bf8f84d' #demo
# private_key = '-'

print (checkCrc(params, private_key, 'koi8-r') or checkCrc(params, private_key, 'cp1251') or checkCrc(params, private_key, 'utf-8'))