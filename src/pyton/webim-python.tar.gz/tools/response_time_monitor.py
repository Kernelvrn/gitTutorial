import json
import time
import logging
import urllib2
import threading
import datetime
import webim.db_utils

__author__ = 'mixey'

class VisitedPageEmulator:

    def __init__(self, host, port, account_name):
        self.host = host
        self.port = port
        self.account_name = account_name

        self.visit_session_id = ''
        self.page_id = ''
        self.revision = 0

    def start(self):
        self.init_tracking()
        while True:
            self.poll()
            time.sleep(30)

    def init_tracking(self):

        url = 'http://' + self.host + ':' + self.port + '/l/v/track.php'\
              + '?event=init'\
              + '&visit-session-id='\
              + '&url=test.com'\
              + '&referer=referer.ru'\
              + '&lang=ru'\
              + '&department-key='\
              + '&since=0'\
              + '&callback=callback'\
              + '&account-name=' + self.account_name

        print url
        response, req_time = self.request(url)
        print response

        self.visit_session_id = response['fullUpdate']['visitSessionId']
        self.page_id = response['fullUpdate']['pageId']# if self.revision else 'none'
        self.revision = response['revision']



    def poll(self):

        url = 'http://' + self.host + ':' + self.port + '/l/v/track.php'\
              + '?event=poll'\
              + '&visit-session-id=' + self.visit_session_id\
              + '&page-id=' + self.page_id\
              + '&since=' + str(self.revision)\
              + '&callback=callback'\
              + '&account-name=' + self.account_name

        print url
        response, resp_time = self.request(url)
        print response
        print resp_time

        self.store_response_time(resp_time)

        if 'error' in response and response['error'] == 'reinit-required':
            self.init_tracking()
        elif 'revision' in response:
            self.revision = response['revision']

    def store_response_time(self, response_time):
        query = 'insert into stats_tornadoresponsetime (host, port, responsetime, dtm) values (%s, %s, %s, %s)'
        c = webim.db_utils.get_connection()
        c.execute(query, self.host, self.port, response_time, datetime.datetime.fromtimestamp(time.time()))
        c.close()

    def request(self, url):

        opener = urllib2.build_opener()
    #        opener.addheaders += [
    #                ('Cookie', self.request.headers['Cookie']),
    #                ('User-Agent', self.request.headers['User-Agent'])]

        start_ts = time.time()
        f = opener.open(url)
        res = f.read()
        end_ts = time.time()

#        print res.index('{', res.index('{') + 1)
#        print res.rindex('}', 0, res.rindex('}') - 1)
#        print len(res)
        responseJson = res[res.index('{', res.index('{') + 1) : res.rindex('}', 0, res.rindex('}') - 1) + 1             ]

#        print res
#        print responseJson

        try:
            f.close()
        except:
            logging.error("Error while trying to execute target", exc_info=True)

        return json.loads(responseJson), end_ts - start_ts


servers = [
    ('s1.webim.ru', '8270', 'laptopdesk'),
    ('laptopdesk.pro-service.webim.ru', '80', 'laptopdesk'),
]
#servers = [
#    ('s1.webim.ru', '8260', 'laptopdesk'),
#    ('s1.webim.ru', '8270', 'laptopdesk'),
#    ('s1.webim.ru', '8271', 'laptopdesk'),
#    ('s1.webim.ru', '8272', 'laptopdesk'),
#    ('s2.webim.ru', '8260', 'laptopdesk'),
#    ('s2.webim.ru', '8269', 'laptopdesk'),
#    ('s2.webim.ru', '8241', 'laptopdesk'),
#]

for host, port, account_name in servers:
    emulator = VisitedPageEmulator(host, port, account_name)
    th = threading.Thread(target=emulator.start)
    th.start()
