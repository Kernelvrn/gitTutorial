#!/usr/bin/env python
# -*- coding: utf-8 -*-
# # codepage=UTF8
# coding: utf-8
# version 1.0
import time
import sys
import traceback
import threading
import signal
import operator
import os
import platform
import logging
import json
import profile
import pstats
import datetime
import urllib
import gc
from urlparse import urlparse

import tornado.auth
import tornado.escape
import tornado.httpserver
import tornado.ioloop
import tornado.options
import tornado.web
from tornado.options import define, options

import recipe
import objgraph
import webim.visitor_tracking
import webim.account
import webim.db_storage
from webim.wm_timer import TimersStatRequestHandler
import webim.wm_web
import webim.button
import webim.wm_timer
import webim.waiter
import webim.wm_operator
import webim.wm_history
import webim.wm_utils
import webim.zendesk
import webim.unisender
import webim.user_agent_parser
import webim.ordered_service
import webim.wm_queue
import webim.wm_tariff
import webim.ddl_update
import webim.wm_account_settings
import webim.api
import webim.wm_cobrowsing
import webim.wm_zabbix
import webim.db_utils as db_utils
import webim.aux.nethouse
from webim import wm_timer
from webim import wm_settings
from webim.callback_hunter import CallbackHunterEventRequestHandler
from webim.channels import wm_telegram_bot, wm_vk, wm_whatsapp, wm_facebook, wm_custom, wm_viber, wm_ok
from webim import wm_resources
from webim import wm_web
from webim import ordered_service


define("port", default=8260, help="run on the given port", type=int)
define("online_dir", default=wm_settings.settings['online_dir'], help="online directory", type=str)
define("logged_in_operators_dir", default="/var/www/webim_ru/login/cache/operators", help="directory with logged in operators", type=str)
define("upstream_timeout", default=40, help="upstream timeout", type=int)
define("profiler_filename", default='', help="profiler_file_name", type=str)
define("profiling", default=True, help="is profiling enabled", type=bool)
# define("maxmind_city_db", default="geo/GeoIPCity.dat", help="MaxMind city db path", type=str)
# define("log_file_prefix", default="tornado", help="Tornado log file prifix", type=str)

START_TIME = time.time()

# This is a throwaway variable to deal with a python bug
throwaway = datetime.datetime.strptime('20110101', '%Y%m%d')


class Application(tornado.web.Application):
    def __init__(self):
        handlers = [
            # (r"/l/o/update.php", ChatUpdatesRequestHandler),
            (r"/webim/button.php", webim.button.ButtonRequestHandler),
            (r"/api/v(\d+)/file", webim.api.APIFileRequestHandler),
            (r"/api/v(\d+)/rt/([^/]+)", webim.api.RealTimeAPIRequestHandler),
            (r"/api/v(\d+)/([^/]+)/?(.*)", webim.api.APIRequestHandler),
            (r"/l/button.php", webim.button.ButtonRequestHandler),
            (r"/l/v/track.php", webim.visitor_tracking.VisitorTrackingRequestHandler),
            (r"/l/v/delta", webim.visitor_tracking.VisitorDeltaRequestHandler),
            (r"/l/v/action", webim.visitor_tracking.VisitorActionRequestHandler),
            (r"/l/v/download/(\w+)/([^/]*)", webim.visitor_tracking.VisitorDownloadRequestHandler),
            (r"/l/v/upload.php", webim.visitor_tracking.UploadRequestHandler),
            (r"/l/v/upload", webim.visitor_tracking.UploadRequestHandler),
            (r"/l/v/enum-operators.php", webim.wm_operator.OperatorsListRequestHandler),
            (r"/l/v/get-online-status", webim.visitor_tracking.GetOnlineStatusRequestHandler),
            (r"/l/v/history", webim.wm_history.HistoryRequestHandler),
            (r"/l/v/get-history", webim.wm_history.VisitorHistoryRequestManager),
            (r"/l/v/js-error.php", JsErrorRequestHandler),
            (r"/l/v/vk/(?P<channel_id>[^/]+)", wm_vk.VkontakteCallbackAPIRequestHandler),
            (r"/l/v/telegram/(?P<channel_id>[^/]+)/(?P<secret_key>[^/]+)", wm_telegram_bot.TelegramBotRequestHandler),
            (r"/l/v/blinger/whatsapp", wm_whatsapp.BlingerWhatsappWebhookRequestHandler),
            (r"/l/v/fb/([^/]+)", wm_facebook.FacebookWebhookRequestHandler),
            (r"/l/v/viber/(?P<channel_id>[^/]+)", wm_viber.ViberRequestHandler),
            (r"/l/v/ok/(?P<channel_id>[^/]+)", wm_ok.OdnoklassnikiCallbackAPIRequestHandler),
            (r"/l/v/m/delta", webim.visitor_tracking.VisitorDeltaRequestHandler),
            (r"/l/v/m/action", webim.visitor_tracking.VisitorActionRequestHandler),
            (r"/l/v/m/download/(\w+)/([^/]*)", webim.visitor_tracking.VisitorDownloadRequestHandler),
            (r"/l/v/m/upload", webim.visitor_tracking.UploadRequestHandler),
            (r"/l/v/m/history", webim.wm_history.MobileHistorySinceRequestHandler),
            (r"/l/o/delta", webim.wm_operator.OperatorDeltaRequestHandler),
            (r"/l/o/download/(\w+)/([^/]*)", webim.wm_operator.OperatorDownloadRequestHandler),
            (r"/l/o/visitors.php", webim.wm_operator.OperatorDeltaRequestHandler),
            (r"/l/o/visit-session.php", webim.visitor_tracking.VisitSessionRequestHandler),
            (r"/l/o/action.php", webim.wm_operator.OperatorActionRequestHandler),
            (r"/l/o/online-operators.php", webim.wm_operator.OperatorOnlineOperatorsListRequestHandler),
            (r"/l/o/current-stats.php", webim.wm_operator.CurrentStatisticsRequestHandler),
            (r"/l/o/set-status", webim.wm_operator.SetStatusRequestHandler),
            (r"/l/o/ios/get-status", webim.wm_operator.IosGetStatusRequestHandler),
            (r"/l/o/ios/set-status", webim.wm_operator.IosSetStatusRequestHandler),
            (r"/l/o/ios/online-tokens", webim.wm_operator.OperatorDevicesRequestHandler),
            (r"/l/o/get-data", webim.wm_operator.OperatorDataRequestHandler),
            (r"/l/o/android/get-status", webim.wm_operator.AndroidGetStatusRequestHandler),
            (r"/l/o/android/set-status", webim.wm_operator.AndroidSetStatusRequestHandler),
            (r"/l/o/android/online-tokens", webim.wm_operator.OperatorDevicesRequestHandler),
            (r"/l/o/inf/set-status", webim.wm_operator.InfSetStatusRequestHandler),
            (r"/l/o/devices", webim.wm_operator.OperatorDevicesRequestHandler),
            (r"/l/o/js-error.php", JsErrorRequestHandler),
            (r"/l/o/current-ts", CurrentTsRequestHandler),
            (r"/l/o/zendesk_ticket", webim.zendesk.ZendeskRequestHandler),
            (r"/l/o/export-contacts-to-unisender", webim.unisender.ExportContactsToUnisenderRequestHandler),
            (r"/l/o/get-operator-chat-history", webim.wm_operator.OperatorChatHistoryRequestHandler),
            (r"/l/o/get-operator-statuses", webim.wm_operator.OperatorStatusesRequestHandler),
            (r"/l/o/close-chats", webim.wm_operator.CloseChatsRequestHandler),
            (r"/l/o/close-offline-chats", webim.wm_operator.CloseOfflineChatsRequestHandler),
            (r"/l/o/check-spelling2", webim.wm_operator.SpellCheckRequestHandler2),
            (r"/l/o/check-spelling", webim.wm_operator.SpellCheckRequestHandler),
            (r"/l/o/out", OutRequestHandler),
            (r"/l/o/settings/channels", webim.wm_account_settings.ChannelSettingRequestHandler),
            (r"/l/o/settings/private-keys", webim.wm_account_settings.PrivateKeysSettingRequestHandler),
            (r"/l/o/settings/spelling-dict", webim.wm_account_settings.SpellingDictSettingRequestHandler),

            (r"/ws/o/delta", webim.wm_operator.OperatorWebSocketDeltaRequestHandler),
            (r"/ws/v/action", webim.visitor_tracking.VisitorWebSocketActionRequestHandler),
            (r"/ws/o/cobrowsing", webim.wm_cobrowsing.CobrowsingWebsocketHandler),
            (r"/ws/v/cobrowsing", webim.wm_cobrowsing.CobrowsingWebsocketHandler),

            (r"/l/o/ordered-service.php", webim.ordered_service.OrderedServiceRequestHandler),
            # (r"/l/o/paypal", webim.paypal.PaypalRequestHandler),
            # (r"/l/o/ipn", webim.paypal.PayPalIPNListener),
            (r"/l/o/pingservice", OperatorPingServiceRequestHandler),

            (r"/l/a/pingservice", PingServiceRequestHandler),

            (r"/l/a/monitor", MonitorRequestHandler),
            (r"/l/a/monitor/reload", ReloadRequestHandler),
            (r"/l/a/monitor/timer-stats", TimersStatRequestHandler),
            (r"/l/a/monitor/accounts-stat", webim.account.AccountsStatMonitorRequestHandler),
            (r"/l/a/monitor/zabbix/tornado", webim.wm_zabbix.TornadoStatsRequestHandler),
            (r"/l/a/monitor/zabbix/channels", webim.wm_zabbix.ChannelErrorStatsRequestHandler),
            (r"/l/a/monitor/failed-to-store-objects", webim.db_storage.CollectedToStoreObjectsMonitorRequestHandler),  # todo remove later
            (r"/l/a/monitor/collected-to-store-objects", webim.db_storage.CollectedToStoreObjectsMonitorRequestHandler),
            (r"/l/a/monitor/change-storager-status", webim.db_storage.ChangeStoragerStatusRequestHandler),
            (r"/l/a/monitor/store-now", webim.db_storage.StoreNowRequestHandler),
            (r"/l/a/monitor/set-ignore-not-belongs", webim.account.IgnoreNotBelongsRequestHandler),
            (r"/l/a/monitor/object-stats", ObjectStatsRequestHandler),
            (r"/l/a/monitor/db-settings", DbSettingsRequestHandler),
            (r"/l/a/monitor/connect-to-db", ConnectToDatabaseRequestHandler),

            (r"/l/a/ordered-service", webim.ordered_service.OrderedServiceAdmRequestHandler),
            (r"/l/a/enum-operators", webim.wm_operator.OperatorsListAdmRequestHandler),
            (r"/l/a/set-profiling-status", ProfilingStatusChangeRequestHandler),
            (r"/l/a/tariff-editor", webim.wm_tariff.TariffEditorRequestHandler),
            (r"/l/a/create-custom-tariff", webim.wm_tariff.CreateCustomTariffRequestHandler),
            (r"/l/a/tariffs-info", webim.wm_tariff.TariffsInfoRequestHandler),
            (r"/l/a/ddl-updater-dry-run", webim.ddl_update.DdlUpdaterDryRunRequestHandler),
            (r"/l/a/gc", GarbageCollectorDebugRequestHandler),
            (r"/l/a/get-orderedservice-keys", ordered_service.GetOrderedServiceKeys),
            (r"/l/a/aux/compare-nethouse-report", webim.aux.nethouse.CompareNethouseReportRequestHandler),


            (r"/l/i/instance-id", InstanceIdRequestHandler),
            (r"/l/i/visit-session", webim.visitor_tracking.VisitSessionPhpRequestHandler),
            (r"/l/i/set-device-status", webim.wm_operator.SetDeviceStatusRequestHandler),
            (r"/l/i/reset-cache", webim.account.ResetCacheRequestHandler),
            (r"/l/i/on-payment-accepted", webim.ordered_service.OnPaymentAcceptedRequestHandler),
            (r"/l/i/daily", DailyRequestHandler),
            (r"/l/i/user-agent-parser", webim.user_agent_parser.UserAgentParseHandler),
            (r"/l/i/send-payed-period-ending-notifications", webim.ordered_service.SendPayedPeriodEndingNotificationsRequestHandler),
            (r"/l/i/disconnect-all-operators", webim.wm_operator.DisconnectAllOperatorsRequestHandler),
            (r"/l/i/disconnect-devices", webim.wm_operator.DisconnectAllDevicesRequestHandler),
            (r"/l/i/check-big-accounts", webim.account.CheckBigAccountsRequestHandler),
            (r"/l/i/callback-update", CallbackHunterEventRequestHandler),
            (r"/l/i/auth-in-bitrix24", webim.account.GetBitrix24Tokens),
            (r"/l/i/account-state", webim.account.AccountStateRequestHandler),
            (r"/l/i/login-logout-operator-event-fire", webim.wm_operator.LoginLogoutOperatorEventFireRequestHandler),

            (r"/l/c/download/(\w+)/([^/]*)", wm_web.CommonDownloadRequestHandler),

            (r"/l/test", TestRequestHandler),

            (r"/l/ch", wm_custom.CustomChannelRequestHandler),
            # (r"/l/ch/test", wm_custom.CustomTest),

            # (r"/webim/operator/update.php", ChatUpdatesRequestHandler), #for plugin
        ]
        settings = dict(
            cookie_secret="43oETzKXQAGaYdkL5gEmGeJJFuYh7EQnp2XdTP1o/Vo=",
            login_url="/auth/login",
            template_path=os.path.join(os.path.dirname(__file__), "webim/templates"),
            static_path=os.path.join(os.path.dirname(__file__), "static"),
            xsrf_cookies=False,
        )
        # webim.user_agent_parser.BrowserCapabilities() # to initialize BC before http server start
        # webim.user_agent_parser.PyBrowscap() # to initialize BC before http server start

        wm_timer.invoke_async(target=webim.user_agent_parser.PyBrowscap, timer_name='pybrowscap')
        tornado.web.Application.__init__(self, handlers, **settings)


class InstanceIdRequestHandler(webim.wm_web.BaseWebimRequestHandler):
    def get(self, *args, **kwargs):
        self.write(webim.wm_utils.tornado_instance_id)


class MonitorRequestHandler(webim.wm_web.AdminRequestHandler):

    @tornado.web.asynchronous
    def get(self, *args, **kwargs):
        wm_timer.invoke_async(self.__get, timer_name='MonitorRequestHandler')

    def __get(self):
        env = webim.wm_utils.get_current_env()
        main_info = {
            'env': env,
            'port': options.port,
            'startTs': START_TIME,
            'startTime': time.strftime('%d-%m-%Y %H:%M:%S', time.localtime(START_TIME)),
            'version': webim.wm_utils.version,
            'ubuntuVersion': platform.dist()[1],
            'branch': webim.wm_utils.branch,
            'avgNTries': round(webim.visitor_tracking.average_number_of_track_request_tries.get_average(), 3),
            'n': webim.visitor_tracking.average_number_of_track_request_tries.get_n(),
            'storingEnabled': webim.db_storage.BackgroundStorager.enabled
        }

        webim.wm_utils.invoke_in_ioloop(lambda: self.finish(json.dumps({'mainInfo': main_info, 'host': self.request.host})), name='MonitorRequestHandler')


class PingServiceRequestHandler(webim.wm_web.AdminRequestHandler):
    def get(self, *args, **kwargs):
        self.write(json.dumps({'result': 'ok'}))


class OperatorPingServiceRequestHandler(webim.wm_web.BaseWebimRequestHandler):
    def get_account(self):
        # для того, чтобы запросы не приводили к созданию полного аккаунта, чтобы можно было вынести
        # обработу этих запросов на отдельный инстанс сервера
        return webim.account.BriefAccount.get(self.get_account_name())

    def get(self, *args, **kwargs):
        logging.warn('Ping ts:' + self.get_argument('ts') + ' pingerId:' + self.get_argument('pinger-id') + ' operatorId:' + str(self.get_operator_id()))
        self.write(json.dumps({'result': 'ok'}))


class OutRequestHandler(webim.wm_operator.BaseOperatorRequestHandler):
    def get(self, *args, **kwargs):
        url = self.get_argument('redir', default=None)

        if not url:
            return
        url = urllib.unquote(url).decode('utf8')
        url = url if urlparse(url).scheme else 'http://' + url

        allowed_domains = self.get_account().get_setting('allowed_for_redirect_domains')
        if allowed_domains:
            allowed_domains = allowed_domains.split(', ')
            domain = urlparse(url).scheme + '://' + urlparse(url).hostname
            if domain not in allowed_domains and urlparse(url).hostname not in allowed_domains:
                self.write(wm_resources.get_resource(self.get_account(),
                                                     self.get_operator_context().get('lang'),
                                                     'out.insecure_domain'))
                return
        self.redirect(url)

    def requires_account_not_blocked(self):
        return False

    def on_unauthorized_operator(self):
        self.redirect("/login.php")


class ReloadRequestHandler(webim.wm_web.AdminRequestHandler):

    @tornado.web.asynchronous
    def get(self, *args, **kwargs):
        wm_timer.invoke_async(self.__get, timer_name='ReloadRequestHandler')

    def __get(self):
        webim.wm_utils.BaseCache.reset_all()
        wm_settings.load()
        webim.wm_utils.invoke_in_ioloop(lambda: self.finish(json.dumps({'result': 'ok'})), name='ReloadRequestHandler')


class JsErrorRequestHandler(webim.wm_web.CrossDomainRequestHandler):

    def post(self, *args, **kwargs):
        self.get(*args, **kwargs)

    def get(self, *args, **kwargs):
        message = 'JavaScript error.\nAccount: %s\nUser Agent: %s\nIP: %s\nError:\n%s' % (self.get_account_name(),
                                                                                          self.get_header('User-Agent', ''),
                                                                                          self.get_ip(''),
                                                                                          self.get_argument('error'))
        logging.warn(message)
        self.send_result({'result': 'ok'})


class CurrentTsRequestHandler(webim.wm_web.CrossDomainRequestHandler):

    def get(self, *args, **kwargs):
        self.send_result({'currentTs': time.time()})


class DailyRequestHandler(tornado.web.RequestHandler):

    @tornado.web.asynchronous
    def get(self, *args, **kwargs):
        def process():
            self.write('<pre>')
            webim.ordered_service.process_daily_operations(self, automatic_reorder_only=self.get_argument('automatic_reorder_only', 'false') == 'true')
            self.finish('</pre>')
        wm_timer.invoke_async(process, 'daily processing')


class TestRequestHandler(tornado.web.RequestHandler):

    def post(self, *args, **kwargs):
        print '################## POST'
        print json.dumps(json.loads(self.get_argument('chat')), indent=1, ensure_ascii=False)
        # print self.get_argument('messageText')
        # print self.request.arguments

    def get(self, *args, **kwargs):
        print '################## GET'
        print self.request.body


class ObjectStatsRequestHandler(webim.wm_web.AdminRequestHandler):

    @tornado.web.asynchronous
    def get(self, *args, **kwargs):
        wm_timer.invoke_async(self.__get, timer_name='ObjectStatsRequestHandler get')

    def __get(self):
        limit = 50
        typestats = sorted(objgraph.typestats().items(), key=operator.itemgetter(1), reverse=True)
        if limit:
            typestats = typestats[:limit]

        width = max(len(name) for name, count in typestats)

        for name, count in typestats:
            self.write(name.ljust(width) + ': ' + str(count) + '\n')
        self.finish()


class GarbageCollectorDebugRequestHandler(tornado.web.RequestHandler):

    @tornado.web.asynchronous
    def get(self, *args, **kwargs):
        wm_timer.invoke_async(self.__get, timer_name='gc req handler')

    def __get(self):
        enable = self.get_argument('status')
        try:
            enable = int(enable)
            gc.set_debug(gc.DEBUG_STATS if enable else 0)
            logging.warning('GC status: %s' % str(enable))
            self.finish(json.dumps({'result': 'ok', 'status': bool(enable)}))
        except Exception as e:
            self.finish(json.dumps({'result': 'error', 'e': str(e)}))


class ProfilingStatusChangeRequestHandler(tornado.web.RequestHandler):

    def get(self, *args, **kwargs):
        enabled = bool(int(self.get_argument('status', 0)))

        if options.profiler_filename:
            try:
                if enabled != options.profiling:
                    if not enabled:
                        snapshot_filename = options.profiler_filename + '_' + str(time.time())
                        stats.dump_stats(snapshot_filename)
                        logging.warn('Profiler snapshot made: %s' % snapshot_filename)
                        restart_profiler()
                    options.profiling = enabled
                self.finish('new status - ' + str(enabled))
            except Exception as e:
                self.finish('Got errror: %s' % str(e))
        else:
            self.finish('profiler_filename not set, profiling disabled, restart tornado with --profiler_filename=xxx option')


class DbSettingsRequestHandler(webim.wm_web.AdminRequestHandler):
    def get(self, *args, **kwargs):
        db_settings = wm_settings.get_account_db_settings(self.get_account_name())['pro']
        db_settings = db_settings.get(self.get_account_name(), db_settings['default'])
        db_settings = db_settings.copy()
        db_settings['password'] = '*****'
        self.write(json.dumps(db_settings))


class ConnectToDatabaseRequestHandler(webim.wm_web.AdminRequestHandler):

    @tornado.web.asynchronous
    def get(self, *args, **kwargs):
        wm_timer.invoke_async(self.__get, timer_name='connect to db req handler')

    def __get(self):
        try:
            conn = db_utils.get_connection()
            # version_query = 'SET GLOBAL connect_timeout=1000; SELECT VERSION()'
            version_query = 'SELECT VERSION()'
            if conn.get(version_query):
                self.set_status(200)
                self.finish(json.dumps({'result': 'ok'}))
            else:
                self.set_status(500)
                self.finish(json.dumps({'result': 'error'}))
        except Exception as e:
            self.set_status(500)
            self.finish(json.dumps({'result': 'error', 'e': str(e)}))


class LoggerWriter:

    def __init__(self, level):
        self.level = level

    def write(self, message):
        if message != '\n':
            self.level(message)

    def flush(self):
        pass


def main():
    tornado.options.parse_command_line()

    if options.profiler_filename:
        old_execute = tornado.web.RequestHandler._execute
        tornado.web.RequestHandler._execute = profile_patch(old_execute)
        restart_profiler()

    logger = logging.getLogger('gc')
    sys.stderr = LoggerWriter(logger.warning)

    try:
        import __pypy__  # noqa
        logging.warn('Interpreter: PyPy')
    except Exception:
        logging.warn('Interpreter: CPython')

    logging.warn("Port: %d" % options.port)
    logging.warn("Online files dir: %s" % options.online_dir)
    logging.warn("profiler filename: %s" % (options.profiler_filename if options.profiler_filename else 'Not set, profiling disabled'))
    logging.warn("Starting server " + webim.wm_utils.tornado_instance_id + " ...")

    application = Application()

    http_server = tornado.httpserver.HTTPServer(application)
    http_server.listen(options.port)

    thread = threading.Thread(name='io loop', target=start_ioloop)
    thread.start()

    signal.signal(signal.SIGUSR1, list_threads_and_backup_collected_data)

    recipe.listen()

    last_objects_not_stored_report_ts = 0

    while True:
        try:
            if not thread.isAlive():
                logging.error('tornado io loop thread is not alive - restarting')
                thread = threading.Thread(name='io loop', target=start_ioloop)
                thread.start()
        except Exception:
            pass

        try:
            now = time.time()
            if now - webim.db_storage.BackgroundStorager.objects_not_stored_since_ts > 60:
                if now - last_objects_not_stored_report_ts > 60 * 10:
                    last_objects_not_stored_report_ts = now
                    logging.error('objects not stored since ts ' + str(webim.db_storage.BackgroundStorager.objects_not_stored_since_ts))
                    wm_timer.invoke_async(lambda: webim.db_storage.BackgroundStorager.store_all(num=0), 'emergency background storaging 0')
                    wm_timer.invoke_async(lambda: webim.db_storage.BackgroundStorager.store_all(num=1), 'emergency background storaging 1')
        except Exception:
            pass

        time.sleep(wm_settings.settings.get('tornado_io_loop_cheking_period', 1))


def profile_patch(execute):
    def _(self, transforms, *args, **kwargs):
        if options.profiling and options.profiler_filename:
            self.profiler = profile.Profile()
            result = self.profiler.runcall(execute, self, transforms, *args, **kwargs)
            stats.add(self.profiler)
            stats.dump_stats(options.profiler_filename)

            return result
        else:
            return execute(self, transforms, *args, **kwargs)
    return _


def start_ioloop():
    tornado.ioloop.IOLoop.instance().start()


def list_threads_and_backup_collected_data(sig, frame):
    webim.db_storage.BackgroundStorager.backup_all()
    result = '####### \n'.join([''.join(traceback.format_stack(f)) for f in sys._current_frames().values()])
    logging.error(result)


def restart_profiler():
    global profiler, stats
    profiler = profile.Profile()
    profiler.dump_stats(options.profiler_filename)
    stats = pstats.Stats(options.profiler_filename)


if __name__ == "__main__":
    # print "Main"
    profiler = None
    stats = None
    main()
