# coding=UTF-8
import logging
import traceback

import db_utils
import account
import wm_mail
import wm_web
import wm_settings


class BaseDdlUpdater:

    def __init__(self, check_next_if_dont_need_update=False, skip_for_big_account=False):
        self.check_next_if_dont_need_update = check_next_if_dont_need_update
        self.skip_for_big_account = skip_for_big_account

    def check_must_be_skipped(self, ctx):
        return self.skip_for_big_account and ctx.account_name in wm_settings.settings.get('big_accounts', [])

    def check_need_update(self, ctx):
        raise Exception('must be overridden')

    def update(self, ctx):
        raise Exception('must be overridden')


class DdlUpdateContext:

    def __init__(self, account_name, connection):
        self.account_name = account_name
        self.connection = connection

    def log(self, message):
        logging.warn('DdlUpd @' + self.account_name + ': ' + message)

    def log_error(self, message):
        logging.warn('DdlUpd @' + self.account_name + ': ' + message, exc_info=True)


class ColumnDdlUpdater(BaseDdlUpdater):  # deprecated

    def __init__(self, table_name, column_name, column_type, check_next_if_dont_need_update=False):
        BaseDdlUpdater.__init__(self, check_next_if_dont_need_update)
        self.table_name = table_name
        self.column_name = column_name
        self.column_type = column_type

    def check_need_update(self, ctx):
        query = 'show columns in ' + self.table_name + ' where field=%s'
        rows = ctx.connection.query(query, self.column_name)
        result = len(rows) == 0
        ctx.log('ColumnDdlUpdater (' + self.table_name + ', ' + self.column_name + ') need update: ' + str(result))
        return result

    def update(self, ctx):
        query = 'alter table ' + self.table_name + ' add column ' + self.column_name + ' ' + self.column_type
        ctx.connection.execute(query)

        ctx.log('ColumnDdlUpdater (' + self.table_name + ', ' + self.column_name + ') column added')


class ColumnsDdlUpdater(BaseDdlUpdater):

    def __init__(self, table_name, column_descriptors, check_next_if_dont_need_update=False, skip_for_big_account=False):
        BaseDdlUpdater.__init__(self, check_next_if_dont_need_update, skip_for_big_account)
        self.table_name = table_name
        self.column_descriptors = [{'name': d[0], 'type': d[1]} if type(d) is tuple else d for d in column_descriptors]

    def __get_columns_to_add_and_modify(self, ctx):
        query = "show full columns in " + self.table_name + " where field in ('" + "','".join([d['name'] for d in self.column_descriptors]) + "')"
        logging.info(query)
        rows = ctx.connection.query(query)
        name_to_selected_column = {r['Field']: r for r in rows}
        to_add = []
        to_modify = []
        for d in self.column_descriptors:
            selected_column = name_to_selected_column.get(d['name'])
            if not selected_column:
                to_add.append(d)
            else:
                modify = False
                if d.get('characterSet'):
                    selected_character_set = selected_column['Collation'] and selected_column['Collation'].split('_')[0]
                    if d['characterSet'] != selected_character_set:
                        modify = True

                # тут по мере необходимости можно будет добавить проверку на совпадение типа и т.п.

                if modify:
                    if 'type' not in d:
                        d['type'] = selected_column['Type']
                    to_modify.append(d)

        return to_add, to_modify

    def check_need_update(self, ctx):
        to_add, to_modify = self.__get_columns_to_add_and_modify(ctx)
        result = len(to_add) != 0 or len(to_modify) != 0
        ctx.log('ColumnsDdlUpdater (' + self.table_name + ') need update: '
                + str(result) + ', columns to add: ' + str([d['name'] for d in to_add]) + ', columns to modify: ' + str([d['name'] for d in to_modify]))
        return result

    def update(self, ctx):
        to_add, to_modify = self.__get_columns_to_add_and_modify(ctx)
        alter_specifications = []
        alter_specifications.extend(self.__prepare_alter_specifications(to_add, 'add'))
        alter_specifications.extend(self.__prepare_alter_specifications(to_modify, 'modify'))
        query = 'alter table ' + self.table_name + ' ' + ', '.join(alter_specifications)
        ctx.log(query)
        ctx.connection.execute(query)
        ctx.log(
            'ColumnsDdlUpdater ({table_name}) columns {columns_to_add} added, columns {columns_to_modify} modified'.format(
                table_name=self.table_name,
                columns_to_add=str([d['name'] for d in to_add]),
                columns_to_modify=str([d['name'] for d in to_modify])
            )
        )

    def __prepare_alter_specifications(self, descriptors, add_or_modify):
        for d in descriptors:
            s = add_or_modify + ' column ' + d['name'] + ' ' + d['type']
            if 'characterSet' in d:
                s += ' character set ' + d['characterSet']
            yield s



class AddSignatureColumnToOrderedServiceDdlUpdater(BaseDdlUpdater):

    def __init__(self):
        BaseDdlUpdater.__init__(self, True)

    def check_need_update(self, ctx):
        if not wm_settings.is_hosted_mode():
            result = False
        else:
            query = "SHOW COLUMNS FROM orderedservice"
            logging.info(query)
            connection = db_utils.get_connection()
            rows = connection.query(query)
            selected_columns = [r['Field'] for r in rows]
            result = 'signature' not in selected_columns
        ctx.log('AddSignatureColumnToOrderedServiceDdlUpdater (orderedservice) need update: {}'.format(result))
        return result

    def update(self, ctx):
        query = 'ALTER TABLE orderedservice ADD COLUMN signature LONGTEXT'
        connection = db_utils.get_connection()
        ctx.log(query)
        connection.execute(query)
        ctx.log('AddSignatureColumnToOrderedServiceDdlUpdater (orderedservice) column "signature" added')


class FillColumnValueUpdater(BaseDdlUpdater):

    def __init__(self, table_name, column_name, fill_with_expression, check_next_if_dont_need_update=False):
        BaseDdlUpdater.__init__(self, check_next_if_dont_need_update)
        self.table_name = table_name
        self.column_name = column_name
        self.fill_with_expression = fill_with_expression

    def check_need_update(self, ctx):
        query = 'show columns in ' + self.table_name + ' where field=%s'
        rows = ctx.connection.query(query, self.column_name)
        result = len(rows) == 0
        if not result:
            ctx.connection.execute('SET SQL_BIG_SELECTS=1')
            row = ctx.connection.get('select exists (SELECT * FROM ' + self.table_name + ' where ' + self.column_name + ' is null) ex')
            ctx.connection.execute('SET SQL_BIG_SELECTS=0')
            result = row['ex'] == 1
        ctx.log('FillColumnValueUpdater (' + self.table_name + ', ' + self.column_name + ') need update: ' + str(result))
        return result

    def update(self, ctx):
        query = 'update ' + self.table_name + ' set ' + self.column_name + ' = ' + self.fill_with_expression + ' where ' + self.column_name + ' is null'
        ctx.log(query)
        ctx.connection.execute(query)

        ctx.log('FillColumnValueUpdater (' + self.table_name + ', ' + self.column_name + ') column filled')


class TableDdlUpdater(BaseDdlUpdater):

    def __init__(self, table_name, create_sql_query, check_next_if_dont_need_update=False):
        BaseDdlUpdater.__init__(self, check_next_if_dont_need_update)
        self.table_name = table_name
        self.create_sql_query = create_sql_query

    def check_need_update(self, ctx):
        query = 'SHOW TABLES LIKE %s'
        rows = ctx.connection.query(query, self.table_name)
        result = len(rows) == 0
        ctx.log('TableDDlUpdater (' + self.table_name + ') need update: ' + str(result))
        return result

    def update(self, ctx):
        ctx.connection.execute(self.create_sql_query)
        ctx.log('TableDdlUpdater (' + self.table_name + ') table created')


class ModifyColumnDdlUpdater(BaseDdlUpdater):

    # IMPORTANT!
    # Do not use this class with "DEFAULT something" in {new_type} param

    def __init__(self, table_name, column_name, new_type, check_next_if_dont_need_update=False):
        BaseDdlUpdater.__init__(self, check_next_if_dont_need_update)
        self.table_name = table_name
        self.column_name = column_name
        self.new_type = new_type

    def check_need_update(self, ctx):
        query = "SHOW COLUMNS FROM " + self.table_name + " WHERE field=%s"
        rows = ctx.connection.query(query, self.column_name)
        result = len(rows) and rows[0] and rows[0]['Type'] != self.new_type
        ctx.log('ModifyColumnDdlUpdater (' + self.table_name + '-' + self.column_name + ') need update to ' + self.new_type + ' : ' + str(result))

        return result

    def update(self, ctx):
        query = "ALTER TABLE " + self.table_name + " MODIFY COLUMN " + self.column_name + " " + self.new_type
        ctx.connection.execute(query)
        ctx.log('ModifyColumnDdlUpdater (' + self.table_name + '-' + self.column_name + ') updated to ' + self.new_type)


class BaseFixDataDdlUpdater(BaseDdlUpdater):

    def check_need_update(self, ctx):
        return True

    def process_queries(self, ctx, queries):
        for q in queries:
            try:
                ctx.log(q)
                ctx.connection.execute(q)
            except Exception:
                ctx.log_error('query failed: ' + q)
                raise


class FixChatThreadDataDdlUpdater(BaseFixDataDdlUpdater):

    def update(self, ctx):
        queries = [
            "alter table chatthread change column lastpingvisitor lastpingvisitor timestamp NULL default NULL, change column lastpingagent lastpingagent timestamp NULL default NULL",  # noqa: E501
            "update chatthread set created='1970-01-01 00:00:00' where created='0000-00-00 00:00:00'",
            "update chatthread set lastpingvisitor='1970-01-02 00:00:00' where lastpingvisitor='0000-00-00 00:00:00'",
            "update chatthread set lastpingagent='1970-01-02 00:00:00' where lastpingagent='0000-00-00 00:00:00'",
        ]
        self.process_queries(ctx, queries)


class FixChatMessageDataDdlUpdater(BaseFixDataDdlUpdater):

    def check_need_update(self, ctx):
        return True

    def update(self, ctx):
        queries = ["update chatmessage set created='1970-01-01 00:00:00' where created='0000-00-00 00:00:00'"]
        self.process_queries(ctx, queries)


class FixChatVisitSessionDataDdlUpdater(BaseFixDataDdlUpdater):

    def update(self, ctx):
        queries = [
            "update chatvisitsession set created='1970-01-01 00:00:00' where created='0000-00-00 00:00:00'",
            "update chatvisitsession set updated='1970-01-01 00:00:00' where updated='0000-00-00 00:00:00'",
        ]
        self.process_queries(ctx, queries)


# class DelColumnDdlUpdater(ColumnDddUpdater):
#
#     def __init__(self, table_name, column_name, check_next_if_dont_need_update=False):
#         ColumnDddUpdater.__init__(self, table_name, column_name, None, check_next_if_dont_need_update)
#
#     def checkNeedUpdate(self, ctx):
#         return not ColumnDddUpdater.checkNeedUpdate(self, ctx)
#
#     def update(self, ctx):
#         query = 'alter table ' + self.table_name + ' drop column ' + self.column_name
#         ctx.connection.execute(query)
#         ctx.log('DelColumnDddUpdater (' + self.table_name + ', ' + self.column_name + ') column deleted')


__updaters = [
    AddSignatureColumnToOrderedServiceDdlUpdater(),

    # version 8.16
    ColumnDdlUpdater('chatdepartment', 'deleted', 'int(1) DEFAULT "0"', check_next_if_dont_need_update=True),
    ColumnDdlUpdater('chatoperatordepartment', 'priority', "INT default NULL", check_next_if_dont_need_update=True),

    ColumnsDdlUpdater('chatvisitsession', [
        {'name': 'visitorname', 'characterSet': 'utf8mb4'}
    ], check_next_if_dont_need_update=True, skip_for_big_account=True),

    FixChatVisitSessionDataDdlUpdater(),

    # version 9.0
    FillColumnValueUpdater('chatmessage', 'modifiedts', fill_with_expression='createdts'),
    FillColumnValueUpdater('chatmessage', 'updatedts', fill_with_expression='insertedts'),
    FillColumnValueUpdater('chatmessage', 'insertedts', fill_with_expression='UNIX_TIMESTAMP(created) * 1000000', check_next_if_dont_need_update=True),
    FillColumnValueUpdater('chatmessage', 'createdts', fill_with_expression='UNIX_TIMESTAMP(created) * 1000000', check_next_if_dont_need_update=True),

    ColumnsDdlUpdater('chatmessage', [
        ('json', 'text'),
        ('insertedts', 'bigint'),
        ('createdts', 'bigint'),
        ('modifiedts', 'bigint'),
        ('updatedts', 'bigint'),
        {'name': 'message', 'characterSet': 'utf8mb4'},
        {'name': 'sendername', 'characterSet': 'utf8mb4'},
    ], check_next_if_dont_need_update=True, skip_for_big_account=True),

    TableDdlUpdater('callback', 'CREATE TABLE `callback` (\
                                  `id` int(11) NOT NULL AUTO_INCREMENT,\
                                  `created` datetime NOT NULL,\
                                  `modified` datetime NOT NULL,\
                                  `recorduri` mediumtext,\
                                  `kind` varchar(45) DEFAULT NULL,\
                                  `visitorphone` varchar(45) NOT NULL,\
                                  `operatorphone` varchar(45) NOT NULL,\
                                  `visitsessionid` varchar(45) NOT NULL,\
                                  `referrerurl` mediumtext NOT NULL,\
                                  `uid` varchar(36) NOT NULL,\
                                  `billsec` int(11) DEFAULT NULL,\
                                  PRIMARY KEY (`id`),\
                                  UNIQUE KEY `uid_UNIQUE` (`uid`),\
                                  KEY `idx_kind` (`kind`),\
                                  KEY `idx_created` (`created`),\
                                  KEY `idx_filtered` (`created`, `kind`)\
                                ) ENGINE=InnoDB DEFAULT CHARSET=utf8', check_next_if_dont_need_update=True),
    TableDdlUpdater('callbackhistory', 'CREATE TABLE `callbackhistory` (\
                                          `id` int(11) NOT NULL AUTO_INCREMENT,\
                                          `callbackuid` varchar(36) NOT NULL,\
                                          `created` datetime NOT NULL,\
                                          `state` varchar(45) NOT NULL,\
                                          `event` varchar(45) NOT NULL,\
                                          PRIMARY KEY (`id`),\
                                          KEY `idx_state` (`state`),\
                                          KEY `idx_created` (`created`),\
                                          KEY `idx_callback` (`callbackuid`)\
                                        ) ENGINE=InnoDB DEFAULT CHARSET=utf8', check_next_if_dont_need_update=True),

    # version 8.16
    TableDdlUpdater('keyvalue', 'CREATE TABLE `keyvalue` (\
                                     `id` int(11) NOT NULL AUTO_INCREMENT,\
                                     `key` varchar(45) NOT NULL,\
                                     `value` text,\
                                     `modifiedts` bigint(20) NOT NULL,\
                                     PRIMARY KEY (`id`),\
                                     UNIQUE KEY `key_UNIQUE` (`key`)\
                                    ) ENGINE=InnoDB DEFAULT CHARSET=utf8', check_next_if_dont_need_update=False),
    ModifyColumnDdlUpdater('chatconfig', 'configvalue', 'mediumtext', check_next_if_dont_need_update=True),
    ModifyColumnDdlUpdater('chatdepartment', 'config', 'mediumtext', check_next_if_dont_need_update=True),
    TableDdlUpdater('operatorchatmessage', 'CREATE TABLE `operatorchatmessage` (\
                                            `messageid` int(11) NOT NULL AUTO_INCREMENT,\
                                            `messageuid` varchar(40) NOT NULL,\
                                            `operatorchatid` int(11) NOT NULL,\
                                            `kind` varchar(64) NOT NULL,\
                                            `operatorid` int(11) DEFAULT NULL,\
                                            `sendername` varchar(64) DEFAULT NULL,\
                                            `message` text NOT NULL,\
                                            `created` datetime NOT NULL,\
                                            `json` text,\
                                            PRIMARY KEY (`messageid`),\
                                            KEY `idx_operatorid` (`operatorid`),\
                                            KEY `idx_operatorchatid` (`operatorchatid`)\
                                            ) ENGINE=InnoDB DEFAULT CHARSET=utf8', check_next_if_dont_need_update=True),

    FillColumnValueUpdater('chatthread', 'updatedts', fill_with_expression='UNIX_TIMESTAMP(modified) * 1000000'),
    FillColumnValueUpdater('chatthread', 'insertedts', fill_with_expression='UNIX_TIMESTAMP(created) * 1000000'),
    FillColumnValueUpdater('chatthread', 'modifiedts', fill_with_expression='UNIX_TIMESTAMP(modified) * 1000000'),
    FillColumnValueUpdater('chatthread', 'createdts', fill_with_expression='UNIX_TIMESTAMP(created) * 1000000'),

    ColumnsDdlUpdater('chatthread', [
        ('manuallyassignedoperatorid', 'int(11)'),
        ('startpage', 'text'),

        ('updatedts', 'bigint'),
        ('insertedts', 'bigint'),
        ('modifiedts', 'bigint'),
        ('createdts', 'bigint')]),

    FixChatThreadDataDdlUpdater(),
    FixChatMessageDataDdlUpdater(),

    ColumnDdlUpdater('chatonlineperiod', 'status', "varchar(20) CHARACTER SET ascii default 'online'"),
    ColumnDdlUpdater('chatthreadhistory', 'officeid', 'int(11)', check_next_if_dont_need_update=True),
    ColumnDdlUpdater('chatban', 'json', 'text', check_next_if_dont_need_update=True)]


class DryRunConnection:

    def __init__(self, connection):
        self.connection = connection
        self.executed = []

    def get(self, *args, **kwargs):
        return self.connection.get(*args, **kwargs)

    def query(self, *args, **kwargs):
        return self.connection.query(*args, **kwargs)

    def close(self, *args, **kwargs):
        return self.connection.close(*args, **kwargs)

    def execute(self, query):
        self.executed.append(query)

    def get_report(self):
        return ';\n'.join(self.executed)


def update(account_name, dry_run=False):
    # todo check belongs
    try:
        connection = db_utils.get_connection(account_name)
        if dry_run:
            connection = DryRunConnection(connection)
        ctx = DdlUpdateContext(account_name, connection)
        ctx.log('ddl_update started dry_run=' + str(dry_run))

        updaters_to_process = []
        for u in __updaters:
            if u.check_must_be_skipped(ctx):
                continue

            if u.check_need_update(ctx):
                updaters_to_process.append(u)
            elif not u.check_next_if_dont_need_update:
                break

        for u in reversed(updaters_to_process):
            u.update(ctx)

        connection.close()

        ctx.log('ddl_update finished')
        if dry_run:
            return connection.get_report()
    except Exception:
        # traceback.format_exc() = sys.exc_info()
        wm_mail.mailer.send_short_message_notification(account.Account.get(account_name), "ddl_update failed", traceback.format_exc())
        ctx.log_error('ddl_update failed')


class DdlUpdaterDryRunRequestHandler(wm_web.AdminRequestHandler):
    def get(self, *args, **kwargs):
        report = update(self.get_verified_argument('account_name'), dry_run=True)
        self.write('<pre>')
        self.write(report)
        if not report:
            self.write('Nothing to update')
        self.write('</pre>')
