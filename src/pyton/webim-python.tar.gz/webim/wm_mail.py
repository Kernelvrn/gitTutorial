# coding=utf-8

import logging
import os
import re
import time
from smtplib import SMTP_SSL, SMTP
from email.mime.text import MIMEText

import requests
from jinja2 import Environment, FileSystemLoader

import wm_settings
import db_utils
import wm_timer
import wm_resources
import wm_utils


__author__ = 'oleg'


class Email(object):

    FOR_HOSTED_MODE_TEMPLATE_NAMES = ['offline-message', 'history-message', 'history-message-operator',
                                      'offline-response', 'operator-timeout', 'operator-rate', 'mail-notification']

    def __init__(self):
        self.__tml = Environment(loader=FileSystemLoader(os.path.join(os.path.dirname(__file__), 'templates/email')))
        self.__tml.globals['get_res'] = self.get_res

        self.account_name_to_last_operator_busy_mail_ts = {}

    def get_res(self, account, lang, key, params=None):
        params = params or {}
        return wm_resources.get_resource(account, lang, key, **params).replace('\\n', '\n')

    def send_offline_message(self, account, params, department=None):  # , pfrom, to, visitor
        if account.name in ['testrussianpostru', 'russianpostru', 'webimru106']:
            return
        to = account.get_setting('offline_email', department)
        params['email_type'] = 'offline'
        pfrom = '%s <%s>' % (params['visitor_name'], params['email'])
        self.__send_templated_mail(to, 'offline-message', params, account, lang=params['session_lang'], pfrom=pfrom)

    def send_chat_history_to_visitor(self, account, department, to, params, lang):  # , pfrom, to, visitor
        self.__send_mail_to_visitor(account, department, to, 'history-message', params, lang)

    def send_chat_history_to_operator(self, account, department, to, params, lang):  # , pfrom, to, operator
        self.__send_mail_to_operator(account, department, to, 'history-message-operator', params, lang)

    def __send_mail_to_visitor(self, account, department, to, template_name, params, lang):  # , pfrom, to, visitor
        params['mode'] = 'visitor'
        from_email_setting = account.get_setting('from_email', department)
        from_email = from_email_setting if from_email_setting is not None else account.get_setting('offline_email', department)
        from_email = re.split('[,;]+\s*', from_email)[0]
        if from_email.find('<') < 0:
            from_email = '%s <%s>' % (account.get_setting('company_name', department), from_email)
        self.__send_templated_mail(to, template_name, params, account, department, lang, from_email)

    def __send_mail_to_operator(self, account, department, to, template_name, params, lang):  # , pfrom, to, visitor
        self.__send_templated_mail(to, template_name, params, account, department, lang)

    def send_offline_response_to_visitor(self, account, department, to, params, lang):
        self.__send_mail_to_visitor(account, department, to, 'offline-response', params, lang)

    def send_operator_busy_notification(self, account, params):  # , pfrom, to, visitor
        if account.name in ['autoru', 'mixey']:
            return

        if time.time() - self.account_name_to_last_operator_busy_mail_ts.get(account.name, 0) < 60 * 60 * 4:
            return

        to = account.get_setting('superviser_email')
        self.__send_templated_mail(to, 'operator-timeout', params, account)

        self.account_name_to_last_operator_busy_mail_ts[account.name] = time.time()

    def send_operator_rating(self, account, params, department=None):
        to = account.get_setting('superviser_email', department)
        self.__send_templated_mail(to, 'operator-rate', params, account)

    def __get_low_balance_email(self, account, is_partner_client=None):
        if is_partner_client:
            to = wm_settings.settings['webim_support_email']
        else:
            to = account.get_setting('low_balance_email')
            if not to:
                to = self.get_first_admin_email(account.name)
            if not to:
                to = wm_settings.settings['server_monitoring_email']
        return to

    def send_payed_period_ending(self, account, params=None, is_partner_client=None):
        to = self.__get_low_balance_email(account, is_partner_client=is_partner_client)
        self.__send_templated_mail(to, 'payed-period-ending', params or {}, account)

    def send_nethouse_payed_period_ending(self, account):
        to = self.__get_low_balance_email(account)
        self.__send_templated_mail(to, 'partner-specific/nethouseru/payed-period-ending', {}, account)

    def send_testing_period_ending(self, account, is_partner_client=None):
        to = self.__get_low_balance_email(account, is_partner_client=is_partner_client)
        self.__send_templated_mail(to, 'testing-period-ending', {}, account)

    def send_payed_period_ending_to_jira(self, account):
        self.__send_templated_mail(wm_settings.get('blocked_notify_email'), 'payed-period-ending-to-jira', {}, account, lang='ru')

    def send_testing_period_ending_to_jira(self, account):
        self.__send_templated_mail(wm_settings.get('blocked_notify_email'), 'testing-period-ending-to-jira', {}, account, lang='ru')

    def send_service_reordered(self, account, params, is_partner_client=None):
        to = self.__get_low_balance_email(account, is_partner_client=is_partner_client)
        self.__send_templated_mail(to, 'service-reordered', params, account)

    def send_payment_guaranteed(self, params):
        self.__send_templated_mail(wm_settings.settings['jira_client_task_mail'], 'payment-guaranteed', params, lang='ru')

    def send_service_blocked_after_test(self, account):
        to = self.__get_low_balance_email(account)
        self.__send_templated_mail(to, 'service-blocked-after-test', {}, account)
        self.__send_templated_mail(wm_settings.get('blocked_notify_email'), 'service-blocked-after-test', {}, account, lang='ru')

    def send_service_blocked(self, account):
        to = self.__get_low_balance_email(account)
        self.__send_templated_mail(to, 'service-blocked', {}, account)
        self.__send_templated_mail(wm_settings.get('blocked_notify_email'), 'service-blocked', {}, account, lang='ru')

    def send_storing_errors_notification(self, account, params):  # , pfrom, to, visitor
        self.__send_templated_mail(wm_settings.settings['server_monitoring_email'], 'storing-errors', params, account, lang='ru', pfrom='root@webim.ru')

    def send_failed_before_objects_stored_notification(self, account, params):  # , pfrom, to, visitor
        self.__send_templated_mail(
            wm_settings.settings['server_monitoring_email'], 'failed-before-objects-stored', params, account, lang='ru', pfrom='root@webim.ru'
        )

    def send_needle_words_in_chat_notification(self, account, params):
        self.__send_templated_mail(wm_settings.settings['server_monitoring_email'], 'found-needle-words-in-chat', params, account, lang='ru')

    def send_too_many_chats_from_one_ip_notification(self, account, params):
        self.__send_templated_mail(wm_settings.settings['server_monitoring_email'], 'too-many-chats-from-one-ip', params, account, lang='ru')

    def send_short_message_notification(self, account, message, long_message=''):
        self.__send_templated_mail(
            wm_settings.settings['server_monitoring_email'], 'short-message',
            {'message': message, 'long_message': long_message, 'tornado_descriptor': str(wm_utils.get_current_tornado_descriptor())}, account, lang='ru'
        )

    def send_notification_email(self, online_operator, params, lang):
        to = online_operator.get_operator().email
        account = online_operator.account
        self.__send_templated_mail(to, 'mail-notification', params, account, lang=lang)

    def send_os_payment_canceled_mail(self, params):
        self.__send_templated_mail(wm_settings.settings['server_monitoring_email'], 'os-payment-canceled', params, lang='ru')

    def send_os_price_changed_mail(self, params):
        self.__send_templated_mail(wm_settings.settings['server_monitoring_email'], 'os-price-changed', params, lang='ru')

    def send_big_accounts_to_check_mail(self, params):
        self.__send_templated_mail(wm_settings.settings['jira_client_task_mail'], 'check-big-accounts', params, lang='ru')

    def __send_templated_mail(self, to, templatename, params=None, account=None, department=None, lang=None, pfrom=None):
        if wm_settings.settings.get('hostedmode') and templatename not in Email.FOR_HOSTED_MODE_TEMPLATE_NAMES:
            return

        pfrom = pfrom or (
            wm_resources.get_resource(account, account.get_setting('default_lang'), 'email.from') if account else wm_settings.settings['default_from']
        )

        target = lambda: self.__do_send_templated_mail(pfrom, to, templatename, params, account, department, lang)
        wm_timer.invoke_async(target, 'mail sending')

    def __create_template_names_list(self, account, template_name, suffix):
        filename = template_name + '-' + suffix + '.tpl'
        return [filename]

    def __do_send_templated_mail(self, pfrom, to, template_name, resource_params=None, account=None, department=None, lang=None):
        try:
            params = {}

            if ',' in to:
                to = [adr.strip() for adr in to.split(',')]
            elif ';' in to:
                to = [adr.strip() for adr in to.split(';')]

            if lang is None:
                if account is not None:
                    lang = account.get_setting('default_lang')
                else:
                    lang = 'ru'

            subject_template = self.__tml.select_template(self.__create_template_names_list(account, template_name, 'subject'))
            body_template = self.__tml.select_template(self.__create_template_names_list(account, template_name, 'body'))

            param_names = ['company_name', 'hosturl', 'company_phone', 'company_email', 'mail_signature']
            if account is not None:
                params['account_name'] = account.name

                for n in param_names:
                    if account.get_setting(n):
                        params[n] = account.get_setting(n)

            if department is not None and department.settings is not None:
                department_settings = department.settings
                for n in param_names:
                    if n in department_settings:
                        params[n] = department_settings[n]

            if 'company_email' in params:
                pfrom = params['company_email']

            for n in param_names:
                if n not in params:
                    params[n] = None

            params['company_url'] = params['hosturl']
            params['base_domain'] = wm_settings.settings['base_domain']

            params['resource_site_url'] = wm_resources.get_resource(account, lang, 'site.url')
            params['resource_site_title'] = wm_resources.get_resource(account, lang, 'site.title')
            params['resource_support_email'] = wm_resources.get_resource(account, lang, 'company.support.email')
            params['resource_service_name'] = wm_resources.get_resource(account, lang, 'service.name')

            resource_params.update(params)

            params['res_params'] = resource_params

            params['lang'] = lang
            params['account'] = account

            logging.warn('Sending mail from %s to: %s template_name: %s subject: %s' % (pfrom, to, template_name, subject_template.render(params)))
            logging.info(body_template.render(params))

            post_params = {'from': pfrom,
                           'to': to,
                           'subject': subject_template.render(params),
                           'body': body_template.render(params)}

            if not wm_settings.settings.get('devmode'):
                post_params['domain'] = wm_settings.get_partner_domain(account and account.partner_name)
            else:
                post_params['domain'] = wm_settings.settings['mailgun_dev_domain']

            post_params['no-reply'] = wm_settings.settings.get('hostedmode_smtp_from_addr') or wm_resources.get_resource(account, lang, 'email.from')

            if wm_settings.settings.get('hostedmode'):
                res = self.send_simple_message_in_hosted_mode(post_params)
            else:
                res = self.send_simple_message(post_params)
            logging.debug(res)
        except Exception:
            logging.error("Error while trying to send mail", exc_info=True)

    def get_first_admin_email(self, account_name):
        connection = db_utils.get_connection()
        row = connection.get("select email from operatoraccountview oav where oav.accountname=%s and roles like '%%admin%%' limit 0, 1", account_name)
        return row['email'] if row else None

    def send_simple_message(self, params):
        return requests.post(
            "https://api.mailgun.net/v2/%s/messages" % params['domain'],
            auth=("api", wm_settings.settings['mailgun_key']),
            data={"from": params['no-reply'],
                  "to": params['to'],
                  "subject": params['subject'],
                  "text": params['body'],
                  "o:tracking": False,
                  "o:native-send": "yes",
                  "h:Reply-To": params['from'],
                  "h:Return-Path": params['no-reply']})

    def send_simple_message_in_hosted_mode(self, params):

        config = {
            'host': wm_settings.settings.get('hostedmode_smtp_server') or None,
            'port': int(wm_settings.settings.get('hostedmode_smtp_port') or 0),
            'user': wm_settings.settings.get('hostedmode_smtp_username') or '',
            'pass': wm_settings.settings.get('hostedmode_smtp_password') or '',
            'auth': wm_settings.settings.get('hostedmode_smtp_auth_mode', '').upper() or None,
            'encr': wm_settings.settings.get('hostedmode_smtp_encryption') or None,
        }

        logging.warn('sending email using config: {}, no-reply: {}, to: {}'.format(
            config, params['no-reply'], params['to']
        ))

        if config['encr'] == 'ssl':
            smtp = SMTP_SSL(host=config['host'], port=config['port'])
            smtp.ehlo()
        elif config['encr'] == 'tls':
            smtp = SMTP(host=config['host'], port=config['port'])
            smtp.ehlo()
            smtp.starttls()
        else:
            smtp = SMTP(host=config['host'], port=config['port'])
            smtp.ehlo()

        # hostedmode_smtp_auth_mode может принимать значения { "plain", "login", "cram-md5" }
        # или быть пустым { "", None }
        if config['auth']:
            smtp.esmtp_features['auth'] = config['auth']

        if config['user'] and config['pass']:
            smtp.login(config['user'], config['pass'])

        msg = MIMEText(params['body'].encode('utf-8'), 'plain', _charset='utf-8')
        msg['From'] = params['no-reply']
        msg['Subject'] = params['subject']

        smtp.sendmail(
            params['no-reply'],
            params['to'] if type(params['to']) is list else [params['to']],
            msg.as_string()
        )
        smtp.quit()

        return 'mail sent'


mailer = Email()

if __name__ == "__main__":
    e = Email()
    import account
    e.send_offline_message(account.Account.get('webimru010'), {
        "visitor_name": "visitor_name",
        "email": "oleg@webim.ru",
        "message": "message",
        "info": "megainfo",
    })
    #    template = Template('Hello {{ name }}!')
    #    print template.render(name='John Doe')

    #    env = Environment(loader=PackageLoader('webim.teamplates', 'email'))
    #    env = Environment(loader=Environment('teamplates'))
    #
    # Open a plain text file for reading.  For this example, assume that
    # the text file contains only ASCII characters.
    #    fp = open(textfile, 'rb')
    # Create a text/plain message
    msg = MIMEText('some text here')
    #    fp.close()

    # me == the sender's email address
    # you == the recipient's email address
    msg['Subject'] = 'The contents'
    msg['From'] = 'oleg@webim.ru'
    msg['To'] = 'oleg@webim.ru'

    # Send the message via our own SMTP server, but don't include the
    # envelope header.
#    s = smtplib.SMTP('localhost')
#    s.sendmail(me, [you], msg.as_string())
#    s.quit()