# -*- coding: utf8 -*-
u"""Модуль содержит весь функционал, используемы в рамках системы для взаимодействия с различными CRM системами"""
__author__ = 'abezroukov'

from abc import ABCMeta, abstractmethod
from time import time, sleep
import logging
import json
import xml.sax.saxutils

import requests

import wm_settings


class CrmBase():
    u"""Базовый класс для взаимодействия с внешними CRM (получение/обновление контактных данных и т.д.)
    :type account: account.Account
    """
    __metaclass__ = ABCMeta

    account = None

    def __init__(self, account):
        """
        :type account account.Account
        """
        self.account = account

    def get_contact(self, visitor):
        u"""Возвращает контактные данные посетителя из CRM, если есть
        :type visitor Visitor
        :rtype: ContactFromCrm|None
        """
        contact = None
        if self._get_crm_contact_id(visitor):
            contact = self._get_contact_by_id(self._get_crm_contact_id(visitor))
            if not contact:
                self._set_crm_contact_id(visitor, None)

        if not contact:
            contact = self._search_contact(visitor)
            if contact:
                self._set_crm_contact_id(visitor, contact['crm_id'])

        return contact

    def save_contact(self, visitor):
        u"""Обновляет или добавляет контактные данные посетителя в CRM
        :type visitor Visitor
        """
        contact = self.get_contact(visitor)

        if contact:
            self._update_contact(contact, visitor)
        else:
            self._create_contact(visitor)

    @abstractmethod
    def add_chat(self, chat):
        u"""Сохраняет чат в CRM в том или ином виде
        :type chat Chat
        """
        pass

    @abstractmethod
    def is_enabled(self):
        """Проверяет, включена ли интеграция с CRM
        :rtype: bool
        """
        pass

    @abstractmethod
    def _get_crm_contact_id(self, visitor):
        u"""Возвращает id записи контакта CRM для посетителя, если есть
        :type visitor Visitor
        :rtype: string|None
        """
        pass

    @abstractmethod
    def _set_crm_contact_id(self, visitor, crm_id):
        u"""Устанавливает id записи контакта CRM для посетителя
        :type visitor Visitor
        :type crm_id string|None
        """
        pass

    @abstractmethod
    def _get_contact_by_id(self, contact_id):
        u"""Получает контактные данные из CRM по id
        :type contact_id string
        :rtype: ContactFromCrm|None
        """
        pass

    @abstractmethod
    def _search_contact(self, visitor):
        u"""Ищет контакт в CRM на основе известной информации (phone, email)
        :type visitor Visitor
        :rtype: ContactFromCrm|None
        """
        pass

    @abstractmethod
    def _update_contact(self, contact, visitor):
        u"""Обновляет существующий в CRM контакт данными посетителя
        :type contact ContactFromCrm
        :type visitor Visitor
        """
        pass

    @abstractmethod
    def _create_contact(self, visitor):
        u"""Создаёт новый контакт в CRM для посетителя
        :type visitor Visitor
        """
        pass

    @staticmethod
    def _format_chat_messages(chat):
        """Форматирует сообщения чата в одну строку, для последующего сохранения в CRM
        :type chat: Chat
        :rtype string
        """
        messages = [chat.format_message_for_history(message) for message in chat.messages]
        return "\n".join(messages)

    @staticmethod
    def _format_chat_utm_marks(chat):
        """Форматирует utm метки чата (если есть) в одну строку, для соохранения в CRM
        :type chat: Chat
        :rtype string
        """
        landing_info = chat.session.get_site_landing_info().to_dict(include_session=False)
        marks = [': '.join([mark_name, mark_value]) for mark_name, mark_value in landing_info.get('marks').items()]
        return "\n".join(marks).replace('=', '')

    def _process_error(self, message):
        u"""Обрабатывает ошибки
        :type message string
        """
        logging.error('Error in %s for %s. Message: %s' % (self.__class__.__name__, self.account.name, message))


class CrmBitrix(CrmBase):
    """Взаимодействие с CRM - Bitrix24. https://www.bitrix24.net/
    Bitrix24 использует oAuth2 (https://dev.1c-bitrix.ru/rest_help/oauth/index.php), так что необходимо знать
    время жизни токенов
    REFRESH_TOKEN_LIFETIME - время жизни в секундах токена обновления авторизационного
    AUTH_TOKEN_LIFETIME - время жизни в секундах авторизационного токена (используется для всех запросов)
    """
    REFRESH_TOKEN_LIFETIME = 3600 * 24 * 28
    AUTH_TOKEN_LIFETIME = 3500

    def is_enabled(self):
        setting = self.account.get_setting('bitrix24') or {}
        return bool(setting.get('bitrix24_portal', False)) and self._get_auth_settings()

    def add_chat(self, chat):
        setting = self.account.get_setting('bitrix24') or {}
        if not setting.get('bitrix24_save_chats_enabled', False):
            return

        if not self._get_crm_contact_id(chat.session.visitor):
            self._process_error('Cannot add chat: visitor bitrix24_contact_id is not set')
            return

        visitor_fields = chat.session.visitor.get_merged_fields()
        params = {
            'FIELDS[NAME]': visitor_fields.get('name', '-'),
            'FIELDS[TITLE]': 'Webim Chat',
            'FIELDS[SOURCE_ID]': 'WEB',
            'FIELDS[SOURCE_DESCRIPTION]': '[BR]'.join(self._format_chat_utm_marks(chat).splitlines()),
            'FIELDS[CONTACT_ID]': chat.session.visitor.integration.get('bitrix24_contact_id'),
            'FIELDS[COMMENTS]': '<br />'.join(self._format_chat_messages(chat).splitlines())
        }
        for key in ('email', 'phone'):
            if visitor_fields.get(key):
                params['FIELDS[' + key.upper() + '][0][VALUE]'] = visitor_fields.get(key)
                params['FIELDS[' + key.upper() + '][0][VALUE_TYPE]'] = 'WORK'
        self._do_request('crm.lead.add', params)

    def init_auth_settings(self, domain, code):
        error = False
        auth_response = requests.get(self._get_rest_api_url('/oauth/token/', domain), params={
            'grant_type': 'authorization_code',
            'client_id': wm_settings.settings.get('bitrix24_app_client_id'),
            'client_secret': wm_settings.settings.get('bitrix24_app_client_secret'),
            'redirect_uri': wm_settings.settings.get('bitrix24_app_redirect_uri'),
            'scope': wm_settings.settings.get('bitrix24_app_scope'),
            'code': code
        })

        auth_result = json.loads(auth_response.text)
        if 'error' not in auth_result:
            auth_result['ts'] = time()
            self._set_auth_settings(auth_result)
        else:
            error = auth_result['error']

        return error

    def _get_crm_contact_id(self, visitor):
        return visitor.integration.get('bitrix24_contact_id')

    def _set_crm_contact_id(self, visitor, contact_id):
        visitor.integration['bitrix24_contact_id'] = contact_id

    def _get_contact_by_id(self, contact_id):
        result = self._do_request('crm.contact.get', {'ID': contact_id})
        if result:
            return self._record_to_contact(result)

    def _search_contact(self, visitor):
        fields = visitor.get_merged_fields()
        contacts = None
        for filter_key in ('email', 'phone'):
            if fields.get(filter_key, None):
                params = {
                    'FILTER[' + filter_key.upper() + ']': fields.get(filter_key)
                }
                contacts = self._do_request('crm.contact.list', params)
                if contacts:
                    break
        if contacts:
            return self._get_contact_by_id(contacts[0]['ID'])

    @staticmethod
    def _record_to_contact(record):
        """
        :type record: dict
        :rtype: ContactFromCrm
        """
        custom_fields = {}
        for key in ['phone', 'email']:
            if record.get(key.upper()):
                for custom_field in record.get(key.upper()):
                    if custom_field['VALUE_TYPE'] == 'WORK':
                        custom_fields[key] = custom_field['VALUE']
                        break
        return ContactFromCrm(
            record['ID'],
            record['NAME'],
            phone=custom_fields.get('phone'),
            email=custom_fields.get('email'),
            raw=record
        )

    def _update_contact(self, contact, visitor):
        visitor_fields = visitor.get_merged_fields()
        params = {
            'FIELDS[NAME]': visitor_fields.get('name', '-')
        }
        for key in ('email', 'phone'):
            if visitor_fields.get(key):
                params['FIELDS[' + key.upper() + '][0][VALUE]'] = visitor_fields.get(key)
                params['FIELDS[' + key.upper() + '][0][VALUE_TYPE]'] = 'WORK'
                if key.upper() in contact.raw:
                    for key_field in contact.raw[key.upper()]:
                        if key_field['VALUE_TYPE'] == 'WORK':
                            params['FIELDS[' + key.upper() + '][0][ID]'] = key_field['ID']
                            break

        params['ID'] = contact['crm_id']
        self._do_request('crm.contact.update', params)

    def _create_contact(self, visitor):
        visitor_fields = visitor.get_merged_fields()
        params = {
            'FIELDS[NAME]': visitor_fields.get('name', '-')
        }
        for key in ('email', 'phone'):
            if visitor_fields.get(key):
                params['FIELDS[' + key.upper() + '][0][VALUE]'] = visitor_fields.get(key)
                params['FIELDS[' + key.upper() + '][0][VALUE_TYPE]'] = 'WORK'

        params['FIELDS[SOURCE_ID]'] = 'WEB'
        params['PARAMS[REGISTER_SONET_EVENT]'] = 'Y'
        contact_id = self._do_request('crm.contact.add', params)
        if contact_id:
            self._set_crm_contact_id(visitor, contact_id)

    def _do_request(self, action, params):
        settings = self._get_auth_settings()
        if settings['ts'] + self.AUTH_TOKEN_LIFETIME < time():
            if not self._refresh_auth_token():
                self._process_error('Cannot refresh token')
                return None
            else:
                settings = self._get_auth_settings()

        params = params.copy()
        params['auth'] = settings.get('access_token')
        resp = requests.get(self._get_rest_api_url('/rest/' + action), params=params)
        try:
            resp_json = resp.json()
        except ValueError:
            self._process_error('Request error: Invalid response. Status code %d' % resp.status_code)
        else:
            if 'error' in resp_json:
                self._process_error('Error in method %s. Error text: %s' % (action, resp_json['error_description']))
            else:
                return resp_json['result']

    def _refresh_auth_token(self):
        result = True
        settings = self._get_auth_settings()
        if settings['ts'] + self.REFRESH_TOKEN_LIFETIME > time():
            refresh_response = requests.get(self._get_rest_api_url('/oauth/token/'), params={
                'grant_type': 'refresh_token',
                'client_id': wm_settings.settings.get('bitrix24_app_client_id'),
                'client_secret': wm_settings.settings.get('bitrix24_app_client_secret'),
                'redirect_uri': wm_settings.settings.get('bitrix24_app_redirect_uri'),
                'scope': wm_settings.settings.get('bitrix24_app_scope'),
                'refresh_token': settings['refresh_token']
            })

            refresh_result = json.loads(refresh_response.text)
            if 'error' not in refresh_result:
                settings.update(refresh_result)
                settings['ts'] = time()
                self._set_auth_settings(settings)
            else:
                result = False
        else:
            result = False

        return result

    def _get_auth_settings(self):
        return self.account.key_value.get('bitrix24') or {}

    def _set_auth_settings(self, settings):
        self.account.key_value.set('bitrix24', settings)

    def _get_rest_api_url(self, path, domain=None):
        portal = domain or self._get_auth_settings()['domain']
        return 'https://' + portal + '/' + path.lstrip('/')


class CrmAmo(CrmBase):
    """Взаимодействие с CRM - AmoCRM. http://www.amocrm.ru/
    AmoCRM использует авторизацию по секретному ключу и кукам с некоторыми ограничениям
    AUTH_TOKEN_LIFETIME - время жизни в секундах сессии/кук после авторизации
    TIMEOUT_BETWEEN_REQUESTS - минимальная пауза в секундах между двумя запросами к серверу AmoCRM
    """
    AUTH_LIFETIME = 15 * 60
    TIMEOUT_BETWEEN_REQUESTS = 1

    _last_auth_time = None
    _auth_cookies = None
    _last_request_time = None

    _contact_custom_field_ids = None

    def is_enabled(self):
        return bool(self.account.get_setting('amocrm')
                    and self.account.get_setting('amocrm').get('amocrm_account')
                    and self.account.get_setting('amocrm').get('amocrm_api_key')
                    and self.account.get_setting('amocrm').get('amocrm_email'))

    def add_chat(self, chat):
        if not self._get_crm_contact_id(chat.session.visitor):
            self._process_error('Cannot add chat: visitor amocrm_contact_id is not set')
            return False

        chat_text = self._format_chat_messages(chat)
        if chat_text:
            self._add_note_to_contact(self._get_crm_contact_id(chat.session.visitor), chat_text)

        utm_marks = self._format_chat_utm_marks(chat)
        if utm_marks:
            self._add_note_to_contact(self._get_crm_contact_id(chat.session.visitor), utm_marks)

    def _get_crm_contact_id(self, visitor):
        return visitor.integration.get('amocrm_contact_id')

    def _set_crm_contact_id(self, visitor, crm_id):
        visitor.integration['amocrm_contact_id'] = crm_id

    def _get_contact_by_id(self, contact_id):
        resp = self._do_request('/contacts/list', {
            'id': contact_id
        })
        if resp and 'contacts' in resp and len(resp['contacts']):
            return self._record_to_contact(resp['contacts'][0])

    def _search_contact(self, visitor):
        fields = visitor.get_merged_fields()
        search_fields = [fields.get(key) for key in ['phone', 'email'] if fields.get(key)]
        for value in search_fields:
            resp = self._do_request('/contacts/list', {
                'query': value
            })
            if resp and 'contacts' in resp and len(resp['contacts']):
                return self._record_to_contact(resp['contacts'][0])

    def _record_to_contact(self, record):
        """
        :type record: dict
        :rtype : ContactFromCrm
        """
        contact_custom_fields = {}
        if 'custom_fields' in record:
            custom_fields_key_to_id = self._get_contact_custom_field_ids()
            custom_fields_id_to_key = {key: value for value, key in custom_fields_key_to_id.iteritems()}

            for custom_field in record.get('custom_fields', []):
                if custom_fields_id_to_key.get(custom_field['id']) in ['phone', 'email']:
                    values = custom_field.get('values', [])
                    if len(values):
                        contact_custom_fields[custom_fields_id_to_key.get(custom_field['id'])] = values[0]['value']

        return ContactFromCrm(
            record['id'],
            record['name'],
            phone=contact_custom_fields.get('phone'),
            email=contact_custom_fields.get('email'),
            raw=record
        )

    def _add_note_to_contact(self, contact_id, note_text):
        post_data = {
            'request': {
                'notes': {
                    'add': [{
                        'element_id': contact_id,
                        'element_type': 1,
                        'text': note_text,
                        'note_type': 4  # COMMON type
                    }]
                }
            }
        }
        self._do_request('/notes/set', post_data, 'POST')

    def _create_contact(self, visitor):
        visitor_fields = visitor.get_merged_fields()
        post_data = {
            'request': {
                'contacts': {
                    'add': [{
                        'name': visitor_fields['name'],
                        'custom_fields': self._get_visitor_custom_fields(visitor)
                    }]
                }
            }
        }
        resp = self._do_request('/contacts/set', post_data, 'POST')
        contact_id = resp.get('contacts', {}).get('add', [{'id': None}])[0].get('id') if resp else None
        if contact_id:
            self._set_crm_contact_id(visitor, contact_id)

    def _update_contact(self, contact, visitor):
        visitor_fields = visitor.get_merged_fields()
        post_data = {
            'request': {
                'contacts': {
                    'update': [{
                        'id': contact['crm_id'],
                        'last_modified': int(time()),
                        'name': visitor_fields['name'],
                        'custom_fields': self._get_visitor_custom_fields(visitor)
                    }]
                }
            }
        }
        self._do_request('/contacts/set', post_data, 'POST')

    def _get_visitor_custom_fields(self, visitor):
        visitor_fields = visitor.get_merged_fields()
        field_ids = self._get_contact_custom_field_ids()

        return [{'id': field_ids[key],
                'values': [{
                    'value': visitor_fields[key] if visitor_fields[key] else '-',
                    'enum': 'WORK'
                }]} for key in ['phone', 'email'] if key in visitor_fields]

    def _get_contact_custom_field_ids(self):
        if not self._contact_custom_field_ids:
            resp = self._do_request('/accounts/current')
            if resp:
                contact_custom_fields = resp.get('account', {}).get('custom_fields', {}).get('contacts', [])
                if len(contact_custom_fields):
                    self._contact_custom_field_ids = {}
                    for field in contact_custom_fields:
                        self._contact_custom_field_ids[field['code'].lower()] = field['id']

        return self._contact_custom_field_ids

    def _do_request(self, action, params=None, method='GET'):
        result = None
        if not self._last_auth_time or self._last_auth_time + self.AUTH_LIFETIME < time():
            if not self._do_auth():
                return result
            self._last_auth_time = time()

        if self._last_request_time and self._last_request_time + self.TIMEOUT_BETWEEN_REQUESTS >= time():
            sleep(self.TIMEOUT_BETWEEN_REQUESTS)

        if method == 'GET':
            resp = requests.get(self._get_base_url() + '/private/api/v2/json' + action,
                                params=params,
                                cookies=self._auth_cookies)
        else:
            resp = requests.post(self._get_base_url() + '/private/api/v2/json' + action,
                                 data=json.dumps(params),
                                 cookies=self._auth_cookies)
        self._last_request_time = time()

        if resp.status_code not in [requests.codes.ok, requests.codes.no_content]:
            try:
                resp_json = resp.json()
            except ValueError:
                self._process_error('Request error. No response. Status code %d' % resp.status_code)
            else:
                self._process_error('Request error. Action: %s. Code: %s. Description: %s.' % (
                    action,
                    resp_json['response']['error_code'],
                    resp_json['response']['error']))
        elif resp.status_code == requests.codes.ok:
            result = resp.json().get('response')

        return result

    def _do_auth(self):
        result = False
        auth_data = {
            'USER_LOGIN': self.account.get_setting('amocrm').get('amocrm_email'),
            'USER_HASH': self.account.get_setting('amocrm').get('amocrm_api_key')
        }
        resp = requests.post(self._get_base_url() + '/private/api/auth.php',
                             params={'type': 'json'},
                             data=auth_data)
        if resp.status_code != requests.codes.ok:
            try:
                resp_json = resp.json()
            except ValueError:
                self._process_error('Auth error. No response. Status code %d' % resp.status_code)
            else:
                self._process_error('Auth error. Code: %s. Description: %s.' % (resp_json['response']['error_code'], resp_json['response']['error']))
        else:
            result = True
            self._auth_cookies = resp.cookies
            self._contact_custom_field_ids = None

        return result

    def _get_base_url(self):
        return 'https://' + self.account.get_setting('amocrm').get('amocrm_account') + '.amocrm.ru'


class CrmZoho(CrmBase):
    """Взаимодействие с CRM - ZohoCRM. https://www.zoho.com/crm/ """
    def is_enabled(self):
        return bool(self.account.get_setting('zohocrm')
                    and self.account.get_setting('zohocrm').get('zohocrm_authtoken'))

    def add_chat(self, chat):
        if not self._get_crm_contact_id(chat.session.visitor):
            self._process_error('Cannot add chat: visitor zohocrm_contact_id is not set')
            return False

        chat_text = self._format_chat_messages(chat)
        if chat_text:
            self._add_note({
                'entityId': self._get_crm_contact_id(chat.session.visitor),
                'Note Title': chat.session.get_resource('crm.zoho.chat_note_title'),
                'Note Content': chat_text
            })

        utm_marks = self._format_chat_utm_marks(chat)
        if utm_marks:
            self._add_note({
                'entityId': self._get_crm_contact_id(chat.session.visitor),
                'Note Title': chat.session.get_resource('crm.zoho.chat_utm_marks_title'),
                'Note Content': utm_marks
            })

    def _add_note(self, note):
        return self._insert_record('Notes', note)

    def _get_crm_contact_id(self, visitor):
        return visitor.integration.get('zohocrm_contact_id')

    def _set_crm_contact_id(self, visitor, crm_id):
        visitor.integration['zohocrm_contact_id'] = crm_id

    def _get_contact_by_id(self, contact_id):
        record = self._get_record_by_id('Leads', contact_id)
        if record:
            return self._record_to_contact(record)

    def _search_contact(self, visitor):
        visitor_fields = visitor.get_merged_fields()
        records = self._search_records('Leads', {
            key.capitalize(): visitor_fields[key] for key in ['phone', 'email'] if visitor_fields.get(key)
        })
        if records:
            record = records[0] if isinstance(records, list) else records
            return self._record_to_contact(record)

    def _update_contact(self, contact, visitor):
        lead = self._visitor_to_lead_record(visitor)
        return self._update_record('Leads', contact['crm_id'], lead)

    def _create_contact(self, visitor):
        lead = self._visitor_to_lead_record(visitor)

        resp = self._insert_record('Leads', lead)
        if resp and 'result' in resp:
            for item in resp['result']['recorddetail']['FL']:
                if item['val'] == 'Id':
                    self._set_crm_contact_id(visitor, item['content'])
                    break

    @staticmethod
    def _record_to_contact(record):
        contact_id = None
        first_name = ''
        last_name = ''
        custom_fields = {}
        if record.get('FL'):
            for row in record.get('FL'):
                if row.get('val') == 'LEADID':
                    contact_id = row.get('content')
                elif row.get('val') == 'First Name':
                    first_name = row.get('content')
                elif row.get('val') == 'Last Name':
                    last_name = row.get('content')
                elif row.get('val') in ['Email', 'Phone']:
                    custom_fields[row.get('val').lower()] = row.get('content')

        name = first_name + ' ' + last_name if first_name else last_name

        return ContactFromCrm(
            contact_id,
            name,
            phone=custom_fields.get('phone'),
            email=custom_fields.get('email'),
            raw=record
        )

    def _visitor_to_lead_record(self, visitor):
        visitor_fields = visitor.get_merged_fields()
        name_parts = list(visitor_fields['name'].split(' ', 1))
        if len(name_parts) > 1:
            first_name = name_parts[0]
            last_name = name_parts[1]
        else:
            last_name = name_parts[0]
            first_name = ''
        params = {
            'First Name': first_name,
            'Last Name': last_name,
            'Email': visitor_fields.get('email', ''),
            'Phone': visitor_fields.get('phone', ''),
        }

        if self.account.get_setting('zohocrm').get('zohocrm_lead_source'):
            params['Lead Source'] = self.account.get_setting('zohocrm').get('zohocrm_lead_source')

        return params

    def _get_record_by_id(self, module, record_id):
        resp = self._do_request('getRecordById', module, {
            'id': record_id
        })
        if resp and 'result' in resp:
            return resp.get('result').get(module, {}).get('row')

    def _search_records(self, module, filters):
        search_criteria = '(' + 'OR'.join(['(' + key + ':' + filters[key] + ')' for key in filters]) + ')'
        resp = self._do_request('searchRecords', module, {
            'criteria': search_criteria
        })
        if resp and 'result' in resp:
            return resp.get('result').get(module, {}).get('row')

    def _insert_record(self, module, data):
        xml_data = self._record_to_xml(module, data)
        return self._do_request('insertRecords', module, {'xmlData': xml_data}, 'POST')

    def _update_record(self, module, record_id, data):
        xml_data = self._record_to_xml(module, data)
        return self._do_request('updateRecords', module, {
            'xmlData': xml_data,
            'id': record_id
        }, 'POST')

    @staticmethod
    def _record_to_xml(module, record):
        # На момент написания ZohoCRM поддерживает только xml данные при вставке-обновлении записей
        xml_data = ''.join(['<FL val=%s>%s</FL>' % (xml.sax.saxutils.quoteattr(key), xml.sax.saxutils.escape(value)) for key, value in record.iteritems()])
        xml_data = '<?xml version="1.0" encoding="UTF-8" ?>'\
                   + '<%s>' % module\
                   + '<row no="1">'\
                   + xml_data\
                   + '</row>' \
                   + '</%s>' % module

        return xml_data

    def _do_request(self, action, module, params, http_method='GET'):
        result = None
        request_params = {
            'authtoken': self.account.get_setting('zohocrm').get('zohocrm_authtoken'),
            'scope': 'crmapi',
            'newFormat': '1'
        }
        request_params.update(params)
        url = 'https://crm.zoho.com/crm/private/json/' + module + '/' + action
        if http_method == 'GET':
            resp = requests.get(url, params=request_params)
        else:
            resp = requests.post(url, data=request_params)

        try:
            resp_json = resp.json()
        except ValueError:
            self._process_error('Request error. No response. Status code %d' % resp.status_code)
        else:
            result = resp_json.get('response')
            if 'error' in result:
                self._process_error('ZohoCRM request error. Action: %s. Code: %s. Description: %s.' % (
                    action,
                    result['error']['code'],
                    result['error']['message']))
                result = {}

        return result


class ContactFromCrm:
    """Небольшая обёртка для гарантированного единообразия между различными форматами контактов CRM"""
    _attrs = None
    raw = None

    def __init__(self, crm_contact_id, name, email=None, phone=None, raw=None):
        self._attrs = {
            'crm_id': crm_contact_id,
            'name': name,
            'email': email,
            'phone': phone
        }
        self.raw = raw or {}

    def __getitem__(self, item):
        return self._attrs.get(item)

    def __contains__(self, item):
        return item in self._attrs