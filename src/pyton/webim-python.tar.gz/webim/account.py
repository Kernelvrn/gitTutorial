import logging
import threading
import json
import time
import datetime
import os.path
from distutils.version import LooseVersion

import tornado.web

import visitor_tracking
import wm_settings
import db_utils
import wm_operator
import wm_operator_chat
import wm_notification
import wm_utils
import wm_web
import wm_queue
import db_storage
import wm_timer
import chat
import wm_mail
import ddl_update
import wm_history
import authtoken
import auto_assign
from unisender import Unisender
from crm import CrmZoho, CrmAmo, CrmBitrix
import ordered_service
import wm_router
import robots as wm_robots
import wm_events


__author__ = 'mixey'


__account_name_to_key_value = wm_utils.DictExt(lambda name: CachedAccountKeyValue(account_name=name))


def get_value(account_name, key):
    return __account_name_to_key_value.get(account_name).get(key)


class BriefAccount(object):

    name_to_brief_account = wm_utils.DictExt(lambda name: BriefAccount(name))

    @classmethod
    def get(cls, name):
        return Account.get(name, create_if_not_found=False) or cls.name_to_brief_account.get(name)

    def __init__(self, name):
        self.name = name
        self.partner_name = self.__get_partner_name()
        self.timezone = self.__get_timezone()

        self._cached_operators = wm_operator.CachedOperators(self)
        self._cached_departments = wm_operator.CachedDepartments(self)

        self.authtokens = wm_utils.DictExt(lambda (auth_token): authtoken.CachedAuthTokens(auth_token))

        self.settings = AccountSettings(self.name)
        self.tariff_settings = CachedTariffSettings(self.name)
        self.location_to_cached_settings = wm_utils.DictExt(lambda location: CachedLocationSettings(self.name, location))

        #todo move to account
        self.visitor_session_numbers = [False] * 100000

    @property
    def operators(self):
        """
            :return: {operator_id: Operator}
        """
        return self._cached_operators.get_operators()

    @property
    def robots(self):
        """
            :return: {robot_type: Operator}
        """
        return self._cached_operators.get_robots()

    def get_operator(self, id):
        return self._cached_operators.get_operator(id)

    def get_operator_by_email(self, email):
        for operator in self.operators.values():
            if operator.email == email:
                return operator

        return None

    def get_operators(self):
        return self.operators

    def get_robots(self):
        return self.robots

    def get_robot(self, robot_type):
        return self._cached_operators.get_robot(robot_type)

    def get_ordered_robots(self):
        ordered_robots = self.robots.values()

        # robots with order === None to the end
        ordered_robots.sort(key=lambda r: (r.robot_logic.get_setting('order') is None, r.robot_logic.get_setting('order')))

        # TODO sort robots with "order is none" by operator id.
        return ordered_robots

    def get_robot_logic(self, operator_id):
        if self.get_setting('robots'):
            robots = self.get_setting('robots')
            robot_config = robots.get(operator_id)
            if robot_config:
                if robot_config.get('type') == 'hints':
                    return wm_robots.HintsRobotLogic(operator_id, robot_config)
                elif robot_config.get('type') == 'json':
                    return wm_robots.JsonRobotLogic(operator_id, robot_config, self.name)
                elif robot_config.get('type') == 'operator':
                    return wm_robots.OperatorRobotLogic(operator_id, robot_config)
                else:
                    return wm_robots.BasicRobotLogic(operator_id, robot_config)

        return None

    def get_department(self, department_key, avoid_empty_dep=False, include_deleted=False):
        if avoid_empty_dep and department_key == '':
            return None
        key_to_dep = self.get_key_to_department(include_deleted=include_deleted)
        return key_to_dep.get(department_key, None)

    def get_key_to_department(self, include_deleted=False):
        key_to_dep = self._cached_departments.get_data()
        if not include_deleted:
            return {key: dep for key, dep in key_to_dep.items() if not dep.deleted}
        else:
            return key_to_dep

    def get_setting(self, setting_name, department=None):
        if setting_name == 'admin_multilang':
            setting_name = 'multilang'

        if setting_name == 'track_every_visitor_department':
            return True

        if department is not None and department.settings is not None and setting_name in department.settings:
            return department.settings[setting_name]
        else:
            return self.settings.get(setting_name)

    def get_localized_setting(self, setting_name, lang, department_key=None):
        if not lang:
            return None

        if not self.get_setting('multilang'):
            lang = self.get_setting('default_lang')
        department = self.get_department(department_key, avoid_empty_dep=True)

        if department and department.settings:
            result = department.settings.get(setting_name, {}).get(lang)
            if result:
                return result
        return self.get_setting('%s_%s' % (setting_name, lang))

    def is_category_mandatory(self):
        if self.get_setting('category_mandatory') and\
           len(self.get_setting('categories')) and\
           self.get_tariff_setting('categories', False):
            return True
        else:
            return False

    def get_available_locale_ids(self):
        return ['ru', 'en', 'ua', 'he', 'tr'] if self.get_setting('multilang') else [self.get_setting('default_lang')]

    def get_tariff_setting(self, setting_name, default=None):
        return self.tariff_settings.get(setting_name, default)

    def get_location_settings(self, location):
        if location and location.startswith('demo-'):
            return CachedLocationSettings.read_location_settings(self.name, location)

        cached_settings = self.location_to_cached_settings.get(location or 'default')
        return cached_settings.get_data()

    def get_client_data_dir(self):
        return os.path.join(wm_settings.settings['accounts-base-local-dir'], self.name)

    def alloc_visitor_number(self):
        for i in range(len(self.visitor_session_numbers)):
            if not self.visitor_session_numbers[i]:
                self.visitor_session_numbers[i] = True
                return '%05d' % i
        return False

    def free_visitor_number(self, number):
        try:
            self.visitor_session_numbers[int(number)] = False
        except Exception:
            logging.error('Invalid visitor number: %s', number, exc_info=True)

    def __get_partner_name(self):
        connection = db_utils.get_connection()
        row = connection.get('select partner from account where accountname = %s', self.name)
        connection.close()
        return row['partner']

    def __get_timezone(self):
        connection = db_utils.get_connection()
        row = connection.get('select timezone from account where accountname = %s', self.name)
        connection.close()
        return row['timezone']

    def update_timezone(self):
        self.timezone = self.__get_timezone()

    def is_blocked(self):
        return self.tariff_settings.get_data()['blocked']
        #return not os.path.exists(old_path) and not os.path.exists(new_path)

    def check_if_mobile_app_supports_feature(self, platform, app_version, feature):
        setting = self.get_setting('mobile_apps_versions_features_support_dependencies')
        if app_version and setting and setting.get(feature) and setting.get(feature).get(platform):
            setting_version = setting.get(feature).get(platform)
            return LooseVersion(app_version) >= LooseVersion(setting_version)
        else:
            return False

    def get_android_api_key(self, service):
        setting = 'gcm_api_key' if service == 'gcm' else 'fcm_api_key'
        return self.get_setting(setting) or wm_settings.settings.get(setting)

class Account(BriefAccount):

    name_to_account = {}

    lock = threading.Lock()

    @classmethod
    def get(cls, name, create_if_not_found=True, request=None):

        with cls.lock:
            if name not in cls.name_to_account and create_if_not_found:
                cls.name_to_account[name] = Account(name)
                logging.warn('Request involved account @' + name + ' creation: ' + str(request))

        return cls.name_to_account.get(name)

    def __init__(self, name):
        super(Account, self).__init__(name)
        self.visit_tracker = visitor_tracking.VisitTracker(self)
        self.oo_manager = wm_operator.OnlineOperatorsManager(self)
        self.queue_manager = wm_queue.VisitorQueueManager(self)
        self.auto_assign_controller = auto_assign.AutoAssignController(self, offline=False)
        self.auto_assign_controller_for_offline = auto_assign.AutoAssignController(self, offline=True)
        self.integration_manager = IntegrationManager(self)
        self.push_manager = wm_notification.PushManager(self)
        self.background_storager = db_storage.BackgroundStorager(self)
        self.background_storager_1 = db_storage.BackgroundStorager(self, num=1)
        self.key_value = KeyValueStorage(self)

        self.cached_ban_records = CachedBanRecords(self)
        self.cached_visit_session_sections = visitor_tracking.CachedVisitSessionSections(self)

        self.cached_belonging_to_current_tornado_instance = CachedBelongingToCurrentTornadoInstance(self)
        self.ignore_not_belongs_to_tornado_instance = False

        self.operator_chat = wm_operator_chat.OperatorChat(self)

        self.history_manager = wm_history.HistoryManager(self)

        self.router = None

        self.initialization_ts = None

        self.realtime_statistics = wm_operator.CachedRealtimeStatistics(self)
        self.prev_periods_statistics = wm_operator.CachedPrevPeriodsStatistics(self)

        from channels import wm_telegram_bot, wm_whatsapp, wm_vk, wm_xmpp, wm_facebook, wm_custom, wm_viber, wm_ok

        self.xmpp_bot_manager = wm_xmpp.XMPPBotManager(self)

        self.fb_api = wm_facebook.FacebookAPI(self)
        self.telegram_api = wm_telegram_bot.TelegramBotAPI(self)
        self.vk_api = wm_vk.VkontakteAPI(self)
        self.blinger_whatsapp_api = wm_whatsapp.BlingerWhatsappAPI(self)
        self.custom_channel_api = wm_custom.CustomChannelAPI(self)
        self.viber_api = wm_viber.ViberAPI(self)
        self.ok_api = wm_ok.OdnoklassnikiAPI(self)

        self.event_dispatcher = wm_events.AccountEventDispatcher(self)

        wm_timer.invoke_async(self.__async_init, 'account async init')

    def belongs_to_current_tornado_instance(self):
        return (wm_settings.settings.get('hostedmode') or
                self.cached_belonging_to_current_tornado_instance.get_data() or
                self.ignore_not_belongs_to_tornado_instance)

    def __async_init(self):
        if self.belongs_to_current_tornado_instance():
            self.__do_async_init()
        else:
            logging.warn('Async init @' + self.name + ' rejected because account doesn\'t belong to current tornado instance')
            wm_timer.add_timer(300, self.__async_init, 'account async init')

    def __do_async_init(self, start_step=1, try_number=1):
        logging.warn('Async init @' + self.name + ' with start step = ' + str(start_step))
        try:
            for step in range(start_step, 8):
                self.do_async_init_step(step)
            self.initialization_ts = time.time()
            logging.warn('Async init @' + self.name + ' finished')
        except Exception:
            logging.error('Failed to do async init @%s step %d. Try number: %d ', self.name, step, try_number, exc_info=True)
            wm_timer.add_timer(5, lambda: self.__do_async_init(step, try_number=try_number + 1), 'account async init')

    def do_async_init_step(self, step):
        logging.warn('Async init @' + self.name + ' step ' + str(step))
        if step == 1:
            ddl_update.update(self.name)
        elif step == 2:
            self.key_value.load()
        elif step == 3:
            self.router = wm_router.get_router(self)
            self.update_event_consumers()
        elif step == 4:
            if self.get_setting('load_previous_visitor_ids_on_account_init'):
                self.visit_tracker.load_previous_visitor_ids()
            else:
                logging.warn('@' + self.name + ' load_previous_visitor_ids disabled')
        elif step == 5:
            chat.Chat.load_not_closed_chats(self, False)
            self.visit_tracker.ready = True
        elif step == 6:
            chat.Chat.load_not_closed_chats(self, True)
        elif step == 7:
            self.operator_chat.load_init_messages()
            wm_timer.invoke_periodically(60 * 60, lambda: self.operator_chat.clean_history(), 'clean_operators_chat_history')
            wm_timer.invoke_async(lambda: self.update_bots(), timer_name='account init update_bots')
            wm_timer.invoke_async(lambda: self.xmpp_bot_manager.update_bots(), timer_name='update_xmpp_bots')
        else:
            logging.error("Unknown step number!")

    def get_auto_assign_controller(self, offline):
        return self.auto_assign_controller_for_offline if offline else self.auto_assign_controller

    def update_bots(self):
        if not self.get_setting('multibot_formatting'):
            wm_utils.request_internal(self.name, '/service/update_bots.php')

    def is_banned_visitor(self, ip=None, push_token=None, user_and_channel_id=None):
        ban_records = self.cached_ban_records.get_data()
        banned = False

        if ip:
            banned = ip in ban_records['by_ips'] and ban_records['by_ips'][ip] > time.time()

        if push_token and not banned:
            banned = push_token in ban_records['by_push_tokens'] and ban_records['by_push_tokens'][push_token] > time.time()

        if user_and_channel_id and not banned:
            user_and_channel_ban_records = ban_records['by_user_and_channel_id']
            banned = (user_and_channel_id in user_and_channel_ban_records and
                      user_and_channel_ban_records[user_and_channel_id] > time.time())

        return banned

    def reset_cached_ban_records(self):
        self.cached_ban_records.reset()

    def check_online_operators_limit_reached(self):
        online_operators_limit = self.get_tariff_setting('online_operators_limit')
        return online_operators_limit and len(self.oo_manager.get_working_online_operators()) >= online_operators_limit

    def check_if_now_in_allowed_online_time(self):
        selected_periods = self.get_setting('allowed_online_time')
        if selected_periods:
            return selected_periods.check_if_current_time_in_time_periods()
        else:
            return True

    def update_router(self):
        self.router = wm_router.get_router(self)

    def update_event_consumers(self):
        consumers = []
        for consumer_name in self.get_setting('event_consumers'):
            if consumer_name == 'tcs_trace':
                consumers.append(wm_events.TCSChatTraceLoggingEventConsumer(self, 'tcs_trace', 5, {'file': '/var/log/pro/tracer.log'}))

        self.event_dispatcher.update_consumers_list(consumers)

    def ensure_online_only_if_should_be_online(self):
        if not self.check_if_now_in_allowed_online_time():
            self.oo_manager.set_status_to_all_operators(wm_operator.OperatorStatus.INVISIBLE, details='not-in-allowed-online-time')

        if self.is_blocked():
            self.oo_manager.disconnect_all_operators(details='account-blocked')
            logging.warn('All operators disconnected since account %s is blocked' % self.name)

        for oo in self.oo_manager.get_working_online_operators():
            if not oo.get_operator():
                oo.disconnect(details='operator-deleted')
                logging.warn('Operator %d disconnected because it was deleted. account: %s' % (oo.operator_id, self.name))

    @classmethod
    def get_all(cls):
        return cls.name_to_account.values()

    @classmethod
    def check_if_operators_needs_to_be_disconnected_for_all(cls):
        for a in cls.get_all():
            try:
                if a.oo_manager.get_online_state('', '') in ['online', 'busy_online']:
                    a.ensure_online_only_if_should_be_online()

                a.check_operator_work_hours()

            except Exception:
                logging.error('Failed ensure_online_only_if_should_be_online @' + a.name, exc_info=True)

    def check_operator_work_hours(self):
        operators = [op for op in self.get_operators().values() if op.work_hours]
        for op in operators:
            self.oo_manager.get(op.id).update_status_by_work_hours_if_needed()


wm_timer.invoke_periodically(60, Account.check_if_operators_needs_to_be_disconnected_for_all, 'check_if_operators_needs_to_be_disconnected_for_all')


class IntegrationManager():
    def __init__(self, account):
        self.account = account
        self.zoho_crm = CrmZoho(account)
        self.amo_crm = CrmAmo(account)
        self.unisender = Unisender(account)
        self.bitrix_crm = CrmBitrix(account)

    def on_chat_finished(self, chat):
        for crm in [self.amo_crm, self.bitrix_crm, self.zoho_crm]:
            if crm.is_enabled():
                crm.save_contact(chat.session.visitor)
                crm.add_chat(chat)

    def on_visitor_update_fields(self, chat):
        for crm in [self.amo_crm, self.bitrix_crm, self.zoho_crm]:
            if crm.is_enabled():
                crm.save_contact(chat.session.visitor)

        self.unisender.add_contact(chat)


class CachedTariffSettings(wm_utils.CachedDBData):

    def __init__(self, account_name):
        wm_utils.CachedDBData.__init__(self, account_name=None, reload_immediately_after_reset=True)
        self.account_name = account_name

    def load_data(self, connection):
        connection = db_utils.get_connection()
        current_os = ordered_service.load_current_ordered_service(self.account_name)

        account_row = connection.get('SELECT tariff, profreedate, isblocked FROM account WHERE accountname=%s', self.account_name)
        if not account_row:
            account_is_blocked = True
        elif account_row['tariff'] == 'free' and not wm_settings.is_hosted_mode():
            account_is_blocked = False
        elif account_row['tariff'] in ('test', 'start', 'bus', 'corp'):
            if current_os:
                account_is_blocked = False
            elif not wm_settings.is_hosted_mode() and account_row['tariff'] == 'test' and account_row['profreedate'] >= datetime.date.today():
                account_is_blocked = False
            else:
                account_is_blocked = True
        else:
            account_is_blocked = wm_settings.is_hosted_mode() or bool(account_row['isblocked'])

        tariff_key = current_os['tariffkey'] if current_os else account_row['tariff']
        tariff = ordered_service.Tariff.get(self.account_name, tariff_key)
        result = tariff.settings.copy()
        if current_os and current_os['settings']:
            result = wm_utils.merge_dict(result, json.loads(current_os['settings']))

        return {
            'settings': result,
            'blocked': account_is_blocked,
            'tariff': tariff_key
        }

    def get(self, key, default=None):
        return self.get_data()['settings'].get(key, default)


class CachedLocationSettings(wm_utils.CachedData):

    def __init__(self, account_name, location):
        wm_utils.CachedData.__init__(self, 15)
        self.account_name = account_name
        self.location = location

    def obtain_data(self):
        return CachedLocationSettings.read_location_settings(self.account_name, self.location)

    @staticmethod
    def get_settings_file_content(account_name, location, filename):
        path = os.path.join(wm_settings.settings['client-data-dir'], account_name, 'locations', location if location else 'default', filename)
        if not os.path.exists(path):
            return None
        f = open(path, 'r')
        try:
            return f.read()
        finally:
            f.close()

    @staticmethod
    def get_old_location(account_name, location):
        js_content = CachedLocationSettings.get_settings_file_content(account_name, location, 'settings.js')
        txt_content = CachedLocationSettings.get_settings_file_content(account_name, location, 'settings.txt')
        js_content = js_content[js_content.index('{'): js_content.rindex('}') + 1] if js_content else '{}'
        txt_content = txt_content if txt_content else '{}'
        settings = json.loads(js_content)
        if settings:
            txt_json = json.loads(txt_content)
            if txt_json:
                if 'button' not in settings or not isinstance(settings['button'], dict):
                    settings['button'] = {}
                if 'button' in txt_json:
                    settings['button']['name'] = txt_json['button']
                if 'offline_enabled' in txt_json:
                    settings['button']['offlineEnabled'] = txt_json.get('offline_enabled', 'Y')
                else:
                    settings['button']['offlineEnabled'] = 'Y' if txt_json.get('hide_button', 'N') != 'Y' else 'N'
        return settings

    @staticmethod
    def get_location_settings(account_name, location):
        settings = {}
        try:
            json_content = CachedLocationSettings.get_settings_file_content(account_name, location, 'settings.json')
            if json_content:
                settings = json.loads(json_content)
            else:
                settings = CachedLocationSettings.get_old_location(account_name, location)
        except Exception:
            pass

        return settings

    @staticmethod
    def read_location_settings(account_name, location):
        result = {}

        all_settings = [
            CachedLocationSettings.get_system_default_location_settings(),
            CachedLocationSettings.get_location_settings(account_name, 'default'),
            CachedLocationSettings.get_location_settings(account_name, location)
        ]

        for s in all_settings:
            if s:
                CachedLocationSettings.location_merge(result, s)

        return result

    @staticmethod
    def location_merge(dict1, dict2):  # TODO rewrite it
        for key in dict2:
            if type(dict1) != dict:
                continue
            if key in dict1:
                if type(dict2[key]) == dict:
                    CachedLocationSettings.location_merge(dict1[key], dict2[key])
                else:
                    dict1[key] = dict2[key]
            else:
                dict1[key] = dict2[key]

    @staticmethod
    def get_system_default_location_settings():
        system_default_location_path = os.path.join(wm_settings.public_html_dir, 'webim/classes/location-default.json')
        with open(system_default_location_path, 'r') as f:
            system_default_location_settings = json.loads(f.read())
            f.close()

        return system_default_location_settings


class CachedBanRecords(wm_utils.CachedDBData):
    # contains address -> till_ts dict

    def __init__(self, account):
        wm_utils.CachedDBData.__init__(self, account.name, autoupdate=True, reload_immediately_after_reset=True)
        self.account = account

    def __update_dict(self, key, sub_dict, main_dict, till_ts):
        if key not in main_dict[sub_dict] or main_dict[sub_dict][key] < till_ts:
            main_dict[sub_dict][key] = till_ts

    def load_data(self, connection):
        result = {'by_ips': {},
                  'by_push_tokens': {},
                  'by_user_and_channel_id': {}}

        self.load_bans(connection, 'chatban', result)

        c = db_utils.get_connection()
        self.load_bans(c, 'ban', result)
        c.close()

        return result

    def on_data_renewed(self, cached, obtained):
        if cached != obtained:
            wm_timer.invoke_async(self.account.visit_tracker.update_ban_statuses_for_visitors, 'update_ban_statuses_for_visitors')

    def load_bans(self, connection, table_name, result):
        rows = connection.query('SELECT address, till, json from ' + table_name)

        for row in rows:
            ban_json = json.loads(row['json']) if row['json'] else {}
            till = row['till']
            till_ts = wm_utils.get_ts(till, 0)

            ban_by_ip = True

            if ban_json:
                if ban_json.get('push_token'):
                    self.__update_dict(ban_json['push_token'], 'by_push_tokens', result, till_ts)
                    ban_by_ip = False

                if ban_json.get('channel_user_id') and ban_json.get('channel_id'):
                    user_and_channel_id = (ban_json['channel_user_id'], ban_json['channel_id'])
                    self.__update_dict(user_and_channel_id, 'by_user_and_channel_id', result, till_ts)
                    ban_by_ip = False

            if ban_by_ip and row['address']:
                self.__update_dict(row['address'], 'by_ips', result, till_ts)


class BanRecord(wm_utils.Jsonable):
    def __init__(self, address, till_ts, comment, push_token=None, stored_to_db_callback=None, chat_id=None,
                 operator_name=None, channel_user_id=None, channel_id=None):
        self.address = address
        self.till_ts = till_ts
        self.comment = comment
        self.stored_to_db_callback = stored_to_db_callback
        self.push_token = push_token
        self.chat_id = chat_id
        self.operator_name = operator_name
        self.channel_user_id = channel_user_id
        self.channel_id = channel_id

    def to_dict(self, context=None):
        context = context or {}
        mode = context.get('mode')

        result = {}

        if mode == 'db':
            if self.push_token:
                result['push_token'] = self.push_token

            if self.channel_user_id:
                result['channel_user_id'] = self.channel_user_id

            if self.channel_id:
                result['channel_id'] = self.channel_id

            result['chat_id'] = self.chat_id
            result['operator_name'] = self.operator_name

        return result


class ResetCacheRequestHandler(wm_web.AdminRequestHandler):

    @tornado.web.asynchronous
    def get(self, *args, **kwargs):
        settings_type = self.get_verified_argument('type')
        wm_timer.invoke_async(lambda: self.__get(settings_type), 'ResetCacheRequestHandler %s' % settings_type)

    def __get(self, settings_type):
        account = self.get_account()
        result = {'result': 'ok'}

        if settings_type == 'all':
            self.reset_all_settings(account)
        else:
            if settings_type == 'location-settings':
                location = self.get_verified_argument('location', 'default', pattern='^(\w|-|\.)+$')
                account.location_to_cached_settings.get(location).reset()
            elif settings_type == 'account-settings':
                account.settings.reset()
                account.update_timezone()
            elif settings_type == 'tariff-settings':
                account.tariff_settings.reset()
            elif settings_type == 'ban-records':
                account.cached_ban_records.reset()
            elif settings_type == 'operators':
                account._cached_operators.reset()
            elif settings_type == 'operator':
                account._cached_operators.reset_one(self.get_int_argument('id'))
            elif settings_type == 'departments':
                account._cached_departments.reset()
            elif settings_type == 'session-sections':
                account.cached_visit_session_sections.reset()
            else:
                result = {'error': 'unknown-type'}

        wm_utils.invoke_in_ioloop(lambda: self.finish(result), 'ResetCacheRequestHandler %s' % settings_type)

    def reset_all_settings(self, account):
        account.settings.reset()
        account.tariff_settings.reset()
        for loc in account.location_to_cached_settings.values():
            loc.reset()
        account.cached_ban_records.reset()
        account._cached_operators.reset()
        account._cached_departments.reset()


class AccountsStatMonitorRequestHandler(wm_web.AdminRequestHandler):

    @tornado.web.asynchronous
    def get(self):
        wm_timer.invoke_async(self.__get, timer_name='AccountsStatMonitorRequestHandler')

    def __get(self):
        total = {'name': 'TOTAL',
                 'sessions_cnt': 0,
                 'offline_sessions_cnt': 0,
                 'visible_sessions_cnt': 0,
                 'alive_sessions_cnt': 0,
                 'pages_cnt': 0,
                 'alive_pages_cnt': 0,
                 'online_operators_cnt': 0,
                 'working_operators_cnt': 0,
                 'chats_cnt': 0,
                 'offline_chats_cnt': 0,
                 'in_queue_cnt': 0,
                 'failed_to_store_objects_cnt': 0,
                 'collected_to_store_objects_cnt': 0,
                 'being_stored_now_objects_cnt': 0,
                 'being_stored_now_processed_objects_cnt': 0,
                 'failed_to_store_objects_cnt_1': 0,
                 'collected_to_store_objects_cnt_1': 0,
                 'being_stored_now_objects_cnt_1': 0,
                 'being_stored_now_processed_objects_cnt_1': 0,
                 'not_belongs_to_tornado_instance': 0}

        result = [total]

        for a in Account.get_all():
            # todo use get_sessions_by_filter_name instead of get_all_sessions
            online_sessions = list(a.visit_tracker.get_all_sessions(kind=visitor_tracking.VisitSession.Kind.ONLINE))
            offline_sessions = list(a.visit_tracker.get_all_sessions(kind=visitor_tracking.VisitSession.Kind.OFFLINE_CHAT))
            stat = {
                'name': a.name,
                'domain': a.name + '.' + wm_settings.get_partner_domain(a.partner_name),
                'sessions_cnt': len(online_sessions),
                'offline_sessions_cnt': len(offline_sessions),
                'visible_sessions_cnt': 0,
                'alive_sessions_cnt': 0,
                'pages_cnt': 0,
                'alive_pages_cnt': 0,
                'online_operators_cnt': len(a.oo_manager.get_alive_online_operators()),
                'working_operators_cnt': len(a.oo_manager.get_working_online_operators()),
                'chats_cnt': 0,
                'offline_chats_cnt': 0,
                'in_queue_cnt': 0,
                'failed_to_store_objects_cnt': a.background_storager.get_collected_count('failed_to_store'),
                'collected_to_store_objects_cnt': a.background_storager.get_collected_count('collected_to_store'),
                'being_stored_now_objects_cnt': a.background_storager.get_collected_count('being_stored_now'),
                'being_stored_now_processed_objects_cnt': a.background_storager.get_being_stored_now_processed_count() or 0,
                'failed_to_store_objects_cnt_1': a.background_storager_1.get_collected_count('failed_to_store'),
                'collected_to_store_objects_cnt_1': a.background_storager_1.get_collected_count('collected_to_store'),
                'being_stored_now_objects_cnt_1': a.background_storager_1.get_collected_count('being_stored_now'),
                'being_stored_now_processed_objects_cnt_1': a.background_storager_1.get_being_stored_now_processed_count() or 0,
                'not_belongs_to_tornado_instance': not a.cached_belonging_to_current_tornado_instance.get_data(force_from_cache=True),
                'ignore_not_belongs_to_tornado_instance': a.ignore_not_belongs_to_tornado_instance,
            }

            for s in online_sessions:
                if s.is_alive():
                    stat['alive_sessions_cnt'] += 1
                    if not s.hidden:
                        stat['visible_sessions_cnt'] += 1
                if s.chat:
                    stat['chats_cnt'] += 1
                    if a.queue_manager.get_chat_queue_id(s.chat):
                        stat['in_queue_cnt'] += 1

                stat['pages_cnt'] += len(s.visited_pages)
                stat['alive_pages_cnt'] += len(s.get_alive_pages())
            for s in offline_sessions:
                if s.chat:
                    stat['offline_chats_cnt'] += 1

            result.append(stat)
            for k, v in total.items():
                if k != 'name':
                    total[k] = v + stat[k]

        wm_utils.invoke_in_ioloop(lambda: self.finish(json.dumps(result)), name='AccountsStatMonitorRequestHandler')


class IgnoreNotBelongsRequestHandler(wm_web.AdminRequestHandler):
    def get(self, *args, **kwargs):
        account_name = self.get_verified_argument('account-name')
        value = self.get_bool_argument('value', False)
        Account.get(account_name).ignore_not_belongs_to_tornado_instance = value
        self.write(json.dumps({'result': 'ok'}))


class CachedAccountSettings(wm_utils.CachedDBData):
    def __init__(self, account_name):
        wm_utils.CachedDBData.__init__(self, account_name)

        self.account_name = account_name

        desc_file_name = os.path.join(wm_settings.public_html_dir, 'webim/classes/account-config-descriptor.json')
        desc_file = open(desc_file_name, 'r')
        self.descriptor = json.loads(desc_file.read())

        account_specific_desc_file_name = os.path.join(wm_settings.public_html_dir,
                                                       'webim/account-specific/%s/configs/account-config-descriptor.json' % account_name)

        if os.path.isfile(account_specific_desc_file_name):
            try:
                account_specific_descriptor = json.loads(open(account_specific_desc_file_name, 'r').read())
                if account_specific_descriptor:
                    self.descriptor = wm_utils.merge_dict(self.descriptor, account_specific_descriptor)
                logging.warn('CachedAccountSettings %s: account-specific descriptor loaded' % account_name)
            except Exception:
                logging.warn('CachedAccountSettings %s: failed to load account-specific descriptor' % account_name, exc_info=True)

    def get(self, key):
        value = self.get_data().get(key)
        if key in self.descriptor:
            if not self.can_use(key):
                value = self.descriptor[key]['tariff_option_dependancy']['value_without_option']

            if value is None:
                value = self.descriptor[key]['default']
        return value

    def can_use(self, key):
        if 'tariff_option_dependancy' in self.descriptor[key]:
            tariff_settings = Account.get(self.account_name, False).tariff_settings
            return tariff_settings.get(self.descriptor[key]['tariff_option_dependancy']['required_option'])
        else:
            return True

    def load_data(self, connection):
        result = {}
        rows = connection.query('select configkey as \'key\', configvalue as value from chatconfig')
        for r in rows:
            key = r['key']
            value = r['value']

            try:
                if key in self.descriptor:
                    data_type = self.descriptor[key]['type'].lower()
                    if value is None:
                        value = self.descriptor[key]['default']
                    elif data_type == 'boolean':
                        value = True if value.lower() == 'true' else False
                    elif data_type == 'integer':
                        value = int(value) if value else self.descriptor[key]['default']
                    elif data_type == 'json':
                        value = json.loads(value) if value else self.descriptor[key]['default']
                    elif data_type == 'comma-separated':
                        value = [v.strip() for v in value.split(',')] if value.strip() else []

                if key == 'allowed_online_time':
                    value = wm_utils.SelectedPeriods(value) if value else None
                elif key == 'high_priority_urls':
                    value = [line.strip() for line in value.split('\n')] if value else None
                elif key == 'robots':
                    value = {int(id): config for id, config in value.items()} if value else None
                elif key == 'visitor_messages_not_requiring_response':
                    value = [msg.lower().strip() for msg in value if msg.strip()] if value else []

                result[key] = value
            except Exception:
                result[key] = None
                logging.error('Failed to load @' + self.account_name + ' config value for key: ' + key + ' (raw value: ' + str(r['value']) + ')', exc_info=True)
                raise

        return result

    def on_data_renewed(self, cached, obtained):
        a = Account.get(self.account_name, False)

        if cached and a:

            if cached.get('custom_router_schema_url') != obtained.get('custom_router_schema_url'):
                wm_timer.invoke_async(lambda: a.update_router())

            if self.__is_one_of_settings_changed(cached, obtained, ['offline_queue_limit', 'online_queue_limit']):
                wm_timer.invoke_async(a.queue_manager.on_limit_setting_changed, 'on_limit_setting_changed')

            if self.__is_one_of_settings_changed(cached, obtained, ['hide_others', 'hide_anothers_chats', 'hide_common_queue']):
                wm_timer.invoke_async(a.oo_manager.update_all_sessions_related, 'update_all_sessions_related')

            if cached.get('robots') != obtained.get('robots'):
                wm_timer.invoke_async(lambda: a._cached_operators.reset())

            if cached.get('event_consumers') != obtained.get('event_consumers'):
                wm_timer.invoke_async(lambda: a.update_event_consumers())

            wm_timer.invoke_async(lambda: a.xmpp_bot_manager.update_bots(), timer_name='channels_data_renewed update_xmpp_bots')

    def __is_one_of_settings_changed(self, cached, obtained, setting_names):
        for name in setting_names:
            if cached.get(name) != obtained.get(name):
                return True

        return False

    def get_proxy_settings(self, proxy_name):
        value = self.get('proxies') or {}

        try:
            settings = value.get(proxy_name)
            if not settings:
                return None

            proxy_str = settings.get('user') + ':' + settings.get('password') + '@' if settings.get('user') and settings.get('password') else ''
            proxy_str += settings.get('host') + ':' + settings.get('port', '3128')

            return {
                "http": 'http://' + proxy_str,
                "https": 'https://' + proxy_str
            }

        except Exception:
            logging.error('Failed to get proxy settings', exc_info=True)

        return None


class AccountSettings(CachedAccountSettings):

    def __init__(self, account_name):
        CachedAccountSettings.__init__(self, account_name)
        self.account_name = account_name

    def __set(self, key, value, reset=True, update_cache_value=None):
        connection = db_utils.get_connection(self.account_name)
        sql = "INSERT INTO chatconfig (configkey, configvalue) VALUES (%s, %s) ON DUPLICATE KEY UPDATE configvalue=%s"
        connection.execute(sql, key, value, value)

        if reset:
            self.reset()

        if update_cache_value:
            self.update_cached(key, update_cache_value)

    def set(self, key, value, async=True, reset=True, update_cache_value=None):
        if async:
            wm_timer.invoke_async(lambda: self.__set(key, value, reset=reset, update_cache_value=update_cache_value), timer_name='account_settings async set')
        else:
            self.__set(key, value, reset=reset, update_cache_value=update_cache_value)

    def update_cached(self, key, value):
        with self._update_lock:
            if self._cached:
                self._cached[key] = value


class CachedBelongingToCurrentTornadoInstance(wm_utils.CachedData):
    def __init__(self, account):
        super(CachedBelongingToCurrentTornadoInstance, self).__init__()
        self.account = account
        self.__mail_sent = False

    def obtain_data(self):
        try:
            response = wm_utils.request_internal(self.account.name, '/l/i/instance-id', partner_name=self.account.partner_name)
            logging.warn('Result for /l/i/instance-id @' + self.account.name + ': ' + str(response))
            return response == wm_utils.tornado_instance_id
        except Exception:
            logging.error('Error while trying to check account %s belonging to current tornado instance', self.account.name, exc_info=True)
            return False

    def on_data_renewed(self, cached, obtained):
        if obtained:
            self.__mail_sent = False
        else:
            if cached is not None and not cached and not self.__mail_sent:
                # sending mail only if we get "False" twice and if we didn't send it before
                # wm_mail.mailer.send_short_message_notification(self.account, "account doesn't belong to tornado instance")
                self.__mail_sent = True


class CachedAccountKeyValue(wm_utils.CachedDBData):

    def __init__(self, account_name):
        wm_utils.CachedDBData.__init__(self, None)

        self.account_name = account_name

    def get(self, key):
        return self.get_data().get(key)

    def load_data(self, connection):
        rows = connection.query('select `key`, `value` from accountkeyvalue where accountname=%s', self.account_name)
        result = {}
        for r in rows:
            result[r['key']] = r['value']
        return result


class CheckBigAccountsRequestHandler(wm_web.AdminRequestHandler):

    def get(self, *args, **kwargs):
        connection = db_utils.get_connection()
        demo = self.get_argument('demo', None)
        sum_to_check = wm_settings.settings['money_amount_threshold_for_big_account_selection']
        big_accounts = connection.query(
            "SELECT a.accountname, max(sums) sums, phone, a.site, a.isblocked, oav.email, oav.fullname, a.tariff from ( \
                    SELECT SUM(money_writed_off) / 3 as sums, accountname FROM webim_pro_writeoff \
                    WHERE billing_date >= date_sub(now(), interval 3 month) GROUP BY accountname having sums > %s \
                UNION ALL \
                    SELECT SUM(price) / SUM(CASE WHEN replacedid IS NULL THEN monthcnt ELSE 0 END) as sums, accountname \
                    FROM orderedservice \
                    WHERE status in ('payed', 'replaced') AND dtmto >= date_sub(CURDATE(), interval 3 month) GROUP BY accountname \
                    HAVING sums > %s) t \
            INNER JOIN account a on a.accountname = t.accountname \
            INNER JOIN operatoraccountview oav on oav.accountname = t.accountname \
            GROUP BY accountname;", sum_to_check, sum_to_check
        )
        if demo:
            text = ''
            for account in big_accounts:
                text += (account['accountname'] + ' - ' + account['site'] + ' - ' + account['tariff'] + ' - ' + str(format(account['sums'], '.2f')) + '</br>')
            text += 'mail count - ' + str(len(big_accounts))
            self.write(text)
        else:
            errors = []
            for account in big_accounts:
                try:
                    account['chats_cnt'] = self.get_chats_cnt(account['accountname'])
                except Exception:
                    account['chats_cnt'] = 'error'
                    errors.append({account['accountname']: 'chat counter'})

                account['isblocked'] = True if account['isblocked'] else False
                account['sums'] = format(account['sums'], '.2f')
                try:
                    wm_mail.mailer.send_big_accounts_to_check_mail(account)
                except Exception:
                    errors.append({account['accountname']: 'mail sender'})
            self.write(json.dumps({'result': 'ok', 'mail_cnt': len(big_accounts), 'mail_errors': errors}))

    def get_chats_cnt(self, account_name):
        connection = db_utils.get_connection(account_name)
        chats_cnt = connection.get("SELECT COUNT(threadid) as cnt FROM chatthread WHERE created >= date_sub(now(), interval 3 month);")
        connection.close()
        return chats_cnt['cnt']


class GetBitrix24Tokens(wm_web.AdminRequestHandler):
    @tornado.web.asynchronous
    def get(self, *args, **kwargs):
        code = self.get_argument('code')
        domain = self.get_argument('domain')

        if code and domain:
            error = self.get_account().integration_manager.bitrix_crm.init_auth_settings(domain, code)
        else:
            error = 'invalid_request_params'

        if not error:
            self.send_result({'result': 'ok'})
        else:
            self.send_result({'error': error})


class AccountStateRequestHandler(wm_web.AdminRequestHandler):

    def get(self, *args, **kwargs):
        action = self.get_verified_argument('action')
        if action == 'get_state':
            account = BriefAccount.get(self.get_account_name())
            self.finish(json.dumps({'blocked': account.is_blocked()}))


class KeyValueStorage:
    def __init__(self, account):
        self.account = account
        self.__key_to_record = {}

    def get(self, key):
        record = self.__key_to_record.get(key)
        return record and record.value

    def set(self, key, value):
        record = self.__key_to_record.get(key)
        if record:
            record.set_value(value)
        else:
            record = KeyValueRecord(self.account, key, value)
            self.__key_to_record[key] = record

        record.store()

    def load(self):
        connection = db_utils.get_connection(self.account.name)
        rows = connection.query("SELECT * FROM keyvalue")
        connection.close()
        for row in rows:
            record = KeyValueRecord.create_loaded(self.account, row)
            self.__key_to_record[record.key] = record

        for filename, back_file_content in wm_utils.get_client_files_content('keyvalue', self.account.name).iteritems():
            record = KeyValueRecord.create_backed(self.account, back_file_content)
            self.__key_to_record[record.key] = record
            record.store()


class KeyValueRecord:
    def __init__(self, account, key, value, modification_ts=None, record_id=None):
        self.account = account
        self.id = record_id
        self.key = key
        self.value = value
        self.modification_ts = modification_ts or time.time()

    @classmethod
    def create_loaded(cls, account, row):
        return KeyValueRecord(account, row['key'], json.loads(row['value'] or 'null'), row['modifiedts'] / 1e6, row['id'])

    @classmethod
    def create_backed(cls, account, back_file_content):
        data = json.loads(back_file_content)
        return KeyValueRecord(account, data['key'], json.loads(data['value'] or 'null'), data['modification_ts'])

    def set_value(self, value):
        self.value = value
        self.modification_ts = time.time()

    def get_value_json(self):
        return json.dumps(self.value)

    def on_stored(self):
        wm_utils.remove_client_file('keyvalue/' + self.key + '.back', self.account.name)
        pass

    def store(self):
        wm_utils.store_client_file(json.dumps({
            'key': self.key,
            'value': self.get_value_json(),
            'modification_ts': self.modification_ts
        }), 'keyvalue/' + self.key + '.back', self.account.name)
        self.account.background_storager.add_object_to_store(self)
