# coding=UTF-8

__author__ = 'andrew'

import os
import json
import logging

import tornado.web

import wm_settings
import wm_timer
import wm_web
import wm_utils
import db_utils
import ordered_service


class TariffEditorRequestHandler(wm_web.AdminRequestHandler):

    def get(self, *args, **kwargs):
        account = self.get_account()

        base_tariff = None
        custom_tariff_row = None

        conn = db_utils.get_connection()
        rows = conn.query('SELECT * FROM tariff WHERE accountname=%s', account.name)
        conn.close()
        for row in rows:
            if row['tariffkey']:
                try:
                    if row['descriptor']:
                        desc = json.loads(row['descriptor'])
                        if desc.get('disabled'):
                            continue
                except Exception:
                    pass

                custom_tariff_row = row
            elif not row['tariffkey'] and not row['descriptor']:
                base_tariff = row

        if custom_tariff_row:
            custom_tariff = ordered_service.Tariff.get(self.get_account_name(), custom_tariff_row['tariffkey']).to_dict()

            res = {
                'descriptor': custom_tariff['descriptor'],
                'settings': merge_settings_with_tariff_descriptor(custom_tariff['settings']),
                'comment': custom_tariff_row['comment'],
                'tariff_key': custom_tariff['key'],
                'mode': 'custom',
                'version': wm_utils.version
            }

        else:
            settings = json.loads(base_tariff['settings']) if base_tariff and base_tariff['settings'] else {}

            res = {
                'settings': merge_settings_with_tariff_descriptor(settings),
                'comment': base_tariff['comment'] if base_tariff else None,
                'mode': 'base',
                'version': wm_utils.version
            }

        self.render('html/edit_tariff.html', **res)

    @tornado.web.asynchronous
    def post(self, *args, **kwargs):
        wm_timer.invoke_async(lambda: self._post(), 'set_tariff_option')

    def _post(self):
        try:
            value_type = self.get_verified_argument('type', None)
            tariff_key = self.get_argument('tariffKey', None)
            tariff_setting = self.get_verified_argument('tariff_setting', None)
            descriptor_setting = self.get_argument('descriptor_setting', None)

            if tariff_setting:
                if value_type == 'integer':
                    value = self.get_int_argument('value')
                elif value_type == 'string':
                    value = self.get_argument('value')
                elif value_type == 'boolean':
                    value = self.get_bool_argument('value')
                else:
                    self.reject_request('unknown_value_type')
                    return

                update_tariff_setting(self.get_account(), tariff_setting, value, tariff_key=tariff_key)

            if descriptor_setting:
                value = self.get_int_argument('value')
                update_tariff_descriptor(self.get_account(), descriptor_setting, value, tariff_key=tariff_key)

            self.finish({'result': 'ok'})

        except Exception as e:
            logging.error(str(e), exc_info=True)
            self.reject_request('unknown')


class CreateCustomTariffRequestHandler(wm_web.AdminRequestHandler):

    def get(self, *args, **kwargs):
        key_to_current_tariffs = {
            'start': ordered_service.Tariff.get(self.get_account_name(), 'start').to_dict(),
            'bus': ordered_service.Tariff.get(self.get_account_name(), 'bus').to_dict(),
            'corp': ordered_service.Tariff.get(self.get_account_name(), 'corp').to_dict()
        }

        for key in key_to_current_tariffs:
            key_to_current_tariffs[key]['settings'] = merge_settings_with_tariff_descriptor(
                settings=key_to_current_tariffs[key]['settings'], value_key_name='default')

        self.render('html/create_custom_tariff.html', **{'key_to_default_tariff': key_to_current_tariffs,
                                                         'version': wm_utils.version})

    @tornado.web.asynchronous
    def post(self, *args, **kwargs):
        wm_timer.invoke_async(lambda: self._post(), 'create_custom_tariff')

    def _post(self):
        settings = self.get_argument('settings')
        descriptor = self.get_argument('descriptor')
        tariff_key = self.get_argument('tariffKey')
        comment = self.get_argument('comment', None)

        account = self.get_account()
        conn = db_utils.get_connection()

        row = conn.get('SELECT * FROM tariff WHERE accountname=%s and tariffkey=%s and descriptor IS NOT NULL', account.name, tariff_key)
        if row:
            conn.execute("UPDATE tariff SET settings=%s and descriptor=%s and comment=%s WHERE id=%s", settings, descriptor, comment, row['id'])
        else:
            conn.execute("INSERT INTO tariff (tariffkey, accountname, settings, descriptor, comment) values (%s, %s, %s, %s, %s)",
                         tariff_key, account.name, settings, descriptor, comment)

        update_tariff_descriptor(account, 'disabled', True)
        conn.close()

        self.finish({'result': 'ok'})


def update_tariff_setting(account, tariff_setting, value, tariff_key=None):
        conn = db_utils.get_connection()

        if tariff_key:
            account_settings = conn.get("SELECT id, settings FROM tariff WHERE accountname=%s AND tariffkey=%s", account.name, tariff_key)
        else:
            account_settings = conn.get("SELECT id, settings FROM tariff WHERE accountname=%s AND tariffkey IS NULL", account.name)

        if account_settings:
            settings = json.loads(account_settings['settings']) if account_settings['settings'] else {}
            if tariff_setting not in settings or settings[tariff_setting] != value:
                settings[tariff_setting] = value
                conn.execute("UPDATE tariff SET settings=%s WHERE id=%s", json.dumps(settings), account_settings['id'])
        else:
            conn.execute("INSERT INTO tariff (tariffkey, accountname, settings) values (%s, %s, %s)",
                         tariff_key, account.name, json.dumps({tariff_setting: value}))

        conn.close()

        account.tariff_settings.reset()
        ordered_service.Tariff.get_cached_tariffs(account.name).reset()


def update_tariff_descriptor(account, descriptor_setting, value, tariff_key=None):
        conn = db_utils.get_connection()

        if tariff_key:
            account_descriptor = conn.get("SELECT id, descriptor FROM tariff WHERE accountname=%s AND tariffkey=%s", account.name, tariff_key)
        else:
            account_descriptor = conn.get("SELECT id, descriptor FROM tariff WHERE accountname=%s AND tariffkey IS NULL", account.name)

        if account_descriptor:
            descriptor = json.loads(account_descriptor['descriptor']) if account_descriptor['descriptor'] else {}
            if descriptor_setting not in descriptor or descriptor[descriptor_setting] != value:
                descriptor[descriptor_setting] = value
                conn.execute("UPDATE tariff SET descriptor=%s WHERE id=%s", json.dumps(descriptor), account_descriptor['id'])
        else:
            conn.execute("INSERT INTO tariff (tariffkey, accountname, descriptor) values (%s, %s, %s)",
                         tariff_key, account.name, json.dumps({descriptor_setting: value}))

        conn.close()

        account.tariff_settings.reset()
        ordered_service.Tariff.get_cached_tariffs(account.name).reset()


def merge_settings_with_tariff_descriptor(settings=None, value_key_name=None):
    if not settings:
        settings = {}

    result = []

    for t_setting in TARIFF_DESCRIPTOR:
        d = {k: v for k, v in TARIFF_DESCRIPTOR[t_setting].items()}
        d['key'] = t_setting
        d[value_key_name or 'value'] = settings[t_setting] if t_setting in settings else ""
        result.append(d)

    return result


class TariffsInfoRequestHandler(wm_web.AdminRequestHandler):

    def get(self, *args, **kwargs):

        conn = db_utils.get_connection()
        rows = conn.query('SELECT * FROM tariff WHERE accountname is null and partner is null')

        tariff_key_to_settings = {}
        for row in rows:
            settings_json = row['settings']
            tariff_key_to_settings[row['tariffkey']] = json.loads(settings_json)

        info = []
        for setting_key, setting_description in TARIFF_DESCRIPTOR.items():
            record = {'setting_key': setting_key, 'setting_description': setting_description['description']}
            for tariff_key, tariff_settings in tariff_key_to_settings.items():
                record[tariff_key] = tariff_settings.get(setting_key)
            info.append(record)

        res = {
            'info': info,
            'version': wm_utils.version
        }

        self.render('html/tariffs_info.html', **res)

def load_descriptor():
    desc_file_name = os.path.join(wm_settings.public_html_dir, 'webim/classes/tariff-options-descriptor.json')
    desc_file = open(desc_file_name, 'r')
    return json.loads(desc_file.read())


TARIFF_DESCRIPTOR = load_descriptor()