import json
import os
import inspect
import copy

import base_utils


settings = {}
db_settings = {}
__connections = {}
__account_to_db_settings = {}
public_html_dir = ''


def get_public_html_dir():
    current_filename = inspect.getfile(inspect.currentframe())
    env = current_filename[:current_filename.rfind('/')]
    env = env[:env.rfind('/') + 1]
    if 'webim-server/python' in env:
        public_html_dir = env.replace('python', 'php')
    else:
        public_html_dir = env.replace('python', 'public_html')
    return public_html_dir


class IniConfigParser:
    @classmethod
    def parse_line(cls, line):
        if line[0] in '[#;\n':
            return
        if ';' in line:
            line = line[:line.index(';')]
        arr = line.split('=', 1)
        arr = [v.strip() for v in arr]
        if '\"' == arr[1][0] or '\'' == arr[1][0]:
            arr[1] = arr[1].strip('\"\'')
        else:
            try:
                arr[1] = int(arr[1])
            except ValueError:
                pass
        return arr

    @classmethod
    def parse_ini(cls, file_path):
        result_dict = {}
        content = []

        if os.path.exists(file_path):
            path = os.path.join(file_path)
            f = open(path, 'r')
            try:
                content = f.readlines()
            finally:
                f.close()
        if not content:
            return
        for line in content:
            kv = cls.parse_line(unicode(line))
            if kv:
                key = kv[0]
                value = kv[1]
                if '[]' in key:
                    array_name = key.strip('[]')
                    if array_name not in result_dict:
                        result_dict[array_name] = list()
                    result_dict[array_name].append(value)
                else:
                    result_dict[key] = value
        return result_dict


def parse_json(file_path):
    data = {}
    if os.path.exists(file_path):
        path = os.path.join(file_path)
        f = open(path, 'r')
        try:
            content = f.read()
            data = json.loads(content)
        finally:
            f.close()
    return data


def dict_merge(dict1, dict2, append_lists=False):
    for key in dict2:
        if key in dict1:
            if type(dict2[key]) == dict:
                dict_merge(dict1[key], dict2[key], append_lists)
            elif append_lists and type(dict2[key]) == list:
                    dict1[key] = dict1[key] + dict2[key]
            else:
                dict1[key] = dict2[key]
        else:
            dict1[key] = dict2[key]


def __load_db_settings():  # noqa: N802
    result = parse_json('/etc/webim/db.json')
    dict_merge(result, parse_json('/etc/webim/db.d.json'))
    dict_merge(result, parse_all_config_files_in_dir('/etc/webim/db.json.d/', parse_json))

    connections = result.get('connections', {})
    __substitute_connections(result['dbs'], connections)

    return result['dbs'], connections


def get_account_db_settings(account_name):
    global __account_to_db_settings
    if account_name not in __account_to_db_settings:  # todo use DictExt (import problem resolving required)
        __account_to_db_settings[account_name] = __load_account_db_settings(account_name)
    return __account_to_db_settings.get(account_name)


def __load_account_db_settings(account_name):  # noqa: N802
    global db_settings, __connections
    account_db_settings = parse_all_config_files_in_dir(os.path.join(settings['client-data-dir'], account_name, "db/db.json.d"), parse_json)
    if account_db_settings:
        __db_settings = copy.copy(db_settings)
        __substitute_connections(account_db_settings['dbs'], __connections)
        dict_merge(__db_settings, account_db_settings['dbs'])
        return __db_settings
    else:
        return db_settings


def __substitute_connections(dbs, connections):  # noqa: N802
    for key, value in dbs.items():
        if type(value) == dict:
            __substitute_connections(value, connections)
        elif key == 'connection':
            if value not in connections:
                raise Exception("Connection %s not found in configuration" % value)
            else:
                dict_merge(dbs, connections.get(value))


def __get_main_settings():  # noqa: N802
    settings = IniConfigParser.parse_ini('/etc/webim/main.ini')
    settings_d = parse_all_config_files_in_dir('/etc/webim/main.ini.d/', IniConfigParser.parse_ini, True)
    dict_merge(settings, settings_d, True)
    if os.path.isfile('/etc/webim/main.json'):
        settings.update(parse_json('/etc/webim/main.json'))
    if os.path.isfile('/etc/webim/main.json.d/main.json'):
        settings.update(parse_json('/etc/webim/main.json.d/main.json'))
    return settings


def parse_all_config_files_in_dir(dir_path, parse_function, merge_lists=False):
    data = {}
    if os.path.exists(dir_path):
        file_names = os.listdir(dir_path)
        for file_name in file_names:
            dict_merge(data, parse_function(os.path.join(dir_path, file_name)), merge_lists)
    return data


def load():
    global settings, db_settings, __connections, __account_to_db_settings, public_html_dir
    settings = __get_main_settings()
    db_settings, __connections = __load_db_settings()
    __account_to_db_settings = {}
    public_html_dir = get_public_html_dir()


load()


def get(name, default=None):
    return settings[name] if name in settings else default


def get_normal_polling_period(account_name):
    normal_polling_period = settings['normal_polling_period'][account_name]\
        if account_name in settings['normal_polling_period']\
        else settings['normal_polling_period']['default']
    return normal_polling_period


def get_partner_domain(partner_name):
    return get_partner_setting(partner_name, 'domain') or settings.get('base_domain') or 'webim.ru'


def get_full_domain(account, public=False):
    if settings.get('hostedmode'):
        if public and settings.get('public_domain'):
            return settings.get('public_domain')

        return settings.get('base_domain')
    else:
        return account.name + '.' + get_partner_domain(account.partner_name)


def get_protocol(public=False):
    if public:
        return settings.get('public_protocol', 'https')

    return 'https'


def get_full_domain_by_account_name(account_name, partner_name=None):  # TODO
    if settings.get('hostedmode'):
        return settings.get('base_domain')
    else:
        return account_name + '.' + get_partner_domain(partner_name)


def get_partner_setting(partner_name, setting_name):
    partner_settings = settings.get('partner_settings', base_utils.EMPTY_DICT)
    return (partner_settings.get(partner_name, base_utils.EMPTY_DICT).get(setting_name)
            or partner_settings.get('default', base_utils.EMPTY_DICT).get(setting_name))

def is_hosted_mode():
    return settings.get('hostedmode')
