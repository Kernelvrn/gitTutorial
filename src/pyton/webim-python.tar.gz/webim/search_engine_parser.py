# -*- coding: utf-8 -*-
# # codepage=UTF8
# coding: utf-8
import logging
import re
import urlparse

class SearchEngineSearch(object):
    def __init__(self, engine, search_text):
        self.engine = engine
        self.search_text = search_text

    def to_dict(self, context=None):
        return {'engine': self.engine, 'search_text': self.search_text}

class SearchEngineParser(object):
    _instance = None

    def __new__(cls, *args, **kwargs):
        if not cls._instance:
            cls._instance = super(SearchEngineParser, cls).__new__(cls, *args, **kwargs)
            cls._instance.init()

        return cls._instance

    def init(self):
        self.__patterns = {
            'market.yandex.ru': {'pattern': re.compile("(http|https):\/\/[\.\w]*(market\.yandex)\.ru"), 'param': 'text'},
            'images.yandex.ru': {'pattern': re.compile("(http|https):\/\/[\.\w]*(images\.yandex)\.ru"), 'param': 'text'},
            'yandex.com': {'pattern': re.compile("(http|https):\/\/[\.\w]*(yandex|ya)\.com"), 'param': 'text'},
            #yandex have different icons
            'yandex.ru': {'pattern': re.compile("(http|https):\/\/[\.\w]*(yandex|ya)\.\w{2,4}"), 'param': 'text'},
            'google.ru': {'pattern': re.compile("(http|https):\/\/[\.\w]*(google?)\.\w{2,4}"), 'param': 'q'},
            'torg.mail.ru': {'pattern': re.compile("(http|https):\/\/[\.\w]*(torg\.mail)\.ru"), 'param': 'q'},
            'mail.ru': {'pattern': re.compile("(http|https):\/\/[\.\w]*(mail)\.ru"), 'param': 'q'},
            'search.qip.ru': {'pattern': re.compile("(http|https):\/\/[\.\w]*(search\.qip)\.ru"), 'param': 'query'},
            'rambler.ru': {'pattern': re.compile("(http|https):\/\/[\.\w]*(rambler)\.ru"), 'param': 'query'},
            'nigma.ru': {'pattern': re.compile("(http|https):\/\/[\.\w]*(nigma)\.ru"), 'param': 's'},
            'webalta.ru': {'pattern': re.compile("(http|https):\/\/[\.\w]*(webalta)\.ru"), 'param': 'q'},
            'bing.com': {'pattern': re.compile("(http|https):\/\/[\.\w]*(bing)\.\w{2,4}"), 'param': 'q'},
            'yahoo.com': {'pattern': re.compile("(http|https):\/\/[\.\w]*(yahoo)\.\w{2,4}"), 'param': 'p'},
        }

    def get_search(self, referer):
        logging.info("Trying to parse: %s for search" % referer)
        try:
            for engine, info in self.__patterns.items():
                logging.info("trying engine %s" % engine)
                if info['pattern'].match(referer) is None:
                    continue

                params = urlparse.parse_qs(urlparse.urlparse(referer).query)

                if not info['param'] in params:
                    return None

                text = params[info['param']][0]

                text = text.encode('iso-8859-1')

                try:
                    text = unicode(text, "utf-8" )
                except UnicodeDecodeError:
                    text = unicode(text, "cp1251" )

                #                if text.upper().find('%D') >= 0 or text.upper().find('%DE') >= 0: # TODO quote hard
                #                    text = urllib.unquote_plus(text).decode('utf-8')
                #                else:
                #                    text = urllib.unquote_plus(text).decode('cp1251')
                #
                logging.info("Got search text: %s for %s" % (text, referer))

                return SearchEngineSearch(engine, text)

        except:
            logging.error(u'Could not parse search engine for: %s' % referer, exc_info=True)
            return None

if __name__ == "__main__":
    logging.getLogger().setLevel(logging.INFO)
    print 'мой тест'
    tests = [
#            'http://go.mail.ru/search?rch=l&drch=e&q=%E1%E0%ED%FF+%E8%E7+%E1%F0%E5%E2%ED%E0+%F6%E5%ED%FB+%ED%E0+%E1%F0%B8%E2%ED%E0'
#            ,
#            'http://go.mail.ru/search?q=%EE%E4%ED%EE%FD%F2%E0%E6%ED%FB%E5%20%EF%F0%EE%E5%EA%F2%FB%20%E4%EE%EC%EE%E2%20%E4%EE%20150%EA%E2.%EC%20%F1%20%E3%E0%F0%E0%E6%E5%EC&rch=e&num=10&sf=10'
#            ,
#            'http://search.qip.ru/search?query=%E1%E0%ED%FF+%E8%E7+%E1%F0%E5%E2%ED%E0+%F6%E5%ED%FB+%ED%E0+%E1%F0%B8%E2%ED%E0&from=opera'
#            ,
#            'http://market.yandex.ru/search.xml?&hid=240865&glfilter=6181009%3A6181010&how=dprice&np=1',
#            "http://www.google.ru/search?q=%D1%81%D1%82%D0%BE%D0%BB%D0%B8%D0%BA+%D0%B4%D0%BB%D1%8F+%D0%BD%D0%BE%D1%83%D1%82%D0%B1%D1%83%D0%BA%D0%B0+fleks&amp;ie=utf-8&amp;oe=utf-8&amp;aq=t&amp;rls=org.mozilla:ru:official&amp;client=firefox"
#            ,
#            'http://yandex.ru/yandsearch?text=1%f1+%e1%e8%f2%f0%e8%ea%f1+%ed%e0%e3%f0%f3%e7%ea%e0',
#            'http://www.google.ru/custom?hl=ru&newwindow=1&safe=active&client=pub-3445190438847833&cof=FORID%3A13%3BAH%3Aleft%3BCX%3AGoogle%3BL%3Ahttp%3A%2F%2Fwww.google.com%2Fintl%2Fen%2Fimages%2Flogos%2Fcustom_search_logo_sm.gif%3BLH%3A30%3BLP%3A1%3BLC%3A%230066cc%3BVLC%3A%23336633%3BGALT%3A%230066cc%3BDIV%3A%23999999%3B&adkw=AELymgUhmTcvinvVgY1SivY7sqoHabqdlUURC1sMwZPW8GXw2iR5Y1Z5jav_QcPgcG8qjyuRQeQtKn9861eO1Fbz55cfJDREsqSjbpWAuhvUV3WPrqSCVHk&q=%D0%BF%D0%BE%D0%B4%D1%81%D1%82%D0%B0%D0%B2%D0%BA%D0%B0+%D0%B4%D0%BB%D1%8F+%D0%BD%D0%BE%D1%83%D1%82%D0%B1%D1%83%D0%BA%D0%BE%D0%B2+%D1%82%D1%83%D0%BB%D0%B0&btnG=%D0%9F%D0%BE%D0%B8%D1%81%D0%BA&cx=partner-pub-3445190438847833%3A49stubd325q'
#            ,
#            'http://yandex.ru/yandsearch?text=%D1%81%D1%82%D0%BE%D0%BB%D0%B8%D0%BA+%D0%B2+%D0%BA%D1%80%D0%BE%D0%B2%D0%B0%D1%82%D1%8C&lr=2'
#            ,
            'http://www.google.ru/search?q=%D1%81%D1%82%D0%BE%D0%BB%D0%B8%D0%BA+%D0%B4%D0%BB%D1%8F+%D0%BD%D0%BE%D1%83%D1%82%D0%B1%D1%83%D0%BA%D0%B0+fleks&ie=utf-8&oe=utf-8&aq=t&rls=org.mozilla:ru:official&client=firefox'
#            ,
#            'http://www.google.ru/url?sa=t&source=web&cd=7&sqi=2&ved=0CE0QFjAG&url=http%3A%2F%2Fww.homeplans.ru%2Fprojects%2Findex.php%3Finfo%3DF-0866-0&rct=j&q=%D0%B4%D0%BE%D0%BC%20%D1%81%20%D0%B3%D0%B0%D1%80%D0%B0%D0%B6%D0%BE%D0%BC%20%D0%BF%D1%80%D0%BE%D0%B5%D0%BA%D1%82&ei=ldFjTbWFFcXpOaSF-bkN&usg=AFQjCNE35UfH6wyE2jA5m7Na4UrmPIgaVQ&cad=rjt '
    ]

    for t in tests:
        s = SearchEngineParser().get_search(t)
        print s.search_text if s is not None else 'None'
