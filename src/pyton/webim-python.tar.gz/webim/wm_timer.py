from heapq import heappush, heappop
import logging
import random
from threading import Thread
import threading
import time

import tornado

import wm_web
from wm_utils import InstanceCountTracker, invoke_in_ioloop
from . import stat


class WmTimer(InstanceCountTracker):
    def __init__(self, target, name, order_importance_key):
        super(WmTimer, self).__init__()
        self.target = target
        self.is_active = True
        self.name = name
        self.order_importance_key = order_importance_key
        self.subtasks = [] if order_importance_key else None

    def cancel(self):
        self.is_active = False
        self.target = None


class TimersManager(object):

    _instance = None

    def __new__(cls, *args, **kwargs):
        if not cls._instance:
            cls._instance = super(TimersManager, cls).__new__(cls, *args, **kwargs)
            cls._instance.__timers = []
            cls._instance.__order_importance_key_to_timer = {}
            cls._instance.__timeout = 1
            cls._instance.__lock = threading.Lock()
            cls._instance.__threads_cnt = 0
            cls._instance.__init_threads()
            cls._instance.__time_of_bad_timer = time.time() - 60

        return cls._instance

    def __init_threads(self):

        for i in range(0, 30):
            name = 'Timer thread %f #%s' % (time.time(), i)
            thread = Thread(name=name, target=self.run)
            thread.start()
            self.__threads_cnt += 1

        self.__last_run = time.time()  # let it be so
        # logging.info('Starting thread name %s' % name)

    def run(self):
        timeout = random.uniform(0.8, 1.2)
        while True:
            self.__run()
            time.sleep(timeout)

    def __run(self):
        # logging.info('%s: Running timer_thread' % self.__thread.getName())
        # print('%s: Running timer_thread' % self.__thread.getName())
        # logging.info("Heart beat, timers: %d" % len(self.__timers))

        # started = time.time()

        while True:
            t = self.__get_next_to_run()
            if not t:
                break

            self.__run_timer(t)

            if t.order_importance_key:
                i = 0
                while True:
                    with self.__lock:
                        if i >= len(t.subtasks):
                            # print "subtasks cnt: " + str(len(t.subtasks)) + ' ' + t.order_importance_key
                            del self.__order_importance_key_to_timer[t.order_importance_key]
                            break
                        subtask = t.subtasks[i]
                    self.__run_timer(subtask)
                    i += 1

        self.__last_run = time.time()
        # logging.info("timers became after heart beat %d" % len(self.__timers))

        # finished = time.time()
        # logging.info('run for timers took %f ' % (finished - started))

    def __run_timer(self, t):
        try:
            start = time.time()
            t.target()
            duration = time.time() - start
            timer_stats.update({
                'timer_name': 'timer: ' + (t.name or ''),
                'func_name': t.target.__name__ if t.target else 'unknown',
                'execution_time': duration
            })
            if duration > 10:
                failed_timer_stats.update({
                    'timer_name': t.name,
                    'func_name': t.target.__name__ if t.target else 'unknown',
                    'execution_time': duration,
                    'ts': start
                })
                logging.warn("timer " + t.name + " execution took " + str(duration) + " sec")
        except Exception:
            logging.error("Error while trying to execute target", exc_info=True)
        self.__last_run = time.time()

    def __get_next_to_run(self):
        when, tmr = 0, None
        with self.__lock:
            while True:
                if len(self.__timers) == 0:
                    return None
                when, tmr = self.__timers[0]
                if when >= time.time():
                    return None
                when, tmr = heappop(self.__timers)

                if tmr.is_active:
                    break

        diff = time.time() - when
        if diff > 2:
            self.__time_of_bad_timer = when
            logging.warn('Timer waiting in the queue too much: %d sec', diff)
        return tmr

    def add_timer(self, interval, target, name=None, order_importance_key=None):
        if interval and order_importance_key:
            raise Exception('order_importance_key can be given only for "run-now tasks"')
        if order_importance_key:
            logging.warn("order_importance_key: " + str(order_importance_key))

        # started = time.time()

        next_start = time.time() + interval
        timer = WmTimer(target=target, name=name, order_importance_key=order_importance_key)
        with self.__lock:
            parent_timer = self.__order_importance_key_to_timer.get(order_importance_key)
            if parent_timer:
                parent_timer.subtasks.append(timer)
            else:
                heappush(self.__timers, (next_start, timer))
                if order_importance_key:
                    self.__order_importance_key_to_timer[order_importance_key] = timer

        # logging.info("add_timer: timers became %d" % len(self.__timers))

        if self.__last_run < time.time() - self.__timeout * 50:
            if self.__threads_cnt < 200:
                logging.warn("Timers: Starting more threads because last run was too long ago")
                self.__init_threads()
                logging.warn("Timers: Total threads: " + str(self.__threads_cnt))
            else:
                logging.warn("Timers: Last run was too long ago but there are too much threads already - " + str(self.__threads_cnt) + ", do not starting more")

        # finished = time.time()
        # logging.warn('add_timer took %f' % (finished - started))

        return timer

    def get_timers(self):
        return self.__timers

    def get_time_of_bad_timer(self):
        return self.__time_of_bad_timer


class TimersStatRequestHandler(wm_web.AdminRequestHandler):

    @tornado.web.asynchronous
    def get(self):
        invoke_async(self.__get, timer_name='TimersStatRequestHandler')

    def __get(self):
        result = {'last_min': timer_stats.prev_collected_stats.data,
                  'failed': failed_timer_stats.current_collected_stats.data}

        invoke_in_ioloop(lambda: self.finish(result), name='TimersStatRequestHandler')


def invoke_async(target, timer_name='invoke_async', order_importance_key=None):
    add_timer(0, target, timer_name, order_importance_key=order_importance_key)


def invoke_periodically(period, target, timer_name=None):
    def t():
        try:
            target()
        except Exception:
            logging.error("Error while invoking periodically (%s)" % timer_name if timer_name else '', exc_info=True)
        invoke_periodically(period, target, timer_name)

    add_timer(period, t, timer_name)


timers_manager = TimersManager()
add_timer = timers_manager.add_timer


if __name__ == "__main__":

    def test_f1():
        print("%s: Test f1 is executed" % time.time())

    def test_f2():
        print("%s: Test f2 is executed" % time.time())

    def test_f3():
        print("%s: Test f3 is executed" % time.time())

    # t1 = timers_manager.add_timer(1, test_f1)
    # t1.cancel()
    #
    # timers_manager.add_timer(5, test_f2)
    # timers_manager.add_timer(5, test_f2)
    # timers_manager.add_timer(15, test_f3)
    # timers_manager.add_timer(50, test_f3)

    t = {'a': [], 'b': [], 'c': [], 'all': []}

    for i in range(1, 30):
        time.sleep(random.random() * 1.4)
        for j in ['a', 'b', 'c']:
            def tmp(ii, jj):
                def target():
                    time.sleep(random.random())
                    t[jj].append(ii)
                    t['all'].append(jj + str(ii))
                invoke_async(target, '123', jj if jj != 'c' else None)
            tmp(i, j)
            # tmp(i)

    def ttt():
        time.sleep(2)
        print t['a']
        print t['b']
        print t['c']
        print t['all']

    invoke_periodically(7, ttt)

    # for i in range(100):
    # timers_manager.add_timer(random.random() * 50, test_f3)

    # time.sleep(6000)

timer_stats = stat.StatsByPeriod(name='timers', stats_type='timers')
failed_timer_stats = stat.StatsByPeriod(name='failed_timers', stats_type='failed_timers', period=24 * 60 * 60)
