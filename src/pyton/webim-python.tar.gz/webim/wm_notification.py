# coding=UTF-8
import json
import random
import os
import time
import urllib
import urllib2
import datetime
import logging
from threading import Lock

import dateutil.tz
from apns import APNs, Payload
import gcmclient
import pyfcm
import nexmo
import requests

import delta
from chat import Chat
from chat import Message
import wm_settings
import wm_timer
import wm_utils
import wm_mail
import wm_resources


__author__ = 'mixey'


class Notification(wm_utils.InstanceCountTracker, wm_utils.Jsonable):

    class Kind(object):
        OPERATOR_BUSY = 'operator_busy'
        WAITING_VISITOR = 'waiting_visitor'
        VISITOR_MESSAGE = 'visitor_message'
        VISITOR_REDIRECTED = 'visitor_redirected'
        NEW_VISITOR = 'new_visitor'
        VISITOR_FIELDS_CHANGED = 'visitor_fields_changed'
        FOR_OPERATOR_MESSAGE = 'for_operator_message'
        FORM_RESPONSE = 'form_response'
        VISITOR_FILE = 'visitor_file'
        VISITOR_CONTACTS = 'visitor_contacts'

    def __init__(self, id, kind, session_id, push_data, url, visitor=None):
        super(Notification, self).__init__()
        self.id = id
        self.kind = kind
        self.session_id = session_id
        self.push_data = push_data
        self.url = url
        self.visitor = visitor
        self.ts = time.time()

    @staticmethod
    def get_formatted_notification_text(account, lang, push_data):
        return wm_resources.get_resource(account, lang or account.get_setting('default_lang'), 'notification.%s' % push_data['loc-key'], *push_data['params'])

    def __get_formatted_notification_text(self, account, lang):
        return Notification.get_formatted_notification_text(account, lang, self.push_data)

    def to_dict(self, context=None):
        account = context.get('account')
        lang = context.get('lang')

        text = self.__get_formatted_notification_text(account, lang)

        return {
            'id': self.id,
            'kind': self.kind,
            'sessionId': self.session_id,
            'text': text,
            'url': self.url,
            'visitor': None if self.visitor is None else self.visitor.to_dict(),
            'ts': self.prepare_ts(self.ts, context)
        }


class NotificationManager(object):

    def __init__(self, online_operator):
        self.online_operator = online_operator
        self.account = online_operator.account
        self.session_id_to_notification = {}

    def get_notifications(self):
        return self.session_id_to_notification.values()

    def process_delta(self, d):
        if type(d) == list:
            for dd in d:
                self.process_delta(dd)
            return

        if d.object_type == 'VISIT_SESSION':
            if d.event == delta.Delta.Event.ADD:
                session = d.data
                if session.chat:
                    self.__process_chat_added_delta(session.chat)
                else:
                    self.add_new_visitor_notification(session)
            elif d.event == delta.Delta.Event.DELETE:
                self.__remove_notification(d.id)

        if d.object_type == 'VISIT_SESSION_ON_SITE':
            on_site = d.data
            if on_site.get():
                pass
                # self.add_new_visitor_notification(self.account.visit_tracker.get_session(d.id))
            else:
                self.__remove_notification(d.id, [Notification.Kind.NEW_VISITOR])

        elif d.object_type == 'CHAT':
            if d.event == delta.Delta.Event.ADD:
                self.__process_chat_added_delta(d.data)
            elif d.event == delta.Delta.Event.DELETE:
                self.__remove_notification(d.id)
        elif d.object_type == 'CHAT_STATE':
            if d.event == delta.Delta.Event.UPDATE:
                state = d.data
                if state == Chat.State.QUEUE:
                    session = self.account.visit_tracker.get_session(d.id)
                    if not session.chat.redirected:
                        self.add_waiting_visitor_notification(session)
                else:
                    self.__remove_notification(d.id)
        elif d.object_type == 'CHAT_MESSAGE_2':
            if d.event == delta.Delta.Event.ADD:
                message = d.data
                session_id = message.session_id

                if message.kind == Message.Kind.VISITOR:
                    # if session_id not in self.session_id_to_notification
                    # or self.session_id_to_notification[session_id].kind != Notification.Kind.OPERATOR_BUSY:
                    session = self.account.visit_tracker.get_session(session_id)
                    if session.chat.state == Chat.State.QUEUE:
                        self.add_waiting_visitor_notification(session, message)
                    else:
                        self.add_visitor_message_notification(message, session)
                if message.kind == Message.Kind.OPERATOR:
                    self.__remove_notification(session_id)
                if message.kind == Message.Kind.OPERATOR_BUSY:
                    session = self.account.visit_tracker.get_session(session_id)
                    self.add_operator_busy_notification(session.chat)
                if message.kind == Message.Kind.FILE_VISITOR:
                    session = self.account.visit_tracker.get_session(session_id)
                    self.add_visitor_file_notification(session)
                if message.kind == Message.Kind.CONTACTS:
                    session = self.account.visit_tracker.get_session(session_id)
                    self.add_visitor_contacts_notification(session)
                if message.kind == Message.Kind.FOR_OPERATOR:
                    session = self.account.visit_tracker.get_session(session_id)
                    if message.data is not None and message.data.get('subKind') == 'identification-received':
                        self.add_visitor_contacts_notification(session)

        elif d.object_type == 'CHAT_UNREAD_BY_OPERATOR_SINCE_TS':
            if d.event == delta.Delta.Event.UPDATE:
                value = d.data
                session_id = d.id
                if not value:
                    self.__remove_notification(session_id, [Notification.Kind.VISITOR_MESSAGE, Notification.Kind.VISITOR_REDIRECTED])

        elif d.object_type == 'CHAT_OPERATOR':
            if d.event == delta.Delta.Event.UPDATE:
                session_id = d.id
                session = self.account.visit_tracker.get_session(session_id)
                if session.chat:
                    if session.chat.get_operator_id() != self.online_operator.operator_id:
                        self.__remove_notification(session_id, [Notification.Kind.VISITOR_MESSAGE, Notification.Kind.VISITOR_REDIRECTED])
                    elif session.chat.redirected:
                        self.add_visitor_redirected_notification(session)
                    elif session.account.get_setting('auto_assign') and session.chat.state == Chat.State.QUEUE:
                        self.add_waiting_visitor_notification(session, self.__get_last_visitor_message(session.chat))

#        elif d.object_type == 'VISITED_PAGE':
#            if d.event == delta.Delta.Event.ADD:
#                page = d.data
#                location_settings = page.get_location_settings()
#                if location_settings.get('js', {}).get('misc', {}).get('newVisitorNotification', False):
#                    self.add_new_visitor_notification(page.visit_session)

    def __process_chat_added_delta(self, chat):
        if chat.state == Chat.State.QUEUE or (self.account.oo_manager.get_online_inf() and chat.state == Chat.State.CHATTING):
            last_busy_operator = self.__get_last_visitor_message(chat, Message.Kind.OPERATOR_BUSY)
            if last_busy_operator:
                self.add_operator_busy_notification(chat)
            else:
                self.add_waiting_visitor_notification(chat.session, self.__get_last_visitor_message(chat))
        elif chat.state == Chat.State.CHATTING:
            last_busy_operator = self.__get_last_visitor_message(chat, Message.Kind.OPERATOR_BUSY)
            if last_busy_operator:
                self.add_operator_busy_notification(chat)
            else:
                last_visitor_message = self.__get_last_visitor_message(chat)
                if last_visitor_message:
                    self.add_visitor_message_notification(last_visitor_message, chat.session)

    def __get_last_visitor_message(self, chat, kind=Message.Kind.VISITOR):
        last_visitor_message = None
        for message in reversed(chat.messages):
            if message.kind == kind:
                last_visitor_message = message
                break
            elif message.kind == Message.Kind.OPERATOR:
                break
        return last_visitor_message

    # add / remove notification methods

    def add_visitor_message_notification(self, message, session):
        if message.get_data('dont_require_response', False):
            return

        if session.chat.get_operator_id() != self.online_operator.operator_id:
            return

        city = _format_city(session.ip_info.get_city(session.lang))

        push_data = {
            'loc-key': 'P.NM',
            'params': [message.text, u' ' + message.name, city],
            'sound': 'm.aiff'
        }

        if message.aux:
            push_data['aux'] = message.aux

        self.__create_and_add_notification(Notification.Kind.VISITOR_MESSAGE, push_data, session)

    def add_visitor_redirected_notification(self, session):
        if session.chat.get_operator_id() != self.online_operator.operator_id:
            return

        city = _format_city(session.ip_info.get_city(session.lang))
        push_data = {
            'loc-key': 'P.TR',
            'params': ['', u' ' + session.visitor.get_name(), city],
            'sound': 'default'
        }

        self.__create_and_add_notification(Notification.Kind.VISITOR_REDIRECTED, push_data, session)

    def add_waiting_visitor_notification(self, session, message=None):
        if session.chat.get_operator_id():
            if session.chat.get_operator_id() != self.online_operator.operator_id:
                return
        else:
            if session.account.get_setting('auto_assign'):
                return

        if not message and session.account.name == 'bauserviceru001':
            return

        city = _format_city(session.ip_info.get_city(session.lang))
        visitor_name = session.visitor.get_name()

        push_data = {
            'loc-key': 'P.NCM' if message else 'P.NC',
            'params': [message.text if message else '', u' ' + visitor_name, city],
            'sound': 'l.aiff'
        }

        if message and message.aux:
            push_data['aux'] = message.aux

        self.__create_and_add_notification(Notification.Kind.WAITING_VISITOR, push_data, session)

    def add_new_visitor_notification(self, session):
        operator = self.online_operator.get_operator()

        #  'new_visitor_notification' can be True, False or None (None means "use account setting")
        if operator.config.get('new_visitor_notification') is False:
            return

        if not self.account.settings.get('new_visitor_notification') and operator.config.get('new_visitor_notification') is None:
            return

        if session.id in self.session_id_to_notification:
            return  # to not override more important notifications

        city = _format_city(session.ip_info.get_city(session.lang))

        push_data = {
            'loc-key': 'P.NV',
            'params': ['', u' ' + session.visitor.get_name(), city],
            'sound': 'l.aiff'
        }

        self.__create_and_add_notification(Notification.Kind.NEW_VISITOR, push_data, session)

    def add_operator_busy_notification(self, chat):
        if self.account.get_setting('hide_anothers_chats'):
            if chat.get_operator_id() != self.online_operator.operator_id:
                return

        session = chat.session
        city = _format_city(session.ip_info.get_city(session.lang))
        push_data = {
            'loc-key': 'P.OB',
            'params': ['', u' ' + session.visitor.get_name(), city],
            'sound': 'm.aiff'
        }

        self.__create_and_add_notification(Notification.Kind.OPERATOR_BUSY, push_data, session)

    def add_visitor_file_notification(self, session):
        if not session.chat or not session.chat.get_operator_id() or session.chat.get_operator_id() != self.online_operator.operator_id:
            return

        city = _format_city(session.ip_info.get_city(session.lang))

        push_data = {
            'loc-key': 'P.VF',
            'params': ['', session.visitor.get_name(), city],
            'sound': 'm.aiff'
        }

        self.__create_and_add_notification(Notification.Kind.VISITOR_FILE, push_data, session)

    def add_visitor_contacts_notification(self, session):
        if not session.chat or not session.chat.get_operator_id() or session.chat.get_operator_id() != self.online_operator.operator_id:
            return

        city = _format_city(session.ip_info.get_city(session.lang))

        push_data = {
            'loc-key': 'P.VC',
            'params': ['', session.visitor.get_name(), city],
            'sound': 'm.aiff'
        }

        self.__create_and_add_notification(Notification.Kind.VISITOR_CONTACTS, push_data, session)

    def remove_new_visitor_notification(self, session):
        self.__remove_notification(session.id)

    def __create_and_add_notification(self, kind, push_data, session):
        url = "http://" + self.account.name + '.' + wm_settings.settings['base_domain'] + '/webim/operator/tracker.php#' + session.id
        self.__add_notification(Notification(session.id, kind, session.id, push_data, url, visitor=session.visitor))

    def __add_notification(self, notification):
        push_data = notification.push_data
        self.__remove_notification(notification.session_id)
        self.session_id_to_notification[notification.session_id] = notification

        if notification.kind == Notification.Kind.NEW_VISITOR and self.account.get_setting('new_visitor_notification_timeout'):
            wm_timer.add_timer(self.account.get_setting('new_visitor_notification_timeout'),
                               lambda: self.__remove_notification(notification.session_id, kinds=[Notification.Kind.NEW_VISITOR]))

        d = delta.Delta('NOTIFICATION', delta.Delta.Event.ADD, notification.session_id, notification)
        self.__add_delta(d)

        if self.account.name in ['novoeecotonspbru', 'ecotonspbru'] and notification.kind == Notification.Kind.NEW_VISITOR:
            return

        if not push_data:
            push_data = {'sound': 'default'}

        push_data['event'] = 'add'
        push_data['kind'] = notification.kind
        push_data['session_id'] = notification.session_id
        push_data['ts'] = notification.ts

        if notification.kind in [Notification.Kind.VISITOR_FILE, Notification.Kind.VISITOR_CONTACTS]:  # TODO: remove after mobile update
            return

        self.account.push_manager.push_notification(push_data, self.online_operator.operator_id)

    def __remove_notification(self, session_id, kinds=None):
        if session_id in self.session_id_to_notification:
            if kinds and self.session_id_to_notification[session_id].kind not in kinds:
                return

            notification = self.session_id_to_notification.pop(session_id)
            d = delta.Delta('NOTIFICATION', delta.Delta.Event.DELETE, session_id, None)
            self.__add_delta(d)
            push_data = {
                'event': 'del',
                'session_id': notification.session_id,
                'sound': None
            }
            self.account.push_manager.push_notification(push_data, self.online_operator.operator_id)

    def __add_delta(self, d):
        self.online_operator.delta_manager.add_delta(d)


class PushManager:

    def __init__(self, account):
        self.account = account

    # send notification methods

    def send_operator_disconnected_notification(self, device):
        push_data = {
            'event': 'add',
            'loc-key': 'P.OFF',
            'sound': 'm.aiff',
            'ts': time.time(),
        }
        self.push_notification(push_data, device=device)

    def send_visitor_accepted_notification(self, session):
        operator = session.chat.get_operator()
        city = _format_city(session.ip_info.get_city(session.lang))
        push_data = {
            'event': 'add',
            'loc-key': 'P.AV',
            'params': ['', u' ' + session.visitor.get_name(), city, operator.fullname],
            'sound': 'm.aiff',
            'session_id': session.id,
            'ts': time.time(),
        }
        self.push_notification(push_data, skip_operator_id=operator.id, ios_cutting_rules={0: 0, 1: 15, 2: 22, 3: -1})

    def send_visitor_left_notification(self, session):
        city = _format_city(session.ip_info.get_city(session.lang))
        push_data = {
            'event': 'add',
            'loc-key': 'P.MV',
            'params': ['', u' ' + session.visitor.get_name(), city],
            'sound': 'm.aiff',
            'session_id': session.id,
            'ts': time.time(),
        }
        self.push_notification(push_data)

    def send_visitor_fields_changed_notification(self, session, fields):
        push_data = {
            'event': 'add',
            'params': fields,
            'session_id': session.id,
            'ts': time.time(),
            'kind': Notification.Kind.VISITOR_FIELDS_CHANGED
        }
        self.push_notification(push_data, platforms=['inf'])

    def send_for_operator_message_notification(self, message, chat):
        push_data = {
            'event': 'add',
            'params': [message.text],
            'session_id': chat.session.id,
            'ts': message.ts,
            'kind': Notification.Kind.FOR_OPERATOR_MESSAGE
        }

        if message.aux:
            push_data['aux'] = message.aux

        if message.data:
            push_data['data'] = message.data

        self.push_notification(push_data, operator_id=chat.get_operator_id(), platforms=['inf'])

    def send_form_response_message_notification(self, message, chat):
        push_data = {
            'event': 'add',
            'params': [message.text, message.data],
            'session_id': chat.session.id,
            'ts': message.ts,
            'kind': Notification.Kind.FORM_RESPONSE
        }

        if message.aux:
            push_data['aux'] = message.aux

        if message.data:
            push_data['data'] = message.data

        self.push_notification(push_data, operator_id=chat.get_operator_id(), platforms=['inf'])

    def push_notification(self, push_data, operator_id=None, skip_operator_id=None, device=None, platforms=None, ios_cutting_rules=None):
        target = lambda: self.__do_push_notification(push_data, operator_id, skip_operator_id, device, platforms, ios_cutting_rules=ios_cutting_rules)
        logging.warn(' ##### before invoke_async ' + str(push_data))
        wm_timer.invoke_async(target, 'push_notification', order_importance_key=push_data.get('session_id'))

    def __do_push_notification(self, push_data, operator_id, skip_operator_id, device, platforms, ios_cutting_rules):
        if device:
            self.__push_notification_to_operator(push_data, device.online_operator, device=device, platforms=platforms, ios_cutting_rules=ios_cutting_rules)
        elif operator_id:
            self.__push_notification_to_operator(push_data, self.account.oo_manager.get(operator_id), platforms=platforms, ios_cutting_rules=ios_cutting_rules)
        else:
            for online_operator in self.account.oo_manager.get_alive_online_operators():
                if online_operator.operator_id != skip_operator_id:
                    # filter by lang and dep
                    self.__push_notification_to_operator(push_data, online_operator, platforms=platforms, ios_cutting_rules=ios_cutting_rules)

    def __get_notification_manager(self, platform):
        return \
            IosPushNotificationManager.instance(self.account) if platform == 'ios' else \
            GCMPushManager(self.account.get_android_api_key('gcm')) if platform == 'android' else \
            IosPushNotificationManager.instance(self.account, platform='ios_flipcat') if platform == 'ios_flipcat' else \
            InfPushNotificationManager.instance(self.account) if platform == 'inf' else \
            None

    def __push_notification_to_operator(self, push_data, online_operator, device=None, platforms=None, ios_cutting_rules=None):
        mail_notification = False
        push_data['badge'] = len(online_operator.notification_manager.get_notifications())
        platform_to_nm = wm_utils.DictExt(lambda platform: self.__get_notification_manager(platform))
        devices = [device] if device else online_operator.get_online_devices()
        for d in devices:
            try:
                if d.push_token != '0000' and (not platforms or d.platform in platforms):
                    nm = platform_to_nm.get(d.platform)
                    if d.platform == 'android':
                        nm.send(d.push_token, push_data)
                    elif d.platform == 'ios':
                        nm.send(d.push_token, push_data, cutting_rules=ios_cutting_rules)
                    elif d.platform == 'ios_flipcat':
                        nm.send(d.push_token, push_data)
                    elif d.platform == 'inf':
                        nm.send(d, push_data)

                    if d.notify_by_email and push_data['event'] == 'add':
                        mail_notification = True
                    if d.phone_for_sms_notification and push_data['event'] == 'add':
                        self.send_sms_notification(d.phone_for_sms_notification, push_data)
            except Exception:
                logging.error("Error while trying to send push notification", exc_info=True)

        if mail_notification:
            lang = online_operator.get_operator().get_backend_locale()
            text = Notification.get_formatted_notification_text(self.account, lang, push_data)
            params = {'notification_text': text,
                      'subject': wm_utils.cut_string(text, 50),
                      'session_id': push_data['session_id']}
            wm_mail.mailer.send_notification_email(online_operator, params, lang)

    def send_sms_notification(self, phone_number, push_data):
        logging.warn("Sending SMS to %s, push_data: %s" % (str(phone_number), push_data))
        url = 'http://{0}.{1}/webim/operator/tracker.php#{2}'.format(*[self.account.name, wm_settings.settings['base_domain'], push_data['session_id']])

        sms = nexmo.Client(key=wm_settings.settings['nexmo_key'], secret=wm_settings.settings['nexmo_secret'])
        response = sms.send_message({'from': wm_settings.settings['nexmo_from'], 'to': '+' + str(phone_number), 'text': url})
        logging.warn("Response to sms for %s: %s" % (str(phone_number), response))


class BaseAndroidPushManager(object):
    def __init__(self, api_key):
        self._api_key = api_key
        self._adapter = None

    @property
    def adapter(self):
        """
        :return: Android Push Service Adapter (GCM or FCM)
        """
        raise NotImplementedError()

    def _prepare_payload(self, push_token, prepared_data):
        """
        :return: Adapter-specific push payload
        """
        raise NotImplementedError()

    def _send(self, payload):
        """
            Adapter "send"-method wrapper
        """
        raise NotImplementedError()

    def _prepare_data(self, push_data):
        if push_data['event'] == 'del':
            return {
                'event': 'del',
                'id_of_session': push_data['session_id'],
                'number_of_notifications': push_data['badge']
            }
        elif push_data['event'] == 'add':

            if 'loc-key' not in push_data:
                return None

            result = {
                'event': 'add',
                'type': push_data['loc-key'],
                'number_of_notifications': push_data['badge']
            }

            if 'session_id' in push_data:
                result['id_of_session'] = push_data['session_id']

            param_names = {
                0: "first_param",
                1: "second_param",
                2: "third_param",
                3: "fourth_param"
            }
            for i, val in enumerate(push_data.get('params', [])):
                result[param_names[i]] = val

            return result
        return None

    def send(self, push_token, push_data):
        if not self.adapter:
            return

        logging.warn('Sending message to android: %s' % push_token)
        data = self._prepare_data(push_data)
        if not data:
            return

        logging.warn('message: %s' % str(data))
        payload = self._prepare_payload(push_token, data)

        try:
            self._send(payload)
        except ValueError as e:
            logging.error('', exc_info=True)
        except Exception as e:
            logging.error('Something wrong: %s' % e.message, exc_info=True)


class BaseVisitorAndroidPushManager(BaseAndroidPushManager):

    def _prepare_data(self, push_data):
        if push_data['event'] == 'del':
            return {'data': {'event': 'del'}}
        elif push_data['event'] == 'add':

            if 'loc-key' not in push_data:
                return None

            result = {
                'data': {
                    'event': 'add',
                    'type': push_data['loc-key'],
                    'params': push_data['params']
                }
            }

            if push_data.get('offline') and 'chatId' in push_data:
                result['data']['chat_id'] = push_data['chatId']

            # todo rename message_push_data -> message
            if push_data.get('message_push_data'):
                result['data']['message'] = push_data.get('message_push_data')

            return result
        return None


class GCMPushManager(BaseAndroidPushManager):
    """
    Android Push Notification Manager for GCM push-service.
    """

    @property
    def adapter(self):
        if not self._adapter and self._api_key:
            self._adapter = gcmclient.GCM(self._api_key)

        return self._adapter

    def _prepare_payload(self, push_token, prepared_data):
        return gcmclient.JSONMessage([push_token], prepared_data,
                                     delay_while_idle=False,
                                     collapse_key=prepared_data.get('id_of_session'),
                                     time_to_live=60 * 60)

    def _send(self, payload):
        self.adapter.send(payload)


class FCMPushManager(BaseAndroidPushManager):
    """
    Android Push Notification Manager for FCM push-service.
    """

    @property
    def adapter(self):
        if not self._adapter and self._api_key:
            self._adapter = pyfcm.FCMNotification(api_key=self._api_key)

        return self._adapter

    def _prepare_payload(self, push_token, prepared_data):
        return {
            "push_token": push_token,
            "data": prepared_data['data'] if prepared_data.get('data') else prepared_data
        }

    def _send(self, payload):
        self.adapter.notify_single_device(registration_id=payload['push_token'], data_message=payload['data'])


class GCMVisitorPushManager(BaseVisitorAndroidPushManager, GCMPushManager): pass
class FCMVisitorPushManager(BaseVisitorAndroidPushManager, FCMPushManager): pass


class IosPushNotificationManager:

    __instance = None

    __DEFAULT_CUTTING_RULES = {
        0: -1,  # message
        1: 15,  # name
        2: 22   # city
    }

    @classmethod
    def instance(cls, account, platform='ios'):
        # if not cls.__instance:
        #     cls.__instance = IosNotificationManager()
        return IosPushNotificationManager(account, platform=platform)

    def __init__(self, account, certs_dir='/etc/webim/ios-certs', platform=None):
        self.account = account
        self.certs_dir = certs_dir
        if platform:
            self.certs_dir = os.path.join(certs_dir, platform)
        self.__do_init()

    def __do_init(self):

        self.__apns_dist = APNs(use_sandbox=False,
                                cert_file=os.path.join(self.certs_dir, 'ios_push_cert.dist.pem'),
                                key_file=os.path.join(self.certs_dir, 'ios_push_private_key.dist.pem'))
        self.__apns_dev = APNs(use_sandbox=True,
                               cert_file=os.path.join(self.certs_dir, 'ios_push_cert.dev.pem'),
                               key_file=os.path.join(self.certs_dir, 'ios_push_private_key.dev.pem'))

    def send(self, token_hex, push_data, cutting_rules=None):
        message = self.__prepare_message(push_data, cutting_rules)
        if not message:
            return
        logging.warn(u'apns push @' + self.account.name + ': ' + token_hex + u' ' + unicode(message) + u' ' + str(message['badge']))

        payload = Payload(alert=message['alert'], sound=message['sound'], badge=message['badge'], custom=message['custom'])

        try:
            self.__try_send(payload, token_hex)
        except Exception:
            logging.error('Error while trying to send ios push notification @' + self.account.name + ' (1st attempt)', exc_info=True)
            self.__do_init()
            try:
                self.__try_send(payload, token_hex)
            except Exception:
                logging.error('Error while trying to send ios push notification @' + self.account.name + ' (2nd attempt)', exc_info=True)

    def __try_send(self, payload, token_hex):
        logging.warning('sending push @' + self.account.name + ' begin %s', token_hex)
        start_ts = time.time()
        if self.account.get_setting('send_dist_ios_pushes'):
            logging.warning('sending dist push @' + self.account.name + ' %s', token_hex)
            self.__apns_dist.gateway_server.send_notification(token_hex, payload)
        if self.account.get_setting('send_dev_ios_pushes'):
            logging.warning('sending dev push @' + self.account.name + ' %s', token_hex)
            self.__apns_dev.gateway_server.send_notification(token_hex, payload)
        logging.warning('sending push @' + self.account.name + ' end %s duration: %d sec', token_hex, time.time() - start_ts)

    def __prepare_message(self, push_data, cutting_rules):
        if push_data.get('event') == 'add':
            alert = {'loc-key': push_data['loc-key']}
            if 'params' in push_data:
                alert['loc-args'] = push_data['params']
        else:
            # на удаление нотификаций ничего не шлем, чтобы избегать кейса, когда посетитель ушел с сайта, а от него остался только пуш
            # про то, что ушел, а пушей с сообщениями нет.
            # Обсуждали и пришли к мысли, что такие чаты должны конвертироваться в "пропущенные" (которы ведут себя аналогично оффлайновым), тогда
            # можно будет корректно разруливать этот кейс
            # а пока решили просто не удалять пуши
            # Тут еще тонкий момент в том, что удаление отдельных пушей для иос нет, чистятся все пуши, когда badge = 0
            # поэтому полностью корректную работу сделать невозможно
            return None
            # alert = ''

        custom = self._prepare_message_custom_part(push_data)

        message = {'alert': alert, 'custom': custom, 'sound': push_data.get('sound', 'default'), 'badge': push_data.get('badge', 0)}

        json_message = json.dumps(message, separators=(',', ':'), ensure_ascii=False).encode('utf-8')
        if len(json_message) > 256:
            self.__cut_message(message, cutting_rules)

        return message

    def _prepare_message_custom_part(self, push_data):
        result = {}
        for key in ['session_id', 'ts']:
            if key in push_data:
                result[key] = push_data[key]

        return result

    def __cut_message(self, message, cutting_rules):
        cutting_rules = cutting_rules or self.__DEFAULT_CUTTING_RULES
        loc_args = message['alert']['loc-args']

        if not loc_args:
            return

        cut_as_much_as_need_idx = None
        for idx, max_len in cutting_rules.items():
            if max_len == -1:
                cut_as_much_as_need_idx = idx
            else:
                loc_args[idx] = wm_utils.cut_string(loc_args[idx], max_len)

        if cut_as_much_as_need_idx is None:
            return

        length = self.__calc_len(message)
        if length <= 256:
            return

        new_text_len = self.__calc_len(loc_args[cut_as_much_as_need_idx]) - 2 - (length - 256)
        if new_text_len < 0:
            loc_args[cut_as_much_as_need_idx] = ""
            return

        loc_args[cut_as_much_as_need_idx] = wm_utils.cut_string(loc_args[cut_as_much_as_need_idx], new_text_len)

        while self.__calc_len(message) > 256 and new_text_len > 0:
            new_text_len -= 1
            loc_args[cut_as_much_as_need_idx] = wm_utils.cut_string(loc_args[cut_as_much_as_need_idx], new_text_len)

    def __calc_len(self, message):
        json_message = json.dumps(message, separators=(',', ':'), ensure_ascii=False).encode('utf-8')
        return len(json_message)


class IosVisitorPushNotificationManager(IosPushNotificationManager):

    @classmethod
    def instance(cls, account, certs_last_dir=None):
        return IosVisitorPushNotificationManager(account, certs_last_dir)

    def __init__(self, account, certs_last_dir):
        certs_dir = os.path.join(wm_settings.settings['client-data-dir'], account.name, 'ios-certs',
                                 certs_last_dir or 'client')
        IosPushNotificationManager.__init__(self, account, certs_dir)

    def _prepare_message_custom_part(self, push_data):
        result = {'webim': 1}
        if push_data.get('offline') and 'chatId' in push_data:
            result['chat_id'] = push_data['chatId']

        return result


class WindowsVisitorPushNotificationManager:

    __account_to_instance = {}
    __get_instance_lock = Lock()

    @classmethod
    def instance(cls, account):
        with cls.__get_instance_lock:
            instance = cls.__account_to_instance.get(account)
            if not instance:
                instance = WindowsVisitorPushNotificationManager(account)
                cls.__account_to_instance[account] = instance

        return instance

    def __init__(self, account):
        self.account = account

        self.__update_token_lock = Lock()

        logging.warn('WindowsVisitorPushNotificationManager %s: init' % self.account.name)

        self.access_token = None
        self.get_access_token()

    def get_access_token(self):
        with self.__update_token_lock:
            if self.account.get_setting('windows_phone_notification_settings') and not self.access_token:
                logging.warn('WindowsVisitorPushNotificationManager %s: get_access_token started' % self.account.name)
                settings = self.account.get_setting('windows_phone_notification_settings')

                response = requests.post(
                    'https://login.live.com/accesstoken.srf',
                    {'grant_type': 'client_credentials',
                     'client_id': settings['client_id'],
                     'client_secret': settings['client_secret'],
                     'scope': 'notify.windows.com'}
                )

                logging.warn('WindowsVisitorPushNotificationManager %s: get_access_token finished' % self.account.name)
                self.access_token = response.json().get('access_token')

        return self.access_token

    def reset_access_token(self, token):
        with self.__update_token_lock:
            if self.access_token == token:
                self.access_token = None

    def make_request(self, push_token, n_type, payload):
        token = self.get_access_token()

        headers = {
            'Authorization': 'Bearer %s' % token,
            'X-WNS-Type': 'wns/%s' % n_type,
            'Content-Type': 'text/xml' if n_type != 'raw' else 'application/octet-stream',
            'Content-Length': len(payload),
            'X-WNS-RequestForStatus': 'true'
        }

        r = requests.post(push_token, data=payload, headers=headers)

        if r.status_code != 200:
            logging.error('WindowsVisitorPushNotificationManager error %d: %s, %s' % (r.status_code, self.account.name, str(r.headers)))

            if r.status_code in [401, 403]:
                self.reset_access_token(token)
                self.make_request(push_token, n_type, payload)
            else:
                r.raise_for_status()

    def prepare_toast_notification_payload(self, text):
        # Thank you, Microsoft!
        result = '''
        <toast launch="webim">
            <visual>
                <binding template="ToastText01">
                    <text id="1">%s</text>
                </binding>
            </visual>
        </toast>
        ''' % text
        return result

    def send(self, push_token, push_data):
        if not self.account.get_setting('windows_phone_notification_settings'):
            return

        logging.warn('WindowsVisitorPushNotificationManager %s: send %s %s' % (self.account.name, push_token, push_data))

        text = wm_resources.get_resource(self.account, 'ru', 'notification.%s' % push_data['loc-key'], *push_data['params'])
        payload = self.prepare_toast_notification_payload(text).encode('utf-8')

        # logging.warn('WindowsVisitorPushNotificationManager %s: send %s payload %s' % (self.account.name, push_token, payload))

        self.make_request(push_token, 'toast', payload)


class PochtaVisitorPushNotificationManager:

    @classmethod
    def instance(cls, account):
        return PochtaVisitorPushNotificationManager(account)

    def __init__(self, account):
        self.url = account.get_setting('pochta_push_url')

    def send(self, push_token, push_data):

        if push_data['loc-key'] == 'P.OM':
            text = push_data['params'][1]
        elif push_data['loc-key'] == 'P.OF':
            text = wm_resources.get_resource(None, 'ru', 'notification.pochta.attached_image')
        else:
            return

        logging.warn(u"pochta push: " + str(push_token))

        try:
            dt = datetime.datetime.fromtimestamp(time.time(), dateutil.tz.tzlocal()).replace(microsecond=0)
            params = {
                'messageText': text.encode('utf8'),
                'messageDateTime': dt.isoformat(),
                'messageChatId': str(push_data['chatId'])
            }
            url = self.url
            post_data = urllib.urlencode(params)
            logging.warn(u"pochta push: " + push_token + u" " + url + u" " + post_data)

            headers = {'MobileApiAccessToken': push_token, 'User-Agent': 'Webim'}

            req = urllib2.Request(url, headers=headers)
            req.add_data(post_data)
            response = urllib2.urlopen(req, timeout=5).read()
            logging.warn(u"pochta push: " + str(push_token) + " response: " + response)
        except Exception:
            logging.error("Error while trying to send pochta push notification. push_token=" + str(push_token), exc_info=True)


class InfPushNotificationManager:

    __instance = None

    @classmethod
    def instance(cls, account):
        return InfPushNotificationManager(account)

    def __init__(self, account):
        self.account = account
        self.url = account.get_setting('inf_push_url') or "http://biz-debug.nanosemantics.ru/webim/notify.php"

    def send(self, device, push_data):
        data = self.__prepare_data(push_data)
        if not data:
            return

        session = self.account.visit_tracker.get_session(data['sessionId'])
        with session.lock_for_inf_notification:
            random_id = random.randint(1, 10000000000)

            data = {
                "deviceId": device.device_id,
                "pushToken": device.push_token,
                "notification": data
            }

            logging.warn('%d Sending message to inf. account: %s, message: %s, url: %s' % (random_id, self.account.name, str(data), self.url))
            try:
                result = wm_utils.external_request(self.url, post_data=json.dumps(data))
                logging.warn('%d inf result: %s' % (random_id, str(result)))
            except Exception as e:
                logging.error('%d Something wrong: %s' % (random_id, e.message), exc_info=True)

    def __prepare_data(self, push_data):
        if 'kind' not in push_data:
            return None

        result = {
            'event': push_data['event'],
            'kind': push_data['kind'],
            'sessionId': push_data['session_id'],
            'params': push_data['params']
        }

        if 'aux' in push_data:
            result['aux'] = push_data['aux']

        if 'data' in push_data:
            result['data'] = push_data['data']

        return result


def _format_city(city):
    return u' (' + city + u')' if city else ''