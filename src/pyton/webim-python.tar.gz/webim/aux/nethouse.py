from datetime import datetime

from .. import db_utils
from .. import wm_web

class CompareNethouseReportRequestHandler(wm_web.AdminRequestHandler):

    def get(self, *args, **kwargs):
        today = datetime.today()
        year = today.year
        quarter = int(today.month / 3)

        if quarter == 0:
            quarter = 4
            year -= 1

        self.finish('<html><body>'
                    '<form method="post">'
                    'Nethouse report<br/>'
                    '<textarea name="nethouse_report"/></textarea><br/>'
                    'year:<input type="text" name="year" value="{year}"><br/>'
                    'quarter:<input type="text" name="quarter" value="{quarter}"><br/>'
                    '<input type="submit" value="Submit">'
                    '</form></body></html>'.format(year=year, quarter=quarter))

    def post(self, *args, **kwargs):
        year = self.get_int_argument('year')
        quarter = self.get_int_argument('quarter')

        nhr = self.load_nethouse_report(self.get_argument('nethouse_report'))
        wmr = self.load_webim_report(year, quarter)

        self.write('hethouse records: ' + str(len(nhr)) + '<br/>')
        self.write('webim records: ' + str(len(wmr)) + '<br/>')

        nh_not_matching = []
        for nh_record in nhr:
            for wm_record in wmr:
                if self.matches(nh_record, wm_record):
                    wmr.remove(wm_record)
                    break
            else:
                nh_not_matching.append(nh_record)

        self.write('<br/><b>nethouse:</b>' + '<br/>')
        for r in nh_not_matching:
            self.write(r['accountname'] + '\t' + str(r['price']) + '\t' + str(r['date']) + '<br/>')
        self.write('<br/><b>webim:</b>' + '<br/>')
        for r in wmr:
            self.write(r['accountname'] + '\t' + str(r['price']) + '\t' + str(r['dtmcreated'].date()) + '<br/>')

    def load_webim_report(self, year, quarter):
        global c, webim_report_rows
        c = db_utils.get_connection()
        webim_report_rows = c.query(
            "select  os.id, os.accountname, os.dtmcreated, os.dtmfrom, os.dtmto, os.description, os.price" +
            " from orderedservice os join account a on os.accountname = a.accountname" +
            " where os.status = 'payed' and a.partner = 'nethouseru' and a.for_test = 0 and os.paymentmethod = 'partner'" +
            " and os.dtmcreated >= date('" + self.__get_date_str(year, quarter, False) + "') and os.dtmcreated < date('" + self.__get_date_str(year, quarter, True) + "')")
        c.close()

        return webim_report_rows

    @staticmethod
    def __get_date_str(year, quarter, till_not_from):
        month = 3 * quarter + 1 if till_not_from else 3 * (quarter - 1) + 1
        if month > 12:
            year = year + 1
            month = month - 12

        return str(year) + ('-%02d' % month) + '-01'

    @staticmethod
    def load_nethouse_report(raw_report):
        result = []

        for line in raw_report.split('\n'):
            if not line.strip():
                continue
            pieces = line.split('\t')
            # date_format = "%d.%m.%y"
            date_format = "%Y-%m-%d"
            result.append({'date': datetime.strptime(pieces[0], date_format).date(), 'accountname': pieces[1], 'price': long(pieces[2])})
        return result

    @staticmethod
    def matches(nh_record, wm_record):
        if nh_record['accountname'] == wm_record['accountname']:
            if nh_record['price'] == wm_record['price']:
                if nh_record['date'] == wm_record['dtmcreated'].date():
                    return True
        return False

