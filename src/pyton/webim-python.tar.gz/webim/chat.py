# coding=UTF-8

import json
import time
import uuid
import re
import copy
import logging
import datetime
import urllib
import hashlib
import threading

import delta
import wm_settings
import visitor_tracking
import wm_resources
import wm_mail
import wm_operator
import wm_timer
import wm_utils
import db_utils
import wm_callbacks
import wm_notification
from zendesk import Zendesk, ZendeskException
from wm_cobrowsing import CobrowsingSession
from wm_events import Event, ChatEventDispatcher, MessageEventConsumer


__author__ = 'mixey'


class Chat(wm_utils.KeepRefs, wm_utils.Jsonable):

    class State:
        ROUTING = 'routing'
        QUEUE = 'queue'
        CHATTING = 'chatting'
        CHATTING_WITH_ROBOT = 'chatting_with_robot'
        CLOSED = 'closed'
        CLOSED_BY_VISITOR = 'closed_by_visitor'
        CLOSED_BY_OPERATOR = 'closed_by_operator'
        OFFLINE_QUEUE = 'offline_queue'
        OFFLINE_PROCESS = 'offline_process'
        INVITATION = 'invitation'
        DELETED = 'deleted'

    def __init__(self):
        super(Chat, self).__init__()

        self.id = None
        self.client_side_id = None
        self.session = None
        self.messages = []
        self.state = None
        self.__operator_id = None
        self.creation_ts = None
        self.modification_ts = None
        self.last_activity_ts = None
        self.inserted_ts = None

        self.operator_busy_message_posted = False

        self.offline = False

        self.operators_in_chat = set()
        self.manually_assigned_operator_id = None

        self.__last_message_id = 0
        self.__last_history_record_number = 0

        self.visitor_typing = False
        self.visitor_message_draft = None
        self.unread_by_visitor_since_ts = None  # None means read
        self.unread_by_visitor_msg_cnt = None
        self.operator_typing = False
        self.unread_by_operator_since_ts = None  # None means read

        self.last_operator_assigned_ts = None
        self.state_modified_ts = None

        self.redirected = False  # True means that chat was redirected from one operator to another and second operator haven't seen it yet

        self.operator_id_to_operator_rate = {}
        self.subject = None
        self.category = None
        self.subcategory = None
        self.requested_form = None
        self.start_page = None
        self.stored_to_db_callbacks = wm_callbacks.Callbacks(once=True, memory=True)
        self.amocrm_id = None
        self.zohocrm_contact_id = None

        self.__process_event_lock = threading.Lock()

        self.chat_thread_local = threading.local()
        self.chat_thread_local.processing_event_flag = False

        self.external_data = {}  # only for internal use
        self.__flags = set()
        self.operator_hints = None

        self.need_to_be_closed = False

        self.event_dispatcher = ChatEventDispatcher(self)

    @classmethod
    def create(cls, session, current_page, offline=False, state=State.QUEUE, operator_id=None, custom_fields=None, subject=None, client_side_id=None):
        result = Chat()

        result.client_side_id = client_side_id or uuid.uuid4().hex
        result.session = session
        result.state = state

        result.__operator_id = operator_id
        result.creation_ts = time.time()
        result.modification_ts = time.time()
        result.last_activity_ts = time.time()

        result.subject = subject

        result.offline = offline

        result.start_page = current_page

        if operator_id:
            result.operators_in_chat.add(operator_id)

        result.session.store(only_if_stored_before=False)
        result.store()

        result.post_chat_history_record()

        if not offline:

            if state == Chat.State.INVITATION:
                session.inc_session_chats_count('current_invitations_count')
            else:
                text = result.session.visitor.get_formatted_fields(session)
                if (session.account.name == 'prologyru' or session.account.name == 'mixey') and custom_fields:
                    text += result.get_resource('chat.message.device_model', **{'nl': '\n' if text else '', 'device': custom_fields.get('device_model', '')})
                if session.landing_page.referer:
                    text += result.get_resource('chat.message.come_from', **{'nl': '\n' if text else '', 'referer': session.landing_page.referer})
                    ChatChecker.check_chat_string(session.landing_page.referer, result)
                msg = result.get_visitor_info_text(
                    {
                        'nl': '\n',
                        'title': current_page.title,
                        'url': current_page.url,
                        'geo': session.ip_info.get_location_str(session.lang, session.get_resource('chat.message.visitor_info.geo_format')),
                        'browser': session.get_browser_str(),
                        'ip': session.ip,
                        'text': text
                    }
                )
                Message.create(result, Message.Kind.FOR_OPERATOR, None, msg, None, False, data={'subKind': 'chat-info-message'})

                if session.account.get_setting('show_chat_department_info_messages'):
                    department = session.account.get_department(session.department_key).get_name()
                    Message.create_from_resource(result, Message.Kind.FOR_OPERATOR, None, 'chat.message.chat_start_in_department_info', None, *[department])

                hello_text = session.account.get_localized_setting('agent_hello_text', session.lang, department_key=session.department_key)
                if hello_text:
                    Message.create(result, Message.Kind.INFO, None, hello_text, None, False,
                                   data={'subKind': 'hello-message'})

                online_inf = session.account.oo_manager.get_online_inf()

                if online_inf and online_inf.get_operator() and online_inf.get_operator().matches((session.lang, session.department_key)):
                    result.process_event('inf.auto_accept', {'operator_id': online_inf.operator_id}, produce_delta=False)
                elif result.try_assign_to_robot(produce_delta=False):
                    pass
                else:
                    if session.account.router and state == Chat.State.QUEUE:
                        dep = session.account.get_department(session.department_key)
                        if dep and dep.settings.get('routing', False):
                            result.state = Chat.State.ROUTING

                    if result.state != Chat.State.ROUTING and not operator_id:
                        if session.account.get_setting('auto_assign'):
                            result.__flags.add('post_welcome_message_after_auto_assign_attempt')
                        else:
                            if not session.account.get_setting('avoid_standard_welcome_message'):
                                Message.create_from_resource(result, Message.Kind.INFO, None, 'chat.message.wait', False)

        result.stored_to_db_callbacks.add(lambda: result.send_history_to_external_handler('chat_started_handler_url'))

        result.session.account.queue_manager.update_chat_in_queue(result, post_place_in_queue_message=True)

        if result.session.visitor.previous_chat_tag is True and session.account.get_setting('previous_chats_label_time_interval'):
            wm_timer.invoke_async(lambda: result.session.visitor.check_last_visitor_chat_created_ts(), timer_name='visitor_last_chat async get')

        return result

    @classmethod
    def create_simple(cls, session, start_page, state, operator_id):
        result = Chat()
        result.client_side_id = uuid.uuid4().hex
        result.session = session

        result.state = state

        result.__operator_id = operator_id
        result.creation_ts = time.time()
        result.modification_ts = time.time()
        result.last_activity_ts = time.time()
        result.offline = False

        result.start_page = start_page

        if operator_id:
            result.operators_in_chat.add(operator_id)

        result.session.store(only_if_stored_before=False)
        result.store()

        result.post_chat_history_record()

        return result

    def get_visitor_info_text(self, params):
        visitor_info = []
        info_keys = ['title', 'geo', 'browser', 'ip', 'text']
        for key in info_keys:
            if key in params and params[key]:
                if key == 'title' and ('url' not in params or not params['url']):
                    continue
                res = self.get_resource('chat.message.visitor_info.%s' % key, **params)
                visitor_info.append(res)
        return '\n'.join(visitor_info)

    @classmethod
    def create_loaded(cls, session, chat_row, last_history_row, message_rows, chat_operators_ids, operator_rate_rows):
        result = Chat()
        result.stored_to_db_callbacks.fire()

        result.session = session

        result.id = chat_row['threadid']
        result.category = chat_row['category']
        result.subcategory = chat_row['subcategory']

        result.manually_assigned_operator_id = chat_row['manuallyassignedoperatorid']
        result.operators_in_chat = chat_operators_ids

        result.state = last_history_row['state']
        result.__operator_id = last_history_row['operatorid']
        result.creation_ts = (chat_row['createdts'] or 0) / 1e6 or wm_utils.get_ts(chat_row['created'])
        result.modification_ts = int(last_history_row['dtm'].strftime('%s'))
        result.last_activity_ts = int(last_history_row['dtm'].strftime('%s'))
        result.inserted_ts = (chat_row['insertedts'] or 0) / 1e6 or wm_utils.get_ts(chat_row['created'])
        result.offline = bool(chat_row['offline'])
        chat_json = chat_row['json']
        if chat_json:
            try:
                chat_dict = json.loads(chat_json)
                result.client_side_id = chat_dict.get('clientSideId')
                if chat_dict.get('startPage'):
                    result.start_page = visitor_tracking.VisitedPage.create_from_dict(session.account, chat_dict['startPage'])
                    result.start_page.set_visit_session(result.session)
                result.requested_form = chat_dict.get('requestedForm')
                result.subject = chat_dict.get('subject')
                result.amocrm_id = chat_dict.get('amocrmId')
                result.zohocrm_contact_id = chat_dict.get('zohocrmId')
                result.external_data['json_robot_current_state'] = chat_dict.get('json_robot_current_state')
            except Exception:
                pass

        result.messages = []
        for mr in message_rows:
            message = Message.create_loaded(result, mr)
            result.messages.append(message)
            if message.kind == Message.Kind.ACTION_REQUEST:
                result.event_dispatcher.add_consumer(message.event_consumer)
            elif message.kind in Message.Kind.VISITOR_KINDS:
                result.unread_by_visitor_since_ts = None
                result.unread_by_operator_since_ts = message.ts
                result.last_activity_ts = max(result.last_activity_ts, message.ts)
            elif message.kind in Message.Kind.OPERATOR_KINDS:
                if not result.unread_by_visitor_since_ts:
                    result.unread_by_visitor_since_ts = message.ts
                result.unread_by_operator_since_ts = None
                result.last_activity_ts = max(result.last_activity_ts, message.ts)
            elif message.kind == Message.Kind.OPERATOR_BUSY:
                result.operator_busy_message_posted = True
                result.last_activity_ts = max(result.last_activity_ts, message.ts)

        result.unread_by_visitor_msg_cnt = result.calc_unread_by_visitor_msg_count()
        result.__last_history_record_number = last_history_row['number']

        if operator_rate_rows:
            for rate_row in operator_rate_rows:
                operator_rate = OperatorRate.create_loaded(rate_row)
                result.operator_id_to_operator_rate[operator_rate.operator_id] = operator_rate

        return result

    def set_id(self, value):
        if self.id == value:
            return
        self.id = value
        if self.session.chat:
            d = delta.Delta('CHAT_ID', delta.Delta.Event.UPDATE, self.session.id, value)
            self.session.add_operator_delta(d)

        self.session.account.event_dispatcher.fire(Event(e_type=Event.Type.CHAT_STORED_TO_DB, e_object=self))

    def on_set_to_session(self):
        self.session.account.queue_manager.update_chat_in_queue(self)
        if self.session.account.router and self.state == Chat.State.ROUTING:
            self.stored_to_db_callbacks.add(lambda: self.session.account.router.route_chat(self))

        if self.session.account.get_setting('auto_assign') and (self.state == Chat.State.QUEUE or self.state == Chat.State.OFFLINE_QUEUE) \
                and self.__operator_id is None:
            auto_assign_controller = self.session.account.get_auto_assign_controller(self.offline)
            auto_assign_controller.set_auto_assign_required()

            if 'post_welcome_message_after_auto_assign_attempt' in self.__flags:
                self.__flags.remove('post_welcome_message_after_auto_assign_attempt')

                def callback():
                    if self.state == Chat.State.QUEUE:
                        if self.__operator_id:
                            if not self.session.account.get_setting('avoid_standard_welcome_message'):
                                Message.create_from_resource(self, Message.Kind.INFO, None, 'chat.message.wait', True)
                        else:
                            Message.create_from_resource(self, Message.Kind.INFO, None, 'chat.message.all_operators_busy', True)

                auto_assign_controller.add_next_run_callback(callback)

    def owned_by_session(self):
        return self.session.chat == self

    @staticmethod
    def __contains_one_of(str, subs):
        return bool([1 for s in subs if s in str])

    def try_auto_close(self, produce_delta=True):
        if self.state in [Chat.State.CLOSED, Chat.State.DELETED]:
            return False

        if not self.offline:
            return False

        if self.session.account.name in ['testrussianpostru', 'russianpostru', 'webimru106', 'mixey']:
            messages = [m for m in self.messages if m.kind in Message.Kind.VISITOR_KINDS]
            if len(messages) == 1:
                if self.session.department_key in ['netochnie_dannie_ops']:

                    Message.create(
                        self, Message.Kind.OPERATOR, '',
                        u'Спасибо за предоставленную информацию! После проверки указанных вами данных мы внесем необходимые изменения.',
                        produce_delta=produce_delta, store_in_background=False
                    )

                    logging.warn('autoclosing chat netochnie_dannie_ops ' + str(self.id))
                    self.process_event('sys.auto_close', produce_delta=produce_delta)
                    return True
                if self.session.department_key in ['otzivi_o_rabote_ops']:
                    m = messages[0]
                    if not self.__contains_one_of(m.text, ['1 / 5', '2 / 5', '1/5', '2/5']):
                        logging.warn('autoclosing chat otzivi_o_rabote_ops ' + str(self.id))
                        self.process_event('sys.auto_close', produce_delta=produce_delta)
                        return True

            if self.session.department_key in ['otsenki_kachestva_dostavki']:
                for m in messages:
                    if not (self.__contains_one_of(m.text, ['5 / 5', '4 / 5', '3 / 5', '5/5', '4/5', '3/5']) or m.text in {'5', '4', '3'}):
                        break
                else:
                    logging.warn('autoclosing chat otsenki_kachestva_dostavki ' + str(self.id))
                    self.process_event('sys.auto_close', produce_delta=produce_delta)
                    return True

        return False

    def try_assign_to_robot(self, produce_delta=True):
        if not self.session.account.get_setting('robots'):
            return False

        ordered_robots = self.session.account.get_ordered_robots()

        for robot in ordered_robots:
            if robot.robot_logic.on_new_chat_created(self, produce_delta):
                return True

        return False

    @classmethod
    def try_auto_assign_chats_in_queue(cls, account, offline=None):
        if offline is None:
            account.auto_assign_controller.set_auto_assign_required()
            account.auto_assign_controller_for_offline.set_auto_assign_required()
        else:
            controller = account.auto_assign_controller_for_offline if offline else account.auto_assign_controller
            controller.set_auto_assign_required()

    def set_requested_form_id(self, form_id):
        self.requested_form = form_id
        self.session.delta_manager.add_delta(delta.Delta('FORM_REQUEST', delta.Delta.Event.UPDATE, self.session.id, {'formId': form_id}))

    def add_message(self, message, produce_delta=True, send_push=True):

        self.messages.append(message)

        if self.state in [Chat.State.CLOSED, Chat.State.DELETED]:
            return

        if message.kind == Message.Kind.ACTION_REQUEST:
            self.event_dispatcher.add_consumer(message.event_consumer)

        event = Event(e_type=Event.Type.MESSAGE_ADD, e_object=message, e_data={"chat": self})
        self.event_dispatcher.fire(event)
        self.session.account.event_dispatcher.fire(event)

        if message.kind == Message.Kind.OPERATOR_BUSY:
            self.last_activity_ts = time.time()

        if message.kind in Message.Kind.VISITOR_KINDS:
            self.last_activity_ts = time.time()
            self.process_event('visitor.message', attrs={'message': message})
            if not message.get_data('dont_require_response', False):
                self.set_unread_by_operator_since_ts(message.ts, produce_delta=produce_delta)
            self.set_unread_by_visitor_since_ts(None, produce_delta=produce_delta)

            if message.kind == Message.Kind.VISITOR:
                if self.session.account.get_setting('operator_hints'):
                    wm_timer.invoke_async(lambda: self.update_operator_hints(message), timer_name='operator_hints async get')

        if message.kind in Message.Kind.OPERATOR_KINDS:
            self.last_activity_ts = time.time()
            self.process_event('operator.message')
            self.set_unread_by_visitor_since_ts(message.ts, produce_delta=produce_delta)
            self.set_unread_by_operator_since_ts(None, produce_delta=produce_delta)
            if self.session.push_token and send_push:
                if self.offline:
                    message.stored_to_db_callbacks.add(lambda: self.push_visitor_on_message(message))
                else:
                    wm_timer.invoke_async(lambda: self.push_visitor_on_message(message), 'push_visitor_on_message')

        if message.kind == Message.Kind.OPERATOR and self.offline:
            wm_timer.invoke_async(lambda: self.send_offline_response_to_visitor(message), 'send_offline_response_to_visitor')

        if message.kind in Message.Kind.VISITOR_AND_OPERATOR_KINDS:
            if self.session.account.get_setting('order_chats_by_unread_by_operator_since_ts'):
                self.session.update_section_and_order()

        if produce_delta:
            d = delta.Delta('CHAT_MESSAGE', delta.Delta.Event.ADD, message.id, message)
            d2 = delta.Delta('CHAT_MESSAGE_2', delta.Delta.Event.ADD, [self.session.id, message.id], message)

            if message.visible_by_visitor():
                self.session.delta_manager.add_delta(d)

            if self.session.account.get_setting('send_chat_message_delta'):
                    self.session.add_operator_delta(d)  # deprecated
            self.session.add_operator_delta(d2)

        if self.state == Chat.State.CHATTING_WITH_ROBOT and message.kind == Message.Kind.VISITOR:
            self.get_operator().robot_logic.on_new_visitor_message(self, message)

        if message.kind == Message.Kind.FOR_OPERATOR or message.kind == Message.Kind.INFO:
            self.session.account.push_manager.send_for_operator_message_notification(message, self)
        if message.kind == Message.Kind.FORM_RESPONSE:
            self.session.account.push_manager.send_form_response_message_notification(message, self)

        if not self.offline:
            self.session.update_polling_period()

    def update_operator_hints(self, message):
        import robots as wm_robots
        hints = wm_robots.operator_hints.get_hints(message.text, self.session)
        if self.operator_hints != hints:
            self.operator_hints = hints
            self.session.add_operator_delta(delta.Delta("OPERATOR_HINTS", delta.Delta.Event.UPDATE, self.session.id, hints))

    def push_visitor_on_message(self, message):
        ios_cutting_rules = None
        if message.kind == Message.Kind.OPERATOR:
            push_data = {'loc-key': 'P.OM',
                         'params': [message.name, message.text],
                         'chatId': self.id, 'messageTs': message.ts,
                         'offline': self.offline,
                         'message_push_data': message.to_dict({'mode': 'visitor.push'})}
            ios_cutting_rules = {0: 22, 1: -1}

        elif message.kind == Message.Kind.CONT_REQ:
            push_data = {'loc-key': 'P.CR',
                         'params': [],
                         'chatId': self.id,
                         'messageTs': message.ts,
                         'offline': self.offline,
                         'message_push_data': message.to_dict({'mode': 'visitor.push'})}

        elif message.kind == Message.Kind.FILE_OPERATOR:
            filename = json.loads(message.text)['filename']
            push_data = {'loc-key': 'P.OF',
                         'params': [message.name, filename],
                         'chatId': self.id,
                         'messageTs': message.ts,
                         'offline': self.offline,
                         'message_push_data': message.to_dict({'mode': 'visitor.push'})}
            ios_cutting_rules = {0: 22, 1: -1}
        else:
            return

        push_data['badge'] = 1  # this should be always 1 for tcsbankru*

        self.push_visitor(push_data, async=False, ios_cutting_rules=ios_cutting_rules)

    def push_visitor(self, push_data, async=True, ios_cutting_rules=None):
        if async:
            wm_timer.invoke_async(lambda: self.push_visitor(push_data, async=False), timer_name='push_visitor')
            return

        if 'event' not in push_data:
            push_data['event'] = 'add'
        push_token = self.session.push_token
        if push_token:
            if self.session.platform == 'android':
                if self.session.push_service == 'fcm':
                    wm_notification.FCMVisitorPushManager(self.session.account.get_android_api_key('fcm')).send(push_token, push_data)
                else:
                    wm_notification.GCMVisitorPushManager(self.session.account.get_android_api_key('gcm')).send(push_token, push_data)
            elif self.session.platform == 'ios':
                separator_index = push_token.find('_')
                certs_dir = None
                if separator_index != -1:
                    certs_dir = push_token[0:separator_index]
                    push_token = push_token[(separator_index + 1):]
                    if not re.match('^[a-zA-Z0-9]+$', certs_dir):
                        certs_dir = None
                wm_notification.IosVisitorPushNotificationManager.instance(self.session.account,
                                                                           certs_last_dir=certs_dir)\
                    .send(push_token, push_data, cutting_rules=ios_cutting_rules)
            elif self.session.platform == 'pochta':
                wm_notification.PochtaVisitorPushNotificationManager.instance(self.session.account).send(push_token, push_data)

            elif self.session.platform == 'winphone':
                wm_notification.WindowsVisitorPushNotificationManager.instance(self.session.account).send(self.session.push_token, push_data)

    def next_message_id(self):
        self.__last_message_id += 1
        return self.session.id + '_' + str(self.__last_message_id)

    def set_unread_by_visitor_since_ts(self, value, produce_delta=True):
        if bool(self.unread_by_visitor_since_ts) != bool(value):
            self.unread_by_visitor_since_ts = value

            if produce_delta:
                d = delta.Delta('CHAT_READ_BY_VISITOR', delta.Delta.Event.UPDATE, self.session.id, value is None)
                self.session.delta_manager.add_delta(d)
                self.session.add_operator_delta(d)
            self.update_unread_by_visitor_msg_count(produce_delta=produce_delta)

            if self.offline:
                self.store()

            for m in self.messages:
                m.update_read(produce_delta=produce_delta)
        elif value:
            self.update_unread_by_visitor_msg_count(produce_delta=produce_delta)

    def update_unread_by_visitor_msg_count(self, produce_delta=True):
        count_unread_by_visitor = self.calc_unread_by_visitor_msg_count()
        if count_unread_by_visitor != self.unread_by_visitor_msg_cnt:
            if produce_delta:
                d = delta.Delta('UNREAD_BY_VISITOR', delta.Delta.Event.UPDATE, self.session.id,
                                {'sinceTs': self.unread_by_visitor_since_ts, 'msgCnt': count_unread_by_visitor})
                self.session.delta_manager.add_delta(d)
            self.unread_by_visitor_msg_cnt = count_unread_by_visitor

    def calc_unread_by_visitor_msg_count(self):
        count_unread_by_visitor = 0
        if self.unread_by_visitor_since_ts:
            for msg in self.messages[::-1]:
                if msg.ts < self.unread_by_visitor_since_ts:
                    break
                if msg.kind in Message.Kind.OPERATOR_KINDS:
                    count_unread_by_visitor += 1
        return count_unread_by_visitor

    def set_visitor_typing(self, value):
        self.last_activity_ts = time.time()
        if value:
            self.set_unread_by_visitor_since_ts(None)
        if self.visitor_typing != value:
            self.visitor_typing = value
            d = delta.Delta('CHAT_VISITOR_TYPING', delta.Delta.Event.UPDATE, self.session.id, value)
#            self.session.delta_manager.add_delta(d)
            self.session.add_operator_delta(d)
            self.session.account.event_dispatcher.fire(Event(e_type=Event.Type.VISITOR_TYPING, e_object=self, e_data={'typing': self.visitor_typing}))

    def set_visitor_message_draft(self, value):
        if self.visitor_message_draft != value:
            self.visitor_message_draft = value
            d = delta.Delta('VISITOR_MESSAGE_DRAFT', delta.Delta.Event.UPDATE, self.session.id, value)
            self.session.add_operator_delta(d)

            if self.state == Chat.State.CHATTING_WITH_ROBOT:
                self.get_operator().robot_logic.on_new_visitor_draft(self, value)

    def set_operator_typing(self, value):
        self.last_activity_ts = time.time()
        if self.operator_typing != value:
            self.operator_typing = value
            d = delta.Delta('CHAT_OPERATOR_TYPING', delta.Delta.Event.UPDATE, self.session.id, value)
            self.session.delta_manager.add_delta(d)
            self.session.account.event_dispatcher.fire(Event(e_type=Event.Type.OPERATOR_TYPING, e_object=self, e_data={'typing': self.operator_typing}))

    def set_need_to_be_closed(self, value):
        if self.need_to_be_closed != value:
            self.need_to_be_closed = value
            d = delta.Delta('CHAT_NEED_TO_BE_CLOSED', delta.Delta.Event.UPDATE, self.session.id, value)
            self.session.add_operator_delta(d)

    def set_unread_by_operator_since_ts(self, value, produce_delta=True):
        if self.offline:
            return
        if bool(self.unread_by_operator_since_ts) != bool(value):
            self.unread_by_operator_since_ts = value
            if self.session.account.get_setting('order_chats_by_unread_by_operator_since_ts'):
                self.session.update_section_and_order()

            if produce_delta:
                d = delta.Delta('CHAT_UNREAD_BY_OPERATOR_SINCE_TS', delta.Delta.Event.UPDATE, self.session.id, value)
                # self.session.delta_manager.add_delta(d)
                self.session.add_operator_delta(d)

            self.session.update_actual_time(produce_delta=produce_delta)
            if not value:
                self.redirected = False

    def get_operator_id(self):
        return self.__operator_id

    def get_operator(self):
        return self.session.account.get_operator(self.__operator_id) if self.__operator_id else None

    def update_last_operator_assigned_ts(self, ts=None, produce_delta=True):
        self.last_operator_assigned_ts = ts or time.time()
        if produce_delta:
            d = delta.Delta('CHAT_LAST_OPERATOR_ASSIGNED_TS', delta.Delta.Event.UPDATE, self.session.id, self.last_operator_assigned_ts)
            self.session.add_operator_delta(d)

    def update_state_modified_ts(self, ts=None, produce_delta=True):
        self.state_modified_ts = ts or time.time()
        d = delta.Delta('CHAT_STATE_MODIFIED_TS', delta.Delta.Event.UPDATE, self.session.id, self.state_modified_ts)
        self.session.add_operator_delta(d)

    def set_operator_id(self, operator_id, redirected=False, post_info_message=True, produce_delta=True):
        if self.__operator_id == operator_id:
            return False

        self.__operator_id = operator_id

        if operator_id:
            self.operators_in_chat.add(self.__operator_id)
            self.update_last_operator_assigned_ts(produce_delta=produce_delta)
            oo = self.session.account.oo_manager.get(operator_id)
            if oo:
                oo.last_chat_assigned_ts = time.time()

        self.session.account.queue_manager.update_chat_in_queue(self, post_place_in_queue_message=True)

        self.set_unread_by_operator_since_ts(time.time(), produce_delta=produce_delta)
        self.redirected = redirected
        self.set_operator_typing(False)

        if self.__operator_id and self.owned_by_session():
            self.session.set_not_hidden(produce_delta=produce_delta)

        if produce_delta:
            operator = self.get_operator()
            d = delta.Delta('CHAT_OPERATOR', delta.Delta.Event.UPDATE, self.session.id, operator)
            self.session.delta_manager.add_delta(d)
            self.session.add_operator_delta(d)

        if self.__operator_id:
            self.stored_to_db_callbacks.add(lambda: self.send_history_to_external_handler('chat_assigned_handler_url'))

        if self.redirected and self.session.cobrowsing_session:
            self.session.set_cobrowsing_session_state(CobrowsingSession.State.DISCONNECTED, CobrowsingSession.StateReason.CLOSED_BY_OPERATOR)

        return True

    def post_operator_joined_chat_message(self, resource_key, produce_delta=True, redirected=False):
        if self.offline and self.session.platform == 'pochta':
            return
        if self.session.account.get_setting('avoid_operator_joined_chat_message'):
            return
        oo = self.session.account.oo_manager.get(self.__operator_id)
        if self.session.account.name in ['tcsbankru', 'mixey'] and oo.is_online_inf():
            return
        operator_name = self.get_operator().get_visible_name(self.session.lang)
        msg = self.get_resource(resource_key, operator_name=operator_name)
        if msg:
            kind = Message.Kind.FOR_OPERATOR if self.session.account.name in {'komusru001', 'mixey'} else Message.Kind.INFO
            Message.create(self, kind, None, msg, produce_delta=produce_delta, data={
                'subKind': 'operator-joined',
                'redirected': redirected,
                'resource': {
                    'key': resource_key,
                    'params': {
                        'operator_name': operator_name
                    }
                }
            })

    def post_operator_closed_chat_message(self, resource_key, produce_delta=True):
        kind = Message.Kind.INFO

        if self.session.account.get_setting('operator_closed_chat_message_for_operator_only'):
            kind = Message.Kind.FOR_OPERATOR

        msg = self.get_resource(resource_key)

        if msg:
            Message.create(self, kind, None, msg, produce_delta=produce_delta)

    def set_category(self, category, subcategory):
        self.category = category
        self.subcategory = subcategory
        self.session.add_operator_delta(
            delta.Delta('CHAT_CATEGORY', delta.Delta.Event.UPDATE, self.session.id, {'category': category, 'subcategory': subcategory})
        )
        Message.create_from_resource(
            self, Message.Kind.FOR_OPERATOR, None, 'chat.message.set_chat_category', True, *[category, ((" - " + subcategory) if subcategory else '')]
        )
        self.store()

    def process_event(self, event, attrs=None, produce_delta=True):
        if 'process_event_flag' in self.chat_thread_local.__dict__ and self.chat_thread_local.process_event_flag:
            wm_timer.invoke_async(lambda: self.process_event(event, attrs=attrs, produce_delta=produce_delta))
            return

        with self.__process_event_lock:
            self.chat_thread_local.process_event_flag = True
            self.__do_process_event(event, attrs=attrs, produce_delta=produce_delta)
            self.chat_thread_local.process_event_flag = False

    def __do_process_event(self, event, attrs=None, produce_delta=True):
        new_state = self.state
        old_operator_id = self.__operator_id
        old_state = self.state

        if self.state == Chat.State.QUEUE:
            if event == 'operator.accept':
                new_state = Chat.State.CHATTING
                self.session.inc_session_chats_count('current_chats_count')
                self.set_operator_id(attrs['operator_id'], produce_delta=produce_delta)
                self.post_operator_joined_chat_message('chat.message.operator_joined_chat')
                self.session.account.push_manager.send_visitor_accepted_notification(self.session)
            if event == 'operator.redirect_to_operator' or event == 'sys.redirect_to_inf':
                new_state = Chat.State.QUEUE
                self.set_operator_id(attrs['operator_id'], redirected=True, produce_delta=produce_delta)
                if self.get_operator() and self.get_operator().is_robot():
                    new_state = Chat.State.CHATTING_WITH_ROBOT
                    self.get_operator().robot_logic.on_chat_redirected_to_robot(self, produce_delta=produce_delta)
                self.post_operator_joined_chat_message('chat.message.chat_redirected_to_operator', redirected=True)
            if event == 'sys.auto_assign':
                new_state = Chat.State.QUEUE
                self.set_operator_id(attrs['operator_id'], produce_delta=produce_delta)
                if self.get_operator().is_robot():
                    new_state = Chat.State.CHATTING_WITH_ROBOT
                    self.get_operator().robot_logic.on_chat_assigned_to_robot(self, produce_delta=produce_delta)
            if event == 'sys.assign_to_robot':
                new_state = Chat.State.CHATTING_WITH_ROBOT
                self.set_operator_id(attrs['operator_id'], produce_delta=produce_delta)
                if not self.session.account.get_setting('hide_robot_presence'):
                    self.post_operator_joined_chat_message('chat.message.operator_joined_chat')
                self.get_operator().robot_logic.on_chat_assigned_to_robot(self, produce_delta=produce_delta)
            if event == 'inf.auto_accept':
                new_state = Chat.State.CHATTING
                self.session.inc_session_chats_count('current_chats_count')
                self.set_operator_id(attrs['operator_id'], produce_delta=produce_delta)
            if event == 'operator.close':
                new_state = Chat.State.CLOSED if self.session.account.get_setting('operator_closes_chat_finally') else Chat.State.CLOSED_BY_OPERATOR
                self.set_operator_id(attrs['operator_id'], post_info_message=False, produce_delta=produce_delta)
                self.post_operator_closed_chat_message('chat.message.operator_closed_chat', produce_delta=produce_delta)
            if event == 'operator.ban':
                Message.create_from_resource(self, Message.Kind.FOR_OPERATOR, None, 'chat.message.visitor_banned_by_operator', produce_delta)
                new_state = Chat.State.CLOSED
                self.set_operator_id(attrs['operator_id'], post_info_message=False, produce_delta=produce_delta)
            if event == 'visitor.close':
                new_state = Chat.State.CLOSED
                Message.create_from_resource(self, Message.Kind.FOR_OPERATOR, None, 'chat.message.visitor_closed_chat', produce_delta)
            if event == 'visitor.left_site_erewhile':
                new_state = Chat.State.CLOSED
                Message.create_from_resource(self, Message.Kind.FOR_OPERATOR, None, 'chat.message.visitor_left', produce_delta)
            if event == 'visitor.ping':
                self.check_operator_busy()
            if event == 'session.delete':
                new_state = Chat.State.CLOSED
            if event == 'sys.close':
                new_state = Chat.State.CLOSED
            if event == 'sys.unassign':
                self.set_operator_id(None, produce_delta=produce_delta)
                new_state = Chat.State.QUEUE
            if event == 'sys.unset_department':
                self.set_operator_id(None, produce_delta=produce_delta)
                self.session.set_department(None, self.session.lang, produce_delta=produce_delta)
                new_state = Chat.State.QUEUE

        elif self.state == Chat.State.ROUTING:
            if event == 'sys.routing_to_department':
                self.session.set_department(attrs['department_key'], self.session.lang, produce_delta=produce_delta)
                new_state = Chat.State.QUEUE
            if event == 'sys.routing_to_operator':
                self.set_operator_id(attrs['operator_id'], produce_delta=produce_delta)
                self.post_operator_joined_chat_message('chat.message.operator_joined_chat')
                new_state = Chat.State.QUEUE
            if event == 'sys.routing_failed':
                new_state = Chat.State.QUEUE

        elif self.state == Chat.State.CHATTING_WITH_ROBOT:
            if event == 'operator.accept':
                new_state = Chat.State.CHATTING
                self.session.inc_session_chats_count('current_chats_count')
                self.get_operator().robot_logic.on_chat_unassigned_from_robot(self, produce_delta=produce_delta)
                self.set_operator_id(attrs['operator_id'], produce_delta=produce_delta)
                self.post_operator_joined_chat_message('chat.message.operator_joined_chat')
                self.session.account.push_manager.send_visitor_accepted_notification(self.session)
            if event == 'sys.assign_to_robot':
                self.set_operator_id(attrs['operator_id'], produce_delta=produce_delta)
                self.post_operator_joined_chat_message('chat.message.operator_joined_chat')
                self.get_operator().robot_logic.on_chat_assigned_to_robot(self, produce_delta=produce_delta)
            if event == 'sys.unassign_from_robot':
                self.get_operator().robot_logic.on_chat_unassigned_from_robot(self, produce_delta=produce_delta)
                self.set_operator_id(None, produce_delta=produce_delta)
                new_state = Chat.State.QUEUE

                if self.session.account.router and self.session.account.get_department(self.session.department_key).settings.get('routing', False):
                    new_state = Chat.State.ROUTING
            if event == 'visitor.close':
                Message.create_from_resource(self, Message.Kind.FOR_OPERATOR, None, 'chat.message.visitor_closed_chat', produce_delta)
                new_state = Chat.State.CLOSED
                self.get_operator().robot_logic.on_chat_closed(self, produce_delta=produce_delta)
            if event == 'visitor.left_site_erewhile':
                Message.create_from_resource(self, Message.Kind.FOR_OPERATOR, None, 'chat.message.visitor_left', produce_delta)
                new_state = Chat.State.CLOSED
                self.get_operator().robot_logic.on_chat_closed(self, produce_delta=produce_delta)
            if event == 'sys.close':
                new_state = Chat.State.CLOSED
                self.get_operator().robot_logic.on_chat_closed(self, produce_delta=produce_delta)
                self.set_operator_id(None, produce_delta=produce_delta)
            if event == 'sys.unassign':
                self.set_operator_id(None, produce_delta=produce_delta)
                new_state = Chat.State.QUEUE
            if event == 'sys.unset_department':
                self.session.set_department(None, self.session.lang, produce_delta=produce_delta)
                new_state = Chat.State.CHATTING_WITH_ROBOT
            if event == 'sys.close_by_timeout':
                new_state = Chat.State.CLOSED
                self.get_operator().robot_logic.on_chat_closed(self, produce_delta=produce_delta)

        elif self.state == Chat.State.INVITATION:
            if event == 'visitor.message':
                self.session.inc_session_chats_count('current_chats_count')
                new_state = Chat.State.CHATTING
            if event == 'visitor.close':
                Message.create_from_resource(self, Message.Kind.FOR_OPERATOR, None, 'chat.message.visitor_closed_chat', produce_delta)
                new_state = Chat.State.CLOSED
            if event == 'operator.close':
                new_state = Chat.State.CLOSED
            if event == 'visitor.left_site_erewhile':
                new_state = Chat.State.CLOSED
                Message.create_from_resource(self, Message.Kind.FOR_OPERATOR, None, 'chat.message.visitor_left', produce_delta)
            if event == 'operator.accept':
                self.set_operator_id(attrs['operator_id'], produce_delta=produce_delta)
                self.post_operator_joined_chat_message('chat.message.operator_joined_chat')
            if event == 'sys.close_by_timeout':
                new_state = Chat.State.CLOSED
            if event == 'sys.close':
                new_state = Chat.State.CLOSED
            if event == 'sys.unassign':
                self.set_operator_id(None, produce_delta=produce_delta)
                new_state = Chat.State.CLOSED
            if event == 'sys.unset_department':
                self.session.set_department(None, self.session.lang, produce_delta=produce_delta)
                new_state = Chat.State.INVITATION

        elif self.state == Chat.State.CHATTING:
            if event == 'operator.accept':
                if self.set_operator_id(attrs['operator_id'], produce_delta=produce_delta):
                    self.post_operator_joined_chat_message('chat.message.operator_joined_chat')
            if event == 'operator.redirect_to_operator' or event == 'sys.redirect_to_inf':
                new_state = Chat.State.QUEUE
                self.set_operator_id(attrs['operator_id'], redirected=True, produce_delta=produce_delta)
                if self.get_operator().is_robot():
                    new_state = Chat.State.CHATTING_WITH_ROBOT
                    self.get_operator().robot_logic.on_chat_redirected_to_robot(self, produce_delta=produce_delta)
                self.post_operator_joined_chat_message('chat.message.chat_redirected_to_operator', redirected=True)
            if event == 'operator.close':
                new_state = Chat.State.CLOSED if self.session.account.get_setting('operator_closes_chat_finally') else Chat.State.CLOSED_BY_OPERATOR
                self.post_operator_closed_chat_message('chat.message.operator_closed_chat', produce_delta=produce_delta)
            if event == 'operator.ban':
                Message.create_from_resource(self, Message.Kind.FOR_OPERATOR, None, 'chat.message.visitor_banned_by_operator', produce_delta)
                new_state = Chat.State.CLOSED
            if event == 'visitor.close':
                new_state = Chat.State.CLOSED_BY_VISITOR
                Message.create_from_resource(self, Message.Kind.FOR_OPERATOR, None, 'chat.message.visitor_closed_chat', produce_delta)
            if event == 'visitor.left_site_erewhile':
                new_state = Chat.State.CLOSED_BY_VISITOR
                Message.create_from_resource(self, Message.Kind.FOR_OPERATOR, None, 'chat.message.visitor_left', produce_delta)
            if event == 'visitor.ping':
                self.check_operator_busy()
            if event == 'session.delete':
                new_state = Chat.State.CLOSED
            if event == 'operator.redirect_to_department':
                self.post_chat_redirected_to_department_message(produce_delta=produce_delta)
                self.set_operator_id(None, produce_delta=produce_delta)
                new_state = Chat.State.QUEUE
            if event == 'sys.unset_department':
                self.session.set_department(None, self.session.lang, produce_delta=produce_delta)
                new_state = Chat.State.CHATTING
            if event == 'sys.close_by_timeout':
                new_state = Chat.State.CLOSED
            if event == 'sys.close':
                new_state = Chat.State.CLOSED
            if event == 'sys.unassign':
                self.set_operator_id(None, produce_delta=produce_delta)
                new_state = Chat.State.QUEUE

        elif self.state == Chat.State.CLOSED_BY_VISITOR:
            if event == 'operator.accept':
                new_state = Chat.State.CHATTING
                self.set_operator_id(attrs['operator_id'], produce_delta=produce_delta)
                self.post_operator_joined_chat_message('chat.message.operator_joined_chat')
            if event == 'operator.redirect_to_operator':
                new_state = Chat.State.QUEUE
                self.set_operator_id(attrs['operator_id'], redirected=True, produce_delta=produce_delta)
                self.post_operator_joined_chat_message('chat.message.chat_redirected_to_operator', redirected=True)
            if event == 'operator.close':
                new_state = Chat.State.CLOSED
            if event == 'operator.ban':
                Message.create_from_resource(self, Message.Kind.FOR_OPERATOR, None, 'chat.message.visitor_banned_by_operator', produce_delta)
                new_state = Chat.State.CLOSED
            if event == 'operator.message':
                if self.session.on_site.get():
                    new_state = Chat.State.CHATTING
            if event == 'visitor.start':
                Message.create_from_resource(self, Message.Kind.FOR_OPERATOR, None, 'chat.message.visitor_reopened_chat', produce_delta)
                new_state = Chat.State.CHATTING
            if event == 'session.delete':
                new_state = Chat.State.CLOSED
            if event == 'operator.redirect_to_department':
                self.post_chat_redirected_to_department_message(produce_delta=produce_delta)
                self.set_operator_id(None, produce_delta=produce_delta)
                new_state = Chat.State.QUEUE
            if event == 'sys.unset_department':
                self.session.set_department(None, self.session.lang, produce_delta=produce_delta)
                new_state = Chat.State.CLOSED_BY_VISITOR
            if event == 'sys.close_by_timeout':
                new_state = Chat.State.CLOSED
            if event == 'sys.close':
                new_state = Chat.State.CLOSED
            if event == 'sys.unassign':
                self.set_operator_id(None, produce_delta=produce_delta)
                new_state = Chat.State.CLOSED

        elif self.state == Chat.State.CLOSED_BY_OPERATOR:
            if event == 'operator.accept':
                new_state = Chat.State.CHATTING
                self.set_operator_id(attrs['operator_id'], produce_delta=produce_delta)
                self.post_operator_joined_chat_message('chat.message.operator_joined_chat')
            if event == 'operator.redirect_to_operator':
                new_state = Chat.State.QUEUE
                self.set_operator_id(attrs['operator_id'], redirected=True, produce_delta=produce_delta)
                self.post_operator_joined_chat_message('chat.message.chat_redirected_to_operator', redirected=True)
            if event == 'operator.message':
                new_state = Chat.State.CHATTING
            if event == 'operator.ban':
                Message.create_from_resource(self, Message.Kind.FOR_OPERATOR, None, 'chat.message.visitor_banned_by_operator', produce_delta)
                new_state = Chat.State.CLOSED
            if event == 'visitor.close':
                new_state = Chat.State.CLOSED
            if event == 'visitor.left_site_erewhile':
                new_state = Chat.State.CLOSED
            if event == 'visitor.message':
                message = attrs.get('message')
                if not message.get_data('dont_require_response', False):
                    self.set_operator_id(None, produce_delta=produce_delta)
                    self.manually_assigned_operator_id = None
                    new_state = Chat.State.QUEUE
            if event == 'session.delete':
                new_state = Chat.State.CLOSED
            if event == 'operator.redirect_to_department':
                self.post_chat_redirected_to_department_message(produce_delta=produce_delta)
                self.set_operator_id(None, produce_delta=produce_delta)
                new_state = Chat.State.QUEUE
            if event == 'sys.unset_department':
                self.session.set_department(None, self.session.lang, produce_delta=produce_delta)
                new_state = Chat.State.CLOSED_BY_OPERATOR
            if event == 'sys.close':
                new_state = Chat.State.CLOSED
            if event == 'sys.close_by_timeout':
                new_state = Chat.State.CLOSED
            if event == 'sys.unassign':
                self.set_operator_id(None, produce_delta=produce_delta)
                new_state = Chat.State.CLOSED

        elif self.state == Chat.State.OFFLINE_QUEUE:
            if event == 'operator.accept':
                new_state = Chat.State.OFFLINE_PROCESS
                self.set_operator_id(attrs['operator_id'], produce_delta=produce_delta)
                self.post_operator_joined_chat_message('chat.message.operator_accepted_ofline_chat')
            if event == 'sys.auto_assign':
                new_state = Chat.State.OFFLINE_QUEUE
                self.set_operator_id(attrs['operator_id'], produce_delta=produce_delta)
            if event == 'operator.close':
                new_state = Chat.State.CLOSED
                self.set_operator_id(attrs['operator_id'], post_info_message=False, produce_delta=produce_delta)
            if event == 'sys.auto_close':
                new_state = Chat.State.CLOSED
            if event == 'operator.ban':
                Message.create_from_resource(self, Message.Kind.FOR_OPERATOR, None, 'chat.message.visitor_banned_by_operator', produce_delta)
                # TODO close other offline chats
                new_state = Chat.State.CLOSED
                self.set_operator_id(attrs['operator_id'], post_info_message=False, produce_delta=produce_delta)
            if event == 'operator.redirect_to_department':
                self.post_chat_redirected_to_department_message(produce_delta=produce_delta)
                self.set_operator_id(None, produce_delta=produce_delta)
                new_state = Chat.State.OFFLINE_QUEUE
            if event == 'sys.unset_department':
                self.set_operator_id(None, produce_delta=produce_delta)
                self.session.set_department(None, self.session.lang, produce_delta=produce_delta)
                new_state = Chat.State.OFFLINE_QUEUE
            if event == 'sys.unassign':
                self.set_operator_id(None, produce_delta=produce_delta)
                new_state = Chat.State.OFFLINE_QUEUE
            if event == 'sys.close':
                new_state = Chat.State.CLOSED

        elif self.state == Chat.State.OFFLINE_PROCESS:
            if event == 'operator.accept':
                self.set_operator_id(attrs['operator_id'], produce_delta=produce_delta)
                self.post_operator_joined_chat_message('chat.message.operator_accepted_ofline_chat')
            if event == 'operator.redirect_to_operator':
                new_state = Chat.State.OFFLINE_PROCESS
                self.set_operator_id(attrs['operator_id'], redirected=True, produce_delta=produce_delta)
                self.post_operator_joined_chat_message('chat.message.offline_chat_redirected_to_operator', redirected=True)
            if event == 'operator.close':
                new_state = Chat.State.CLOSED
                if self.session.platform != 'pochta':
                    Message.create_from_resource(self, Message.Kind.INFO, None, 'chat.message.operator_closed_offline_chat', produce_delta)
            if event == 'sys.auto_close':
                new_state = Chat.State.CLOSED
            if event == 'operator.ban':
                Message.create_from_resource(self, Message.Kind.FOR_OPERATOR, None, 'chat.message.visitor_banned_by_operator', produce_delta)
                # TODO close other offline chats
                new_state = Chat.State.CLOSED
            if event == 'operator.redirect_to_department':
                self.set_operator_id(None, produce_delta=produce_delta)
                new_state = Chat.State.OFFLINE_QUEUE
            if event == 'sys.unset_department':
                self.set_operator_id(None, produce_delta=produce_delta)
                self.session.set_department(None, self.session.lang, produce_delta=produce_delta)
                new_state = Chat.State.OFFLINE_PROCESS
            if event == 'sys.unassign':
                self.set_operator_id(None, produce_delta=produce_delta)
                new_state = Chat.State.OFFLINE_QUEUE
            if event == 'sys.close':
                new_state = Chat.State.CLOSED

        elif self.state == Chat.State.CLOSED:
            if event == 'visitor.message':
                self.set_operator_id(None, produce_delta=produce_delta)
                new_state = Chat.State.OFFLINE_QUEUE

                # todo may be  better to move this under if new_state != self.state
                self.session.set_chat(self, produce_delta=False)
                self.session.account.visit_tracker.add_session(self.session)
                self.session.update_alive()

            if event == 'visitor.delete':
                Message.create_from_resource(self, Message.Kind.FOR_OPERATOR, None, 'chat.message.visitor_deleted_chat', produce_delta)
                new_state = Chat.State.DELETED

        now_ts = time.time()
        if new_state != self.state:
            self.update_state_modified_ts()
            self.state = new_state
            self.modification_ts = now_ts
            self.last_activity_ts = now_ts
            self.session.update_polling_period(produce_delta)
            self.session.account.queue_manager.update_chat_in_queue(self)

            self.event_dispatcher.fire(Event(e_type=Event.Type.CHAT_STATE_MODIFIED, e_object=self))

            if produce_delta:
                d = delta.Delta('CHAT_STATE', delta.Delta.Event.UPDATE, self.session.id, self.state)
                self.session.delta_manager.add_delta(d)
                self.session.add_operator_delta(d)

            self.store()

            if new_state == Chat.State.ROUTING:
                self.stored_to_db_callbacks.add(lambda: self.session.account.router.route_chat(self))

            if new_state == Chat.State.CLOSED:
                if old_state == Chat.State.QUEUE:
                    self.session.account.push_manager.send_visitor_left_notification(self.session)

                self.session.set_previous_chats_to_true(self.creation_ts, self.offline, produce_delta=produce_delta)
                self.session.set_chat(None, produce_delta=produce_delta)

                self.session.process_event('chat-closed')
                wm_timer.invoke_async(self.session.update_prev_chats_count, 'update_prev_chats_count')
                self.stored_to_db_callbacks.add(lambda: self.send_history_to_external_handler('chat_closed_handler_url'))
                self.stored_to_db_callbacks.add(lambda: self.session.account.integration_manager.on_chat_finished(self))

                if self.__operator_id:
                    self.session.visitor.update_last_chat_operator_id(self.__operator_id, produce_delta=produce_delta)

                if not self.offline:
                    self.store_global_chat()

                if self.operator_busy_message_posted:
                    if self.session.visitor.channel_user_id:
                        return
                    self.send_operator_busy_notification()

                if self.session.account.settings.get('send_operator_rate_mail_on_chat_close'):
                    for operator_id, rate in self.operator_id_to_operator_rate.iteritems():
                        if rate.value < 0:
                            self.send_negative_operator_rate_mail(rate_value=rate.value, operator_id=operator_id)

            self.session.update_alive()

        if old_operator_id != self.__operator_id or old_state != self.state:
            self.modification_ts = now_ts
            self.last_activity_ts = now_ts
            self.post_chat_history_record(event)
            self.session.update_section_and_order(produce_delta=produce_delta, force_delta=(old_operator_id != self.__operator_id))
            self.session.update_actual_time(produce_delta=produce_delta)
            self.session.update_in_subsets()

            self.session.account.event_dispatcher.fire(
                Event(e_type=Event.Type.CHAT_STATE_MODIFIED, e_object=self,
                      e_data={'new_state': new_state, 'old_state': old_state, "old_operator_id": old_operator_id})
            )

            if old_state in [Chat.State.CHATTING, Chat.State.QUEUE, Chat.State.OFFLINE_QUEUE, Chat.State.OFFLINE_PROCESS] and old_operator_id:
                wm_timer.invoke_async(lambda: Chat.try_auto_assign_chats_in_queue(self.session.account, offline=self.offline), 'try_auto_assign_chats_in_queue')

            if new_state in [Chat.State.QUEUE, Chat.State.OFFLINE_QUEUE] and self.__operator_id is None:
                wm_timer.invoke_async(lambda: Chat.try_auto_assign_chats_in_queue(self.session.account, offline=self.offline), 'try_auto_assign_chats_in_queue')

            if old_operator_id and self.session.account.oo_manager.get(old_operator_id):
                wm_timer.invoke_async(self.session.account.oo_manager.get(old_operator_id).on_assigned_chat_state_changed, 'on_assigned_chat_state_changed')

    def get_last_important_message(self):
        for message in reversed(self.messages):
            if message.kind not in [Message.Kind.INFO, Message.Kind.FOR_OPERATOR]:
                return message

        return None

    def get_message_by_client_id(self, client_side_id):
        for m in self.messages:
            if m.client_side_id == client_side_id:
                return m

        return None

    def get_last_visitor_message(self):
        for message in reversed(self.messages):
            if message.kind in [Message.Kind.VISITOR]:
                return message

        return None

    def get_last_human_message(self):
        for message in reversed(self.messages):
            if message.kind in Message.Kind.VISITOR_AND_OPERATOR_KINDS:
                return message

        return None

    def create_zendesk_ticket(self, data, form_response):
        try:
            zendesk_options = self.session.account.settings.get('zendesk')
            z = Zendesk(zendesk_options)

            ticket = z.create_ticket(self.session, data, form_response)
            ticket_url = 'https://%s.zendesk.com/tickets/%s' % (zendesk_options['zendesk_account'], ticket['ticket']['id'])

            if form_response:
                msg = self.session.get_resource('chat.message.zendesk_ticket_created', **{'ticket_id': str(ticket['ticket']['id']), 'ticket_url': ticket_url})
                msg_kind = Message.Kind.INFO if form_response['visitorShouldSeeTicketId'] else Message.Kind.FOR_OPERATOR
            elif data:
                msg = self.session.get_resource('chat.message.zendesk_ticket_created.for_operator',
                                                **{'ticket_id': str(ticket['ticket']['id']), 'ticket_url': ticket_url})
                msg_kind = Message.Kind.FOR_OPERATOR
            else:
                msg = self.session.get_resource('chat.message.zendesk_ticket_created.for_operator',
                                                **{'ticket_id': str(ticket['ticket']['id']), 'ticket_url': ticket_url})
                msg_kind = Message.Kind.FOR_OPERATOR

            Message.create(self, msg_kind, None, msg, aux=None, data={'ticket_info': ticket['ticket']})
        except ZendeskException as e:
            Message.create(self, Message.Kind.FOR_OPERATOR,
                           None, self.session.get_resource('chat.message.zendesk_ticket_error'), aux=None,
                           data={'error': e.error})

    def send_history_to_external_handler(self, handler_url_setting_name):
        handler_url = self.session.account.get_setting(handler_url_setting_name)
        if not handler_url:
            logging.info(handler_url_setting_name + ' hasn\'t set')
            return
        time_to_iso = lambda t: time.strftime('%Y-%m-%dT%H:%M:%SZ', time.gmtime(t))

        result = {"created_at": time_to_iso(self.creation_ts),
                  "id": self.id,
                  "category": self.category,
                  "subcategory": self.subcategory,
                  "locale": self.session.lang,
                  "department_key": self.session.department_key}

        operator = self.get_operator()

        if operator:
            result['operator'] = {"email": operator.email,
                                  "name": operator.fullname,
                                  "id": operator.id}
        messages = []
        for m in self.messages:
            message = {"created_at": time_to_iso(m.ts),
                       "kind": m.kind,
                       "message": m.text}
            if m.author_id:
                message["operator_id"] = m.author_id
            messages.append(message)

        if self.session.account.get_setting('chat_event_handlers_version') >= 2:
            v = self.session.visitor
            visitor = {'id': v.id, 'fields': v.get_merged_fields()}
            if v.channel_id and v.channel_type:
                visitor['channel'] = {'id': v.channel_id,
                                      'type': v.channel_type,
                                      'user_id': v.channel_user_id}
        else:
            visitor = self.session.visitor.get_merged_fields()
        result['messages'] = messages
        result['visitor'] = visitor
        result['visit_session'] = {'ip': self.session.ip,
                                   'landing_page': {
                                       'url': self.session.landing_page.url} if self.session.landing_page else None}
        result['start_page'] = {'url': self.start_page.url} if self.start_page else None
        data = {'chat': json.dumps(result, ensure_ascii=True).encode('utf-8')}

        m = hashlib.md5()
        m.update(data['chat'])
        m.update(self.session.account.get_setting('private_key')[0])
        data['crc'] = m.hexdigest()

        wm_utils.external_request(handler_url, data)
        logging.warn('Chat was sent to external handler ' + handler_url_setting_name + ' ' + handler_url)

    def store_global_chat(self):
        try:
            # global chat storing disabled hardcodely
            if True or self.session.account.name == 'sportmasterru':
                return

            messages = [self.format_message_for_history(message) for message in self.messages]
            text = wm_utils.cut_string('\n'.join(messages), 32000)
            global_chat = GlobalChat(
                self.session.account.name, self.session.ip, text, self.creation_ts, self.session.id, self.session.user_agent, self.session.get_platform_str()
            )
            self.session.account.background_storager.add_object_to_store(global_chat)
        except Exception:
            logging.error('Failed to store global chat. Account name: %s, session id: %s', self.session.account.name, self.session.id, exc_info=True)

    def store(self):
        self.session.account.background_storager.store(
            self, background=not self.offline or self.id or not self.session.account.get_setting('store_visitor_offline_message_immediately'))

    def delete(self):
        self.process_event('sys.close')
        self.process_event('visitor.delete')

    def post_chat_history_record(self, event=None):
        a = self.session.account
        self.__last_history_record_number += 1
        office_id = self.get_operator().office_id if self.get_operator() else None
        dep = a.get_department(self.session.department_key, avoid_empty_dep=True)
        record = ChatHistoryRecord(self, self.__last_history_record_number, self.state, self.__operator_id, dep and dep.id, self.session.lang, event, office_id)
        a.background_storager.store(record)

    def process_visitor_ping(self):
        self.process_event('visitor.ping')

    def is_in_queue(self):
        return self.session.account.queue_manager.get_chat_queue_id(self)

    def check_operator_busy(self):
        if self.state == Chat.State.QUEUE:
            agent_cant_pick_timeout = self.session.account.get_setting('agent_cant_pick_timeout',
                                                                       self.session.account.get_department(self.session.department_key, avoid_empty_dep=True))
            if not agent_cant_pick_timeout:
                return
            busy = self.modification_ts + agent_cant_pick_timeout < time.time()
        else:
            agent_busy_timeout = self.session.account.get_setting('agent_busy_timeout',
                                                                  self.session.account.get_department(self.session.department_key, avoid_empty_dep=True))
            if not agent_busy_timeout:
                return
            busy = self.unread_by_operator_since_ts and max(self.unread_by_operator_since_ts, self.modification_ts) + agent_busy_timeout < time.time()

        if busy:
            if self.session.account.get_setting('unassign_chat_if_operator_busy') and self.get_operator_id():
                current_oo = self.session.account.oo_manager.get(self.get_operator_id())

                if current_oo and current_oo.is_online():
                    status = self.session.account.get_setting('status_for_busy_operator')
                    current_oo.set_all_devices_status(status, status_reason='unread-chat-timeout')
                    current_oo.update_status()  # in device.set_status() update_status invoked async

                wm_timer.invoke_async(self.unassign_chat_if_operator_busy)
            else:
                online_inf = self.session.account.oo_manager.get_online_inf()
                if False and online_inf and online_inf.get_operator() and online_inf.operator_id != self.get_operator_id():
                    # возврат инфу пока отключаем, т.к. работает некорректно - если включать обратно, то нужно сделать, чтобы чат возвращался только если
                    # инф был уже в этом чате (как один из вариантов) + менять отдел на отдел, в котором есть инф.
                    wm_timer.invoke_async(lambda: self.process_event('sys.redirect_to_inf', {'operator_id': online_inf.operator_id}))
                else:
                    if self.session.account.get_setting('auto_assign') and self.is_in_queue():
                        if not self.session.account.oo_manager.get_online_state(self.session.lang, self.session.department_key) in [
                                wm_operator.OnlineState.OFFLINE, wm_operator.OnlineState.BUSY_OFFLINE]:
                            return

                    self.__post_operator_busy_message()

    def unassign_chat_if_operator_busy(self):
        self.process_event('sys.unassign')
        if self.session.account.oo_manager.get_online_state(self.session.lang, self.session.department_key) in [
                wm_operator.OnlineState.OFFLINE, wm_operator.OnlineState.BUSY_OFFLINE]:
            self.__post_operator_busy_message()
        else:
            self.session.account.get_auto_assign_controller(self.offline).set_auto_assign_required()

    def __post_operator_busy_message(self):
        if not self.operator_busy_message_posted:
            agent_busy_text = self.session.account.get_localized_setting('agent_busy_text', self.session.lang, department_key=self.session.department_key)
            if agent_busy_text:
                Message.create(self, Message.Kind.OPERATOR_BUSY, None, agent_busy_text)
                self.operator_busy_message_posted = True

    def check_can_be_closed_by_operator(self):
        result = 'ok'
        can_be_closed = False
        account = self.session.account
        if self.get_operator() and self.get_operator().is_robot():
            can_be_closed = True
        elif account.is_category_mandatory() and not self.is_category_set():
            result = 'category_has_to_be_set'
        elif account.get_setting('manual_operator_assign') and not self.manually_assigned_operator_id and len(self.operators_in_chat) > 1:
            result = 'operator_has_to_be_assigned'
        else:
            can_be_closed = True
        return can_be_closed, result

    def send_operator_busy_notification(self):
        if self.session.account.name == 'prologyru':
            return
        formatted_messages = [self.format_message_for_history(message) for message in self.messages]
        operator_info = self.get_operator().get_operator_info_str(lang=self.session.lang) if self.get_operator() else ''
        wm_mail.mailer.send_operator_busy_notification(
            self.session.account,
            {'visitor_name': self.session.visitor.get_name(), 'chat_history': '\n'.join(formatted_messages), 'info': operator_info}
        )

    def get_visitor_message_count(self):
        return len([m for m in self.messages if m.kind == Message.Kind.VISITOR])

    def to_dict(self, context=None):
        context = context or {}
        mode = context.get('mode')

        if mode == 'visitor.history':
            messages = [m.to_dict(context=context) for m in self.messages if m.visible_by_visitor() and not m.deleted]
            result = {
                'id': str(self.id),
                'clientSideId': self.client_side_id,
                'creationTs': self.creation_ts,
                'insertedTs': self.inserted_ts,
                'modificationTs': self.modification_ts,
                'offline': self.offline,
                'unreadByVisitorSinceTs': self.unread_by_visitor_since_ts,
                'subject': self.subject,
                'messages': messages
            }
        elif mode == 'db':
            result = {
                'clientSideId': self.client_side_id,
                'startPage': self.start_page.to_dict(context=context) if self.start_page else None,
                'unreadByVisitorSinceTs': self.unread_by_visitor_since_ts,
                'subject': self.subject,
                'requestedForm': self.requested_form,
                'amocrmId': self.amocrm_id,
                'zohocrmId': self.zohocrm_contact_id
            }
            if self.external_data.get('json_robot_current_state'):
                result['json_robot_current_state'] = self.external_data.get('json_robot_current_state')
        else:
            messages = [m.to_dict(context=context) for m in self.messages if (mode != 'visitor' or m.visible_by_visitor()) and not m.deleted]
            ratings = {operator_id: {
                'rating': rate.value,
                'operatorId': operator_id
            } for operator_id, rate in self.operator_id_to_operator_rate.items()}
            result = {
                'id': self.id,
                'clientSideId': self.client_side_id,
                'state': self.state,
                'offline': self.offline,
                'creationTs': self.prepare_ts(self.creation_ts, context),
                'visitorTyping': self.visitor_typing,
                'visitorMessageDraft': self.visitor_message_draft,
                'readByVisitor': self.unread_by_visitor_since_ts is None,  # todo remove
                'unreadByVisitorSinceTs': self.prepare_ts(self.unread_by_visitor_since_ts, context),
                'unreadByVisitorMsgCnt': self.unread_by_visitor_msg_cnt,
                'operatorTyping': self.operator_typing,
                'unreadByOperatorSinceTs': self.prepare_ts(self.unread_by_operator_since_ts, context),
                'subject': self.subject,
                'category': self.category,
                'subcategory': self.subcategory,
                'messages': messages,
                'requestedForm': self.requested_form,
                'operatorIdToRate': ratings,
                'needToBeClosed': self.need_to_be_closed
            }

            if mode == 'operator':
                result['operatorHints'] = self.operator_hints
                result['lastOperatorAssignedTs'] = self.prepare_ts(self.last_operator_assigned_ts, context)
                result['stateModifiedTs'] = self.prepare_ts(self.state_modified_ts, context)

            operator = self.get_operator()
            result['operator'] = operator.to_dict() if operator else None

        return result

    def send_offline_response_to_visitor(self, operator_message):
        visitor_email = self.session.visitor.fields.get('email', None)
        if not visitor_email:
            return

        visitor_message = None
        for m in self.messages:
            if m.kind == Message.Kind.VISITOR:
                visitor_message = m
                break

        wm_mail.mailer.send_offline_response_to_visitor(
            self.session.account,
            self.session.account.get_department(self.session.department_key),
            visitor_email,
            {
                'visitor_name': self.session.visitor.get_name(),
                'visitor_message': visitor_message.text if visitor_message else '',
                'operator_name': operator_message.name,
                'operator_message': operator_message.text,
            },
            self.session.lang
        )
        Message.create_from_resource(self, Message.Kind.FOR_OPERATOR, None, 'chat.message.sent_message_to_visitor_email', True, **{'email': visitor_email})

    def send_history_to_visitor(self, visitor_email):
        messages = [self.format_message_for_history(message) for message in self.messages if message.visible_by_visitor()]
        wm_mail.mailer.send_chat_history_to_visitor(
            self.session.account,
            self.session.account.get_department(self.session.department_key),
            visitor_email,
            {'visitor_name': self.session.visitor.get_name(), 'chat_history': '\n'.join(messages), 'info': ''},
            self.session.lang
        )

    def send_history_to_operator(self, target_operator_id):
        session = self.session
        operator = self.session.account.get_operator(self.__operator_id)
        target_operator = self.session.account.get_operator(target_operator_id)
        messages = [session.chat.format_message_for_history(message) for message in session.chat.messages]
        chat_url = 'http://' + session.account.name + '.' + wm_settings.settings['base_domain'] + '/webim/operator/threadprocessor.php?threadid=' + str(self.id)
        if session.chat:
            wm_mail.mailer.send_chat_history_to_operator(session.account, session.account.get_department(session.department_key), target_operator.email,
                                                         {'visitor_name': session.visitor.get_name(),
                                                          'target_operator_fullname': target_operator.fullname,
                                                          'operator_fullname': operator.fullname,
                                                          'chat_history': '\n'.join(messages),
                                                          'url': chat_url,
                                                          'info': ''},
                                                         session.lang)
            message_text = session.get_resource('chat.message.chat_sent_to_operator', target_operator.fullname)
            Message.create(session.chat, Message.Kind.FOR_OPERATOR, operator.get_visible_name(session.lang), message_text, operator.id)

    def process_operator_rate(self, rate):
        if rate.value < 0:
            account = self.session.account
            if account.settings.get('send_operator_rate_mail_immediately'):
                self.send_negative_operator_rate_mail(rate_value=rate.value, operator_id=rate.operator_id)
        else:
            logging.info('Visitor was happy')
        self.session.account.background_storager.add_object_to_store(rate)
        d = delta.Delta('OPERATOR_RATE', delta.Delta.Event.UPDATE, self.session.id, {
            'operatorId': rate.operator_id,
            'rating': rate.value
        })
        self.session.delta_manager.add_delta(d)

    def send_negative_operator_rate_mail(self, rate_value, operator_id=None):
        self.stored_to_db_callbacks.add(lambda: self.__do_send_negative_operator_rate_mail(rate_value, operator_id))

    def __do_send_negative_operator_rate_mail(self, rate_value, operator_id=None):
        messages = [self.format_message_for_history(message) for message in self.messages]
        chat_num = str(self.id)
        chat_url = 'http://' + wm_settings.get_full_domain_by_account_name(self.session.account.name, partner_name=None) + \
                   '/webim/operator/threadprocessor.php?threadid=' + str(self.id)
        if operator_id:
            operator = self.session.account.get_operator(operator_id)
            operator_info = operator.get_operator_info_str(lang=self.session.lang) if operator else ''
        else:
            operator_info = self.get_operator().get_operator_info_str(lang=self.session.lang) if self.get_operator() else ''
        wm_mail.mailer.send_operator_rating(self.session.account,
                                            {'visitor': self.session.visitor.get_name(),
                                             'chat_history': '\n'.join(messages),
                                             'chat_link': chat_url,
                                             'chat_num': chat_num,
                                             'info': operator_info,
                                             'rate_value': self.get_resource('rate.' + str(rate_value))},
                                            self.session.account.get_department(self.session.department_key))

    def post_chat_redirected_to_department_message(self, produce_delta=True):
        if not self.session.account.get_setting('show_chat_department_info_messages'):
            return

        if not self.get_operator():
            return

        department = self.session.account.get_department(self.session.department_key).get_name()
        operator_name = self.get_operator().get_fullname(self.session.lang)
        Message.create_from_resource(self, Message.Kind.FOR_OPERATOR, None, 'chat.message.redirect_to_department', produce_delta, *[operator_name, department])

    def format_message_for_history(self, message):
        text = message.text
        if message.kind in [Message.Kind.FILE_OPERATOR, Message.Kind.FILE_VISITOR]:
            message_data = json.loads(message.text)
            filename = urllib.quote(message_data['filename'].encode('utf-8'))
            download_url = 'http://' + wm_settings.get_full_domain(self.session.account, public=True) + '/l/v/download/' + message_data['guid'] + '/' + filename
            text = '%s - %s %s' % (
                self.get_resource('chat.operator_sent_file' if message.kind == Message.Kind.FILE_OPERATOR else 'chat.visitor_sent_file'),
                message_data['filename'],
                download_url if not self.session.account.get_setting('check_visitor_auth') else ''
            )
        if message.kind == Message.Kind.CONTACTS:
            visitor_fields = json.loads(message.text)
            text = self.get_resource('chat.visitor_sent_contacts')
            first = True
            for field in visitor_fields:
                if visitor_fields[field]:
                    text += (' ' if first else ', ') + self.get_resource('visitor_field.' + field) + ': ' + visitor_fields[field]
                    first = False

        return '%s %s%s%s' % (
            datetime.datetime.fromtimestamp(message.ts).strftime('%H:%M:%S'),
            message.name if message.name != '' else '',
            ': ' if message.name != '' else '',
            text
        )

    def get_resource(self, key, *args, **kwargs):
        return wm_resources.get_resource(self.session.account, self.session.lang, key, *args, **kwargs)

    @classmethod
    def post_offline_message(cls, visited_page, text, custom_fields, file_descs, category, subcategory, subject,
                             chat_client_side_id=None, message_client_side_id=None):
        if visited_page.visit_session.account.name == 'sportmasterru':
            return

        session = visited_page.visit_session.create_not_current_copy(visitor_tracking.VisitSession.Kind.OFFLINE_CHAT)
        visitor = session.visitor

        chat_start_params = visited_page.visit_session.chat_start_params
        logging.warn(
            'post_offline_message ' +
            str(visited_page.visit_session.id) + ' ' +
            str(visited_page.location) + ' ' +
            str(chat_start_params.get('department_key', None)) + ' ' +
            str(chat_start_params.get('force_without_department', False))
        )  # todo remove later
        department_key = '' if chat_start_params.get('force_without_department', False) else\
            chat_start_params['department_key'] if 'department_key' in chat_start_params else\
            visited_page.department_key

        session.set_department(department_key, visited_page.lang, produce_delta=False)
        state = Chat.State.OFFLINE_QUEUE if session.account.get_setting('offline_chat_processing') else Chat.State.CLOSED
        chat = Chat.create(session, visited_page, offline=True, state=state, subject=subject, client_side_id=chat_client_side_id)
        if session.account.name == 'prologyru':
            info_text = visitor.get_formatted_fields(session)
        else:
            info_text = chat.get_visitor_info_text(
                {
                    'nl': '\n',
                    'title': visited_page.title,
                    'url': visited_page.url,
                    'geo': session.ip_info.get_location_str(session.lang, session.get_resource('chat.message.visitor_info.geo_format')),
                    'browser': session.get_browser_str(),
                    'ip': session.ip,
                    'text': visitor.get_formatted_fields(session)
                }
            )
        if session.account.name == 'rolfmitsubishiru':
            if visited_page.department_key:
                department = session.account.get_department(visited_page.department_key)
                info_text += u"\nДилерский Центр: %s" % department.locale_to_name.get('ru', '')
            info_text += u"\nГород: %s" % custom_fields.get('city', '')
        elif session.account.name == 'mediasaturncom001' or session.account.name == '_mixey':
            info_text += u"\nМагазин: %s" % custom_fields.get('mediamarkt_store', '')

        offline_chat_accepted_message = session.account.settings.get('offline_chat_accepted_text')

        Message.create(chat, Message.Kind.FOR_OPERATOR, None, info_text, produce_delta=False)
        if session.platform != 'pochta':
            Message.create(chat, Message.Kind.FOR_OPERATOR, None, chat.get_resource('chat.message.visitor_left_offline_message'), produce_delta=False)
        if subject:
            Message.create(chat, Message.Kind.FOR_OPERATOR, None, chat.get_resource('chat.message.subject', subject), produce_delta=False)
        if text:
            Message.create(chat, Message.Kind.VISITOR, visitor.get_name(), text, produce_delta=False, client_side_id=message_client_side_id)
            message_client_side_id = None

        if offline_chat_accepted_message:
            Message.create(chat, Message.Kind.INFO, None, offline_chat_accepted_message, produce_delta=False)

        if file_descs:
            files_text = u'\n' + chat.get_resource('chat.message.visitor_attached_files')
            for file in file_descs:
                Message.create(chat, Message.Kind.FILE_VISITOR, visitor.get_name(), json.dumps(file),
                               produce_delta=False, client_side_id=message_client_side_id)
                message_client_side_id = None
                filename = urllib.quote(file['filename'].encode('utf-8'))
                if not session.account.get_setting('check_visitor_auth'):
                    download_url = 'http://' + wm_settings.get_full_domain(session.account, public=True) + '/l/v/download/' + file['guid'] + '/' + filename
                    files_text += u"\n" + download_url

            info_text = files_text + "\n\n" + info_text

        if category or subcategory:
            chat.set_category(category, subcategory)

        session.set_chat(chat, produce_delta=False)

        if not chat.try_auto_close(produce_delta=False):
            session.account.visit_tracker.add_session(session)

        chat.store_global_chat()

        wm_timer.invoke_async(lambda: session.account.integration_manager.on_chat_finished(chat), 'integration.on_chat_finished')
        wm_mail.mailer.send_offline_message(session.account,
                                            {'visitor_name': visitor.get_name(),
                                             'email': visitor.fields.get('email', 'noreply@webim.ru'),
                                             'info': info_text,
                                             'message': text,
                                             'session_lang': session.lang},
                                            session.account.get_department(session.department_key))

        return chat

    @classmethod
    def get_previous_chats_count(cls, account_name, visitor_id):
        conn = db_utils.get_connection(account_name)
        result = conn.get(
            'select count(*) cnt from chatthread th join chatvisitsession s on s.visitsessionid = th.visitsessionid where s.visitorid = %s',
            visitor_id
        )
        conn.close()
        return result['cnt']

    @classmethod
    def load_not_closed_chats(cls, account, offline):
        logging.warn('@' + account.name + ' load_not_closed_chats offline=' + str(offline))
        chat_query_common_part = "from chatthread th join chatvisitsession s on s.visitsessionid = th.visitsessionid where " + \
                                 "th.offline = " + str(int(offline)) + " and th.state not in ('" + Chat.State.CLOSED + "', '" + Chat.State.DELETED + "')" + \
                                 " and s.json is not null order by threadid asc"
        conn = db_utils.get_connection(account.name)
        conn.execute('SET SQL_BIG_SELECTS=1')

        logging.warn('@' + account.name + ' load_not_closed_chats processing query: select th.* ' + chat_query_common_part)
        rows = conn.query("select th.* " + chat_query_common_part)

        chat_id_subquery = "(select th.threadid " + chat_query_common_part + ") th"

        chat_id_to_message_rows = Chat.__load_chat_id_to_rows_dict(
            account, conn, "select * from chatmessage m join " + chat_id_subquery + " on th.threadid = m.threadid order by m.messageid")
        chat_id_to_operator_rate_rows = Chat.__load_chat_id_to_rows_dict(
            account, conn, "select * from chatrate r join " + chat_id_subquery + " on th.threadid = r.threadid where deldate is NULL")
        chat_id_to_history_rows = Chat.__load_chat_id_to_rows_dict(
            account, conn, "select h.*, d.departmentkey from chatthreadhistory h left join chatdepartment d on d.departmentid=h.departmentid "
                           "join " + chat_id_subquery + " on th.threadid = h.threadid")
        chat_id_to_session_rows = Chat.__load_chat_id_to_rows_dict(
            account, conn, "select s.*, th.threadid from chatvisitsession s "
                           "join (select th.threadid, th.visitsessionid " + chat_query_common_part + ") th on th.visitsessionid = s.visitsessionid")

        i = 0
        start_ts = time.time()  # todo remove

        logging.warn('@' + account.name + ' load_not_closed_chats loaded ' + str(len(rows)) + ' chats rows')
        for row in rows:
            # noinspection PyBroadException
            try:
                session_id = row['visitsessionid']
                if not offline and account.visit_tracker.get_session(session_id):
                    continue

                chat_id = row['threadid']
                ch = cls.__load_chat(account, row,
                                     chat_id_to_session_rows[chat_id][0],
                                     chat_id_to_message_rows.get(chat_id),
                                     chat_id_to_history_rows.get(chat_id),
                                     chat_id_to_operator_rate_rows.get(chat_id),
                                     try_auto_close=True)
                if not ch:
                    continue

                if ch.state in [Chat.State.CLOSED, Chat.State.DELETED]:
                    # this case can occur when db contains wrong data: last_thread_history.status == 'closed' and thread.status != closed
                    # - we select chats from db by thread.status but fill ch.status with last_thread_history.status
                    # so we load "wrong" (closed) chat, but here it has right status
                    # and we can filter it out and fix thread.status in db by invoking ch.store()
                    ch.store()
                    continue

                # трешим пустые чаты
                trash = ch.state in [Chat.State.QUEUE, Chat.State.OFFLINE_QUEUE]
                trash = trash and not [m for m in ch.messages if m.kind in Message.Kind.VISITOR_AND_OPERATOR_KINDS]
                trash = trash and ch.creation_ts <= time.time() - 3600
                if trash:
                    ch.state = Chat.State.CLOSED
                    ch.external_data['skip'] = True
                    ch.store()
                    continue

                #     ch.process_event('operator.redirect_to_department', produce_delta=False)
                if ch.get_operator_id():
                    o = account.get_operator(ch.get_operator_id())
                    if not o or not o.matches((ch.session.lang, ch.session.department_key)):
                        if not o or not o.is_robot:
                            ch.process_event('sys.unassign')

                account.visit_tracker.add_session(ch.session)

                i += 1
                if i % 250 == 0:
                    Chat.try_auto_assign_chats_in_queue(account, offline=offline)
                    logging.warn('@' + account.name + ' load_not_closed_chats processed ' + str(i) + ' chats in ' + str(time.time() - start_ts) + ' seconds')
            except Exception:
                logging.error('Failed to load chat. Account name: %s, chat id: %s', account.name, row['threadid'], exc_info=True)

        conn.close()
        Chat.try_auto_assign_chats_in_queue(account, offline=offline)

    @staticmethod
    def __load_chat_id_to_rows_dict(account, conn, query):
        logging.warn('@' + account.name + ' load_not_closed_chats processing query: ' + query)
        rows = conn.query(query)
        result = wm_utils.DictExt(lambda k: [])
        for row in rows:
            result.get(row['threadid']).append(row)
        return result

    @classmethod
    def load_chat(cls, account, chat_id):
        conn = db_utils.get_connection(account.name)
        row = conn.get('select * from chatthread where threadid=%s', chat_id)

        session_row = conn.get('select * from chatvisitsession where visitsessionid = %s', row['visitsessionid'])
        message_rows = conn.query('select * from chatmessage where threadid = %s order by messageid', chat_id)
        operator_rate_rows = conn.query('select * from chatrate where threadid = %s and deldate is NULL', chat_id)
        history_rows = conn.query('select h.*, d.departmentkey from chatthreadhistory h '
                                  'left join chatdepartment d on d.departmentid=h.departmentid where threadid = %s', chat_id)

        result = cls.__load_chat(account, row, session_row, message_rows, history_rows, operator_rate_rows) if row else None
        conn.close()
        return result

    @classmethod
    def __load_chat(cls, account, chat_row, session_row, message_rows, history_rows, operator_rate_rows, try_auto_close=False):
        session = visitor_tracking.VisitSession.create_loaded(
            account, session_row, visitor_tracking.VisitSession.Kind.OFFLINE_CHAT if bool(chat_row['offline']) else visitor_tracking.VisitSession.Kind.ONLINE
        )
        session.loading = True

        last_operator_assigned_ts = None
        chat_ops_ids = set()
        last_history_row = None
        for history_row in history_rows:
            if history_row['operatorid']:
                chat_ops_ids.add(history_row['operatorid'])
            if not last_history_row or last_history_row['number'] < history_row['number']:
                last_history_row = history_row
                if last_history_row['event'] == 'operator.accept':
                    last_operator_assigned_ts = int(last_history_row['dtm'].strftime('%s'))

        if not last_history_row:
            return None

        ch = Chat.create_loaded(session, chat_row, last_history_row, message_rows, chat_ops_ids, operator_rate_rows)

        ch.update_last_operator_assigned_ts(last_operator_assigned_ts, produce_delta=False)
        ch.update_state_modified_ts(int(last_history_row['dtm'].strftime('%s')), produce_delta=False)
        session.set_department(last_history_row['departmentkey'], last_history_row['locale'], produce_delta=False)
        if ch.state not in {Chat.State.CLOSED, Chat.State.DELETED}:
            session.set_chat(ch, produce_delta=False)
        session.loading = False

        if try_auto_close:
            if ch.try_auto_close(produce_delta=False):
                ch = None

        return ch

    def is_category_set(self):
        return True if self.category or self.subcategory else False

    @classmethod
    def close_expired_chats(cls):
        threshold_ts_default = time.time() - 10 * 60  # 10 min

        threshold_ts_for_left_site = time.time() - 2 * 60  # 2 min

        for ch in cls.get_instances():
            try:
                s = ch.session
                a = s.account

                threshold_ts = time.time() - 2 * 24 * 60 * 60 if a.name == 'promo' else \
                    time.time() if a.name == 'prologyru' else \
                    threshold_ts_default
                if ch.state == Chat.State.CLOSED_BY_VISITOR and ch.modification_ts < threshold_ts:
                    if a.settings.get('auto_close_chat_by_timeout') and (not a.is_category_mandatory() or ch.is_category_set()):
                        ch.process_event('sys.close_by_timeout')

                # todo think about it later (there is a broblem with chats with robot - it not closes them )
                # if not s.on_site.get() and a.settings.get('visitor_can_close_chat'):
                if not s.on_site.get():
                    if ch.state in [Chat.State.QUEUE, Chat.State.CHATTING, Chat.State.CHATTING_WITH_ROBOT,
                                    Chat.State.CLOSED_BY_OPERATOR, Chat.State.INVITATION]:
                        threshold_ts = time.time() - a.get_setting('timeout_for_chat_auto_close_if_visitor_left_for_mobile') if s.mobile else threshold_ts_for_left_site  # noqa: E501
                        if s.on_site.get_last_gone_away_ts() < threshold_ts:
                            ch.process_event('visitor.left_site_erewhile')

                # todo не нужно держать открытыми мобильные чаты
                # todo тут мы пока не готовы держать открытыми чаты CLOSED_BY_OPERATOR, это можно делать только в ветке для ткс, т.к. там есть скрывание
                # if ch.state == Chat.State.CLOSED_BY_OPERATOR and not ch.unread_by_visitor_since_ts or ch.state == Chat.State.INVITATION:
                if ch.state == Chat.State.CLOSED_BY_OPERATOR or ch.state == Chat.State.INVITATION:
                    timeout = a.get_setting('timeout_for_chat_auto_close_if_closed_by_operator', a.get_department(ch.session.department_key, avoid_empty_dep=True))

                    if timeout and ch.modification_ts < time.time() - timeout:
                        ch.process_event('sys.close_by_timeout')

                cls.set_need_to_be_closed_if_necessary(ch)
            except Exception as e:
                logging.error('close_expired_chats failed for chat %s: %s' % (str(ch.id or None), str(e)), exc_info=True)

    @classmethod
    def set_need_to_be_closed_if_necessary(cls, ch):
        a = ch.session.account
        timeout = a.get_setting('timeout_for_chat_auto_close_if_chat_is_inactive', a.get_department(ch.session.department_key, avoid_empty_dep=True))

        if ch.state in [Chat.State.CHATTING, Chat.State.CHATTING_WITH_ROBOT, Chat.State.INVITATION, Chat.State.CLOSED_BY_VISITOR]:
            msg = ch.messages[-1] if ch.messages else None
            if time.time() - ch.last_activity_ts >= timeout:
                if ch.check_can_be_closed_by_operator()[0]:
                    ch.process_event('sys.close_by_timeout')
                else:
                    ch.set_need_to_be_closed(True)
            elif time.time() - ch.last_activity_ts >= timeout - min(60, timeout / 2) \
                    and not (msg and msg.data and msg.data.get('subKind') == 'closure-warning'):
                Message.create(ch, Message.Kind.INFO, None, ch.get_resource('chat.message.closure_warning'),
                               data={'subKind': 'closure-warning'})

    @classmethod
    def unassign_chats_from_offline_operators(cls):
        for ch in cls.get_instances():
            chat_unassign_from_offline_operators_timeout = ch.session.account.get_setting('chat_unassign_from_offline_operators_timeout')
            if chat_unassign_from_offline_operators_timeout is None:
                continue

            if ch.get_operator_id() and ch.state in [Chat.State.OFFLINE_QUEUE, Chat.State.OFFLINE_PROCESS, Chat.State.QUEUE, Chat.State.CHATTING]:
                threshold_ts = time.time() - chat_unassign_from_offline_operators_timeout
                if not ch.session.account.initialization_ts or (ch.session.account.initialization_ts > threshold_ts):
                    continue

                oo = ch.session.account.oo_manager.get(ch.get_operator_id())
                if oo and oo.is_offline():

                    if oo.status_modified_ts and oo.status_modified_ts > threshold_ts:
                        continue

                    ch.process_event('sys.unassign')

    @classmethod
    def unassign_chats_if_operator_not_in_department(cls, account, o):
        filter = lambda ch: ch.get_operator_id() == o.id
        for ch in account.visit_tracker.get_chats(filter, True):  # todo get all chats - not only offline:
            if not o.matches((ch.session.lang, ch.session.department_key)):
                ch.process_event('sys.unassign')

    @classmethod
    def unset_deleted_department_in_chats(cls, account, department):
        filter = lambda ch: ch.session.department_key == department.key
        for ch in account.visit_tracker.get_chats(filter):
            ch.process_event('sys.unset_department')

    @classmethod
    def ping_chats(cls):
        for ch in cls.get_instances():
            try:
                if ch and ch.state not in [Chat.State.CLOSED]:
                    ch.process_visitor_ping()
            except Exception:
                logging.warn('Failed to ping chat: id %d account %s' % (ch.id, ch.session.account.name))

    # todo optimize may be (not all accounts use routing)
    @classmethod
    def check_routing_chats(cls):
        for ch in cls.get_instances():
            # if chat routing too long -> move to queue (if db is dead, for example)
            if ch.state == Chat.State.ROUTING and time.time() - ch.creation_ts >= 30:
                logging.warn('Failed to route chat: chat moved to queue')
                ch.process_event('sys.routing_failed')


wm_timer.invoke_periodically(30, Chat.close_expired_chats, 'Expired chats closer')
wm_timer.invoke_periodically(30, Chat.unassign_chats_from_offline_operators, 'unassign_chats_from_offline_operators')
wm_timer.invoke_periodically(5, Chat.ping_chats, 'chat_pinger')
# wm_timer.invoke_periodically(10, Chat.check_routing_chats, 'check_routing_chats')


class Message(wm_utils.InstanceCountTracker, wm_utils.Jsonable):

    class Kind:
        VISITOR = 'visitor'
        OPERATOR = 'operator'
        FOR_OPERATOR = 'for_operator'
        INFO = 'info'
        OPERATOR_BUSY = 'operator_busy'
        CONT_REQ = 'cont_req'
        CONTACTS = 'contacts'
        FILE_OPERATOR = 'file_operator'
        FILE_VISITOR = 'file_visitor'
        FORM_RESPONSE = 'form_response'
        OPERATOR_NOTE = 'operator_note'
        ACTION_REQUEST = 'action_request'

        VISITOR_KINDS = frozenset([VISITOR, FILE_VISITOR, CONTACTS, FORM_RESPONSE])
        OPERATOR_KINDS = frozenset([OPERATOR, FILE_OPERATOR, CONT_REQ])
        VISITOR_AND_OPERATOR_KINDS = frozenset(VISITOR_KINDS | OPERATOR_KINDS)
        ONLY_VISIBLE_BY_OPERATOR = frozenset([FOR_OPERATOR, OPERATOR_NOTE])
        ONLY_VISIBLE_BY_OPERATOR_NUMS = []

        NAME_TO_NUM = {
            VISITOR: 1,
            OPERATOR: 2,
            FOR_OPERATOR: 3,
            INFO: 4,
            OPERATOR_BUSY: 9,
            CONT_REQ: 10,
            CONTACTS: 11,
            FILE_OPERATOR: 13,
            FILE_VISITOR: 14,
            FORM_RESPONSE: 15,
            OPERATOR_NOTE: 16,
            ACTION_REQUEST: 17
        }

        for n in ONLY_VISIBLE_BY_OPERATOR:
            ONLY_VISIBLE_BY_OPERATOR_NUMS.append(NAME_TO_NUM[n])

        NUM_TO_NAME = dict([[v, k] for k, v in NAME_TO_NUM.items()])

    class ActionState:

        PENDING = 'pending'
        COMPLETED = 'completed'
        IGNORED = 'ignored'

    def __init__(self, chat, id, kind, name, text, author_id, ts, modified_ts, aux=None, data=None, client_side_id=None, deleted=None):
        super(Message, self).__init__()
        self.id = id
        self.client_side_id = client_side_id or uuid.uuid4().hex
        self.db_id = None
        self.chat = chat
        self.kind = kind
        self.text = text
        self.ts = ts
        self.name = wm_utils.filter_4_byte_characters(name) if name else ''
        self.author_id = author_id
        self.session_id = chat.session.id
        self.aux = aux
        self.data = data
        self.read = kind not in Message.Kind.OPERATOR_KINDS  # implemented only for operator messages yet
        self.modified_ts = modified_ts
        self.deleted = deleted or False

        self.stored_to_db_callbacks = wm_callbacks.Callbacks(once=True, memory=True)

        self.event_consumer = self.get_consumer()

    @classmethod
    def create(cls, chat, kind, name, text, author_id=None, produce_delta=True, aux=None, data=None,
               store_in_background=True, client_side_id=None, deleted=None, send_push=True):

        m = Message(chat, chat.next_message_id(), kind, name, text, author_id, time.time(), time.time(),
                    aux=aux, data=data, client_side_id=client_side_id, deleted=deleted)

        if m.kind == Message.Kind.ACTION_REQUEST and not m.get_data('state'):
            m.set_data_field('state', Message.ActionState.PENDING, produce_delta=False)

        m.check_if_dont_require_response()
        m.check_markdown()

        storager = chat.session.account.background_storager
        storager.store(
            m, background=store_in_background and not
            (chat.offline and m.kind in Message.Kind.VISITOR_KINDS and chat.session.account.get_setting('store_visitor_offline_message_immediately'))
        )

        chat.add_message(m, produce_delta=produce_delta, send_push=send_push)

        ChatChecker.check_chat_string(text, chat)

        return m

    @classmethod
    def create_loaded(cls, chat, row):
        msg_json = json.loads(row.get('json') or '{}')
        data = msg_json.get('data', None)
        aux = msg_json.get('aux', None)

        created_ts = (row['createdts'] or 0) / 1e6 or wm_utils.get_ts(row['created'])
        modified_ts = row['modifiedts'] / 1e6
        result = Message(chat, chat.next_message_id(), Message.Kind.NUM_TO_NAME[row['kind']], row['sendername'], row['message'], row['operatorid'],
                         created_ts, modified_ts, data=data, aux=aux, client_side_id=msg_json.get('clientSideId'), deleted=msg_json.get('deleted', False))
        result.db_id = row['messageid']
        result.update_read(produce_delta=False)
        return result

    @classmethod
    def create_from_resource(cls, chat, kind, name, resource, produce_delta, *args, **kwargs):
        msg = chat.get_resource(resource, *args, **kwargs)
        if not msg:
            return

        Message.create(chat, kind, name, msg, produce_delta=produce_delta)

    def get_consumer(self):
        if self.kind == Message.Kind.ACTION_REQUEST:
            if self.get_data('subKind') == 'buttons':
                return MessageEventConsumer('buttons_message_consumer', self)

            return MessageEventConsumer('base_message_consumer', self)
        return None

    def get_data(self, key, default=None):
        return self.data.get(key, default) if self.data else default

    def set_data_field(self, key, value, produce_delta=True):
        if self.data is None:
            self.data = {}

        self.data[key] = value

        if produce_delta:
            d = delta.Delta('CHAT_MESSAGE', 'upd', self.id, self)
            d2 = delta.Delta('CHAT_MESSAGE_2', 'upd', [self.session_id, self.id], self)
            self.chat.session.add_operator_delta(d2)
            self.chat.session.delta_manager.add_delta(d)

    def visible_by_visitor(self):
        return self.kind not in self.Kind.ONLY_VISIBLE_BY_OPERATOR

    def update_message_in_db(self):
        if self.db_id is None:
            self.stored_to_db_callbacks.add(self.update_message_in_db)
        else:
            self.chat.session.account.background_storager.store(self)

    def update(self, new_text=None, data_changes=None, produce_delta=True):
        old_data = copy.deepcopy(self.data)

        if new_text:
            self.text = new_text

        if data_changes:
            self.data.update(data_changes)

        self.modified_ts = time.time()

        self.update_message_in_db()

        if produce_delta and (new_text or old_data != self.data):
            d = delta.Delta('CHAT_MESSAGE', 'upd', self.id, self)
            d2 = delta.Delta('CHAT_MESSAGE_2', 'upd', [self.session_id, self.id], self)
            self.chat.session.add_operator_delta(d2)
            self.chat.session.delta_manager.add_delta(d)

    def delete(self, produce_delta=True):
        if not self.deleted:
            self.deleted = True
            self.modified_ts = time.time()
            self.chat.session.account.background_storager.store(self)

            self.update_message_in_db()

        if produce_delta:
            d = delta.Delta('CHAT_MESSAGE', 'del', self.id, self)
            d2 = delta.Delta('CHAT_MESSAGE_2', 'del', [self.session_id, self.id], self)
            self.chat.session.add_operator_delta(d2)
            self.chat.session.delta_manager.add_delta(d)

    def update_read(self, produce_delta=True):
        if self.kind in Message.Kind.OPERATOR_KINDS:
            read = self.chat.unread_by_visitor_since_ts is None or self.ts < self.chat.unread_by_visitor_since_ts
            if self.read != read:
                self.read = read
                if produce_delta:
                    d = delta.Delta('MESSAGE_READ', 'upd', [self.session_id, self.id], read)
                    self.chat.session.add_operator_delta(d)

    def check_if_dont_require_response(self):
        if self.kind in Message.Kind.VISITOR_KINDS and self.chat and self.chat.session.account.get_setting('visitor_messages_not_requiring_response'):
            if self.text.lower() in self.chat.session.account.get_setting('visitor_messages_not_requiring_response'):
                self.set_data_field('dont_require_response', True, produce_delta=False)

    @staticmethod
    def replace_markdown_if_not_supported(match, markdown_type):
        if markdown_type == 'hyperlink':
            return "%s %s" % (match.group(1), match.group(2))

    def to_dict(self, context=None):
        context = context or {}
        mode = context.get('mode')
        session = self.chat.session

        name = self.name
        avatar = None
        if mode in ['operator', 'visitor', 'visitor.history', 'visitor.push'] and self.kind in Message.Kind.OPERATOR_KINDS and self.author_id is not None:
            operator = session.account.get_operator(self.author_id)
            if operator:
                if mode == 'operator':
                    name = operator.get_fullname(session.lang)
                avatar = operator.avatar

        text = self.text

        if mode in ['visitor', 'visitor.history', 'visitor.push'] and self.data and self.data.get('markdowns'):
            for markdown_type in self.data.get('markdowns'):
                if session.platform != 'web' and not session.account.check_if_mobile_app_supports_feature(session.platform, session.app_version, markdown_type):
                    regex = wm_utils.MARKDOWNS_REGEXP[markdown_type]
                    text = regex.sub(lambda match: self.replace_markdown_if_not_supported(match, markdown_type), text)

        if mode == 'visitor.history':
            result = {
                'id': str(self.db_id),
                'clientSideId': self.client_side_id,
                'chatId': str(self.chat.id),
                'kind': self.kind,
                'ts': self.ts,
                'text': text,
                'name': name,
                'avatar': avatar,
                'authorId': self.author_id,
                'data': self.data
            }
        elif mode == 'visitor.push':
            result = {
                'kind': self.kind,
                'text': text,
                'name': name,
                'avatar': avatar,
                'clientSideId': self.client_side_id,
                'ts': self.prepare_ts(self.ts, context)
            }
        elif mode == 'db':
            result = {
                'data': self.data,
                'clientSideId': self.client_side_id,
            }

            if self.aux:
                result['aux'] = self.aux

            if self.deleted:
                result['deleted'] = self.deleted

        else:
            result = {
                'id': self.id,
                'clientSideId': self.client_side_id,
                'kind': self.kind,
                'name': name,
                'avatar': avatar,
                'authorId': self.author_id,
                'text': text,
                'sessionId': self.session_id,
                'ts': self.prepare_ts(self.ts, context),
                'modifiedTs': self.prepare_ts(self.modified_ts, context)
            }

            if self.aux:
                result['aux'] = self.aux

            if self.data:
                result['data'] = self.data

            if mode == 'operator':
                result['read'] = self.read

        return result

    def check_markdown(self):
        if self.chat.session.account.get_tariff_setting('markdown', False):
            if self.kind in [Message.Kind.OPERATOR, Message.Kind.VISITOR]:
                markdowns = []
                for markdown_type, regex in wm_utils.MARKDOWNS_REGEXP.items():
                    result = regex.search(self.text)
                    if result:
                        markdowns.append(markdown_type)

                if markdowns:
                    self.set_data_field('markdowns', markdowns)


class ChatHistoryRecord(wm_utils.InstanceCountTracker):

    def __init__(self, chat, number, state, operator_id, department_id, lang, event, office_id):
        super(ChatHistoryRecord, self).__init__()
        self.chat = chat
        self.ts = time.time()
        self.number = number
        self.state = state
        self.operator_id = operator_id
        self.department_id = department_id
        self.lang = lang
        self.event = event
        self.office_id = office_id


class OperatorRate(wm_utils.InstanceCountTracker):

    def __init__(self, operator_id, chat, value):
        super(OperatorRate, self).__init__()
        self.operator_id = operator_id
        self.chat = chat
        self.value = value
        self.ts = time.time()

    @classmethod
    def create_loaded(cls, rate_row):
        r = OperatorRate(rate_row['operatorid'], rate_row['threadid'], rate_row['rate'])
        r.ts = rate_row['date']

        return r


class ChatChecker:
    checked_chat_ids = []
    stop_words = ['livetex', u'лайфтекс', u'лайвтекст', 'jivosite', u'живосайт', u'марва', 'marva']

    @staticmethod
    def check_chat_string(string, chat):
        try:
            if chat.id in ChatChecker.checked_chat_ids:
                return
            lower_string = string.lower()
            for word in ChatChecker.stop_words:
                if word in lower_string:
                    ChatChecker.checked_chat_ids.append(chat.id)
                    messages = [chat.format_message_for_history(message) for message in chat.messages]
                    chat.stored_to_db_callbacks.add(
                        lambda: wm_mail.mailer.send_needle_words_in_chat_notification(
                            chat.session.account,
                            {
                                'found_word': word,
                                'account_name': chat.session.account.name,
                                'session_key': chat.session.id,
                                'chat_id': chat.id,
                                'chat_text': '\n'.join(messages)
                            }
                        )
                    )
                    return
        except Exception:
            logging.error('Failed to check string', exc_info=True)


class GlobalChat:
    def __init__(self, account_name, ip, chat_text, creation_ts, session_id, user_agent, platform):
        self.data = [account_name, ip, chat_text, datetime.datetime.fromtimestamp(creation_ts), session_id, user_agent, platform]
