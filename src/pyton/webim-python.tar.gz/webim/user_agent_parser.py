import time
import os
import sre_constants
import logging
import locale
import csv
import re
import json
from datetime import datetime

from ua_parser import user_agent_parser

import wm_settings
import wm_web


try:
    from cStringIO import StringIO
except ImportError:
    from StringIO import StringIO

from pybrowscap.loader import Browscap, TYPE_CSV

__all__ = [
    "PyBrowscap"
]
# Url where latest version of csv browscap data file is located
URL = 'http://browsers.garykeith.com/stream.asp?BrowsCapCSV'

BC_PATH = os.path.abspath(wm_settings.settings["browscap-path"])
BC_CSV_PATH = os.path.abspath(wm_settings.settings["browscap-csv-path"])

log = logging.getLogger(__name__)


class PyBrowscap(object):
    def __new__(cls, *args, **kwargs):
        # Only create one instance of this class
        if "instance" not in cls.__dict__:
            cls.instance = object.__new__(cls, *args, **kwargs)
            cls.instance.__my_init__()
        return cls.instance

    def __my_init__(self):
        self.browscap = None
        # self.on_parsing_finished_callbacks = wm_callbacks.Callbacks(once=True, memory=False)
        # if not wm_settings.settings.get('disable_browscap'):
        #     self.parse()
        # else:
        #     logging.warn('BROWSCAP disabled because of disable_browscap setting')


    def parse(self):
        pass
        # self.browscap = load_file(BC_CSV_PATH)
        # self.on_parsing_finished_callbacks.fire()

    def reload(self):
        pass
        # self.browscap.reload()

    def search(self, user_agent):
        res = user_agent_parser.Parse(user_agent)

        for field in ['major', 'minor']:
            if 'user_agent' in res and field in res['user_agent'] and res['user_agent'][field]:
                res['user_agent'][field] = int(res['user_agent'][field])

        return res

        # return self.browscap.search(user_agent) if self.browscap else None

    def browser_to_dict(self, user_agent):
        try:
            browser = self.search(user_agent)
            if browser and browser['os']['family'] != 'Other':
                ua = browser['user_agent']
                return {'name':  ua['family'], 'version': [ua['major'] or 0, ua['minor'] or 0], 'platform': browser['os']['family']}
            else:
                return None
        except:
                logging.error('browser_to_dict failed for user_agent: ' + str(user_agent), exc_info=True)
                return None

    __call__ = search

class UserAgentParseHandler(wm_web.AdminRequestHandler):
    def get(self, *args, **kwargs):
        bc = PyBrowscap()
        user_agent = self.get_argument('user-agent', None)
        if user_agent:
            try:
                b = bc(user_agent)
                result = {
                    'result': 'ok',
                    'ua': [b['user_agent']['family'], b['user_agent']['major'], None, None, b['os']['family']]
                }
            except:
                result = {
                    'result': 'error',
                    'reason': 'bad user-agent'
                }
        else:
            result = {
                'result': 'error',
                'reason': 'no user-agent param'
            }
        self.write(json.dumps(result))


def test():
    bc = PyBrowscap()

    start_time = time.time()
    bc("Mozilla/4.0 (compatible; MSIE 7.0; Windows NT 5.1; Trident/4.0; GTB6.6; .NET CLR 1.1.4322; .NET CLR 2.0.50727; .NET CLR 3.0.04506.30)")
    bc("Mozilla/4.0 (compatible; MSIE 7.0; Windows NT 5.1; Trident/4.0; GTB6.6; .NET CLR 1.1.4322; .NET CLR 2.0.50727; .NET CLR 3.0.04506.30)")
    bc("Mozilla/4.0 (compatible; MSIE 7.0; Windows NT 5.1; Trident/4.0; GTB6.6; .NET CLR 1.1.4322; .NET CLR 2.0.50727; .NET CLR 3.0.04506.30)")
    print("--- %s ms ---" % ((time.time() - start_time) * 1000 / 3))

    for agent in [
        "Mozilla/5.0 (iPhone; CPU iPhone OS 5_0 like Mac OS X) AppleWebKit/534.46 (KHTML, like Gecko) Version/5.1 Mobile/9A334 Safari/7534.48.3",
        "Mozilla/5.0 (Macintosh; Intel Mac OS X 10.6; rv:5.0) Gecko/20100101 Firefox/5.0",
        "Mozilla/5.0 (iPad; CPU OS 5_0 like Mac OS X) AppleWebKit/534.46 (KHTML, like Gecko) Version/5.1 Mobile/9A334 Safari/7534.48.3",
        "Mozilla/5.0 (Linux; Android 4.0.4; Galaxy Nexus Build/IMM76B) AppleWebKit/535.19 (KHTML, like Gecko) Chrome/18.0.1025.133 Mobile Safari/535.19",
       "Mozilla/5.0 (Windows NT 6.1; WOW64) AppleWebKit/534.24 (KHTML, like Gecko) Chrome/11.0.696.65 Safari/534.24",
       "Mozilla/5.0 (Windows NT 5.1) AppleWebKit/534.24 (KHTML, like Gecko) Chrome/11.0.696.68 Safari/534.24",
       "Mozilla/5.0 (compatible; Konqueror/3.5; Linux; X11; de) KHTML/3.5.2 (like Gecko) Kubuntu 6.06 Dapper",
       "Mozilla/5.0 (X11; U; Linux i686; de; rv:1.8.0.5) Gecko/20060731 Ubuntu/dapper-security Firefox/1.5.0.5",
       "Mozilla/4.0 (compatible; MSIE 7.0; Windows NT 5.1; Trident/4.0; GTB6.6; .NET CLR 1.1.4322; .NET CLR 2.0.50727; .NET CLR 3.0.04506.30)",
       "Mozilla/4.0 (compatible; MSIE 8.0; Windows NT 5.1; Trident/4.0; .NET CLR 2.0.50727; .NET CLR 3.0.4506.2152; .NET CLR 3.5.30729; .NET4.0C; .NET4.0E)",
       "Opera/9.80 (Windows NT 6.1; U; ru) Presto/2.7.62 Version/11.01",
       "Mozilla/5.0 (X11; U; Linux i686; en-US; rv:1.9.2.13) Gecko/20101206 Ubuntu/10.10 (maverick) Firefox/3.6.13 FirePHP/0.5", # mix
       "Mozilla/4.0 (compatible; MSIE 8.0; Windows NT 5.1; Trident/4.0; .NET CLR 1.1.4322; .NET CLR 2.0.50727; .NET CLR 3.0.4506.2152; .NET CLR 3.5.30729)",
       "Mozilla/5.0 (X11; U; Linux i686; en-US; rv:1.7.12) Gecko/20060216 Debian/1.7.12-1.1ubuntu2",
       "Mozilla/5.0 (X11; U; Linux i686; en-US; rv:1.8.0.5) Gecko/20060731 Ubuntu/dapper-security Epiphany/2.14 Firefox/1.5.0.5",
       "Opera/9.00 (X11; Linux i686; U; en)",
       "Wget/1.10.2",
       "Mozilla/5.0 (X11; Linux i686; U;) Gecko/20051128 Kazehakase/0.3.3 Debian/0.3.3-1",
       "Mozilla/5.0 (X11; U; Linux i386) Gecko/20063102 Galeon/1.3test",
       "Mozilla/4.0 (compatible; MSIE 6.0; Windows 98)" # Tested under Wine
      ]:
        b = bc(agent)
        if not b:
            print "!", agent
        else:
            print b['user_agent']['family'], b['user_agent']['major'], None, None, b['os']['family']


def update():
    pass
    # import urllib
    # urllib.urlretrieve("http://browsers.garykeith.com/stream.asp?BrowsCapINI",
    #                    BC_PATH)

#   Function "load_file" from pybrowscap.loader.csv with some bugfixes
def load_file(browscap_file_path):
    """
    Loading browscap csv data file, parsing in into accessible python
    form and returning a new Browscap class instance with all appropriate data.

    :param browscap_file_path: location of browcap file on filesystem
    :type browscap_file_path: string
    :returns: Browscap instance filled with data
    :rtype: pybrowscap.loader.Browscap

    """
    def replace_defaults(line, defaults):
        """Replaces 'default' values for a line with parent line value and converting it into native python value.

        :param line: original line from browscap file
        :type line: dict
        :param defaults: default values for current line
        :type defaults: dict
        :returns: dictionary with replaced default values
        :rtype: dict
        :raises: IOError

        """
        new_line = {}
        for feature, value in line.iteritems():
            if value == 'default' or value == '':
                value = defaults[feature]
            if value == 'true':
                value = True
            if value == 'false':
                value = False
            if feature == 'MinorVer' and value == '0':
                value = defaults[feature]
            if feature == 'MajorVer' or feature == 'MinorVer':
                try:
                    value = int(value)
                except (ValueError, OverflowError):
                    value = 0
            if (feature == 'Version' or feature == 'RenderingEngine_Version') and value == '0':
                value = defaults[feature]
            if (feature == 'CSSVersion' or feature == 'AolVersion' or feature == 'Version' or
                feature == 'RenderingEngine_Version' or feature == 'Platform_Version'):
                try:
                    value = float(value)
                except (ValueError, OverflowError):
                    value = float(0)
            new_line[feature.lower()] = value
        return new_line
    try:
        with open(browscap_file_path, 'rb') as csvfile:
            log.info('Reading browscap source file %s', browscap_file_path)
            dialect = csv.Sniffer().sniff(csvfile.read(4096))
            csvfile.seek(0)
            log.info('Getting file version and release date')
            csvfile.readline()
            line = csv.reader(StringIO(csvfile.readline())).next()
            log.info('Getting browcap file version')
            try:
                version = int(line[0])
            except ValueError:
                log.exception('Error while getting browscap file version')
                version = None
            log.info('Getting browscap file release date')
            try:
                old_locale = locale.getlocale()
                locale.setlocale(locale.LC_TIME, locale.normalize('en_US.utf8'))
                release_date = datetime.strptime(line[1][:-6], '%a, %d %b %Y %H:%M:%S')
            except (ValueError, locale.Error):
                log.exception('Error while getting browscap file release date')
                release_date = None
            finally:
                locale.setlocale(locale.LC_TIME, old_locale)

            log.info('Reading browscap user-agent data')
            reader = csv.DictReader(csvfile, dialect=dialect)
            defaults = {}
            browscap_data = {}
            regex_cache = []
            for line in reader:
                # Fix for KeyError: 'Platform'
                # if line['Parent'] == 'DefaultProperties':
                #     continue
                # if line['Parent'] == line['PropertyName']:
                #      defaults = line
                #      continue
                if line['PropertyName'] == 'DefaultProperties':
                    defaults = line
                    continue
                if line['Parent'] == 'DefaultProperties':
                    continue
                line = replace_defaults(line, defaults)
                try:
                    ua_regex = '^{0}$'.format(re.escape(line['propertyname']))
                    ua_regex = ua_regex.replace('\\?', '.').replace('\\*', '.*?')
                    browscap_data[ua_regex] = line
                    log.debug('Compiling user agent regex: %s', ua_regex)
                    regex_cache.append(re.compile(ua_regex))
                except sre_constants.error:
                    continue
        return Browscap(browscap_data, regex_cache, browscap_file_path, TYPE_CSV,
                        version, release_date)
    except IOError:
        log.exception('Error while reading browscap source file %s', browscap_file_path)
        raise

if __name__ == "__main__":
    # update()
    import sys, os
    bc_filename = BC_PATH
    if not os.path.exists(bc_filename) or "-update" in sys.argv[1:]:
        print "Downloading browser database to %r..." % bc_filename,
        update()
        print "done"
    test()