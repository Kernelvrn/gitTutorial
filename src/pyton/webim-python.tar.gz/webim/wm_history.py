# coding=UTF-8

import threading
import time
import json
import logging

import tornado

import db_utils
import wm_utils
import chat
import wm_web
import wm_timer


class HistoryRequestHandler(wm_web.CrossDomainRequestHandler):

    @tornado.web.asynchronous
    def get(self, *args, **kwargs):
        visitor_id = self.get_verified_argument('visitor-id')
        account = self.get_account()
        if account.get_setting('check_visitor_auth'):
            visit_tracker = self.get_account().visit_tracker
            page_id = self.get_verified_argument('page-id', None)
            if page_id not in visit_tracker.id_to_visited_page:
                self.reject_request('reinit-required')
                return
            visit_session = visit_tracker.id_to_visited_page[page_id].visit_session
            if self.get_argument('auth-token', None) != visit_session.auth_token:
                self.reject_request('reinit-required')
                return
        since_ts = self.get_int_argument('since')
        wm_timer.invoke_async(lambda: self.get_history(visitor_id, since_ts), timer_name='history_for_visitor')

    def get_history(self, visitor_id, since_ts):
        # ip = self.get_header('X-Real-Ip', self.request.remote_ip)
        # if not self.is_visitor_exists(visitor_id):
        #     self.add_bruteforce_attempt(ip)
        # if self.is_ip_banned(ip):
        #     raise tornado.web.HTTPError(500)
        hm = self.get_account().history_manager
        result = hm.get_history_response_for_visitor(visitor_id, since_ts)
        wm_utils.invoke_in_ioloop(lambda: self.send_result(result), name='history_for_visitor')

    # def is_visitor_exists(self, visitor_id):
    #     c = db_utils.get_connection(self.get_account_name())
    #     query = 'select visitorid from chatvisitsession where visitorid = %s limit 1'
    #     return True if c.execute_rowcount(query, visitor_id) else False


class HistoryManager:

    def __init__(self, account):
        self.account = account
        self.visitor_id_to_last_change_ts_micros = {}
        self.__lock = threading.Lock()

    def set_last_change_ts(self, visitor_id, last_change_ts):
        with self.__lock:
            self.visitor_id_to_last_change_ts_micros[visitor_id] = last_change_ts

    def set_last_change_ts_if_not_set(self, visitor_id, last_change_ts):
        with self.__lock:
            if visitor_id not in self.visitor_id_to_last_change_ts_micros:
                self.visitor_id_to_last_change_ts_micros[visitor_id] = last_change_ts
                return last_change_ts
            return self.visitor_id_to_last_change_ts_micros[visitor_id]

    def get_visitor_id_to_last_change_ts_secs(self, visitor_id):
        last_change_ts = self.visitor_id_to_last_change_ts_micros.get(visitor_id)
        return wm_utils.microseconds_to_seconds(last_change_ts) if last_change_ts else None

    def get_history_response_for_visitor(self, visitor_id, since_ts):

        if self.get_visitor_id_to_last_change_ts_secs(visitor_id) == since_ts:
            return {'lastChangeTs': since_ts, 'chats': [], 'messages': []}

        last_change_ts = since_ts

        collected_chats = self.account.background_storager.get_objects(
            chat.Chat, lambda ch: ch.id and ch.inserted_ts > since_ts and ch.session.visitor.id == visitor_id
        )
        id_to_collected_chat = dict([(ch.id, ch) for ch in collected_chats])

        c = db_utils.get_connection(self.account.name)
        c.execute('SET SESSION TRANSACTION ISOLATION LEVEL READ UNCOMMITTED')
        query = ('select th.* from chatthread th join chatvisitsession s on th.visitsessionid = s.visitsessionid '
                 'where s.visitorid = %s and floor(th.insertedts/1e6) > %s and th.state!=%s')
        chat_rows = c.query(query, visitor_id, since_ts, chat.Chat.State.DELETED)

        query = ('select m.* from chatmessage m join chatthread th on m.threadid = th.threadid join chatvisitsession s on th.visitsessionid = s.visitsessionid '
                 'where m.kind NOT IN %s and s.visitorid = %s and floor(m.insertedts/1e6) > %s and th.state !=%s')
        message_rows = c.query(query, chat.Message.Kind.ONLY_VISIBLE_BY_OPERATOR_NUMS, visitor_id, since_ts, chat.Chat.State.DELETED)

        result_chats = []
        id_to_chat = {}
        # todo modified/created difference
        for r in chat_rows:
            id = r['threadid']
            if id in id_to_collected_chat:
                collected_chat = id_to_collected_chat[id]
                if collected_chat.state == chat.Chat.State.DELETED:
                    continue
                ch = collected_chat.to_dict({'mode': 'visitor.history'})
                inserted_ts = ch['insertedTs']
            else:
                ch_dict = json.loads(r['json']) if r['json'] else {}
                offline = bool(r['offline'])
                ch = {
                    'id': str(id),
                    'clientSideId': ch_dict.get('clientSideId') or str(id),
                    'creationTs': wm_utils.microseconds_to_seconds(r['createdts'], return_int=False),
                    'modificationTs': wm_utils.microseconds_to_seconds(r['modifiedts'], return_int=False),
                    'offline': offline,
                    'canBeReopened': offline,
                    'unreadByVisitorSinceTs': ch_dict.get('unreadByVisitorSinceTs') if offline else None,
                    'subject': ch_dict.get('subject'),
                    'messages': []
                }
                inserted_ts = wm_utils.microseconds_to_seconds(r['insertedts'])

            result_chats.append(ch)
            id_to_chat[ch['id']] = ch

            last_change_ts = inserted_ts if inserted_ts > last_change_ts else last_change_ts

        result_messages = []

        visit_session = self.account.visit_tracker.get_session_by_visitor_id(visitor_id)

        for r in message_rows:
            collected_chat = id_to_collected_chat.get(r['threadid'])
            if collected_chat and collected_chat.state == chat.Chat.State.DELETED:
                continue

            msg_dict = json.loads(r.get('json') or '{}')
            text = r['message']

            if msg_dict.get('deleted'):
                continue

            if msg_dict.get('data') and msg_dict.get('data').get('markdowns'):
                for markdown_type, regex in wm_utils.MARKDOWNS_REGEXP.items():
                    mobile_app_support = self.account.check_if_mobile_app_supports_feature(visit_session.platform, visit_session.app_version, markdown_type)
                    if not visit_session or not mobile_app_support:
                        text = regex.sub(lambda match: chat.Message.replace_markdown_if_not_supported(match, markdown_type), text)

            kind = chat.Message.Kind.NUM_TO_NAME.get(r['kind'])
            author_id = r['operatorid']
            avatar = None
            if kind in chat.Message.Kind.OPERATOR_KINDS and author_id is not None:
                operator = self.account.get_operator(author_id)
                if operator:
                    avatar = operator.avatar
            m = {
                'id': str(r['messageid']),
                'clientSideId': msg_dict.get('clientSideId') or str(r['messageid']),
                'chatId': str(r['threadid']),
                'kind': kind,
                'ts': wm_utils.microseconds_to_seconds(r['createdts'], return_int=False),
                'text': text,
                'name': r['sendername'],
                'avatar': avatar,
                'authorId': author_id
            }
            if m['chatId'] in id_to_chat:
                id_to_chat[m['chatId']]['messages'].append(m)
            else:
                result_messages.append(m)

            inserted_ts = wm_utils.microseconds_to_seconds(r['insertedts'])
            last_change_ts = inserted_ts if inserted_ts > last_change_ts else last_change_ts

        c.close()

        self.set_last_change_ts_if_not_set(visitor_id, last_change_ts * 1e6)

        return {'lastChangeTs': last_change_ts, 'chats': result_chats, 'messages': result_messages}


class VisitorHistoryRequestManager(wm_web.CrossDomainRequestHandler):

    def requires_account_not_blocked(self):
        return True

    def prepare(self):
        super(VisitorHistoryRequestManager, self).prepare()
        session_id = self.get_verified_argument('sessionid')
        self.session = self.get_account().visit_tracker.get_session(session_id)
        # ip = self.get_header('X-Real-Ip', self.request.remote_ip)
        # if self.is_ip_banned(ip):
        #     raise tornado.web.HTTPError(500)

        if not self.get_account().get_setting('load_prev_chat_for_visitor'):
            self.reject_request('setting_disabled')
            return

        if not self.session:
            # self.add_bruteforce_attempt(ip)
            self.reject_request('session_not_found')
            return

        if not self.session.visitor.previous_chat_tag:
            self.reject_request('no_previous_chats')
            return

    @tornado.web.asynchronous
    def get(self, *args, **kwargs):
        chat_id = self.get_int_argument('chatid')
        wm_timer.invoke_async(lambda: self.get_visitor_history(chat_id), timer_name='history_for_visitor')

    def get_visitor_history(self, chat_id):
        account = self.get_account()

        if not account:
            logging.error('VisitorHistoryRequestManager: no account found in get_visitor_history')
            self.reject_request('unknown')
            return

        if chat_id < 0:
            logging.error('VisitorHistoryRequestManager: long if error')
            logging.error(self.session.chat)
            logging.error(chat_id)
            if self.session.chat:
                logging.error(self.session.chat.id)
            # ip = self.get_header('X-Real-Ip', self.request.remote_ip)
            # self.add_bruteforce_attempt(ip)
            self.reject_request('unknown')
            return

        c = db_utils.get_connection(account.name)

        def get_previous_chats(chat_id):
            query = """SELECT t.threadid, t.createdts FROM chatthread as t
                INNER JOIN chatvisitsession as v
                ON t.visitsessionid=v.visitsessionid
                WHERE v.visitorid = %s """ + ("AND t.threadid < %s " if chat_id > 0 else "%s") + \
                    """AND t.visitormessagecount >= 0 AND t.state!=%s ORDER BY t.threadid DESC LIMIT 3"""
            return c.query(query, self.session.visitor.id, chat_id if chat_id > 0 else '', chat.Chat.State.DELETED)

        current_chat_id = self.session.chat and self.session.chat.id or 0
        previous_chat_ids = filter(lambda chat: chat['threadid'] != current_chat_id, get_previous_chats(chat_id))

        if previous_chat_ids:
            result = {
                'result': 'ok',
                'data': {
                    'hasAnotherOne': len(previous_chat_ids) >= 2,
                    'chat': {
                        'id': previous_chat_ids[0]['threadid'],
                        'creationTs': wm_utils.microseconds_to_seconds(previous_chat_ids[0]['createdts']),
                        'messages': []
                    }
                }
            }
            query = """SELECT m.messageid, m.createdts, m.kind, m.message, m.operatorid, m.sendername, m.json FROM chatmessage m
                    WHERE m.threadid=%s and m.kind not in %s"""
            message_rows = c.query(query, result['data']['chat']['id'], chat.Message.Kind.ONLY_VISIBLE_BY_OPERATOR_NUMS)
            for msg in message_rows:
                if 'json' in msg and 'data' in json.loads(msg['json']):
                    data = json.loads(msg['json'])['data']
                else:
                    data = {}
                m = {
                    'id': msg['messageid'],
                    'ts': wm_utils.microseconds_to_seconds(msg['createdts']),
                    'kind': chat.Message.Kind.NUM_TO_NAME[msg['kind']],
                    'name': msg['sendername'],
                    'avatar': account.get_operator(msg['operatorid']).avatar if msg['operatorid'] and account.get_operator(msg['operatorid']) else None,
                    'text': msg['message'],
                    'data': data
                }
                result['data']['chat']['messages'].append(m)
        else:
            result = {
                'result': 'ok',
                'data': {
                    'hasAnotherOne': False,
                    'chat': None
                }
            }

        wm_utils.invoke_in_ioloop(lambda: self.send_result(result), name='history_for_visitor')


class MobileHistorySinceRequestHandler(wm_web.CrossDomainRequestHandler):
    LIMIT = 100

    def requires_account_not_blocked(self):
        return True

    def prepare(self):
        super(MobileHistorySinceRequestHandler, self).prepare()

        if not self.get_account():
            logging.error('MobileHistorySinceRequestHandler: no account found')
            self.reject_request('unknown')
            return

    @tornado.web.asynchronous
    def get(self, *args, **kwargs):
        account = self.get_account()
        visit_tracker = account.visit_tracker
        if not visit_tracker.ready:
            self.reject_request('server-not-ready')
            logging.warn('server-not-ready ' + self.request.uri)
            return

        page_id = self.get_argument('page-id')
        if page_id not in visit_tracker.id_to_visited_page:
            self.reject_request('reinit-required')
            return

        # May be either since or before_message_ts, or both None
        since = self.get_int_argument('since', None)
        before_ts = self.get_int_argument('before-ts', None)
        if since is not None and before_ts is not None:
            self.reject_request('wrong-argument-value')
            return

        limit = self.get_int_argument('limit', MobileHistorySinceRequestHandler.LIMIT)
        if limit < 1 or limit > MobileHistorySinceRequestHandler.LIMIT:
            self.reject_request('wrong-argument-value')
            return

        session = visit_tracker.id_to_visited_page[page_id].visit_session
        if self.get_argument('auth-token', None) != session.auth_token:
            self.reject_request('reinit-required')
            return

        # if not session.visitor.has_chats_before:
        #     self.respond_empty(since)
        #     return

        if since and account.history_manager.visitor_id_to_last_change_ts_micros.get(session.visitor.id) == since:
            self.__respond_empty()
            return

        wm_timer.invoke_async(
            lambda: self.get_visitor_history(session, since, before_ts, limit),
            timer_name='history_for_visitor_mobile')

    def get_visitor_history(self, session, since, before_ts, limit):
        account = self.get_account()
        visitor_id = session.visitor.id
        respond_revision = not before_ts

        has_more = False
        revision = since
        messages = []

        c = db_utils.get_connection(account.name)
        c.execute('SET SESSION TRANSACTION ISOLATION LEVEL READ UNCOMMITTED')
        query_common = (
            'SELECT m.messageid, m.threadid, m.createdts, m.kind, m.message, m.operatorid, m.sendername, m.json, m.insertedts '
            'FROM chatmessage AS m '
            'INNER JOIN chatthread AS t ON m.threadid = t.threadid '
            'INNER JOIN chatvisitsession AS v ON t.visitsessionid = v.visitsessionid '
            'WHERE v.visitorid = %s '
            'AND t.offline = 0 ')
        if since:
            query = query_common + (
                'AND m.insertedts > %s '
                'AND m.kind NOT IN %s '
                'ORDER BY m.insertedts ASC LIMIT %s')

            message_rows = c.query(query, visitor_id, since,
                                   chat.Message.Kind.ONLY_VISIBLE_BY_OPERATOR_NUMS, limit + 1)
            if len(message_rows) == limit + 1:
                message_rows.pop()
                has_more = True

            for msg_row in message_rows:
                insertedts = msg_row['insertedts']
                revision = max(revision, insertedts)
                m = self.__prepare_message(account, msg_row, session)
                if m.get('deleted', False) and insertedts > since:
                    continue
                messages.append(m)
            if not has_more:
                account.history_manager.set_last_change_ts_if_not_set(visitor_id, revision)
        else:
            if respond_revision:
                revision = account.history_manager.set_last_change_ts_if_not_set(visitor_id, long(time.time() * 1e6))
            while True:
                query = query_common + (
                    ('AND m.createdts < %s ' if before_ts else '') +
                    'AND m.kind NOT IN %s '
                    'ORDER BY m.createdts DESC LIMIT %s')

                if before_ts:
                    message_rows = c.query(query, visitor_id, before_ts,
                                           chat.Message.Kind.ONLY_VISIBLE_BY_OPERATOR_NUMS, limit + 1)
                else:
                    message_rows = c.query(query, visitor_id,
                                           chat.Message.Kind.ONLY_VISIBLE_BY_OPERATOR_NUMS, limit + 1)
                if len(message_rows) == limit + 1:
                    message_rows.pop()
                    has_more = True

                for msg_row in reversed(message_rows):
                    m = self.__prepare_message(account, msg_row, session)
                    if not m.get('deleted', False):
                        if respond_revision:
                            revision = max(revision, msg_row['insertedts'])
                        messages.append(m)
                if messages or not has_more:
                    break
                else:
                    before_ts = message_rows[-1]['createdts']
                    # continue
        c.close()

        if respond_revision or messages:
            self.__respond_messages(has_more, revision if respond_revision else None, messages)
        else:
            # has_more is always False here
            self.__respond_empty()

    @staticmethod
    def __prepare_message(account, msg_row, session):
        operator_id = msg_row['operatorid']
        operator = account.get_operator(operator_id) if operator_id else None
        avatar = operator.avatar if operator else None
        msg_dict_str = msg_row.get('json')
        msg_dict = json.loads(msg_dict_str) if msg_dict_str else {}
        text = msg_row['message']

        if msg_dict.get('deleted', False):
            m = {
                'id': str(msg_row['messageid']),
                'deleted': True
            }
        else:
            msg_data = msg_dict.get('data', {})
            if msg_data and msg_data.get('markdowns'):
                for markdown_type, regex in wm_utils.MARKDOWNS_REGEXP.items():
                    if not account.check_if_mobile_app_supports_feature(session.platform, session.app_version, markdown_type):
                        text = regex.sub(lambda match: chat.Message.replace_markdown_if_not_supported(match, markdown_type), text)

            m = {
                'id': str(msg_row['messageid']),
                'clientSideId': msg_dict.get('clientSideId'),
                'chatId': str(msg_row['threadid']),
                'ts_m': msg_row['createdts'],
                'kind': chat.Message.Kind.NUM_TO_NAME[msg_row['kind']],
                'name': msg_row['sendername'],
                'avatar': avatar,
                'authorId': operator_id,
                'text': text,
                'data': msg_data
            }
        return m

    def __respond_messages(self, has_more, revision, messages):
        result = {
            'result': 'ok',
            'data': {
                'hasMore': has_more,
                'messages': messages
            }
        }
        if revision is not None:
            result['data']['revision'] = str(revision)

        wm_utils.invoke_in_ioloop(lambda: self.send_result(result), name='history_for_visitor_mobile')

    def __respond_empty(self):
        self.send_result({'result': 'ok'})
