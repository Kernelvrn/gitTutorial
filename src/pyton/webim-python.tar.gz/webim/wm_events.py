# coding=UTF-8

__author__ = 'andrew'

import logging
import re
import datetime
from threading import Lock
from logging import handlers

import wm_timer
import chat
from wm_utils import DictExt


# ------------EVENTS ------------ #

class Event(object):

    class Type:
        MESSAGE_ADD = 'message_add'
        OPERATOR_STATUS_CHANGED = 'operator_status_changed'
        OPERATOR_TYPING = 'operator_typing'
        VISITOR_TYPING = 'visitor_typing'
        VISITOR_REDIRECTED = 'visitor_redirected'
        VISITOR_BANNED = 'visitor_banned'
        VISITOR_LEFT = 'visitor_left'
        NEW_VISITED_PAGE = 'new_visited_page'
        CHAT_STORED_TO_DB = 'chat_stored_to_db'
        VISITOR_LOGIN = 'visitor_login'
        VISITOR_LOGOUT = 'visitor_logout'
        OPERATOR_LOGIN = 'operator_login'
        OPERATOR_LOGOUT = 'operator_logout'
        SIEBEL_BUTTON_CLICK = 'siebel_button_click'
        OPERATOR_SELECT_SESSION = 'operator_select_session'
        VISITOR_HIDE_CHAT = 'visitor_hide_chat'
        CHAT_STATE_MODIFIED = 'chat_state_modified'

    def __init__(self, e_type, e_object=None, e_data=None):
        self.type = e_type
        self.object = e_object
        self.data = e_data

# ------------DISPATCHERS ------------ #


class BasicEventDispatcher(object):

    def __init__(self):
        self.consumers = []
        self.e_type_to_consumers = DictExt(lambda key: [])

        self.lock = Lock()

    def add_consumer(self, consumer):
        with self.lock:
            try:
                if consumer not in self.consumers:
                    self.consumers.append(consumer)

                events = consumer.get_supported_types()

                for t in events:
                    self.e_type_to_consumers[t] = self.e_type_to_consumers.get(t) + [consumer]

                logging.warn('EventDispatcher: %s consumer added for events %s' % (consumer.name, str(events)))
            except Exception:
                logging.warn('EventDispatcher: FAILED to add %s consumer' % consumer.name, exc_info=True)

    # def delete_consumer(self, consumer): # TODO consumer -> consumer_name
    #     with self.lock:
    #         if consumer in self.consumers:
    #             self.consumers.remove(consumer)
    #
    #             for e_type, consumers in self.e_type_to_consumers.items():
    #                 if consumer in consumers:
    #                     consumers.remove(consumer)
    #                     self.e_type_to_consumers[e_type] = consumers

    def get_consumers_by_type(self, e_type):
        return self.e_type_to_consumers.get(e_type)

    def fire(self, event):
        if not len(self.consumers):
            return

        for consumer in self.get_consumers_by_type(event.type):
            try:
                consumer.process_event(event)
            except Exception:
                logging.error('EventDispatcher: failed to dispatch event %s to %s Consumer' % (event.type, consumer.name), exc_info=True)


class AccountEventDispatcher(BasicEventDispatcher):

    def __init__(self, account):
        super(AccountEventDispatcher, self).__init__()
        self.account = account

    def get_account(self):
        return self.account

    def update_consumers_list(self, consumers):
        with self.lock:
            self.consumers = []
            self.e_type_to_consumers = DictExt(lambda key: [])

        for consumer in consumers:
            self.add_consumer(consumer)


class ChatEventDispatcher(BasicEventDispatcher):

    def __init__(self, ch):
        super(ChatEventDispatcher, self).__init__()
        self.chat = ch

# ------------CONSUMERS ------------ #


class BasicEventConsumer(object):

    EVENT_PROCESSOR_METHOD_NAME_REGEXP = re.compile("on_[\w]+$")

    def __init__(self, consumer_name, disabled=None):
        self.name = consumer_name
        self.disabled = disabled or {}

        self.e_type_to_processor = {}

        self.__update_processors()

    def __update_processors(self):
        e_types = self.get_supported_types()
        for e_type in e_types:
            e_processor = getattr(self, "on_%s" % e_type, None)
            if e_processor and callable(e_processor):
                self.e_type_to_processor[e_type] = e_processor

    def update_event_disabled(self, e_type, disabled):
        self.disabled[e_type] = disabled

    def get_supported_types(self):
        return [m[3:] for m in filter(self.EVENT_PROCESSOR_METHOD_NAME_REGEXP.search, dir(self)) if m]

    def process_event(self, event):
        try:
            if self.disabled.get(event.type):
                return

            self._process_event(event)
        except Exception:
            logging.warn("EventConsumer %s: failed to process event %s" % (self.name, event.type), exc_info=True)

    def _process_event(self, event):
        self._run_event_processor(event)

    def _run_event_processor(self, event):
        e_processor = self.e_type_to_processor.get(event.type)
        if e_processor:
            return e_processor(event)


class AccountEventConsumer(BasicEventConsumer):

    def __init__(self, account, consumer_name, disabled=None):
        super(AccountEventConsumer, self).__init__(consumer_name, disabled=disabled)
        self.account = account


class MessageEventConsumer(BasicEventConsumer):

    def __init__(self, consumer_name, message, disabled=None):
        super(MessageEventConsumer, self).__init__(consumer_name, disabled=disabled)
        self.message = message

    def on_chat_state_modified(self, event):
        ch = event.object
        if ch and ch.state == chat.Chat.State.CLOSED and self.message.get_data('state') != chat.Message.ActionState.COMPLETED:
            self.message.update(data_changes={'state': chat.Message.ActionState.IGNORED})


class AsyncEventConsumer(AccountEventConsumer):

    def process_event(self, event):
        wm_timer.invoke_async(lambda: self._process_event(event), timer_name='%s AsyncEventConsumer task - %s' % (self.name, event.type))


class AsyncQueueLoggingEventConsumer(AccountEventConsumer):

    def __init__(self, account, consumer_name, logging_period, log_settings, disabled=None):
        super(AsyncQueueLoggingEventConsumer, self).__init__(account=account, consumer_name=consumer_name, disabled=disabled)

        self.log_settings = log_settings or {}
        self.logger = self.setup_logger('%sLogger' % self.name, log_settings.get('file'), log_format=log_settings.get('format'))

        self.logging_lock = Lock()
        self.logging_queue = []

        wm_timer.invoke_periodically(logging_period, self.__do_log, timer_name="%s AsyncQueueLoggingEventConsumer __do_log" % self.name)

    def setup_logger(self, logger_name, log_file_path, log_format=None):
        handler = handlers.RotatingFileHandler(log_file_path, maxBytes=10 * 1024 * 1024, backupCount=5)
        if log_format:
            handler.setFormatter(logging.Formatter(log_format))

        logger = logging.getLogger(logger_name)
        logger.setLevel(logging.INFO)
        logger.addHandler(handler)

        return logger

    def _process_event(self, event):
        log_str = self._run_event_processor(event)
        with self.logging_lock:
            if log_str:
                self.logging_queue.append(log_str)

    def __do_log(self):
        with self.logging_lock:
            for l in self.logging_queue:
                self.logger.info(l)
            self.logging_queue = []


class TCSChatTraceLoggingEventConsumer(AsyncQueueLoggingEventConsumer):

    def __get_formated_log(self, *extra):
        t = datetime.datetime.now().strftime('%Y-%m-%d %H:%M:%S')
        extra = [str(e) if e is not None else "null" for e in extra]
        return "%s|" % t + "|".join(extra)

    def __get_operator_email_by_id(self, operator_id):
        op = self.account.get_operator(operator_id)
        if op:
            return op.email

    def on_operator_status_changed(self, event):
        return self.__get_formated_log(
            "change_mode", self.__get_operator_email_by_id(event.object.operator_id), event.data.get('old_status'), event.data.get('new_status')
        )

    def on_message_add(self, event):
        msg = event.object
        ch = event.data.get('chat')
        operator = ch.get_operator()
        visitor = ch.session.visitor

        if msg.kind == chat.Message.Kind.OPERATOR:
            return self.__get_formated_log("send_message_spec", operator.email, ch.id)

        elif msg.kind == chat.Message.Kind.OPERATOR_NOTE:
            return self.__get_formated_log("add_note", operator.email, ch.id)

        elif msg.kind == chat.Message.Kind.CONT_REQ:
            return self.__get_formated_log("request_contact", operator.email, ch.id)

        elif msg.kind == chat.Message.Kind.FILE_OPERATOR:
            return self.__get_formated_log("send_file", operator.email, ch.id)

        elif msg.kind == chat.Message.Kind.VISITOR:
            return self.__get_formated_log(
                "send_message_clients", visitor.provided_fields.get('id'), visitor.id, "Y" if bool(visitor.provided_fields) else "N", ch.id
            )

    def on_chat_state_modified(self, event):
        ch = event.object
        if event.data.get('new_state') == chat.Chat.State.QUEUE and ch.get_operator() and not ch.get_operator().is_robot():
            return self.__get_formated_log("wait_answer", ch.get_operator().email, ch.id)

        if event.data.get('new_state') == chat.Chat.State.CHATTING and ch.get_operator():
            return self.__get_formated_log("dialog", ch.get_operator().email, ch.id)

        if event.data.get('new_state') == chat.Chat.State.CLOSED_BY_OPERATOR:
            return self.__get_formated_log("close_chat_spec", ch.get_operator().email, ch.id)

    def on_operator_typing(self, event):
        ch = event.object
        if event.data.get('typing'):
            return self.__get_formated_log("begin_print_spec", ch.get_operator().email, ch.id)

    def on_visitor_typing(self, event):
        ch = event.object
        if ch and event.data.get('typing'):
            visitor = ch.session.visitor
            return self.__get_formated_log(
                "begin_print_client", visitor.provided_fields.get('id'), visitor.id, "Y" if bool(visitor.provided_fields) else "N", ch.id
            )

    def on_visitor_redirected(self, event):
        if event.data.get('redirect_type') == 'operators':
            return self.__get_formated_log(
                "redirect",
                self.__get_operator_email_by_id(event.data.get('requested_by_operator_id')),
                event.object.chat.id,
                "operator",
                self.__get_operator_email_by_id(event.object.chat.get_operator_id()),
            )
        elif event.data.get('redirect_type') == 'departments':
            return self.__get_formated_log(
                "redirect",
                self.__get_operator_email_by_id(event.data.get('requested_by_operator_id')),
                event.object.chat.id,
                "skill",
                event.data.get('redirect_id')
            )

    def on_visitor_banned(self, event):
        if event.object.chat:
            return self.__get_formated_log("blocked", event.object.chat.get_operator().email, event.object.chat.id)

    def on_new_visited_page(self, event):
        session = event.object
        if session.visitor and session.chat:
            return self.__get_formated_log(
                "go_url", session.visitor.provided_fields.get('id'), session.visitor.id, "Y" if bool(session.visitor.provided_fields) else "N", session.chat.id
            )

    def on_chat_stored_to_db(self, event):
        ch = event.object
        if ch.session and ch.session.visitor:
            visitor = ch.session.visitor
            return self.__get_formated_log("begin_chat", visitor.provided_fields.get('id'), visitor.id, "Y" if bool(visitor.provided_fields) else "N", ch.id)

    def on_visitor_left(self, event):
        session = event.object
        if session.visitor and session.chat:
            return self.__get_formated_log(
                "close_chat_client", session.visitor.provided_fields.get('id'),
                session.visitor.id, "Y" if bool(session.visitor.provided_fields) else "N", session.chat.id
            )

    def on_visitor_login(self, event):
        session = event.object
        return self.__get_formated_log(
            "authorization_y", session.visitor.provided_fields.get('id'), session.visitor.id, session.chat.id if session.chat else None
        )

    def on_visitor_logout(self, event):
        session = event.object
        return self.__get_formated_log(
            "authorization_n", session.visitor.provided_fields.get('id'), session.visitor.id, session.chat.id if session.chat else None
        )

    def on_operator_login(self, event):
        operator = event.object
        return self.__get_formated_log("login", operator.email, event.data.get('status'))

    def on_operator_logout(self, event):
        operator = event.object
        return self.__get_formated_log("logout", operator.email)

    def on_siebel_button_click(self, event):
        session = event.object
        return self.__get_formated_log("siebel", event.data.get('operator').email, session.chat.id if session.chat else None)

    def on_operator_select_session(self, event):
        session = event.object
        return self.__get_formated_log(
            "change_dialog", event.data.get('operator').email, event.data.get('previous_session_chat_id') or None, session.chat.id if session.chat else None
        )

    def on_visitor_hide_chat(self, event):
        session = event.object
        return self.__get_formated_log(
            "hide_chat", session.visitor.provided_fields.get('id'), session.visitor.id,
            "Y" if bool(session.visitor.provided_fields) else "N", session.chat.id if session.chat else None
        )
