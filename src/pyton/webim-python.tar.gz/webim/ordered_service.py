# coding=UTF-8
import calendar
import json
import logging

import tornado.web

import db_utils
import account
import wm_timer
import wm_mail
import wm_settings
import wm_web
import wm_utils
import wm_resources
import rsa
import datetime
import base64


__author__ = 'mixey'

class CachedTariffs(wm_utils.CachedDBData):

    def __init__(self, account_name):
        self.account_name = account_name
        wm_utils.CachedDBData.__init__(self, None, reload_immediately_after_reset=True)

    def load_data(self, connection):
        rows = connection.query("select * from accounttariffview where account_accountname = %s", self.account_name)
        result = {}
        for r in rows:
            key = r['tariffkey']
            if key and key not in result:
                result[key] = Tariff(key, {}, {})

        for r in rows:
            if r['tariffkey']:
                tariff = result.get(r['tariffkey'])
                self.__update_tariff(tariff, r)
            else:
                for k, tariff in result.items():
                    self.__update_tariff(tariff, r)
        return result

    def __update_tariff(self, tariff, row):
        if row['descriptor']:
            tariff.descriptor = wm_utils.merge_dict(tariff.descriptor, json.loads(row['descriptor']))
        if row['settings']:
            tariff.settings = wm_utils.merge_dict(tariff.settings, json.loads(row['settings']))

class CachedDiscounts(wm_utils.CachedDBData):

    def __init__(self, account_name):
        self.account = account.BriefAccount(account_name)
        wm_utils.CachedDBData.__init__(self, None)

    def load_data(self, connection):
        r = connection.get("select value from globalsettings where name='tariff_discount_by_month'")

        result = json.loads(r['value'])

        #if self.account.name == 'mixey' or self.account.name == 'nethouseru' or self.account.partner_name == 'nethouseru':
        #    result['12'] = 60

        return result

ACCOUNT_NAME_TO_CACHED_DISCOUNTS = wm_utils.DictExt(lambda account_name: CachedDiscounts(account_name))

class Tariff:

    ACCOUNT_TO_CACHED_TARIFFS = {}

    def __init__(self, key, settings, descriptor):
        self.key = key
        self.settings = settings
        self.descriptor = descriptor

    def to_dict(self, context=None):
        return {
            'key': self.key,
            'settings': self.settings,
            'descriptor': self.descriptor,
        }

    @classmethod
    def get(cls, account_name, key):
        cached_tariffs = cls.get_cached_tariffs(account_name)
        return cached_tariffs.get_data()[key]

    @classmethod
    def get_cached_tariffs(cls, account_name):
        if account_name not in cls.ACCOUNT_TO_CACHED_TARIFFS:
            cls.ACCOUNT_TO_CACHED_TARIFFS[account_name] = CachedTariffs(account_name)
        return cls.ACCOUNT_TO_CACHED_TARIFFS[account_name]


class OrderedServiceRequestHandler(wm_web.BaseWebimRequestHandler):

    def requires_authorized_operator(self):
        return True

    def requires_origin_checking(self):
        return True

    @tornado.web.asynchronous
    def get(self, *args, **kwargs):
        wm_timer.invoke_async(self.__get, timer_name='ordered_services get')

    def __get(self):
        action = self.get_verified_argument('action')
        if action == 'list':
            self.finish_in_ioloop(self.get_list())
        if action == 'get_tariffs':
            self.finish_in_ioloop(self.get_tariffs())
        if action == 'get_current_tariff':
            self.finish_in_ioloop(self.get_current_tariff())

    @tornado.web.asynchronous
    def post(self, *args, **kwargs):
        wm_timer.invoke_async(self.__post, timer_name='ordered_services post')

    def __post(self):
        action = self.get_verified_argument('action')
        if action == 'calculate':
            result = calculate(self.get_account_name(), self.get_json_argument('options'))
            self.finish_in_ioloop(date_to_ts(result))
        elif action == 'order':
            try:
                options = self.get_json_argument('options')
                id = order(self.get_account_name(), options, ignore_existing_pending=False)
                result = date_to_ts(load_by_id(id))
            except PendingOrderFoundException:
                result = {'error': 'pending_order_found'}
            self.finish_in_ioloop(result)
        elif action == 'set-free-tariff':
            if set_free_tariff(self.get_account_name()):
                self.finish_in_ioloop({'result': 'ok'})
            else:
                self.finish_in_ioloop({'error': 'could_not_enable_free_tariff'})
        elif action == 'cancel':
            id = self.get_int_argument('id')
            cancel(id, self.get_account_name())
            self.finish_in_ioloop({'result': 'ok'})
        elif action == 'apply_license_key':
            account = self.get_account()
            lang = account.settings.get('default_lang')
            try:
                key = json.loads(base64.b64decode(self.get_argument('key', {})))
            except TypeError:
                logging.error('{}. Decoding license key has failed'.format(self.__class__.__name__), exc_info=True)
                self.finish_in_ioloop({"result": "error", "msg": wm_resources.get_resource(account, lang, 'ordered_service.incorrect_license_key.decoding_error')})
                return
            except ValueError:
                logging.error('{}. Failed load JSON'.format(self.__class__.__name__), exc_info=True)
                self.finish_in_ioloop({"result": "error", "msg": wm_resources.get_resource(account, lang, 'ordered_service.incorrect_license_key.incorrect_json')})
                return
            except Exception as e:
                logging.error('{}. Undefined error'.format(self.__class__.__name__), exc_info=True)
                self.finish_in_ioloop({"result": "error", "msg": wm_resources.get_resource(account, lang, 'ordered_service.incorrect_license_key.undefined')})
                return

            os_row_is_verified, error_type = verify_os_row(key)
            if not os_row_is_verified:
                self.finish_in_ioloop({"result": "error", "msg": wm_resources.get_resource(account, lang, 'ordered_service.' + error_type)})
                return

            os = load_by_id(key['id'])
            if os:
                self.__update_os_by_key(key)
            else:
                self.__store_key_as_os(key)

            account = self.get_account()
            account.tariff_settings.reset()

            self.finish_in_ioloop({'result': 'ok'})

    def get_list(self):
        connection = db_utils.get_connection()
        rows = connection.query("select os.*, replacing_os.id replacingid from orderedservice os " +
                                "left join orderedservice replacing_os on replacing_os.replacedid = os.id  and replacing_os.status != 'canceled'" +
                                "where os.accountname=%s and os.status != \'canceled\' order by os.dtmfrom desc, os.id desc", self.get_account_name())

        account = self.get_account()
        for row in rows:
            formate_os_row_if_need(row, account)

        # profile = load_active_profile(self.get_account_name())
        date_to_ts(rows)
        # date_to_ts(profile)

        connection.close()
        return {
            'activeProfile': None,
            'orderedServices': rows
        }

    def get_current_tariff(self):
        tariff = self.get_account().tariff_settings.get_data()
        return {
            'tariff': tariff['tariff'],
            'blocked': tariff['blocked']
        }

    def get_tariffs(self):
        tariffs = {}
        for key, tariff in Tariff.get_cached_tariffs(self.get_account_name()).get_data().items():
            if key in ['free', 'start', 'bus', 'corp']:
                tariffs[key] = tariff.to_dict()
        return {
            'keyToTariff': tariffs,
            'discounts': ACCOUNT_NAME_TO_CACHED_DISCOUNTS.get(self.get_account_name()).get_data()
        }

    @staticmethod
    def __update_os_by_key(key):
        ts_to_date(key)
        names = [k for k, v in key.items()]
        values = [v for k, v in key.items()]
        values.append(key['id'])
        query = 'update orderedservice set ' + ', '.join(map(lambda k: k + '=%s', names)) + " where id = %s"
        connection = db_utils.get_connection()
        connection.execute(query, *values)

        if key['status'] == ('payed', 'payment_guaranteed'):
            account_row = connection.get("select accountname, partner, tariff, profreedate from account where accountname = %s", key['accountname'])
            update_account(account_row)

        connection.close()

    @staticmethod
    def __store_key_as_os(os_row):
        tariff = Tariff.get(os_row['accountname'], os_row['tariffkey'])
        settings = json.loads(os_row['settings'])
        ts_to_date(os_row)

        values = {
            'id': os_row['id'],
            'accountname': os_row['accountname'],
            'dtmfrom': os_row['dtmfrom'],
            'dtmto': os_row['dtmto'],
            'monthcnt': os_row['monthcnt'],
            'tariffkey': tariff.key,
            'settings': json.dumps(settings),
            'description': u'Тариф: {}, операторов: {}'.format(tariff.descriptor['name'],
                                                               settings.get('online_operators_limit')),
            'invoiceguid': os_row['invoiceguid'],
            'dtmcreated': datetime.datetime.now(),
            'status': os_row['status'],
            'replacedid': os_row['replacedid'],
            'signature': os_row['signature']
        }

        connection = db_utils.get_connection()
        store_record(connection, 'orderedservice', values)
        if os_row['replacedid']:
            replaced_os = connection.get("select * from orderedservice os where os.id=%s", os_row['replacedid'])
            update_os(replaced_os, 'replaced', connection)

        max_dtmto_row = load_one("select max(dtmto) dtmto from orderedservice where accountname=%s and status in ('payed', 'payment_guaranteed')", os_row['accountname'])
        connection.execute('update account set profreedate=%s where accountname=%s', max_dtmto_row['dtmto'], os_row['accountname'])

        connection.close()


class OrderedServiceAdmRequestHandler(OrderedServiceRequestHandler, wm_web.AdminRequestHandler):

    def requires_authorized_operator(self):
        return False

    def _get_account_name(self):
        return self.get_verified_argument('account-name')

    def post(self, *args, **kwargs):
        action = self.get_verified_argument('action')
        if action == 'set_payment_guaranteed':
            os_id = self.get_verified_argument('id')
            account_name = self.get_verified_argument('account-name')
            try:
                set_payment_guaranteed(os_id)
                self.finish(json.dumps({'result': 'ok'}))
            except Exception as e:
                logging.error('OrderedService: Error on set_payment_guaranteed, account=%s, os_id=%s, message=%s' % (account_name, os_id, e.message), exc_info=True)
                self.finish(json.dumps({'result': 'error'}))
        elif action == 'change_price':
            try:
                os_id = self.get_verified_argument('os_id')
                new_price = self.get_int_argument('new_price')
                change_os_price(os_id, new_price)
                self.finish(json.dumps({'result': 'ok'}))
            except Exception as e:
                logging.error('OrderedService: Error on change_price - %s' % e.message, exc_info=True)
                self.finish(json.dumps({'result': 'error'}))
        elif action == 'cancel':
            os_id = self.get_verified_argument('id')
            force = self.get_bool_argument('force-for-already-started-payment-guaranteed')
            cancel(os_id, self.get_account_name(), force)
        else:
            super(OrderedServiceAdmRequestHandler, self).post(*args, **kwargs)


class OnPaymentAcceptedRequestHandler(wm_web.BaseWebimRequestHandler):

    def get(self, *args, **kwargs):
        guid = self.get_verified_argument('guid')
        connection = db_utils.get_connection()
        row = connection.get("select os.id, os.monthcnt, os.dtmfrom, os.accountname, os.replacedid, os.dtmto, os.status from orderedservice os join invoice i on i.guid = os.invoiceguid where i.paydate is not null and i.guid = %s",guid)
        result = accept_payment(row, connection, 'payed')
        connection.close()
        return self.write(result)


class GetOrderedServiceKeys(wm_web.AdminRequestHandler):

    def get(self):
        logging.warn('{}.get; account={}'.format(self.__class__.__name__, self.get_account().name))

        if wm_settings.is_hosted_mode():
            self.send_error(403)
            return

        keys = self.get_os_keys()
        self.finish(json.dumps({'public': keys['public']}, indent=4, sort_keys=True))

    def get_os_keys(self):
        account = self.get_account()
        keys = account.get_setting('keys_for_os')
        if not keys:
            (public_key, private_key) = rsa.newkeys(2048)

            keys = {
                'public': {
                    'n': public_key.n,
                    'e': public_key.e
                },
                'private': {
                    'n': private_key.n,
                    'e': private_key.e,
                    'd': private_key.d,
                    'p': private_key.p,
                    'q': private_key.q
                }
            }

            account.settings.set('keys_for_os', json.dumps(keys), async=False)

        return keys


def ts_to_date(key):
    for ts_field in ('dtmfrom', 'dtmto'):
        key[ts_field] = datetime.date.fromtimestamp(int(key[ts_field]))
    return key


def verify_os_row(row):
    if not row:
        return False, 'incorrect_license_key.no_key'

    if not wm_settings.settings.get('hostedmode'):
        return True, None

    account_name = row.get('accountname')
    if not account_name:
        return False, 'incorrect_license_key.no_account_name'

    a = account.Account.get(account_name, False)
    if not a:
        return False, 'incorrect_license_key.not_found_account'

    keys = a.get_setting('keys_for_os')
    if not keys:
        return False, 'incorrect_license_key.not_found_keys_for_os'

    signature = row.get('signature')
    if not signature:
        return False, 'incorrect_license_key.no_signature'

    public_key = rsa.PublicKey(keys['public']['n'], keys['public']['e'])
    try:
        message = make_message_for_encript(row)
        return rsa.verify(message, signature.decode('hex'), public_key), None
    except rsa.VerificationError:
        logging.error('OrderedService. VerificationError')
        return False, 'incorrect_license_key.verification_error'


def formate_os_row_if_need(row, account):
    if wm_settings.is_hosted_mode() or not account.get_setting('keys_for_os') or row['status'] not in ('payed', 'payment_guaranteed'):
        return row

    license_key_fields = ['accountname', 'dtmfrom', 'dtmto', 'tariffkey', 'settings', 'status', 'id', 'replacedid',
                          'invoiceguid', 'monthcnt']
    license_key = date_to_ts({k: v for k, v in row.items() if k in license_key_fields})
    license_key['signature'] = calc_signature(row, get_private_key_for_account(account))
    row['license_key'] = base64.b64encode(json.dumps(license_key))

    return row


def get_private_key_for_account(account):
    keys = account.get_setting('keys_for_os')
    if not keys:
        return None
    private_key = rsa.PrivateKey(
        keys['private']['n'],
        keys['private']['e'],
        keys['private']['d'],
        keys['private']['p'],
        keys['private']['q']
    )
    return private_key


def calc_signature(row, private_key):
    message = make_message_for_encript(row)
    return rsa.sign(message, private_key, 'SHA-256').encode('hex')


def make_message_for_encript(row):
    date_to_ts(row)
    fields = ['accountname', 'dtmfrom', 'dtmto', 'tariffkey', 'settings', 'status']
    return reduce(lambda a, x: str(a) + str(row[x]), fields, '')


def load_current_ordered_service(account_name):
    current_os = load_one("select * from orderedservice where accountname=%s and status in ('payed', 'payment_guaranteed') and dtmfrom <= curdate() and curdate() <= dtmto order by id desc limit 1", account_name)
    weekday_num = datetime.datetime.now().isoweekday()
    if not current_os and weekday_num > 5:
        diff = weekday_num - 5
        current_os = load_one("select * from orderedservice where accountname=%s and status in ('payed', 'payment_guaranteed') and dtmfrom <= curdate() - interval " + str(diff) + " day and curdate() - interval " + str(diff) + " day <= dtmto order by id desc limit 1", account_name)
    # return current_os
    os_row_is_verified, error_type = verify_os_row(current_os)
    return current_os if os_row_is_verified else None


def accept_payment(row, connection, status):
    if row and not wm_settings.is_hosted_mode():
        correct_os_dates_if_necessary(row)
        if row['status'] in ['pending', 'payment_guaranteed']:
            update_os(row, status, connection)
        elif row['status'] == 'canceled':
            if row['replacedid']:
                os_rows = connection.query("select * from orderedservice os where os.replacedid=%s and os.accountname=%s and os.status != 'canceled'", row['replacedid'], row['accountname'])
            else:
                os_rows = connection.query("select * from orderedservice os where os.dtmfrom>=%s and os.dtmfrom<%s and os.accountname=%s and os.status != 'canceled' and os.status!='replaced'", row['dtmfrom'],row['dtmto'], row['accountname'])

            for os_row in os_rows:
                if os_row['status'] == 'payed':
                    connection.close()
                    return json.dumps({"result": "error"})

                if os_row['status'] == 'pending':
                    update_os(os_row, 'canceled', connection)

            update_os(row, status, connection)

        if row['replacedid']:
            replaced_os = connection.get("select * from orderedservice os where os.id=%s", row['replacedid'])
            update_os(replaced_os, 'replaced', connection)

    return json.dumps({"result": "ok"})


def set_payment_guaranteed(os_id):
    connection = db_utils.get_connection()
    os = load_by_id(os_id)
    accept_payment(os, connection, 'payment_guaranteed')
    wm_mail.mailer.send_payment_guaranteed(os)
    connection.close()

def correct_os_dates_if_necessary(os):
        today = datetime.date.today()
        if os['status'] != 'payment_guaranteed' and not os['replacedid'] and os['dtmfrom'] < today:
            os['dtmfrom']= today
            os['dtmto']= calculate_date_to(today, os['monthcnt'])

def update_os(os, status, connection):
    os['status'] = status
    connection.execute("update orderedservice set status=%s, dtmfrom = %s, dtmto = %s where id = %s", os['status'], os['dtmfrom'], os['dtmto'], os['id'])
    if status in ['payed', 'payment_guaranteed']:
        account_row = connection.get("select accountname, partner, tariff, profreedate from account where accountname = %s", os['accountname'])
        update_account(account_row)

def process_daily_operations(request_handler, automatic_reorder_only=False):
    if not automatic_reorder_only:
        log(request_handler, "update_accounts")
        update_accounts(request_handler)

    log(request_handler, "automatic_reorder")
    automatic_reorder()

    log(request_handler, "daily processing end")

def log(request_handler, message):
    logging.warn(message)
    request_handler.write(message + '\n')


def send_ending_account_notifications():
    connection = db_utils.get_connection()
    rows = connection.query('select * from endingaccountview')

    for row in rows:
        try:
            account_name = row['accountname']
            is_partner_client = row['is_partner_client']
            tariff = row['tariff']
            daysdiff = row['daysdiff']

            now = datetime.date.today()

            if tariff == 'test':
                if daysdiff == 2:
                    wm_mail.mailer.send_testing_period_ending(account.BriefAccount(account_name), is_partner_client=is_partner_client)
                elif daysdiff == 1 and now.isoweekday() not in [6, 7]:
                    wm_mail.mailer.send_testing_period_ending_to_jira(account.BriefAccount(account_name))
            else:
                if daysdiff == 5:
                    wm_mail.mailer.send_payed_period_ending(account.BriefAccount(account_name), params={'days': str(daysdiff)}, is_partner_client=is_partner_client)
                elif daysdiff == 1 and now.isoweekday() not in [6, 7]:
                    wm_mail.mailer.send_payed_period_ending_to_jira(account.BriefAccount(account_name))
        except:
            logging.error("payed period ending notification sending failed for account=%s" % str(row['accountname']), exc_info=True)

    connection.close()

def send_nethouse_payed_period_ending_notifications():
    connection = db_utils.get_connection()
    rows = connection.query('select * from endingpayedorderedserviceidview')
    for row in rows:
        try:
            account_name = row['accountname']
            logging.warn('send_payed_period_ending ' + account_name)
            wm_mail.mailer.send_nethouse_payed_period_ending(account.BriefAccount(account_name))
        except:
            logging.error("nethouse payed period ending notification sending failed %s" % str(row['id'] if 'id' in row else 0), exc_info=True)
    connection.close()

def automatic_reorder():
    connection = db_utils.get_connection()

    rows = connection.query('select * from orderedserviceforautoreorderview')
    for row in rows:
        try:
            account_name = row['accountname']
            is_partner_client = row['is_partner_client']
            tariff = Tariff.get(account_name, row['tariffkey'])
            os_settings = json.loads(row['settings'])
            operatorsCnt = os_settings.get('online_operators_limit', tariff.settings['online_operators_limit'])
            options = {
                'monthCnt': row['monthcnt'],
                'operatorsCnt': operatorsCnt,
                'tariffKey': row['tariffkey'],
                'paymentMethod': 'invoicebox' if row['paymentmethod'] == 'robokassa' else row['paymentmethod'], # TODO: временный хардкод для перехода на InvoiceBox
                'replacedId': None,
            }
            id = order(account_name, options)
            os = load_by_id(id)

            if account_name in wm_settings.settings.get('big_accounts', []):
                set_payment_guaranteed(id)

            wm_mail.mailer.send_service_reordered(account.BriefAccount(account_name), {
                'tariff_name': tariff.descriptor['name'],
                'payment_method': os['paymentmethod'],
                'invoice_guid': os['invoiceguid'],
                'operators_cnt': operatorsCnt,
                'price': os['price'],
                'payed_till_date': row['dtmto'].strftime('%d.%m.%Y'),
                'dtm_from': os['dtmfrom'].strftime('%d.%m.%Y'),
                'dtm_to': os['dtmto'].strftime('%d.%m.%Y'),
            }, is_partner_client=is_partner_client)
        except:
            logging.error("automatic reorder failed %s" % str(row['id'] if 'id' in row else 0), exc_info=True)
    connection.close()

def update_accounts(request_handler):
    connection = db_utils.get_connection()
    rows = connection.query("select * from accountfororderedservicedailyprocessing")
    logging.warn('Ordered service - accounts updating: loaded ' + str(len(rows)) + ' accounts')
    for row in rows:
        try:
            request_handler.write(row['accountname'] + "\n")
            update_account(row)
        except:
            logging.error("account updating failed for account %s" % (row['accountname'] if 'accountname' in row else ''), exc_info=True)
    connection.close()

def update_account(account_row):
    account_name = account_row['accountname']
    tariff = account_row['tariff']
    profreedate = account_row['profreedate']
    if tariff == 'test' and datetime.date.today() <= profreedate:
        return #do nothing - testing periood

    current_os = load_one("select * from orderedservice where accountname=%s and status in ('payed', 'payment_guaranteed') and dtmfrom <= curdate() and curdate() <= dtmto order by id desc limit 1", account_name)
    if current_os:
        os_row_is_verified, error_type = verify_os_row(current_os)
        if os_row_is_verified:
            logging.warn('accounts updating: current_os found for account ' + account_name)
            blocked = False
            tariff = current_os['tariffkey']
            settings = current_os['settings']
            max_dtmto_row = load_one("select max(dtmto) dtmto from orderedservice where accountname=%s and status in ('payed', 'payment_guaranteed')", account_name)
            profreedate = max_dtmto_row['dtmto']
        else:
            logging.warn('accounts updating: incorrect signature in current_os for account @{}. error_type="{}"'.format(account_name, error_type))
            settings = '{}'
            blocked = True
    elif tariff == 'free':
        settings = '{}'
        blocked = False
    else:
        logging.warn('accounts updating: current_os NOT found for account ' + account_name)
        settings = ''
        blocked = True
        if account_row['isblocked'] != 1:
            if tariff == 'test':
                wm_mail.mailer.send_service_blocked_after_test(account.BriefAccount(account_name))
            else:
                wm_mail.mailer.send_service_blocked(account.BriefAccount(account_name))

    connection = db_utils.get_connection()
    #TODO EM remove isblocked setting later when new version of set-account-status.php (which do isblocked setting) will be on all servers
    connection.execute('update account set isblocked=%s, tariff=%s, tariff_settings=%s, profreedate=%s where accountname=%s',
                       blocked, tariff, settings, profreedate, account_name)
    connection.close()

    wm_utils.request_php_service(account_name, 'set-account-status.php', partner_name=account_row['partner'], enabled=('false' if blocked else 'true'))

def calculate(account_name, options, ignore_existing_pending=True):
    month_cnt = options['monthCnt']
    operators_cnt = options['operatorsCnt']
    tariff = Tariff.get(account_name, options['tariffKey'])

    price_per_month = tariff.descriptor['base_price']

    if operators_cnt > tariff.settings['online_operators_limit']:
        price_per_month += (operators_cnt - tariff.settings['online_operators_limit']) * tariff.descriptor['per_operator_price']

    discount = tariff.descriptor.get('discounts', {}).get(str(month_cnt))
    discount = discount or ACCOUNT_NAME_TO_CACHED_DISCOUNTS.get(account_name).get_data()[str(month_cnt)]
    price_per_month = price_per_month * (1 - 0.01 * discount)

    total_price = int(price_per_month * month_cnt)

    date_from = None

    if options['replacedId']:
        changingOs = load_by_id(options['replacedId'])
        date_from = changingOs['dtmfrom']
        date_to = changingOs['dtmto']
        month_cnt = changingOs['monthcnt']

        payed_before = calculate_total_payed(options['replacedId'])
        total_days = (changingOs['dtmto'] - changingOs['dtmfrom']).days
        day_diff = (changingOs['dtmto'] - datetime.date.today()).days if datetime.date.today() > changingOs['dtmfrom'] else total_days
        part_of_period = day_diff / float(total_days)

    else:
        payed_before = 0
        part_of_period = 1
        last_os = load_last(account_name)

        if not ignore_existing_pending and last_os and last_os['status'] == 'pending':
            raise PendingOrderFoundException

        if last_os:
            date_from = last_os['dtmto']
            date_from += datetime.timedelta(days=1)
        if not date_from:
            account_row = load_one('select profreedate, tariff from account where accountname=%s', account_name)
            if account_row['profreedate'] and account_row['tariff'] == 'test':
                date_from = account_row['profreedate'] + datetime.timedelta(days=1)
        if not date_from or date_from < datetime.date.today():
            date_from = datetime.date.today()

        #todo AL/EM protect from passing dtmto from client
        date_to = options['dtmto'] if 'dtmto' in options else calculate_date_to(date_from, month_cnt)

    price_to_pay = int(round((total_price - payed_before) * part_of_period, 0))
    return {
        'pricePerMonth': round(price_per_month, 2),
        'totalPrice': total_price,
        'from': date_from,
        'to': date_to,
        'priceToPay': price_to_pay,
        'monthCnt': month_cnt
    }

def calculate_date_to(date_from,month_cnt):
    to_year, to_month, to_day = date_from.year, date_from.month, date_from.day
    to_month += month_cnt
    while to_month > 12:
        to_year += 1
        to_month -= 12
    if to_day > calendar.monthrange(to_year, to_month)[1]:
        to_day = 1
        to_month += 1
    return datetime.date(to_year, to_month, to_day) - datetime.timedelta(days=1)


def set_free_tariff(account_name):
    current_os = load_current_ordered_service(account_name)
    if current_os:
        return False
    connection = db_utils.get_connection()
    connection.execute('update account set isblocked=%s, tariff=%s, tariff_settings="{}" where accountname=%s', False, 'free', account_name)
    connection.close()

    brief_account = account.BriefAccount(account_name)
    wm_utils.request_php_service(account_name, 'set-account-status.php', partner_name=brief_account.partner_name, enabled='true')
    brief_account.tariff_settings.reset()
    return True


def order(account_name, options, ignore_existing_pending=True):
    partner_client = options.get('partner_client', '')
    calculated = calculate(partner_client if partner_client else account_name, options, ignore_existing_pending=ignore_existing_pending)
    if options['replacedId'] and calculated['priceToPay'] <= 0:
        return False
    invoice_guid = create_invoice(account_name, calculated['priceToPay'], options['paymentMethod'], calculated['from'], calculated['to'], partner_client)

    tariff = Tariff.get(account_name, options['tariffKey'])
    settings = {}
    if options['operatorsCnt'] > tariff.settings['online_operators_limit']:
        settings['online_operators_limit'] = options['operatorsCnt']

    values = {
        'accountname': partner_client if partner_client else account_name,
        'dtmfrom': calculated['from'],
        'dtmto': calculated['to'],
        'monthcnt': options['monthCnt'],
        'tariffkey': tariff.key,
        'settings': json.dumps(settings),
        'description': u'Тариф: %s, операторов: %s' % (tariff.descriptor['name'], options['operatorsCnt']),
        'price': calculated['priceToPay'],
        'invoiceguid': invoice_guid,
        'paymentmethod': options['paymentMethod'],
        'dtmcreated': datetime.datetime.now(),
        'status': 'payed' if partner_client else 'pending',
        'autoreorder': 0 if options['paymentMethod'] == 'paypal' else 1,
        'replacedid': options['replacedId']
    }
    connection = db_utils.get_connection()
    result = store_record(connection, 'orderedservice', values)
    connection.close()
    return result


def create_invoice(account_name, totalPrice, paymentMethod, dtmfrom = None, dtmto = None, partnerClient = ''):
    response = wm_utils.request_php_service(account_name, 'make-invoice.php', method=paymentMethod, amount=totalPrice, dfrom=dtmfrom, dto=dtmto, client=partnerClient)
    return json.loads(response)['guid']


def cancel(id, account_name, force_for_already_started_payment_guaranteed=False):
    connection = db_utils.get_connection()
    if force_for_already_started_payment_guaranteed:
        connection.execute("UPDATE orderedservice SET status = 'canceled' WHERE id = %s AND status = 'payment_guaranteed'", id)
        wm_mail.mailer.send_os_payment_canceled_mail({'accountname': account_name, 'id': id})
    else:
        connection.execute("UPDATE orderedservice SET status = 'canceled' WHERE id = %s AND (status = 'pending' OR (status = 'payment_guaranteed' AND dtmfrom > %s))", id, datetime.date.today())

    # profile = load_active_profile(account_name)
    # if profile and profile['firstosid'] == id:
    #     connection.execute("update recurringpaymentprofile set profilestatus=%s, dtmmodified=%s where profileid=%s and firstosid=%s", 'Cancelled', datetime.datetime.now(), profile['profileid'], str(id))
    connection.close()


def change_os_price(id, new_price):
    os = load_by_id(id)
    comment = ''
    if os['comment']:
        comment += os['comment'] + '; '
    comment += '%s: changing price %s -> %s' % (datetime.date.today(), os['price'], new_price)
    connection = db_utils.get_connection()
    connection.execute('update orderedservice set price=%s, comment=%s where id=%s',
                       new_price, comment, id)
    connection.close()
    change_invoice_price(os['invoiceguid'], new_price)
    wm_mail.mailer.send_os_price_changed_mail({
        'accountname': os['accountname'],
        'id': os['id'],
        'old_price': os['price'],
        'new_price': new_price
    })

def change_invoice_price(guid, new_price):
    connection = db_utils.get_connection()
    connection.execute('update invoice set price=%s where guid=%s',
                       new_price, guid)
    connection.close()

def store_record(connection, table_name, value_dict):
    items = value_dict.items()[:]
    names = [k for k, v in items]
    values = [v for k, v in items]
    query = 'insert into ' + table_name + ' (' + ', '.join(names) + ') values (' + ', '.join(['%s'] * len(names)) + ')'
    return connection.execute(query, *values)


def load_last(account_name):
    row = load_one("select * from orderedservice where accountname=%s and status != 'canceled' order by dtmfrom desc, id desc limit 1", account_name)
    return row


def load_by_id(id):
    row = load_one('select * from orderedservice where id=%s', id)
    return row

def load_active_profile(account_name):
    return load_one("select * from recurringpaymentprofile where accountname=%s and profilestatus = 'Active' order by id desc limit 1", account_name)

def load_one(query, *params):
    connection = db_utils.get_connection()
    result = connection.get(query, *params)
    connection.close()
    return result

def date_to_ts(data):
    if isinstance(data, list):
        for i, value in enumerate(data):
            if isinstance(value, (list, dict)):
                date_to_ts(value)
            elif isinstance(value, (datetime.date, datetime.datetime)):
                data[i] = int(value.strftime('%s'))
    elif isinstance(data, dict):
        for key, value in data.items():
            if isinstance(value, (list, dict)):
                date_to_ts(value)
            elif isinstance(value, (datetime.date, datetime.datetime)):
                data[key] = int(value.strftime('%s'))
    return data

def calculate_total_payed(replacedId):
    total_payed = 0
    connection = db_utils.get_connection()
    row = connection.get("select * from orderedservice os where os.id=%s", replacedId)
    total_payed += row['price']
    if row['replacedid']:
        total_payed += calculate_total_payed(row['replacedid'])
    connection.close()
    return total_payed


class SendPayedPeriodEndingNotificationsRequestHandler(tornado.web.RequestHandler):

    @tornado.web.asynchronous
    def get(self, *args, **kwargs):
        def process():
            self.write('<pre>')
            log(self, "send_payed_period_ending_notifications\n")
            send_ending_account_notifications()
            send_nethouse_payed_period_ending_notifications()
            log(self, "end\n")
            self.finish('</pre>')
        wm_timer.invoke_async(process, 'send_payed_period_ending_notifications')


class PendingOrderFoundException(wm_utils.WebimException):
    pass
