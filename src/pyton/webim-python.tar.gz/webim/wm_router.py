__author__ = 'andrew'
import logging
import json

import suds
import requests


class Router:

    default_url = "https://www.tinkoff.ru/"
    default_user_id = 0

    def __init__(self, account, schema_url):
        self.account = account
        self.client = suds.client.Client(schema_url, timeout=5)

    def route_chat(self, chat):
        request = self.prepare_lookup_request(chat)

        logging.warn('Router: routing chat %s\nRequest: %s' % (str(chat.id), request))

        try:
            resp = self.client.service.lookup(request)
            self.__route_chat(chat, resp)
        except Exception:
            logging.error('Failed to route chat %s' % (str(chat.id)), exc_info=True)
            chat.process_event('sys.routing_failed')

    def __route_chat(self, chat, response):
        # print response
        if response.code not in ['skill', 'employee']:
            logging.warn('Router: wrong code in response %s' % response)
            chat.process_event('sys.routing_failed')
            return

        logging.warn('Router: routing response for chat %s - %s' % (str(chat.id), response))

        extra = {}
        if response.additionalField:
            try:
                extra = json.loads(response.additionalField)
            except Exception:
                logging.error('Router: additionalField json loading failed')

        chat.session.visitor.update_custom_fields(
            {
                'siebelId': response.siebelId,
                'taskId': extra.get('taskId')
            }
        )

        if response.code == 'skill':
            department = self.account.get_department(response.skill)
            if department:
                chat.process_event('sys.routing_to_department', attrs={'department_key': response.skill})
            else:
                logging.warn('Router: department %s not found' % str(response.skill))
                chat.process_event('sys.routing_failed')

        elif response.code == 'employee':
            operator = self.account.get_operator_by_email(response.skill)
            if operator:
                chat.process_event('sys.routing_to_operator', attrs={'operator_id': operator.id})
            else:
                logging.warn('Router: operator %s not found' % str(response.skill))
                chat.process_event('sys.routing_failed')

    def prepare_lookup_request(self, chat):
        request = self.client.factory.create('LookupRequestType')

        request.chatId = chat.id

        if False and chat.routing_test:
            request.channel = chat.routing_test.get('type')
            request.userId = chat.routing_test.get('id') or self.default_user_id
            request.url = chat.routing_test.get('url') or self.default_url
        else:
            channel = self.get_channel(chat)

            request.channel = channel
            request.userId = self.get_user_id(chat) or self.default_user_id
            request.url = chat.start_page.url or self.default_url

        m = chat.get_last_visitor_message()
        if m:
            request.message = m.text

        return request

    def get_channel(self, chat):
        session = chat.session

        if session.visitor.channel_type:
            if session.visitor.channel_type == 'vk':
                return 'vkontakte'

            if session.visitor.channel_type == 'telegram':
                if session.visitor.fields.get('phone'):
                    return 'telegram_mob'
                else:
                    return 'telegram'

            if session.visitor.channel_type == 'blinger_whatsapp':
                return 'whatsapp'

            return session.visitor.channel_type

        if session.visitor.provided_fields.get('id'):
            return 'portal_auth' if session.platform == 'web' else 'mobile_auth'
        else:
            return 'portal_noauth' if session.platform == 'web' else 'mobile_noauth'

    def get_user_id(self, chat):
        channel = self.get_channel(chat)
        if channel == 'whatsapp':
            return chat.session.visitor.channel_user_name

        if channel == 'telegram_mob':
            return chat.session.visitor.fields.get('phone')

        return chat.session.visitor.provided_fields.get('id') or chat.session.visitor.channel_user_id

    def on_telegram_phone_added(self, chat):
        request = self.prepare_lookup_request(chat)
        logging.warn('Router: on telegram phone added routing  %s\nRequest: %s' % (str(chat.id), request))

        try:
            response = self.client.service.lookup(request)
            logging.warn('Router: on telegram phone added routing response for chat %s - %s' % (str(chat.id), response))

            chat.session.visitor.update_custom_fields(
                {
                    'siebelId': response.siebelId,
                }
            )

        except Exception:
            logging.error('Failed on telegram phone added routing %s' % (str(chat.id)), exc_info=True)
            chat.process_event('sys.routing_failed')


def get_router(account):
    if account.get_setting('custom_router_schema_url'):
        try:
            # checking connection to TCS vpn first
            # because suds client cache schema
            # TODO delete after deploy to production
            requests.get(account.get_setting('custom_router_schema_url'), timeout=3)

            r = Router(account, account.get_setting('custom_router_schema_url'))
            logging.warn('Router init success for %s' % account.name)
            return r
        except Exception:
            logging.error('Router init failed for %s' % account.name, exc_info=True)
            pass

    return None