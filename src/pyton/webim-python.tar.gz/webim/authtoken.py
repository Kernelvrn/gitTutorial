#!/usr/bin/env python
# -*- coding: utf-8 -*-
import wm_utils


class CachedAuthTokens(wm_utils.CachedDBData):
    def __init__(self, authtoken):
        wm_utils.CachedDBData.__init__(self, None)
        self.token = authtoken
        decoded = authtoken.decode('base64')
        self.operator_id = decoded.split("|")[0]

    def load_data(self, connection):
        result = False
        data = connection.get('SELECT * FROM authtoken WHERE operatorid = %s AND authtoken = %s', self.operator_id, self.token)
        if data:
            connection.execute('UPDATE authtoken SET modified = current_timestamp() WHERE id = %s', data['id'])
            result = True
        return result
