import re
import logging
import os
import hashlib
import time

import torndb

import wm_settings


__author__ = 'mixey'


class Connection(torndb.Connection):
    def __init__(self, host, database, user=None, password=None, use_ssl=False):
        self.use_ssl = use_ssl
        super(Connection, self).__init__(host, database, user, password)

    def reconnect(self):
        self._db_args['connect_timeout'] = wm_settings.settings.get('python_db_connect_timeout', 10)
        if self.use_ssl:
            self._db_args['ssl'] = {'cert': wm_settings.settings.get('ssl_client_cert', '/etc/mysql/client-cert.pem'),
                                    'key': wm_settings.settings.get('ssl_client_key', '/etc/mysql/client-key.pem')}

        super(Connection, self).reconnect()


def get_connection(account_name=None):
    db_type = 'pro' if account_name else 'meta'

    db_settings = wm_settings.get_account_db_settings(account_name)[db_type] if account_name else wm_settings.db_settings[db_type]

    if db_type == 'pro':
        db_settings = db_settings.get(account_name, db_settings['default'])

    slave = check_slave(account_name, db_type)

    if slave:
        if 'slave' in db_settings:
            db_settings = db_settings['slave']
        else:
            logging.error('Slave db settings not found for account %s, db_type=%s' % (account_name, db_type))
            raise NoSlaveDBSettingsException('NoSlaveDBSettingsException raised!')

    port = ':' + str(db_settings['port']) if 'port' in db_settings else ''
    schema_name = get_schema_name(account_name) if account_name else db_settings['database']

    try:
        connection = Connection(db_settings['host'] + port, schema_name, db_settings['user'], db_settings['password'], db_settings.get('ssl', 0))
        connection.execute('set time_zone=SYSTEM')
        connection.execute('SET NAMES utf8mb4 COLLATE utf8mb4_unicode_ci')

        if not slave:
            db_failure_tracker.reset(db_settings['host'], port, schema_name)

        return connection
    except Exception:
        logging.error('Connection to db failed, type=%s, account_name=%s' % (db_type, str(account_name)))

        if db_failure_tracker.on_failure(db_settings['host'], port, schema_name):
            logging.error('Too many errors with %s db for %s.' % (db_type, account_name or 'login'))
            if not slave and 'slave' in db_settings:

                logging.error('Creating slave file for %s.' % account_name or 'login')
                create_slave_file(account_name, db_type)

                logging.error('Trying slave connection...')
                return get_connection(account_name)
            else:
                raise
        else:
            raise


account_pattern = re.compile('^(\w)+$')


def get_schema_name(account_name):
    if account_name:
        if not account_pattern.match(account_name):
            raise Exception('Account name is not allowed: ' + account_name)
        schema_name = 'webim_service_pro_' + account_name
    else:
        schema_name = 'mysql'
    return schema_name


def check_slave(account_name, db_type):
    account_name = account_name or 'login'
    if os.path.isdir('/var/pro/client-data/cd/%s/db/' % account_name):
        return os.path.isfile('/var/pro/client-data/cd/%s/db/%s-slave.txt' % (account_name, db_type))
    else:
        os.makedirs('/var/pro/client-data/cd/%s/db/' % account_name)
        return False


def create_slave_file(account_name, db_type):
    account_name = account_name or 'login'

    if not check_slave(account_name, db_type):
        filename = '/var/pro/client-data/cd/%s/db/%s-slave.txt' % (account_name, db_type)
        open(filename, 'a').close()
    else:
        logging.error('%s-slave.txt already existed for %s' % (db_type, account_name))


class NoSlaveDBSettingsException(Exception):
    pass


class DBConnectionFailureTracker():

    def __init__(self):
        self.failure_times = {}

    def __get_hash(self, host, port, schema_name):
        m = hashlib.md5()
        m.update(host + port + schema_name)
        return m.hexdigest()

    def __update_failure_time(self, db_hash):
        self.failure_times[db_hash] = time.time()

    def reset(self, host, port, schema_name):
        db_hash = self.__get_hash(host, port, schema_name)

        if db_hash in self.failure_times:
            del self.failure_times[db_hash]  # or =0, or =None???

    def on_failure(self, host, port, schema_name):
        db_hash = self.__get_hash(host, port, schema_name)

        if db_hash not in self.failure_times:
            self.__update_failure_time(db_hash)
            return False
        else:
            if time.time() - self.failure_times[db_hash] <= 60:
                return False
            else:
                return True


db_failure_tracker = DBConnectionFailureTracker()