# coding=UTF-8

import os.path
import logging

import wm_settings
import visitor_tracking
import wm_web
import wm_utils
from wm_operator import OnlineState


__author__ = 'mixey'


class ButtonRequestHandler(wm_web.BaseWebimRequestHandler):

    filename_to_cached_content = {}

    online_status_to_postfix = {
        'on': '_on',    # for oldschool clients support
        'off': '_off',  # for oldschool clients support
        'online': '_on',
        'offline': '_off',
        'busy_online': '_on_busy',
        'busy_offline': '_off_busy',
    }

    extention_to_content_type = {
        'gif': 'image/gif',
        'png': 'image/png',
        'jpg': 'image/jpeg',
        'jpeg': 'image/jpeg',
        'swf': 'image/swf',
    }

    def get(self, *args, **kwargs):
        account = self.get_account()

        location = self.get_verified_argument('location', None, pattern='^(\w|-|\.)+$')
        location_settings = account.get_location_settings(location)

        chat_settings = location_settings.get('chat', {})
        button_settings = location_settings.get('button', {})

        if self.get_verified_argument('locale', None):  # todo enum
            lang = self.get_verified_argument('locale', None)
        else:
            default_lang = account.get_setting('default_lang')
            lang = chat_settings.get('lang', default_lang) if account.get_setting('multilang') else default_lang

        force_status = self.get_verified_argument('force-status', None)  # todo enum
        force_show = self.get_verified_argument('force-show', None)
        online_status = force_status if force_status else visitor_tracking.VisitedPage.get_online_status(account, location, lang, self._get_lang_to_geo())
        button_name = self.get_verified_argument('button-name', None, pattern=self.ARG_PATTERN_FILENAME)
        show_offline = button_settings.get('offlineEnabled', 'Y') != 'N' and account.tariff_settings.get('offline_message')

        if button_name and button_name != 'html':
            filename = self.get_button_filename(button_name, lang, online_status)
        elif (not show_offline and online_status in [OnlineState.OFFLINE, OnlineState.BUSY_OFFLINE]
              or 'kind' in button_settings and button_settings['kind'] != 'simple' and not force_show
              or button_settings.get('kind') == 'html'):
            filename = self.get_button_filename('empty.gif', lang, online_status)
        else:
            filename = self.get_button_filename(button_settings.get('name', 'corner.gif'), lang, online_status)

        content = self.get_button_file_content(filename)
        if not content:
            filename = self.get_button_filename('empty.gif', lang, online_status)
            content = self.get_button_file_content(filename)

        if filename.rfind('.') >= 0:
            extention = filename[filename.rfind('.') + 1:]
            if extention in self.extention_to_content_type:
                self.set_header("Content-Type", self.extention_to_content_type[extention])

        if content is None:
            logging.warn('content is None; filename: ' + filename)

        self.write(content)

    def get_button_filename(self, base_filename, lang, online_status):
        account = self.get_account()
        idx = base_filename.rindex('.')
        filename = base_filename[0:idx] + (self.online_status_to_postfix[online_status] if base_filename != 'empty.gif' else '_on') + base_filename[idx:]
        button_filename = os.path.join(wm_settings.public_html_dir + 'webim/themes/.buttons', lang, filename)
        if filename.find(account.name) != 0:
            return button_filename
        else:
            button_path = os.path.join(account.get_client_data_dir(), 'images', 'buttons', lang, filename)
            if not os.path.exists(button_path):
                return button_filename
            return button_path

    def get_button_file_content(self, filename):
        if filename in self.filename_to_cached_content:
            cached_content = self.filename_to_cached_content[filename]
        else:
            cached_content = CachedFileContent(filename)
            self.filename_to_cached_content[filename] = cached_content
        return cached_content.get_data()


class CachedFileContent(wm_utils.CachedData):

    def __init__(self, filename):
        wm_utils.CachedData.__init__(self, 3 * 60 * 60)
        self.filename = filename

    def obtain_data(self):
        if not os.path.exists(self.filename):
            return None
        data_file = open(self.filename, "rb")
        try:
            return data_file.read()
        finally:
            data_file.close()
