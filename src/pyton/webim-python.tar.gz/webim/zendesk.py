#!/usr/bin/env python
# -*- coding: utf-8 -*-

import urllib2
import base64
import logging
import json

import tornado.web
import requests

import wm_web
import wm_timer
import wm_resources
from wm_utils import WebimException


class ZendeskRequestHandler(wm_web.TimeoutedRequestHandler, wm_web.BaseWebimRequestHandler):
    @tornado.web.asynchronous
    def get(self):
        wm_timer.invoke_async(self.create_ticket, "create_ticket")

    def check_zendesk_options(self, options):
        r = self.api_request(options, 'users/me.json')
        if r and r['user']['created_at']:
            return True
        else:
            return False

    def create_ticket(self):
        session_id = self.get_argument('session_id', None)
        options = self.get_account().settings.get('zendesk')
        if not self.check_zendesk_options(options):
            self.error('Zendesk user not found. Check your settings.')
            return
        logging.info('Session: %s Zendesk: %s' % (session_id, options))
        if not session_id or not options:
            self.error('Zendesk integration error')
            return
        session = self.get_account().visit_tracker.get_session(session_id)
        if session is None or session.chat is None:
            self.error('Chat not found')
            return
        zendesk_visitor = self.get_visitor_zendesk_user(options, session.visitor)
        zendesk_operator = self.get_operator_zendesk_user(options)

        if zendesk_visitor is None:
            self.error('Zendesk user not created')
            return

        ticket = {'requester_id': zendesk_visitor['id'], 'external_id': session.chat.id}
        ticket['subject'] = 'Webim support request'
        ticket['description'] = ''
        for m in session.chat.messages:
            ticket['description'] += session.chat.format_message_for_history(m) + '\n'

        if zendesk_operator:
            ticket['assignee_id'] = zendesk_operator['id']

        ticket = self.api_request(options, 'tickets.json', {'ticket': ticket})

        if ticket is None:
            self.error('Ticket not created')
            return

        url = 'https://%s.zendesk.com/tickets/%s' % (options['zendesk_account'], ticket['ticket']['id'])
        self.redirect(url)

    def get_operator_zendesk_user(self, options):
        result = self.api_request(options, 'users/search.json?query=%s' % self.get_operator().email)
        if result['count'] > 0:
            return result['users'][0]
        else:
            return None

    def get_visitor_zendesk_user(self, options, visitor):
        result = self.api_request(options, 'users/search.json?external_id=%s' % str(visitor.id))
        if result['count'] > 0:
            return result['users'][0]

        if 'email' in visitor.fields:
            result = self.api_request(options, 'users/search.json?query=%s' % str(visitor.fields['email']))
            if result['count'] > 0:
                return result['users'][0]
            else:
                user = {'name': visitor.fields['name'], 'external_id': str(visitor.id)}
                user['email'] = visitor.fields['email']
                if 'phone' in visitor.fields:
                    user['phone'] = visitor.fields['phone']
                user['details'] = json.dumps(visitor.to_dict()['fields'], ensure_ascii=False, indent=2)
                result = self.api_request(options, 'users.json', {'user': user})
                if result:
                    return result['user']

        result = self.api_request(options, 'users/search.json?query=%s' % self.get_operator().email)
        if result['count'] > 0:
            return result['users'][0]

        return None

    def api_request(self, options, request, data=None):
        req = urllib2.Request('https://%s.zendesk.com/api/v2/%s' % (options['zendesk_account'], request))
        if data:
            data = json.dumps(data, ensure_ascii=True, indent=2)
            req.add_data(data)
        req.add_header('Authorization', 'Basic ' + base64.urlsafe_b64encode("%s:%s" % ('%s' % options['zendesk_login'], options['zendesk_token'])))
        req.add_header('Content-Type', 'application/json')
        try:
            result = urllib2.urlopen(req, timeout=15).read()
            return json.loads(result)
        except urllib2.URLError as e:
            message = 'Url %s error: %s\n' % (request, str(e))
            logging.error(message)
            return None
        except Exception as e:
            message = 'Something wrong: %s\n', str(e)
            logging.error(message)
            return None

    def error(self, message):
        self.finish(json.dumps({'error': message}))

    def on_timeout(self):
        self.error('Timeout')


class Zendesk:

    def __init__(self, settings):
        self.settings = settings
        # self.authorized = self.check_zendesk_settings()

    def __get_request(self, request, data=None):
        if self.settings['zendesk_account'] != 'avito':
            request_url = 'https://%s.zendesk.com/api/v2/%s' % (self.settings['zendesk_account'], request)
        else:
            request_url = 'https://support.avito.ru/api/v2/%s' % request
        r = requests.get(url=request_url,
                         auth=(self.settings['zendesk_login'] + '/token', self.settings['zendesk_token']),
                         params=data)

        if r.status_code >= 400:
            raise ZendeskConnectionException('Response from Zendesk with error code %s, %s' % (str(r.status_code), str(r.json())))
        elif 'error' in r.json():
            raise ZendeskConnectionException(str(r.json()))
        else:
            return r.json()

    def __post_request(self, request, data):
        headers = {'content-type': 'application/json'}
        if self.settings['zendesk_account'] != 'avito':
            request_url = 'https://%s.zendesk.com/api/v2/%s' % (self.settings['zendesk_account'], request)
        else:
            request_url = 'https://support.avito.ru/api/v2/%s' % request
        r = requests.post(url=request_url,
                          data=json.dumps(data),
                          headers=headers,
                          auth=(self.settings['zendesk_login'] + '/token', self.settings['zendesk_token']))

        if r.status_code >= 400:
            raise ZendeskConnectionException('Response from Zendesk with error code %s' % str(r.status_code))
        elif 'error' in r.json():
            raise ZendeskConnectionException(r.json()['error'])
        else:
            return r.json()

    def __put_request(self, request, data):
        headers = {'content-type': 'application/json'}
        if self.settings['zendesk_account'] != 'avito':
            request_url = 'https://%s.zendesk.com/api/v2/%s' % (self.settings['zendesk_account'], request)
        else:
            request_url = 'https://support.avito.ru/api/v2/%s' % request
        r = requests.put(url=request_url,
                         data=json.dumps(data),
                         headers=headers,
                         auth=(self.settings['zendesk_login'] + '/token', self.settings['zendesk_token']))

        if r.status_code >= 400:
            raise ZendeskConnectionException('Response from Zendesk with error code %s' % str(r.status_code))
        elif 'error' in r.json():
            raise ZendeskConnectionException(r.json()['error'])
        else:
            return r.json()

    def request(self, request_type, request, data=None):
        try:
            if request_type == 'get':
                r = self.__get_request(request, data)
            elif request_type == 'post':
                r = self.__post_request(request, data)
            elif request_type == 'put':
                r = self.__put_request(request, data)
            else:
                raise ZendeskConnectionException('Wrong request method chosen')

        except ZendeskConnectionException as e:
            logging.error('Zendesk connection error, message: %s, method=%s, request=%s, data=%s' % (e.error, request_type, request, str(data)))
            raise ZendeskException(e.error)
        return r

    def check_zendesk_settings(self):
        r = self.request('get', 'users/me.json')
        if r and r['user']['created_at']:
            return True
        else:
            return False

    def get_visitor_user(self, visitor, form_response=None):
        if not form_response:
            visitor_email = visitor.fields['email']
        else:
            if form_response['visitorShouldSeeTicketId']:
                visitor_email = form_response['formData']['email']
            else:
                visitor_email = 'fake@email.ru'  # TODO: fake email

        visitor_user = self.request('get', 'users/search.json', data={'query': visitor_email})

        if visitor_user['count'] > 0:
                return visitor_user['users'][0]
        else:
            return None

    def create_description(self, session, data=None, form_response=None):
        description = ''

        if form_response:
            account = session.account
            for field in form_response['formData']:
                try:
                    res = (wm_resources.get_resource(account, account.settings.get('default_lang'), 'zendesk.field.' + field)
                           + u': ' + unicode(form_response['formData'][field]))
                    description += res + '\n'
                except Exception:
                    pass
            description += '\n\n'

            if 'additionalParams' in form_response:
                for param in form_response['additionalParams']:
                    description += str(param) + ': ' + form_response['additionalParams'][param] + '\n'
                description += '\n\n'

        for m in session.chat.messages:
            description += session.chat.format_message_for_history(m) + '\n' if m.visible_by_visitor() else ''

        return description

    def get_operator_user(self, operator):
        operator_user = self.request('get', 'users/search.json', {'query': operator.email if operator else self.settings['zendesk_login']})
        if operator_user['count'] > 0:
            return operator_user['users'][0]
        else:
            return None

    def create_ticket(self, session, data=None, form_response=None):
        ticket = self.get_ticket_dict(None, None, session, data=data, form_response=form_response)

        created_ticket = self.request('post', 'tickets.json', {'ticket': ticket})

        if data and data['description']:
            self.add_comment_to_ticket(created_ticket['ticket']['id'], data['description'], session)

        return created_ticket

    def add_comment_to_ticket(self, ticket_id, comment, session, public=False):
        data = {'ticket': {'comment': {'body': comment, 'public': public}}}

        operator = self.get_operator_user(session.chat.get_operator()) if session.chat else None
        if operator:
            data['ticket']['comment']['author_id'] = operator['id']

        self.request('put', 'tickets/%s.json' % str(ticket_id), data=data)

    def get_requester(self, session, visitor, form_response):
        if form_response:
            if form_response['visitorShouldSeeTicketId']:
                form_data = form_response['formData']
                user = {'email': form_data['email']}
                if 'username' in form_data:
                    user['name'] = form_data['username']
                elif visitor:
                    user['name'] = visitor.get_field_value('name')
                else:
                    user['name'] = wm_resources.get_resource(session.account, session.lang, 'chat.default.visitorname')
            else:
                user = session.account.settings.get('fake_zendesk_requester')
                if not user:
                    user = self.get_operator_as_requester(session)
            return user
        elif visitor:
            user = {'name': visitor.get_field_value('name') or wm_resources.get_resource(session.account, session.lang, 'chat.default.visitorname'),
                    'email': visitor.get_field_value('email')}
            if not user['email']:
                user = self.get_operator_as_requester(session)
            return user

    def get_operator_as_requester(self, session):
        op = session.chat.get_operator()
        return {'name': op.get_fullname(session.lang), 'email': op.email}

    def get_ticket_dict(self, visitor, operator, session, data=None, form_response=None):
        ticket = {'external_id': session.chat.id}

        if data:
            ticket['subject'] = (data['subject']
                                 or wm_resources.get_resource(session.account, session.account.settings.get('default_lang'), 'zendesk.subject.default'))
        elif form_response:
            ticket['subject'] = wm_resources.get_resource(session.account, session.account.settings.get('default_lang'), 'zendesk.subject.form_avito_default')
            ticket['tags'] = self.get_ticket_tags(form_response, session)

        if visitor:
            ticket['requester_id'] = visitor['id']
        else:
            ticket['requester'] = self.get_requester(session, visitor=session.visitor, form_response=form_response)

        if operator:
            ticket['assignee_id'] = operator['id']

        ticket['comment'] = {
            'body': self.create_description(session, data=data, form_response=form_response),
        }

        return ticket

    def get_ticket_tags(self, form_response, session):
        tags = ['channel_chat']
        if session and session.chat:
            try:
                oo = session.account.oo_manager.get(session.chat.get_operator_id())
                form_id = form_response['formId']

                if oo.is_online_inf():
                    tag = 'inf_'
                else:
                    tag = 'chat_'

                if form_id == 'form_avito_common':
                    tag += 'other'
                elif form_id == 'form_avito_security':
                    tag += 'safety'
                elif form_id == 'form_avito_paymentfail':
                    tag += 'failed_payment'
                elif form_id == 'form_avito_paymentcommon':
                    tag += 'payments'
                else:
                    tag += 'common'

                tags.append(tag)
            except Exception as e:
                logging.error('problem at get_ticket_tags, error=%s' % e.message)

        return tags


class ZendeskConnectionException(WebimException):
    def __init__(self, error):
        self.error = error


class ZendeskException(WebimException):
    def __init__(self, error):
        self.error = error
