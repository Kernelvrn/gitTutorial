# coding=UTF-8
__author__ = 'andrew'

import json
import uuid
import logging

from tornado.websocket import WebSocketHandler

import wm_timer
import wm_utils
from delta import Delta


OLD_COBROWSING_SESSION_CLEANING_PERIOD = 5 * 60  # 5 min


class CobrowsingWebsocketHandler(WebSocketHandler):
    def __init__(self, application, request, **kwargs):
        super(CobrowsingWebsocketHandler, self).__init__(application, request, **kwargs)
        self.session = None
        self.role = None

    def check_origin(self, origin):
        return True

    def open(self):
        logging.warning('WebSocket opened')
        logging.warning("And it's unknown connection until init message... (which is lame)")

    def on_message(self, message_json):
        message = json.loads(message_json)

        if message['type'] == 'init':
            self.session = cobrowsing_session_manager.get_session_by_id(message['session_id'])
            self.role = message['role']
            if self.role == 'visitor':
                self.session.set_url(message['url'])
            self.session.set_connection(self.role, self)
        else:
            if self.session:
                self.session.on_message(message)

    def on_close(self):
        if self.session:  # защита от старых коннекшнов
            self.session.set_connection(self.role, None)
            logging.warning('WebSocket closed for %s %s' % (self.role, self.session.id))
            self.session = None


class CobrowsingSession(wm_utils.Jsonable):
    class State:
        WAITING_FOR_VISITOR = 'waiting_for_visitor'
        CONNECTED = 'connected'
        DISCONNECTED = 'disconnected'

    class StateReason:
        REJECTED_BY_VISITOR = 'rejected_by_visitor'
        CLOSED_BY_OPERATOR = 'closed_by_operator'
        CLOSED_BY_VISITOR = 'closed_by_visitor'
        NOT_SUPPORTED = 'not_supported'

    def __init__(self, id, visitor_connection=None, operator_connection=None):
        self.id = id
        self.connections = {
            'visitor': visitor_connection,
            'operator': operator_connection
        }

        self.visit_session = None

        self.alive = True
        self.check_operator_alive_timer = None

        self.state = self.State.WAITING_FOR_VISITOR
        self.last_state_reason = None

        self.url = None
        self.operator_id = None

    @classmethod
    def __get_new_id(cls):
        return uuid.uuid4().hex

    @classmethod
    def create(cls):
        return CobrowsingSession(cls.__get_new_id())

    def is_empty(self):
        return not any(self.connections.values())

    def to_dict(self, context=None):
        result = {'id': self.id,
                  'state': self.state,
                  'operatorId': self.operator_id,
                  'lastStateReason': self.last_state_reason,
                  'url': self.url}

        return result

    def set_state(self, new_state, reason=None, produce_delta=True):
        if new_state != self.state:
            self.state = new_state
            if reason:
                self.last_state_reason = reason
            if produce_delta:
                self.visit_session.add_operator_delta(
                    Delta("COBROWSING_STATE", Delta.Event.UPDATE, self.visit_session.id, {'state': self.state, 'reason': self.last_state_reason})
                )
                self.visit_session.delta_manager.add_delta(
                    Delta("COBROWSING_STATE", Delta.Event.UPDATE, self.visit_session.id, {'state': self.state, 'reason': self.last_state_reason})
                )

            if self.state == CobrowsingSession.State.DISCONNECTED:
                self.visit_session.cobrowsing_session = None
                self.stop_session()

    def set_url(self, url):
        if self.url != url:
            self.url = url
            self.visit_session.add_operator_delta(Delta("COBROWSING_SESSION", Delta.Event.UPDATE, self.visit_session.id, self))

    def stop_session(self):
        for conn in self.connections.values():
            if conn:
                conn.write_message(json.dumps({'type': 'stop'}))

        cobrowsing_session_manager.delete_session(self.id)

    def set_connection(self, role, connection):
        if self.connections[role] and connection:  # кейс когда перебиваем коннекшн
            self.connections[role].session = None  # отлинковываем старый коннекшн от кобраузинг-сессии
            self.connections[role].write_message(json.dumps({'type': 'stop'}))  # отрубаем старый коннекшн

        self.connections[role] = connection  # подрубаем новый коннекшн

        if role == 'operator':  # ставим таймер на закрытие сессии, если оператор закрыл страницу с кобраузингом и не хочет возвращаться
            if not connection:
                self.alive = False
                self.check_operator_alive_timer = wm_timer.add_timer(15, lambda: self.operator_checker(), 'check_operator_cobrowsing_alive')
            else:
                self.alive = True
                if self.check_operator_alive_timer:
                    self.check_operator_alive_timer.cancel()
                    self.check_operator_alive_timer = None

        if all(self.connections.values()):  # Если все подключились
            for conn in self.connections.values():  # то
                conn.write_message(json.dumps({'type': 'ready'}))  # шлем всем сигнал на спаривание

        logging.warning('set_connection for role=%s' % role)
        logging.warning('connections in cobrowsing session:')
        logging.warning(self.connections)

    def on_message(self, message):
        for role, connection in self.connections.items():
            if connection and role != message['role']:
                connection.write_message(json.dumps(message))

    def on_visitor_accept(self, url):
        self.set_state(CobrowsingSession.State.CONNECTED)
        self.set_url(url)

    def operator_checker(self):
        if not self.alive:
            self.set_state(CobrowsingSession.State.DISCONNECTED, CobrowsingSession.StateReason.CLOSED_BY_OPERATOR)


class CobrowsingSessionManager:

    def __init__(self):
        self.session_ids_to_session = {}

    def create_new_session(self, operator_id, v_session):
        new_session = CobrowsingSession.create()
        new_session.operator_id = operator_id
        new_session.visit_session = v_session
        self.session_ids_to_session[new_session.id] = new_session
        return new_session

    def delete_session(self, id):
        self.session_ids_to_session[id] = None

    def get_session_by_id(self, id):
        return self.session_ids_to_session.get(id, None)


cobrowsing_session_manager = CobrowsingSessionManager()
