import cgi
import threading
import logging
import time

import tornado.auth
import tornado.escape
import tornado.httpserver
import tornado.options
import tornado.web

import account
import wm_web
import wm_timer
import wm_utils


__author__ = 'mixey'


class AccountContainer(object):
    def __init__(self, revision):
        self.revision = revision
        self.waiters = []


class Waiter(wm_utils.InstanceCountTracker):
    def __init__(self, on_revision_changed_callback, info, request_handler):
        super(Waiter, self).__init__()
        self.on_revision_changed_callback = lambda: wm_utils.add_ioloop_callback(on_revision_changed_callback, 'on_revision_changed')
        self.info = info
        self.time = int(time.time())
        self.request_handler = request_handler

        from wm_operator import OperatorWebSocketDeltaRequestHandler
        from visitor_tracking import VisitorWebSocketActionRequestHandler

        self.is_ws = isinstance(request_handler, (OperatorWebSocketDeltaRequestHandler, VisitorWebSocketActionRequestHandler))


class WaitersManager(object):

    def __init__(self, account, name=''):
        self.account = account
        self.name = name
        self.waiters = []
        self.lock = threading.Lock()

    def before_add_waiter(self, since, waiter):
        return True

    def add_waiter(self, since, waiter):

        if not self.before_add_waiter(since, waiter):
            return

        with self.lock:
            self.waiters.append(waiter)
            self.on_waiters_count_changed(len(self.waiters))

            if since != self.get_current_revision() or waiter.request_handler.get_argument('respond-immediately', 'false') == 'true':
                waiter.on_revision_changed_callback()
                if not waiter.is_ws:
                    self.waiters.remove(waiter)
                    self.on_waiters_count_changed(len(self.waiters))

    def remove_waiter(self, waiter):
        with self.lock:
            if waiter in self.waiters:
                self.waiters.remove(waiter)
                self.on_waiters_count_changed(len(self.waiters))

    def notify_all_waiters(self, new_revision, min_timeout=0):
        with self.lock:
            # logging.info("Revision changed for account %s from %d to %d. Sending answer to %r listeners",
            # account_name, waiters_container.revision, new_revision, len(waiters_container.waiters))
            waiters = self.waiters
            self.waiters = [w for w in waiters if w.is_ws and w.request_handler and w.request_handler.ws_connection]
            for waiter in waiters:
                try:
                    self.__notify_waiter(waiter, min_timeout)
                except Exception:
                    logging.error("Error in waiter callback", exc_info=True)
            self.on_waiters_count_changed(len(self.waiters))

    def __notify_waiter(self, waiter, min_timeout):
        #        time_delta = time.time() - waiter.time
        #        if time_delta >= 5 and min_timeout == 0:
        #            waiter.on_revision_changed_callback()
        #        else:
        #            wm_timer.add_timer(max(5 - time_delta, min_timeout), waiter.on_revision_changed_callback)
        if min_timeout == 0:
            waiter.on_revision_changed_callback()
        else:
            wm_timer.add_timer(min_timeout, waiter.on_revision_changed_callback)

    def get_current_revision(self):
        return None

    def write_waiters_info(self, write, show_account=True, indent=0):
        cnt = 0
        if show_account:
            write("<b>%s</b><br/>" % self.account.name)
        write("&nbsp;" * (indent + 4) + "revision: %d<br/>" % self.get_current_revision())
        write("&nbsp;" * (indent + 4) + "waiters:<br/>")
        for waiter in self.waiters:
            write("&nbsp;" * (indent + 8) + "info: %s <br/>" % cgi.escape(waiter.info, True))
            cnt += 1

        return cnt

    def on_waiters_count_changed(self, count):
        pass

    def reject_all_waiters(self, details):
        with self.lock:
            for waiter in self.waiters:
                waiter.request_handler.reject_request(details)
            self.waiters = []
            self.on_waiters_count_changed(len(self.waiters))


class WaitersInfoRequestHandler(tornado.web.RequestHandler):

    def __init__(self, name, application, request, **kwargs):
        super(WaitersInfoRequestHandler, self).__init__(application, request, **kwargs)
        self.name = name

    def get(self, *args, **kwargs):
        total = 0
        self.write("<h2>" + self.name + "</h2><br/><br/>")
        self.write("<b>account to waiters</b><br/>")
        for a in account.Account.get_all():
            manager = self.get_waiters_manager(a)
            total += manager.write_waiters_info(self.write)

        self.write("<b>Total connections: %d</b><br/>" % total)

    def get_waiters_manager(self, account):
        return None


class WaiterRequestHandler(wm_web.TimeoutedRequestHandler, wm_web.BaseWebimRequestHandler):

    def get_waiters_manager(self):
        return None

    def get_since(self):
        if self.get_argument('t-id', None) and self.get_argument('t-id') != wm_utils.tornado_instance_id[-6:]:
            logging.warn('WaiterRequestHandler: different tornado_instance_id')
            return 0

        return self.get_int_argument("since")

    def process(self):
        info = str([self.request.headers['User-Agent']]) if 'User-Agent' in self.request.headers else 'no user-agent'
        info = info + ' mode: ' + self.get_verified_argument('mode', 'no-mode')

        self.waiter = Waiter(self.on_revision_changed, info, self)
        self.get_waiters_manager().add_waiter(self.get_since(), self.waiter)

    def on_revision_changed(self):  # revision is expired
        pass

    @tornado.web.asynchronous
    def get(self, *args, **kwargs):
        self.process()

    @tornado.web.asynchronous
    def post(self, *args, **kwargs):
        self.process()

    def on_timeout(self):
        if hasattr(self, 'waiter'):
            self.get_waiters_manager().remove_waiter(self.waiter)
        return None

    def on_connection_close(self):
        if hasattr(self, 'waiter'):
            self.get_waiters_manager().remove_waiter(self.waiter)
        self.__cleanup()

    def on_finish(self):
        self.__cleanup()

    def __cleanup(self):
        if hasattr(self, 'waiter') and self.waiter:
            # this fixes memory leaks caused by cyclic references 'waiter <-> request_handler'
            self.waiter.request_handler = None
            self.waiter = None
