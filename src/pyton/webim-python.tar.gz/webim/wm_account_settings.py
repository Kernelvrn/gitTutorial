import json
import uuid
import time

import tornado.web

import wm_operator
import wm_timer
import wm_settings
import wm_utils


class ChannelSettingRequestHandler(wm_operator.BaseOperatorRequestHandler):

    def requires_csrf_token_checking(self):
        return True

    @tornado.web.asynchronous
    def get(self, *args, **kwargs):
        wm_timer.invoke_async(lambda: self.__get(), timer_name='channel_setting get')

    @tornado.web.asynchronous
    def post(self, *args, **kwargs):
        wm_timer.invoke_async(lambda: self.__post(), timer_name='channel_setting post')

    def __get(self):
        channel_type = self.get_verified_argument('type', None)
        id = self.get_verified_argument('id', None)

        account = self.get_account()

        if channel_type == 'new_vk':
            channel_id = uuid.uuid4().hex

            self.finish(json.dumps({
                'id': channel_id,
                'secret_key': uuid.uuid4().hex,
                'callback_url': self.get_callback_url('vk', channel_id)
            }))
            return

        if channel_type == 'new_fb':
            channel_id = uuid.uuid4().hex

            self.finish(json.dumps({
                'id': channel_id,
                'secret_key': uuid.uuid4().hex,
                'callback_url': self.get_callback_url('fb', channel_id)
            }))
            return

        if channel_type == 'new_custom':
            channel_id = uuid.uuid4().hex

            self.finish(json.dumps({
                'id': channel_id,
                'secret_key': uuid.uuid4().hex,
            }))
            return

        if channel_type == 'new_viber':
            channel_id = uuid.uuid4().hex

            self.finish(json.dumps({
                'id': channel_id,
                'secret_key': uuid.uuid4().hex,
                'callback_url': self.get_callback_url('viber', channel_id),
                'viber_api_endpoint': True if account.get_setting('viber_api_endpoint') else False
            }))
            return

        if not id:
            self.finish(json.dumps(self.get_formatted_channels()))
        else:
            channels = account.get_setting('channels')

            if channels and id in channels:
                channel = channels.get(id).copy()
                channel['id'] = id

                del channel['provided_id_key']

                if channel.get('type') == 'telegram':
                    del channel['secret_key']

                if channel.get('type') == 'whatsapp':
                    del channel['secret_key']

                if channel.get('type') == 'viber':
                    del channel['secret_key']
                    channel['callback_url'] = self.get_callback_url(channel.get('type'), id)
                    channel['viber_api_endpoint'] = True if account.get_setting('viber_api_endpoint') else False

                if channel.get('type') == 'vk':
                    channel['callback_url'] = self.get_callback_url(channel.get('type'), id)

                if channel.get('type') == 'fb':
                    channel['callback_url'] = self.get_callback_url(channel.get('type'), id)

                if channel.get('type') == 'odnoklassniki':
                    channel['callback_url'] = self.get_callback_url(channel.get('type'), id)

                self.finish(json.dumps(channel))
            else:
                self.finish(json.dumps({'error': 'channel-not-found'}))

    def __post(self):
        channel_type = self.get_verified_argument('type')
        account = self.get_account()
        channels = self.get_account().get_setting('channels')

        if not channels or type(channels) == list:
            channels = {}

        if channel_type == 'delete':
            id = self.get_verified_argument('id')
            channel = channels.get(id)

            if channel:
                if channel['type'] == 'telegram':
                    account.telegram_api.set_webhook(channel)
                # elif channel['type'] == 'whatsapp':
                #     account.blinger_whatsapp_api.set_webhook(channel)
                elif channel['type'] == 'viber' and not account.get_setting('viber_api_endpoint'):
                    account.viber_api.set_webhook(channel['token'])
                elif channel['type'] == 'odnoklassniki':
                    callback_url = self.get_callback_url('ok', id)
                    account.ok_api.set_webhook(channel, callback_url, method='unsubscribe')

                del channels[id]

        if channel_type == 'telegram':
            bot = self.get_json_argument('bot')

            if 'id' in bot:
                id = bot['id']
                channel = channels.get(id).copy()

                channel['token'] = bot['token']
                channel['dep_key'] = bot['dep_key']
                channel['name'] = bot['name']
            else:
                id = uuid.uuid4().hex

                channel = {
                    'type': 'telegram',
                    'token': bot['token'],
                    'name': bot['name'],
                    'dep_key': bot['dep_key'],
                    'provided_id_key': uuid.uuid4().hex,
                    'secret_key': uuid.uuid4().hex
                }

            callback_url = self.get_callback_url('telegram', id, channel['secret_key'])
            account.telegram_api.set_webhook(channel, callback_url)

            channels[id] = channel

        if channel_type == 'odnoklassniki':
            bot = self.get_json_argument('bot')

            if 'id' in bot:
                id = bot['id']
                channel = channels.get(id).copy()

                channel['token'] = bot['token']
                channel['dep_key'] = bot['dep_key']
                channel['name'] = bot['name']
            else:
                id = uuid.uuid4().hex

                channel = {
                    'type': 'odnoklassniki',
                    'token': bot['token'],
                    'name': bot['name'],
                    'dep_key': bot['dep_key'],
                    'provided_id_key': uuid.uuid4().hex,
                    'secret_key': uuid.uuid4().hex
                }

            callback_url = self.get_callback_url('ok', id)
            account.ok_api.set_webhook(channel, callback_url)

            channels[id] = channel

        if channel_type == 'xmpp':
            bot = self.get_json_argument('bot')

            if 'id' in bot:
                id = bot['id']
                channel = channels.get(id).copy()

                channel['jid'] = bot['jid']
                channel['password'] = bot['password']
                channel['host'] = bot['host']
                channel['port'] = bot['port']
                channel['dep_key'] = bot['dep_key']
                channel['name'] = bot['name']
            else:
                id = uuid.uuid4().hex

                channel = {
                    'type': 'xmpp',
                    'jid': bot['jid'],
                    'password': bot['password'],
                    'host': bot['host'],
                    'port': bot['port'],
                    'name': bot['name'],
                    'dep_key': bot['dep_key'],
                    'provided_id_key': uuid.uuid4().hex,
                    'secret_key': uuid.uuid4().hex
                }

            channels[id] = channel

        if channel_type == 'vk':
            page = self.get_json_argument('page')
            id = page.get('id')
            if channels.get(id):
                provided_key = channels.get(id).get('provided_id_key')
            else:
                provided_key = uuid.uuid4().hex

            page['provided_id_key'] = provided_key
            page['type'] = 'vk'

            channels[id] = page

        if channel_type == 'fb':
            page = self.get_json_argument('page')
            id = page.get('id')
            if channels.get(id):
                provided_key = channels.get(id).get('provided_id_key')
            else:
                provided_key = uuid.uuid4().hex

            page['provided_id_key'] = provided_key
            page['type'] = 'fb'

            channels[id] = page

        if channel_type == 'whatsapp':
            bot = self.get_json_argument('bot')
            if 'id' in bot:
                id = bot['id']
                channel = channels.get(id).copy()

                channel['token'] = bot['token']
                channel['dep_key'] = bot['dep_key']
                channel['name'] = bot['name']
                channel['user_id'] = bot['user_id']
            else:
                id = uuid.uuid4().hex

                channel = {
                    'type': 'whatsapp',
                    'token': bot['token'],
                    'name': bot['name'],
                    'user_id': bot['user_id'],
                    'dep_key': bot['dep_key'],
                    'provided_id_key': uuid.uuid4().hex,
                    'secret_key': uuid.uuid4().hex
                }

            callback_url = self.get_callback_url('blinger/whatsapp')
            account.blinger_whatsapp_api.set_webhook(channel, callback_url)

            channels[id] = channel

        if channel_type == 'viber':
            public_account = self.get_json_argument('publicAccount')

            if 'id' in public_account:
                id = public_account['id']
                channel = channels.get(id).copy()

                channel['token'] = public_account['token']
                channel['dep_key'] = public_account['dep_key']
                channel['name'] = public_account['name']
            else:
                id = uuid.uuid4().hex

                channel = {
                    'type': 'viber',
                    'token': public_account['token'],
                    'name': public_account['name'],
                    'dep_key': public_account['dep_key'],
                    'provided_id_key': uuid.uuid4().hex,
                    'secret_key': uuid.uuid4().hex,
                }

            if not account.get_setting('viber_api_endpoint'):
                callback_url = self.get_callback_url('viber', id)
                account.viber_api.set_webhook(channel['token'], callback_url)

            channels[id] = channel

        if channel_type == 'custom':
            properties = self.get_json_argument('properties')

            channel = {
                'type': 'custom',
                'name': properties['name'],
                'creators_secret_key': properties['creators_secret_key'],
                'callback_url': properties['callback_url'],
                'secret_key': properties['secret_key'],
                'dep_key': properties['dep_key'],
            }

            if channels.get(properties.get('id')):
                channel['provided_id_key'] = channels[properties['id']]['provided_id_key']
            else:
                channel['provided_id_key'] = uuid.uuid4().hex

            channels[properties['id']] = channel

        account.settings.set('channels', json.dumps(channels), async=False)

        self.finish(json.dumps(self.get_formatted_channels()))

    def get_callback_url(self, type, id=None, secret_key=None):
        account = self.get_account()
        if account.name == 'alenyashin':
            callback_url = 'https://alenyashin.olegb.ru/l/v/%s' % type
        elif account.name == 'artur':
            callback_url = 'https://artur.olebo.ru/l/v/%s' % type
        elif account.name == 'devwebimdevru':
            callback_url = 'https://devwebimdevru.olegb.ru/l/v/%s' % type
        elif account.name == 'barrelroller':
            callback_url = 'https://mshavlyuk.olegb.ru/l/v/%s' % type
        else:
            callback_url = '%s://%s/l/v/%s' % (wm_settings.get_protocol(public=True), wm_settings.get_full_domain(account, public=True), type)

        if id:
            callback_url += '/%s' % id

        if secret_key:
            callback_url += '/%s' % secret_key

        return callback_url

    def get_formatted_channels(self):
        account = self.get_account()

        result = {}
        channels = account.get_setting('channels')

        if channels and type(channels) == list:
            channels = {}

        if channels:
            for channel_id, channel in channels.iteritems():
                if channel['type'] not in result:
                    result[channel['type']] = []

                channel['id'] = channel_id
                result[channel['type']].append(channel)

        return result


class PrivateKeysSettingRequestHandler(wm_operator.BaseOperatorRequestHandler):

    def requires_csrf_token_checking(self):
        return True

    @tornado.web.asynchronous
    def get(self, *args, **kwargs):
        wm_timer.invoke_async(self.__get, timer_name='private_keys_setting get')

    @tornado.web.asynchronous
    def post(self, *args, **kwargs):
        wm_timer.invoke_async(self.__post, timer_name='private_keys_setting post')

    def __get(self):
        private_keys = self.get_account().get_setting('private_key')
        if private_keys:
            self.finish(json.dumps({'keys': private_keys}))
        else:
            self.finish(json.dumps({'keys': []}))

    def __post(self):
        account = self.get_account()

        keys = account.get_setting('private_key')
        if not keys:
            keys = []

        keys.append(wm_utils.new_key())

        keys_as_strings = ', '.join(keys)
        account.settings.set('private_key', keys_as_strings, async=False)

        self.finish(json.dumps({'keys': keys}))


class SpellingDictSettingRequestHandler(wm_operator.BaseOperatorRequestHandler):

    def requires_csrf_token_checking(self):
        return True

    @tornado.web.asynchronous
    def get(self, *args, **kwargs):
        if self.get_account().get_setting('server_dicts_spell_check'):
            wm_timer.invoke_async(self.__get, timer_name='spelling_dict_setting get')
        else:
            self.finish(json.dumps({'error': 'server_dicts_spell_check_is_off'}))

    @tornado.web.asynchronous
    def post(self, *args, **kwargs):
        if self.get_account().get_setting('server_dicts_spell_check'):
            wm_timer.invoke_async(self.__post, timer_name='spelling_dict_setting post')
        else:
            self.finish(json.dumps({'error': 'server_dicts_spell_check_is_off'}))

    def __get(self):
        self.finish(json.dumps({'dict': self.get_account().get_setting(self.get_verified_argument('dict')) or []}))

    def __post(self):
        account = self.get_account()
        action = self.get_verified_argument('action')
        user_dict = self.get_argument('dict').lower().split(',')

        if action == 'add_list':
            spelling_dict = account.get_setting('spelling_dict') or {}
            forbidden_dict = account.get_setting('forbidden_spelling_dict') or {}
            adding_time = int(time.time())
            for u_word in user_dict:
                if u_word not in spelling_dict and u_word not in forbidden_dict:
                    spelling_dict[u_word] = adding_time
            account.settings.set('spelling_dict', json.dumps(spelling_dict, ensure_ascii=False), async=False)
            self.finish(json.dumps({'dict': spelling_dict}))

        elif action == 'add':
            spelling_dict = account.get_setting('spelling_dict') or {}
            self.add_words_in_account_spelling_dict(spelling_dict, 'spelling_dict', user_dict)

        elif action == 'forbid':
            forbidden_spelling_dict = account.get_setting('forbidden_spelling_dict') or {}
            self.add_words_in_account_spelling_dict(forbidden_spelling_dict, 'forbidden_spelling_dict', user_dict)

        elif action == 'delete':
            setting_name = self.get_verified_argument('spelling_dict')
            spelling_dict = account.get_setting(setting_name) or {}
            for u_word in user_dict:
                if u_word in spelling_dict:
                    spelling_dict.pop(u_word, None)
            account.settings.set(setting_name, json.dumps(spelling_dict, ensure_ascii=False), async=False)
            self.finish(json.dumps({'dict': spelling_dict}))

    def add_words_in_account_spelling_dict(self, spelling_dict, setting_name, words):
        account = self.get_account()
        candidates = account.get_setting('candidate_spelling_dict') or {}
        adding_time = int(time.time())
        for word in words:
            if word not in spelling_dict:
                spelling_dict[word] = adding_time
            if word in candidates:
                candidates.pop(word, None)
        account.settings.set(setting_name, json.dumps(spelling_dict, ensure_ascii=False), async=False)
        account.settings.set('candidate_spelling_dict', json.dumps(candidates, ensure_ascii=False), async=False)
        self.finish(json.dumps({'dict': candidates}))
