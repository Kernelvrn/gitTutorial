# coding=UTF-8
__author__ = 'andrew'

import time
import uuid
import threading

from wm_utils import Jsonable
import db_utils
import delta


class OperatorChat(Jsonable):

    MESSAGE_PACK_LENGTH = 50
    SERVER_MESSAGE_LIMIT = 500

    def __init__(self, account):
        self.account = account
        self.id = 0
        self.messages = []
        self.no_more_messages = False
        self.lock = threading.Lock()

    def to_dict(self, context=None):
        result = dict()
        result['chatId'] = self.id
        result['onlineOperators'] = [oo.operator_id for oo in self.account.oo_manager.get_online_operators()]
        some = self.get_messages_for_operator()
        result['messages'] = some['messages']
        result['noMoreMessages'] = some['no_more_messages']

        return result

    def add_operator_message(self, operator, text, uid):
        msg = OperatorChatMessage.create(uid, OperatorChatMessage.Kind.OPERATOR, time.time(), operator.id, operator.fullname, text, self.id)
        with self.lock:
            self.messages.append(msg)
        self.account.background_storager.store(msg)
        for oo in self.account.oo_manager.get_online_operators():
            oo.delta_manager.add_delta(delta.Delta('OPERATOR_CHAT_MESSAGE', delta.Delta.Event.ADD, self.id, msg))

    def load_init_messages(self):
        conn = db_utils.get_connection(self.account.name)
        rows = conn.query('select * from operatorchatmessage where operatorchatid=%s order by messageid desc limit %s', self.id, self.SERVER_MESSAGE_LIMIT)
        rows.reverse()

        for row in rows:
            msg = OperatorChatMessage(
                row['messageuid'], row['kind'], int(row['created'].strftime('%s')), row['operatorid'], row['sendername'], row['message'], row['operatorchatid']
            )
            self.messages.append(msg)
        conn.close()

        self.no_more_messages = len(self.messages) < self.SERVER_MESSAGE_LIMIT  # Флаг, что при первой загрузке сообщений нет или загрузились все

    def load_more_messages(self, m_uid):
        messages = []

        conn = db_utils.get_connection(self.account.name)
        rows = conn.query('SELECT * FROM operatorchatmessage allmsgs '
                          'JOIN (SELECT messageid FROM operatorchatmessage WHERE operatorchatid=%s AND messageuid=%s) trgt '
                          'ON allmsgs.messageid < trgt.messageid AND allmsgs.operatorchatid=%s '
                          'ORDER BY allmsgs.messageid DESC LIMIT %s',
                          self.id, m_uid, self.id, self.MESSAGE_PACK_LENGTH)
        rows.reverse()

        for row in rows:
            msg = OperatorChatMessage(
                row['messageuid'], row['kind'], int(row['created'].strftime('%s')), row['operatorid'], row['sendername'], row['message'], row['operatorchatid']
            )
            messages.append(msg)
        conn.close()

        return {'chat_id': self.id, 'messages': [message.to_dict() for message in messages], 'no_more_messages': len(messages) < self.MESSAGE_PACK_LENGTH}

    def get_messages_for_operator(self, first_message_uid=None):
        with self.lock:
            idx = self.get_index_by_uid(first_message_uid) if first_message_uid else -1

            if idx == 0 and first_message_uid and not self.no_more_messages:   # Нужна ли тут проверка на f_m_uid, если без него idx всегда -1?
                return self.load_more_messages(first_message_uid)
            elif idx == -1:
                return self.get_pack_of_messages(self.messages)
            else:
                return self.get_pack_of_messages(self.messages[0:idx])

    def get_index_by_uid(self, uid):
        for index, message in enumerate(self.messages):
            if message.uid == uid:
                break
        else:
            index = 0

        return index

    def get_pack_of_messages(self, messages):
        if len(messages) <= self.MESSAGE_PACK_LENGTH:
            return {'chat_id': self.id, 'messages': [msg.to_dict() for msg in messages], 'no_more_messages': self.no_more_messages}
        else:
            return {'chat_id': self.id, 'messages': [msg.to_dict() for msg in messages[len(messages) - self.MESSAGE_PACK_LENGTH:]], 'no_more_messages': False}

    def clean_history(self):
        with self.lock:
            if len(self.messages) > self.SERVER_MESSAGE_LIMIT:
                self.messages = self.messages[len(self.messages) - self.SERVER_MESSAGE_LIMIT:]


class OperatorChatMessage(Jsonable):

    class Kind:
        OPERATOR = 'operator'
        SYSTEM = 'system'

    def __init__(self, uid, kind, ts, operator_id, operator_name, text, chat_id):
        self.kind = kind
        self.uid = uid
        self.ts = ts
        self.operator_id = operator_id
        self.operator_name = operator_name
        self.text = text
        self.chat_id = chat_id

    @classmethod
    def __next_id(cls):
        return uuid.uuid4().hex

    @classmethod
    def create(cls, uid, kind, ts, operator_id, operator_name, text, chat_id):
        return OperatorChatMessage(uid, kind, ts, operator_id, operator_name, text, chat_id)

    def to_dict(self, context=None):
        result = {
            'kind': self.kind,
            'ts': self.ts,
            'uid': self.uid,
            'operator_id': self.operator_id,
            'operator_name': self.operator_name,
            'text': self.text,
            'chat_id': self.chat_id,
        }
        return result