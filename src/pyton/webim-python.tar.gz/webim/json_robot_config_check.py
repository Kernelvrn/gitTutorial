# coding=utf-8

"""
Скрипт, который осуществляет глубокую проверку добавляемого json-дескриптора бота.
Этот скрипт стоит запустить отдельно со следующими параметрами:
:param: Имя аккаунта, в account-specific папке которого лежит json-дескриптор
:param: Имя json-файла

Метод выведет ошибки дескриптора, если таковые найдутся.

Дополнительная информация: https://conf.olegb.ru/pages/viewpage.action?pageId=27886266
"""

__author__ = 'akupina'

import json
import os.path
import sys

import networkx as nx

import wm_settings


def get_robot_logic_descriptor(account_name, filename):

    robot_logic_descriptor_filename = os.path.join(
        wm_settings.public_html_dir,
        'webim/account-specific/{0}/configs/{1}'.format(
            account_name,
            filename
        )
    )

    robot_logic_descriptor = {}

    if os.path.isfile(robot_logic_descriptor_filename):
        try:
            robot_logic_descriptor = json.loads(open(robot_logic_descriptor_filename, 'r').read())
        except ValueError:
            return {'error': 'Failed to decode Json robot logic descriptor: incorrect JSON'.format(
                account_name, robot_logic_descriptor_filename)}
        except Exception:
            return {'error': 'Failed to load Json robot logic descriptor'.format(
                account_name, robot_logic_descriptor_filename)}

    return {'descriptor': robot_logic_descriptor}


def get_robot_logic_descriptor_errors(account_name, filename):
    errors = []
    descriptor = None

    #  Попытка получить файл с дескриптором
    get_descriptor_result = get_robot_logic_descriptor(account_name, filename)
    if get_descriptor_result.get('error'):
        return [get_descriptor_result.get('error')]
    else:
        descriptor = get_descriptor_result.get('descriptor')

    #  Базовые проверки дескриптора
    if not descriptor:
        return ['Descriptor is empty']

    dict_states = descriptor.get('states')

    if not dict_states:
        return ['No states found in descriptor']

    if not dict_states.get('start'):
        errors.append('"start" state not found')

    #  Попытка сохранить states как узлы графа
    graph = nx.DiGraph()
    try:
        graph.add_nodes_from(dict_states.keys())
    except Exception as e:
        errors.append(e.message)
        return errors

    #  Проверка корректности actions и title для каждого state
    for state_id, state in dict_states.items():
        if state.get('actions'):
            for action in state.get('actions'):
                if not action.get('type'):
                    errors.append('In State "{}" action "{}" has not type'.format(state_id, str(action)))
        else:
            errors.append('State "{}" has not actions'.format(state_id))

        if not state.get('title'):
            errors.append('State "{}" has not title'.format(state_id))

    #  Проверка корректности steps для каждого state, добавление их в граф для проверки связности
    for state_id, state in dict_states.items():
        if not state.get('steps'):
            continue

        keywords = []

        for step in state.get('steps'):
            if step.get('keyword'):
                if not step.get('keyword') in keywords:
                    keywords.append(step.get('keyword'))
                else:
                    errors.append('In state "{}" step "{}" has duplicate keyword'.format(state_id, str(step)))
            else:
                errors.append('In state "{}" step "{}" has not keyword'.format(state_id, str(step)))

            destination_state_id = step.get('state_id')
            if destination_state_id:
                if graph.has_node(destination_state_id):
                    if not graph.has_edge(state_id, destination_state_id):
                        graph.add_edge(state_id, destination_state_id)
                    else:
                        errors.append(
                            'In state "{}" step "{}" is duplicated'.format(state_id, str(step)))
                else:
                    errors.append('In state "{}" step "{}" points to nonexistent state'.format(state_id, str(step)))
            else:
                errors.append('In state "{}" step "{}" has not destination state_id'.format(state_id, str(step)))

    #  Проверка того, что до всех states можно дойти из state "start"
    if dict_states.get('start'):
        for state_id in dict_states.keys():
            if not nx.has_path(graph, 'start', state_id):
                errors.append('State "{}" is unreachable from "start" state'.format(state_id))

    #  Проверка корректности errors в дескрипторе и наличия обязательной ошибки "unrecognized_response"
    dict_errors = descriptor.get('errors')
    if dict_errors:
        if not dict_errors.get('unrecognized_response'):
            errors.append('Required error "unrecognized_response" is not found')

        for error_id, error in dict_errors.items():
            if not error.get('actions'):
                errors.append('Error "{}" has not actions'.format(error_id))
    else:
        errors.append('Errors description not found')

    return errors


account_name, filename = [sys.argv[1], sys.argv[2]]
errors = get_robot_logic_descriptor_errors(account_name, filename)
print '\n'.join(errors)
