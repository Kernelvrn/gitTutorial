# coding=utf-8

"""
Robots documentation: https://conf.olegb.ru/pages/viewpage.action?pageId=15074076
"""

__author__ = 'andrew'

import logging

import requests

from .basic import BasicRobotLogic
from .. import chat
from .. import wm_timer


class OperatorRobotLogic(BasicRobotLogic):

    def on_new_chat_created(self, ch, produce_delta=True):
        logging.warn('OperatorRobotLogic: on_new_chat_created. Chat: {}'.format(ch.id))

        if ch.state == chat.Chat.State.QUEUE:
            robot = ch.session.account.get_operator(self.operator_id)
            oo_robot = ch.session.account.oo_manager.get(self.operator_id)
            if not oo_robot.is_offline() and robot.matches((ch.session.lang, ch.session.department_key)):
                ch.process_event('sys.assign_to_robot', {'operator_id': self.operator_id}, produce_delta=produce_delta)
                return True

        return False

    def _post(self, event, data):
        data['event'] = event
        api_url = self.get_setting('api')
        response_timeout = int(self.get_setting('response_timeout', default=5))
        verify_certificate = self.get_setting('verify_certificate', default=True)

        response = requests.post(api_url, json=data, timeout=response_timeout, verify=verify_certificate)
        if response.status_code == requests.codes.ok:
            logging.warn('OperatorRobotLogic: _post. Data: {}. Response: {} {}'.format(
                data, response.status_code, response.text if response.text else ''))
            if response.text:
                return response.json()
        else:
            response.raise_for_status()

    def on_chat_assigned_to_robot(self, ch, produce_delta=True):
        wm_timer.invoke_async(
            lambda: self._on_new_chat(ch),
            order_importance_key='operator_robot_{robot_id}_{chat_csid}'.format(robot_id=self.operator_id, chat_csid=ch.client_side_id)
        )

    def _on_new_chat(self, ch):
        logging.warn('OperatorRobotLogic: _on_new_chat. Chat: {}'.format(ch.id))

        event = 'new_chat'
        data = {
            'chat': {
                'id': ch.client_side_id
            },
            'webim_visitor': ch.session.visitor.webim_visitor
        }

        try:
            self._post(event, data)
        except Exception:
            logging.exception('OperatorRobotLogic: _on_new_chat failed with data {data}'.format(data=data))
            ch.process_event('sys.unassign_from_robot')

    def on_new_visitor_message(self, ch, message):
        wm_timer.invoke_async(
            lambda: self._on_new_visitor_message(ch, message),
            order_importance_key='operator_robot_{robot_id}_{chat_csid}'.format(robot_id=self.operator_id, chat_csid=ch.client_side_id)
        )

    def _on_new_visitor_message(self, ch, message):
        logging.warn('OperatorRobotLogic: _on_new_visitor_message. Chat: {}. Message: {}'.format(ch.id, message))

        event = 'new_message'
        data = {
            'chat': {
                'id': ch.client_side_id
            },
            'text': message.text,
            'webim_visitor': ch.session.visitor.webim_visitor
        }

        try:
            result = self._post(event, data)
        except Exception:
            logging.exception('OperatorRobotLogic: _on_new_visitor_message failed with data {data}'.format(data=data))
            ch.process_event('sys.unassign_from_robot')
            return

        try:
            has_answer = result['has_answer']
            messages = result.get('messages')
        except Exception:
            logging.exception('OperatorRobotLogic: _on_new_visitor_message failed with result {result}'.format(result=result))
            ch.process_event('sys.unassign_from_robot')
            return

        if messages and ch.get_operator_id() and ch.get_operator_id() == self.operator_id:
            for m in messages:
                chat.Message.create(
                    ch, chat.Message.Kind.OPERATOR, ch.get_operator().get_visible_name(ch.session.lang),
                    m.get('text'), ch.get_operator_id()
                )

        if not has_answer:
            logging.warn('OperatorRobotLogic: _on_new_visitor_message. Regular unassign from robot.')
            ch.process_event('sys.unassign_from_robot')
