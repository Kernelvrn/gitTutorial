# coding=utf-8

"""
Robots documentation: https://conf.olegb.ru/pages/viewpage.action?pageId=15074076
"""

import logging

import requests

from .basic import BasicRobotLogic
from .. import chat
from .. import delta
from .. import wm_timer


class HintsRobotLogic(BasicRobotLogic):

    def on_new_chat_created(self, ch, produce_delta=True):
        if ch.state == chat.Chat.State.QUEUE:
            location_settings = ch.start_page.get_location_settings()
            if location_settings and location_settings.get('chat').get('hintsEnabled') == 'Y':
                ch.process_event('sys.assign_to_robot', {'operator_id': self.operator_id}, produce_delta=produce_delta)
                return True

        return False

    def on_chat_unassigned_from_robot(self, chat, produce_delta=True):
        if produce_delta:
            d = delta.Delta('VISITOR_HINTS', 'add', chat.session.id, [])
            chat.session.delta_manager.add_delta(d)

    def on_new_visitor_message(self, ch, message):
        wm_timer.invoke_async(lambda: self.get_answer_from_robot(ch, message))

    # def on_new_visitor_draft(self, chat, visitor_draft):
    #     wm_timer.invoke_async(lambda: self.get_autocomplete_hints(chat, visitor_draft))

    def get_answer_from_robot(self, ch, message):
        try:
            r = requests.post('%s/%s' % (self.get_setting('api'), 'answer'),
                              timeout=5, json={'message': {"text": message.text}})
            result = r.json()
            if result.get('has_answer'):
                if ch.get_operator_id() and ch.get_operator_id() == self.operator_id:
                    for m in result.get('messages'):
                        chat.Message.create(
                            ch, chat.Message.Kind.OPERATOR, ch.get_operator().get_visible_name(ch.session.lang), m.get('text'), ch.get_operator_id()
                        )
            else:
                logging.warn('HintsAPI: no answer')
                ch.process_event('sys.unassign_from_robot')
        except Exception:
            logging.error('HintsAPI: failed for message "%s"' % str(message.text), exc_info=True)
            ch.process_event('sys.unassign_from_robot')
            return None

    # def get_autocomplete_hints(self, chat, visitor_draft):
    #     try:
    #         r = requests.post('%s/%s' % (self.get_setting('api'), 'autocomplete'),
    #                           timeout=5,
    #                           json={
    #                               "message": {"text": visitor_draft or ""}
    #                           })
    #
    #         result = r.json()
    #         hints = result.get('hints')
    #         if chat.get_operator_id() == self.operator_id:
    #             d = delta.Delta('VISITOR_HINTS', 'add', chat.session.id, hints)
    #             chat.session.delta_manager.add_delta(d)
    #     except:
    #         logging.error('HintsAPI: failed for draft "%s"' % str(visitor_draft), exc_info=True)
    #         return None