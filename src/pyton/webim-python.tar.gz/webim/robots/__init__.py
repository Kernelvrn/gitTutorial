# coding=utf-8

"""
Robots documentation: https://conf.olegb.ru/pages/viewpage.action?pageId=15074076
"""

from __future__ import absolute_import
import json
import logging

import requests

from .basic import BasicRobotLogic
from .hints import HintsRobotLogic
from .json import JsonRobotLogic
from .operator import OperatorRobotLogic

__all__ = ['BasicRobotLogic', 'HintsRobotLogic', 'JsonRobotLogic', 'OperatorRobotLogic']


class OperatorHintsAPI(object):

    def get_hints(self, message, session):
        hints = None

        try:
            response = requests.post(session.account.settings.get('operator_hints_api_url'), json={"session": session.id, "text": message}, timeout=5)
            if response.status_code == 200:
                response_data = json.loads(response.content)
                hints = response_data.get("answerVariants")
            else:
                logging.error('Operator hints api request is not ok, status code = %s', response.status_code)
        except Exception:
            logging.error(u'Error at get_hints', exc_info=True)

        return hints


operator_hints = OperatorHintsAPI()
