# coding=utf-8

"""
Robots documentation: https://conf.olegb.ru/pages/viewpage.action?pageId=15074076
"""
from __future__ import absolute_import
import logging
import json
import os

from .basic import BasicRobotLogic
from .. import wm_settings
from .. import chat
from .. import wm_timer


class JsonRobotLogic(BasicRobotLogic):

    """
    Дополнительная информация: https://conf.olegb.ru/pages/viewpage.action?pageId=27886266

    Для запуска этого бота в account-config в поле "robots" ожидается настройка вида:
    {
        "OPERATOR_ID": {"type": "json", "logic_descriptor_filename": "FILENAME"},
        ...
    }
    , где OPERATOR_ID - id оператора, за которым закреплен бот,
          FILENAME - имя JSON-файла с описанием логики
          этот JSON-файл должен лежать в папке account-specific/ACCOUNT_NAME/configs
          , где ACCOUNT_NAME - имя аккаунта, для которого подключается бот.
    """

    class State:

        def __init__(self, id, title, actions, steps=None):
            """
            :param id: ID состояния
            :param title: Заголовок состояния
            :param actions: Список действий. Каждое действие имеет формат:
                        {"type": "ACTION_TYPE", "parameters": {"PARAM_1_NAME": PARAM_1, "PARAM_2_NAME": PARAM_2, ...}}
                        , где ACTION_TYPE - (string) тип действия (по нему выбирается метод, который будет вызываться)
                              PARAM_1_NAME, PARAM_2_NAME и т.д. - (string) имена параметров, передаваемых в метод
                              PARAM_1, PARAM_2 и т.д. - параметры соответственно.
            :param steps: Список шагов (экземпляров Step)- к каким состояниям можно перейти из текущего состояния
                        Каждый шаг (step) в конфиге имеет формат:
                        {"keyword": "KEYWORD", "step_id": "STEP_ID"}
                        , где KEYWORD - (string) ключевое слово, которео нужно ввести пользователю для перехода
                              STEP_ID - (string) ID состояния, к которому ведет переход

            :type id: string
            :type title: string
            :type actions: dictionary
            :type steps: list
            """

            if not all([id, title, actions]):
                raise JsonRobotParametersException('"id", "title", "actions" can not be None')

            self.id = id
            self.title = title
            self.actions = actions

            self.steps = []
            self.parse_steps_config(steps)

        def parse_steps_config(self, steps):
            if steps:
                for step_config in steps:
                    self.steps.append(self.Step(step_config.get('keyword'), step_config.get('state_id'), self.id))

        class Step:

            def __init__(self, keyword, state_id, source_state_id):
                """
                :param keyword: Ключевое слово, которое нужно ввести, чтобы перейти по этому шагу
                :param state_id: Состояние, в которое ведет шаг
                :param source_state_id: Состояние, из которого ведет шаг

                :type keyword: string
                :type state_id: string
                :type source_state_id: string
                """
                if not all([keyword, state_id, source_state_id]):
                    raise JsonRobotParametersException('"keyword", "state_id", "source_state_id" can not be None')

                self.keyword = keyword
                self.state_id = state_id
                self.source_state_id = source_state_id

    def __init__(self, operator_id, settings, account_name):
        super(JsonRobotLogic, self).__init__(operator_id, settings)
        self.account_name = account_name

        self.states = {}
        self.errors = {}
        self.general_properties = {
            'steps_header': None,
            'steps_template': '{0} - {1}\n'
        }

        self.parse_robot_logic_descriptor()

        self.action_methods = {
            'send_message': self.on_action_send_message,
            'redirect_to_queue': self.on_action_redirect_to_queue
        }

    def get_state(self, id):
        return self.states.get(id)

    def get_error(self, id):
        return self.errors.get(id)

    def parse_robot_logic_descriptor(self):
        """
        Читает файл-дескриптор бота, создает объекты-состояния бота,
        логирует ошибки и сохраняет пустой набор состояний в случае некорректного дескриптора.
        """

        robot_logic_descriptor_filename = os.path.join(
            wm_settings.public_html_dir,
            'webim/account-specific/{0}/configs/{1}'.format(
                self.account_name,
                self.get_setting('logic_descriptor_filename')
            )
        )

        robot_logic_descriptor = {}

        if os.path.isfile(robot_logic_descriptor_filename):
            try:
                robot_logic_descriptor = json.loads(open(robot_logic_descriptor_filename, 'r').read())
            except ValueError:
                logging.exception(
                    'JsonRobotLogic account_name={}: failed to decode Json robot logic descriptor: incorrect JSON'.format(self.account_name)
                )
                return
            except Exception:
                logging.exception(
                    'JsonRobotLogic account_name={}: failed to load Json robot logic descriptor'.format(self.account_name)
                )
                return

        robot_logic_descriptor_errors = self.get_robot_logic_descriptor_errors(robot_logic_descriptor)
        if not robot_logic_descriptor_errors:
            for state_id, state in robot_logic_descriptor.get('states').items():
                state_descriptor = state
                try:
                    self.states[state_id] = self.State(state_id, state_descriptor.get('title'),
                                                       state_descriptor.get('actions'), state_descriptor.get('steps'))
                except Exception:
                    logging.exception(
                        'JsonRobotLogic account_name={}: failed to parse Json robot logic descriptor: invalid structure'.format(self.account_name)
                    )
                    self.states = {}
                    break

            self.errors = robot_logic_descriptor.get('errors')
            if robot_logic_descriptor.get('general_properties'):
                self.general_properties['steps_header'] = robot_logic_descriptor.get('general_properties').get('steps_header')
                if self.is_steps_template_valid(
                        robot_logic_descriptor.get('general_properties').get('steps_template')):
                    self.general_properties['steps_template'] = robot_logic_descriptor.get('general_properties').get('steps_template')
        else:
            self.states = {}
            logging.error(
                'JsonRobotLogic account_name={}: failed to parse Json robot logic descriptor:\n{}'.format(
                    self.account_name, '\n'.join(robot_logic_descriptor_errors)
                ))

    def get_robot_logic_descriptor_errors(self, descriptor):
        errors = []
        dict_states = descriptor.get('states')

        if not dict_states:
            return ['No states found in descriptor']

        if not dict_states.get('start'):
            errors.append('"start" state not found')

        return errors

    def on_new_chat_created(self, ch, produce_delta=True):
        logging.warn(
            'JsonRobotLogic account_name={}: Trying create chat with Json robot. Chat ID: {}'.format(self.account_name, ch.id)
        )

        if ch.state == chat.Chat.State.QUEUE:
            robot_operator = ch.session.account.get_operator(self.operator_id)

            if not self.states:  # При некорректном конфиге для робота не сохраняются состояния
                logging.warn(
                    'JsonRobotLogic account_name={}: Unable to assign chat to Json robot - config is invalid. Chat ID: {}'.format(
                        self.account_name,
                        ch.id
                    )
                )
                return False

            if robot_operator.matches((ch.session.lang, ch.session.department_key)):
                ch.process_event('sys.assign_to_robot', {'operator_id': self.operator_id}, produce_delta=produce_delta)
                return True

            logging.warn(
                'JsonRobotLogic account_name={}: Failed to create chat with Json robot. Chat ID: {}'.format(self.account_name, ch.id)
            )

        return False

    def on_chat_assigned_to_robot(self, ch, produce_delta=True):
        logging.warn(
            'JsonRobotLogic account_name={}: Assigning chat to Json robot. Chat ID: {}'.format(self.account_name, ch.id)
        )

        # Сохраняем в чат ID стартового состояния. (Он всегда имеет ID == "start")
        self.set_current_state(ch, self.get_state('start'))
        self.process_current_state(ch)

    def on_chat_redirected_to_robot(self, ch, produce_delta=True):
        wm_timer.invoke_async(lambda: self.on_chat_assigned_to_robot(ch, produce_delta=produce_delta))

    def on_new_visitor_message(self, ch, message):

        message_text = self.visitor_message_text_cleaner(message.text)
        state_to_go = None

        if self.get_current_state(ch).steps:
            if message_text:
                for step in self.get_current_state(ch).steps:
                    if message_text == step.keyword:
                        state_to_go = self.get_state(step.state_id)
                        break
        else:
            # Когда из состояния нет шагов в другие состояния, он считается тупиковым и чат переводится на оператора
            self.do_unassign_from_robot(ch)

        if state_to_go:
            self.set_current_state(ch, state_to_go)
            self.process_current_state(ch)
        else:
            try:
                error = self.get_error('unrecognized_response')

                if not error:
                    logging.exception(
                        'JsonRobotLogic account_name={}: "unrecognized_response" is not defined. \
                        Unassigning from robot'.format(self.account_name)
                    )
                    self.do_unassign_from_robot(ch)
                    return

                self.process_error(ch, error)
            except Exception as e:
                logging.exception(
                    'JsonRobotLogic account_name={}: Error at trying to process error: {}. State_ID: {}.'.format(
                        self.account_name, e, self.get_current_state(ch).id
                    )
                )

                self.do_unassign_from_robot(ch)

    def get_current_state(self, ch):
        return self.get_state(ch.external_data['json_robot_current_state'])

    def set_current_state(self, ch, state):
        ch.external_data['json_robot_current_state'] = state.id
        ch.store()

    def process_current_state(self, ch):
        current_state = self.get_current_state(ch)

        try:
            self.process_actions(ch, current_state.actions)
        except Exception:
            self.do_unassign_from_robot(ch)
            return

        if not current_state.steps:
            self.do_unassign_from_robot(ch)
        else:
            steps_text = None
            try:
                steps_text = self.make_steps_text(current_state.steps)
            except Exception as e:
                logging.exception(
                    'JsonRobotLogic account_name={}: Error at make_steps_text: {}. State_ID: {}.'.format(
                        self.account_name, e, current_state.id
                    )
                )
                self.do_unassign_from_robot(ch)

            if steps_text:
                self.send_bot_message(ch, steps_text)

    def process_actions(self, ch, actions):
        for action in actions:
            try:
                action_function = self.action_methods[action.get('type')]
                if action.get("parameters"):
                    action_function(ch, ** action.get("parameters"))
                else:
                    action_function(ch)

            except Exception as e:
                logging.exception(
                    'JsonRobotLogic account_name={}: Error while executing action with type "{}": {}. Action parameters: {}. State_ID: {}'.format(
                        self.account_name,
                        action.get('type'),
                        e,
                        action.get('parameters'),
                        self.get_current_state(ch).id
                    )
                )

                raise ProcessJsonRobotActionsException('Error was thrown in process_actions')

    def process_error(self, ch, error):
        self.process_actions(ch, error.get('actions'))

    def make_steps_text(self, steps):
        if self.general_properties['steps_header']:
            text = '{}\n\n'.format(self.general_properties['steps_header'])
        else:
            text = ''

        for step in steps:
            text += self.general_properties['steps_template'].format(step.keyword, self.get_state(step.state_id).title)

        return text

    def is_steps_template_valid(self, template):
        try:
            template.format('1', 'text')
            return True
        except Exception as e:
            logging.exception(
                'JsonRobotLogic account_name={}: Custom steps template is invalid. steps_template: "{}". Error: {}'.format(
                    self.account_name, template, e
                )
            )

            return False

    def send_bot_message(self, ch, text):
        operator = ch.get_operator()
        chat.Message.create(ch, chat.Message.Kind.OPERATOR, operator.get_visible_name(ch.session.lang), text, operator.id)

    def do_unassign_from_robot(self, ch):
        ch.external_data['json_robot_current_state'] = None
        ch.store()
        ch.process_event('sys.unassign_from_robot')

    def visitor_message_text_cleaner(self, message_text):
        return message_text.strip().lower()

    def on_action_send_message(self, ch, text):
        self.send_bot_message(ch, text)

    def on_action_redirect_to_queue(self, ch):
        self.do_unassign_from_robot(ch)


class JsonRobotParametersException(Exception):
    pass


class ProcessJsonRobotActionsException(Exception):
    pass