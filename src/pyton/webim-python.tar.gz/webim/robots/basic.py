# coding=utf-8

"""
Robots documentation: https://conf.olegb.ru/pages/viewpage.action?pageId=15074076
"""


class BasicRobotLogic(object):

    def __init__(self, operator_id, settings):
        self.operator_id = operator_id
        self.settings = settings

    def on_new_chat_created(self, chat, produce_delta=True):
        return False

    def on_new_visitor_message(self, chat, message):
        pass

    def on_new_visitor_draft(self, chat, visitor_draft):
        pass

    def on_chat_assigned_to_robot(self, chat, produce_delta=True):
        pass

    def on_chat_unassigned_from_robot(self, chat, produce_delta=True):
        pass

    def on_chat_redirected_to_robot(self, chat, produce_delta=True):
        pass

    def on_chat_closed(self, chat, produce_delta=True):
        pass

    def get_setting(self, key, default=None):
        return self.settings.get(key, default)

    def get_type(self):
        return self.settings.get('type')