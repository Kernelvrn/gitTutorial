# coding=UTF-8
from collections import defaultdict
import datetime
import time
import logging
import sys
import threading
import json
import os.path

from tornado.options import define
import tornado

import wm_settings
import visitor_tracking
import chat
import wm_mail
import wm_operator
import account
import wm_timer
import wm_utils
import wm_web
import db_utils
import wm_operator_chat
import callback_hunter


__author__ = 'mixey'


class BackgroundStorager(wm_utils.KeepRefs):

    objects_not_stored_since_ts = None
    enabled = True
    __lock = [threading.Lock(), threading.Lock()]

    def __init__(self, _account, num=0):
        super(BackgroundStorager, self).__init__()

        self.account = _account
        self.num = num
        self.__to_store_collector = Collector()
        self.__failed_collector = Collector()
        self.__being_stored_now_collector = None
        self._being_stored_now_processed_cnt = None

        self.__storing_lock = threading.Lock()
        self.__objects_access_lock = threading.Lock()

        self.__failed_to_connect = False

        self.OBJ_CLASS_AND_STORAGER_PAIRS = [(visitor_tracking.VisitSession, SessionStorager()),
                                             (chat.Chat, ChatStorager()),
                                             (chat.GlobalChat, GlobalChatStorager()),
                                             (chat.ChatHistoryRecord, ChatHistoryStorager()),  # history records must be stored after chats
                                             (chat.Message, MessageStorager()),  # messages must be stored after chats
                                             (chat.OperatorRate, RateStorager()),
                                             (account.BanRecord, BanStorager()),
                                             (wm_operator.OnlinePeriod, OnlinePeriodsStorager()),
                                             (wm_operator.OperatorDevice, OperatorDeviceStorager()),
                                             (wm_operator_chat.OperatorChatMessage, OperatorChatMessageStorager()),
                                             (callback_hunter.Callback, CallbackStorager()),
                                             (callback_hunter.CallbackHistory, CallbackHistoryStorager()),
                                             (account.KeyValueRecord, KeyValueRecordStorager())]

        self.CLASS_TO_STORAGER = dict(self.OBJ_CLASS_AND_STORAGER_PAIRS)

    def add_object_to_store(self, obj):
        with self.__objects_access_lock:
            if not BackgroundStorager.objects_not_stored_since_ts:
                BackgroundStorager.objects_not_stored_since_ts = time.time()
            self.__to_store_collector.add_object(obj)

    def get_object(self, clazz, filter_func):
        with self.__objects_access_lock:
            for o in self.__get_all_objects(clazz):
                if filter_func(o):
                    return o
            return None

    def get_objects(self, clazz, filter_func):
        with self.__objects_access_lock:
            result = []
            for o in self.__get_all_objects(clazz):
                if filter_func(o):
                    result.append(o)
            return result

    def __get_all_objects(self, clazz):
        for c in [self.__to_store_collector, self.__failed_collector, self.__being_stored_now_collector]:
            if not c:
                continue
            for o in c.get_objects(clazz):
                yield o

    def add_failed(self, obj):
        with self.__objects_access_lock:
            return self.__failed_collector.add_object(obj)

    def store(self, obj, background=True):
        if background:
            self.add_object_to_store(obj)
            return

        storager = self.CLASS_TO_STORAGER[obj.__class__]
        connection = db_utils.get_connection(self.account.name)
        ctx = StorageContext(connection, None)
        storager.do_store_one(ctx, obj)

    @classmethod
    def retry_store_failed(cls, num=0):
        cls.store_all(num=num, failed=True)

    @classmethod
    def store_all(cls, num=0, failed=False, force_enabled=False, ignore_account_not_belongs=False):
        with cls.__lock[num]:
            if cls.enabled or force_enabled:
                for storager in cls.get_instances():
                    if storager.num == num:
                        storager.__store(failed, ignore_account_not_belongs)

    def __store(self, failed, ignore_account_not_belongs=False):
        with self.__storing_lock:
            if not ignore_account_not_belongs and not self.account.belongs_to_current_tornado_instance():
                return

            BackgroundStorager.objects_not_stored_since_ts = None
            collector = self.__failed_collector if failed else self.__to_store_collector

            if collector.is_empty():
                return

            failed_to_store_objects_cnt_before = 0
            if failed:
                failed_to_store_objects_cnt_before = self.__failed_collector.get_total_objects_count()

            try:
                connection = db_utils.get_connection(self.account.name)
                if self.__failed_to_connect:
                    self.__failed_to_connect = False
                    wm_mail.mailer.send_short_message_notification(self.account, "Background Storager: Connection established")
            except Exception:
                if not self.__failed_to_connect:
                    self.__failed_to_connect = True
                    wm_mail.mailer.send_short_message_notification(self.account, "Background Storager: Failed to connect to db")  # str(sys.exc_info())
                raise

            ctx = StorageContext(connection, self)

            with self.__objects_access_lock:
                # should be done after get_connection to avoid objects missing in case of connection error
                being_stored_now_collector = collector.retrieve_collected()
                self.__being_stored_now_collector = being_stored_now_collector
                self._being_stored_now_processed_cnt = 0

            for clazz, storager in self.OBJ_CLASS_AND_STORAGER_PAIRS:
                if being_stored_now_collector.has_objects(clazz):
                    storager.store(ctx, list(being_stored_now_collector.get_objects(clazz)))

            self.__being_stored_now_collector = None
            self._being_stored_now_processed_cnt = None

            if not failed and len(ctx.storing_errors):
                wm_mail.mailer.send_storing_errors_notification(
                    self.account,
                    {'errors': '\n\n'.join(ctx.storing_errors),
                     'total_failed_to_store_objects_cnt': self.__failed_collector.get_total_objects_count()})

            if failed:
                failed_cnt_now = self.__failed_collector.get_total_objects_count()
                if failed_to_store_objects_cnt_before != failed_cnt_now:
                    wm_mail.mailer.send_failed_before_objects_stored_notification(
                        self.account,
                        {'stored_objects_cnt': failed_to_store_objects_cnt_before - failed_cnt_now,
                         'total_failed_to_store_objects_cnt': failed_cnt_now})

            connection.close()

    def get_collected_count(self, collector_name):
        with self.__objects_access_lock:
            collector = self.__get_collector(collector_name)
            return collector.get_total_objects_count() if collector else 0

    def get_being_stored_now_processed_count(self):
        return self._being_stored_now_processed_cnt

    def __get_collector(self, name):
        if name == 'failed_to_store':
            return self.__failed_collector
        elif name == 'collected_to_store':
            return self.__to_store_collector
        elif name == 'being_stored_now':
            return self.__being_stored_now_collector

    @classmethod
    def backup_all(cls):
        for storager in cls.get_instances():
            try:
                storager.__backup_collected()
            except Exception:
                logging.error("Failed to backup", exc_info=True)

    def __backup_collected(self):
        # todo being stored now
        with self.__objects_access_lock:
            data = {}
            ctx = {'account': self.account, 'lang': self.account.get_setting('default_lang')}
            for collector_name, collector in [('collected_to_store', self.__to_store_collector), ('failed_to_store', self.__failed_collector)]:
                class_to_objects_dicts = {}
                for clazz, storager in self.OBJ_CLASS_AND_STORAGER_PAIRS:
                    obj_dicts = []
                    for obj in collector.get_objects(clazz):
                        obj_dict = {}
                        if isinstance(obj, wm_utils.Jsonable):
                            obj_dict['json'] = obj.to_dict(context=ctx)
                        obj_dict['row'] = storager.obj_to_row(obj)
                        obj_dicts.append(obj_dict)
                    if obj_dicts:
                        class_to_objects_dicts[clazz.__name__] = obj_dicts
                if class_to_objects_dicts:
                    data[collector_name] = class_to_objects_dicts

            if data:
                f = open(os.path.join(wm_settings.settings['client-data-dir'], self.account.name, 'bg_storager.bkp.' + str(time.time()) + '.json'), 'w')
                f.write(json.dumps(data, cls=wm_utils.DateTimeJSONEncoder, indent=1))
                f.close()

    def process_monitor_request(self, collector_name, mode, params):
        with self.__objects_access_lock:
            collector = self.__get_collector(collector_name)
            if not collector:
                return []
            result = []
            for clazz, storager in self.OBJ_CLASS_AND_STORAGER_PAIRS:
                if mode == 'stat':
                    cnt = collector.get_objects_count(clazz)
                    if cnt:
                        result.append({"class": clazz.__name__, 'cnt': cnt})
                if mode == 'objects':
                    if clazz.__name__ == params['class_name']:
                        for o in collector.get_objects(clazz):
                            row = storager.obj_to_row(o)
                            row = row[0] if isinstance(row, tuple)and isinstance(row[0], tuple) else row
                            result.append([str(val) if val.__class__ == datetime.datetime else val for val in row])
            return result


wm_timer.invoke_periodically(5, lambda: BackgroundStorager.store_all(num=0), 'BackgroundStorager 0')
wm_timer.invoke_periodically(5, lambda: BackgroundStorager.store_all(num=1), 'BackgroundStorager 1')
wm_timer.invoke_periodically(10 * 60, lambda: BackgroundStorager.retry_store_failed(num=0), 'BackgroundStorager - retrying store failed 0')
wm_timer.invoke_periodically(10 * 60, lambda: BackgroundStorager.retry_store_failed(num=1), 'BackgroundStorager - retrying store failed 1')


class Collector:

    def __init__(self, class_to_objects=None, class_to_object_set=None, unmodifiable=False):
        self.__class_to_objects = class_to_objects or defaultdict(list)
        self.__class_to_object_set = class_to_object_set or defaultdict(set)
        self.__unmodifiable = unmodifiable

    def add_object(self, obj):
        if self.__unmodifiable:
            raise Exception

        if obj not in self.__class_to_object_set[obj.__class__]:
            self.__class_to_objects[obj.__class__].append(obj)
            self.__class_to_object_set[obj.__class__].add(obj)
            return True
        else:
            return False

    def retrieve_collected(self):
        if self.__unmodifiable:
            raise Exception

        result = Collector(self.__class_to_objects, self.__class_to_object_set, True)
        self.__class_to_objects = defaultdict(list)
        self.__class_to_object_set = defaultdict(set)
        return result

    def get_objects(self, clazz):
        if clazz in self.__class_to_objects:
            for o in self.__class_to_objects[clazz]:
                yield o

    def has_objects(self, clazz):
        return bool(self.get_objects_count(clazz))

    def get_objects_count(self, clazz):
        if clazz in self.__class_to_objects:
            return len(self.__class_to_objects[clazz])
        else:
            return 0

    def get_total_objects_count(self):
        result = 0
        for objects in self.__class_to_objects.values():
            result += len(objects)
        return result

    def is_empty(self):
        return len(self.__class_to_objects) == 0


class BaseStorager:

    allow_bulk = False

    def store(self, ctx, objects):
        if self.__class__.allow_bulk:
            self.bulk_insert(ctx, objects)
        else:
            for obj in objects:
                self.store_one(ctx, obj)
                ctx.increment_being_stored_now_processed_cnt()

    def store_one(self, ctx, obj):
        try:
            self.do_store_one(ctx, obj)
        except Exception:
            logging.error("Storing failed (%s)" % self.__class__.__name__, exc_info=True)
            added = ctx.background_storager.add_failed(obj)
            if added:
                try:
                    row = self.obj_to_row(obj)
                except Exception:
                    row = []

                try:
                    error = u'Failed to store object\nclass: %s\nvalues:\n%s\nError:\n%s\n' % (
                            obj.__class__.__name__, u', '.join([unicode(val) for val in row]), str(sys.exc_info()))
                    ctx.storing_errors.append(error)
                except Exception:
                    logging.error("Failed to add storing error", exc_info=True)

    def do_store_one(self, ctx, obj):
        row = self.obj_to_row(obj)
        callback = None
        if isinstance(row[0], tuple):
            callback = row[1]
            row = row[0]
        result = ctx.connection.execute(self.__class__.insert_sql, *row)
        if callback:
            callback()
        return result

    def obj_to_row(self, obj):
        pass

    def bulk_insert(self, ctx, objects):
        try:
            self.do_bulk_insert(ctx, objects)
            ctx.increment_being_stored_now_processed_cnt(len(objects))
        except Exception:
            logging.error("Bulk insert failed (%s)" % self.__class__.__name__, exc_info=True)
            for obj in objects:
                self.store_one(ctx, obj)
                ctx.increment_being_stored_now_processed_cnt()

    def do_bulk_insert(self, ctx, objects):
        rows = []
        callbacks = []
        for obj in objects:
            row = self.obj_to_row(obj)
            if isinstance(row[0], tuple):
                callbacks.append(row[1])
                row = row[0]
            rows.append(row)
        ctx.connection.executemany(self.__class__.insert_sql, rows)
        for c in callbacks:
            c()


class StorageContext(wm_utils.InstanceCountTracker):

    def __init__(self, connection, background_storager):
        super(StorageContext, self).__init__()
        self.connection = connection
        self.background_storager = background_storager
        self.storing_errors = []

    def increment_being_stored_now_processed_cnt(self, cnt=1):
        self.background_storager._being_stored_now_processed_cnt += cnt


class SessionStorager(BaseStorager):
    insert_sql = "insert into chatvisitsession (visitsessionid, ip, useragent, visitorid, visitorname, created, updated, json, country, region) values (%s, %s, %s, %s, %s, %s, %s, %s, %s, %s)"  # noqa: E501
    update_sql = "update chatvisitsession set ip=%s, useragent=%s, visitorid=%s, visitorname=%s, created=%s, updated=%s, json=%s where visitsessionid=%s"

#    def store(self, ctx, sessions):
#        BaseStorager.store(self, ctx, [s for s in sessions if not s.stored_to_db])
#
    def obj_to_row(self, s):
        geo = s.ip_info.get_geo(s.lang) or {}
        return (
            s.id, s.ip, wm_utils.cut_string(s.user_agent, 512),
            s.visitor.id, wm_utils.cut_string(s.visitor.get_name(), 255),
            datetime.datetime.fromtimestamp(s.creation_ts),
            datetime.datetime.fromtimestamp(s.modification_ts),
            s.to_json(context={'mode': 'db'}),
            geo.get('country_name'),
            geo.get('city')
        )

    def do_store_one(self, ctx, s):
        if not s.stored_to_db:
            BaseStorager.do_store_one(self, ctx, s)
            s.stored_to_db = True
        else:
            ctx.connection.execute(
                self.__class__.update_sql,
                s.ip, wm_utils.cut_string(s.user_agent, 512),
                s.visitor.id, wm_utils.cut_string(s.visitor.get_name(), 255),
                datetime.datetime.fromtimestamp(s.creation_ts),
                datetime.datetime.fromtimestamp(s.modification_ts),
                s.to_json(context={'mode': 'db'}),
                s.id)


class ChatStorager(BaseStorager):
    insert_sql = "insert into chatthread (created, modified, state, visitsessionid, token, offline, visitormessagecount, category, subcategory, locale, json, manuallyassignedoperatorid, startpage, createdts, modifiedts, insertedts, updatedts) values (%s, %s, %s, %s, 1, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s)"  # noqa: E501
    update_sql = "update chatthread set modified = %s, state = %s, visitormessagecount=%s, category=%s, subcategory=%s, threadkind=%s, locale=%s, json=%s, manuallyassignedoperatorid=%s, modifiedts=%s, updatedts=%s where threadid = %s"  # noqa: E501

    def obj_to_row(self, ch):
        now_ts = long(time.time() * 1e6)
        return (
            datetime.datetime.fromtimestamp(ch.creation_ts),
            datetime.datetime.fromtimestamp(ch.modification_ts),
            ch.state,
            ch.session.id,
            ch.offline,
            ch.get_visitor_message_count(),
            ch.category,
            ch.subcategory,
            ch.session.lang,
            ch.to_json(context={'mode': 'db'}),
            ch.manually_assigned_operator_id,
            ch.start_page.url if ch.start_page else None,
            long(ch.creation_ts * 1e6),
            long(ch.modification_ts * 1e6),
            now_ts,
            now_ts
        ), lambda: self.__on_inserted(ch, now_ts)

    def __on_inserted(self, ch, now_ts):
        ch.session.account.history_manager.set_last_change_ts(ch.session.visitor.id, now_ts)
        ch.inserted_ts = now_ts

    def do_store_one(self, ctx, ch):
        if ch.id is None:
            ch.set_id(BaseStorager.do_store_one(self, ctx, ch))
            ch.stored_to_db_callbacks.fire()
        else:
            now_ts = long(time.time() * 1e6)
            ctx.connection.execute(
                self.__class__.update_sql,
                datetime.datetime.fromtimestamp(ch.modification_ts),
                ch.state,
                ch.get_visitor_message_count(),
                ch.category,
                ch.subcategory,
                # hardcode: единсвенный кейс, когда из питона проставляется не undefined значение для threadkind - когда
                # при загрузке обнаруживаются пустые чаты, в остальных случаях проставляем undefined, чтобы сбросить то,
                # что могло быть проставлено в php
                'skip' if ch.external_data.get('skip', False) else 'undefined',
                ch.session.lang,
                ch.to_json(context={'mode': 'db'}),
                ch.manually_assigned_operator_id,
                long(ch.modification_ts * 1e6),
                now_ts,
                ch.id)


class GlobalChatStorager(BaseStorager):
    insert_sql = "insert into chat (accountname, ip, chattext, created, sessionid, useragent, platform) values (%s, %s, %s, %s, %s, %s, %s)"

    def obj_to_row(self, gch):
        return gch.data

    def do_store_one(self, ctx, od):
        connection = db_utils.get_connection()
        row = self.obj_to_row(od)
        connection.execute(self.__class__.insert_sql, *row)


class ChatHistoryStorager(BaseStorager):

    insert_sql = "insert into chatthreadhistory (threadid, number, dtm, state, operatorid, event, locale, departmentid, officeid) values (%s, %s, %s, %s, %s, %s, %s, %s, %s)"  # noqa: E501
    allow_bulk = True

    def obj_to_row(self, r):
        return (r.chat.id, r.number, datetime.datetime.fromtimestamp(r.ts), r.state,
                r.operator_id, r.event, r.lang, r.department_id, r.office_id)


class MessageStorager(BaseStorager):

    insert_sql = "insert into chatmessage (threadid, kind, message, created, sendername, operatorid, json, createdts, insertedts, modifiedts, updatedts) values (%s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s)"  # noqa: E501
    update_sql = "update chatmessage set message=%s, json=%s, modifiedts=%s, updatedts=%s where messageid=%s"

    def do_store_one(self, ctx, m):
        if m.db_id is None:
            db_id = BaseStorager.do_store_one(self, ctx, m)
            m.db_id = db_id
            return db_id
        else:
            now_ts = long(time.time() * 1e6)
            ctx.connection.execute(
                self.__class__.update_sql,
                m.text,
                m.to_json(context={'mode': 'db'}),
                long(m.modified_ts * 1e6),
                now_ts,
                m.db_id)
            return m.db_id

    def obj_to_row(self, m):
        now_ts = long(time.time() * 1e6)
        return (
            m.chat.id,
            chat.Message.Kind.NAME_TO_NUM[m.kind],
            m.text,
            datetime.datetime.fromtimestamp(m.ts),
            wm_utils.cut_string(m.name, 64),
            m.author_id,
            m.to_json(context={'mode': 'db'}),
            long(m.ts * 1e6),
            now_ts,
            long(m.ts * 1e6),
            now_ts
        ), lambda: self.__on_inserted(m, now_ts)

    def __on_inserted(self, m, now_ts):
        session = m.chat.session
        if m.kind != chat.Message.Kind.FOR_OPERATOR:
            session.account.history_manager.set_last_change_ts(session.visitor.id, now_ts)
        m.stored_to_db_callbacks.fire()


class RateStorager(BaseStorager):

    insert_sql = "insert into chatrate (operatorid, threadid, rate, date, deldate) values (%s, %s, %s, %s, NULL) on duplicate key update rate = %s, date = %s, deldate = NULL"  # noqa: E501
    # allow_bulk = True

    def obj_to_row(self, rate):
        return (
            rate.operator_id,
            rate.chat.id,
            rate.value,
            datetime.datetime.fromtimestamp(rate.ts),
            rate.value,
            datetime.datetime.fromtimestamp(rate.ts)
        )


class BanStorager(BaseStorager):

    insert_sql = "insert into chatban (address, till, comment, json) values (%s, %s, %s, %s)"
    # allow_bulk = True

    def obj_to_row(self, ban):
        return ban.address, datetime.datetime.fromtimestamp(ban.till_ts), ban.comment, ban.to_json(context={'mode': 'db'})

    def do_store_one(self, ctx, obj):
        result = BaseStorager.do_store_one(self, ctx, obj)
        obj.stored_to_db_callback()
        return result


class OnlinePeriodsStorager(BaseStorager):

    insert_sql = "insert into chatonlineperiod (operatorid, status, locale, dtmfrom, dtmto, departmentid) values (%s, %s, %s, %s, %s, (select d.departmentid from chatdepartment d where d.departmentkey = %s))"  # noqa: E501
    update_sql = "update chatonlineperiod set dtmto = %s where id=%s"

    def obj_to_row(self, op):
        return (
            op.operator_id,
            op.status,
            op.lang_and_dep[0],
            datetime.datetime.fromtimestamp(op.ts_from),
            datetime.datetime.fromtimestamp(op.ts_to),
            op.lang_and_dep[1]
        )

    def do_store_one(self, ctx, op):
        if op.id is None:
            op.id = BaseStorager.do_store_one(self, ctx, op)
        else:
            ctx.connection.execute(
                self.__class__.update_sql,
                datetime.datetime.fromtimestamp(op.ts_to),
                op.id)


class OperatorDeviceStorager(BaseStorager):

    insert_sql = "insert into operatordevice (deviceid, accountname, operatorid, devicestatus, useragent, pushtoken, dtmcreated, dtmmodified, platform, workhoursstatus) values (%s, %s, %s, %s, %s, %s, %s, %s, %s, %s)"  # noqa: E501
    update_sql = "update operatordevice set devicestatus = %s, pushtoken = %s, useragent = %s, platform = %s, dtmmodified = %s, workhoursstatus = %s where id = %s"  # noqa: E501

    def obj_to_row(self, od):
        return (
            od.device_id,
            od.online_operator.account.name,
            od.online_operator.operator_id,
            od.status,
            wm_utils.cut_string(od.user_agent, 1023),
            od.push_token,
            datetime.datetime.fromtimestamp(od.creation_ts),
            datetime.datetime.fromtimestamp(od.modification_ts),
            od.platform,
            od.workhours_status
        )

    def do_store_one(self, ctx, od):
        connection = db_utils.get_connection()
        if od.id is None:
            row = self.obj_to_row(od)
            od.id = connection.execute(self.__class__.insert_sql, *row)
        else:
            connection.execute(
                self.__class__.update_sql,
                od.status,
                od.push_token,
                wm_utils.cut_string(od.user_agent, 1023),
                od.platform,
                datetime.datetime.fromtimestamp(od.modification_ts),
                od.workhours_status,
                od.id)

        connection.close()


class OperatorChatMessageStorager(BaseStorager):

    insert_sql = "insert into operatorchatmessage (messageuid, operatorchatid, kind, operatorid, sendername, message, created, json) values (%s, %s, %s, %s, %s, %s, %s, %s)"  # noqa: E501

    def obj_to_row(self, ocm):
        return (
            ocm.uid,
            ocm.chat_id,
            ocm.kind,
            ocm.operator_id,
            ocm.operator_name,
            ocm.text,
            datetime.datetime.fromtimestamp(ocm.ts),
            None
        )


class KeyValueRecordStorager(BaseStorager):
    insert_sql = "insert into keyvalue(`key`, `value`, `modifiedts`) values (%s, %s, %s) ON DUPLICATE KEY UPDATE `value` = %s, `modifiedts` = %s"
    update_sql = "update keyvalue set `value` = %s, `modifiedts` = %s where `id`=%s"

    def obj_to_row(self, record):
        return (
            record.key,
            record.get_value_json(),
            long(record.modification_ts * 1e6),
            record.get_value_json(),
            long(record.modification_ts * 1e6)
        )

    def do_store_one(self, ctx, record):
        if record.id is None:
            record.id = BaseStorager.do_store_one(self, ctx, record)
        else:
            ctx.connection.execute(
                self.update_sql,
                record.get_value_json(),
                long(record.modification_ts * 1e6),
                record.id)
        record.on_stored()


class CallbackStorager(BaseStorager):

    insert_sql = "insert into callback (uid, created, modified, visitorphone, operatorphone, visitsessionid, referrerurl) values (%s, %s, %s, %s, %s, %s, %s)"
    update_sql = "update callback set modified=%s, recorduri=%s, billsec=%s where uid=%s"

    def obj_to_row(self, callback):
        return (
            callback.uid,
            datetime.datetime.fromtimestamp(callback.creation_ts),
            datetime.datetime.fromtimestamp(callback.modification_ts),
            callback.visitor_phone,
            callback.operator_phone,
            callback.session_id,
            callback.referrer_url
        )

    def do_store_one(self, ctx, callback):
        if callback.id is None:
            callback.id = BaseStorager.do_store_one(self, ctx, callback)
        else:
            ctx.connection.execute(
                self.__class__.update_sql,
                datetime.datetime.fromtimestamp(callback.modification_ts),
                callback.record_uri,
                callback.bill_seconds,
                callback.uid)


class CallbackHistoryStorager(BaseStorager):

    insert_sql = "insert into callbackhistory (callbackuid, created, state, event) values (%s, %s, %s, %s)"

    def obj_to_row(self, callback_history):
        return (
            callback_history.callback_uid,
            datetime.datetime.fromtimestamp(callback_history.creation_ts),
            callback_history.state,
            callback_history.event
        )


class CollectedToStoreObjectsMonitorRequestHandler(wm_web.AdminRequestHandler):

    @tornado.web.asynchronous
    def get(self):
        wm_timer.invoke_async(self.__get, timer_name='CollectedToStoreObjectsMonitorRequestHandler')

    def __get(self):
        mode = self.get_verified_argument('mode')
        account_name = self.get_verified_argument('account_name')
        num = self.get_int_argument('num', 0)
        a = account.Account.get(account_name, False)
        bs = a.background_storager if num == 0 else a.background_storager_1
        params = {}
        if mode == 'objects':
            params['class_name'] = self.get_verified_argument('class_name')
        result = bs.process_monitor_request(self.get_verified_argument('collector_name'), mode, params)
        result = json.dumps(result)

        wm_utils.invoke_in_ioloop(lambda: self.finish(result), name='CollectedToStoreObjectsMonitorRequestHandler')


class ChangeStoragerStatusRequestHandler(wm_web.AdminRequestHandler):
    def get(self, *args, **kwargs):
        try:
            BackgroundStorager.enabled = self.get_bool_argument('value')
            self.write(json.dumps({'result': 'ok', 'enabled': BackgroundStorager.enabled}))
        except Exception as e:
            logging.error('ChangeStoragingRequestHandler failed', exc_info=True)
            self.write(json.dumps({'result': 'error', 'message': str(e)}))


class StoreNowRequestHandler(wm_web.AdminRequestHandler):

    @tornado.web.asynchronous
    def get(self, *args, **kwargs):
        wm_timer.invoke_async(self.__get, 'StoreNowRequestHandler')

    def __get(self):
        try:
            failed = self.get_bool_argument('failed')
            ignore_account_not_belongs = self.get_bool_argument('ignore-account-not-belongs', False)
            BackgroundStorager.store_all(num=0, failed=failed, force_enabled=True, ignore_account_not_belongs=ignore_account_not_belongs)
            BackgroundStorager.store_all(num=1, failed=failed, force_enabled=True, ignore_account_not_belongs=ignore_account_not_belongs)
            self.finish(json.dumps({'result': 'ok'}))
        except Exception as e:
            logging.error('StoreNowRequestHandler failed', exc_info=True)
            self.finish(json.dumps({'result': 'error', 'message': str(e)}))


def output_collected_objects():
    for a in account.Account.get_all():
        bs = a.background_storager
        collector = bs._BackgroundStorager__to_store_collector
        class_to_objects = collector._Collector__class_to_objects
        for cl, storager in bs.OBJ_CLASS_AND_STORAGER_PAIRS:
            objects = class_to_objects.get(cl)
            print cl.__name__
            if not objects:
                continue
            for o in objects:
                row = storager.obj_to_row(o)
                modified_row = []
                for val in row:
                    if type(val) == datetime.datetime:
                        modified_row.append(wm_utils.get_ts(val))
                    else:
                        modified_row.append(val)

                print json.dumps(modified_row)


if __name__ == "__main__":

    a = account.Account.get('mixey')
    bs = BackgroundStorager(a)

    define("port", default=8235, help="run on the given port", type=int)
    define("online_dir", default=wm_settings.settings['online_dir'], help="online directory", type=str)
    define("logged_in_operators_dir", default="/var/www/webim_ru/login/cache/operators",
           help="directory with logged in operators", type=str)
    define("upstream_timeout", default=50, help="upstream timeout", type=int)

    v = visitor_tracking.Visitor(a, '123321', 'Bob')
    lp = visitor_tracking.VisitedPage('', '', True, 'title', 'ru', '')

    s = visitor_tracking.VisitSession(a, '11.111.1.11', 'Mazilllla', lp, v, None)
    a.visit_tracker.add_session(s)
    bs.add_object_to_store(s)
    s = visitor_tracking.VisitSession(a, '22.111.1.11', 'Chrome', lp, v, None)
    a.visit_tracker.add_session(s)
    bs.add_object_to_store(s)

    BackgroundStorager.store_all()

    s = visitor_tracking.VisitSession(a, '11.111.1.11', 'IE', lp, v, None)
    a.visit_tracker.add_session(s)
    bs.add_object_to_store(s)
    s = visitor_tracking.VisitSession(a, '22.111.1.11', 'Opera', lp, v, None)
    a.visit_tracker.add_session(s)
    bs.add_object_to_store(s)

    ch = chat.Chat.create(s, lp)
    m = chat.Message.create(ch, chat.Message.Kind.VISITOR, 'vasia', 'abyrvalg', None, False)
    bs.add_object_to_store(ch)
    bs.add_object_to_store(m)

    BackgroundStorager.store_all()