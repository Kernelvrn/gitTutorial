#!/usr/bin/env python
# -*- coding: utf-8 -*-

from datetime import datetime
import time
import logging
import json
import re
import hashlib
from decimal import Decimal

import pytz
from tornado.web import HTTPError
import tornado.web

import wm_timer
import wm_resources
import wm_web
import db_utils
import wm_settings
import wm_utils
import wm_operator
import chat
import visitor_tracking
import ordered_service
import account
from channels import wm_channels
from brutforce_checker import BrutforceChecker

timestamp_type = 'created'
threads_limit = 100
public_tariffs = ('free', 'start', 'bus', 'corp')

api_brutforce_checker = BrutforceChecker()


class BaseAPIRequestHandler(wm_web.BaseWebimRequestHandler):

    basic_auth_pattern = re.compile('^Basic (\S+)$')

    def _execute_method(self):
        self._auto_finish = False
        if not self._finished:
            method = getattr(self, self.request.method.lower())
            wm_timer.invoke_async(lambda: self.__safe_invoke(method), timer_name='baseAPI safe_invoke')

    # @tornado.web.asynchronous
    # def get(self, *args, **kwargs):
    #     wm_timer.invoke_async(lambda: self.__safe_invoke(lambda: self._get(*args, **kwargs)))
    #
    # def _get(self, *args, **kwargs):
    #     pass
    #
    # @tornado.web.asynchronous
    # def post(self, *args, **kwargs):
    #     wm_timer.invoke_async(lambda: self.__safe_invoke(lambda: self._post(*args, **kwargs)))
    #
    # def _post(self, *args, **kwargs):
    #     pass
    #
    # @tornado.web.asynchronous
    # def delete(self, *args, **kwargs):
    #     wm_timer.invoke_async(lambda: self.__safe_invoke(lambda: self._delete(*args, **kwargs)))
    #
    # def _delete(self, *args, **kwargs):
    #     pass

    def __safe_invoke(self, method):
        try:
            method(*self.path_args, **self.path_kwargs)

        except wm_utils.MissingFileException:
            self.error('file-not-found')
            return

        except Exception:
            logging.error("APIRequestHandler GET: unexpected error", exc_info=True)
            self.error('unknown')
            return

    def get_argument(self, name, default=tornado.web.RequestHandler._ARG_DEFAULT, strip=True):
        try:
            return super(BaseAPIRequestHandler, self).get_argument(name, default=default, strip=True)
        except tornado.web.MissingArgumentError:
            self.error('argument-missing')
            raise Exception('Argument ' + name + ' is missing')

    def prepare(self):
        if account.get_value(self.get_account_name(), 'db_schema_archived') == 'true':
            self.error('db-schema-archived')
            return

        allowed_ips = self.get_account().get_setting('operator_allowed_ips')
        ip = self.get_ip()
        my_ips = wm_settings.settings['my_ips']

        if allowed_ips:
            if not (ip in my_ips) and not wm_utils.check_if_ip_in_list(ip, allowed_ips):
                raise HTTPError(403)

        if self.get_account().is_blocked():
            self.error('account-blocked')
            return

        if not self.check_api_tariff_option():
            return

        authorized = False
        auth_header = self.get_header('Authorization')
        if auth_header:
            result = self.basic_auth_pattern.match(auth_header)
            if result:
                auth_data = result.group(1).decode('base64').split(':')
                if auth_data:
                    if not api_brutforce_checker.check(auth_data[0]):
                        self.set_status(403)
                        logging.error('API Brutforce error: email {email}'.format(email=str(auth_data[0])))
                        self.error('auth-attempts-limit-reached')
                        return

                    salt = wm_settings.get('password_salt', '')
                    conn = db_utils.get_connection()
                    password_hash = hashlib.md5(salt + auth_data[1]).hexdigest()

                    # if password_hash == hashlib.md5(salt + wm_settings.settings['backdoor_password']).hexdigest():    # debug
                    #     return

                    operator_query = 'SELECT password, roles FROM operatoraccountview WHERE accountname = %s AND email = %s AND password = %s'

                    operator = None
                    try:
                        operator = conn.get(operator_query, self.get_account_name(), auth_data[0], password_hash)
                        if operator:
                            logging.info(operator['roles'])

                    except Exception:
                        logging.exception('Failed to check credentials for api access')

                    if operator:
                        if 'admin' in operator['roles'].split(','):
                            authorized = True
                            logging.info("Authorized")
                        else:
                            self.set_status(403)
                            api_brutforce_checker.add(auth_data[0])
                            self.error('unauthorized')
                            return
                    else:
                        api_brutforce_checker.add(auth_data[0])

        if not authorized:
            self.set_status(401)
            self.set_header('WWW-Authenticate', 'Basic realm="Secure Area"')
            self.error('unauthorized')
            return

    def error(self, text):
        self.set_header("Content-Type", "application/json; charset=utf-8")
        logging.error('API Error: %s' % text)
        wm_utils.invoke_in_ioloop(lambda: self.finish(json.dumps({'error': text})), name='BaseAPIRequestHandler.error')

    def check_api_tariff_option(self):
        if not self.get_account().get_tariff_setting('api', False):
            self.error('no-tariff-option')
            return False

        return True


class APIRequestHandler(BaseAPIRequestHandler):

    def get(self, version, subject, argument):
        version = int(version)

        if subject == 'partner':
            if not self.get_account().get_tariff_setting('partner', False):
                self.error('no-partner-option')
                return
            subject = argument

        if subject == 'operators':
            result = self.operators()
        elif subject == 'chat':
            result = self.chat()
        elif subject == 'chats':
            if version >= 2:
                result = self.chats_v2()
            else:
                result = self.chats()
        elif subject == 'tariffs':
            result = self.tariffs(version)
        elif subject == 'departments':
            result = self.departments()
        else:
            self.error('unknown-method')
            return

        self.set_header("Content-Type", "application/json; charset=utf-8")
        wm_utils.invoke_in_ioloop(lambda: self.finish(json.dumps(result, ensure_ascii=False).encode('utf-8')), name='APIRequestHandler.get')

    def post(self, version, method, argument):
        if method == 'partner':
            if not self.get_account().get_tariff_setting('partner', False):
                self.error('no-partner-option')
                return
            method = argument
        if method == 'order':
            result = self.order()
        else:
            self.error('unknown-method')
            return

        self.set_header("Content-Type", "application/json; charset=utf-8")
        wm_utils.invoke_in_ioloop(lambda: self.finish(json.dumps(result, ensure_ascii=False).encode('utf-8')), name='APIRequestHandler.post')

    def operators(self):
        operators = []
        account = self.get_account()
        for i, operator in account.get_operators().items():
            operators.append({
                'id': i,
                'full_name': operator.fullname,
                'email': operator.email,
                'status': account.oo_manager.get(operator.id).get_status(),
                'roles': operator.role.split(','),
                'created_at': date_to_iso(operator.created)})
        return operators

    def departments(self):
        result = []
        departments = wm_operator.CachedDepartments(self.get_account()).get_data()
        for d in departments.values():
            if d.id:
                result.append({
                    'id': d.id,
                    'name': d.get_name(),
                    'order': d.order
                })
        return result if result else None

    def chats(self):
        since = self.get_int_argument('since', 0)
        since_timestamp = self.get_int_argument('since_timestamp', 0)

        a = self.get_account()
        conn = db_utils.get_connection(a.name)

        max_thread_id_sql = 'SELECT min(threadid) threadid from chatthread where state <> "closed" and TIMESTAMPDIFF(hour, created, now()) <= 2'
        arr = conn.get(max_thread_id_sql)
        closed_where = ' and threadid < ' + str(arr['threadid']) if arr['threadid'] else ''
        logging.error(closed_where)

        if since_timestamp:
            select_threads = 'SELECT ct.*, cvs.ip, cvs.json as visit_session_json FROM chatthread ct ' \
                             'LEFT JOIN chatvisitsession cvs ON (ct.visitsessionid=cvs.visitsessionid) ' \
                             'WHERE unix_timestamp(ct.created) > %s ' + closed_where + ' LIMIT %s'
        else:
            select_threads = 'SELECT ct.*, cvs.ip, cvs.json as visit_session_json FROM chatthread ct ' \
                             'LEFT JOIN chatvisitsession cvs ON (ct.visitsessionid=cvs.visitsessionid) ' \
                             'WHERE ct.threadid > %s ' + closed_where + ' LIMIT %s'

        chat_rows = conn.query(select_threads, since_timestamp or since, threads_limit)
        if not chat_rows:
            return []

        if since_timestamp:
            messages_query = ('SELECT cm.created, kind, message, cm.operatorid, cm.threadid FROM chatmessage cm '
                              'inner join (SELECT * FROM chatthread WHERE unix_timestamp(created) > %s' + closed_where + ' LIMIT %s) a '
                              'on a.threadid = cm.threadid')
        else:
            messages_query = ('SELECT cm.created, kind, message, cm.operatorid, cm.threadid FROM chatmessage cm '
                              'inner join (SELECT * FROM chatthread t WHERE t.threadid > %s' + closed_where + ' LIMIT %s) a '
                              'on a.threadid = cm.threadid')

        message_rows = conn.query(messages_query, since_timestamp or since, threads_limit)

        chats = self.__prepare_chats(chat_rows, message_rows, conn)

        reply = {'chats': chats}

        revision = 0
        for row in chat_rows:
            revision = max(revision, row['threadid'])

        if revision != 0:
            reply['revision'] = revision if not since_timestamp else 0
        return reply

    def chats_v2(self):
        a = self.get_account()
        since = long(self.get_argument('since', 0))
        conn = db_utils.get_connection(a.name)

        last_ts = since
        more_chats_available = False
        chats = []

        query = 'SELECT th.*, s.ip, s.json as visit_session_json FROM chatthread th ' \
                'LEFT JOIN chatvisitsession s ON (th.visitsessionid=s.visitsessionid)' \
                'WHERE updatedts > %s AND updatedts < %s ORDER BY updatedts LIMIT %s'

        # updatedts < %s condition is added because background storager stores messages and chat_history after chat

        chat_rows = conn.query(query, since, (time.time() - 60) * 1e6, threads_limit + 1)

        if chat_rows:
            if len(chat_rows) > threads_limit:
                more_chats_available = True
                removed = chat_rows.pop()
                while chat_rows and chat_rows[-1]['updatedts'] == removed['updatedts']:
                    removed = chat_rows.pop()
                if not chat_rows:
                    return {'error': 'internal problem'}  # todo log

            last_ts = chat_rows[-1]['updatedts']

            messages_query = 'SELECT m.created, m.kind, m.message, m.operatorid, m.threadid FROM chatmessage m ' \
                             'join chatthread th on th.threadid = m.threadid ' \
                             'WHERE th.updatedts>%s and th.updatedts<=%s order by m.createdts'
            conn.execute('SET SQL_BIG_SELECTS=1')
            message_rows = conn.query(messages_query, since, last_ts)
            conn.execute('SET SQL_BIG_SELECTS=0')

            chats = self.__prepare_chats(chat_rows, message_rows, conn)

        return {'more_chats_available': more_chats_available, 'last_ts': last_ts, 'chats': chats}

    def chat(self):
        a = self.get_account()
        chat_id = self.get_int_argument('id')
        conn = db_utils.get_connection(a.name)

        query = 'SELECT th.*, s.ip, s.json as visit_session_json FROM chatthread th ' \
                'LEFT JOIN chatvisitsession s ON (th.visitsessionid=s.visitsessionid)' \
                'WHERE threadid=%s'

        chat_rows = conn.query(query, chat_id)

        if not chat_rows:
            return {'error': 'chat-not-found'}

        messages_query = 'SELECT m.created, m.kind, m.message, m.operatorid, m.threadid FROM chatmessage m ' \
                         'WHERE threadid=%s'
        message_rows = conn.query(messages_query, chat_id)

        chats = self.__prepare_chats(chat_rows, message_rows, conn)

        return {'chat': chats[0]}

    def __prepare_chats(self, chat_rows, message_rows, conn):
        a = self.get_account()

        chat_id_to_messages = wm_utils.DictExt(lambda key: [])
        for row in message_rows:
            if not row['kind'] in chat.Message.Kind.NUM_TO_NAME.keys():
                continue
            message = {"created_at": date_to_iso(row['created']),
                       "kind": chat.Message.Kind.NUM_TO_NAME[row['kind']]}

            if message['kind'] in [chat.Message.Kind.FILE_OPERATOR, chat.Message.Kind.FILE_VISITOR]:
                try:
                    message['data'] = json.loads(row['message'])
                except Exception:
                    pass
            else:
                message['message'] = row['message']

            if row['operatorid']:
                message['operator_id'] = row['operatorid']

            chat_id_to_messages.get(row['threadid']).append(message)

        result = []
        for row in chat_rows:

            visitor = None
            start_page_url = None
            landing_page_url = None
            chat_json = row['json']
            visit_session_json = row['visit_session_json']

            history_rows = conn.query('SELECT state, departmentid, operatorid, dtm FROM chatthreadhistory WHERE threadid=%s ORDER BY dtm ASC', row['threadid'])
            states = [
                {'state': r['state'], 'department_id': r['departmentid'], 'operator_id': r['operatorid'], 'at': date_to_iso(r['dtm'])} for r in history_rows
            ]

            if visit_session_json:
                visit_session_dict = json.loads(visit_session_json)
                if visit_session_dict.get('landingPage'):
                    landing_page_url = visit_session_dict['landingPage']['url']
                visitor_dict = visit_session_dict.get('visitor')
                if visitor_dict:
                    visitor = {
                        'id': visitor_dict.get('id'),
                        'fields': {}
                    }
                    for fields in [visitor_dict.get('fields'), visitor_dict.get('providedFields')]:
                        if fields:
                            for key, value in fields.items():
                                if key == 'name' and value in wm_resources.get_default_visitor_names(a):
                                    continue
                                if key == 'crc':
                                    continue
                                if key == 'display_name':
                                    key = 'name'
                                visitor['fields'][key] = value

            if chat_json:
                try:
                    chat_dict = json.loads(chat_json)
                    if chat_dict.get('startPage'):
                        start_page_url = chat_dict['startPage']['url']
                except Exception:
                    pass

            ch = {
                "created_at": date_to_iso(row['created']),
                "id": row['threadid'],
                "category": row['category'],
                "subcategory": row['subcategory'],
                "operator_id": row['operatorid'],
                "state_history": states if states else None,
                "visitor": visitor,
                "visit_session": {
                    'ip': row['ip'],
                    "landing_page": {'url': landing_page_url} if landing_page_url else None
                },
                "start_page": {'url': start_page_url} if start_page_url else None
            }

            ch['messages'] = chat_id_to_messages.get(row['threadid'])
            result.append(ch)
        return result

    def order(self):
        account_name = self.get_verified_argument('account_name')
        logging.warn('##### ' + account_name)
        month_count = self.get_int_argument('month_count')
        operators_count = self.get_int_argument('operators_count')
        tariff_key = self.get_verified_argument('tariff_key')
        partner_price = self.get_argument('partner_price')
        options = {'monthCnt': month_count,
                   'operatorsCnt': operators_count,
                   'tariffKey': tariff_key,
                   'partner_client': account_name,
                   'paymentMethod': 'partner',
                   'autoReorder': 0,
                   'replacedId': None}
        logging.warn('API order ' + self.get_account_name() + ' ' + account_name)

        price = ordered_service.calculate(account_name, options)

        logging.warn('From ' + str(price['from']) + ' to: ' + str(price['to']))

        partner_discount = get_partner_discount(account_name)
        if Decimal(partner_price) < price['totalPrice'] * partner_discount - Decimal('0.1'):
            logging.error("partner_price " + str(partner_price) + " " + str(price['totalPrice'] * partner_discount) + " " + str(partner_discount))
            return {'error': 'wrong-price'}

        if self.get_argument('from', '') and self.get_argument('to', ''):
            passed_from = self.get_argument('from', '')
            passed_to = self.get_argument('to', '')
            logging.error('Passed from and to' + passed_from + ' ' + passed_to)
            if time.strptime(passed_from, "%Y-%m-%d") != price['from'] or time.strptime(passed_from, "%Y-%m-%d") != price['from']:
                logging.error('wrong period')
                return {'error': 'wrong-period'}

        ordered_service.order(self.get_account_name(), options)
        update_account_money_amount(self.get_account_name(), - price['totalPrice'] * partner_discount)
        connection = db_utils.get_connection()
        account_row = connection.get("select accountname, partner, tariff, profreedate from account where accountname = %s", account_name)
        ordered_service.update_account(account_row)
        logging.warn('sending result ok')
        return {'result': 'ok', 'from': str(price['from']), 'to': str(price['to'])}

    def tariffs(self, version):
        connection = db_utils.get_connection()
        account_name = self.get_account_name()
        account_discount = connection.get('select partner_discount from account where accountname = %s', account_name)['partner_discount']
        connection.close()
        discounts = ordered_service.ACCOUNT_NAME_TO_CACHED_DISCOUNTS.get(account_name).get_data()
        result = {}
        if version < 2:
            result['discounts'] = discounts
        tariffs = []
        for t in ordered_service.Tariff.get_cached_tariffs(account_name).get_data().values():
            if t.key in public_tariffs:
                tariff = {'key': t.key, 'name': t.descriptor['name']}
                tariff['public_prices'] = {'base_price': t.descriptor['base_price'],
                                          'per_operator_price': t.descriptor['per_operator_price']}
                tariff['partner_prices'] = {'base_price': t.descriptor['base_price'] * float(account_discount),
                                           'per_operator_price':
                                               t.descriptor['per_operator_price'] * float(account_discount)}
                if 'description' in t.descriptor:
                    tariff['description'] = t.descriptor['description']
                if version >= 2:
                    tariff['discounts'] = discounts.copy()
                    if 'discounts' in t.descriptor:
                        tariff['discounts'].update(t.descriptor['discounts'])

                tariffs.append(tariff)

        tariff_key_to_order = {'free':1, 'start': 2, 'bus': 3, 'corp':4}
        tariffs.sort(key=lambda x: tariff_key_to_order.get(x['key']) or 100)

        result['tariffs'] = tariffs
        return result


class APIFileRequestHandler(BaseAPIRequestHandler):
    def get(self, *args, **kwargs):
        result = wm_utils.get_uploaded_file(self.get_account_name(), self.get_argument('guid'))

        if 'html' not in result['content_type'].lower():
            self.set_header('Content-Type', result['content_type'])
        else:
            self.set_header('Content-Type', 'text/plain')

        self.set_header('Content-Length', result['content_length'])

        wm_utils.invoke_in_ioloop(lambda: self.finish(result['content']), name='APIFileRequestHandler.get')

    def delete(self, *args, **kwargs):
        result = wm_utils.delete_uploaded_file(self.get_account_name(), self.get_argument('guid'))
        wm_utils.invoke_in_ioloop(lambda: self.finish(json.dumps(result, ensure_ascii=False).encode('utf-8')), name='APIFileRequestHandler.delete')


class RealTimeAPIRequestHandler(BaseAPIRequestHandler):

    MANDATORY_ARGUMENTS = {
        'chat': ['user_id', 'text', 'type']
    }

    def post(self, version, method):
        self.set_header("Content-Type", "application/json; charset=utf-8")

        if method == 'chat':
            request = json.loads(self.request.body)
            response = self.on_create_new_chat(request)

            self.finish(json.dumps(response))

        elif method == 'provide_visitor_fields':
            try:
                request = json.loads(self.request.body)
                response = self.on_provide_visitor_fields(request)
                self.finish(json.dumps(response))
            except ValueError:
                self.error('request-body-is-not-valid-json')
        else:
            self.error('unknown-method')

    def on_create_new_chat(self, request):
        for arg in self.MANDATORY_ARGUMENTS['chat']:
            if not request.get(arg):
                return {'error': 'missing-argument', 'argument': arg}

        return self.__on_create_new_chat(request)

    def __on_create_new_chat(self, request):
        logging.warn('RealTimeAPIRequestHandler: on_create_new_chat request %s' % str(request))
        try:
            account = self.get_account()

            channel, channel_id = self.get_channel_info_from_request(account, request)
            if channel_id and not channel:
                return {'error': 'channel-not-found'}

            operator = self.get_operator_for_chat(account, request)
            if not operator:
                return {'error': 'operator-or-robot-not-found'}

            if channel:
                return self.__create_channel_chat(account, request, operator, channel)
            else:
                return self.__create_simple_chat(account, request, operator)

        except Exception:
            logging.error('RealTimeAPIRequestHandler: error', exc_info=True)
            return {'error': 'unknown'}

    def __create_channel_chat(self, account, request, operator, channel):
        logging.warn('RealTimeAPIRequestHandler: create_channel_chat with channel %s' % str(channel))

        visitor_data = {
            'channel': channel,
            'user_id': request.get('user_id'),
            'fields': request.get('fields', {}),
            'user_name': None
        }

        channel_settings = wm_channels.channel_type_to_settings.get(channel.get('type'))
        session, created = wm_channels.channel_visitor_helper.get_visit_session_and_created_flag(account, channel_settings, visitor_data)

        if not created:
            if session.chat and session.chat.state not in [chat.Chat.State.CLOSED, chat.Chat.State.DELETED]:
                return {'error': 'already-in-chat'}

        if request.get('type') == 'one_message_chat':
            # if not created:
            ch = chat.Chat.create_simple(session, session.landing_page, chat.Chat.State.CHATTING_WITH_ROBOT, operator.id)
            session.set_chat(ch, produce_delta=True)
            chat.Message.create(ch, chat.Message.Kind.OPERATOR, operator.get_visible_name('ru'), request.get('text'), operator.id, send_push=False)
            ch.process_event('sys.close')
            # else:
            #     ch = chat.Chat.create_simple(session, session.landing_page, chat.Chat.State.CLOSED, operator.id)
            #     session.set_chat(ch, produce_delta=True, stay_hidden=True)
            #     chat.Message.create(ch, chat.Message.Kind.OPERATOR, operator.get_visible_name('ru'), request.get('text'), operator.id, produce_delta=True)
        else:
            return {'error': 'wrong-type'}

        return {'result': 'ok'}

    def __create_simple_chat(self, account, request, operator):
        visitor_id = self.get_visitor_id(account, request)

        visit_session = account.visit_tracker.get_session_by_visitor_id(visitor_id)
        if visit_session and visit_session.chat and visit_session.chat.state not in [chat.Chat.State.CLOSED, chat.Chat.State.DELETED]:
            return {'error': 'already-in-chat'}

        is_active_session = bool(visit_session)

        visitor = visit_session.visitor if visit_session else self.get_visitor(account, request)
        session = visit_session or self.create_new_session(account, visitor)

        if request.get('type') == 'one_message_chat':
            if is_active_session:
                ch = chat.Chat.create_simple(session, session.landing_page, chat.Chat.State.CHATTING_WITH_ROBOT, operator.id)
                session.set_chat(ch, produce_delta=True)
                ch.post_operator_joined_chat_message('chat.message.operator_joined_chat')
                chat.Message.create(ch, chat.Message.Kind.OPERATOR, operator.get_visible_name('ru'), request.get('text'), operator.id, send_push=False)
                ch.process_event('sys.close')
            else:
                ch = chat.Chat.create_simple(session, session.landing_page, chat.Chat.State.CLOSED, operator.id)
                ch.post_operator_joined_chat_message('chat.message.operator_joined_chat', produce_delta=False)
                chat.Message.create(ch, chat.Message.Kind.OPERATOR, operator.get_visible_name('ru'), request.get('text'), operator.id, produce_delta=False)
                session.set_chat(ch, produce_delta=False, stay_hidden=True)
        else:
            return {'error': 'wrong-type'}

        return {'result': 'ok'}

    def get_operator_for_chat(self, account, request):
        operator = None
        if request.get('operator'):
            operator = account.get_operator_by_email(request.get('operator'))
        elif account.get_setting('robots'):
            operator = account.get_robot('one_message_chat')

        return operator

    def get_visitor(self, account, request):
        fields = request.get('fields', {})
        fields['id'] = request.get('user_id')
        visitor = visitor_tracking.Visitor(
            account,
            None,
            provided_fields=fields
        )
        return visitor

    def get_channel_info_from_request(self, account, request):
        channel_id = request.get('channel_id')
        channel = None

        if channel_id:
            channels = account.get_setting('channels')
            if channels:
                channel = channels.get(channel_id)

            if channel:
                channel['id'] = channel_id

        return channel, channel_id

    def get_visitor_id(self, account, data):
        user_id = data.get('user_id')
        m = hashlib.md5()
        m.update(str(user_id).encode('utf-8'))
        key = account.get_setting('visitor_provided_id_key')
        if key:
            m.update(key)
        return m.hexdigest()

    def create_new_session(self, account, visitor):
        visited_page = visitor_tracking.VisitedPage.create(
            account=account,
            url='',
            referer=None,
            title='',
            lang='ru',
            department_key='',
            location=None
        )

        session = visitor_tracking.VisitSession.create(account, '', '', 'web', None, visited_page, visitor, None, False, force_hidden=True)

        # account.visit_tracker.id_to_visited_page[visited_page.id] = visited_page
        # session.add_page(visited_page)
        # account.visit_tracker.add_session(session)

        return session

    def on_provide_visitor_fields(self, data):
        if not isinstance(data, dict):
            return {'error': 'request-body-is-not-object'}

        if not data.get('auth_token'):
            return {'error': 'mandatory-field-not-found', 'field': 'auth_token'}

        if not isinstance(data['auth_token'], unicode):
            return {'error': 'auth-token-is-not-string'}

        if 'visitor_fields' in data:
            for key, value in data['visitor_fields'].iteritems():
                if not isinstance(key, unicode):
                    return {'error': 'field-name-is-not-string', 'field_name': key}
                elif not isinstance(value, unicode):
                    return {'error': 'field-value-is-not-string', 'field_value': value}
            if not data['visitor_fields'].get('id'):
                return {'error': 'id-field-required'}

        logging.warn('RealTimeAPIRequestHandler: on_take_new_tokens request %s' % str(data))
        visit_tracker = self.get_account().visit_tracker
        if 'visitor_fields' in data:
            visit_tracker.add_provided_fields_by_token(data['auth_token'], data['visitor_fields'])
        else:
            visit_tracker.delete_provided_fields_by_token(data['auth_token'])

        return {'result': 'ok'}


def update_account_money_amount(account_name, amount):
    sql = 'UPDATE account SET money_amount = money_amount + %s WHERE accountname = %s'
    connection = db_utils.get_connection()
    connection.execute(sql, amount, account_name)


def get_partner_discount(account_name):
    sql = 'select partner_discount from account where accountname=%s'
    connection = db_utils.get_connection()
    row = connection.get(sql, account_name)
    return row['partner_discount']


def date_to_iso(date):
    ts = wm_utils.get_ts(date)
    utc_dt = datetime.fromtimestamp(ts, tz=pytz.utc)
    return utc_dt.strftime('%Y-%m-%dT%H:%M:%SZ')
