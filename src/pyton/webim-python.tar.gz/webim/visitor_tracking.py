# coding=UTF-8
import copy
import hashlib
import hmac
import logging
import random
import threading
import time
import weakref
import json
import uuid
import urlparse
import re
import sys
import urllib
import urllib2
from Crypto.Cipher import AES

import tornado
import tornado.web
from tornado.websocket import WebSocketHandler
from tornado.iostream import StreamClosedError

from account import Account
import wm_timer
import wm_resources
import chat
import db_utils
import wm_mail
from user_agent_parser import PyBrowscap
from search_engine_parser import SearchEngineParser
from geo.ip_info import IPInfo
import wm_web
from delta import Delta, DeltaManager, DeltaRequestHandler, DELTA_MANAGER_STUB
from wm_operator import Department, OnlineState, DepartmentDelta
import wm_utils
import wm_settings
import waiter
from account import BanRecord
from wm_utils import WebimException
from wm_cobrowsing import CobrowsingSession
from callback_hunter import Callback, CallbackHistory
from wm_events import Event
from . import stat


class SiteLandingInfo:
    def __init__(self, landing_page, search):
        self.__landing_page = landing_page
        self.__search = search
        self.__marks = None

    def to_dict(self, include_session=True, context=None):
        res = {}

        if self.__search is not None:
            res['search'] = self.__search.to_dict()

        if self.__landing_page is not None:
            res['landingPage'] = self.__landing_page.to_dict(include_session)
        res['marks'] = self.__get_url_marks()
        return res

    def __get_url_marks(self):
        if self.__marks is None:
            self.__marks = {}

            if not self.__landing_page.url:
                return {}

            q = urlparse.urlparse(self.__landing_page.url).query
            params = urlparse.parse_qs(q)

            if params is None:
                return {}

            for param_name in ['utm_source', 'utm_medium', 'utm_term', 'utm_content', 'utm_campaign']:
                try:
                    if param_name not in params:
                        continue

                    text = params[param_name][0]
                    text = text.encode('iso-8859-1')
                    try:
                        #               text = text.decode('utf-8')
                        text = unicode(text, "utf-8")
                    except UnicodeDecodeError:
                        text = unicode(text, "cp1251")

                    self.__marks[param_name] = text
                except Exception:
                    logging.error(u'Could not decode param: %s' % params[param_name][0], exc_info=True)
        return self.__marks


class VisitTracker(object):
    OLD_SESSION_REMOVING_TIMEOUT = 30 * 60  # 30 min
    OLD_SESSION_CLEANING_PERIOD = 5 * 60  # 5 min

    session_filters = {
        'alive': lambda s: s.is_alive(),
        'alive_not_hidden': lambda s: s.is_alive() and not s.hidden,
        'chats': lambda s: s.chat,
        'assigned_chats': lambda s: s.chat and s.chat.get_operator_id(),
        'not_hidden_chats': lambda s: s.is_alive() and not s.hidden and s.chat
    }

    def __init__(self, account):
        self.account = account
        self.__id_to_visit_session = {}
        self.id_to_visited_page = {}
        self.visitor_id_to_visit_session = weakref.WeakValueDictionary()
        self.push_token_to_session = weakref.WeakValueDictionary()

        self.provided_token_to_fields = {}

        self.visitor_id_to_previous_chat_tag = {}

        self.ready = False

        self.__unhide_chats_lock = threading.Lock()

        wm_timer.invoke_periodically(30, self.clean_old_closed_chats, 'clean_old_closed_chats')

        self.kind_to_filter_name_to_session_id_subset = wm_utils.DictExt(lambda kind: dict([(name, set()) for name in VisitTracker.session_filters]))

    def get_session(self, id):
        return self.__id_to_visit_session.get(id)

    def add_session(self, session):
        if session.chat and not self.is_visible_chats_limit_reached(session.chat.offline):
            session.set_not_hidden(produce_delta=False)
        self.__id_to_visit_session[session.id] = session
        if session.kind == VisitSession.Kind.ONLINE:
            self.visitor_id_to_visit_session[session.visitor.id] = session
            session.register_by_push_token_and_invalidate_in_other(session.push_token)
        session.update_related_to_operators()
        self.update_subsets(session)

    def get_sessions_by_filter_name(self, kind, filter_name):
        if kind:
            for id in self.kind_to_filter_name_to_session_id_subset.get(kind)[filter_name]:
                yield self.get_session(id)
        else:
            for k in VisitSession.Kind.ALL:
                for s in self.get_sessions_by_filter_name(k, filter_name):
                    yield s

    def update_subsets(self, session):
        for name, filter in self.session_filters.items():
            subset = self.kind_to_filter_name_to_session_id_subset.get(session.kind)[name]
            if session.id in self.__id_to_visit_session and filter(session):
                if session.id not in subset:
                    subset.add(session.id)
            else:
                if session.id in subset:
                    subset.remove(session.id)

    def get_session_by_visitor_id(self, visitor_id):
        session = self.visitor_id_to_visit_session.get(visitor_id)
        if (not session) or (session.id not in self.__id_to_visit_session):
            return None
        return session

    def get_all_sessions(self, kind=None, kinds=None):
        kinds = [kind] if kind else kinds
        for session in self.__id_to_visit_session.values():
            if not kinds or session.kind in kinds:
                yield session

    def is_session_exist(self, session_id):
        return session_id in self.__id_to_visit_session

    def get_online_alive_sessions_count(self):
        return len(self.kind_to_filter_name_to_session_id_subset.get(VisitSession.Kind.ONLINE)['alive'])

    def get_sessions_count(self, filter_func):
        result = 0
        for s in self.__id_to_visit_session.values():
            if filter_func(s):
                result += 1
        return result

    def get_sessions_with_closed_chats(self):
        result = []
        for s in self.get_all_sessions():
            if s.closed_chat:
                result.append(s)
        return result

    def get_alive_not_hidden_sessions_count(self, session_kind=None):
        session_kind = session_kind or VisitSession.Kind.ONLINE
        return len(self.kind_to_filter_name_to_session_id_subset.get(session_kind)['alive_not_hidden'])

    def get_not_hidden_chats_count(self, offline):
        session_kind = VisitSession.Kind.OFFLINE_CHAT if offline else VisitSession.Kind.ONLINE
        return len(self.kind_to_filter_name_to_session_id_subset.get(session_kind)['not_hidden_chats'])

    def is_visible_chats_limit_reached(self, offline):
        limit = self.account.get_setting('visible_offline_chats_limit' if offline else 'visible_online_chats_limit')
        return self.get_not_hidden_chats_count(offline) >= limit

    def unhide_chats_up_to_limit(self):
        with self.__unhide_chats_lock:
            self.__unhide_chats_up_to_limit(False)
            self.__unhide_chats_up_to_limit(True)

    def __unhide_chats_up_to_limit(self, offline):

        if not self.is_visible_chats_limit_reached(offline):
            chats = self.get_chats(
                lambda ch: ch.session.is_alive() and ch.session.hidden and ch.state != chat.Chat.State.CLOSED_BY_OPERATOR,
                offline)
            while chats:
                ch = min(chats, key=lambda ch: ch.creation_ts if ch.session.hidden else float('inf'))
                if not ch.session.hidden:
                    break
                ch.session.set_not_hidden()
                if self.is_visible_chats_limit_reached(offline):
                    break

    @classmethod
    def hide_chats_if_necessary(cls):
        for account in Account.get_all():
            try:
                tracker = account.visit_tracker

                # todo order
                offline = False
                if tracker.is_visible_chats_limit_reached(offline):
                    threshold_ts = time.time() - 10 * 60  # 10 min
                    for ch in tracker.get_chats(lambda ch: ch.state == chat.Chat.State.CLOSED_BY_OPERATOR and ch.modification_ts < threshold_ts,
                                                offline):
                        session = ch.session
                        if not session.hidden:
                            session.set_hidden(True)
                            if not tracker.is_visible_chats_limit_reached(offline):
                                break
            except Exception:
                logging.error("Error in hide_chats_if_necessary for account " + account.name, exc_info=True)

    def clean_old_closed_chats(self):
        sessions_with_closed_chats = self.get_sessions_with_closed_chats()
        department_key_to_sessions = wm_utils.DictExt(lambda key: [])

        for s in sessions_with_closed_chats:
            department_key_to_sessions.get(s.department_key).append(s)

        shown_closed_chats_limit = self.account.get_setting('shown_closed_chats_limit')
        for dep_key, sessions in department_key_to_sessions.items():
            if len(sessions) > shown_closed_chats_limit:
                sessions.sort(key=lambda x: x.closed_chat.modification_ts)
                for s in sessions[0: len(sessions) - shown_closed_chats_limit]:
                    s.set_chat(None, produce_delta=True, reset_closed_chat=True)

    def count_chats_per_operator(self, offline=False):
        result = {}
        # todo special filter for assigned actual chats (or remember aasigned chats by operator)
        for s in self.get_sessions_by_filter_name(kind=VisitSession.Kind.OFFLINE_CHAT if offline else VisitSession.Kind.ONLINE,
                                                  filter_name='assigned_chats'):
            if s.chat.get_operator_id() and s.chat.state in self.account.get_setting('chat_states_for_count_per_operator'):
                operator_id = s.chat.get_operator_id()
                result[operator_id] = result.get(operator_id, 0) + 1
        return result

    def get_chats(self, filter, offline=False):
        result = []
        for s in self.get_sessions_by_filter_name(kind=VisitSession.Kind.OFFLINE_CHAT if offline else VisitSession.Kind.ONLINE, filter_name='chats'):
            if filter(s.chat):
                result.append(s.chat)
        return result

    def unassign_all_chats(self, offline=False):
        chats = self.get_chats(lambda ch: True, offline=offline)
        for c in chats:
            c.process_event('sys.unassign')

    def close_all_chats(self, offline=False):
        chats = self.get_chats(lambda ch: True, offline=offline)
        for c in chats:
            c.process_event('sys.close')

    def get_offline_chats_by_visitor_id(self, visitor_id):
        filter = lambda chat: chat.session.visitor.id == visitor_id
        return self.get_chats(filter, offline=True)

    def load_previous_visitor_ids(self):
        connection = db_utils.get_connection(self.account.name)
        rows = connection.query('SELECT visitorid FROM chatvisitsession')
        connection.close()

        self.visitor_id_to_previous_chat_tag = {row['visitorid']: True for row in rows}

    def check_visitor_previous_chat_tag(self, visitor_id):
        return self.visitor_id_to_previous_chat_tag.get(visitor_id, False)

    def add_provided_fields_by_token(self, token, fields):
        self.provided_token_to_fields[token] = {'visitor_fields': fields, 'ts': time.time()}

    def delete_provided_fields_by_token(self, token):
        if token in self.provided_token_to_fields:
            del self.provided_token_to_fields[token]

    def get_provided_fields_by_token(self, token):
        return self.provided_token_to_fields.get(token, {}).get('visitor_fields')

    def update_ban_statuses_for_visitors(self):
        for session in self.get_all_sessions(kinds=[VisitSession.Kind.ONLINE, VisitSession.Kind.OFFLINE_CHAT]):
            session.visitor.update_banned_status()

    # TODO  [merge_8_with_9] remove (infotel shit)
    def update_sections(self, op_id):
        for session in self.get_all_sessions(kinds=[VisitSession.Kind.ONLINE]):
            if session.visitor and session.visitor.last_chat_operator_id == op_id:
                session.update_section_and_order()

    def clean_old_tokens(self):
        current_time = time.time()
        tokens_to_delete = []
        for token in self.provided_token_to_fields:
            if ('session_id' in self.provided_token_to_fields[token]
               and not self.is_session_exist(self.provided_token_to_fields[token].get('session_id'))
               or self.provided_token_to_fields[token]['ts'] > current_time + 60 * 60):
                tokens_to_delete.append(token)
        for token in tokens_to_delete:
            del self.provided_token_to_fields[token]

    def clean_session(self, session_id):
        pages_cnt = 0
        session = self.__id_to_visit_session[session_id]

        for page in session.visited_pages:
            page.get_waiters_manager().reject_all_waiters('reinit-required')
            del self.id_to_visited_page[page.id]
            pages_cnt += 1

        del self.__id_to_visit_session[session_id]
        self.update_subsets(session)
        session.before_delete()

        return pages_cnt

    @classmethod
    def clean_old_sessions(cls):
        threshold_time = time.time() - cls.OLD_SESSION_REMOVING_TIMEOUT

        logging.info('Old sessions cleaning starting...')

        total_deleted_pages_cnt = 0
        sessions_cnt = 0
        for account in Account.get_all():
            tracker = account.visit_tracker
            ids_to_remove = [id for id, session in tracker.__id_to_visit_session.items() if
                             not session.is_alive() and session.last_alive_ts < threshold_time]
            for id in ids_to_remove:
                total_deleted_pages_cnt += tracker.clean_session(id)
                sessions_cnt += 1
            tracker.clean_old_tokens()

        logging.info('Old sessions cleaning finished. Removed %d sessions, %d pages' % (sessions_cnt, total_deleted_pages_cnt))


# clean_old_sessions()
wm_timer.invoke_periodically(VisitTracker.OLD_SESSION_CLEANING_PERIOD, VisitTracker.clean_old_sessions, "old sessions cleaning")
wm_timer.invoke_periodically(60, VisitTracker.hide_chats_if_necessary, "hide_chats_if_necessary")


class Visitor(wm_utils.InstanceCountTracker, wm_utils.Jsonable):
    provided_field_name_to_field_name_mapping = {
        'display_name': 'name',
    }

    def __init__(self, account, id, default_visitor_name='', icon=None, fields=None, provided_fields=None, webim_visitor=None, creation_ts=None,
                 modification_ts=None, integration=None, tags=None, channel_type=None, channel_user_id=None, channel_user_name=None, channel_id=None,
                 last_chat_operator_id=None, operator_edited_fields=None, custom_fields=None):
        super(Visitor, self).__init__()
        self.account = account
        self.session = None
        self.id = id or uuid.uuid4().hex

        self.fields = fields or {}
        self.unserved_fields = {}  # these fields contain information that MUST NOT be saved in DB (bank account keys, etc) because of security reasons

        self.fields['name'] = wm_utils.filter_4_byte_characters(self.fields.get('name', None) or default_visitor_name)
        self.provided_fields = provided_fields or {}
        self.webim_visitor = webim_visitor or {}
        self.custom_fields = custom_fields or {}

        self.integration = integration or {}
        self.icon = icon or VisitorIcon()

        self.creation_ts = creation_ts
        self.modification_ts = modification_ts

        self.previous_chat_tag = False
        self.banned = False
        self.tags = tags or []

        self.operator_edited_fields = operator_edited_fields or {}
        self.last_chat_operator_id = last_chat_operator_id

        self.channel_type = channel_type
        self.channel_id = channel_id
        self.channel_user_id = channel_user_id
        self.channel_user_name = channel_user_name  # telegram username or vk screen_name

        self.__update_id_according_to_provided_id()

    def __update_id_according_to_provided_id(self):
        if self.provided_fields.get('id'):
            self.id = self.get_visitor_id_by_provided_id(self.account.get_setting('visitor_provided_id_key'), self.provided_fields.get('id'))

    @classmethod
    def get_visitor_id_by_provided_id(cls, provided_id_key, visitor_provided_id):
        if visitor_provided_id:
            m = hashlib.md5()
            m.update(visitor_provided_id.encode('utf-8'))
            if provided_id_key:
                m.update(provided_id_key)
            return m.hexdigest()

    @classmethod
    def create_from_dict(cls, account, d, visitor_ext, default_visitor_name):
        provided_fields = d.get('providedFields') or visitor_ext  # visitor_ext - oldschool format of session json
        icon_dict = d.get('icon') or {}
        return Visitor(
            account,
            d.get('id'),
            fields=d.get('fields'),
            provided_fields=provided_fields,
            webim_visitor=d.get('webimVisitor'),
            icon=VisitorIcon(icon_dict.get('shape'), icon_dict.get('color')),
            creation_ts=d.get('creationTs'),
            modification_ts=d.get('modificationTs'),
            default_visitor_name=default_visitor_name,
            integration=d.get('integration') or None,
            tags=d.get('tags'),
            operator_edited_fields=d.get('opFields'),
            last_chat_operator_id=d.get('lastOpId'),
            channel_type=d.get('channelType'),
            channel_id=d.get('channelId'),
            channel_user_id=d.get('channelUserId'),
            channel_user_name=d.get('channelUserName'),
            custom_fields=d.get('customFields')
        )

    def get_name(self):
        return self.get_field_value('name')

    def get_field_value(self, field):
        if field == 'name':
            return self.provided_fields.get('display_name') or self.fields['name']
        else:
            return self.provided_fields.get(field) or self.fields.get(field)

    def to_dict(self, context=None):
        mode = context and context.get('mode')
        result = {'id': self.id,
                  'icon': self.icon.to_dict(),
                  'tags': self.tags,
                  'lastOpId': self.last_chat_operator_id,
                  'channelType': self.channel_type,
                  'channelId': self.channel_id,
                  'channelUserId': self.channel_user_id,
                  'channelUserName': self.channel_user_name
                  }

        if self.operator_edited_fields:
            result['opFields'] = self.operator_edited_fields

        # ios application has problems with storing null values
        if self.creation_ts:
            result['creationTs'] = self.creation_ts
        if self.modification_ts:
            result['modificationTs'] = self.modification_ts

        if mode == 'operator' and self.unserved_fields:
            result['unservedFields'] = self.unserved_fields.copy()

        if mode == 'visitor':
            result['fields'] = self.fields.copy()
            result['hasProvidedFields'] = bool(self.provided_fields)
        elif mode == 'db':
            result['fields'] = self.fields.copy()
            result['providedFields'] = self.provided_fields.copy()
            result['webimVisitor'] = self.webim_visitor.copy()
            result['integration'] = self.integration.copy()
            result['customFields'] = self.custom_fields.copy()
        else:
            result['banned'] = self.banned
            result['hasPreviousChats'] = bool(self.previous_chat_tag) and self.account.get_setting('show_previous_chats_to_operator')
            result['previousChatTag'] = self.previous_chat_tag
            result['fields'] = self.get_merged_fields()
            if self.session.platform == 'pochta':
                result['fields'] = self.fields.copy()
            result['customFields'] = self.custom_fields.copy()

        return result

    def set_session(self, session):
        self.session = session

        # todo возможно стоит перенести это в __init__ т.к. там теперь есть аккаунт
        self.previous_chat_tag = session.account.visit_tracker.check_visitor_previous_chat_tag(self.id)
        self.banned = session.account.is_banned_visitor(ip=session.ip, push_token=session.push_token)

    def set_banned_status(self, value):
        if self.banned != value:
            self.banned = value
            self.session.add_operator_delta(Delta('VISITOR', Delta.Event.UPDATE, self.session.id, self))

            if self.banned:
                if self.session.chat:
                    self.session.chat.process_event('operator.ban', {'operator_id': self.session.chat.get_operator_id()})

                offline_chats = self.session.account.visit_tracker.get_offline_chats_by_visitor_id(self.id)
                for chat in offline_chats:
                    chat.process_event('operator.ban', {'operator_id': chat.get_operator_id()})

    def update_banned_status(self):
        new_status = self.session.account.is_banned_visitor(ip=self.session.ip, push_token=self.session.push_token)
        self.set_banned_status(new_status)

    def __deepcopy__(self, memo):
        return Visitor(
            self.account,
            self.id,
            icon=copy.deepcopy(self.icon, memo),
            fields=copy.deepcopy(self.fields, memo),
            provided_fields=copy.deepcopy(self.provided_fields, memo),
            webim_visitor=copy.deepcopy(self.webim_visitor, memo),
            creation_ts=self.creation_ts,
            modification_ts=self.modification_ts)

    def get_merged_fields(self):
        result = self.fields.copy()
        for provided_field_name, value in self.provided_fields.items():
            if provided_field_name == 'crc':
                continue
            name = Visitor.provided_field_name_to_field_name_mapping.get(provided_field_name, provided_field_name)
            result[name] = value

        for operator_field_name, value in self.operator_edited_fields.items():
            if value:
                result[operator_field_name] = value

        return result

    def update_name_according_to_lang(self, produce_delta=True):
        default_names = wm_resources.get_default_visitor_names(self.session.account)
        if self.get_name() in default_names:
            self.update_fields({'name': self.session.get_resource('chat.default.visitorname')}, produce_delta=produce_delta)

    def update_custom_fields(self, fields):
        changed = False
        for key, value in fields.iteritems():
            if key not in self.custom_fields or self.custom_fields.get(key) != value:
                changed = True
                self.custom_fields[key] = value

        if changed:
            self.session.add_operator_delta(Delta("VISITOR", Delta.Event.UPDATE, self.session.id, self))
            self.session.store()

    def update_unserved_fields(self, unserved_fields):
        for fieldName in unserved_fields:
            if self.unserved_fields.get(fieldName, None) != unserved_fields[fieldName]:
                self.unserved_fields[fieldName] = unserved_fields[fieldName]
        self.session.add_operator_delta(Delta("VISITOR", Delta.Event.UPDATE, self.session.id, self))

    def update_fields(self, fields, produce_delta=True, produce_visitor_delta=False):
        changed = False
        if not fields.get('name') and 'name' in fields:
            del fields['name']
        for fieldName in fields:
            if self.fields.get(fieldName, None) != fields[fieldName]:
                changed = True
        self.update({'fields': fields})
        if changed:
            self.modification_ts = time.time()
            if produce_delta:
                self.session.add_operator_delta(Delta("VISITOR", Delta.Event.UPDATE, self.session.id, self))
            if produce_visitor_delta:
                self.session.delta_manager.add_delta(Delta("VISITOR", Delta.Event.UPDATE, self.session.id, self))
            self.session.account.push_manager.send_visitor_fields_changed_notification(self.session, self.fields)
            self.session.store()
            if self.session.chat:
                wm_timer.invoke_async(lambda: self.session.account.integration_manager.on_visitor_update_fields(self.session.chat),
                                      'integration.on_visitor_update_fields')

    def update(self, values):
        if 'fields' in values:
            for field_name in values['fields']:
                self.fields[field_name] = values['fields'][field_name]

        icon_dict = values.get('icon')
        self.icon = VisitorIcon(icon_dict.get('shape'), icon_dict.get('color')) if icon_dict else self.icon

    def set_avatar_url(self, avatar_url, produce_delta=True):
        if self.fields.get('avatar_url') != avatar_url:
            self.fields['avatar_url'] = avatar_url

            if produce_delta:
                self.session.add_operator_delta(Delta("VISITOR", Delta.Event.UPDATE, self.session.id, self))
                self.session.delta_manager.add_delta(Delta("VISITOR", Delta.Event.UPDATE, self.session.id, self))

    def update_last_chat_operator_id(self, operator_id, produce_delta=True):
        if self.last_chat_operator_id != operator_id:
            self.last_chat_operator_id = operator_id

            if produce_delta:
                self.session.add_operator_delta(Delta("VISITOR", Delta.Event.UPDATE, self.session.id, self))
                self.session.delta_manager.add_delta(Delta("VISITOR", Delta.Event.UPDATE, self.session.id, self))

    def update_visitor_previous_chat_tag(self, tag, produce_delta=True):
        if tag != self.previous_chat_tag:
            self.previous_chat_tag = tag
            self.session.account.visit_tracker.visitor_id_to_previous_chat_tag[self.id] = tag

            if produce_delta:
                self.session.add_operator_delta(Delta('VISITOR', Delta.Event.UPDATE, self.session.id, self))

    def check_last_visitor_chat_created_ts(self):
        account_name = self.session.account.name
        connection = db_utils.get_connection(account_name)

        sql = ("select createdts from chatthread th "
               "join chatvisitsession s on s.visitsessionid = th.visitsessionid "
               "where s.visitorid = %s and th.state='closed' "
               "order by threadid desc limit 1;")

        result = connection.get(sql, self.id)
        connection.close()
        if result:
            self.update_visitor_previous_chat_tag(result['createdts'])

    def update_operator_fields(self, operator_fields, produce_delta=True):
        self.operator_edited_fields = operator_fields

        if produce_delta:
            self.session.add_operator_delta(Delta("VISITOR", Delta.Event.UPDATE, self.session.id, self))
            self.session.delta_manager.add_delta(Delta("VISITOR", Delta.Event.UPDATE, self.session.id, self))

        msg = self.session.get_resource('system.operator_contacts') + '\n' + self.format_fields(self.session, operator_fields)
        chat.Message.create(self.session.chat, chat.Message.Kind.FOR_OPERATOR, None,
                            msg, produce_delta=produce_delta, data={'subKind': 'fields_by_operator', 'fields': operator_fields})

    def get_encrypted_operator_fields(self):
        # Tip for future me: you can't use same AES Cipher object for encrypting and decrypting at once because of padding. (Just trust me)

        plaint_text_op_fields = json.dumps(self.operator_edited_fields)

        # our plaintext length must be a multiple of 16 in length
        r = 16 - len(plaint_text_op_fields) % 16
        plaint_text_op_fields += " " * r

        obj = AES.new('1S9p6t6elL5872wNuKa7eepZ', AES.MODE_CBC, 'TsfGg6YNvnyDbndw')
        encrypted_op_fields = obj.encrypt(plaint_text_op_fields).decode("latin-1")
        return encrypted_op_fields

    def get_decrypted_operator_fields(self, encrypted_operator_fields):
        fields = {}

        if encrypted_operator_fields:
            if type(encrypted_operator_fields) == str:
                try:
                    encrypted = encrypted_operator_fields.encode("latin-1")
                    obj = AES.new('1S9p6t6elL5872wNuKa7eepZ', AES.MODE_CBC, 'TsfGg6YNvnyDbndw')
                    decrypted = obj.decrypt(encrypted)

                    fields = json.loads(decrypted)
                except Exception:
                    logging.error('get_decrypted_operator_fields: decryption failed for session %s, encrypted=%s', str(self.session.id),
                                  encrypted_operator_fields, exc_info=True)

            if type(encrypted_operator_fields) == dict:
                fields = encrypted_operator_fields

        return fields

    def set_tags(self, tags, produce_delta=True):
        self.tags = tags

        if produce_delta:
            self.session.add_operator_delta(Delta("VISITOR", Delta.Event.UPDATE, self.session.id, self))
            self.session.delta_manager.add_delta(Delta("VISITOR", Delta.Event.UPDATE, self.session.id, self))

    def set_provided_fields(self, provided_fields, webim_visitor, produce_delta=True):
        self.session.log('set_provided_fields')
        provided_fields = provided_fields or {}
        if self.provided_fields == provided_fields:
            self.session.log('set_provided_fields true')
            return True

        if self.provided_fields and self.provided_fields.get('id') != provided_fields.get('id'):
            self.session.log('set_provided_fields false')
            return False  # another visitor logged in

        self.provided_fields = provided_fields
        self.webim_visitor = webim_visitor
        self.modification_ts = time.time()

        if self.provided_fields.get('id'):
            self.__update_id_according_to_provided_id()

            if self.session.has_previous_chats:
                if self.id not in self.session.account.visit_tracker.visitor_id_to_previous_chat_tag:
                    self.session.account.visit_tracker.visitor_id_to_previous_chat_tag[self.id] = True
            self.previous_chat_tag = self.session.account.visit_tracker.check_visitor_previous_chat_tag(self.id)

            self.session.account.visit_tracker.visitor_id_to_visit_session[self.id] = self.session

        if produce_delta:
            self.session.add_operator_delta(Delta("VISITOR", Delta.Event.UPDATE, self.session.id, self))
        self.session.store()

        return True

    def get_formatted_fields(self, session):
        return self.format_fields(session, self.get_merged_fields())

    def format_fields(self, session, fields):
        # todo sort order
        pieces = []
        default_names = wm_resources.get_default_visitor_names(session.account)
        for field_name, value in fields.items():
            if type(value) == str or type(value) == unicode:
                if field_name != 'avatar_url' and not (field_name == 'name' and value in default_names):
                    resource_key = 'active.visits.conatcts.' + field_name
                    localized_name = session.get_resource(resource_key)
                    localized_name = (field_name[0].upper() + field_name[1:]) if resource_key == localized_name else localized_name
                    pieces.append(localized_name + ": " + value)
                if field_name == 'id' and self.account.get_setting('crm_url_template'):
                    resource_key = 'active.visits.conatcts.crm_link'
                    localized_name = session.get_resource(resource_key)
                    localized_name = 'CRM link' if resource_key == localized_name else localized_name
                    crm_link = self.account.get_setting('crm_url_template').replace('{id}', value)
                    if crm_link:
                        pieces.append(localized_name + ": " + crm_link)
        return "\n".join(pieces)

    def is_authorized(self):
        return bool(self.provided_fields.get('id'))


class VisitorIcon(wm_utils.InstanceCountTracker):
    SHAPES = ['asterisk', 'check', 'circle', 'drop', 'plus', 'rhombus', 'star', 'square', 'triangle']
    COLORS = ['#0f71e0', '#710fe0', '#d112ee', '#e00f0f', '#f25d0c', '#e5e718', '#25931a']

    def __init__(self, shape=None, color=None):
        super(VisitorIcon, self).__init__()
        if shape:
            self.shape = shape
        else:
            self.shape = random.choice(VisitorIcon.SHAPES)

        if color:
            self.color = color
        else:
            self.color = random.choice(VisitorIcon.COLORS)

            r = self.__extract_color_component_and_update(self.color, 1)
            g = self.__extract_color_component_and_update(self.color, 3)
            b = self.__extract_color_component_and_update(self.color, 5)

            self.color = "#%x%x%x" % (r, g, b)

    def __extract_color_component_and_update(self, color, idx):
        val = int('0x' + color[idx: idx + 2], 0)
        return val + (256 - val) / 3

    def to_dict(self, context=None):
        return {'shape': self.shape, 'color': self.color}


class VisitorActionController:
    def __init__(self, account, session):
        self.account = account
        self.visit_session = session

    def process_ws_action(self, ws_message, params):
        response = self.process_action(params)
        return response

    def get_pending_request_responses(self, pending_requests, visited_page, request_handler):
        result = []

        for request_id in pending_requests.keys():
            data = pending_requests[request_id]
            params = data.get('reqParams')

            params['visited_page'] = visited_page
            params['request_handler'] = request_handler

            result.append({
                'reqId': request_id,
                'reqResult': self.process_ws_action(data, params)
            })

        return result

    def process_action(self, data, event=None):
        event = event or data.get('event')
        visited_page = data.get('visited_page')
        visit_session = self.visit_session
        request_handler = data.get('request_handler')

        if event.startswith('inv.'):
            if event == 'inv.accept':
                args = {
                    'visited_page': visited_page,
                    'first_message_text': None,
                    'department_key': self.get_department_key_arg(data, None),
                    'visitor_message': data.get('message', ''),
                    'message': data.get('inv_message')}
            elif event in ['inv.ainvite', 'inv.by-url-param']:
                args = {'message': data.get('inv_message'), 'avatar': None, 'ainvite_id': data.get('ainvite_id', None)}
            else:
                args = {}
            visit_session.process_event(event, args)

        if event == 'chat.start':
            logging.warn('chat.start ' + str(visit_session.id) + ' ' + str(visited_page.location) + ' ' + str(
                self.get_department_key_arg(data, None)) + ' ' + str(data.get('force-without-department', False)))
            visitor_fields = self.get_visitor_fields(data)
            if visitor_fields:
                visit_session.visitor.update_fields(visitor_fields)

            custom_fields = data.get('custom_fields', None)

            visit_session.process_event('visitor.chat.start', {
                'visited_page': visited_page,
                'first_message_text': data.get('first-question', None),
                'department_key': self.get_department_key_arg(data, None),
                'force_without_department': data.get('force-without-department', False),
                'force_online': data.get('force-online', False),
                'force_start': data.get('force-start', False),
                'custom_fields': custom_fields,
                'mode': data.get('mode', None)
            })

            return {'result': 'ok'}

        if event == 'chat.close':
            visit_session.process_event('visitor.chat.close')

        if event == 'chat.message':
            chat_location_settings = visit_session.account.get_location_settings(visited_page.location).get('chat', {})
            if data.get('message') and len(data.get('message')) > 32000:
                raise ActionProcessingException('max-message-length-exceeded')
            if chat_location_settings.get('chatStartAfterMessage') == 'Y' and not visit_session.chat:
                visit_session.process_event('visitor.chat.start', {
                    'visited_page': visited_page,
                    'first_message_text': data.get('message', ''),
                    'department_key': data.get('department-key', None),
                    'force_without_department': data.get('force-without-department', False),
                    'force_offline': data.get('force-offline', False),
                    'custom_fields': None
                })
            else:
                if not visit_session.chat and visit_session.account.get_setting('force_start_chat_on_visitor_message'):
                    logging.warn(
                        'Starting chat on visitor message @' + visit_session.account.name + ' for session: ' + visit_session.id)
                    visit_session.process_event('visitor.chat.start', {
                        'visited_page': visited_page,
                        'department_key': None,
                        'first_message_text': None,
                        'force_start': True,
                        'force_online': True})

                if not visit_session.chat:
                    raise ActionProcessingException('no-chat')

                aux = data.get('aux', None)
                chat.Message.create(visit_session.chat, chat.Message.Kind.VISITOR, visit_session.visitor.get_name(), data.get('message', ''),
                                    aux=aux, client_side_id=data.get('client-side-id', None))
            try:
                logging.warn('visitor.message '
                             + visit_session.visitor.get_name() + ' '
                             + visit_session.visitor.id + ' '
                             + visit_session.id + ' '
                             + visit_session.chat.session.id + ' '
                             + str(visit_session.chat.id) + ' '

                             )
            except Exception:
                pass

        if event == 'chat.for_operator_message':
            aux = data.get('aux', None)
            chat.Message.create(visit_session.chat, chat.Message.Kind.FOR_OPERATOR, '', data.get('message', ''), aux=aux)

        if event == 'chat.start_upload_file':
            chat.Message.create_from_resource(visit_session.chat, chat.Message.Kind.INFO, None, 'chat.message.file_uploading', True,
                                              **{'visitor_name': visit_session.visitor.get_name()})

        if event == 'chat.upload_file_wrong_size':
            try:
                nginx_upload_size = int(wm_settings.settings['nginx_upload_size'])
            except Exception:
                nginx_upload_size = 10

            max_size = 10
            if self.account.get_setting('max_visitor_upload_file_size'):
                max_size = self.account.get_setting('max_visitor_upload_file_size') if int(
                    self.account.get_setting('max_visitor_upload_file_size')) <= nginx_upload_size else nginx_upload_size

            msg = visit_session.get_resource('chat.error_message.file_uploading_wrong_size', max_size)
            chat.Message.create(visit_session.chat, chat.Message.Kind.INFO, visit_session.visitor.get_name(), msg)

        if event == 'chat.message-part':
            visited_page.visitor_long_message_head_part += data.get('message_part', '')
            if data.get('last_part', False):
                chat.Message.create(visit_session.chat, chat.Message.Kind.VISITOR, visit_session.visitor.get_name(),
                                    visited_page.visitor_long_message_head_part, client_side_id=data.get('client-side-id', None))
                visited_page.visitor_long_message_head_part = ''

        if event == 'chat.read_by_visitor':
            ch = request_handler.get_chat(data=data)
            if ch:
                ch.set_unread_by_visitor_since_ts(None)
            else:
                if visit_session.chat:
                    visit_session.chat.set_unread_by_visitor_since_ts(None)

        if event == 'chat.visitor_typing':
            if visit_session.chat:
                visit_session.chat.set_visitor_typing(visited_page.id if data.get('typing', False) else None)

                message_draft = data.get('message-draft', None)
                if message_draft:
                    visit_session.chat.set_visitor_message_draft(message_draft)
                elif data.get('del-message-draft', False):
                    visit_session.chat.set_visitor_message_draft(None)
        if event == 'chat.identification':
            if data.get('action_type') == 'close':
                chat.Message.create(visit_session.chat, chat.Message.Kind.FOR_OPERATOR, None,
                                    visit_session.get_resource('chat.operator.identification.client_closed_form'))
            else:
                identification_fields = data.get('identification-fields')
                if identification_fields:
                    visit_session.visitor.update_unserved_fields(identification_fields)
                chat.Message.create(visit_session.chat, chat.Message.Kind.FOR_OPERATOR, None,
                                    visit_session.get_resource('chat.operator.identification.information_received'),
                                    data={'subKind': 'identification-received'})
        if event == 'chat.cont_resp':
            visitor_fields = self.get_visitor_fields(data)
            visit_session.visitor.update_fields(visitor_fields)
            chat.Message.create(visit_session.chat, chat.Message.Kind.CONTACTS, None, json.dumps(visitor_fields),
                                client_side_id=data.get('client-side-id', None))

        if event == 'chat.send_chat_history':
            if not self.account.get_setting('show_visitor_send_chat_to_email_button'):
                raise ActionProcessingException('disabled')

            email = data.get('email')  # todo verify
            logging.info('Sending email %s' % email)
            visit_session.chat.send_history_to_visitor(email)

        if event == 'chat.operator_rate_select':
            if not self.account.get_setting('rate_operator'):
                raise ActionProcessingException('rate-disabled')
            elif not visit_session.chat:
                raise ActionProcessingException('no-chat')
            else:
                rate_value = data.get('rate')
                operator_id = data.get('operator_id') or visit_session.chat.get_operator_id()
                if rate_value < -2 or rate_value > 2:
                    raise ActionProcessingException('rate-value-incorrect')
                elif operator_id not in visit_session.chat.operators_in_chat:
                    raise ActionProcessingException('operator-not-in-chat')
                else:
                    rate = chat.OperatorRate(operator_id, visit_session.chat, rate_value)
                    visit_session.chat.operator_id_to_operator_rate[rate.operator_id] = rate
                    logging.info('Operator rated %s\n' % rate_value)
                    visit_session.chat.process_operator_rate(rate)

        if event == 'chat.offline_message':
            if visit_session.visitor.banned:
                raise VisitorBannedError
            if not self.account.get_tariff_setting('offline_message'):
                raise ActionProcessingException('no_tariff_option')

            captcha_fields = data.get('captcha_fields', None)
            if captcha_fields:
                captcha_fields['remoteip'] = visit_session.ip
                check = self.check_captcha(captcha_fields)
                if not check:
                    visit_session.captcha_attempts += 1
                    if visit_session.captcha_attempts >= 10:
                        visit_session.ban_visitor(visit_session.get_resource('operator.captcha_ban'))
                        visit_session.captcha_attempts = 0
                        raise ActionProcessingException('ban')

                    raise ActionProcessingException('wrong captcha')
                else:
                    visit_session.captcha_attempts = 0

            message_client_side_id = data.get('client-message-id', None)
            chat_client_side_id = data.get('client-chat-id', None)
            file_descs = data.get('file-descs-json', None) or data.get('file-descs', None) or []
            ch = request_handler.get_chat(data=data)
            text = data.get('msg_text', None) or data.get('text', None)
            if text and len(text) > 32000:
                raise ActionProcessingException('max-message-length-exceeded')
            context = {'mode': 'visitor.history'}
            if ch:
                if text or file_descs:
                    ch.process_event('visitor.message')
                result = list()
                if text:
                    result.append(chat.Message.create(ch, chat.Message.Kind.VISITOR, ch.session.visitor.get_name(), text,
                                                      client_side_id=message_client_side_id))
                    message_client_side_id = None
                if file_descs:
                    for desc in file_descs:
                        result.append(chat.Message.create(ch, chat.Message.Kind.FILE_VISITOR, ch.session.visitor.get_name(), json.dumps(desc),
                                                          client_side_id=message_client_side_id))
                        message_client_side_id = None

                return None if not result else result[0].to_dict(context) if len(result) == 1 else [m.to_dict(context) for m in result]

            department_key = self.get_department_key_arg(data, None)
            if department_key:
                visit_session.chat_start_params['department_key'] = department_key

            visitor_fields = self.get_visitor_fields(data)
            if visitor_fields:
                visit_session.visitor.update_fields(visitor_fields)
            custom_fields = data.get('custom_fields', None)
            ch = chat.Chat.post_offline_message(visited_page,
                                                text,
                                                custom_fields, file_descs,
                                                data.get('category', None), data.get('subcategory', None),
                                                data.get('subject', None),
                                                chat_client_side_id=chat_client_side_id, message_client_side_id=message_client_side_id)

            # we have to do it here too because offline message can be posted in idle state (in case of pochta for e[ample)
            visit_session.chat_start_params = {}

            visit_session.process_event('visitor.chat.offline_message')
            return ch.to_dict(context)

        if event == 'chat.delete':
            chat_ids = data.get('chat-ids', None)
            if chat_ids:
                for chat_id in chat_ids:
                    ch = request_handler.get_chat(only_offline=False, chat_id=int(chat_id), data=data)
                    ch.delete()
            else:
                ch = request_handler.get_chat(only_offline=False, data=data)
                ch.delete()

        if event == 'init_visitor_number':
            visit_session.process_init_visitor_number_event()

        if event == 'update_visitor_coordinates':
            coordinates = {'latitude': data.get('latitude'), 'longitude': data.get('longitude')}
            visit_session.ip_info.update_coordinates(coordinates)

        if event == 'set_push_token':
            visit_session.set_push_token(data.get('platform'), data.get('push-token'))

        if event == 'chat.form_response':
            text = data.get('text')
            form_data = data.get('data')
            aux = data.get('aux')

            visit_session.chat.set_requested_form_id(None)
            chat.Message.create(visit_session.chat, chat.Message.Kind.FORM_RESPONSE, None, text, visit_session.chat.get_operator_id(), True, aux,
                                form_data)
            wm_timer.invoke_async(lambda: visit_session.chat.create_zendesk_ticket(data=None, form_response=form_data),
                                  'create_zendesk_ticket_from_form_response')

        if event == 'cobrowsing.accept':
            url = visited_page.url
            if visit_session.cobrowsing_session:
                visit_session.cobrowsing_session.on_visitor_accept(url)

        if event == 'cobrowsing.reject':
            visit_session.set_cobrowsing_session_state(CobrowsingSession.State.DISCONNECTED, CobrowsingSession.StateReason.REJECTED_BY_VISITOR)

        if event == 'cobrowsing.stop':
            visit_session.set_cobrowsing_session_state(CobrowsingSession.State.DISCONNECTED, CobrowsingSession.StateReason.CLOSED_BY_VISITOR)

        if event == 'cobrowsing.not_supported':
            visit_session.set_cobrowsing_session_state(CobrowsingSession.State.DISCONNECTED, CobrowsingSession.StateReason.NOT_SUPPORTED)

        if event == 'chat.custom_action_request.buttons':
            client_side_id = data.get('client-side-id', None)
            message = visit_session.chat.get_message_by_client_id(client_side_id) if client_side_id else None
            if message:
                message.update(data_changes={'state': chat.Message.ActionState.COMPLETED, 'result': data.get('result')})

                chat.Message.create(
                    visit_session.chat, chat.Message.Kind.VISITOR,
                    visit_session.visitor.get_name(),
                    wm_resources.get_resource(visit_session.account, visited_page.lang, message.data['params'][data.get('result')]['request'])
                )

                chat.Message.create(
                    visit_session.chat, chat.Message.Kind.OPERATOR,
                    visit_session.chat.get_operator().get_visible_name(visit_session.lang),
                    wm_resources.get_resource(visit_session.account, visited_page.lang, message.data['params'][data.get('result')]['response']),
                    visit_session.chat.get_operator().id
                )

        if event == 'cbh.order':
            if not self.account.get_setting('callback_hunter_enabled'):
                raise ActionProcessingException('callback-hunter-disabled')
            elif not self.account.get_setting('callback_hunter_number'):
                raise ActionProcessingException('hasnt-callback-hunter-number')
            elif not data.get('phone', None):
                raise ActionProcessingException('hasnt-visitor-phone')
            else:
                visitor_phone = re.sub('\D', '', data.get('phone'))
                if len(visitor_phone) == 10:
                    visitor_phone = '7' + visitor_phone
                elif visitor_phone[0] == '8':
                    visitor_phone = '7' + visitor_phone[1:]
                if len(visitor_phone) != 11 or visitor_phone[1] in ['6', '7']:
                    raise ActionProcessingException('incorrect-visitor-phone')
                else:
                    dep_config = {}
                    if visit_session.department_key:
                        department = self.account.get_department(visit_session.department_key)
                        dep_config = department.settings

                    operator_phone = self.account.get_setting('callback_hunter_number')
                    if 'callback_hunter_number' in dep_config and dep_config['callback_hunter_number']:
                        operator_phone = dep_config['callback_hunter_number']

                    caller_phone = self.account.get_setting('public_callback_hunter_number') or operator_phone
                    if 'public_callback_hunter_number' in dep_config and dep_config['public_callback_hunter_number']:
                        caller_phone = dep_config['public_callback_hunter_number']

                    operator_phone = re.sub('\D', '', operator_phone)
                    if operator_phone[0] == '8':
                        operator_phone = '7' + operator_phone[1:]
                    if len(operator_phone) != 11 or operator_phone[1] in ['6', '7']:
                        raise ActionProcessingException('cant-order-callback')

                    caller_phone = re.sub('\D', '', caller_phone)
                    if caller_phone[0] == '8':
                        caller_phone = '7' + caller_phone[1:]
                    if len(caller_phone) != 11:
                        caller_phone = operator_phone

                    callback = Callback(self.account.get_setting('callback_hunter_number'), data.get('phone', ''), visit_session.id, visited_page.url)
                    visit_session.account.background_storager.store(callback, background=False)
                    visit_session.account.background_storager.add_object_to_store(
                        CallbackHistory(callback.uid, CallbackHistory.State.ORDER, 'callback.order'))
                    res = wm_utils.external_request(
                        'http://{0}:{1}@cbh.olebo.ru/cbh-call.php'
                        .format(wm_settings.settings.get('cbh_user', ''), wm_settings.settings.get('cbh_password', '')),
                        {
                            'operator_phone': operator_phone,
                            'visitor_phone': visitor_phone,
                            'caller_phone': caller_phone,
                            'callback_uid': callback.uid,
                            'account': self.account.name
                        }
                    )
                    res = json.loads(res) if res else {}
                    if 'result' in res and res['result'] == 'ok':
                        visit_session.account.background_storager.add_object_to_store(
                            CallbackHistory(callback.uid, CallbackHistory.State.QUEUE, 'callback.queue_call_to_operator'))
                    else:
                        raise ActionProcessingException('cant-order-callback')

        return {"result": "ok"}

    def check_captcha(self, params):
        url = 'http://www.google.com/recaptcha/api/verify'
        params['response'] = params['response'].encode('utf8')
        data = urllib.urlencode(params)
        request = urllib2.Request(url, data)
        response = urllib2.urlopen(request).read().split('\n')
        result = response[0] == 'true'
        return result

    def get_visitor_fields(self, data):
        result = data.get('visitor-fields', None)
        if result is None:
            return None
        for name, value in result.items():
            result[name] = wm_utils.filter_4_byte_characters(value)

        visited_page = data.get('visited_page')
        visit_session = visited_page.visit_session
        if visit_session.platform == 'pochta':
            result['name'] = wm_resources.get_resource(visit_session.account, visited_page.lang, 'chat.default.visitorname')

        return result

    def get_department_key_arg(self, data, default):
        return data.get('department-key', default) if self.account.get_tariff_setting('departments', True) else default


class VisitSession(wm_utils.KeepRefs, wm_utils.Jsonable):
    class Kind:
        ONLINE = 'online'
        OFFLINE_CHAT = 'offline_chat'

        ALL = [ONLINE, OFFLINE_CHAT]

    def __init__(self, account, id, kind, ip, user_agent, platform, push_token, creation_ts, modification_ts,
                 landing_page, visitor, lang_to_geo, hidden, mobile, stored_to_db, app_version=None, push_service=None):
        super(VisitSession, self).__init__()
        self.account = account
        self.id = id
        self.kind = kind

        self.invitation = Invitation()
        self.creation_ts = creation_ts
        self.modification_ts = modification_ts

        self.ip = ip
        self.user_agent = user_agent

        self.platform = platform
        self.push_token = push_token
        self.push_service = push_service

        # self.app_version = self.get_mobile_app_version(self.platform)
        self.app_version = app_version
        # logging.warn('platform, pushToken: ' + str(platform) + ' ' + str(push_token))

        self.landing_page = landing_page
        self.landing_page.set_visit_session(self)

        track_every_visitor_department = account.get_setting('track_every_visitor_department')
        self.lang = landing_page.lang if track_every_visitor_department else ''
        self.department_key = landing_page.department_key if track_every_visitor_department else ''
        self.__landing_info = None

        self.hidden = hidden

        # todo remove mobile param, use platform
        self.mobile = mobile

        self.has_previous_chats = False

        self.visitor = visitor
        visitor.set_session(self)

        self.on_site = OnSite(self)
        self.alive = kind == VisitSession.Kind.ONLINE

        self.ip_info = IPInfo(ip, lang_to_geo, account.get_setting('hide_geo') or self.visitor.channel_type or not ip)

        self.visited_pages = []
        self.alive_pages = []

        self.chat = None
        self.closed_chat = None

        self.prev_chats_count = {'all_chats': 0, 'current_invitations_count': 0, 'current_chats_count': 0}

        self.section = VisitSessionSection.NOT_IN_CHAT
        self.section_for_assigned = VisitSessionSection.NOT_IN_CHAT
        self.order = self.__get_order()

        self.actual_time = None
        self.update_actual_time(produce_delta=False)

        self.stored_to_db = stored_to_db
        self.auth_token = uuid.uuid4().hex

        self.current_polling_period = self.account.settings.get('normal_polling_period')
        self.polling_period_updater = None
        self.visitor_number = None
        self.cobrowsing_session = None
        self.captcha_attempts = 0

        self.lock_for_inf_notification = threading.Lock()

        self.loading = False

        self.action_controller = VisitorActionController(self.account, self)

        if kind == VisitSession.Kind.ONLINE:

            self.data = {}

            self.last_alive_ts = self.modification_ts

            self.delta_manager = VisitorDeltaManager(self)

            self.chat_start_params = {}

        # wm_timer.invoke_async(self.update_prev_chats_count, 'update_prev_chats_count')
        else:
            self.delta_manager = DELTA_MANAGER_STUB

        self.update_polling_period(False)

    @classmethod
    def create(cls, account, ip, user_agent, platform, push_token, landing_page, visitor, geo, mobile, force_hidden=False, app_version=None, push_service=None):
        try:
            user_agent = unicode(user_agent, 'cp1251')
        except Exception:
            pass

        visible_visitors_limit = account.get_setting('visible_visitors_limit')

        cnt = account.visit_tracker.get_alive_not_hidden_sessions_count()
        hidden = force_hidden or cnt >= visible_visitors_limit
        debug_message = 'cnt: ' + str(cnt) + ' limit: ' + str(visible_visitors_limit) + ' hidden: ' + str(hidden)
        if account.name == 'spbtvoetv':
            hidden = hidden or wm_utils.check_if_ip_matches_tvoe_tv_subnet(ip)
        if account.name in ['playbetboxcom', 'scasinovulcanco', '_mixey']:
            hidden = hidden or (not visitor.provided_fields and landing_page.location != 'landing')
            debug_message += ' provided_fields: ' + str(len(visitor.provided_fields)) + ' hidden: ' + str(hidden)

        now = time.time()
        s = VisitSession(
            account,
            cls.__next_id(),
            VisitSession.Kind.ONLINE,
            ip,
            user_agent,
            platform,
            push_token,
            now,
            now,
            landing_page,
            visitor,
            geo,
            hidden,
            mobile,
            False,
            app_version=app_version,
            push_service=push_service
        )

        s.log('created session ' + debug_message)

        return s

    @classmethod
    def create_loaded(cls, account, row, kind):

        data = json.loads(row['json'])

        if 'geo' in data['ipInfo']:
            data['ipInfo']['lang_to_geo'] = {'ru': data['ipInfo']['geo']} if data['ipInfo']['geo'] else {}

        landing_page = VisitedPage.create_from_dict(account, data['landingPage'])
        default_visitor_name = wm_resources.get_resource(account, landing_page.lang, 'chat.default.visitorname')
        visitor = Visitor.create_from_dict(account, data['visitor'], data.get('visitorExt'), default_visitor_name)

        s = VisitSession(
            account,
            row['visitsessionid'],
            kind,
            row['ip'],
            row['useragent'],
            data.get('platform', None),
            data.get('pushToken', None),
            wm_utils.get_ts(row['created']),
            wm_utils.get_ts(row['updated']),
            landing_page,
            visitor,
            data['ipInfo']['lang_to_geo'],
            True,
            data.get('mobile', False),
            True,
            app_version=data.get('appVersion', None),
            push_service=data.get('pushService', None)
        )

        if 'prevChatsCount' in data:
            s.prev_chats_count = data['prevChatsCount']
        s.invitation.state = data['state']

        s.on_site = OnSite.create_from_dict(s, data['onSite'])
        s.on_site._set(False, produce_delta=False)

        if s.visitor.channel_user_id:
            s.add_page(landing_page)
            account.visit_tracker.id_to_visited_page[landing_page.id] = landing_page
            landing_page.ping(10)

        return s

    def create_not_current_copy(self, kind):

        landing_page = copy.copy(self.landing_page)
        visitor = copy.deepcopy(self.visitor)

        s = VisitSession(
            self.account,
            self.__next_id(),
            kind,
            self.ip,
            self.user_agent,
            self.platform,
            self.push_token,
            self.creation_ts,
            time.time(),
            landing_page,
            visitor,
            self.ip_info.get_lang_to_geo(),
            True,
            self.mobile,
            False,
            app_version=self.app_version,
            push_service=self.push_service)

        s.on_site = OnSite.create_from_dict(s, self.on_site.to_dict())
        s.on_site._set(False, produce_delta=False)

        return s

    @classmethod
    def load(cls, connection, account, session_id, kind):
        row = connection.get('select * from chatvisitsession where visitsessionid = %s', session_id)
        return cls.create_loaded(account, row, kind)

    def before_delete(self):
        if self.chat:
            self.chat.process_event('session.delete')
        if self.visitor_number:
            self.account.free_visitor_number(self.visitor_number)
        if not self.hidden:
            # checking  for "not self.hidden" is not necessary (it will work without it), but it is made to do less work
            self.update_related_to_operators(force_del=True)
        if self.push_token:
            push_token_to_session = self.account.visit_tracker.push_token_to_session
            if push_token_to_session.get(self.push_token) is self:
                del push_token_to_session[self.push_token]

    @classmethod
    def __next_id(cls):
        return uuid.uuid4().hex

    def update_in_subsets(self):
        self.account.visit_tracker.update_subsets(self)

    def to_dict(self, include_pages=True, context=None):
        context = context or {}
        mode = context.get('mode')

        result = {'id': self.id,
                  'state': self.invitation.state,
                  'creationTs': self.prepare_ts(self.creation_ts, context),
                  'modificationTs': self.prepare_ts(self.modification_ts, context),
                  'onSite': self.on_site.to_dict(context),
                  'departmentKey': self.department_key,
                  'lang': self.lang,
                  'ip': self.ip,
                  'userAgent': self.user_agent,
                  'ipInfo': self.ip_info.to_dict(context=context),
                  'visitor': self.visitor.to_dict(context=context),
                  'prevChatsCount': self.prev_chats_count,
                  'visitorNumber': self.visitor_number,
                  'mobile': self.mobile}

        if mode == 'db':
            result['landingPage'] = self.landing_page.to_dict(context=context)
            result['platform'] = self.platform
            result['pushToken'] = self.push_token
            result['hasPreviousChats'] = self.has_previous_chats
            result['appVersion'] = self.app_version
            result['pushService'] = self.push_service
        else:
            result['invitationState'] = self.invitation.state  # use state field instead of invitationState in js and remove invitationState field here
            result['alive'] = self.is_alive()
            result['invitationId'] = self.invitation.id
            result['invitation'] = self.invitation.to_dict()
            ch = self.chat or self.closed_chat
            result['chat'] = ch.to_dict(context=context) if ch is not None else None
            result['pushToken'] = self.push_token
            result['pollingPeriod'] = self.current_polling_period
            result['cobrowsingSession'] = self.cobrowsing_session.to_dict() if self.cobrowsing_session else None

            bc = PyBrowscap()
            browser_dict = bc.browser_to_dict(self.user_agent)
            if browser_dict is not None:
                result['browser'] = browser_dict

            result['landingInfo'] = self.get_site_landing_info().to_dict(include_session=False)
            if include_pages:
                result['pages'] = [p.to_dict(context=context) for p in self.get_alive_pages()]

            if context.get('operator_id') and context.get('operator_id') == self.__get_assigned_operator_id():
                result['sectionKey'] = self.section_for_assigned
            else:
                result['sectionKey'] = self.section
            result['order'] = self.order

            result['actualTime'] = self.actual_time.to_dict(context=context) if self.actual_time else None

        if mode == 'operator':
            shown_department_name = ''
            if self.department_key:
                d = self.account.get_department(self.department_key, include_deleted=True)
                shown_department_name = d.get_shown_department_name(context)

            result['shownDepartmentName'] = shown_department_name

        return result

    def to_json(self, context=None, indent=None):
        try:
            return wm_utils.Jsonable.to_json(self, context=context, indent=1 if context and context.get('mode') == 'db' else None)
        except Exception:
            dicted = self.to_dict(context=context)
            self.__fill_with_stub(dicted)
            return json.dumps(dicted)

    def store(self, only_if_stored_before=True):
        if self.loading:
            return

        self.modification_ts = time.time()
        if self.stored_to_db or not only_if_stored_before:
            self.account.background_storager.store(self)

    def set_data(self, key, value):
        self.data[key] = value

    def get_data(self, key, default=None):
        return self.get_data(key, default)

    def set_push_token(self, platform, push_token):
        platform = platform or self.platform

        # Some mobile apps send push_token == "none" to stop receiving push notifications
        if push_token == "none":
            push_token = None

        if self.platform == platform and self.push_token == push_token:
            return

        if self.push_token is not None and self is self.account.visit_tracker.push_token_to_session.get(self.push_token):
            self.account.visit_tracker.push_token_to_session.pop(self.push_token, None)

        self.platform = platform
        self.push_token = push_token
        self.register_by_push_token_and_invalidate_in_other(push_token)

        self.store()
        logging.warn('session push-token updated ' + str(platform) + ' ' + str(push_token) + ' ' + str(self.id))

    def update_polling_period(self, produce_delta=True):
        polling_settings = self.account.settings.get('smart_polling_period_settings')
        if self.account.settings.get('smart_polling_period_logic') and polling_settings:
            if self.polling_period_updater:
                self.polling_period_updater.cancel()
                self.polling_period_updater = None
            if self.chat:
                last_message = self.chat.get_last_important_message()
                last_modification_time_diff = time.time() - max([last_message.ts if last_message else 0, self.chat.modification_ts])
                for polling_interval_setting in polling_settings:
                    if last_modification_time_diff < polling_interval_setting['int']:
                        self.set_polling_period_according_to_polling_setting(polling_interval_setting, last_message, produce_delta)
                        self.update_polling_period_timer(polling_interval_setting['int'] - last_modification_time_diff)
                        return

                self.set_polling_period(self.account.settings.get('normal_polling_period'), produce_delta)
            else:
                self.set_polling_period(self.account.settings.get('normal_polling_period'), produce_delta)
        else:
            if self.chat:
                self.set_polling_period(self.account.settings.get('in_chat_polling_period'), produce_delta)
            else:
                self.set_polling_period(self.account.settings.get('normal_polling_period'), produce_delta)

    def update_polling_period_timer(self, period):
        self.polling_period_updater = wm_timer.add_timer(period, lambda: self.update_polling_period(produce_delta=True),
                                                         str(self.id) + " polling_period_updater")

    def set_polling_period_according_to_polling_setting(self, setting, last_message, produce_delta):
        hot = last_message.kind in chat.Message.Kind.VISITOR_KINDS if last_message else False
        self.set_polling_period(setting['hot'] if hot else setting['cold'], produce_delta)

    def set_polling_period(self, value, produce_delta):
        if value != self.current_polling_period:
            self.current_polling_period = value
            if produce_delta:
                d = Delta('POLLING_PERIOD', Delta.Event.UPDATE, self.id, self.current_polling_period)
                self.delta_manager.add_delta(d)

    def set_cobrowsing_session_state(self, state, reason=None, produce_delta=True):
        if self.cobrowsing_session:
            self.cobrowsing_session.set_state(state, reason, produce_delta)
            if self.chat:
                chat.Message.create_from_resource(
                    self.chat,
                    chat.Message.Kind.INFO if reason != CobrowsingSession.StateReason.NOT_SUPPORTED else chat.Message.Kind.FOR_OPERATOR,
                    None, 'cobrowsing.chat.%s' % (reason or state), produce_delta
                )

    def set_cobrowsing_session(self, session):
        if self.cobrowsing_session != session:
            self.cobrowsing_session = session
            self.add_operator_delta(Delta("COBROWSING_SESSION", Delta.Event.UPDATE, self.id, self.cobrowsing_session))
            self.delta_manager.add_delta(Delta("COBROWSING_SESSION", Delta.Event.UPDATE, self.id, self.cobrowsing_session))
            if self.chat:
                chat.Message.create_from_resource(self.chat, chat.Message.Kind.INFO, None, 'cobrowsing.chat.%s' % self.cobrowsing_session.state, True)

    def get_browser_str(self):
        bc = PyBrowscap()
        browser = bc(self.user_agent)
        browser_str = ''
        if browser:
            known_browser_version = False
            if browser['user_agent']['major'] and int(browser['user_agent']['major']) != 0:
                known_browser_version = True
            browser_version_str = ' ' + str(browser['user_agent']['major']) if known_browser_version else ''
            browser_str = browser['user_agent']['family'] + browser_version_str
        return browser_str

    def get_platform_str(self):
        bc = PyBrowscap()
        browser = bc(self.user_agent)
        platform_str = ''
        if browser:
            platform_str = browser['os']['family']
        return platform_str

    # def get_mobile_app_version(self, platform):
    #     return self.account.get_mobile_app_version(platform, self.user_agent)

    def get_resource(self, key, *args, **kwargs):
        return wm_resources.get_resource(self.account, self.lang, key, *args, **kwargs)

    def __fill_with_stub(self, dicted):
        for k, v in dicted.items():
            if k == 'id' or k == 'invitationState':
                continue
            if type(v) == str or type(v) == unicode:
                dicted[k] = '--'
            if type(v) == dict:
                self.__fill_with_stub(v)

    def add_page(self, page):
        self.visited_pages.append(page)
        page.set_visit_session(self)
        if self.chat and self.platform == 'web':
            msg = self.get_resource('chat.message.visited_page', *[page.title, page.url])
            chat.Message.create(self.chat, chat.Message.Kind.FOR_OPERATOR, None, msg)
        self.account.event_dispatcher.fire(Event(e_type=Event.Type.NEW_VISITED_PAGE, e_object=self))

    def on_page_alive_state_changed(self, visited_page, alive):
        if alive:
            self.alive_pages.append(visited_page)
            if self.account.get_setting('track_every_visitor_department'):
                if not self.chat:
                    self.set_department(visited_page.department_key, visited_page.lang)
        else:
            if visited_page in self.alive_pages:
                self.alive_pages.remove(visited_page)

        self.log('alive_pages ' + str(len(self.alive_pages)))
        if len(self.alive_pages):
            self.on_site.set_true()
        else:
            self.on_site.delayed_set_false()

    def get_alive_pages(self):
        return self.alive_pages

    def is_alive(self):
        return self.alive

    def send_delta_on_browscap_parsing_finished(self):
        bc = PyBrowscap()
        browser_data = bc.browser_to_dict(self.user_agent)
        if browser_data:
            self.add_operator_delta(Delta("USER_AGENT", Delta.Event.UPDATE, self.id, browser_data))

    def update_alive(self, produce_delta=True):
        alive = (
            self.on_site.get()
            or self.chat is not None and self.chat.state != chat.Chat.State.CLOSED
            or self.closed_chat is not None
        )

        if self.alive != alive:
            self.alive = alive
            self.log('alive ' + str(alive))
            self.last_alive_ts = None if alive else time.time()
            self.update_in_subsets()
            if not alive:
                if self.cobrowsing_session:
                    self.set_cobrowsing_session_state(
                        CobrowsingSession.State.DISCONNECTED,
                        CobrowsingSession.StateReason.CLOSED_BY_VISITOR,
                        produce_delta=False)

                self.account.event_dispatcher.fire(Event(e_type=Event.Type.VISITOR_LEFT, e_object=self))

            if produce_delta and not self.hidden:
                # checking  for "not self.hidden" is not necessary (it will work without it), but it is made to do less work
                self.update_related_to_operators()
            self.store()

    # todo remove
    def set_not_hidden(self, produce_delta=True):
        self.set_hidden(False, produce_delta=produce_delta)

    def set_hidden(self, value, produce_delta=True):
        if self.hidden == value:
            return
        self.hidden = value
        self.log('set_hidden ' + str(value))
        self.update_in_subsets()
        if produce_delta:
            self.update_related_to_operators()

    def set_department(self, department_key, lang, produce_delta=True):
        department_key = department_key if self.account.get_tariff_setting('departments', True) else ''
        department_key = department_key if department_key else ''

        dep = self.account.get_department(department_key)
        department_key = department_key if dep else ''

        if self.department_key == department_key and self.lang == lang:
            return

        self.department_key = department_key
        self.lang = lang
        self.visitor.update_name_according_to_lang(produce_delta=produce_delta)

        if self.chat:
            self.account.queue_manager.update_chat_in_queue(self.chat)

        self.log('set_department')

        if produce_delta:
            self.update_related_to_operators()
            dep = self.account.get_department(department_key)
            self.add_operator_delta(Delta('DEPARTMENT', 'upd', self.id, DepartmentDelta(dep, lang)))
        self.store()

    def get_site_landing_info(self):
        if self.__landing_info is None:
            search = SearchEngineParser().get_search(self.landing_page.referer) if self.landing_page.referer is not None else None
            self.__landing_info = SiteLandingInfo(self.landing_page, search)

        return self.__landing_info

    def set_chat(self, ch, produce_delta=True, reset_closed_chat=False, stay_hidden=False):

        old_chat = self.chat or self.closed_chat

        if reset_closed_chat:
            self.closed_chat = None
        else:
            if self.chat == ch:
                return

            remember_closed_chat = self.account.get_setting('shown_closed_chats_limit') and self.chat and not self.chat.offline and ch is None
            self.closed_chat = self.chat if remember_closed_chat else None

            self.chat = ch

        new_chat = self.chat or self.closed_chat

        self.update_in_subsets()

        if produce_delta:
            if not reset_closed_chat:
                self.delta_manager.add_delta(Delta('CHAT', Delta.Event.UPDATE, self.id, ch))
            if new_chat != old_chat:
                self.add_operator_delta(Delta('CHAT', Delta.Event.ADD if new_chat else Delta.Event.DELETE, self.id, new_chat))

        self.log('set_chat ' + str(bool(ch)))
        if (ch and (ch.get_operator_id() and ch.state != chat.Chat.State.CLOSED_BY_OPERATOR
                    or not self.account.visit_tracker.is_visible_chats_limit_reached(ch.offline))
           and not stay_hidden):
            self.set_not_hidden(produce_delta)
        self.update_polling_period(produce_delta)
        self.update_alive(produce_delta)
        self.update_section_and_order(produce_delta)
        self.update_actual_time(produce_delta)

        if ch:
            self.chat.on_set_to_session()
        else:
            wm_timer.invoke_async(self.account.visit_tracker.unhide_chats_up_to_limit, 'unhide_chats_up_to_limit')

    def set_previous_chats_to_true(self, prev_chat_creation_ts, offline, produce_delta=True):
        self.has_previous_chats = True  # for current session

        self.visitor.update_visitor_previous_chat_tag(prev_chat_creation_ts, produce_delta=produce_delta)

        if offline:
            original_session = self.account.visit_tracker.get_session_by_visitor_id(self.visitor.id)
            if original_session:
                original_session.set_previous_chats_to_true(prev_chat_creation_ts, False, produce_delta=produce_delta)

    def create_and_set_chat(self, visited_page, first_message_text, custom_fields, client_side_id=None):
        ch = chat.Chat.create(self, visited_page, custom_fields=custom_fields, client_side_id=client_side_id)

        if self.invitation.message:
            msg = self.get_resource('chat.message.invitation', *[self.invitation.message])
            chat.Message.create(ch, chat.Message.Kind.FOR_OPERATOR, None, msg, produce_delta=False)
        if first_message_text:
            chat.Message.create(ch, chat.Message.Kind.VISITOR, self.visitor.get_name(), first_message_text, produce_delta=False)

        wm_timer.invoke_async(self.check_chats_count_limit_from_one_ip, 'check_chats_count_limit_from_one_ip')

        self.set_chat(ch)

    def check_chats_count_limit_from_one_ip(self):
        c = db_utils.get_connection()
        row = c.get('select count(distinct  accountname) cnt from chat where ip = %s and created >= now() - interval 1 day', self.ip)
        cnt = row['cnt']
        if cnt >= 4 and self.ip != '91.209.128.154':  # Rentgena
            wm_mail.mailer.send_too_many_chats_from_one_ip_notification(self.account, {'cnt': cnt, 'ip': self.ip})
        c.close()

    def inc_session_chats_count(self, param):
        self.prev_chats_count[param] += 1
        self.add_operator_delta(Delta("PREV_CHATS_COUNT", Delta.Event.UPDATE, self.id, self.prev_chats_count))

    def set_prev_chats_count(self, value):
        if self.prev_chats_count['all_chats'] == value:
            return
        self.prev_chats_count['all_chats'] = value
        self.add_operator_delta(Delta("PREV_CHATS_COUNT", Delta.Event.UPDATE, self.id, self.prev_chats_count))

    def update_prev_chats_count(self):
        cnt = chat.Chat.get_previous_chats_count(self.account.name, self.visitor.id)
        self.set_prev_chats_count(cnt)

    def process_event(self, event, args=None):
        args = args or {}
        old_state = self.invitation.state
        new_state = self.invitation.state

        logging.warn('process_event ' + str(self.id) + ' ' + str(event))

        if old_state in [Invitation.STATE_IDLE, Invitation.STATE_IDLE_AFTER_CHAT]:
            if event == 'visitor.chat.start':
                new_state = self.process_visitor_chat_start_event(old_state, args)
            elif event == 'operator.chat.start':
                new_state = self.process_operator_chat_start_event(old_state, args)
            elif event == 'invitation-created':
                new_state = Invitation.STATE_SHOWING
            elif event == 'inv.ainvite':
                new_state = Invitation.STATE_SHOWING_AUTO
            elif event == 'inv.by-url-param':
                new_state = Invitation.STATE_SHOWING_BY_URL_PARAM
            elif event == 'inv.accept':  # in case when visitor_tracking turned off
                self.invitation.message = args.get('message', None)
                new_state = self.process_visitor_chat_start_event(old_state, args)
                if new_state == Invitation.STATE_FIRST_QUESTION or new_state == Invitation.STATE_DEPARTMENT_SELECTION:
                    args['message'] = self.invitation.message
                    # this huck is made to keep inv. message while first question is being entered and post it to the chat when it's submitted

        elif old_state == Invitation.STATE_SHOWING:
            if event == 'chat-opened':
                new_state = Invitation.STATE_CHAT
            elif event == 'inv.accept':
                ch = chat.Chat.create(self, args['visited_page'], offline=False, state=chat.Chat.State.CHATTING,
                                      operator_id=self.invitation.operator_id)
                msg = self.get_resource('chat.message.invitation', *[self.invitation.message])
                chat.Message.create(ch, chat.Message.Kind.INFO, None, msg, produce_delta=False)
                chat.Message.create(ch, chat.Message.Kind.VISITOR, self.visitor.get_name(), args['visitor_message'], produce_delta=False)
                self.set_chat(ch)
                new_state = Invitation.STATE_CHAT
            elif event == 'inv.reject' or event == 'inv.timeout':
                new_state = Invitation.STATE_IDLE

        elif old_state in [Invitation.STATE_SHOWING_AUTO, Invitation.STATE_SHOWING_BY_URL_PARAM]:
            if event == 'chat-opened':
                new_state = Invitation.STATE_CHAT
            elif event == 'invitation-created':
                new_state = Invitation.STATE_SHOWING
            elif event == 'inv.accept' or event == 'visitor.chat.start':
                new_state = self.process_visitor_chat_start_event(old_state, args)
                if new_state == Invitation.STATE_FIRST_QUESTION or new_state == Invitation.STATE_DEPARTMENT_SELECTION:
                    args['message'] = self.invitation.message
                    # this huck is made to keep inv. message while first question is being entered and post it to the chat when it's submitted
            elif event == 'inv.reject' or event == 'inv.timeout':
                new_state = Invitation.STATE_IDLE
            elif event == 'inv.by-url-param':
                new_state = Invitation.STATE_SHOWING_BY_URL_PARAM
            elif event == 'operator.chat.start':
                new_state = self.process_operator_chat_start_event(old_state, args)

        elif old_state == Invitation.STATE_FIRST_QUESTION or old_state == Invitation.STATE_DEPARTMENT_SELECTION:
            if event == 'visitor.chat.close':
                new_state = Invitation.STATE_IDLE_AFTER_CHAT
            elif event == 'visitor.chat.start':
                new_state = self.process_visitor_chat_start_event(old_state, args)
            elif event == 'operator.chat.start':
                raise EventProcessingException('visitor_starting_chat_from_his_side')

        elif old_state == Invitation.STATE_OFFLINE_MESSAGE:
            if event == 'visitor.chat.close':
                new_state = Invitation.STATE_IDLE
            elif event == 'visitor.chat.offline_message':
                new_state = Invitation.STATE_IDLE
            elif event == 'operator.chat.start':
                raise EventProcessingException('visitor_starting_chat_from_his_side')
            elif event == 'visitor.chat.start':  # На случай если кто-то открыл offline-форму, после чего попытался открыть чат с force-online=true
                new_state = self.process_visitor_chat_start_event(old_state, args)

        elif old_state == Invitation.STATE_CALLBACK_HUNTER:
            if event == 'visitor.chat.start':
                new_state = self.process_visitor_chat_start_event(old_state, args)
            elif event == 'visitor.chat.close':
                new_state = Invitation.STATE_IDLE

        elif old_state == Invitation.STATE_CHAT:
            if event == 'visitor.chat.start':
                self.chat.process_event('visitor.start')
            elif event == 'visitor.chat.close':
                if self.account.get_setting('visitor_can_close_chat'):
                    self.chat.process_event('visitor.close')
            elif event == 'chat-closed':
                new_state = Invitation.STATE_IDLE_AFTER_CHAT

        elif old_state == Invitation.STATE_CHAT_SHOWING:
            if event == 'visitor.chat.start':
                new_state = self.process_visitor_chat_start_event(old_state, args)
            elif event == 'visitor.chat.close':
                new_state = Invitation.STATE_IDLE
            elif event == 'operator.chat.start':
                new_state = self.process_operator_chat_start_event(old_state, args)

        if new_state != old_state:
            self.invitation.state = new_state

            if new_state == Invitation.STATE_IDLE_AFTER_CHAT or new_state == Invitation.STATE_IDLE:
                self.chat_start_params = {}
                logging.warn('chat_start_params ' + str(self.id) + ' empty')

            self.invitation.message = args.get('message', None)
            self.invitation.avatar = args.get('avatar', None)
            self.invitation.operator_id = args.get('operator_id', None)
            self.invitation.ainvite_id = args.get('ainvite_id', None)

            delta_list = []
            if new_state in Invitation.STATE_GROUP_SHOWING:
                delta_list.append(Delta("INVITATION", Delta.Event.UPDATE, self.id, self.invitation))
            delta_list.append(Delta("VISIT_SESSION_STATE", Delta.Event.UPDATE, self.id, new_state))
            self.delta_manager.add_delta(delta_list)
            self.add_operator_delta(delta_list)

            self.store()

    def process_operator_chat_start_event(self, old_state, args):
        operator = self.account.get_operator(args['operator_id'])

        if not self.account.get_setting('invite_visitors_from_other_departments'):
            for p in self.get_alive_pages():
                if operator.matches((p.lang, p.department_key)):
                    break
            else:
                raise EventProcessingException('operator_cant_start_chat_with_visitor_from_another_department')

        if not self.lang:
            langs = operator.locales
            self.set_department(self.department_key, 'ru' if 'ru' in langs else 'en' if 'en' in langs else iter(langs).next())

        alive_pages = self.get_alive_pages()

        ch = chat.Chat.create(self, alive_pages[-1] if alive_pages else None, state=chat.Chat.State.INVITATION, operator_id=args['operator_id'])
        self.set_chat(ch, produce_delta=True)
        return Invitation.STATE_CHAT

    def process_visitor_chat_start_event(self, old_state, args):
        if self.visitor.banned:
            raise VisitorBannedError

        if args['department_key']:
            self.chat_start_params['department_key'] = args['department_key']
            logging.warn('chat_start_params 800 ' + str(self.id) + ' ' + str(self.chat_start_params))
        if args.get('force_without_department', False):
            self.chat_start_params['force_without_department'] = True
            logging.warn('chat_start_params 803 ' + str(self.id) + ' ' + str(self.chat_start_params))
        if args['first_message_text']:
            self.chat_start_params['first_message_text'] = args['first_message_text']
            logging.warn('chat_start_params 806 ' + str(self.id) + ' ' + str(self.chat_start_params))
        if args.get('visitor_message'):
            self.chat_start_params['visitor_message_from_invitation'] = args.get('visitor_message')  # auto invitation case
        if args.get('force_offline', False):
            self.chat_start_params['force_offline'] = True
        if args.get('force_start', False):
            self.chat_start_params['force_start'] = True
        if args.get('mode', 'chat') in ['callback-hunter', 'offline', 'chat']:
            self.chat_start_params['mode'] = args.get('mode', 'chat')

        visited_page = args['visited_page']
        location_settings = self.account.get_location_settings(visited_page.location)
        chat_location_settings = location_settings.get('chat', {})

        department_selected = ('department_key' in self.chat_start_params
                               or self.chat_start_params.get('force_without_department', False)
                               or args.get('force_start', False))

        if chat_location_settings.get('chooseDepartment') == 'Y' and self.account.get_tariff_setting('departments', True) and not department_selected:
            departments = Department.get_departments_with_online_status_dict(visited_page, {})
            if len(departments):
                self.delta_manager.add_delta(Delta('DEPARTMENT_LIST', Delta.Event.UPDATE, self.id, departments))
                return Invitation.STATE_DEPARTMENT_SELECTION
        if chat_location_settings.get('chooseDepartment') == 'geo' and self.account.get_tariff_setting('departments',
                                                                                                       True) and not department_selected:
            departments = Department.get_departments_with_online_status_dict(visited_page, self.ip_info.get_lang_to_geo())
            if len(departments) == 0:
                self.chat_start_params['department_key'] = visited_page.department_key
                logging.warn('chat_start_params 821 ' + str(self.id) + ' ' + str(self.chat_start_params))
            elif len(departments) == 1:
                self.chat_start_params['department_key'] = departments[0]['key']
                logging.warn('chat_start_params 824 ' + str(self.id) + ' ' + str(self.chat_start_params))
            else:
                if visited_page.department_key in [d['key'] for d in departments]:
                    self.chat_start_params['department_key'] = visited_page.department_key
                    logging.warn('chat_start_params 828 ' + str(self.id) + ' ' + str(self.chat_start_params))
                else:
                    self.delta_manager.add_delta(Delta('DEPARTMENT_LIST', Delta.Event.UPDATE, self.id, departments))
                    return Invitation.STATE_DEPARTMENT_SELECTION

        department_key = ('' if self.chat_start_params.get('force_without_department', False) else
                          self.chat_start_params['department_key'] if 'department_key' in self.chat_start_params else
                          visited_page.department_key)

        department_key = department_key if self.account.get_department(department_key) else ''

        if self.chat_start_params.get('mode', 'chat') == 'callback-hunter':
            return Invitation.STATE_CALLBACK_HUNTER

        if args.get('force_online', False):
            online_status = OnlineState.ONLINE
        else:
            online_status = self.account.oo_manager.get_online_state(visited_page.lang, department_key)

        if 'first_message_text' in self.chat_start_params and self.account.oo_manager.has_online_operators(visited_page.lang, department_key):
            # хак, чтобы посетитель мог начать чат, если он уже ввел первый вопрос, а после этого очередь переполнилась, но операторы в олайне есть
            online_status = OnlineState.ONLINE

        if online_status in [OnlineState.OFFLINE] or self.chat_start_params.get('force_offline', False):
            button_location_settings = location_settings.get('button', {})
            if button_location_settings.get('offlineEnabled', 'Y') == 'N' or not self.account.tariff_settings.get('offline_message'):
                raise ActionProcessingException('no_operators_online_and_offline_enabled_false')
            return Invitation.STATE_OFFLINE_MESSAGE

        if self.account.name == 'playbetboxcom' or self.account.name == 'mixey':
            if self.landing_page.location == 'landing':
                filter_func = lambda s: s.kind == VisitSession.Kind.ONLINE and s.landing_page.location == 'landing' and s.chat
                online_sessions_count = self.account.visit_tracker.get_sessions_count(filter_func=filter_func)

                chats_count_limit = 50
                if online_sessions_count >= chats_count_limit:
                    wm_mail.mailer.send_short_message_notification(self.account, 'too_many_chats: >= %d' % chats_count_limit)
                    raise ActionProcessingException('chat_count_limit_exceeded')

        if online_status in [OnlineState.BUSY_OFFLINE, OnlineState.BUSY_ONLINE]:
            raise ActionProcessingException('chat_count_limit_exceeded')

        if chat_location_settings.get('chatEnterFirstMessage') == 'Y' and 'first_message_text' not in self.chat_start_params and not args.get('force_start', False):  # noqa: E501
            if not (self.account.name == 'abscityru' and self.chat_start_params.get('visitor_message_from_invitation')):  # WEBIMADMIN-645 hardcode
                return Invitation.STATE_FIRST_QUESTION

        if (chat_location_settings.get('chatStartAfterMessage') == 'Y'
           and 'first_message_text' not in self.chat_start_params
           and 'force_start' not in self.chat_start_params):
            return Invitation.STATE_CHAT_SHOWING

        self.set_department(department_key, visited_page.lang)
        first_message_text = self.chat_start_params.get('first_message_text')
        first_message_text = first_message_text if first_message_text else self.chat_start_params.get('visitor_message_from_invitation')
        if not self.chat:
            self.create_and_set_chat(visited_page, first_message_text, args.get('custom_fields'), client_side_id=args.get('client_side_id'))
        return Invitation.STATE_CHAT

    def process_init_visitor_number_event(self):
        if not self.visitor_number:
            self.visitor_number = self.account.alloc_visitor_number()
            self.set_not_hidden()
            d = Delta('VISIT_SESSION_NUMBER', Delta.Event.UPDATE, self.id, self.visitor_number)
            self.delta_manager.add_delta(d)
            self.add_operator_delta(d)

    def get_section_for_operator(self, operator_id):
        return self.section_for_assigned if operator_id == self.__get_assigned_operator_id() else self.section

    def update_section_and_order(self, produce_delta=True, force_delta=False):
        order = self.__get_order()
        section = self.__get_section(False)
        section_for_assigned = self.__get_section(True)

        assigned_operator_id = self.__get_assigned_operator_id()

        if self.section != section or self.order != order or force_delta:
            self.section = section
            if produce_delta:
                d = [Delta('VISIT_SESSION_SECTION_KEY', 'upd', self.id, section),
                     Delta('VISIT_SESSION_SECTION_AND_ORDER', 'upd', self.id, {'sectionKey': section, 'order': order})]
                self.add_operator_delta(d, skip_operator_ids=[assigned_operator_id] if assigned_operator_id else None)
                self.update_related_to_operators()

        if self.section_for_assigned != section_for_assigned or self.order != order or force_delta:
            self.section_for_assigned = section_for_assigned
            if assigned_operator_id and produce_delta and not self.hidden and self.alive:
                self.update_related_to_operators()
                if self.account.oo_manager.get(assigned_operator_id).is_session_related(self.id):
                    d = [Delta('VISIT_SESSION_SECTION_KEY', 'upd', self.id, section_for_assigned),
                         Delta('VISIT_SESSION_SECTION_AND_ORDER', 'upd', self.id, {'sectionKey': section_for_assigned, 'order': order})]
                    self.account.oo_manager.get(assigned_operator_id).delta_manager.add_delta(d)

        self.order = order

    def __get_assigned_operator_id(self):
        assigned_operator_id = self.chat.get_operator_id() if self.chat else None
        return assigned_operator_id

    def __get_order(self):
        if self.chat:
            if self.account.get_setting('order_chats_by_unread_by_operator_since_ts') and self.chat.get_operator_id():
                if self.chat.state == chat.Chat.State.QUEUE:
                    return self.chat.modification_ts
                elif self.chat.state == chat.Chat.State.CHATTING:
                    if self.chat.unread_by_operator_since_ts:
                        return self.chat.unread_by_operator_since_ts
                    else:
                        last_human_message = self.chat.get_last_human_message()
                        if last_human_message:
                            return 9000000000 - last_human_message.ts
            return 13000000000 - self.chat.creation_ts
        else:
            return 17000000000 - self.creation_ts

    def __get_section(self, for_assigned_operator):
        auto_assign = self.account.get_setting('auto_assign')
        ch = self.chat
        State = chat.Chat.State  # noqa : N806
        Section = VisitSessionSection # noqa : N806

        if self.account.name in ['playbetboxcom', 'scasinovulcanco', '_mixey']:
            if for_assigned_operator and ch and ch.state == State.INVITATION:
                return Section.IN_CHAT

        return (
            Section.CLOSED_BY_OPERATOR if ch and ch.state == State.CLOSED_BY_OPERATOR and self.account.get_setting('show_closed_by_operator_chats') and for_assigned_operator else  # noqa: E501
            Section.CLOSED_CHATS if (self.closed_chat or ch and ch.state in [State.CLOSED_BY_OPERATOR]) and self.account.get_setting('shown_closed_chats_limit') else  # noqa: E501
            Section.NOT_IN_CHAT if not ch or ch.state in [State.ROUTING, State.CLOSED, State.CLOSED_BY_OPERATOR, State.INVITATION] else
            Section.COMMON_QUEUE if ch.state == State.QUEUE and not ch.get_operator_id() and auto_assign else
            Section.QUEUE if not auto_assign and ch.state == State.QUEUE and not ch.get_operator_id() or (ch.state == State.QUEUE or ch.state == State.OFFLINE_QUEUE) and for_assigned_operator else  # noqa: E501
            Section.OFFLINE_QUEUE if ch.state == State.OFFLINE_QUEUE and (not auto_assign or not ch.get_operator_id()) else
            Section.IN_CHAT if for_assigned_operator else
            Section.IN_CHAT_WITH_OTHERS
        )

    def update_actual_time(self, produce_delta=True):
        actual_time = None

        if self.chat:
            if self.chat.offline:
                pass
            elif self.chat.state == chat.Chat.State.QUEUE:
                actual_time = ActualTime(self.chat.modification_ts, 'page.visit.waiting_time', '#ff0000', '#ffffff')
            elif self.chat.unread_by_operator_since_ts:
                actual_time = ActualTime(self.chat.unread_by_operator_since_ts, 'page.visit.waiting_time', '#ff0000', '#ffffff')
        else:
            if self.on_site.get_last_come_back_ts():
                actual_time = ActualTime(self.on_site.get_last_come_back_ts() - self.on_site.get_cumulated_on_site_time(),
                                         'page.visit.time_on_site', None, '#000000')

        if self.actual_time != actual_time:
            self.actual_time = actual_time
            if produce_delta:
                d = Delta('VISIT_SESSION_ACTUAL_TIME', 'upd', self.id, actual_time)
                self.add_operator_delta(d)

    def update_related_to_operators(self, force_del=False):
        self.account.oo_manager.update_session_related(self, force_del=force_del)

    def add_operator_delta(self, delta, min_timeout=0, notify_waiters=True, skip_operator_ids=None, even_if_not_alive=False, even_if_hidden=False):
        if (not self.hidden or even_if_hidden) and (self.alive or even_if_not_alive):
            self.account.oo_manager.add_delta(delta, self.id, min_timeout, notify_waiters, skip_operator_ids=skip_operator_ids)

    def ban_visitor(self, ban_message, chat_id=None, operator_name=None):
        a = self.account
        self.account.event_dispatcher.fire(Event(e_type=Event.Type.VISITOR_BANNED, e_object=self))
        self.visitor.set_banned_status(True)
        ban_record = BanRecord(self.ip, time.time() + 7 * 24 * 60 * 60, ban_message,
                               push_token=self.push_token,
                               stored_to_db_callback=lambda: a.reset_cached_ban_records(),
                               chat_id=chat_id,
                               operator_name=operator_name,
                               channel_user_id=self.visitor.channel_user_id,
                               channel_id=self.visitor.channel_id
                               )
        a.background_storager.add_object_to_store(ban_record)

    def log(self, msg):
        if self.account.name != '':
            return
        text = 'Session ' + self.id
        text += ' pvid= ' + (self.visitor.provided_fields and self.visitor.provided_fields.get('id') or '')
        text += ' dep=(' + self.department_key + ',' + self.lang + ')'
        text += ' loc=' + (self.landing_page.location or '')
        logging.warn(text + ' ' + msg)

    def register_by_push_token_and_invalidate_in_other(self, push_token):
        """Регистрирует online-сессию в `visit_tracker.push_token_to_session` по `push_token`
        И устаналивает `push_token` на None в предыдущей сессии по этому пуш-токену.

        """

        # BUGZTASKS-4159: Убираем пуш-токен в другой сессии с таким же пуш-токеном
        # Это можно было бы делать через /ws/v/action с параметром "event": "set-push-token".
        # Но в некоторых случаях это может не сработать.

        if self.kind != VisitSession.Kind.ONLINE or push_token is None:
            return

        session = self.account.visit_tracker.push_token_to_session.get(push_token)
        if session and session is not self and session.push_token == push_token:
            session.set_push_token(session.platform, None)
        # Теперь единственная сессия с этим пуш-токеном - текущая
        self.account.visit_tracker.push_token_to_session[push_token] = self


class OnSite(wm_utils.Jsonable):
    def __init__(self, session, value=True, cumulated_on_site_time=0, last_come_back_ts='now', last_gone_away_ts=None):
        self.__session = session
        self.__value = value
        self.__cumulated_on_site_time = cumulated_on_site_time
        self.__last_come_back_ts = time.time() if last_come_back_ts == 'now' else last_come_back_ts
        self.__last_gone_away_ts = last_gone_away_ts
        self.__timer = None

    def get(self):
        return self.__value

    def get_last_gone_away_ts(self):
        return self.__last_gone_away_ts

    def get_last_come_back_ts(self):
        return self.__last_come_back_ts

    def get_cumulated_on_site_time(self):
        return self.__cumulated_on_site_time

    def to_dict(self, context=None):
        return {
            'value': self.__value,
            'cumulatedOnSiteTime': self.__cumulated_on_site_time,
            'lastComeBackTs': self.prepare_ts(self.__last_come_back_ts, context),
            'lastGoneAwayTs': self.prepare_ts(self.__last_gone_away_ts, context)
        }

    @classmethod
    def create_from_dict(cls, session, d):
        return OnSite(session, d['value'], d['cumulatedOnSiteTime'], d['lastComeBackTs'], d['lastGoneAwayTs'])

    def set_true(self):
        self.__cancel_timer()
        self._set(True)

    def delayed_set_false(self):
        self.__cancel_timer()
        self.__timer = wm_timer.timers_manager.add_timer(5, self.__on_timer, "visit session on_site")  # TODO 5 -> 10

    def _set(self, value, produce_delta=True):
        if self.__value != value:
            self.__value = value
            self.__session.log('on_site.set ' + str(value))

            if value:
                self.__last_come_back_ts = time.time()
                self.__last_gone_away_ts = None
            else:
                self.__last_gone_away_ts = time.time()
                self.__cumulated_on_site_time += self.__last_gone_away_ts - self.__last_come_back_ts
                self.__last_come_back_ts = None

            # if self.__session.chat:
            #                    self.__session.chat.process_event('visitor.left_site')

            self.__session.update_alive(produce_delta=produce_delta)
            self.__session.update_actual_time(produce_delta=produce_delta)
            if produce_delta:
                self.__session.add_operator_delta(Delta("VISIT_SESSION_ON_SITE", Delta.Event.UPDATE, self.__session.id, self))

            self.__session.store()

    def __cancel_timer(self):
        if self.__timer is not None:
            self.__timer.cancel()
            self.__timer = None

    def __on_timer(self):
        self._set(False)
        self.__timer = None


class VisitSessionSection(wm_utils.Jsonable):
    NOT_IN_CHAT = 'not_in_chat'
    COMMON_QUEUE = 'common_queue'
    QUEUE = 'queue'
    OFFLINE_QUEUE = 'offline_queue'
    IN_CHAT = 'in_chat'
    IN_CHAT_WITH_OTHERS = 'in_chat_with_others'
    CLOSED_CHATS = 'closed_chats'
    CLOSED_BY_OPERATOR = 'closed_by_operator'

    def __init__(self, account, key, name_resource_key, color):
        self.account = account
        self.key = key
        self.name_resource_key = name_resource_key
        self.color = color

    def to_dict(self, context=None):
        context = context or {}
        lang = context.get('lang', self.account.get_setting('default_lang'))

        return {
            'key': self.key,
            'name': wm_resources.get_resource(self.account, lang, self.name_resource_key),
            'color': self.color,
            'hidden': VisitSessionSection.is_hidden(self.key, self.account, self.account.get_operator(context['operator_id']))
        }

    @staticmethod
    def is_hidden(section_key, account, operator):
        if section_key == VisitSessionSection.NOT_IN_CHAT:
            return account.get_setting('hide_others')
        if section_key == VisitSessionSection.IN_CHAT_WITH_OTHERS:
            return account.get_setting('hide_anothers_chats') and 'admin' not in operator.role.split(',') and 'supervisor' not in operator.role.split(',')
        if section_key in [VisitSessionSection.OFFLINE_QUEUE, VisitSessionSection.COMMON_QUEUE]:
            return account.get_setting('hide_common_queue') and 'admin' not in operator.role.split(',') and 'supervisor' not in operator.role.split(',')
        return False


class ActualTime(wm_utils.Jsonable):
    def __init__(self, ts, title_key, bg_color, color):
        self.ts = ts
        self.title_key = title_key
        self.bg_color = bg_color
        self.color = color

    def to_dict(self, context=None):
        return {
            'ts': self.prepare_ts(self.ts, context),
            'title': wm_resources.get_resource(context.get('account'), context.get('lang'), self.title_key),
            'bgColor': self.bg_color,
            'color': self.color
        }

    def __eq__(self, other):
        return other and self.ts == other.ts and self.title_key == other.title_key and self.bg_color == other.bg_color and self.color == other.color

    def __ne__(self, other):
        return not self.__eq__(other)


class CachedVisitSessionSections(wm_utils.CachedData):
    def __init__(self, account):
        super(CachedVisitSessionSections, self).__init__(reload_immediately_after_reset=True)
        self.account = account

    def obtain_data(self):
        auto_assign = self.account.get_setting('auto_assign')
        result = []
        result.append(VisitSessionSection(self.account, VisitSessionSection.QUEUE,
                                          'active.visits.waiting_for_answer', '#fe1e00'))

        result.append(VisitSessionSection(self.account, VisitSessionSection.IN_CHAT,
                                          'active.visits.in_chat_with_you' if auto_assign else 'active.visits.in_chat',
                                          '#4f8a00'))
        if self.account.get_setting('show_closed_by_operator_chats'):
            result.append(VisitSessionSection(self.account, VisitSessionSection.CLOSED_BY_OPERATOR,
                                              'active.visits.closed_by_operator_chats', '#4f8a00'))

        if self.account.get_setting('offline_chat_processing'):
            result.append(VisitSessionSection(self.account, VisitSessionSection.OFFLINE_QUEUE,
                                              'active.visits.offline_queue', '#ffb400'))
        if auto_assign:
            result.append(VisitSessionSection(self.account, VisitSessionSection.COMMON_QUEUE,
                                              'active.visits.general_queue', '#ffb400'))
        result.append(VisitSessionSection(self.account, VisitSessionSection.IN_CHAT_WITH_OTHERS,
                                          'active.visits.other_requests' if auto_assign else 'active.visits.in_chat_with_anothers', '#ffb400'))
        if self.account.get_setting('shown_closed_chats_limit'):
            result.append(VisitSessionSection(self.account, VisitSessionSection.CLOSED_CHATS,
                                              'active.visits.last_chats', '#2a5f8f'))
        result.append(VisitSessionSection(self.account, VisitSessionSection.NOT_IN_CHAT,
                                          'active.visits.others' if self.account.get_setting('visitor_tracking') else
                                          'active.visits.previous_in_chat', '#808080'))
        return result


class VisitedPage(wm_utils.InstanceCountTracker, wm_utils.Jsonable):
    def __init__(self, account, id, url, referer, title, lang, department_key, creation_ts, location=None):
        super(VisitedPage, self).__init__()
        self.id = id
        self.account = account
        self.visit_session = None

        self.url = url
        self.referer = referer
        self.decodedReferer = wm_utils.decode_url(referer)
        self.title = title
        self.lang = lang
        self.department_key = department_key if self.account.get_department(department_key) else ''
        self.location = location

        self.creation_ts = creation_ts
        #        self.last_alive_ts = self.creation_ts
        self.alive = False
        self.timer = None

        self.high_priority = False

        self.visitor_long_message_head_part = ''

        self.waiters_manager = None

        self.teleport_url = None

    @classmethod
    def create(cls, account, url, referer, title, lang, department_key, location=None):
        return VisitedPage(account, cls.__next_id(), url, referer, title, lang, department_key, time.time(), location)

    @classmethod
    def create_from_dict(cls, account, d):
        return VisitedPage(account, d['id'], d['url'], d['referer'], d['title'], d['lang'], d['departmentKey'], d['creationTs'], d['location'])

    def set_visit_session(self, visit_session):
        self.visit_session = visit_session
        self.high_priority = self.check_priority()

    def check_priority(self):
        urls = self.account.settings.get('high_priority_urls') if self.account.tariff_settings.get('high_priority_urls') else None
        return False if not urls else self.url in urls

    @classmethod
    def __next_id(cls):
        return uuid.uuid4().hex

    def set_lang_and_dep(self, lang, department_key):
        self.lang = lang
        self.department_key = department_key

    def get_location_settings(self):
        return self.account.get_location_settings(self.location)

    def ping(self, timeout):
        self.set_alive(True)
        self.cancel_timer()
        if timeout:
            self.timer = wm_timer.timers_manager.add_timer(timeout, self.__on_timer, "page killing after ping")

    def on_left(self):
        self.cancel_timer()
        self.set_alive(False)

    def cancel_timer(self):
        if self.timer is not None:
            self.timer.cancel()
            self.timer = None

    def __on_timer(self):
        if self.visit_session and self.visit_session.chat and self.visit_session.visitor.channel_user_id:
            self.ping(10)
        else:
            self.set_alive(False)
            self.timer = None

    def set_alive(self, alive):
        if self.alive != alive:
            self.alive = alive
            self.visit_session.on_page_alive_state_changed(self, alive)

            if alive:
                self.visit_session.add_operator_delta(Delta("VISITED_PAGE", Delta.Event.ADD, self.id, self))  # deprecated
                self.visit_session.add_operator_delta(Delta("VISITED_PAGE_2", Delta.Event.ADD, [self.visit_session.id, self.id], self))
            else:
                self.visit_session.add_operator_delta(Delta("VISITED_PAGE", Delta.Event.DELETE, self.id, None), min_timeout=1)  # deprecated
                self.visit_session.add_operator_delta(Delta("VISITED_PAGE_2", Delta.Event.DELETE, [self.visit_session.id, self.id], None), min_timeout=1)
                if self.visit_session.chat and self.visit_session.chat.visitor_typing == self.id:  # cancel typing and draft if visitor left page
                    self.visit_session.chat.set_visitor_typing(False)
                    self.visit_session.chat.set_visitor_message_draft(None)

    def is_alive(self):
        return self.alive

    def get_waiters_manager(self):
        if not self.waiters_manager:
            self.waiters_manager = VisitorWaitersManager(self)
        return self.waiters_manager

    def to_dict(self, include_session=False, context=None):
        context = context or {}
        mode = context.get('mode')

        result = {
            'id': self.id,
            'url': self.url,
            'title': self.title,
            'alive': self.is_alive(),
            'creationTs': self.prepare_ts(self.creation_ts, context),
            'referer': self.referer,
            'decodedReferer': self.decodedReferer,
            'sessionId': self.visit_session.id,
            'highPriority': self.high_priority
        }
        if mode == 'db':
            result['location'] = self.location
            result['lang'] = self.lang
            result['departmentKey'] = self.department_key
        if include_session:
            result['session'] = self.visit_session.to_dict()
        return result

    @classmethod
    def get_online_status(cls, account, location, lang, lang_to_geo):
        if not account.get_tariff_setting('departments', True):
            return account.oo_manager.get_online_state(lang, '')

        chat_location_settings = account.get_location_settings(location).get('chat', {})

        location_department_key = chat_location_settings.get('departmentKey', '')
        the_departments = None
        department_key = None
        if chat_location_settings.get('chooseDepartment') == 'Y':
            the_departments = Department.get_departments_for_location(account, chat_location_settings, {})
        elif chat_location_settings.get('chooseDepartment') == 'geo':
            departments = Department.get_departments_for_location(account, chat_location_settings, lang_to_geo)
            if len(departments) == 0:
                department_key = location_department_key
            elif len(departments) == 1:
                department_key = departments[0].key
            else:
                if location_department_key in [d.key for d in departments]:
                    department_key = location_department_key
                else:
                    the_departments = departments
        else:
            department_key = location_department_key

        if the_departments:
            online_state = OnlineState.BUSY_OFFLINE
            for d in the_departments:
                online_state = OnlineState.get_more_priority_state(online_state, account.oo_manager.get_online_state(lang, d.key))

            return online_state
        else:
            department_key = department_key if account.get_department(department_key) else ''
            return account.oo_manager.get_online_state(lang, department_key)


class Invitation(wm_utils.Jsonable):
    STATE_IDLE = 'idle'
    STATE_SHOWING = 'showing'
    STATE_SHOWING_AUTO = 'showing-auto'
    STATE_SHOWING_BY_URL_PARAM = 'showing-by-url-param'
    STATE_IDLE_AFTER_CHAT = 'idle-after-chat'
    STATE_FIRST_QUESTION = 'first-question'
    STATE_DEPARTMENT_SELECTION = 'department-selection'
    STATE_CHAT_SHOWING = 'chat-showing'
    STATE_CHAT = 'chat'
    STATE_OFFLINE_MESSAGE = 'offline-message'
    STATE_CALLBACK_HUNTER = 'callback-hunter'
    STATE_END = 'end'

    STATE_GROUP_SHOWING = set([STATE_SHOWING, STATE_SHOWING_AUTO, STATE_SHOWING_BY_URL_PARAM])

    def __init__(self):
        self.id = None
        self.state = Invitation.STATE_IDLE
        self.message = None
        self.avatar = None
        self.operator_id = None
        self.ainvite_id = None

    def to_dict(self, context=None):
        result = {
            "message": self.message,
            "operatorAvatar": self.avatar,
            "ainviteId": self.ainvite_id
        }
        return result


# Visitor side request handling

class VisitorDeltaManager(DeltaManager):
    DELTA_LIVE_PERIOD = 30

    def __init__(self, visit_session):
        self.visit_session = visit_session
        super(VisitorDeltaManager, self).__init__(VisitorDeltaManager.DELTA_LIVE_PERIOD)

    def add_delta(self, delta, min_timeout=0, notify_waiters=True):
        if self.visit_session.visitor and self.visit_session.visitor.channel_type == 'telegram':
            wm_timer.invoke_async(lambda: self.visit_session.account.telegram_api.process_delta(delta, self.visit_session),
                                  timer_name='telegram process_delta')
        elif self.visit_session.visitor and self.visit_session.visitor.channel_type == 'vk':
            wm_timer.invoke_async(lambda: self.visit_session.account.vk_api.process_delta(delta, self.visit_session),
                                  timer_name='vk process_delta')
        elif self.visit_session.visitor and self.visit_session.visitor.channel_type == 'xmpp':
            wm_timer.invoke_async(lambda: self.visit_session.account.xmpp_bot_manager.process_delta(delta, self.visit_session),
                                  timer_name='xmpp process_delta')
        elif self.visit_session.visitor and self.visit_session.visitor.channel_type == 'fb':
            wm_timer.invoke_async(lambda: self.visit_session.account.fb_api.process_delta(delta, self.visit_session),
                                  timer_name='fb process_delta')
        elif self.visit_session.visitor and self.visit_session.visitor.channel_type == 'blinger_whatsapp':
            wm_timer.invoke_async(lambda: self.visit_session.account.blinger_whatsapp_api.process_delta(delta, self.visit_session),
                                  timer_name='blinger_whatsapp process_delta')
        elif self.visit_session.visitor and self.visit_session.visitor.channel_type == 'custom':
            wm_timer.invoke_async(lambda: self.visit_session.account.custom_channel_api.process_delta(
                delta, self.visit_session), timer_name='custom process_delta')
        elif self.visit_session.visitor and self.visit_session.visitor.channel_type == 'viber':
            wm_timer.invoke_async(lambda: self.visit_session.account.viber_api.process_delta(delta, self.visit_session),
                                  timer_name='viber process_delta')
        elif self.visit_session.visitor and self.visit_session.visitor.channel_type == 'odnoklassniki':
            wm_timer.invoke_async(lambda: self.visit_session.account.ok_api.process_delta(delta, self.visit_session), timer_name='ok process_delta')
        else:
            super(VisitorDeltaManager, self).add_delta(delta, min_timeout=min_timeout, notify_waiters=notify_waiters)

    def notify_waiters(self, min_timeout):
        for p in self.visit_session.get_alive_pages():
            if p.waiters_manager:
                p.waiters_manager.notify_all_waiters(self.revision, min_timeout)


class BaseVisitorTrackingRequestHandler(wm_web.CrossDomainRequestHandler, DeltaRequestHandler):
    def requires_account_not_blocked(self):
        return True

    def __get_or_create_visit_session_and_bind_with_page(self, visited_page):
        visit_session_id = self.get_verified_argument('visit-session-id', '')
        visitor = self.__get_visitor(visited_page.lang)

        visit_tracker = self.get_account().visit_tracker

        logging.info('### visit_session_id ' + visit_session_id)
        logging.info('### visitor_id ' + visitor.id)

        session_by_visitor_id = visit_tracker.get_session_by_visitor_id(visitor.id)
        session_by_id = visit_tracker.get_session(visit_session_id)

        visit_session = None

        provided_visitor_fields = self.__get_provided_visitor_fields() or {}
        visitor_provided_id = provided_visitor_fields.get('id')
        webim_visitor = self.get_json_argument('visitor-ext', default=None)

        previous_provided_visitor_fields = session_by_id.visitor.provided_fields if session_by_id else {}
        previous_visitor_provided_id = previous_provided_visitor_fields.get('id')

        if (session_by_visitor_id and session_by_id and session_by_visitor_id is not session_by_id and
                not session_by_id.visitor.is_authorized() and session_by_id.chat):
            visit_tracker.clean_session(session_by_visitor_id.id)
            session_by_id.visitor.set_provided_fields(provided_visitor_fields, webim_visitor)
            visit_session = session_by_id
            logging.info('### by visit session id with killing old auth session')
        elif session_by_id and session_by_id.chat and session_by_id.visitor.set_provided_fields(provided_visitor_fields, webim_visitor):
            visit_session = session_by_id
            logging.info('### by visit session id because of chat')
        elif session_by_visitor_id and session_by_visitor_id.visitor.set_provided_fields(provided_visitor_fields, webim_visitor):
            visit_session = session_by_visitor_id
            logging.info('### by visitor id')
        elif session_by_id and session_by_id.visitor.set_provided_fields(provided_visitor_fields, webim_visitor):
            visit_session = session_by_id
            logging.info('### by visit session id')
        elif session_by_id or session_by_visitor_id:  # session exists but can't set provided fields
            visitor = self.__create_new_visitor(visited_page.lang)
            logging.info('### session and visitor reset')

        if visit_session:
            visit_session.add_page(visited_page)
            push_token = self.get_argument('push-token', None)
            platform = self.get_verified_argument('platform', 'android' if push_token else 'web')
            visit_session.set_push_token(platform, push_token)
        else:
            logging.info('### new session')
            visit_session = self.__create_visit_session_and_bind_with_page(visited_page, visitor)

        if previous_visitor_provided_id and previous_visitor_provided_id != visitor_provided_id:
            self.get_account().event_dispatcher.fire(Event(e_type=Event.Type.VISITOR_LOGOUT, e_object=session_by_id))

        if visitor_provided_id and visitor_provided_id != previous_visitor_provided_id:
            self.get_account().event_dispatcher.fire(Event(e_type=Event.Type.VISITOR_LOGIN, e_object=visit_session))

        return visit_session

    def __create_visit_session_and_bind_with_page(self, visited_page, visitor):
        visit_tracker = self.get_account().visit_tracker
        ip = self.get_ip('')
        #            ips = self.get_header('X-Forwarded-For', '')
        #            arr = ips.split(', ')
        #            ip = arr[0]
        #            ip = '64.233.161.99'
        #            ip = '84.52.101.196'
        #            ip = '93.185.191.120' #tvoe tv

        push_token = self.get_argument('push-token', None)
        platform = self.get_verified_argument('platform', 'android' if push_token else 'web')
        app_version = self.get_argument('app-version', None)
        push_service = self.get_argument('push-service', None)

        visit_session = VisitSession.create(
            self.get_account(),
            ip,
            self.get_header('User-Agent', ''),
            platform,
            push_token,
            visited_page,
            visitor,
            self._get_lang_to_geo(),
            platform != 'web',
            app_version=app_version,
            push_service=push_service)

        visit_session.add_page(visited_page)
        visit_tracker.add_session(visit_session)
        return visit_session

    def get_department_key_arg(self, default):
        return self.get_verified_argument('department-key', default) if self.get_account().get_tariff_setting('departments', True) else default

    def create_visited_page(self):
        account = self.get_account()
        visit_tracker = account.visit_tracker
        location = self.get_verified_argument('location', None, pattern='^(\w|-|\.)+$')
        chat_location_settings = account.get_location_settings(location).get('chat', {})
        account_default_lang = account.get_setting('default_lang')
        lang = chat_location_settings.get('lang', account_default_lang) if account.get_setting('multilang') else account_default_lang
        department_key = chat_location_settings.get('departmentKey', '') if account.get_tariff_setting('departments', True) else ''

        visited_page = VisitedPage.create(
            account, self.get_argument('url', None), self.get_argument('referer', None),
            self.get_argument('title', '--'),
            lang, department_key, location)

        visit_session = self.__get_or_create_visit_session_and_bind_with_page(visited_page)
        provided_auth_token = self.get_argument('provided_auth_token', default=None)
        if provided_auth_token and provided_auth_token in visit_tracker.provided_token_to_fields:
            visit_tracker.provided_token_to_fields[provided_auth_token]['session_id'] = visit_session.id
        visit_tracker.id_to_visited_page[visited_page.id] = visited_page
        return visited_page

    def __get_visitor(self, lang):
        visitor_json = self.get_argument('visitor', default=None)
        logging.warn('visitor_json ' + unicode(visitor_json))
        default_visitor_name = wm_resources.get_resource(self.get_account(), lang, 'chat.default.visitorname')
        if visitor_json is not None:
            try:
                v = json.loads(visitor_json)
                if self.get_account_name() == 'webim' or self.get_account_name() == 'mixey':
                    if 'fields' in v and 'email' in v['fields'] and v['fields']['email'].endswith('@webim.ru'):
                        v['fields'] = {}

                if self.get_verified_argument('platform', None) == 'pochta':
                    if 'fields' in v:
                        v['fields']['name'] = default_visitor_name

            except Exception:
                logging.warn('visitor_json parsing failed')
                v = {}
            logging.warn('visitor id ' + str(v.get('id')))

            v['providedFields'] = self.__get_provided_visitor_fields()
            v['webimVisitor'] = self.get_json_argument('visitor-ext', default=None)

            if v.get('hasProvidedFields') and not v['providedFields']:
                # visitor was authorized before and has id generated from providedFields, he is not authorized now and we should not use this id
                return self.__create_new_visitor(lang)

            visitor = Visitor.create_from_dict(self.get_account(), v, None, default_visitor_name)
            return visitor
        else:
            return self.__create_new_visitor(lang)

    def __create_new_visitor(self, lang):
        a = self.get_account()
        default_visitor_name = wm_resources.get_resource(a, lang, 'chat.default.visitorname')
        now = time.time()
        return Visitor(a, None, default_visitor_name, provided_fields=self.__get_provided_visitor_fields(),
                       webim_visitor=self.get_json_argument('visitor-ext', default=None), creation_ts=now, modification_ts=now)

    def __get_provided_visitor_fields(self):
        if self.get_verified_argument('platform', None) == 'pochta' and self.get_argument('push-token', None):
            result = {'id': self.get_argument('push-token', None)}
            logging.warn('__get_provided_visitor_fields pochta ' + str(result))
            return result

        visitor_ext = self.get_json_argument('visitor-ext', default=None)
        provided_auth_token = self.get_argument('provided_auth_token', default=None)

        if visitor_ext:
            if isinstance(visitor_ext.get('fields'), dict):
                fields = visitor_ext.get('fields')
                expires = visitor_ext.get('expires')
                hash_value = visitor_ext.get('hash')
            else:  # oldschool format
                hash_value = visitor_ext.get('crc')
                fields = visitor_ext
                if 'crc' in fields:
                    del fields['crc']
                expires = None

            if expires:
                if isinstance(expires, int) and expires < 1e10:
                    if time.time() > expires:
                        raise VisitorRequestProcessingException('provided-visitor-expired')
                else:
                    raise VisitorRequestProcessingException('wrong-provided-visitor-expires-value')

            for encoding in ['utf-8', 'cp1251', 'koi8-r']:
                if self.__check_provided_visitor_hash(fields, expires, hash_value, encoding):
                    return fields

            logging.warn('__get_provided_visitor_fields wrong crc ' + json.dumps(visitor_ext) + ' ' + self.get_argument('url', ''))
            raise VisitorRequestProcessingException('wrong-provided-visitor-hash-value')

        elif provided_auth_token:
            fields = self.get_account().visit_tracker.get_provided_fields_by_token(provided_auth_token)
            if not fields:
                raise VisitorRequestProcessingException('provided-auth-token-not-found')

            return fields
        else:
            return None

    def __check_provided_visitor_hash(self, fields, expires, hash_value, encoding):
        if not hash_value:
            return False

        account = self.get_account()
        private_keys = self.get_account().get_setting('private_key')
        if not private_keys:
            return False

        msg_parts = []
        for key in sorted(fields.keys()):
            value = fields[key]
            msg_parts.append(value.encode(encoding))
        if expires:
            msg_parts.append(str(expires))
        msg = ''.join(msg_parts)

        hash_algorithm = account.get_setting('provided_visitor_hash_algorithm')

        try:
            if hash_algorithm == 'hmac-sha256':
                for private_key in private_keys:
                    if hmac.new(key=str(private_key), msg=msg, digestmod=hashlib.sha256).hexdigest() == hash_value.lower():
                        return True
                else:
                    return False

            else:
                if hash_algorithm == 'sha256':
                    m = hashlib.sha256()
                elif hash_algorithm == 'md5':
                    m = hashlib.md5()
                else:
                    return False

                m.update(msg)

                for private_key in private_keys:
                    copied_m = m.copy()
                    copied_m.update(private_key)
                    if copied_m.hexdigest().lower() == hash_value.lower():
                        return True
                else:
                    return False
        except Exception:
            logging.error(u'Error at __check_provided_visitor_hash', exc_info=True)
            return False

    def before_process(self):
        account = self.get_account()
        visit_tracker = account.visit_tracker

        if not visit_tracker.ready:
            self.reject_request('server-not-ready')
            logging.warn('server-not-ready ' + self.request.uri)
            return False

        id = self.get_verified_argument("page-id", None)
        event = self.get_verified_argument('event', None)

        if event == 'init':
            try:
                # TODO  [merge_8_with_9] check this logic for websockets
                if self.is_from_whitelist_domain():
                    self.visited_page = self.create_visited_page()
                else:
                    self.reject_request('domain-not-from-whitelist')
                    return False
            except VisitorRequestProcessingException as e:  # todo try/except on upper level
                self.reject_request(e.error)
                return False
        elif id and id in visit_tracker.id_to_visited_page:
            self.visited_page = visit_tracker.id_to_visited_page[id]

            if account.get_setting('check_visitor_auth') and \
                    self.get_argument('auth-token', None) != self.visited_page.visit_session.auth_token:
                self.reject_request('reinit-required')
                return False
        else:
            self.reject_request('reinit-required')
            return False

        return True

    def process_action(self, event):
        data = {
            'visited_page': self.visited_page,
            'event': event,
            'request_handler': self
        }

        visit_session = self.visited_page.visit_session
        if event.startswith('inv.'):
            if event == 'inv.accept':
                data['first_message_text'] = None
                data['department-key'] = self.get_verified_argument('department-key', None)
                data['visitor_message'] = self.get_argument('message', '')
                data['inv_message'] = self.get_argument('inv_message')

            elif event in ['inv.ainvite', 'inv.by-url-param']:
                data['inv_message'] = self.get_argument('inv_message')
                data['avatar'] = None
                data['ainvite_id'] = self.get_int_argument('ainvite_id', None)

        if event == 'chat.start':
            data['department-key'] = self.get_verified_argument('department-key', None)
            data['force-without-department'] = self.get_bool_argument('force-without-department', False)
            data['visitor-fields'] = self.get_json_argument('visitor-fields', None)
            data['custom_fields'] = self.get_json_argument('custom_fields', None)
            data['first-question'] = self.get_argument('first-question', None)
            data['force-start'] = self.get_bool_argument('force-start', False)
            data['force-online'] = self.get_bool_argument('force-online', False)
            data['client-side-id'] = self.get_verified_argument('client-side-id', None)
            data['mode'] = self.get_argument('mode', None)

        if event == 'chat.close':
            pass

        if event == 'chat.hide':
            # TODO
            visit_session.account.event_dispatcher.fire(Event(e_type=Event.Type.VISITOR_HIDE_CHAT, e_object=visit_session))

        if event == 'chat.message':
            data['aux'] = self.get_argument('aux', None)
            data['client-side-id'] = self.get_verified_argument('client-side-id', None)
            data['message'] = self.get_argument('message', '')
            data['department-key'] = self.get_verified_argument('department-key', None)
            data['force-without-department'] = self.get_bool_argument('force-without-department', False)
            data['force-offline'] = self.get_bool_argument('force-offline', False)

        if event == 'chat.for_operator_message':
            data['aux'] = self.get_argument('aux', None)
            data['message'] = self.get_argument('message', '')

        if event == 'chat.start_upload_file':
            pass

        if event == 'chat.upload_file_wrong_size':
            pass

        if event == 'chat.message-part':
            data['message_part'] = self.get_argument('message_part', '')
            data['last_part'] = self.get_bool_argument('last_part', False)
            data['client-side-id'] = self.get_verified_argument('client-side-id', None)

        if event == 'chat.read_by_visitor':
            pass

        if event == 'chat.visitor_typing':
            data['typing'] = self.get_bool_argument('typing', False)
            data['message-draft'] = self.get_argument('message-draft', None)
            data['del-message-draft'] = self.get_bool_argument('del-message-draft', False)

        if event == 'chat.identification':
            data['action_type'] = self.get_argument('action_type')
            data['identification-fields'] = self.get_json_argument('identification-fields', None)

        if event == 'chat.cont_resp':
            data['visitor-fields'] = self.get_json_argument('visitor-fields', None)
            data['client-side-id'] = self.get_verified_argument('client-side-id', None)

        if event == 'chat.send_chat_history':
            data['email'] = self.get_argument('email')  # todo verify

        if event == 'chat.operator_rate_select':
            data['rate'] = self.get_int_argument('rate')
            data['operator_id'] = self.get_int_argument('operator_id', None)

        if event == 'chat.offline_message':
            data['captcha_fields'] = self.get_json_argument('captcha_fields', None)
            data['client-message-id'] = self.get_verified_argument('client-message-id', None)
            data['client-chat-id'] = self.get_verified_argument('client-chat-id', None)
            data['file-descs-json'] = self.get_json_argument('file-descs-json', None)
            data['file-descs'] = self.get_json_argument('file-descs', None)
            data['text'] = self.get_argument('msg_text', None, strip=False) or self.get_argument('text', None, strip=False)
            data['department-key'] = self.get_verified_argument('department-key', None)
            data['visitor-fields'] = self.get_json_argument('visitor-fields', None)
            data['custom_fields'] = self.get_json_argument('custom_fields', None)
            data['category'] = self.get_argument('category', None)
            data['subcategory'] = self.get_argument('subcategory', None)
            data['subject'] = self.get_argument('subject', None)

        if event == 'chat.delete':
            data['chat-ids'] = self.get_json_argument('chat-ids', None)

        if event == 'init_visitor_number':
            pass

        if event == 'update_visitor_coordinates':
            data['latitude'] = self.get_argument('latitude')
            data['longitude'] = self.get_argument('longitude')

        if event == 'set_push_token':
            data['platform'] = self.get_argument('platform', None)
            data['push-token'] = self.get_argument('push-token')

        if event == 'chat.form_response':
            data['text'] = self.get_argument('text')
            data['data'] = self.get_json_argument('data')
            data['aux'] = self.get_argument('aux')

        if event == 'chat.custom_action_request.buttons':
            data['client-side-id'] = self.get_verified_argument('client-side-id', None)
            data['result'] = self.get_verified_argument('result', None)

        if event == 'cobrowsing.accept':
            pass
        if event == 'cobrowsing.reject':
            pass
        if event == 'cobrowsing.stop':
            pass
        if event == 'cobrowsing.not_supported':
            pass
        if event == 'cbh.order':
            data['phone'] = self.get_argument('phone')

        self.visited_page.visit_session.action_controller.process_action(data, event)

    def get_chat(self, only_offline=True, chat_id=None, data=None):
        chat_id = chat_id or self.get_int_argument('chat-id', None)
        if not chat_id:
            return None
        # ip = self.get_header('X-Real-Ip', self.request.remote_ip)
        visit_session = self.visited_page.visit_session

        # if self.is_ip_banned(ip):
        #     raise tornado.web.HTTPError(500)

        for s in visit_session.account.visit_tracker.get_sessions_by_filter_name(kind=None, filter_name='chats'):
            if s.chat.id == chat_id:
                ch = s.chat
                break
        else:
            ch = visit_session.account.background_storager.get_object(chat.Chat, lambda _ch_: _ch_.id == chat_id)
            ch = ch or chat.Chat.load_chat(visit_session.account, chat_id)

        if not ch:
            logging.warn('chat not found in db ' + str(chat_id))
            # self.add_bruteforce_attempt(ip)
            raise ActionProcessingException('chat-not-found')
        if ch.state == chat.Chat.State.DELETED:
            logging.warn('chat deleted ' + str(chat_id))
            # self.add_bruteforce_attempt(ip)
            raise ActionProcessingException('chat-not-found')
        if ch.session.visitor.id != visit_session.visitor.id:
            logging.warn('chat not found - wrong visitor ' + str(chat_id))
            # self.add_bruteforce_attempt(ip)
            raise ActionProcessingException('chat-not-found')
        if not ch.offline and only_offline:
            logging.warn('chat not found - chat not offline ' + str(chat_id))
            raise ActionProcessingException('chat-not-found')

        return ch

    def get_context(self):
        return {'mode': 'visitor'}

    def get_full_update(self):
        session = self.visited_page.visit_session
        invitation = session.invitation

        online_status = VisitedPage.get_online_status(session.account, self.visited_page.location, self.visited_page.lang,
                                                      session.ip_info.get_lang_to_geo())
        result = {
            "visitSessionId": session.id,
            "pageId": self.visited_page.id,
            "authToken": session.auth_token,
            "visitor": session.visitor,
            "onlineOperators": online_status == OnlineState.ONLINE,  # deprecated, needed for mobile sdk old versions support
            "onlineStatus": online_status,
            "state": invitation.state,
            "chat": session.chat,
            "pollingPeriod": session.current_polling_period,
            # we should keep it for some time for compatibility with cached js
            "normalPollingPeriod": wm_settings.get_normal_polling_period(session.account.name),
            "visitorNumber": session.visitor_number,
            "cobrowsingSession": session.cobrowsing_session,
            "hasPreviousChats": bool(session.visitor.previous_chat_tag) if session.account.get_setting("load_prev_chat_for_visitor") else False
        }

        if invitation.state in Invitation.STATE_GROUP_SHOWING:
            result["invitation"] = invitation

        if invitation.state == Invitation.STATE_DEPARTMENT_SELECTION:
            chat_location_settings = session.account.get_location_settings(self.visited_page.location).get('chat', {})
            lang_to_geo = session.ip_info.get_lang_to_geo() if chat_location_settings.get('chooseDepartment') == 'geo' else {}
            result["departments"] = Department.get_departments_with_online_status_dict(self.visited_page, lang_to_geo)

        return result

    def get_delta_manager(self):
        return self.visited_page.visit_session.delta_manager

    def respond(self):
        result = self.get_response(self.get_since())
        self.send_result(result)

    def is_from_whitelist_domain(self):
        if self.get_account().get_setting('allowed_domains'):
            url = self.get_argument('url', default=None)
            domain = urlparse.urlparse(url).hostname
            scheme = urlparse.urlparse(url).scheme
            whitelist = self.get_account().get_setting('allowed_domains').split(', ')
            account_domain = wm_settings.get_full_domain(self.get_account())

            if domain != account_domain and '%s://%s' % (scheme, domain) not in whitelist and domain not in whitelist:
                logging.warn('Visitor domain %s not from whitelist' % domain)
                return False

        return True


class VisitorTrackingRequestHandler(BaseVisitorTrackingRequestHandler):

    @tornado.web.asynchronous
    def get(self):

        n_tries = self.get_int_argument('n-tries', 0)
        if n_tries < 20:
            average_number_of_track_request_tries.update(n_tries)
        processing_start_time = time.time()
        request_waiting_time_stats.update(processing_start_time - self.request._start_time)

        if not self.before_process():
            self.after_request_processing(processing_start_time)
            return

        if self.visited_page.teleport_url:
            self.send_result({'teleportUrl': self.visited_page.teleport_url})
            self.visited_page.teleport_url = None
            return

        event = self.get_verified_argument('event', None)
        visit_session = self.visited_page.visit_session

        if event == 'left':
            self.visited_page.on_left()
            self.respond()
            self.after_request_processing(processing_start_time)
            return

        self.visited_page.ping(self.get_account().settings.get('normal_polling_period') + 10)

        if event == 'poll':
            if visit_session.chat:
                message_daft = self.get_argument('message-draft', None)
                if message_daft:
                    visit_session.chat.set_visitor_message_draft(message_daft)
                elif self.get_bool_argument('del-message-draft', False):
                    visit_session.chat.set_visitor_message_draft(None)

        try:
            self.process_action(event)
            self.respond()
        except ActionProcessingException as e:
            self.send_result({'error': e.error})
        except VisitorBannedError:
            self.send_result({'error': 'visitor_banned'})

        self.after_request_processing(processing_start_time)

    def after_request_processing(self, processing_start_time):
        request_processing_time_stats.update(time.time() - processing_start_time)


class VisitorWaitersManager(waiter.WaitersManager):

    def __init__(self, visited_page):
        self.visited_page = visited_page
        super(VisitorWaitersManager, self).__init__(visited_page.visit_session.account, "Visitor updates waiters")

    def get_current_revision(self):
        return self.visited_page.visit_session.delta_manager.revision

    def on_waiters_count_changed(self, count):
        self.visited_page.ping(None if count else 10)


class VisitorDeltaRequestHandler(BaseVisitorTrackingRequestHandler, waiter.WaiterRequestHandler):

    def process(self):
        if not self.before_process():
            return
        super(VisitorDeltaRequestHandler, self).process()

    def get_waiters_manager(self):
        return self.visited_page.get_waiters_manager()

    def on_revision_changed(self):
        if self._finished or self.request.connection.stream.closed():
            return
        self.respond()

    def on_timeout(self):
        super(VisitorDeltaRequestHandler, self).on_timeout()
        self.set_header("Content-Type", "application/json; charset=UTF-8")
        event = self.get_verified_argument('event', None)
        if event == 'init':
            return json.dumps({'error': 'timeout'})
        return "{}"

    def get_delta_manager(self):
        return self.visited_page.visit_session.delta_manager


class VisitorActionRequestHandler(BaseVisitorTrackingRequestHandler):

    @tornado.web.asynchronous
    def get(self, *args, **kwargs):
        self.post(*args, **kwargs)

    @tornado.web.asynchronous
    def post(self, *args, **kwargs):
        if self.get_verified_argument('action', '') == 'chat.offline_message':
            wm_timer.invoke_async(self._post, timer_name='visitor action chat.offline_message')
        else:
            self._post()

    def _post(self):
        if not self.before_process():
            return
        self.set_header("Content-Type", "application/json")
        action = self.get_verified_argument('action')
        try:
            result_data = self.process_action(action)
            result = {'result': 'ok'}
            if isinstance(result_data, wm_utils.Jsonable):
                result['data'] = result_data.to_dict({'mode': 'visitor'})
            elif isinstance(result_data, dict) or isinstance(result_data, list):
                result['data'] = result_data
            self.send_result(result)

        except ActionProcessingException as e:
            self.send_result({'error': e.error})
        except VisitorBannedError:
            self.send_result({'error': 'visitor_banned'})

    def send_result(self, result):
        action = self.get_verified_argument('action')
        logging.warn('Result for action ' + action + ': ' + json.dumps(result))
        super(VisitorActionRequestHandler, self).send_result(result)


class VisitorWebSocketActionRequestHandler(BaseVisitorTrackingRequestHandler, waiter.WaiterRequestHandler, WebSocketHandler):

    PING_STR = 'string for ping'

    def open(self):
        if not self._prepare():
            return

        event = self.get_argument('event')
        if event != 'init':
            self.close()

        self.page_id = None
        self.visited_page = None
        self.write_response_lock = threading.Lock()

        self.visit_session_id = self.get_argument('visit-session-id')
        self.since = self.get_int_argument('since')

        if not self.before_process():
            return

        self.write_message(json.dumps({'connected': 'ok'}))

        self.process()
        # Nginx close WebSocket connection after {PROXY_TIMEOUT} sec if no msgs were sent, this is "stay alive" pinger.
        self.ping_timer = wm_timer.timers_manager.add_timer(60, self.check_alive, 'ws checker')

    def check_alive(self):
        if self.ws_connection:
            try:
                self.ping(VisitorWebSocketActionRequestHandler.PING_STR)
                self.ping_timer = wm_timer.timers_manager.add_timer(60, self.check_alive, 'ws checker')
            except StreamClosedError:
                self.ping_timer.cancel()
        else:
            self.ping_timer.cancel()

    def on_pong(self, data):
        return data == VisitorWebSocketActionRequestHandler.PING_STR

    def on_message(self, message):
        data = json.loads(message)
        params = data.get('reqParams')

        if data.get('reqAction') == 'event':

            if params['event'] == 'left':
                self.write_message(json.dumps([{
                    'reqId': data.get('reqId'),
                    'reqResult': {'result': 'ok'}
                }]))
                self.visited_page.on_left()
                self.close()
                return

            params['visited_page'] = self.visited_page
            params['request_handler'] = self

            try:
                result = self.visited_page.visit_session.action_controller.process_ws_action(data, params)
            except ActionProcessingException as e:
                result = {'error': e.error}
            except VisitorBannedError:
                result = {'error': 'visitor_banned'}
            except Exception:
                logging.error('VisitorWebSocketActionRequestHandler: on_message error, params %s' % str(data), exc_info=True)
                result = {'error': 'unknown'}

            self.write_message(json.dumps([{
                'reqId': data.get('reqId'),
                'reqResult': result
            }]))

        elif data.get('reqAction') == 'draftUpdate':
            if self.visited_page.visit_session.chat:
                message_daft = params.get('message-draft', None)
                if message_daft:
                    self.visited_page.visit_session.chat.set_visitor_message_draft(message_daft)
                elif params.get('del-message-draft', False):
                    self.visited_page.visit_session.chat.set_visitor_message_draft(None)

        elif data.get('reqAction') == 'getPendingResponses':
            result = self.visited_page.visit_session.action_controller.get_pending_request_responses(params, self.visited_page, self)
            self.write_message(json.dumps(result))

    def on_close(self):
        try:
            self.get_waiters_manager().remove_waiter(self.waiter)
        except Exception as e:
            logging.error('%s' % str(e), exc_info=True)

        logging.error('WebSocketHandler was closed')

    def process(self):
        if not self.before_process():
            return
        super(VisitorWebSocketActionRequestHandler, self).process()

    def get_since(self):
        return self.since

    def get_waiters_manager(self):
        return self.visited_page.get_waiters_manager()

    def on_revision_changed(self):
        with self.write_response_lock:
            response = self.get_response(self.since)
            if response:
                self.since = response.get('revision')
                self.write_message(json.dumps(response))

    def reject_request(self, details):
        self.write_message({'error': details})
        self.close()

    def get_delta_manager(self):
        return self.visited_page.visit_session.delta_manager

    def get_chat(self, only_offline=True, chat_id=None, data=None):
        chat_id = chat_id or data.get('chat-id', None)
        if not chat_id:
            return None

        # ip = self.get_header('X-Real-Ip', self.request.remote_ip)
        visit_session = self.visited_page.visit_session

        # if self.is_ip_banned(ip):
        #     raise tornado.web.HTTPError(500)

        for s in visit_session.account.visit_tracker.get_all_sessions(kinds=[VisitSession.Kind.ONLINE, VisitSession.Kind.OFFLINE_CHAT]):
            if s.chat and s.chat.id == chat_id:
                ch = s.chat
                break
        else:
            ch = visit_session.account.background_storager.get_object(chat.Chat, lambda _ch_: _ch_.id == chat_id)
            ch = ch or chat.Chat.load_chat(visit_session.account, chat_id)

        if not ch:
            logging.warn('chat not found in db ' + str(chat_id))
            # self.add_bruteforce_attempt(ip)
            raise ActionProcessingException('chat-not-found')
        if ch.session.visitor.id != visit_session.visitor.id:
            logging.warn('chat not found - wrong visitor ' + str(chat_id))
            # self.add_bruteforce_attempt(ip)
            raise ActionProcessingException('chat-not-found')
        if not ch.offline and only_offline:
            logging.warn('chat not found - chat not offline ' + str(chat_id))
            raise ActionProcessingException('chat-not-found')

        return ch


class GetOnlineStatusRequestHandler(wm_web.CrossDomainRequestHandler):

    def get(self, *args, **kwargs):
        account = self.get_account()
        location = self.get_verified_argument('location', None, pattern='^(\w|-|\.)+$')
        chat_location_settings = account.get_location_settings(location).get('chat', {})
        default_lang = account.get_setting('default_lang')
        lang = chat_location_settings.get('lang', default_lang) if account.get_setting('multilang') else default_lang
        status = VisitedPage.get_online_status(account, location, lang, self._get_lang_to_geo())

        result = {
            "onlineOperators": status == OnlineState.ONLINE,  # deprecated, needed for mobile sdk old versions support
            "onlineStatus": status}
        self.send_result(result)


class UploadRequestHandler(wm_web.BaseWebimRequestHandler):

    @tornado.web.asynchronous
    def post(self, *args, **kwargs):
        wm_timer.invoke_async(self.__post, timer_name='l/v/upload')

    def __post(self):
        self.headers()
        logging.warn('UploadRequestHandler 0')
        self.visit_tracker = self.get_account().visit_tracker
        id = self.get_verified_argument('page-id', None)
        chat_mode = self.get_verified_argument('chat-mode', 'online')

        logging.warn('UploadRequestHandler 1')
        if id not in self.visit_tracker.id_to_visited_page:
            logging.warn('UploadRequestHandler reinit-required')
            self.reject_request('reinit-required')
            return
        self.visited_page = self.visit_tracker.id_to_visited_page[id]
        visit_session = self.visited_page.visit_session
        if self.get_account().get_setting('check_visitor_auth') and \
                self.get_argument('auth-token', None) != visit_session.auth_token:
            self.reject_request('reinit-required')
            return
        account = self.get_account()
        max_size = 10
        try:
            nginx_upload_size = int(wm_settings.settings['nginx_upload_size'])
        except Exception:
            nginx_upload_size = 10

        max_visitor_upload_file_size = account.get_setting('max_visitor_upload_file_size')
        if max_visitor_upload_file_size:
            max_size = max_visitor_upload_file_size if int(max_visitor_upload_file_size) <= nginx_upload_size else nginx_upload_size

        file_type = self.request.files['webim_upload_file'][0].filename.lower().split('.')[-1]

        if not wm_utils.security_check_file_type(file_type, account):
            logging.warn('UploadRequestHandler not_allowed_file_type')
            self.set_status(415)
            self.send_result({'error': 'not_allowed_file_type'})
            return

        try:
            file_size = sys.getsizeof(self.request.files['webim_upload_file'][0]['body'])
        except Exception:
            logging.warn('PyPyError: sys.getsizeof() not implemented in PyPy')
            file_size = len(self.request.files['webim_upload_file'][0]['body'])

        if file_size >= int(max_size) * 1024 * 1024:
            logging.warn('UploadRequestHandler max_file_size_exceeded')
            self.set_status(413)
            self.send_result({'error': 'max_file_size_exceeded'})
            return

        file_desc = wm_utils.store_file(self.request.files['webim_upload_file'][0],
                                        visit_session.visitor.id,
                                        account.name)

        if chat_mode == 'online':
            chat.Message.create(visit_session.chat, chat.Message.Kind.FILE_VISITOR, visit_session.visitor.get_name(), json.dumps(file_desc),
                                client_side_id=self.get_verified_argument('client-side-id', None))
        else:
            logging.warn('UploadRequestHandler result ' + str(file_desc))
        self.send_result({'result': 'ok', 'data': file_desc})

    def send_result(self, result):
        wm_utils.invoke_in_ioloop(lambda: self.finish(json.dumps(result)), name='l/v/upload')

    def options(self, *args, **kwargs):
        self.headers()

    def headers(self):
        self.set_header('Content-Type', 'text/json; charset=utf-8')
        self.set_header('Expires', 'Mon, 26 Jul 1997 05:00:00 GMT')
        self.set_header('Last-Modified', time.strftime('%a, %d %b %Y %H:%M:%S GMT', time.gmtime()))
        self.set_header('Cache-Control', 'no-store, no-cache, must-revalidate')
        self.add_header('Cache-Control', 'post-check=0, pre-check=0')
        self.set_header('Pragma', 'no-cache')
        self.set_header('Access-Control-Allow-Origin', '*')


class VisitorDownloadRequestHandler(wm_web.BaseDownloadRequestHandler):

    def requires_not_bot_request(self):
        return True

    def prepare(self):
        super(VisitorDownloadRequestHandler, self).prepare()

        account = self.get_account()

        if account.get_setting('check_visitor_auth'):
            session = self.get_session()

            if not session or not session.is_alive():
                raise tornado.web.HTTPError(403)

            expires = self.get_float_argument('expires')
            if time.time() > expires:
                raise tornado.web.HTTPError(403)

    def do_additional_check(self, file_data, guid):
        account = self.get_account()

        if account.get_setting('check_visitor_auth'):
            session = self.get_session()

            if file_data.get('visitor_id'):
                if session.visitor.id != file_data['visitor_id']:
                    raise tornado.web.HTTPError(403)

            hash = self.get_verified_argument('hash')
            expires = self.get_verified_argument('expires')

            if hash != wm_utils.calc_file_url_hash(account, guid, expires, session.auth_token):
                raise tornado.web.HTTPError(403)

    def get_session(self):
        page_id = self.get_verified_argument('page-id')
        visit_page = self.get_account().visit_tracker.id_to_visited_page.get(page_id)
        return visit_page.visit_session if visit_page else None


class VisitSessionRequestHandler(wm_web.BaseWebimRequestHandler):

    def __init__(self, application, request, include_pages=True, **kwargs):
        super(VisitSessionRequestHandler, self).__init__(application, request, **kwargs)
        self.include_pages = include_pages

    @tornado.web.asynchronous
    def get(self, *args, **kwargs):
        wm_timer.invoke_async(self.respond_on_get, 'visit_session response')

    def respond_on_get(self):
        id = self.get_verified_argument('id')
        visit_tracker = self.get_account().visit_tracker

        result = visit_tracker.get_session(id).to_dict(include_pages=self.include_pages) if visit_tracker.get_session(id) else None

        self.set_header("Content-Type", "application/json; charset=UTF-8")
        self.finish(json.dumps(result))


class VisitSessionPhpRequestHandler(VisitSessionRequestHandler):

    def __init__(self, application, request, **kwargs):
        super(VisitSessionPhpRequestHandler, self).__init__(application, request, include_pages=False, **kwargs)

    def post(self, *args, **kwargs):
        id = self.get_verified_argument('id')
        visit_tracker = self.get_account().visit_tracker
        session = visit_tracker.get_session(id)

        session.invitation.id = self.get_verified_argument('invitation-id', session.invitation.id)
        session.saved_to_db = self.get_verified_argument('saved-to-db', session.saved_to_db)
        session.visitor.fields['name'] = self.get_argument('visitor-name', session.visitor.get_name())

        self.write('ok')


class VisitorBannedError(WebimException):
    def __init__(self):
        logging.warn('Exception: VisitorBannedError was raised')


class EventProcessingException(WebimException):
    def __init__(self, error):
        self.error = error


class VisitorRequestProcessingException(WebimException):
    def __init__(self, error):
        self.error = error


class ActionProcessingException(VisitorRequestProcessingException):
    def __init__(self, error):
        super(ActionProcessingException, self).__init__(error)


def log_stats(name, stats):
    logging.warn("stats - " + name + ": " + str(stats))


average_number_of_track_request_tries = stat.StatsByPeriod('number_of_track_request_tries', log_stats)
request_waiting_time_stats = stat.StatsByPeriod('request_waiting_time', log_stats)
request_processing_time_stats = stat.StatsByPeriod('request_processing_time', log_stats)
