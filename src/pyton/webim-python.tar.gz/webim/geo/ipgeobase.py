import os.path
import codecs
from collections import defaultdict

from ip_binary import IP


# The default path to db files is the dir "db_files" relative to the script path
FILES_ROOT = '/var/pro/geodb'


class IPGeobaseException(Exception):
    pass


def str_to_int(string):
    """Try to convert a string to int or float"""
    try:
        return int(string)
    except ValueError:
        try:
            return float(string)
        except ValueError:
            return string


class IPGeobase(object):
    """The cached IPGeobase DB, needed to determine location data by IP.

    Usage:
    >>> from ipgeobase import IPGeobase
    >>> geobase = IPGeobase('/path/to/db_files/')
    >>> geobase.search('213.180.204.3')

    or a shortcut

    >>> from ipgeobase import search
    >>> search('178.130.4.71')

    if found, returns a dict, which is a matching record in the indices or

    DB Files are read and cached on first access.
    """

    def __init__(self, files_root=FILES_ROOT):
        assert os.path.isdir(files_root), \
            'files_root should be an existing dir'
        self._master_index_path = os.path.join(files_root,
                                                'cidr_ru_master_index.db')
        self._slave_index_path = os.path.join(files_root,
                                               'cidr_ru_slave_index.db')

        # The index ".db" files are converted into a list of tuples, which are
        # created on first access
        self._master_index = None
        self._slave_index = None

        # To lower index memory consumption, all the strings in it are
        # converted to integers, which are mapped in this dict
        # This dict has the following structure:
        # {'string': 1, 1:'string', ...
        # }
        # It is later operated with _set_mapping ang _get_mapping methods

        self._seq_id = 0
        def next():
            self._seq_id += 1
            return self._seq_id
        self._maps = defaultdict(next)

    def _set_mapping(self, value):
        id = self._maps[value]
        self._maps[id] = value
        return id

    def _process_master_line(self, line):
        """Convert master index line to a low-mem tuple"""
        start, stop, inetnum, country, city, region, district, status, \
            slave, n_slave = line.strip().split('\t')
        return int(start), int(stop), self._set_mapping(city), self._set_mapping(region),\
              self._set_mapping(district), self._set_mapping(status), int(slave), int(n_slave)

    def _process_slave_line(self, line):
        """Convert master index line to a low-mem tuple"""
        start, stop, inetnum, country, city, region,\
            district, status = line.strip().split('\t')
        return int(start), int(stop), self._set_mapping(city), self._set_mapping(region),\
              self._set_mapping(district), self._set_mapping(status)

    def _index_line_to_dict(self, data):
        """Convert a line in self's indices to a human-readable dict"""

        return {
            'start': data[0],
            'stop': data[1],
            'inetnum': '%s - %s' %
                       (IP.int_to_str(data[0]), IP.int_to_str(data[1])),
            'city': self._maps[data[2]],
            'region': self._maps[data[3]],
            'district': self._maps[data[4]],
            'status': self._maps[data[5]],
        }

    def _search_master(self, integer):
        """Search the matching line in the master index

        Create the index if it does not exist
        """
        if not self._master_index:
            # Fill the master index
            self._master_index = []
            for line in codecs.open(self._master_index_path,
                             encoding='windows-1251'):
#                             encoding='utf-8'):
                self._master_index.append(self._process_master_line(line))
#                self._master_index.append(self._process_master_line(line.decode('windows-1251')))

        for line in self._master_index:
            if line[0] <= integer <= line[1]:
                return line

    def _search_slave(self, integer, master_index_record=None):
        """Search for the matching line in the slave index.

        Create the index if it does not exist
        """
        if not self._slave_index:
            self._slave_index = []
            for line in codecs.open(self._slave_index_path,
                             encoding='windows-1251'):
#                             encoding='utf-8'):
                self._slave_index.append(self._process_slave_line(line))
#                self._slave_index.append(self._process_slave_line(line.decode('windows-1251')))

        # If master_index_record is provided (normally, it is always so)
        # slice the slave index to have only the needed records, pointed
        # by the master index
        if master_index_record:
            mi = master_index_record
            lines = self._slave_index[mi[-2]:mi[-2]+mi[-1]]
        else:
            lines = self._slave_index

        for line in lines:
            if line[0] <= integer <= line[1]:
                return line
        if not master_index_record:
            return
        # I didn't find a clue in the docs, if it is right, but the method
        # assumes that there MUST be a record in the slave index, if the master
        # points to it. If it is not, just uncomment this
        # return master_index_record
        raise IPGeobaseException('Broken index. Found a reference in master,'
                                 ' but no match in slave index')

    def search(self, ip):
        """The main method to search the IP in the ipgeobase db"""
        # Search the master index for the matching line, and if it
        # points to the slave index, get the resulting record from the
        # slave.
        ip = IP.str_to_int(ip)
        master_index_record = self._search_master(ip)
        if not master_index_record:
            return
        # If the slave pointer is not empty, search slave
        if master_index_record[-1] > 0:
            # There should be a record in the slave index
            return self._index_line_to_dict(self._search_slave(ip, master_index_record))
        else:
            return self._index_line_to_dict(master_index_record)


# A shortcut, e.g.
# import ipgeobase
# ipgeobase.search('188.134.30.195')

ipGeobaseSearch = IPGeobase().search
