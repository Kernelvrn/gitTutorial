# -*- coding: utf-8 -*-
import logging
import os
import re

import pygeoip
import subprocess32

import ipgeobase
from .. import wm_settings
#from dns import resolver,reversename


class IPInfo:

    maxMindCities = None

    def __init__(self, ip, lang_to_geo, hide_geo=False):
        if ip.find(',') < 0:
            self.__ip = ip
        else:
            list = ip.split(',')
            self.__ip = list[len(list) - 1]

        self.__updated_html5_geo = False
        self.__initialized = False
        self.__lang_to_geo = lang_to_geo if not hide_geo else {}
        self.__hide_geo = hide_geo
        self.__whois = None
        self.__host = None

    def __add_name(self, geo, region, field_name):
        if 'name' in region and 'RU' in region['name']:
            geo[field_name] = region['name']['RU']
        elif 'name_official' in region and 'RU' in region['name_official']:
            geo[field_name] = region['name_official']['RU']
        elif 'name' in region and 'EN' in region['name']:
            geo[field_name] = region['name']['EN']
        elif 'name_official' in region and 'EN' in region['name_official']:
            geo[field_name] = region['name_official']['EN']

    def __ensure_initialized(self):
        if self.__initialized:
            return

        if wm_settings.get('resolve_visitor_host', True):
            self.__host = self.__get_host()

        if wm_settings.get('resolve_visitor_geo', True) and not self.__hide_geo:

            if 'ru' not in self.__lang_to_geo:
                try:
                    ipgeobase_search_result = ipgeobase.ipGeobaseSearch(self.__ip)
                    if ipgeobase_search_result is not None:
                        self.__lang_to_geo['ru'] = ipgeobase_search_result
                        self.__lang_to_geo['ru']['country_name'] = u'Россия' # TODO very hard
                except:
                    message = 'Could not get geo for ip from ipgeobase: %s' % self.__ip
        #            logging.error(message, sys.exc_info()[0])
                    logging.exception(message)

            if 'en' not in self.__lang_to_geo:
                if IPInfo.maxMindCities is None:
    #                IPInfo.maxMindCities = pygeoip.GeoIP(os.path.join('/var/pro/geodb', 'GeoIPCity.dat'),  pygeoip.MEMORY_CACHE) # for old ubuntu
                    IPInfo.maxMindCities = pygeoip.GeoIP(os.path.join('/var/pro/geodb', 'GeoIPCity.dat'),  pygeoip.STANDARD) # for ubuntu 12

                try:
                    maxmind_search_result = IPInfo.maxMindCities.record_by_addr(self.__ip)
                    if maxmind_search_result is not None:
                        self.__lang_to_geo['en'] = maxmind_search_result
                        self.__fix_unicode(self.__lang_to_geo['en'])
                except:
                    message = 'Could not get geo for ip from maxmind: %s' % self.__ip
                    logging.exception(message)

#TODO for future use
#        try:
#            self.__whois = self.__get_whois(self.__ip)
#        except:
#            message = 'Could not get whois for ip: %s' % self.__ip
#            logging.error(message, sys.exc_info()[0])
#            self.__whois = None

        self.__initialized = True


    def __fix_unicode(self, arr):
        for key, value in arr.items():
            if type(value).__name__ != 'str':
                continue

#            arr[key] = u'' + value
            val = ''
            for i in range(0, len(value)):
                val += unichr(ord(value[i]))
            arr[key] = val




    def to_dict(self, context=None):
        context = context or {}
        mode = context.get('mode')
        lang = context.get('lang')

        self.__ensure_initialized()
        res = {}

        if mode == 'db':
            res['lang_to_geo'] = self.__lang_to_geo
        elif lang:
            geo = self.get_geo(lang)
            fields = ['country_name', 'city', 'latitude', 'longitude']
            if geo is not None and 'country_name' in geo and 'city' in geo:
                res['geo'] = {}
                for f in fields:
                    if f in geo:
                        res['geo'][f] = geo[f]
        else:
            res['geo'] = None

        if self.__whois is not None:
            res['whois'] = self.__whois

        if self.__host is not None:
            res['host'] = self.__host

        if self.__updated_html5_geo:
            res['html5geo'] = True #TODO remove after BUGZTASKS-1836 completed

        return res

    def get_lang_to_geo(self):
        return self.__lang_to_geo

    @staticmethod
    def get_geo_by_lang(lang_to_geo, lang):
        from .. import wm_resources

        if lang in lang_to_geo:
            return lang_to_geo[lang]
        else:
            s_langs = wm_resources.get_substituting_lang(lang)
            for s_lang in s_langs:
                if s_lang in lang_to_geo:
                    return lang_to_geo[s_lang]

        return None

    def get_geo(self, lang):
        return IPInfo.get_geo_by_lang(self.__lang_to_geo, lang)

    def update_coordinates(self, geo):
        self.__ensure_initialized()
        if self.get_lang_to_geo():
            for lang in self.__lang_to_geo:
                self.__lang_to_geo[lang]['latitude'] = geo['latitude']
                self.__lang_to_geo[lang]['longitude'] = geo['longitude']
        self.__updated_html5_geo = True

    def get_location_str(self, lang, format_string):
        self.__ensure_initialized()
        geo = self.get_geo(lang)

        result = ''

        if geo is not None:
            geo_name = ''
            geo_link = ''

            if geo.get('country_name') and geo.get('city'):
                geo_name = geo.get('country_name') + ', ' + geo.get('city')

            if geo.get('latitude') and geo.get('longitude'):
                geo_link = ' http://maps.google.com/maps?q=' + str(geo.get('latitude')) + ',' + str(geo.get('longitude'))

            if geo_name or geo_link:
                result = format_string.format(geo_name, geo_link)

        return result

    def get_city(self, lang):
        self.__ensure_initialized()
        geo = self.get_geo(lang)
        return geo['city'] if geo is not None and 'city' in geo else None

    def __get_host(self):
        #todo EM remove
        return None
#        reversename.from_address("192.168.0.1")

        try:
            output = subprocess32.check_output(["host", self.__ip], timeout=1)
        except:
            logging.error('Error occured while trying to get host', exc_info=True)
            return None

#        logging.info('Got output %s for host %s' % (output, self.__ip))
        m = re.search('pointer\s+(.+?)\.*$', output)

        return m.group(1) if m is not None else None

    def __get_whois(self):
        res = dict()
        #todo use timeout like __get_host do
        p = subprocess32.Popen("whois n %s" % self.__ip, shell=True, bufsize=0,
              stdin=subprocess32.PIPE, stdout=subprocess32.PIPE, close_fds=True)

        (stdin, stdout) = (p.stdin, p.stdout)

        line = stdout.readline()
        while line:
            line = stdout.readline()
            sline = line.strip()
            m = re.search('^(\S+)\:\s+(.+)$', sline)

            if m is not None:
                res[m.group(1)] = m.group(2)

        return res


if __name__ == "__main__":
#    define("maxmind_city_db", default="../geo/GeoIPCity.dat", help="MaxMind city db path", type=str)
#    define("maxmind_city_db", default="../geo/cngeoip.dat", help="MaxMind city db path", type=str)

#    print IPInfo('77.8.62.150').to_dict()
    print IPInfo('222.82.29.55').to_dict()
#    print IPInfo('178.93.185.229').to_dict()
#    print IPInfo('84.52.101.196').to_dict()
#    print IPInfo('109.205.252.191').to_dict()
#    print IPInfo('192.168.1.57, 85.113.133.67').to_dict()
#    print IPInfo('64.233.161.99').to_dict()
#    print IPInfo('64.233.161.99').to_dict()
#    print IPInfo('64.233.161.99').to_dict()
#    print IPInfo('64.233.161.99').to_dict()

