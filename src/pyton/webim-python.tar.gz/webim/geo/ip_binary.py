# Do basic operations with IPs

import struct
import socket
import re


# A regex to match the following IP and netmask notations
# 127.0.0.1, 127.0.0.1/32, 127.0.0.1/255.255.255.255
IP_RE = re.compile(r'^\d{1,3}\.\d{1,3}\.\d{1,3}\.\d{1,3}(|\/(\d{1,2}|\d{1,3}\.\d{1,3}\.\d{1,3}\.\d{1,3}))$')


class IP(object):
    """This class does some basic operations with IPs, e.g.

    - Convert an IP string to integer
    - Convert an integer to IP string
    - Determine if an ip is within a given range

    Examples:

    >>> '192.168.0.1' in IP('192.168.0.0/16')
    True

    >>> IP.str_to_int('127.0.0.1')
    2130706433

    >>> IP.int_to_str(2130706433)
    '127.0.0.1'

    """

    def __init__(self, addr):
        """Parse the addr and add a netmask to it

        """
        assert IP_RE.match(addr), 'Invalid IP'
        if '/' not in addr:
            addr += '/32'
        self.ip, self.mask = map(self.str_to_int, addr.split('/'))

    @staticmethod
    def str_to_int(ip):
        """Convert the IP or bitcount (netmask) to integer

        Example:
        >>> IP.str_to_int('127.0.0.1')
        2130706433

        """
        if '.' in ip:
            return struct.unpack('!L',socket.inet_aton(ip))[0]
        else:
            ip=int(ip)
            return ((1 << ip) - 1) << (32 - ip)

    @staticmethod
    def int_to_str(ip):
        """Convert the IP an integer to IP

        Example:
        >>> IP.int_to_str(2130706433)
        '127.0.0.1'

        """
        return socket.inet_ntoa(struct.pack('!L', ip))

    def __iter__(self):
        ip = self.ip
        while ip & self.mask == self.ip & self.mask:
            yield self.int_to_str(ip)
            ip += 1

    def __contains__(self, ip):
        """Test if an IP is within the ip/mask range

        Example:
        >>> '192.168.0.1' in IP('192.168.0.0/16')
        True
        """
        if self.ip & self.mask == self.str_to_int(ip) & self.mask:
            return True
        else:
            return False

