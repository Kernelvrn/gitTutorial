#!/usr/bin/env python
import json
import os
import socket
import struct

# JSON import
#try:
#import cjson as json

#json_decode = lambda x: json.decode(x)
json_decode = json.loads
#except ImportError:
#    import simplejson as json
#    json_decode = lambda x: json.loads(x)

API_PATH = os.path.dirname(__file__)
BINARY_TREE = os.path.join('/var/pro/geodb', 'geobaza.dat')

class GeobazaException(Exception):
    pass

class Geobaza(object):
    _level_size = []

    def __init__(self):
        try:
            self._btree = open(BINARY_TREE, 'rb')
        except IOError, e:
            raise GeobazaException("Can't open binary tree file %s: %s" % (BINARY_TREE, e))
        # Datafile signature
        signature = self._btree.read(7)
        if signature != 'GEOBAZA':
            raise GeobazaException('Invalid datafile signature!')
        # Datafile headers
        data = self._btree.read(2)
        unpack = struct.unpack('!H', data)[0]
        data = self._btree.read(unpack)
        self.headers = json_decode(data);

        while True:
            data = self._btree.read(1)
            unpack = struct.unpack_from('B', data)[0]
            hi = ((unpack >> 4) & 0x0f)
            lo = (unpack & 0x0f)
            self._level_size.append(hi)
            if hi == 0:
                break
            self._level_size.append(lo)
            if lo == 0:
                break
        self._start_offset = self._btree.tell()

    def _ip2long(self, ip):
        try:
            return struct.unpack_from('!L', socket.inet_aton(ip))[0]
        except socket.error:
            raise GeobazaException('Given IP-adress is invalid!')

    def lookup(self, ip):
        ipint = self._ip2long(ip);
        shift = 32;
        offset = self._start_offset;
        i = 0
        result = []
        for i in range(0, len(self._level_size)):
            shift -= self._level_size[i]
            index = ((ipint >> shift)) & ((1 << self._level_size[i]) - 1)
            tell = offset + index * 4
            self._btree.seek(tell, 0)
            data = self._btree.read(4)
            try:
                unpack = struct.unpack_from('!L', data)[0]
            except struct.error:
                pass
            offset = (unpack & 0xffffffff)
            if (offset & 0x80000000):
                while offset:
                    tell = (offset & 0x7fffffff)
                    self._btree.seek(tell, 0)
                    data = self._btree.read(2)
                    unpack = struct.unpack_from('!H', data)[0]
                    length = (unpack & 0xffff)
                    if not length:
                        return None
                    info = self._btree.read(length)
                    unpack_data = json_decode(info)
                    if unpack_data.get('special', False):
                        return unpack_data
                    result.append(unpack_data)
                    data = self._btree.read(4)
                    unp = struct.unpack_from('!L', data)[0]
                    offset = unp
                break
        return result

def lookup(ip):
#    try:
    geobaza = Geobaza()
    return geobaza.lookup(ip)
#    except GeobazaException:
#        return None

if __name__ == '__main__':
    import sys
    try:
        geobaza = lookup(sys.argv[1])
    except IndexError:
        sys.exit('Usage: geobaza.py ip_address')
    import pprint
    pprint.pprint(geobaza)
