# -*- coding: utf-8 -*-
import logging
import re
import urllib
import json
import os.path
import time

from tornado.ioloop import IOLoop
from tornado.options import options
import tornado.web

import account
import wm_settings
import wm_utils
import wm_timer


__author__ = 'mixey'


class DummyClass:
    def __init__(self):
        pass


class TimeoutedRequestHandler(tornado.web.RequestHandler):

    timeout = None

    def prepare(self):
        super(TimeoutedRequestHandler, self).prepare()
        timeout_period = self.get_timeout_period()
        if timeout_period is not None and not self._finished and not self.request.connection.stream.closed():
            ioloop = IOLoop.current()
            self.timeout = ioloop.add_timeout(ioloop.time() + timeout_period, self.inner_on_timeout)
        else:
            self.timeout = None

    def finish(self, chunk=None):
        super(TimeoutedRequestHandler, self).finish(chunk)
        if self.timeout is not None:
            IOLoop.current().remove_timeout(self.timeout)
            self.timeout = None

    def inner_on_timeout(self):
        result = self.on_timeout()
#        self.set_status(504)
        if not self._finished and not self.request.connection.stream.closed():
            self.finish(result)

    def get_timeout_period(self):
        return options.upstream_timeout

    def on_timeout(self):
        return None


class BaseWebimRequestHandler(tornado.web.RequestHandler, wm_utils.InstanceCountTracker):

    ARG_PATTERN_NORMAL_ID = '^[\w\-.]+$'
    ARG_PATTERN_FILENAME = '^[\w\-.]+$'

    account_aliases = {
        'superfishkaru': 'komusru001',
        'tonermarketru': 'komusru001',
        'officediscountru': 'komusru001',
        'todayonlyru': 'robozru',
    }
    # ban_timeout = 3600
    # bf_attempts_limit = 3
    # account_name_to_ip_bruteforce_info = None

    # def add_bruteforce_attempt(self, ip):
    #     account_name = self.get_account_name()
    #     if ip in self.account_name_to_ip_bruteforce_info.get(account_name):
    #         if self.account_name_to_ip_bruteforce_info[account_name][ip]['till'] > time.time():
    #             self.account_name_to_ip_bruteforce_info[account_name][ip]['till'] = time.time() + self.ban_timeout
    #             self.account_name_to_ip_bruteforce_info[account_name][ip]['attempts'] += 1
    #         else:
    #             self.account_name_to_ip_bruteforce_info[account_name][ip]['till'] = time.time() + self.ban_timeout
    #             self.account_name_to_ip_bruteforce_info[account_name][ip]['attempts'] = 1
    #     else:
    #         self.account_name_to_ip_bruteforce_info[account_name][ip] = {'till': time.time() + self.ban_timeout, 'attempts': 1}

    # def is_ip_banned(self, ip):
    #     account_name = self.get_account_name()
    #     attempts = self.account_name_to_ip_bruteforce_info.get(account_name, {}).get(ip, {}).get('attempts', 0)
    #     if attempts >= self.bf_attempts_limit:
    #         if self.account_name_to_ip_bruteforce_info[account_name][ip]['till'] > time.time():
    #             return True
    #         else:
    #             del self.account_name_to_ip_bruteforce_info[account_name][ip]
    #             return False
    #     else:
    #         return False

    def prepare(self):
        super(BaseWebimRequestHandler, self).prepare()

        self.set_header('X-Webim-Version', wm_utils.version)
        self._prepare()

    def _prepare(self):
        if self.get_argument('client', None) == 'ff_plugin':
            self.reject_request('ff_plugin-not-supported')
            return False

        if account.get_value(self.get_account_name(), 'db_schema_archived') == 'true':
            self.reject_request('db-schema-archived')
            return False

        if self.requires_authorized_operator():
            if self.get_operator() is None:
                self.on_unauthorized_operator()
                return False

            ip = self.get_ip()
            my_ips = wm_settings.settings['my_ips']

            allowed_ips = self.get_account().get_setting('operator_allowed_ips')
            if allowed_ips:
                if not (ip in my_ips) and not wm_utils.check_if_ip_in_list(ip, allowed_ips):
                    self.reject_request('ip-not-allowed')
                    return False

        if self.requires_account_not_blocked() and self.is_account_blocked():
            logging.info("Account is blocked")
            self.reject_request('account-blocked')
            return False

        if self.requires_not_bot_request() and self.is_bot_request():
            raise tornado.web.HTTPError(404)

        if self.requires_origin_checking() and not self.is_same_origin():
            raise tornado.web.HTTPError(403)

        if self.request.method != 'GET' and self.requires_csrf_token_checking() and not self.check_csrf_token():
            raise tornado.web.HTTPError(403)

        return True

    def _execute(self, transforms, *args, **kwargs):
        start = time.time()
        super(BaseWebimRequestHandler, self)._execute(transforms, *args, **kwargs)
        duration = time.time() - start
        wm_timer.timer_stats.update({'timer_name': 'req: ' + self.request.path, 'func_name': 'unknown', 'execution_time': duration})

    def requires_origin_checking(self):
        return False

    def is_same_origin(self):
        return True

    def requires_csrf_token_checking(self):
        return False

    def requires_authorized_operator(self):
        return False

    def on_unauthorized_operator(self):
        self.reject_request('unauthorized')

    def requires_not_bot_request(self):
        return False

    def is_bot_request(self):
        user_agent = self.get_header('User-Agent', '')
        if user_agent:
            # bot, crawl and spider - common, slurp - for Yahoo, stack - for Rambler
            bot_user_agents = ('bot', 'crawl', 'spider', 'slurp', 'stack')
            if 'odnoklassniki.ru' not in user_agent.lower() and any([keyword in user_agent.lower() for keyword in bot_user_agents]):
                logging.error('BotRequestError: request from robot, UA: %s' % user_agent)
                return True
        else:
            logging.error('BotRequestError: missing User-Agent')
            return True

        return False

    def get_operator_id(self):

        if hasattr(self, 'operator_id'):
            return self.operator_id

        self.operator_id = None

        token = self.get_decoded_cookie('WEBIM_AUTH_TOKEN', None)

        if token is None:
            logging.warn("Could not find auth token for request %s" % self)
            return None

        decoded = token.decode('base64')
        operator_id, session_id = decoded.split("|")
        operator_id = int(operator_id)

        operator = self.get_account().get_operator(operator_id)
        if operator and self.get_account().authtokens.get(token).get_data():
            self.operator_id = operator_id
            return self.operator_id
        else:
            return None

    def get_operator(self):
        operator_id = self.get_operator_id()
        return self.get_account().get_operator(operator_id) if operator_id is not None else None

    def get_operator_context(self):
        a = self.get_account()
        default_lang = a.get_setting('default_lang')
        operator_id = self.get_operator_id()
        result = {
            'mode': 'operator',
            'operator_id': operator_id,
            'lang': self.__get_lang_from_arg() or (self.get_cookie('WEBIM_LOCALE', default_lang) if a.get_setting('admin_multilang') else default_lang),
            'account': a
        }

        device_id = self.get_argument('device-id', None)
        result['device_id'] = device_id
        device = device_id and a.oo_manager.get(operator_id).get_device(device_id, create_if_not_found=False)
        ts = self.get_float_argument('ts', None)
        if ts and ts < 0:
            if device:
                device.reset_ts_offset()
        else:
            ts_offset = ts and (ts - self.request._start_time)
            if device:
                result['ts_offset'] = device.get_ts_offset(ts_offset)
            else:
                if ts_offset:
                    result['ts_offset'] = ts_offset

        return result

    def __get_lang_from_arg(self):
        result = self.get_argument('lang', None)
        if result and len(result) > 2:
            result = result[0: 2]
        if result:
            result = result.lower()
        return result

    def __get_session_file_name(self, operator_id, session_id):
        return os.path.join(options.logged_in_operators_dir, '%d-%s.txt' % (operator_id, session_id))

    def requires_account_not_blocked(self):
        return False

    def is_account_blocked(self):
        return self.get_account().is_blocked()

    def get_account_name(self):
        result = self._get_account_name()
        return BaseWebimRequestHandler.account_aliases.get(result, result)

    def _get_account_name(self):
        account_name = self.get_header('X-Account-Name') if not wm_settings.settings.get('hostedmode') else wm_settings.settings.get('hosted_accountname')
        if account_name:
            return account_name

        account_name = self.get_argument('account-name', None)
        if account_name is not None:
            logging.info("Got account name from param %s" % account_name)
            return account_name

        raise Exception("Could not extract account name from %s " % self.request.host)

    def get_account(self):
        """
        :rtype: webim.account.Account
        """
        return account.Account.get(self.get_account_name(), request=self.request)

    def _get_lang_to_geo(self):
        res = {}
        try:
            if self.get_header('X_GEOIP_JSON', '') != '':
                geo = json.loads(self.get_header('X_GEOIP_JSON'))

                res['ru'] = {
                    'latitude': geo['lat'],
                    'longitude': geo['lon'],
                    'city': geo['city'],
                    'country_name': geo['country']
                }

            if self.get_header('X_GEOIP_JSON_EN', None):
                geo = json.loads(self.get_header('X_GEOIP_JSON_EN'))

                # Check if at least one field is not Falsy, because Nginx put valid json string to header with empty values if geo wasn't found
                if any(geo.values()):
                    res['en'] = {
                        'latitude': geo['lat'],
                        'longitude': geo['lon'],
                        'city': geo['city'],
                        'country_name': geo['country']
                    }

            ip = self.get_ip()
            my_ips = wm_settings.settings['my_ips']

            if self.get_header('X_GEOIP_JSON_CHECK', '') != '' and ip in my_ips:
                logging.warn("Checking geo for ip=%s, result=%s" % (self.get_cookie('checkip', ''), self.get_header('X_GEOIP_JSON_CHECK')))
                geo = json.loads(self.get_header('X_GEOIP_JSON_CHECK'))

                res['ru'] = {
                    'latitude': geo['lat'],
                    'longitude': geo['lon'],
                    'city': geo['city'],
                    'country_name': geo['country']
                }

            return res
        except Exception:
            message = 'Could not get geo for ip from nginx headers: %s' % ''  # TODO
            logging.exception(message)

        return res

    def get_ip(self, default=None):
        x_real_ip = self.request.headers.get('X-Real-IP')
        if x_real_ip:
            if re.match(r"^\d{1,3}\.\d{1,3}\.\d{1,3}\.\d{1,3}$", x_real_ip):
                return x_real_ip

        if default is None:
            return self.request.remote_ip

        return default

    def get_header(self, name, default=None):
        if name in self.request.headers:
            return self.request.headers[name]
        return default

    def get_decoded_cookie(self, name, default=None):
        result = self.get_cookie(name, None)
        if result is None:
            return default
        return urllib.unquote_plus(result).decode('cp1251')

    def get_verified_argument(self, name, default=tornado.web.RequestHandler._ARG_DEFAULT, pattern=ARG_PATTERN_NORMAL_ID, respond_wrong_arg_value=None):
        result = self.get_argument(name, default)
        if result and not re.match(pattern, result):
            if respond_wrong_arg_value:
                respond_wrong_arg_value()
            else:
                self.__respond_wrong_arg_value(name)
            raise Exception('Argument ' + name + ' value ' + result + ' doesn\'t match pattern ' + pattern)
        return result

    def get_enum_argument(self, name, allowed_values, default=tornado.web.RequestHandler._ARG_DEFAULT):
        result = self.get_argument(name, default)
        if result and result not in allowed_values:
            self.__respond_wrong_arg_value(name)
            raise Exception('Argument ' + name + ' value ' + result + ' not in allowed list ' + str(allowed_values))
        return result

    def get_int_argument(self, name, default=tornado.web.RequestHandler._ARG_DEFAULT):
        value = self.get_argument(name, default if default == tornado.web.RequestHandler._ARG_DEFAULT else None)
        if not value or value == 'null':
            return default
        try:
            return int(value)
        except Exception:
            self.__respond_wrong_arg_value(name)
            raise Exception('Argument ' + name + ' value ' + value + ' is not correct int value')

    def get_float_argument(self, name, default=tornado.web.RequestHandler._ARG_DEFAULT):
        value = self.get_argument(name, default if default == tornado.web.RequestHandler._ARG_DEFAULT else None)
        if not value or value == 'null':
            return default
        try:
            return float(value)
        except Exception:
            self.__respond_wrong_arg_value(name)
            raise Exception('Argument ' + name + ' value ' + value + ' is not correct float value')

    def get_json_argument(self, name, default=tornado.web.RequestHandler._ARG_DEFAULT):
        value = self.get_argument(name, default if default == tornado.web.RequestHandler._ARG_DEFAULT else None)
        if not value:
            return default
        try:
            return json.loads(value)
        except Exception:
            self.__respond_wrong_arg_value(name)
            raise Exception('Argument ' + name + ' value ' + value + ' is not valid json')

    def get_bool_argument(self, name, default=tornado.web.RequestHandler._ARG_DEFAULT):
        value = self.get_argument(name, default if default == tornado.web.RequestHandler._ARG_DEFAULT else None)
        if not value or value == 'null':
            return default
        return value == 'true' or value == '1'

    def __respond_wrong_arg_value(self, name):
        self.send_result({'error': 'wrong-argument-value', 'argumentName': name})

    def reject_request(self, details):
        self.send_result({'error': details})

    def send_result(self, result):
        self.set_header("Content-Type", "application/json; charset=utf-8")
        self.finish(json.dumps(result))

    def finish_in_ioloop(self, result, name=''):
        wm_utils.invoke_in_ioloop(lambda: self.finish(result), name=name)

    def check_csrf_token(self):
        request_csrf_token = self.get_argument('csrfToken', None)
        cookie_csrf_token = self.get_cookie('WEBIM_CSRF_TOKEN', None)

        return request_csrf_token and cookie_csrf_token and request_csrf_token == cookie_csrf_token


class CrossDomainRequestHandler(BaseWebimRequestHandler):

    def send_result(self, result):
        if self.request.connection.stream.closed():
            return
        callback_name = self.get_verified_argument(
            "callback", default=None,
            respond_wrong_arg_value=lambda: self.finish(json.dumps({'error': 'wrong-argument-value', 'argumentName': 'callback'})))
        self.set_header('Content-Type', 'application/x-javascript; charset=UTF-8' if callback_name else 'application/json; charset=UTF-8')
        if type(result).__name__ == 'instancemethod' or type(result).__name__ == 'method':
            if callback_name:
                self.write('if (%s) {%s(' % (callback_name, callback_name))
                result()
                self.finish(');}')
            else:
                result()
                self.finish()
        else:
            if callback_name:
                self.finish('if (%s) {%s(%s);}' % (callback_name, callback_name, json.dumps(result) if result is not None else "{}"))
            else:
                self.finish(json.dumps(result))


class AdminRequestHandler(BaseWebimRequestHandler):

    basic_auth_pattern = re.compile('^Basic (\S+)$')

    def prepare(self):
        ip = self.get_ip()
        if ip not in wm_settings.settings['my_ips']:
            logging.warn('AdminRequestHandler: Ip ' + ip + ' not allowed')
            raise tornado.web.HTTPError(403)
        authorized = False
        auth_header = self.get_header('Authorization')
        if auth_header:
            result = self.basic_auth_pattern.match(auth_header)
            if result:
                auth_data = result.group(1).decode('base64')
                if auth_data.split(':') == [wm_settings.settings.get('service_user'), wm_settings.settings.get('service_password')]:
                    authorized = True

        if not authorized:
            self.set_status(401)
            self.set_header('WWW-Authenticate', 'Basic realm="Secure Area"')
            self.finish()


class BaseDownloadRequestHandler(BaseWebimRequestHandler):

    @tornado.web.asynchronous
    def get(self, guid, filename):
        # Используем async_callback, чтоб raise tornado.web.HTTPError не перехватывались обработчиком в методе
        # __run_timer(self, t) из TimersManager
        wm_timer.invoke_async(self.async_callback(lambda: self.__get(guid, filename)), timer_name='download_file')

    def __get(self, guid, filename):
        thumb = self.get_verified_argument('thumb', None)

        try:
            file_data = wm_utils.get_uploaded_file(self.get_account_name(), guid, thumb=thumb)
        except wm_utils.MissingFileException:
            raise tornado.web.HTTPError(404)
        except wm_utils.MissingThumbnailKeyException:
            raise tornado.web.HTTPError(400)

        if filename != file_data['filename']:
            raise tornado.web.HTTPError(404)

        self.do_additional_check(file_data, guid)

        if 'html' in file_data['content_type'].lower() or 'xml' in file_data['content_type'].lower():
            self.set_header('Content-Type', 'text/plain')
        else:
            self.set_header('Content-Type', file_data['content_type'])

        self.set_header('Content-Length', file_data['content_length'])
        #        self.set_header('Content-disposition', 'attachment; filename=%s' % fileData['filename']) done by nginx

        wm_utils.invoke_in_ioloop(lambda: self.finish(file_data['content']), name='download_file')

    def do_additional_check(self, file_data, guid):
        pass


class CommonDownloadRequestHandler(BaseDownloadRequestHandler):

    def requires_not_bot_request(self):
        return True

    def prepare(self):
        super(CommonDownloadRequestHandler, self).prepare()

        if time.time() > self.get_float_argument('expires'):
            raise tornado.web.HTTPError(403)

    def do_additional_check(self, file_data, guid):
        account = self.get_account()

        file_hash = self.get_verified_argument('hash')
        expires = self.get_float_argument('expires')

        if file_hash != wm_utils.calc_file_url_hash(account, guid, expires):
            raise tornado.web.HTTPError(403)
