import tornado.web

import wm_web
import wm_timer
import account
import visitor_tracking
import wm_utils
from .channels import wm_channels


class TornadoStatsRequestHandler(wm_web.AdminRequestHandler):

    @tornado.web.asynchronous
    def get(self, *args, **kwargs):
        wm_timer.invoke_async(self.__get, timer_name='Zabbix TornadoStatsRequestHandler')

    def __get(self):
        stat = {'sessions_cnt': 0,
                'working_operators_cnt': 0,
                'chats_cnt': 0,
                'accounts_cnt': 0,
                'failed_to_store_objects_cnt': 0,
                'collected_to_store_objects_cnt': 0}

        for a in account.Account.get_all():
            online_sessions = list(a.visit_tracker.get_all_sessions(kind=visitor_tracking.VisitSession.Kind.ONLINE))

            stat['sessions_cnt'] += len(online_sessions)
            stat['working_operators_cnt'] += len(a.oo_manager.get_working_online_operators())
            stat['failed_to_store_objects_cnt'] += a.background_storager.get_collected_count('failed_to_store')
            stat['collected_to_store_objects_cnt'] += a.background_storager.get_collected_count('collected_to_store')
            stat['accounts_cnt'] += 1

            for s in online_sessions:
                if s.chat:
                    stat['chats_cnt'] += 1

        wm_utils.invoke_in_ioloop(lambda: self.send_result(stat), name="Zabbix TornadoStatsRequestHandler")


class ChannelErrorStatsRequestHandler(wm_web.AdminRequestHandler):

    @tornado.web.asynchronous
    def get(self, *args, **kwargs):
        wm_timer.invoke_async(self.__get, timer_name='Zabbix ChannelErrorStatsRequestHandler')

    def __get(self):
        wm_utils.invoke_in_ioloop(
            lambda: self.send_result(wm_channels.channel_errors.current_collected_stats.data),
            name="Zabbix ChannelErrorStatsRequestHandler")
