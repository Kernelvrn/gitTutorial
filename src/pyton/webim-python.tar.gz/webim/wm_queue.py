# coding=UTF-8

__author__ = 'andrew'

import logging
import threading

from chat import Message, Chat


class VisitorQueueManager():

    def __init__(self, account):
        self.account = account
        self.queue_id_to_queue = {}  # (lang, dep_key, is_offline) => VisitorQueue
        self.chat_in_queue_order_key_function = self.__create_chat_in_queue_order_key_function()

    def __create_chat_in_queue_order_key_function(self):
        if self.account.name in ['testrussianpostru', 'russianpostru', 'webimru106', 'mixey']:
            return lambda ch: (1 if ch.session.department_key == 'soobshcheniya' else 2, ch.creation_ts)
        return lambda ch: (1 if ch.session.visitor.get_field_value('high_priority') == '1' else 2, ch.creation_ts)

    def get_queue(self, lang, dep_key, offline):
        self.__ensure_queue_created(lang, dep_key, offline)
        return self.queue_id_to_queue[(lang, dep_key, offline)]

    def get_all_chats_in_queues(self, offline=False):
        result = []
        for queue in self.queue_id_to_queue.values():
            if queue.offline == offline:  # TODO:is queue locking necessary here?
                result += queue.chats_in_queue

        return result

    def get_queues(self, offline=False):
        return [q for q in self.queue_id_to_queue.values() if q.offline == offline]

    def get_chat_queue_id(self, chat):
        return chat.external_data.get('queue_id', None) if chat else None

    def get_queue_by_id(self, (lang, dep_key, offline)):
        return self.get_queue(lang, dep_key, offline)

    def add_chat_to_queue(self, ch, post_place_in_queue_message=False):
        self.remove_chat_from_queue(ch)

        queue = self.get_queue(ch.session.lang, ch.session.department_key, ch.offline)
        place = queue.add_chat(ch)

        if self.account.get_setting('post_number_in_queue_message_to_visitor') and post_place_in_queue_message and place:
            Message.create_from_resource(ch, Message.Kind.INFO, None, 'chat.message.place_in_queue', True, **{'place_in_queue': place})

    def remove_chat_from_queue(self, chat):
        queue_id = self.get_chat_queue_id(chat)
        if queue_id:
            old_queue = self.get_queue_by_id(queue_id)
            old_queue.remove_chat(chat)

    def update_chat_in_queue(self, chat, post_place_in_queue_message=False):
        if chat.state == Chat.State.ROUTING:
            return

        if self.chat_should_be_in_queue(chat):
            self.add_chat_to_queue(chat, post_place_in_queue_message=post_place_in_queue_message)
        else:
            self.remove_chat_from_queue(chat)

        self.update_queues_statuses_if_zero_limit()

    @classmethod
    def chat_should_be_in_queue(cls, ch):
        return ch.state in [Chat.State.QUEUE, Chat.State.OFFLINE_QUEUE] and ch.get_operator_id() is None

    def get_queue_status(self, lang, dep_key, offline):
        queue = self.get_queue(lang, dep_key, offline)
        return queue.status

    def get_all_chats_in_queues_count(self):
        count = 0
        for queue in self.queue_id_to_queue.values():
            count += len(queue.chats_in_queue)
        return count

    def __ensure_queue_created(self, lang, dep_key, offline):
        if (lang, dep_key, offline) not in self.queue_id_to_queue:
            self.queue_id_to_queue[(lang, dep_key, offline)] = VisitorQueue(dep_key, lang, offline, self.account)

    def update_queues_statuses_if_zero_limit(self):
        for q in self.queue_id_to_queue.values():
            if q.get_limit() == 0:
                q.update_status()

    def on_limit_setting_changed(self):
        for q in self.queue_id_to_queue.values():
            q.update_status()


class VisitorQueue():

    class Status:
        FREE = 'free'
        FULL = 'full'

    def __init__(self, dep_key, lang, offline, account):
        self.account = account
        self.chats_in_queue = []
        self.dep_key = dep_key
        self.lang = lang
        self.offline = offline

        self.status = VisitorQueue.Status.FULL if self.get_limit() == -1 else VisitorQueue.Status.FREE

        self.lock = threading.Lock()

    def get_first(self):
        while self.chats_in_queue:
            ch = self.chats_in_queue[0]
            if ((ch.session.lang, ch.session.department_key, ch.offline) != (self.lang, self.dep_key, self.offline) or
                    not VisitorQueueManager.chat_should_be_in_queue(ch)):
                logging.error(
                    'Unexpected chat ({chat_id}, {session_id}, {chat_lang_dep_offline})'
                    ' has been found in queue ({queue_id}),'
                    ' ch.external_data["queue_id"]: {ch_external_data_queue_id} '.format(
                        chat_id=ch.id,
                        session_id=ch.session.id,
                        chat_lang_dep_offline=(ch.session.lang, ch.session.department_key, ch.offline),
                        queue_id=(self.lang, self.dep_key, self.offline),
                        ch_external_data_queue_id=ch.external_data['queue_id']))
                self.remove_chat(ch)
                continue
            return ch
        return None

    def add_chat(self, chat):
        if chat not in self.chats_in_queue:
            with self.lock:
                place = self.__do_add_chat(chat)
                chat.external_data['queue_id'] = (self.lang, self.dep_key, self.offline)
                self.update_status()
                return place

        return None

    def __do_add_chat(self, chat):
        place = self.find_place_for_chat(chat)
        self.chats_in_queue.insert(place, chat)

        return place

    def find_place_for_chat(self, chat):
        key_function = self.account.queue_manager.chat_in_queue_order_key_function
        key_function_value = key_function(chat)

        # this was working very slow for big queue:
        # for index, chat in reversed(list(enumerate(self.chats_in_queue))):

        index = len(self.chats_in_queue)
        while index > 0:
            index -= 1
            if key_function(self.chats_in_queue[index]) <= key_function_value:
                return index + 1

        return 0

    def remove_chat(self, chat):
        if chat in self.chats_in_queue:
            with self.lock:
                self.chats_in_queue.remove(chat)
                chat.external_data['queue_id'] = None
                self.update_status()

    def get_chat_place_in_queue(self, chat):
        with self.lock:
            return self.chats_in_queue.index(chat) + 1 if chat in self.chats_in_queue else None

    def get_limit(self):
        return self.account.get_setting('offline_queue_limit' if self.offline else 'online_queue_limit', department=self.account.get_department(self.dep_key))

    def update_status(self):
        queue_limit = self.get_limit()
        if queue_limit is None:
            new_status = VisitorQueue.Status.FREE
        elif queue_limit == -1:
            new_status = VisitorQueue.Status.FULL
        elif queue_limit == 0:
            if len(self.chats_in_queue) > 0:
                new_status = VisitorQueue.Status.FULL
            else:
                all_operators_busy = self.account.oo_manager.check_if_all_operators_busy(self.lang, self.dep_key, self.offline)
                new_status = VisitorQueue.Status.FREE if not all_operators_busy else VisitorQueue.Status.FULL
        else:
            new_status = VisitorQueue.Status.FREE if len(self.chats_in_queue) < queue_limit else VisitorQueue.Status.FULL

        if new_status != self.status:
            self.status = new_status
            self.account.oo_manager.recheck_online_state()