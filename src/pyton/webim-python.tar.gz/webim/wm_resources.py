import os
import traceback
from string import Formatter
import logging

import wm_settings
from properties import Properties
from wm_utils import CachedData, DictExt


def get_resource(account, lang, key, *args, **kwargs):
    result = do_get_resource(account, lang, key, *args, **kwargs)
    if result is not None:
        return result

    for s_lang in get_substituting_lang(lang):
        result = do_get_resource(account, s_lang, key, *args, **kwargs)
        if result is not None:
            return result

    return key


def do_get_resource(account, lang, key, *args, **kwargs):
    if lang == 'uk' or lang == 'de':  # TODO: oleg
        lang = 'en'
    if account is None:
        lang_partner_account_tuples = [
            (lang, None, None)
        ]
    else:
        lang_partner_account_tuples = [
            (lang, None, account.name),          # account level
            (lang, account.partner_name, None),  # partner level
            (lang, None, None),                  # common
        ]
    for lang_partner_account in lang_partner_account_tuples:
        resources = lang_partner_account_to_cached_resources.get(lang_partner_account).get_data()
        if key in resources:
            result = unicode(resources.get(key), 'utf-8')
            if len(args) or len(kwargs):
                try:
                    result = result.format(*args, **kwargs)
                except Exception:
                    logging.error('Format failed. key-%s' % (key))
                    try:
                        result = wm_format(result, key, args, kwargs)
                    except Exception:
                        logging.error('wm_format failed. key-%s' % (key))
                        pass
            return result

    logging.error('Resource key %s not found. lang: %s \nTraceback:\n%s' % (key, lang, ''.join(traceback.format_stack())))
    return None


def get_substituting_lang(lang):
    if lang == 'ua':
        return ['ru', 'en', 'tr', 'he']
    else:
        arr = ['en', 'ru', 'ua', 'tr', 'he']
        if lang in arr:
            arr.remove(lang)
        return arr


def get_default_visitor_names(account):
    names = []
    for locale in account.get_available_locale_ids():
        names.append(get_resource(account, locale, 'chat.default.visitorname'))
    return names


def wm_format(resource, key=None, args=None, kwargs=None):
    if len(args):
        res_args = [i[1] for i in Formatter().parse(resource)]
        max_arg = max([int(i) for i in res_args if i is not None]) + 1

        args = list(args)

        if max_arg > len(args):
            logging.error('Missing %d argument(s) in resource "%s"' % (max_arg - len(args), key or resource))
            for i in range(max_arg - len(args)):
                args.append('')

        resource = resource.format(*args)

    if len(kwargs):
        res_kwargs = [i[1] for i in Formatter().parse(resource)]

        for res_kwarg in res_kwargs:
            if res_kwarg not in kwargs.keys():
                logging.error('Missing kwarg "%s" in resource "%s"' % (res_kwarg, key or resource))
                kwargs[res_kwarg] = ''
        resource = resource.format(**kwargs)

    return resource


lang_partner_account_to_cached_resources = DictExt(lambda (lang, partner_name, account_name): CachedResources(lang, partner_name, account_name))


class CachedResources(CachedData):

    def __init__(self, lang, partner_name, account_name):
        CachedData.__init__(self, timeout=3600)
        self.lang = lang
        self.partner_name = partner_name
        self.account_name = account_name

    def obtain_data(self):
        p = Properties()
        if self.account_name:
            file_names = [
                os.path.join(wm_settings.settings['client-data-dir'], self.account_name, 'locales', self.lang, 'properties.txt'),
                os.path.join(wm_settings.public_html_dir, 'webim/account-specific', self.account_name, 'locales', self.lang, 'properties.txt')
            ]
        elif self.partner_name:
            file_names = [os.path.join(wm_settings.public_html_dir, 'webim/locales.' + self.partner_name, self.lang, 'properties.txt'),
                          os.path.join(wm_settings.public_html_dir, 'webim/account-specific/' + self.partner_name + '.partner/locales/',
                                       self.lang, 'properties.txt')]
        else:
            file_names = [os.path.join(wm_settings.public_html_dir, 'webim/locales', self.lang, 'properties.txt')]

#        file = open('/home/mixey/svn/webim/trunk/codebase/source' + '/webim/themes/default/locales/' + self.lang + '/resources.txt', "r") #todo
        for file_name in file_names:
            if os.path.exists(file_name):
                file = open(file_name, "r")
                p.load(file)
                file.close()

        return p.getPropertyDict()