# coding=UTF-8
import logging
import threading
import time
import json
import datetime
import random
import re
import urllib
import collections
import copy

import aspell
import requests
import tornado.web
from tornado.websocket import WebSocketHandler

import account
import visitor_tracking
import wm_notification
import chat
import db_utils
from delta import DeltaManager
from delta import DeltaRequestHandler
from delta import Delta
import waiter
import wm_timer
import wm_utils
import wm_web
import wm_settings
import wm_resources
import wm_queue
from wm_cobrowsing import cobrowsing_session_manager, CobrowsingSession
from wm_events import Event
from .geo import ip_info


__author__ = 'mixey'


class Operator(wm_utils.InstanceCountTracker, wm_utils.Jsonable):

    operator_id_to_lang_to_fullname = {
        36: {'en': 'Eugeny Mikhalev'},
        162122: {'en': 'Eugeny Mikhalev'},
        161793: {'en': 'Olga Pokrovskaya'},
        161812: {'en': 'Alex Shcherbinin'},
        163273: {'en': 'Valeria'},
    }

    def __init__(self, account_name, id, fullname, avatar, roles, sip, email, created, order, config, office_id, robot_logic=None):
        super(Operator, self).__init__()
        self.id = id
        self.account_name = account_name
        self.fullname = fullname
        self.lang_to_fullname = self.operator_id_to_lang_to_fullname[id] if id in self.operator_id_to_lang_to_fullname else {}
        self.avatar = avatar
        self.role = roles

        self.department_keys = set()
        self.supervised_department_ids = set()
        self.supervised_department_keys = set()
        self.department_key_to_priority = {'': account.BriefAccount.get(account_name).get_setting('default_operator_department_priority')}

        self.locales = set(self.__get_account().get_available_locale_ids())
        self.sip = sip
        self.email = email
        self.created = created
        self.order = order
        self.config = json.loads(config) if config else {}  # backend_locale & visible_name & new_visitor_notification setting
        self.office_id = office_id
        work_hours = self.config.get('workhours') if self.__get_account().get_tariff_setting("workhours") else None
        self.work_hours = wm_utils.SelectedPeriods(work_hours, timezone=self.__get_account().timezone) if work_hours else None

        self.robot_logic = robot_logic

    def get_setting(self, key, default=None):
        return self.config.get(key, default)

    def is_robot(self):
        return bool(self.robot_logic)

    def set_locales(self, locales):
        a = self.__get_account()
        if a.get_setting('multilang') and locales:
            self.locales = set(locales.split(','))

    def get_fullname(self, lang):
        return self.lang_to_fullname.get(lang, self.fullname)

    def get_office_name(self):
        offices = self.__get_account().get_setting('offices')
        if offices:
            for office in offices:
                if office['id'] == self.office_id:
                    return office['name']
        else:
            return None

    def get_operator_jid(self):
        return self.config.get('jid')

    def get_operator_info_str(self, lang=None):
        if not lang:
            lang = self.__get_account().get_setting('default_lang') or 'ru'
        info = ''
        try:
            info += self.get_resource('operator.full_name', lang=lang) + ' ' + self.get_fullname(lang) + '\n'
            info += self.get_resource('operator.email', lang=lang) + ' ' + self.email + '\n'
            if self.get_office_name():
                info += self.get_resource('operator.office', lang=lang) + ' ' + self.get_office_name() + '\n'
        except Exception:
            logging.warn('Error while trying to get operator info, operator_id=%d' % self.id)
        return info

    def matches(self, (locale, department_key)):
        if locale != '' and locale not in self.locales:
            return False
        if department_key != '' and department_key not in self.department_keys:
            return False
        return True

    def get_visible_name(self, lang):
        return self.config['visible_name'] if 'visible_name' in self.config else self.get_fullname(lang)

    def get_operator_avatar_url(self, size=None, default=True):
        avatar_url = None

        if self.avatar:
            avatar_url = self.avatar

            if size:
                splitted = avatar_url.split('.')
                avatar_url = (splitted[0] + '-%sx%s.' + splitted[1]) % (size, size)

        elif default:
            avatar_url = '/webim/images/default-operator-avatar.gif'

        return avatar_url

    def get_backend_locale(self):
        ops_account = self.__get_account()
        return self.config['backend_locale'] if 'backend_locale' in self.config and ops_account.get_setting('admin_multilang') else ops_account.get_setting('default_lang')  # noqa: E501

    def get_resource(self, key, lang=None, *args, **kwargs):
        ops_account = self.__get_account()
        return wm_resources.get_resource(ops_account, lang or ops_account.get_setting('default_lang'), key, *args, **kwargs)

    def __get_account(self):
        return account.BriefAccount.get(self.account_name)

    def to_dict(self, context=None):
        context = context or {}
        mode = context.get('mode')

        if mode != 'operator':
            name = self.config['visible_name'] if 'visible_name' in self.config else self.fullname
        else:
            name = self.fullname

        result = {
            'id': self.id,
            'fullname': name,
            'langToFullname': self.lang_to_fullname,
            'avatar': self.avatar,
            'departmentKeys': list(self.department_keys),
            'sip': self.sip,
            'robotType': self.robot_logic.get_setting('type') if self.is_robot() else None
            # TODO add this, if data doesn't go to visitor:
            # 'roles': self.role,
            # 'email': self.email
        }

        if mode == 'operator':
            result['roles'] = self.role
        return result


class OperatorActionController:

    def __init__(self, online_operator):
        self.online_operator = online_operator
        self.account = online_operator.account

    def process(self, data):
        msg_type = data.get('type')
        if msg_type == 'action':
            self.process_action(data)

    def get_operator(self):
        return self.online_operator.get_operator()

    def get_operator_id(self):
        return self.online_operator.operator_id

    def get_session(self, data):
        session_id = data.get('session_id')
        return self.account.visit_tracker.get_session(session_id)

    def get_pending_request_responses(self, pending_requests):
        result = []

        for request_id in pending_requests.keys():
            result.append({
                'reqId': request_id,
                'reqResult': json.dumps(self.process_ws_action(pending_requests[request_id]))
            })

        return result

    def process_ws_action(self, ws_message):
        response = self.process_action(ws_message.get('reqParams'))
        return response

    def process_action(self, data, action=None):
        action = action or data.get('action')

        if action == 'accept_visitor':
            session = self.get_session(data)
            # todo check "if session.chat"
            assigned_to_another_operator = session.chat.get_operator_id() and session.chat.get_operator_id() != self.get_operator_id()
            if not assigned_to_another_operator or data.get('confirmed', False) and self.account.get_setting('chat_intercept'):
                session.chat.process_event('operator.accept', {'operator_id': self.get_operator_id()})
                return {'result': 'ok'}
            else:
                return {'error': 'confirmation_required'}
        elif action == 'redirect_visitor':
            session = self.get_session(data)
            redirect_type = data.get('redirect_type', 'operators')
            redirect_id = data.get('redirect_id', None)

            if redirect_type == 'operators':
                operator_id = int(redirect_id)
                new_online_operator = session.account.oo_manager.get(operator_id)

                if not new_online_operator.is_offline():
                    session.chat.process_event('operator.redirect_to_operator', {'operator_id': operator_id})
                    return {'result': 'ok'}
                else:
                    return {'result': 'offline'}

            elif redirect_type == 'departments':
                if session.account.oo_manager.determine_mutual_department_status(redirect_id) != OperatorStatus.OFFLINE:
                    session.set_department(redirect_id, session.lang)
                    session.chat.process_event('operator.redirect_to_department')
                    return {'result': 'ok'}
                else:
                    online_locales = session.account.oo_manager.get_langs_with_online_operators(redirect_id)
                    if online_locales:
                        session.set_department(redirect_id, random.choice(online_locales))
                        session.chat.process_event('operator.redirect_to_department')
                        return {'result': 'ok'}
                    else:
                        return {'result': 'offline'}

            elif redirect_type == 'locales':
                if session.account.oo_manager.determine_mutual_department_status(session.department_key, locale=redirect_id) != OperatorStatus.OFFLINE:
                    session.set_department(session.department_key, redirect_id)
                    session.chat.process_event('operator.redirect_to_department')
                    return {'result': 'ok'}
                else:
                    if session.account.oo_manager.determine_mutual_department_status('', locale=redirect_id) != OperatorStatus.OFFLINE:
                        session.set_department('', redirect_id)
                        session.chat.process_event('operator.redirect_to_department')
                        return {'result': 'ok'}
                    else:
                        return {'result': 'offline'}

            elif redirect_type == 'queue':
                # TODO on auto_assign don't assign to same operator
                session.set_department(session.department_key, session.lang)
                session.chat.process_event('operator.redirect_to_department')
                return {'result': 'ok'}

            session.account.event_dispatcher.fire(
                Event(e_type=Event.Type.VISITOR_REDIRECTED, e_object=session,
                      e_data={
                          'redirect_type': redirect_type,
                          'redirect_id': redirect_id,
                          'requested_by_operator_id': data.get('requested_by_operator_id')
                      })
            )

        elif action == 'send_chat_to_operator_email':
            target_operator_id = int(data.get('target_operator_id'))
            session = self.get_session(data)
            session.chat.stored_to_db_callbacks.add(lambda: session.chat.send_history_to_operator(target_operator_id))
            return {'result': 'ok'}

        elif action == 'operator_typing':
            session = self.get_session(data)
            if session.chat and self.get_operator_id() == session.chat.get_operator_id():
                session.chat.set_operator_typing(data.get('typing'))
            return {'result': 'ok'}

        elif action == 'operator_note':
            session = self.get_session(data)
            operator = self.get_operator()
            message_text = data.get('message')
            response = {}
            if session.chat:
                if operator.role == 'admin' or operator.id == session.chat.get_operator().id:
                    chat.Message.create(session.chat, chat.Message.Kind.OPERATOR_NOTE, operator.get_fullname(session.lang), message_text, operator.id)
                    response['result'] = 'ok'
                else:
                    response['result'] = 'chat_not_owned'
            else:
                response['result'] = 'no_session_chat'
            return response

        elif action == 'message' or action == 'invite_visitor':
            session = self.get_session(data)  # todo respond error if session not found
            operator = self.get_operator()
            aux = data.get('aux', None)
            message_text = data.get('message')
            if message_text and len(message_text) > 32000:
                raise visitor_tracking.ActionProcessingException('max-message-length-exceeded')
            if not session.chat:
                try:
                    session.process_event('operator.chat.start', args={'operator_id': operator.id})
                except visitor_tracking.EventProcessingException as e:
                    return {'error': e.error}
            elif not session.chat.get_operator_id() or session.chat.state == chat.Chat.State.QUEUE or session.chat.state == chat.Chat.State.OFFLINE_QUEUE:
                session.chat.process_event('operator.accept', {'operator_id': self.get_operator_id()})
            elif session.chat.get_operator_id() and session.chat.get_operator_id() != self.get_operator_id():
                return {'error': 'another_operator_in_chat'}

            client_side_id = data.get('client-side-id', None)
            message = session.chat.get_message_by_client_id(client_side_id) if client_side_id else None
            if message:
                if message.author_id != self.get_operator_id():
                    return {'error': 'message_not_owned'}
                if not message_text:
                    return {'error': 'message_empty'}
                if message_text != message.text:
                    message.update(new_text=message_text)
            else:
                chat.Message.create(
                    session.chat, chat.Message.Kind.OPERATOR, operator.get_visible_name(session.lang), message_text, operator.id, aux=aux,
                    client_side_id=data.get('client-side-id', None)
                )

            return {'result': 'ok'}

        elif action == 'delete_message':
            session = self.get_session(data)
            client_side_id = data.get('client-side-id', None)

            message = session.chat.get_message_by_client_id(client_side_id)

            if not message:
                return {'error': 'message_not_found'}

            if message.author_id != self.get_operator_id():
                return {'error': 'message_not_owned'}

            message.delete()

            return {'result': 'ok'}

        elif action == 'close_chat':
            response = {}
            session = self.get_session(data)
            # todo check "if session.chat"
            if not session.chat.get_operator_id() or self.get_operator_id() == session.chat.get_operator_id():
                if self.account.is_category_mandatory() and not session.chat.is_category_set():
                    response['result'] = 'category_has_to_be_set'
                elif (self.account.get_setting('manual_operator_assign')
                      and not session.chat.manually_assigned_operator_id
                      and len(session.chat.operators_in_chat) > 1):
                    response['result'] = 'operator_has_to_be_assigned'
                    response['operators_in_chat'] = list(session.chat.operators_in_chat)
                else:
                    session.chat.process_event('operator.close', {'operator_id': self.get_operator_id()})
                    response['result'] = 'ok'
            else:
                response['result'] = 'chat_not_owned'
            return response

        elif action == 'ban_visitor':
            session = self.get_session(data)

            # Делается заранее, т.к. после process_event('operator.ban' ...
            # session.chat == None
            operator = session.chat.get_operator()
            operator_name = operator.get_fullname(session.lang) if operator else None
            chat_id = session.chat.id

            session.chat.process_event('operator.ban', {'operator_id': self.get_operator_id()})
            session.ban_visitor(u'Запрещен оператором.', chat_id, operator_name)
            return {'result': 'ok'}

        elif action == 'set_chat_read_by_operator':
            session = self.get_session(data)
            if session.chat and self.get_operator_id() == session.chat.get_operator_id():
                session.chat.set_unread_by_operator_since_ts(None)
            return {'result': 'ok'}

        elif action == 'request_identification':
            session = self.get_session(data)
            if self.get_operator_id() == session.chat.get_operator_id():
                operator = self.get_operator()
                chat.Message.create(session.chat, chat.Message.Kind.FOR_OPERATOR,
                                    operator.get_visible_name(session.lang), session.get_resource('chat.operator.identification.request'),
                                    operator.id)
                chat.Chat.set_requested_form_id(session.chat, data.get('identification_type'))
        elif action == 'request_contacts':
            session = self.get_session(data)
            if self.get_operator_id() == session.chat.get_operator_id():
                operator = self.get_operator()
                if session.visitor.channel_type == 'telegram':
                    chat.Message.create(session.chat, chat.Message.Kind.CONT_REQ, operator.get_visible_name(session.lang),
                                        session.get_resource('chat.telegram.contact_request'), operator.id,
                                        client_side_id=data.get('client-side-id', None))

                elif session.visitor.channel_type == 'viber':
                    chat.Message.create(session.chat, chat.Message.Kind.CONT_REQ,
                                        operator.get_visible_name(session.lang),
                                        session.get_resource('chat.viber.contact_request'), operator.id,
                                        client_side_id=data.get('client-side-id', None))

                else:
                    chat.Message.create(session.chat, chat.Message.Kind.CONT_REQ, operator.get_visible_name(session.lang),
                                        session.get_resource('visitor.contacts.message'), operator.id,
                                        client_side_id=data.get('client-side-id', None))
            return {'result': 'ok'}

        elif action == 'set_category':
            session = self.get_session(data)
            session.chat.set_category(data.get('category', None), data.get('subcategory', None))
            return {'result': 'ok'}

        elif action == 'disconnect_operator':
            current_operator = self.get_operator()
            if 'admin' in current_operator.role.split(','):
                operator_id = int(data.get('operator_id'))
                oo = self.account.oo_manager.get(operator_id)
                oo.disconnect(details='disconnected-by-admin')

        elif action == 'disconnect_all_operators':
            current_operator = self.get_operator()
            if current_operator.role == 'admin':
                self.account.oo_manager.disconnect_all_operators(details='disconnected-by-admin')

        elif action == 'upload_file':
            session = self.get_session(data)
            if not session.chat.get_operator_id():
                session.chat.process_event('operator.accept', {'operator_id': self.get_operator_id()})
            operator = self.get_operator()

            desc_json = json.dumps(wm_utils.store_file(data.get('files')['file'][0], session.visitor.id, self.account.name))

            chat.Message.create(session.chat, chat.Message.Kind.FILE_OPERATOR, operator.get_visible_name(session.lang), desc_json, operator.id,
                                client_side_id=data.get('client-side-id', None))
            return {"jsonrpc": "2.0", "result": None, "id": "id"}

        elif action == 'upload_file_start_message':
            session = self.get_session(data)
            if not session.chat.get_operator_id():
                session.chat.process_event('operator.accept', {'operator_id': self.get_operator_id()})

            filename = data.get('filename', None)
            message_text = session.get_resource('chat.message.file_upload_started', filename=filename) if filename else data.get('message')
            operator = self.get_operator()
            chat.Message.create(session.chat, chat.Message.Kind.FOR_OPERATOR, operator.get_visible_name(session.lang), message_text, operator.id)
            return {'result': 'ok'}

        elif action == 'new_visitor_notification_close':
            online_operator = self.account.oo_manager.get(self.get_operator_id())
            online_operator.notification_manager.remove_new_visitor_notification(self.get_session(data))

        elif action == 'teleport_visitor':
            session = self.get_session(data)
            page_id = data.get('page_id')
            if page_id in self.account.visit_tracker.id_to_visited_page:
                self.account.visit_tracker.id_to_visited_page[page_id].teleport_url = data.get('url')
                if session.chat:
                    if not session.chat.get_operator_id():
                        session.chat.process_event('operator.accept', {'operator_id': self.get_operator_id()})
                    message_text = session.get_resource('chat.redirected.to', *[data.get('url')])
                    operator = self.get_operator()
                    chat.Message.create(session.chat, chat.Message.Kind.FOR_OPERATOR, operator.get_visible_name(session.lang), message_text, operator.id)

        elif action == 'set_visitor_fields':
            fields = json.loads(data.get('fields'))
            session = self.get_session(data)
            if session and session.visitor:
                session.visitor.update_fields(fields, produce_visitor_delta=True)

        elif action == 'manually_assign_operator':
            session = self.get_session(data)
            current_operator = self.get_operator()
            assigned_operator_id = data.get('operator_id')
            session.chat.manually_assigned_operator_id = assigned_operator_id
            message_text = session.get_resource(
                'chat.operator_manually_assigned', *[current_operator.fullname, self.account.get_operator(assigned_operator_id).fullname]
            )
            chat.Message.create(session.chat, chat.Message.Kind.FOR_OPERATOR, None, message_text, current_operator.id)
            return {'result': 'ok'}

        elif action == 'request_form':
            session = self.get_session(data)
            form_id = data.get('form_id', None)
            if session.chat:
                session.chat.set_requested_form_id(form_id)

        elif action == 'create_zendesk_ticket':
            session = self.get_session(data)
            ticket_data = json.loads(data.get('ticket_data', None))
            if session.chat:
                wm_timer.invoke_async(lambda: session.chat.create_zendesk_ticket(data=ticket_data, form_response=None), 'create_zendesk_ticket')

        elif action == 'start_cobrowsing':
            session = self.get_session(data)
            operator_id = self.get_operator_id()
            if session.chat:
                session.chat.process_event('operator.accept', {'operator_id': operator_id})
            new_cobrowsing_session = cobrowsing_session_manager.create_new_session(operator_id, session)
            session.set_cobrowsing_session(new_cobrowsing_session)

        elif action == 'stop_cobrowsing':
            session = self.get_session(data)
            if session and session.cobrowsing_session:
                session.set_cobrowsing_session_state(CobrowsingSession.State.DISCONNECTED, CobrowsingSession.StateReason.CLOSED_BY_OPERATOR)

        elif action == 'operator_chat_message':
            account = self.account
            operator = self.get_operator()
            text = data.get('message')
            uid = data.get('uid')

            account.operator_chat.add_operator_message(operator, text, uid)
            return {'result': 'ok'}

        elif action == 'set_tags':
            session = self.get_session(data)
            tags = json.loads(data.get('tags'))

            session.visitor.set_tags(tags)
            return {'result': 'ok'}

        elif action == 'update_visitor_fields':
            session = self.get_session(data)
            fields = json.loads(data.get('fields', '{}'))

            session.visitor.update_operator_fields(fields)
            return {'result': 'ok'}

        elif action == 'on_chat_timer':

            session = self.get_session(data)
            operator = self.get_operator()
            if session.chat and operator.id == session.chat.get_operator_id() and session.chat.state == chat.Chat.State.CHATTING:
                message_text = session.get_resource('chat.message.chat_timer.%s' % data.get('message_id'))
                if message_text:
                    chat.Message.create(session.chat, chat.Message.Kind.OPERATOR, operator.get_visible_name(session.lang),
                                        message_text, operator.id)
            return {'result': 'ok'}

        elif action == 'add_word_to_spelling_dict':
            if self.account.get_setting('server_dicts_spell_check'):
                word = data.get('word')
                forbidden_spelling_dict = self.account.get_setting('forbidden_spelling_dict') or {}
                if word not in forbidden_spelling_dict:
                    operator = self.get_operator()
                    candidate_spelling_dict = self.account.get_setting('candidate_spelling_dict') or {}

                    if operator.id not in candidate_spelling_dict.get(word, []):
                        candidate_spelling_dict[word] = candidate_spelling_dict.get(word, []) + [operator.id]

                    self.account.settings.set('candidate_spelling_dict', json.dumps(candidate_spelling_dict, ensure_ascii=False), async=True, reset=False,
                                              update_cache_value=candidate_spelling_dict)
            return {'result': 'ok'}

        elif action == 'siebel_button_click':
            session = self.get_session(data)
            session.account.event_dispatcher.fire(
                Event(e_type=Event.Type.SIEBEL_BUTTON_CLICK, e_object=session, e_data={'operator': self.get_operator()}))
            return {'result': 'ok'}

        elif action == 'select_session':
            session = self.get_session(data)
            session.account.event_dispatcher.fire(Event(e_type=Event.Type.OPERATOR_SELECT_SESSION, e_object=session,
                                                        e_data={'previous_session_chat_id': data.get('previous_session_chat_id'),
                                                                'operator': self.get_operator()}))
            return {'result': 'ok'}

        elif action == 'custom_action_request':
            session = self.get_session(data)
            operator = self.get_operator()
            sub_kind = data.get('sub_kind')
            request_state = data.get('state')

            defaults = {'buttons': {'yes': {'request': 'chat.custom_action_request.buttons.options.request.yes',
                                            'response': 'chat.custom_action_request.buttons.options.response.yes'},
                                    'no': {'request': 'chat.custom_action_request.buttons.options.request.no',
                                           'response': 'chat.custom_action_request.buttons.options.response.no'}
                                    }
                        }

            if sub_kind == 'buttons':
                if session.chat:
                    chat.Message.create(session.chat, chat.Message.Kind.ACTION_REQUEST, operator.get_fullname(session.lang),
                                        session.get_resource('chat.custom_action_request.buttons.question'), None,
                                        data={'subKind': sub_kind, 'state': request_state, 'params': defaults[sub_kind]})

        elif action == 'assign_overlimit_chat':
            if not self.account.get_setting('auto_assign'):
                return {'error': 'no_account_setting'}

            operator = self.get_operator()
            if not operator:
                return {'error': 'no_operator'}

            self.account.auto_assign_controller.assign_overlimit_chat(operator)
            return {'result': 'ok'}

class CachedOperators(wm_utils.MultiCache):

    def __init__(self, account=None, timeout=None):
        wm_utils.MultiCache.__init__(self, account, timeout, reload_immediately_after_reset=True)
        self.robot_type_to_operator = {}

    def get_robots(self):
        return self.robot_type_to_operator

    def get_robot(self, robot_type):
        if not self.account.get_setting('robots'):
            return None

        return self.robot_type_to_operator.get(robot_type)

    def get_operators(self):
        return self.get_data()

    def get_operator(self, operator_id):
        return self.get_one(operator_id)

    def load_all_objects(self, connection):
        operators = self.__load_operators(connection)
        return operators

    def load_one_object(self, connection, operator_id):
        operator_id_to_operator = self.__load_operators(connection, operator_id=operator_id)
        return operator_id_to_operator.get(operator_id)

    def __load_operators(self, connection, operator_id=None):
        conn_meta = db_utils.get_connection()
        operators = {}

        operators_query = 'select o.*, oa.roles from chatoperator o join chatoperatoraccount oa on oa.operatorid = o.operatorid and oa.accountname = %s'
        if operator_id:
            operator_rows = conn_meta.query(operators_query + ' where o.operatorid=%s', self.account.name, operator_id)
        else:
            operator_rows = conn_meta.query(operators_query, self.account.name)

        for r in operator_rows:
            robot_logic = self.account.get_robot_logic(r['operatorid'])
            operators[r['operatorid']] = Operator(self.account.name, r['operatorid'], r['fullname'], r['avatar'], r['roles'],
                                                  r['sip'], r['email'], r['created'], r['operatororder'], r['config'],
                                                  r['officeid'], robot_logic)

        last_access_query = 'select operatorid, locales from chatoperatorlastaccess'
        if operator_id:
            la_rows = connection.query(last_access_query + ' where operatorid=%s', operator_id)
        else:
            la_rows = connection.query(last_access_query)

        for r in la_rows:
            if r['operatorid'] in operators:
                o = operators[r['operatorid']]
                o.set_locales(r['locales'])

        if self.account.get_tariff_setting('departments', True):
            department_query = 'select departmentkey, od.operatorid, d.departmentid, od.supervisor, od.priority from chatoperatordepartment od ' \
                               'join chatdepartment d on d.departmentid = od.departmentid ' \
                               'where d.deleted=0'
            if operator_id:
                dep_rows = connection.query(department_query + ' and od.operatorid=%s', operator_id)
            else:
                dep_rows = connection.query(department_query)

            for r in dep_rows:
                operator_id = r['operatorid']
                if operator_id in operators:
                    operators[operator_id].department_keys.add(r['departmentkey'])
                    operators[operator_id].department_key_to_priority[r['departmentkey']] = r['priority']
                    if r['supervisor'] == 1:
                        operators[operator_id].supervised_department_ids.add(r['departmentid'])
                        operators[operator_id].supervised_department_keys.add(r['departmentkey'])

        conn_meta.close()

        return operators

    def on_one_renewed(self, cached_o, loaded_o):
        recheck = False

        if cached_o and loaded_o:
            recheck = self.on_one_updated(cached_o, loaded_o)
        elif not cached_o and loaded_o:
            self.on_one_added(cached_o, loaded_o)
        elif cached_o and not loaded_o:
            self.on_one_deleted(cached_o, loaded_o)

        return recheck

    def on_one_updated(self, cached_o, loaded_o):
        recheck = False

        if cached_o.department_keys != loaded_o.department_keys or cached_o.locales != loaded_o.locales:
                recheck = True
                create_target = lambda o: lambda: chat.Chat.unassign_chats_if_operator_not_in_department(self.account, o)
                wm_timer.invoke_async(create_target(loaded_o), 'unassign_chats_if_operator_not_in_department')

        if cached_o.get_setting('max_chats_per_operator') != loaded_o.get_setting('max_chats_per_operator'):
            recheck = True

        if cached_o.get_setting('max_overlimit_chats_per_operator') != loaded_o.get_setting('max_overlimit_chats_per_operator'):
            recheck = True

        if cached_o.role != loaded_o.role:
            wm_timer.invoke_async(lambda: self.account.oo_manager.get(cached_o.id).update_all_sessions_related())

        if cached_o.supervised_department_keys != loaded_o.supervised_department_keys:
            wm_timer.invoke_async(lambda: self.account.oo_manager.get(cached_o.id).update_all_sessions_related())

        if cached_o.robot_logic and not loaded_o.robot_logic:
            del self.robot_type_to_operator[cached_o.robot_logic.get_type()]
            self.account.oo_manager.delete_online_operator(cached_o.id)
            recheck = True

        if not cached_o.robot_logic and loaded_o.robot_logic:
            self.on_robot_added(loaded_o)
            recheck = True

        if cached_o.robot_logic and loaded_o.robot_logic:
            self.robot_type_to_operator[loaded_o.robot_logic.get_type()] = loaded_o
            if cached_o.robot_logic.get_setting('status') != loaded_o.robot_logic.get_setting('status'):
                self.update_robot_online_status(loaded_o)

        return recheck

    def on_one_deleted(self, cached_o, loaded_o):
        if cached_o.robot_logic:
            del self.robot_type_to_operator[cached_o.robot_logic.get_type()]
        self.account.oo_manager.delete_online_operator(cached_o.id)

    def on_one_added(self, cached_o, loaded_o):
        if loaded_o.robot_logic:
            self.on_robot_added(loaded_o)

    def on_robot_added(self, robot):
        self.robot_type_to_operator[robot.robot_logic.get_type()] = robot
        self.update_robot_online_status(robot)

    def update_robot_online_status(self, robot):
        create_target = lambda r: lambda: self.account.oo_manager.get(r.id).update_status()
        wm_timer.invoke_async(create_target(robot), 'update_status_for_robot')

    def recheck_after_update(self):
        wm_timer.invoke_async(self.account.oo_manager.recheck_online_state, 'recheck_online_state')
        wm_timer.invoke_async(lambda: chat.Chat.try_auto_assign_chats_in_queue(self.account), 'try_auto_assign_chats_in_queue')


class OnlineOperator(wm_utils.KeepRefs):

    def __init__(self, account, operator_id):
        super(OnlineOperator, self).__init__()

        self.account = account
        self.operator_id = operator_id

        self.delta_manager = OperatorDeltaManager(self)
        self.notification_manager = wm_notification.NotificationManager(self)

        self.action_controller = OperatorActionController(self)

        self.__status = self.get_robot_status() if self.get_operator().is_robot() else OperatorStatus.OFFLINE
        self.status_modified_ts = None

        self.__related_visit_session_ids = set()
        self.__related_visit_session_ids_lock = threading.Lock()

        self.lang_and_dep_to_online_period = {}

        self.__devices = {}

        self.last_chat_assigned_ts = time.time()

        self.__lock = threading.Lock()

    def update_overlimit_chat_availibility(self, value):
        self.delta_manager.add_delta(Delta('OVERLIMIT_CHAT', Delta.Event.UPDATE, self.operator_id, value))

    def on_added_to_oo_manager(self):
        self.update_all_sessions_related()

    def get_operator(self):
        return self.account.get_operator(self.operator_id)

    def disconnect(self, details=None):
        if details == 'disconnected-by-admin' and self.is_online_inf():
            return
        for device in self.get_devices():
            if device.status != OperatorStatus.OFFLINE:
                device.set_status(OperatorStatus.OFFLINE, details)
                self.account.push_manager.send_operator_disconnected_notification(device)
        self.update_status()

    def is_online(self):
        return self.__status == OperatorStatus.ONLINE

    def is_offline(self):
        return self.__status == OperatorStatus.OFFLINE

    def get_status(self):
        return self.__status

    def get_robot_status(self):
        return self.get_operator().robot_logic.get_setting('status') or OperatorStatus.ONLINE

    def update_status(self):
        value = OperatorStatus.OFFLINE

        if self.get_operator() and self.get_operator().is_robot():
            value = self.get_robot_status()
        else:
            for d in self.__devices.values():
                status = d.get_effective_status()
                if d.backdoor_login and status != OperatorStatus.ONLINE:
                    continue
                value = OperatorStatus.get_more_priority_status(value, status)

        if self.__status != value:
            prev_status = self.__status
            self.__status = value
            self.status_modified_ts = int(time.time())
            self.account.oo_manager.recheck_online_state()

            if prev_status != OperatorStatus.OFFLINE:
                self.finish_online_periods()
            if value != OperatorStatus.OFFLINE:
                self.update_online_periods()

            if value == OperatorStatus.ONLINE:
                wm_timer.invoke_async(lambda: chat.Chat.try_auto_assign_chats_in_queue(self.account), 'try_auto_assign_chats_in_queue')

            self.delta_manager.add_delta(Delta('STATUS_MODIFIED_TS', Delta.Event.UPDATE, self.operator_id, self.status_modified_ts))
            self.account.oo_manager.add_delta(Delta('OPERATOR_STATUS', Delta.Event.UPDATE, self.operator_id, value))

            wm_timer.invoke_async(self.auto_switch_to_dinner_status_if_need, 'auto_switch_to_dinner_status_if_need')

            self.account.queue_manager.update_queues_statuses_if_zero_limit()

            self.account.event_dispatcher.fire(
                Event(e_type=Event.Type.OPERATOR_STATUS_CHANGED, e_object=self, e_data={'old_status': prev_status, 'new_status': self.__status})
            )

    def is_session_related(self, session_id):
        return session_id in self.__related_visit_session_ids

    def get_related_session_ids(self):
        return self.__related_visit_session_ids

    def update_session_related(self, session, force_del=False):
        must_be_related = not force_del
        must_be_related = must_be_related and not session.hidden and session.alive

        operator = self.get_operator()
        section = session.get_section_for_operator(self.operator_id)

        must_be_related = must_be_related and operator and (operator.matches((session.lang, session.department_key)) or session.chat and session.chat.get_operator_id() == operator.id)  # noqa: E501
        must_be_related = must_be_related and not visitor_tracking.VisitSessionSection.is_hidden(section, self.account, operator)  # noqa: E501

        if must_be_related:

            if operator.role == 'supervisor':
                if section == visitor_tracking.VisitSessionSection.IN_CHAT_WITH_OTHERS and self.account.get_setting('hide_anothers_chats'):
                    must_be_related = session.department_key in operator.supervised_department_keys
                elif section in [visitor_tracking.VisitSessionSection.OFFLINE_QUEUE, visitor_tracking.VisitSessionSection.COMMON_QUEUE] and self.account.get_setting('hide_common_queue'):  # noqa: E501
                    must_be_related = session.department_key in operator.supervised_department_keys

        with self.__related_visit_session_ids_lock:
            if must_be_related and session.id not in self.__related_visit_session_ids:
                self.__related_visit_session_ids.add(session.id)
                self.delta_manager.add_delta(Delta("VISIT_SESSION", Delta.Event.ADD, session.id, session))
            if not must_be_related and session.id in self.__related_visit_session_ids:
                self.__related_visit_session_ids.remove(session.id)
                self.delta_manager.add_delta(Delta("VISIT_SESSION", Delta.Event.DELETE, session.id, None))

    def update_all_sessions_related(self):
        for s in self.account.visit_tracker.get_sessions_by_filter_name(kind=None, filter_name='alive_not_hidden'):
            self.update_session_related(s)

    def update_status_by_work_hours_if_needed(self):
        op = self.get_operator()
        new_workhours_status = OperatorStatus.ONLINE if op.work_hours.check_if_current_time_in_time_periods() else OperatorStatus.INVISIBLE

        if self.get_workhours_status() != new_workhours_status:
            self.set_all_devices_status(new_workhours_status, force=new_workhours_status == OperatorStatus.ONLINE, workhours=True, status_reason="work_hours")

    def get_workhours_status(self):
        value = OperatorStatus.OFFLINE
        for d in self.__devices.values():
            status = d.workhours_status
            if d.backdoor_login and status != OperatorStatus.ONLINE:
                continue
            value = OperatorStatus.get_more_priority_status(value, status)

        return value

    def __add_device(self, device):
        self.__devices[device.device_id] = device
        if device.get_effective_status() != OperatorStatus.OFFLINE:
            self.update_status()
            self.account.oo_manager.recheck_online_inf()

    def get_device(self, device_id, user_agent=None, push_token=None, platform='ios', create_if_not_found=True, backdoor_login=None):
        with self.__lock:
            if device_id in self.__devices:
                return self.__devices[device_id]

            device = None
            if not backdoor_login:
                device = OperatorDevice.load_from_db(device_id, self)
            if not device and create_if_not_found:
                device = OperatorDevice.create(device_id, self, user_agent, push_token, platform, backdoor_login)
            if device:
                self.__add_device(device)
            return device

    def get_devices(self):
        return self.__devices.values()

    def get_online_devices(self):
        return [d for d in self.get_devices() if d.is_online() and d.push_token]

    def is_online_inf(self):
        for d in self.get_devices():
            if d.is_online() and d.platform == 'inf':
                return True
        return False

    def on_assigned_chat_state_changed(self):
        self.auto_switch_to_dinner_status_if_need()

    def auto_switch_to_dinner_status_if_need(self):
        if self.get_status() == OperatorStatus.PRE_DINNER:
            chats_per_operator = self.account.visit_tracker.count_chats_per_operator()
            if not chats_per_operator.get(self.operator_id):
                self.set_all_devices_status(OperatorStatus.DINNER)

    def set_all_devices_status(self, status, force=False, workhours=False, status_reason=None, except_backdoor=False):
        logging.warn('set_all_devices_status @{account_name} {operator_id} status: {status}, reason: {reason}'.format(
            account_name=self.account.name, operator_id=self.operator_id, status=status, reason=status_reason))
        for d in self.get_devices():
            if except_backdoor and d.backdoor_login:
                continue
            if workhours:
                d.set_workhours_status(status)
            if d.status != OperatorStatus.OFFLINE or force:
                d.set_status(status, status_reason=status_reason, from_set_all_devices_status=True)

    def finish_online_periods(self):
        self.update_online_periods()
        self.lang_and_dep_to_online_period = {}

    def update_online_periods(self):
        operator = self.get_operator()
        if not operator:  # may occur if operator is deleted
            return

        lang_and_deps = []
        langs = operator.locales.copy()
        langs.add(None)
        for lang in langs:
            lang_and_deps.append((lang, None))
            for dep in operator.department_keys:
                lang_and_deps.append((lang, dep))

        updated = {}
        for lang_and_dep in lang_and_deps:
            if lang_and_dep in self.lang_and_dep_to_online_period:
                period = self.lang_and_dep_to_online_period.get(lang_and_dep)
                period = period.update()
            else:
                period = OnlinePeriod(self, lang_and_dep, self.get_status())
            updated[lang_and_dep] = period

        # we keep in self.lang_and_dep_to_online_period only periods for actual departments.
        # if department is unlinked from operator we just stop to update it
        self.lang_and_dep_to_online_period = updated

    def after_deleted(self):
        for device in self.get_devices():
            device.waiters_manager.reject_all_waiters('unauthorized')

        self.disconnect()

        chats_with_deleted_operator = self.account.visit_tracker.get_chats(lambda ch: ch.get_operator_id() == self.operator_id)
        for ch in chats_with_deleted_operator:
            ch.process_event('sys.unassign')

    @classmethod
    def update_all_online_periods(cls, for_xxx=False):
            for oo in cls.get_instances():
                if for_xxx != (oo.account.name == 'shoptimeru'):
                    continue

                if not oo.is_offline() and oo.get_operator():
                    oo.update_online_periods()


wm_timer.invoke_periodically(600, OnlineOperator.update_all_online_periods, "operator online periods updating")
wm_timer.invoke_periodically(300, lambda: OnlineOperator.update_all_online_periods(True), "operator online periods updating")


class OperatorStatus:

    ONLINE = 'online'
    INVISIBLE = 'invisible'
    DINNER = 'dinner'
    PRE_DINNER = 'pre_dinner'
    PRIVATE_BREAK = 'private_break'
    OFFLINE = 'offline'
    COACHING_BREAK = 'coaching_break'
    TECHNICAL_BREAK = 'technical_break'
    MEETING_BREAK = 'meeting_break'
    SHORT_BREAK = 'short_break'

    ALL = {ONLINE, INVISIBLE, DINNER, PRE_DINNER, PRIVATE_BREAK, OFFLINE, COACHING_BREAK, TECHNICAL_BREAK, MEETING_BREAK, SHORT_BREAK}

    @staticmethod
    def get_more_priority_status(s1, s2):
        if s1 == OperatorStatus.ONLINE:
            return s1
        if s2 == OperatorStatus.ONLINE:
            return s2

        if s1 == OperatorStatus.PRE_DINNER:
            return s1
        if s2 == OperatorStatus.PRE_DINNER:
            return s2

        if s1 == OperatorStatus.OFFLINE:
            return s2
        return s1


class OperatorDevice(wm_utils.Jsonable):

    def __init__(self, device_id, online_operator, user_agent, push_token, creation_ts, modification_ts, platform='ios', notify_by_email=None,
                 phone_for_sms_notification=None, backdoor_login=None, workhours_status=None):

        self.id = None
        self.device_id = device_id
        self.online_operator = online_operator
        self.status = OperatorStatus.OFFLINE
        self.user_agent = user_agent
        self.push_token = push_token
        self.creation_ts = creation_ts
        self.modification_ts = modification_ts
        self.platform = platform
        self.notify_by_email = notify_by_email
        self.phone_for_sms_notification = phone_for_sms_notification
        self.backdoor_login = backdoor_login
        self.workhours_status = workhours_status

        self.waiters_manager = OperatorWaitersManager(self)
        # interval = 60 if online_operator.account.name == 'chocolifemekz' or self.online_operator.account.name == 'shoptimeru' else 10
        interval = 60
        self.alive_tracker = wm_utils.AliveTracker(interval, self.on_alive_changed_handler)

        self.__last_ts_offsets = collections.deque()

    @classmethod
    def create(cls, device_id, online_operator, user_agent, push_token, platform='ios', backdoor_login=None):
        now = time.time()
        result = OperatorDevice(device_id, online_operator, user_agent, push_token, now, now, platform, backdoor_login=backdoor_login)
        result.store()
        return result

    @classmethod
    def load_from_db(cls, device_id, online_operator):
        c = db_utils.get_connection()
        row = c.get('select * from operatordevice where accountname = %s and operatorid = %s and deviceid = %s',
                    online_operator.account.name, online_operator.operator_id, device_id)
        c.close()

        if not row:
            return None

        platform = row.get('platform') or 'ios'

        result = OperatorDevice(device_id, online_operator, row['useragent'], row['pushtoken'],
                                wm_utils.get_ts(row['dtmcreated']), wm_utils.get_ts(row['dtmmodified']), platform, row['pushbyemail'], row['pushphone'],
                                workhours_status=row['workhoursstatus'])
        result.id = row['id']
        result.set_status(row['devicestatus'])

        return result

    def to_dict(self, context=None):
        context = context or {}
        result = {
            'platform': self.platform,
            'deviceId': self.device_id,
            'status': self.status,
            'userAgent': self.user_agent,
            'pushToken': self.push_token,
            'creationTs': self.prepare_ts(self.creation_ts, context),
            'modificationTs': self.prepare_ts(self.modification_ts, context),
            'creationDateTime': str(datetime.datetime.fromtimestamp(self.prepare_ts(self.creation_ts, context))),
            'modificationTime': str(datetime.datetime.fromtimestamp(self.prepare_ts(self.modification_ts, context)))
        }
        if context.get('dev_list_request'):
            result['id'] = self.id
            result['isAlive'] = self.alive_tracker.is_alive()
            if context.get('backdoor_login'):
                result['backdoorLogin'] = self.backdoor_login

        return result

    def is_online(self):
        return self.get_effective_status() == OperatorStatus.ONLINE

    def get_effective_status(self):
        return self.status if self.push_token or self.alive_tracker.is_alive() else OperatorStatus.OFFLINE

    def on_alive_changed_handler(self, value):
        wm_timer.invoke_async(self.online_operator.update_status, 'online_operator.update_status')

    def __on_status_changed(self, status_reason, value):
        self.online_operator.delta_manager.add_delta(Delta('DEVICE_STATUS', 'upd', self.device_id, {'value': value, 'reason': status_reason}))
        self.online_operator.update_status()
        self.online_operator.account.oo_manager.recheck_online_inf()

    def set_status(self, value, status_reason=None, from_set_all_devices_status=False):
        if value != OperatorStatus.OFFLINE and not from_set_all_devices_status and not self.backdoor_login:
            self.online_operator.set_all_devices_status(value, status_reason=status_reason, except_backdoor=True)

        if self.status != value:
            if value != OperatorStatus.OFFLINE and self.online_operator.is_offline() and self.online_operator.account.check_online_operators_limit_reached():
                return 'online-operators-count-limit-exceeded'
            if value not in [OperatorStatus.OFFLINE, OperatorStatus.INVISIBLE] and not self.online_operator.account.check_if_now_in_allowed_online_time():
                return 'not-in-allowed-online-time'
            if value == OperatorStatus.ONLINE and self.push_token:
                wm_timer.invoke_async(self.ensure_no_other_online_devices_with_same_push_token, 'ensure_no_other_online_devices_with_same_push_token')
            self.status = value
            wm_timer.invoke_async(lambda: self.__on_status_changed(status_reason, value), 'dev.__on_status_changed')
            self.store()

        return 'ok'

    def set_workhours_status(self, value):
        if self.workhours_status != value:
            self.workhours_status = value
            self.store()

    def ensure_no_other_online_devices_with_same_push_token(self):
        c = db_utils.get_connection()
        rows = c.query('select d.id, d.accountname, a.partner, d.operatorid, d.deviceid from operatordevice d '
                       'join account a on a.accountname = d.accountname where d.devicestatus!=%s and d.pushtoken=%s',
                       OperatorStatus.OFFLINE, self.push_token)
        for r in rows:
            if r['id'] == self.id:
                continue
            try:
                wm_utils.request_internal(r['accountname'], '/l/i/set-device-status', partner_name=r['partner'],
                                          **{'operator-id': r['operatorid'], 'device-id': r['deviceid'], 'status': OperatorStatus.OFFLINE})
            except Exception:
                logging.error("Error while trying to request set-device-status fof %s %d %s" %
                              (r['accountname'], r['operatorid'], r['deviceid']), exc_info=True)

        c.close()

    def reset_ts_offset(self):
        self.__last_ts_offsets.clear()

    def get_ts_offset(self, current_ts_offset=None):

        if current_ts_offset:
            if len(self.__last_ts_offsets) >= 10:
                self.__last_ts_offsets.popleft()
            self.__last_ts_offsets.append(current_ts_offset)

        result = max(self.__last_ts_offsets) if self.__last_ts_offsets else 0

        # if self.online_operator.account.name in ['mixey', 'komusru001']:
        #     path = os.path.join(self.online_operator.account.get_client_data_dir(), 'debug')
        #     if not os.path.exists(path):
        #         os.mkdir(path)
        #     f = open(os.path.join(path, 'offset_' + str(self.id)), 'a')
        #     f.write(str(datetime.datetime.now()) + ' ' + str(current_ts_offset) + ' ' + str(result) + '\n')
        #     f.close()

        return result

    def store(self):
        if self.backdoor_login:
            # we are not storing backdoor device in db because there is no place for backdoor_login there (so we'll loose this info ater loading back)
            return
        self.modification_ts = time.time()
        self.online_operator.account.background_storager.add_object_to_store(self)


class OnlinePeriod:

    def __init__(self, online_operator, lang_and_dep, status):
        self.id = None
        self.operator_id = online_operator.operator_id
        self.online_operator = online_operator
        self.lang_and_dep = lang_and_dep
        self.status = status
        self.ts_from = time.time()
        self.ts_to = self.ts_from

        self.online_operator.account.background_storager_1.add_object_to_store(self)

    def update(self):
        cur_time = time.time()
        if time.localtime(cur_time).tm_yday != time.localtime(self.ts_from).tm_yday:
            return OnlinePeriod(self.online_operator, self.lang_and_dep, self.status)
        self.ts_to = cur_time
        self.online_operator.account.background_storager_1.add_object_to_store(self)
        return self


class OnlineState:

    ONLINE = 'online'
    BUSY_ONLINE = 'busy_online'
    OFFLINE = 'offline'
    BUSY_OFFLINE = 'busy_offline'

    @classmethod
    def get_more_priority_state(cls, os1, os2):

        if OnlineState.ONLINE in [os1, os2]:
            return OnlineState.ONLINE

        if OnlineState.BUSY_ONLINE in [os1, os2]:
            return OnlineState.BUSY_ONLINE

        if OnlineState.OFFLINE in [os1, os2]:
            return OnlineState.OFFLINE

        return OnlineState.BUSY_OFFLINE


class OnlineOperatorsManager:

    def __init__(self, account):
        self.account = account
        self.id_to_online_operator = {}

        # (locale, department_key) -> (OnlineState[ONLINE, OFFLINE, BUSY_ONLINE, BUSY_OFFLINE], has_online_operators[True/False]);  lazy-filled
        self.__online_state = {}

        self.online_inf = None
        self.__lock = threading.Lock()

        wm_timer.invoke_async(self.load_online_devices, 'load_online_devices')

    def get(self, operator_id):
        if not operator_id or not self.account.get_operator(operator_id):
            return None
        with self.__lock:
            if operator_id in self.id_to_online_operator:
                return self.id_to_online_operator[operator_id]
            else:
                oo = OnlineOperator(self.account, operator_id)
                self.id_to_online_operator[operator_id] = oo
                oo.on_added_to_oo_manager()
                return oo

    def get_langs_with_online_operators(self, department_key):
        result = []
        for lang in ['ru', 'en', 'ua', 'he', 'tr']:
            if self.get_online_state(lang, department_key) in [OnlineState.ONLINE, OnlineState.BUSY_ONLINE]:
                result.append(lang)
        return result

    def get_online_state(self, locale, department_key):
        return self.__get_online_state(locale, department_key)[0]

    def has_online_operators(self, locale, department_key):
        return self.__get_online_state(locale, department_key)[1]

    def __get_online_state(self, locale, department_key):
        if (locale, department_key) in self.__online_state:
            return self.__online_state[(locale, department_key)]
        else:
            result = self.__determine_online_state(locale, department_key)
            self.__online_state[(locale, department_key)] = result
            return result

    def determine_mutual_department_status(self, department_key, locale=None):
        dep_status = OperatorStatus.OFFLINE

        for oo in self.get_online_operators():
            op = oo.get_operator()
            if op and op.matches((locale or '', department_key)):
                dep_status = OperatorStatus.get_more_priority_status(dep_status, oo.get_status())

        return dep_status

    def recheck_online_state(self):
        for (locale, department_key), state in self.__online_state.items():
            new_state = self.__determine_online_state(locale, department_key)
            if new_state != state:
                self.__online_state[(locale, department_key)] = new_state

# todo don't filter sessions by department and lang but send delta to every session for every dep and lang
#                d = Delta("ONLINE_OPERATORS", Delta.Event.UPDATE, 0, new_state)
#                for s in self.account.visit_tracker.get_sessions(locale, department_key):
#                    s.delta_manager.add_delta(d)

    def __determine_online_state(self, locale, department_key):
        online_state = OnlineState.OFFLINE
        online_operators = False

        if self.account.get_setting('force_online', department=self.account.get_department(department_key)):
            return (OnlineState.ONLINE, True)

        for oo in self.get_online_operators():
            if oo.is_online() and oo.get_operator() and oo.get_operator().matches((locale, department_key)):
                online_state = OnlineState.ONLINE
                online_operators = True

        online_state = self.__correct_online_state(online_state, locale, department_key)

        if online_state == OnlineState.BUSY_ONLINE and self.account.get_setting('offline_instead_of_busy_online'):
            online_state = self.__correct_online_state(OnlineState.OFFLINE, locale, department_key)

        return (online_state, online_operators)

    def __correct_online_state(self, online_state, locale, department_key):
        queue_state = self.account.queue_manager.get_queue_status(locale, department_key, online_state == OnlineState.OFFLINE)

        online_state = (online_state if queue_state == wm_queue.VisitorQueue.Status.FREE else
                        OnlineState.BUSY_OFFLINE if online_state == OnlineState.OFFLINE else
                        OnlineState.BUSY_ONLINE)

        return online_state

    def update_session_related(self, session, force_del=False):
        for oo in self.get_online_operators():
            oo.update_session_related(session, force_del=force_del)

    def update_all_sessions_related(self):
        for oo in self.get_online_operators():
            oo.update_all_sessions_related()

    def add_delta(self, delta, visit_session_id=None, min_timeout=0, notify_waiters=True, skip_operator_ids=None):
        for oo in self.get_online_operators():
            if skip_operator_ids and oo.operator_id in skip_operator_ids:
                continue
            if visit_session_id and not oo.is_session_related(visit_session_id):
                continue
            try:
                oo.delta_manager.add_delta(delta, min_timeout, notify_waiters)
            except Exception:
                logging.error('add_delta failed for operator ' + str(o.id), exc_info=True)

    def get_online_operators(self):
        with self.__lock:
            return self.id_to_online_operator.values()

    def get_working_online_operators(self):
        return [o for o in self.get_online_operators() if o.get_status() != OperatorStatus.OFFLINE]

    def get_alive_online_operators(self):
        return [o for o in self.get_online_operators() if o.is_online()]

    def delete_online_operator(self, operator_id):
        oo = None

        with self.__lock:
            if operator_id in self.id_to_online_operator:
                oo = self.id_to_online_operator[operator_id]
                del(self.id_to_online_operator[operator_id])

        if oo:
            wm_timer.invoke_async(lambda: oo.after_deleted(), timer_name='after_online_operator_was_deleted')

    def set_status_to_all_operators(self, status, details=None):
        for oop in self.get_online_operators():
            oop.set_all_devices_status(status, status_reason=details)

    def disconnect_all_operators(self, details=None):
        for oop in self.get_online_operators():
            oop.disconnect(details)

        if details in ['not-in-allowed-online-time']:
            action = self.account.get_setting('action_on_chats_if_all_operators_disconnected')

            if action == 'none':
                return
            elif action == 'unassign':
                self.account.visit_tracker.unassign_all_chats()
            elif action == 'close':
                self.account.visit_tracker.close_all_chats()

    def load_online_devices(self):
        connection = db_utils.get_connection()
        rows = connection.query('select operatorid, deviceid from operatordevice where accountname=%s and devicestatus=%s',
                                self.account.name, OperatorStatus.ONLINE)
        for row in rows:
            oo = self.get(row['operatorid'])
            if oo:
                logging.warn('[account ' + self.account.name + '] loading device: ' + str(row['deviceid']))
                d = oo.get_device(row['deviceid'], None, None)
                logging.warn('[account ' + self.account.name + '] device loaded: ' + d.to_json())
        connection.close()

    def get_online_inf(self):
        return self.online_inf

    def recheck_online_inf(self):
        for oo in self.get_online_operators():
            if oo.is_online_inf():
                self.online_inf = oo
                return
        self.online_inf = None

    def get_online_operators_by_lang_and_dep(self, lang, department_key):
        return [oo for oo in self.get_alive_online_operators() if oo.get_operator().matches((lang, department_key))]

    def check_if_all_operators_busy(self, lang, department_key, offline):
        alive_online_operators = self.get_online_operators_by_lang_and_dep(lang, department_key)
        operator_id_to_chats_count = self.account.visit_tracker.count_chats_per_operator(offline=offline)
        account_max_chats_per_operator = int(self.account.get_setting('max_chats_per_operator'))
        for oo in alive_online_operators:
            operator = oo.get_operator()
            if not operator:
                continue

            max_chats_per_operator = operator.get_setting('max_chats_per_operator') or account_max_chats_per_operator
            count = operator_id_to_chats_count.get(operator.id, 0)

            if count < max_chats_per_operator:
                return False

        return True


class OperatorDeltaManager(DeltaManager):

    DELTA_LIVE_PERIOD = 300

    def __init__(self, online_operator):
        self.online_operator = online_operator
        super(OperatorDeltaManager, self).__init__(OperatorDeltaManager.DELTA_LIVE_PERIOD)

    def notify_waiters(self, min_timeout):
        for d in self.online_operator.get_devices():
            d.waiters_manager.notify_all_waiters(self.revision, min_timeout)

    def add_delta(self, delta, min_timeout=0, notify_waiters=True):
        super(OperatorDeltaManager, self).add_delta(delta, min_timeout, notify_waiters)

        try:
            self.online_operator.notification_manager.process_delta(delta)
        except Exception:
            logging.error('notification_manager.process_delta failed for operator ' + str(self.online_operator.operator_id), exc_info=True)


class OperatorWaitersManager(waiter.WaitersManager):

    def __init__(self, operator_device):
        self.operator_device = operator_device
        self.online_operator = operator_device.online_operator
        self.disconnect_flag = False
        super(OperatorWaitersManager, self).__init__(self.online_operator.account, "Visitor updates waiters")

    def before_add_waiter(self, since, waiter):
        if self.operator_device.status == OperatorStatus.OFFLINE and self.operator_device.platform not in ['android', 'fake-dev']:
            waiter.request_handler.reject_request('offline')
            return False

        if self.online_operator.account.check_online_operators_limit_reached() and self.online_operator.is_offline():
            waiter.request_handler.reject_request('online-operators-count-limit-exceeded')
            return False

        if (self.operator_device.status not in [OperatorStatus.INVISIBLE, OperatorStatus.OFFLINE]
           and not self.online_operator.account.check_if_now_in_allowed_online_time()):
            waiter.request_handler.reject_request('not-in-allowed-online-time')
            return False

        return True

    def get_current_revision(self):
        return self.online_operator.delta_manager.revision

    def on_waiters_count_changed(self, count):
        if count:
            self.operator_device.alive_tracker.ping()
        else:
            self.operator_device.alive_tracker.delayed_set_dead()


class OperatorDeltaRequestHandler(waiter.WaiterRequestHandler, DeltaRequestHandler):

    def requires_authorized_operator(self):
        return True

    def requires_account_not_blocked(self):
        return True

    def get_waiters_manager(self):
        online_operator = self.get_account().oo_manager.get(self.get_operator_id())
        device_id = self.get_verified_argument('device-id', 'fake-old-dev-id')
        fake_device = device_id == 'fake-old-dev-id'
        device = online_operator.get_device(device_id, create_if_not_found=fake_device, platform='fake-dev' if fake_device else None)
        if fake_device:
            device.set_status(self.get_enum_argument('status', OperatorStatus.ALL, 'offline'))

        if not device:
            self.reject_request('init-required')
            return None
        return device.waiters_manager

    def on_revision_changed(self):
        if self._finished or self.request.connection.stream.closed():
            return

#        self.set_header("Content-Type", "application/json; charset=cp1251")
        self.set_header("Content-Type", "application/json; charset=UTF-8")
        response = self.get_response(self.get_since())
        self.finish(json.dumps(response))

    def on_timeout(self):
        super(OperatorDeltaRequestHandler, self).on_timeout()
        self.set_header("Content-Type", "application/json; charset=UTF-8")
        return "{}"

    def get_delta_manager(self):
        return self.get_account().oo_manager.get(self.get_operator_id()).delta_manager

    def get_context(self):
        return self.get_operator_context()

    def get_mode(self):
        return self.get_verified_argument('mode', 'full')

    def filter_delta(self, delta_list):
        if self.get_mode() == 'full':
            return delta_list
        return [d for d in delta_list if d.object_type == 'NOTIFICATION' or d.object_type == 'DEVICE_STATUS' or d.object_type == 'STATUS_MODIFIED_TS']

    def get_full_update(self):
        account = self.get_account()
        operator = self.get_operator()

        logging.warn("fullUpdate @" + account.name + " operator: " + str(operator.id) + " since: " + str(self.get_since()))

        online_operator = account.oo_manager.get(self.get_operator_id())
        visit_tracker = account.visit_tracker
        full_update = {}

        sessions = []
        for session_id in online_operator.get_related_session_ids():
            s = visit_tracker.get_session(session_id)
            if s:
                sessions.append(s)

        if self.get_mode() == 'full':
            full_update['visitSessionSections'] = account.cached_visit_session_sections.get_data()
            full_update['visitSessions'] = sessions

            key_to_department = {}
            for key, department in account.get_key_to_department(include_deleted=True).items():
                key_to_department[key] = department.to_dict()
            full_update['keyToDepartment'] = key_to_department

            id_to_operator = {}
            for id, o in account.get_operators().items():
                o_dict = o.to_dict(context={'mode': 'operator'})
                o_dict['status'] = account.oo_manager.get(id).get_status()
                id_to_operator[id] = o_dict
            full_update['idToOperator'] = id_to_operator

            full_update['operatorChat'] = account.operator_chat.to_dict()

        if account.auto_assign_controller.check_overlimit_chat_abilitity(online_operator.get_operator()):
            full_update['overlimitChatAbilitiy'] = True
        full_update['statusModifiedTs'] = online_operator.status_modified_ts
        full_update['notifications'] = online_operator.notification_manager.get_notifications()
        full_update['idToDevice'] = dict([(d.device_id, d.to_dict()) for d in online_operator.get_devices()])
        full_update['tId'] = wm_utils.tornado_instance_id[-6:]
        return full_update


class OperatorWebSocketDeltaRequestHandler(WebSocketHandler, OperatorDeltaRequestHandler):

    PING_STR = 'string for ping'

    def __init__(self, application, request, **kwargs):
        WebSocketHandler.__init__(self, application, request, **kwargs)
        self.account = None
        self.online_operator = None
        self.since = None
        self.waiter = None
        self.waiters_manager = None
        self.time_delta_timer = None

        self.write_response_lock = threading.Lock()

    def open(self):
        if not self._prepare():
            return

        logging.warning('WebSocket opened')
        self.set_nodelay(False)

        self.account = self.get_account()
        self.online_operator = self.account.oo_manager.get(self.get_operator_id())

        self.since = self.get_int_argument('since', 0)

        if self.get_argument('t-id') and self.get_argument('t-id') != wm_utils.tornado_instance_id:
            logging.warn('OperatorWSHandler %s: different tornado_instance_id' % (self.account.name))
            self.since = 0

        self.write_message(json.dumps({'connected': 'ok'}))

        self.waiter = waiter.Waiter(self.on_revision_changed, '', self)
        self.waiters_manager = self.get_waiters_manager()
        self.waiters_manager.add_waiter(self.since, self.waiter)

        # We use this timer for 2 reasons:
        #  1. for time shift detecting
        #  2. as "stay alive" pinger (Nginx close WebSocket connection after {PROXY_TIMEOUT} sec if no msgs were sent)
        self.time_delta_timer = wm_timer.timers_manager.add_timer(55, self.update_time_delta, 'ws checker')

    def update_time_delta(self):
        if self.ws_connection:
            self.write_message({'currentTs': time.time()})
            self.time_delta_timer = wm_timer.timers_manager.add_timer(55, self.update_time_delta, 'ws checker')
        else:
            self.time_delta_timer.cancel()

    def on_pong(self, data):
        return data == OperatorWebSocketDeltaRequestHandler.PING_STR

    def get_mode(self):
        return self.get_argument('mode')

    def get_since(self):
        return self.since

    def on_revision_changed(self):
        with self.write_response_lock:
            response = self.get_response(self.since)
            if response:
                self.since = response.get('revision')
                if 'deltaList' in response and not response.get('deltaList'):
                    return

                self.write_message(json.dumps(response))

    def on_close(self):
        try:
            self.waiters_manager.remove_waiter(self.waiter)
        except Exception as e:
            logging.error('%s' % str(e), exc_info=True)

        # logging.error('WebSocketHandler was closed')

    def on_message(self, message):
        request = json.loads(message)
        request_type = request.get('reqType', None)

        if request_type == 'action':
            start = time.time()
            if not request.get('reqId'):
                return

            result = self.online_operator.action_controller.process_ws_action(request)
            self.write_message(json.dumps([
                {'reqId': request.get('reqId'),
                 'reqResult': json.dumps(result)}
            ]))

            logging.warning('[GL operator_action] action:%s time:%.5f' % (request.get('reqParams', {}).get('action', 'unknown'), time.time() - start))

        elif request_type == 'getPendingResponses':
            result = self.online_operator.action_controller.get_pending_request_responses(request.get('pendingRequests'))
            self.write_message(json.dumps(result))

    def reject_request(self, details):
        self.write_message({'error': details})
        self.close()


class OperatorChatHistoryRequestHandler(wm_web.BaseWebimRequestHandler):

    @tornado.web.asynchronous
    def get(self, *args, **kwargs):
        wm_timer.invoke_async(self.process, 'OperatorChatHistoryRequest')

    def process(self):
        account = self.get_account()
        first_message_uid = self.get_verified_argument('first_message_uid')

        messages = account.operator_chat.get_messages_for_operator(first_message_uid)

        self.write(json.dumps(messages))
        self.finish()


class OperatorStatusesRequestHandler(wm_web.BaseWebimRequestHandler):

    @tornado.web.asynchronous
    def get(self, *args, **kwargs):
        wm_timer.invoke_async(self._get, 'GetOperatorStatusesRequest')

    def _get(self):
        account = self.get_account()
        operator_id_to_status = {op_id: account.oo_manager.get(op_id).get_status() for op_id in account.get_operators().keys()}
        self.finish(json.dumps(operator_id_to_status))


class CloseOfflineChatsRequestHandler(wm_web.BaseWebimRequestHandler):

    def requires_authorized_operator(self):
        return True

    def get(self, *args, **kwargs):

        department_key = self.get_verified_argument('departmentkey', '')
        count = self.get_int_argument('count', 50)

        closed_chats_amount = 0
        account = self.get_account()
        operator = self.get_operator()

        result = {'closed_chat_ids': [],
                  'not_closed_chats': [],
                  'result': 'ok',
                  'message': ''}

        filter = lambda offline_chat: offline_chat.state in [offline_chat.State.OFFLINE_QUEUE] \
            and offline_chat.session.department_key == department_key \
            and offline_chat.get_operator_id() is None

        chats = account.visit_tracker.get_chats(filter, True)

        if len(chats) > count:
            chats = chats[:count]

        for chat in chats:
            try:
                chat.process_event('operator.close', attrs={'operator_id': operator.id})
                result['closed_chat_ids'].append(chat.id)
                closed_chats_amount += 1
            except Exception as e:
                result['not_closed_chats'].append({'chat_id': chat.id, 'error': str(e)})
                result['result'] = 'got errors'

        result['message'] = str(closed_chats_amount) + ' chats were closed'

        self.write(json.dumps(result))


class CloseChatsRequestHandler(wm_web.BaseWebimRequestHandler):

    def requires_authorized_operator(self):
        return True

    def get(self, *args, **kwargs):

        ids_str = self.get_verified_argument('ids', pattern='^[\w,]+$')
        ids = set([int(id) for id in ids_str.split(',')])

        closed_chats_amount = 0
        account = self.get_account()
        operator = self.get_operator()

        result = {'closed_chat_ids': [],
                  'not_closed_chats': [],
                  'result': 'ok',
                  'message': ''}

        for offline in [True, False]:
            chats = account.visit_tracker.get_chats(lambda ch: ch.id in ids, offline)

            for ch in chats:
                try:
                    ch.process_event('operator.close', attrs={'operator_id': operator.id})
                    result['closed_chat_ids'].append(ch.id)
                    closed_chats_amount += 1
                except Exception as e:
                    result['not_closed_chats'].append({'chat_id': ch.id, 'error': str(e)})
                    result['result'] = 'got errors'

        result['message'] = str(closed_chats_amount) + ' chats were closed'

        self.write(json.dumps(result))


class OperatorActionRequestHandler(wm_web.BaseWebimRequestHandler):

    def requires_account_not_blocked(self):
        return True

    def requires_authorized_operator(self):
        return True

    def get(self, *args, **kwargs):
        self.post(*args, **kwargs)

    def post(self, *args, **kwargs):
        self.set_header("Content-Type", "application/json")

        action = self.get_verified_argument('action')
        account = self.get_account()

        data = {
            'session_id': self.get_argument('session_id', None)
        }

        if action == 'accept_visitor':
            data['confirmed'] = self.get_bool_argument('confirmed', False)
        elif action == 'redirect_visitor':
            data['redirect_type'] = self.get_verified_argument('redirect_type', 'operators')
            data['redirect_id'] = (self.get_verified_argument('redirect_id', None)
                                   or self.get_verified_argument('target_operator_id', None) if data['redirect_type'] == 'operators' else
                                   self.get_verified_argument('redirect_id', ''))  # no_department hack
            data['requested_by_operator_id'] = self.get_operator_id()
        elif action == 'send_chat_to_operator_email':
            data['target_operator_id'] = self.get_int_argument('target_operator_id')
        elif action == 'operator_typing':
            data['typing'] = self.get_bool_argument('typing')
        elif action == 'operator_note':
            data['message'] = self.get_argument('message')
        elif action == 'message' or action == 'invite_visitor':
            data['aux'] = self.get_argument('aux', None)
            data['message'] = self.get_argument('message')
            data['client-side-id'] = self.get_verified_argument('client-side-id', None)
        elif action == 'edit_message':
            data['client-side-id'] = self.get_verified_argument('client-side-id', None)
            data['text'] = self.get_argument('text', None)
        elif action == 'delete_message':
            data['client-side-id'] = self.get_verified_argument('client-side-id', None)
        elif action == 'close_chat':
            pass
        elif action == 'ban_visitor':
            pass
        elif action == 'set_chat_read_by_operator':
            pass
        elif action == 'request_identification':
            data['identification_type'] = self.get_verified_argument('identification_type')
        elif action == 'request_contacts':
            data['client-side-id'] = self.get_verified_argument('client-side-id', None)
        elif action == 'set_category':
            data['category'] = self.get_argument('category', None)
            data['subcategory'] = self.get_argument('subcategory', None)
        elif action == 'disconnect_operator':
            data['operator_id'] = self.get_int_argument('operator_id')
        elif action == 'disconnect_all_operators':
            pass
        elif action == 'upload_file':
            data['files'] = self.request.files
            data['client-side-id'] = self.get_verified_argument('client-side-id', None)
        elif action == 'upload_file_start_message':
            data['filename'] = self.get_argument('filename', None)
            data['message'] = self.get_argument('message', None)
        elif action == 'new_visitor_notification_close':
            pass
        elif action == 'teleport_visitor':
            data['page_id'] = self.get_verified_argument('page_id')
            data['url'] = self.get_argument('url')
        elif action == 'set_visitor_fields':
            data['fields'] = self.get_argument('fields')
        elif action == 'manually_assign_operator':
            data['operator_id'] = self.get_int_argument('operator_id')
        elif action == 'request_form':
            data['form_id'] = self.get_verified_argument('form_id', None)
        elif action == 'create_zendesk_ticket':
            data['ticket_data'] = self.get_argument('ticket_data', None)
        elif action == 'start_cobrowsing':
            pass
        elif action == 'stop_cobrowsing':
            pass
        elif action == 'operator_chat_message':
            data['message'] = self.get_argument('message')
            data['uid'] = self.get_verified_argument('uid')
        elif action == 'set_tags':
            data['tags'] = self.get_argument('tags', [])
        elif action == 'update_visitor_fields':
            data['fields'] = self.get_argument('fields', None)
        elif action == 'on_chat_timer':
            data['message_id'] = self.get_argument('message_id')
        elif action == 'add_word_to_spelling_dict':
            data['word'] = self.get_argument('word')
        elif action == 'siebel_button_click':
            pass
        elif action == 'select_session':
            data['previous_session_chat_id'] = self.get_int_argument('previous_session_chat_id')
        elif action == 'action_request':
            data['sub_kind'] = self.get_verified_argument('sub_kind')
            data['state'] = self.get_verified_argument('state', default='pending')
            data['extra'] = self.get_argument('extra')
        elif action == 'assign_overlimit_chat':
            pass
        result = account.oo_manager.get(self.get_operator_id()).action_controller.process_action(data, action=action)

        self.finish(json.dumps(result))

    def get_session(self):
        session_id = self.get_verified_argument('session_id')
        return self.get_account().visit_tracker.get_session(session_id)


class BaseOperatorRequestHandler(wm_web.BaseWebimRequestHandler):

    def requires_account_not_blocked(self):
        return True

    def requires_authorized_operator(self):
        return True


class BaseDeviceStatusRequestHandler(BaseOperatorRequestHandler):
    def prepare(self):
        self.set_header("Content-Type", "application/json")
        super(BaseDeviceStatusRequestHandler, self).prepare()

    def _process(self, device):
        pass

    def _get_os(self):
        pass

    def get(self, *args, **kwargs):
        online_operator = self.get_account().oo_manager.get(self.get_operator_id())
        push_token = self.get_verified_argument('push-token', None)
        if push_token == '0000':
            push_token = None

        logging.warn("Got push token %s" % push_token)

        device_id = self.get_verified_argument('device-id')

        backdoor_login = self.get_cookie('backdoor')
        device = online_operator.get_device(device_id, self.get_header('User-Agent', ''), push_token, self._get_os(), backdoor_login=backdoor_login)

        should_store = False

        if device.backdoor_login != backdoor_login:
            device.backdoor_login = backdoor_login
            should_store = True

        if push_token is not None and device.push_token != push_token:
            logging.warn("Should store")
            device.push_token = push_token
            should_store = True

        user_agent = self.get_header('User-Agent', None)
        if user_agent is not None and user_agent != device.user_agent:
            device.user_agent = user_agent
            should_store = True

        if should_store:
            device.store()

        self._process(device)


class SetStatusRequestHandler(BaseDeviceStatusRequestHandler):

    def _get_os(self):
        return self.get_verified_argument('platform')  # todo enum

    def _process(self, device):
        status = self.get_enum_argument('status', OperatorStatus.ALL)
        oo = device.online_operator
        result = device.set_status(status)
        self.write(json.dumps({'result': result} if result == 'ok' else {'error': result}))

        logging.warn(
            'Device set status %s, %d, %s, %s, %s, %s',
            oo.account.name, oo.operator_id, device.device_id, status, self.get_argument('push-token', None), self.get_header('User-Agent', None)
        )


class BaseAndroidStatusRequestHandler(BaseDeviceStatusRequestHandler):
    def _get_os(self):
        return 'android'


class AndroidGetStatusRequestHandler(BaseDeviceStatusRequestHandler):

    def _process(self, device):
        status = device.status
        self.write(json.dumps({'status': status}))


class AndroidSetStatusRequestHandler(BaseAndroidStatusRequestHandler):

    def _process(self, device):
        status = self.get_enum_argument('status', OperatorStatus.ALL)
        result = device.set_status(status)
        self.write(json.dumps({'result': result} if result == 'ok' else {'error': result}))

        logging.warn(
            'android set status %s, %d, %s, %s, %s, %s',
            device.online_operator.account.name, device.online_operator.operator_id, device.device_id, status,
            self.get_argument('push-token', None), self.get_header('User-Agent', None)
        )


class BaseIosStatusRequestHandler(BaseDeviceStatusRequestHandler):
    def _get_os(self):
        return 'ios'


class IosGetStatusRequestHandler(BaseIosStatusRequestHandler):

    def _process(self, device):
        status = device.status
        self.write(json.dumps({'status': status}))


class IosSetStatusRequestHandler(BaseIosStatusRequestHandler):

    def _process(self, device):  # todo review
        status = self.get_enum_argument('status', OperatorStatus.ALL)
        push_token = self.get_argument('push-token', None)

        should_store = False
        if push_token is not None and device.push_token != push_token:
            device.push_token = push_token
            should_store = True

        user_agent = self.get_header('User-Agent', None)
        if user_agent is not None and user_agent != device.user_agent:
            device.user_agent = user_agent
            should_store = True

        if should_store:
            device.store()

        logging.warn(
            'ios set status %s, %d, %s, %s, %s, %s',
            device.online_operator.account.name, device.online_operator.operator_id, device.device_id, status, push_token, user_agent
        )

        result = device.set_status(status)
        self.write(json.dumps({'result': result} if result == 'ok' else {'error': result}))


class InfSetStatusRequestHandler(BaseDeviceStatusRequestHandler):

    def _get_os(self):
        return 'inf'

    def _process(self, device):
        status = self.get_enum_argument('status', OperatorStatus.ALL)
        result = device.set_status(status)
        self.write(json.dumps({'result': result} if result == 'ok' else {'error': result}))


class OperatorDevicesRequestHandler(BaseOperatorRequestHandler):

    def get(self, *args, **kwargs):
        result = {}
        platform = self.get_verified_argument('platform', None)
        backdoor_login = self.get_cookie('backdoor')
        context = {'dev_list_request': True, 'backdoor_login': backdoor_login}
        for oo in self.get_account().oo_manager.get_online_operators():
            result[oo.operator_id] = [d.to_dict(context) for d in oo.get_devices()
                                      if (d.platform == platform or platform is None) and (backdoor_login or not d.backdoor_login)]

        self.write(result)


class SetDeviceStatusRequestHandler(wm_web.AdminRequestHandler):

    def get(self, *args, **kwargs):
        account = self.get_account()
        operator_id = self.get_int_argument('operator-id')
        device_id = self.get_verified_argument('device-id')
        status = self.get_enum_argument('status', OperatorStatus.ALL)

        online_operator = account.oo_manager.get(operator_id)
        device = online_operator.get_device(device_id, create_if_not_found=False)
        if device:
            device.set_status(status)


class OperatorsListRequestHandler(wm_web.CrossDomainRequestHandler):
    def get(self, *args, **kwargs):
        if self.get_account().settings.get('enum_operators') == 'true':
            wm_timer.invoke_async(self.get_operators_list, 'enum_operators')
        else:
            raise tornado.web.HTTPError(404)

    def get_operators_list(self):
        operators = {}
        base_url = "http://" + self.get_account_name() + '.pro-service.' + wm_settings.settings['base_domain']
        for id, o in self.get_account().get_operators().items():
            avatar_url = (base_url + o.avatar) if o.avatar else None
            operators[id] = {
                'fullname': o.fullname,
                'avatar': avatar_url,
                'isOnline': False
            }

        aoos = self.get_account().oo_manager.get_alive_online_operators()
        for oo in aoos:
            o = oo.get_operator()
            operators[o.id]['isOnline'] = True

        wm_utils.invoke_in_ioloop(lambda: self.send_result(operators), name='enum_operators')


class OperatorsListAdmRequestHandler(wm_web.AdminRequestHandler):
    def get(self, *args, **kwargs):
        operators = {}
        accountname = self.get_verified_argument('account-name', None)
        if accountname:
            acc = account.BriefAccount.get(accountname)
            for id, o in acc.get_operators().items():
                operators[id] = o.to_dict()
            del acc
        self.send_result(operators)


class OperatorOnlineOperatorsListRequestHandler(wm_web.BaseWebimRequestHandler):

    def requires_account_not_blocked(self):
        return True

    def requires_authorized_operator(self):
        return True

    def get(self, *args, **kwargs):
        current_op_id = self.get_operator_id()
        result = {'operators': [], 'departments': [], 'locales': []}
        key_to_dep = self.get_account().get_key_to_department()

        temp_result = {'operators': {}, 'departments': {}, 'locales': []}

        woos = self.get_account().oo_manager.get_working_online_operators()

        for oo in woos:
            o = oo.get_operator()
            if self.get_account().get_tariff_setting('departments', False):
                for dep_key in o.department_keys:
                    dep = key_to_dep.get(dep_key, None)

                    if dep and dep_key not in temp_result['departments']:
                        dep_dict = dep.to_dict()
                        dep_dict['status'] = oo.get_status()
                        temp_result['departments'][dep_key] = dep_dict
                    else:
                        temp_result['departments'][dep_key]['status'] = OperatorStatus.get_more_priority_status(
                            temp_result['departments'][dep_key]['status'], oo.get_status()
                        )

            if o.id != current_op_id:
                dict_op = o.to_dict({'mode': 'operator'})
                dict_op['status'] = oo.get_status()
                result['operators'].append(dict_op)

            for locale in o.locales:
                if locale not in result['locales']:
                    result['locales'].append(locale)

        for dep in temp_result['departments'].values():
            result['departments'].append(dep)

        def key_getter(item):
            return item['order']

        result['departments'].sort(key=key_getter)

        self.write(json.dumps(result))


class Department:
    def __init__(self, account, id, key, order, is_hidden, deleted, department_settings=None, geo=None):
        self.account = account
        self.id = id
        self.key = key
        self.order = order
        self.locale_to_name = {}
        self.is_hidden = is_hidden
        self.settings = department_settings or {}
        self.geo = geo or ''
        self.deleted = deleted

    def get_name(self, lang=None):
        default_lang = self.account.get_setting('default_lang')
        return self.locale_to_name.get(lang) or self.locale_to_name.get(default_lang) or self.locale_to_name.itervalues().next()

    def get_shown_department_name(self, context):
        shown_department_name = ''
        o = self.account.get_operator(context.get('operator_id'))
        if o:
            if self.key and len(o.department_keys) != 1:
                shown_department_name = self.get_name(context.get('lang'))

        return shown_department_name

    def to_dict(self, context=None):
        context = context or {}
        return {
            # 'id': self.id,
            'key': self.key,
            'order': self.order,
            'localeToName': self.locale_to_name,  # todo remove use name instead
            'name': self.get_name(context.get('lang')),
            'logo': self.settings.get('logo')
        }

    @classmethod
    def get_departments_for_location(cls, account, chat_location_settings, lang_to_geo):
        departments = account.get_key_to_department().values()

        departments = [d for d in departments if d.key != '' and not d.is_hidden]

        available_department_keys = chat_location_settings.get('availableDepartmentKeys') if account.get_tariff_setting('available_departments_for_location') else None  # noqa: E501
        if available_department_keys:
            departments = [d for d in departments if d.key in available_department_keys]

        default_lang = account.get_setting('default_lang')
        # todo use all available geo
        geo = ip_info.IPInfo.get_geo_by_lang(lang_to_geo, default_lang)

        result = cls.__filter_departments_by_geo(departments, geo)
        if not result:
            result = cls.__filter_departments_by_geo(departments, geo, all_cities=True)
        if not result:
            result = cls.__filter_departments_by_geo(departments, geo, all_cities=True, all_countries=True)

        return result

    @classmethod
    def __filter_departments_by_geo(cls, departments, geo, all_cities=False, all_countries=False):
        country_name = u'все_страны' if all_countries else (geo['country_name'] if geo else None)
        city = u'все_города' if all_cities else (geo['city'] if geo else None)
        result = []
        for d in departments:
            if geo is None or country_name in d.geo and city in d.geo:
                result.append(d)
        return result

    @classmethod
    def get_departments_with_online_status_dict(cls, visited_page, lang_to_geo):
        account = visited_page.visit_session.account
        chat_location_settings = visited_page.get_location_settings().get('chat', {})
        result = []
        for d in cls.get_departments_for_location(account, chat_location_settings, lang_to_geo):
            dicted = d.to_dict()
            dicted['online'] = account.oo_manager.get_online_state(visited_page.lang, d.key)
            if dicted['online'] in [OnlineState.ONLINE, OnlineState.BUSY_ONLINE] or not chat_location_settings.get('hideOfflineDepartments', False):
                result.append(dicted)

        result.sort(key=lambda dicted: dicted['order'])
        return result


class DepartmentDelta(wm_utils.Jsonable):

    def __init__(self, department, lang):
        self.department = department
        self.lang = lang

    def to_dict(self, context=None):
        result = {
            'departmentKey': self.department.key if self.department else '',
            'lang': self.lang,
            'shownDepartmentName': self.department.get_shown_department_name(context) if self.department else ''
        }

        return result


class CachedDepartments(wm_utils.CachedDBData):

    def __init__(self, account):
        self.account = account
        wm_utils.CachedDBData.__init__(self, account.name, reload_immediately_after_reset=True)

    def load_data(self, connection):
        dep_rows = connection.query('select * from chatdepartment')
        id_to_dep = {}
        key_to_dep = {}
        for row in dep_rows:
            if 'config' in row and row['config']:
                department_settings = json.loads(row['config'])
            else:
                department_settings = {}

            dep = Department(
                self.account, row['departmentid'], row['departmentkey'], row['departmentorder'],
                False if row['ishidden'] == 0 else True,  # TODO WTF?
                bool(row['deleted']), department_settings, row['departmentgeo']
            )

            id_to_dep[dep.id] = dep
            key_to_dep[dep.key] = dep
        dep_locale_rows = connection.query('select * from chatdepartmentlocale')
        for loc_row in dep_locale_rows:
            dep = id_to_dep[loc_row['departmentid']]
            dep.locale_to_name[loc_row['locale']] = loc_row['departmentname']

        empty_dep = Department(self.account, 0, '', -1, False, False)
        acc = account.Account.get(self.account.name)
        for locale in acc.get_available_locale_ids():
            empty_dep.locale_to_name[locale] = wm_resources.get_resource(acc, locale, 'department.without_department')
        key_to_dep[empty_dep.key] = empty_dep
        return key_to_dep

    def on_data_renewed(self, cached, obtained):
        if cached is not None:
            for key in obtained.keys():
                cached_dep = cached.get(key)
                loaded_dep = obtained.get(key)
                if cached_dep and loaded_dep:
                    if not cached_dep.deleted and loaded_dep.deleted:
                        create_target = lambda dep: lambda: chat.Chat.unset_deleted_department_in_chats(self.account, dep)
                        wm_timer.invoke_async(create_target(loaded_dep), 'unset_department_for_chats_in_queue')


class CachedRealtimeStatistics(wm_utils.CachedData):

    def __init__(self, account):
        super(CachedRealtimeStatistics, self).__init__()
        self.account = account

    def get_timeout(self):
        return self.account.get_setting('dashboard_realtime_update_interval')

    def get_formatted_stats(self, sv_dep_ids=None, context=None):
        lang = context.get('lang')
        stats = copy.deepcopy(self.get_data())

        if sv_dep_ids:
            sv_dep_keys = {key for key, dep in self.account.get_key_to_department().items() if dep.id in sv_dep_ids}
            stats['chatsByOperator'] = {dep_key: chat_by_op for dep_key, chat_by_op in stats['chatsByOperator'].items() if dep_key in sv_dep_keys}
            stats['chatsByDepartment'] = [chat_by_dep for chat_by_dep in stats['chatsByDepartment'] if chat_by_dep['departmentKey'] in sv_dep_keys]

        for chats_by_dep in stats['chatsByDepartment']:
            chats_by_dep['department'] = self.account.get_department(chats_by_dep['departmentKey'], include_deleted=True).to_dict(context)

        for dep_key, chats_by_ops_stats in stats['chatsByOperator'].items():
            chats_by_ops_stats['departmentName'] = self.account.get_department(dep_key, include_deleted=True).get_name(lang)

            for op_id, op_stats in chats_by_ops_stats['operators'].items():
                if self.account.get_operator(op_id):
                    op_stats['fullname'] = self.account.get_operator(op_id).get_fullname(lang)

        stats['update_interval'] = self.get_timeout()

        return stats

    def obtain_data(self):
        waiting_now = 0
        chatting_now = 0
        filter = lambda ch: ch.state in [chat.Chat.State.QUEUE, chat.Chat.State.CHATTING,
                                         chat.Chat.State.CLOSED_BY_VISITOR]
        for ch in self.account.visit_tracker.get_chats(filter):
            if ch.state == chat.Chat.State.QUEUE and not ch.get_operator_id():
                waiting_now += 1
            else:
                chatting_now += 1

        stats = {
            'chats': {
                'waiting_now': waiting_now,
                'chatting_now': chatting_now
            },
            'chatsByDepartment': self.get_chats_by_department(),
            'operators': {
                'online_now': len(self.account.oo_manager.get_alive_online_operators())
            },
            'chatsByOperator': self.get_stats_by_operators(),
            'visitors': {
                'online_now': self.account.visit_tracker.get_online_alive_sessions_count()
            }
        }

        return stats

    def get_chats_by_department(self):
        visit_tracker = self.account.visit_tracker
        key_to_offline_stats = wm_utils.DictExt(lambda k: {'waiting': 0, 'max_waiting_time': 0})
        for s in visit_tracker.get_sessions_by_filter_name(kind=visitor_tracking.VisitSession.Kind.OFFLINE_CHAT, filter_name='chats'):
            chat_stats = key_to_offline_stats.get(s.department_key)
            chat_stats['waiting'] += 1
            if s.chat.state == chat.Chat.State.OFFLINE_QUEUE and time.time() - s.chat.modification_ts > chat_stats['max_waiting_time']:
                chat_stats['max_waiting_time'] = time.time() - s.chat.modification_ts

        key_to_online_stats = wm_utils.DictExt(lambda k: {'waiting': 0, 'in_process': 0, 'max_waiting_time': 0})
        filter = lambda ch: ch.state in [chat.Chat.State.QUEUE, chat.Chat.State.CHATTING, chat.Chat.State.CLOSED_BY_VISITOR]
        for ch in self.account.visit_tracker.get_chats(filter):
            chat_stats = key_to_online_stats.get(ch.session.department_key)
            if ch.state == chat.Chat.State.QUEUE and not ch.get_operator_id():
                chat_stats['waiting'] += 1
                if time.time() - ch.modification_ts > chat_stats['max_waiting_time']:
                    chat_stats['max_waiting_time'] = time.time() - ch.modification_ts
            else:
                chat_stats['in_process'] += 1
        departments = sorted(self.account.get_key_to_department().values(), key=lambda d: d.order)

        return [{'department': None,
                 'departmentKey': d.key,
                 'offline': key_to_offline_stats.get(d.key),
                 'online': key_to_online_stats.get(d.key)} for d in departments]

    def get_stats_by_operators(self):
        result = {}

        for operator in self.account.get_operators().values():
            oo = self.account.oo_manager.get(operator.id)
            if oo and not oo.is_offline():
                for dep_key in operator.department_keys:
                    result = self.add_operator_and_department_to_result(dep_key, operator.id, result)

        filter = lambda ch: ch.state in [chat.Chat.State.QUEUE, chat.Chat.State.CHATTING, chat.Chat.State.CLOSED_BY_VISITOR]

        for ch in self.account.visit_tracker.get_chats(filter):
            dep_key = ch.session.department_key
            op_id = ch.get_operator_id()

            result = self.add_operator_and_department_to_result(dep_key, op_id, result)
            if op_id in result[dep_key]['operators']:
                result[dep_key]['operators'][op_id]['threads_now'] += 1

        return result

    def add_operator_and_department_to_result(self, dep_key, operator_id, result):

        if dep_key not in result:
            if dep_key != '':
                dep = self.account.get_department(dep_key, include_deleted=True)
                if dep:
                    result[dep_key] = {'departmentName': None,
                                       'operators': {}}
            else:
                result[dep_key] = {'departmentName': None,
                                   'operators': {}}

        if operator_id not in result[dep_key]['operators']:
            operator = self.account.get_operator(operator_id)
            oo = self.account.oo_manager.get(operator_id)
            if oo:
                online_period = oo.lang_and_dep_to_online_period.get((None, dep_key or None))

                result[dep_key]['operators'][operator_id] = {
                    'id': operator.id,
                    'fullname': None,
                    'status': oo.get_status(),
                    # 'avg_answer_time': 0,
                    # 'threads_hour': 0,
                    'threads_now': 0,
                    'ts_diff_in_current_status': time.time() - online_period.ts_from if online_period else None
                }

        return result


class CachedPrevPeriodsStatistics(wm_utils.CachedData):

    def __init__(self, account):
        super(CachedPrevPeriodsStatistics, self).__init__()
        self.account = account

    def get_timeout(self):
        return self.account.get_setting('dashboard_prev_periods_update_interval')

    def get_formatted_stats(self, sv_dep_ids=None, context=None):
        lang = context.get('lang')
        stats = copy.deepcopy(self.get_data())

        for dep_key, dep_stats in stats['chatsByOperator'].items():
            dep_stats['departmentName'] = self.account.get_department(dep_key, include_deleted=True).get_name(lang)

            for op_id, op_stats in dep_stats['operators'].items():
                if self.account.get_operator(op_id):
                    op_stats['fullname'] = self.account.get_operator(op_id).get_fullname(lang)

        if stats.get('department_extended'):
            for dep_key, dep_stats in stats['department_extended']['departments'].items():
                dep_stats['department_name'] = self.account.get_department(dep_key, include_deleted=True).get_name(lang)

            stats['department_extended']['total']['department_name'] = wm_resources.get_resource(self.account, lang, 'dashboard.total')

        if stats.get('operator_extended'):
            for op_id, op_stats in stats['operator_extended'].items():
                if self.account.get_operator(op_id):
                    op_stats['fullname'] = self.account.get_operator(op_id).get_fullname(lang)

        stats['update_interval'] = self.get_timeout()

        return stats

    def obtain_data(self):
        conn = db_utils.get_connection(self.account.name)
        conn.execute('SET SQL_BIG_SELECTS=1')
        conn.execute('SET SESSION TRANSACTION ISOLATION LEVEL READ UNCOMMITTED')

        query = '''SELECT
                        (SELECT count(threadid) AS threads
                         FROM chatthread t
                         WHERE (NOT threadkind IN ("skip",
                                                   "undefined")
                                OR threadkind="undefined"
                                AND NOT EXISTS
                                  (SELECT *
                                   FROM chatthreadhistory h
                                   WHERE `event`="sys.auto_close"
                                     AND h.threadid = t.threadid
                                     AND h.number =
                                       (SELECT max(h2.number)
                                        FROM chatthreadhistory h2
                                        WHERE h2.threadid = t.threadid)))
                           AND created > date_sub(now(), INTERVAL 1 HOUR)) AS threads_hour,

                        (SELECT count(threadid) AS threads
                         FROM chatthread t
                         WHERE (NOT threadkind IN ("skip",
                                                   "undefined")
                                OR threadkind="undefined"
                                AND NOT EXISTS
                                  (SELECT *
                                   FROM chatthreadhistory h
                                   WHERE `event`="sys.auto_close"
                                     AND h.threadid = t.threadid
                                     AND h.number =
                                       (SELECT max(h2.number)
                                        FROM chatthreadhistory h2
                                        WHERE h2.threadid = t.threadid)))
                           AND created >= DATE(NOW())) AS threads_day,

                        (SELECT count(DISTINCT h1.threadid) AS missed
                         FROM chatthread t
                         INNER JOIN chatthreadhistory h1 ON h1.threadid = t.threadid
                         INNER JOIN chatthreadhistory h2 ON h2.threadid = t.threadid AND h1.number + 1 = h2.number 
                         WHERE 1=1
                           AND h1.state = "queue"
                           AND h2.state = "closed"
                           AND unix_timestamp(h2.dtm) - unix_timestamp(h1.dtm) >= ifnull((SELECT configvalue FROM chatconfig WHERE configkey = "seconds_before_visitor_missed"), 0)
                           AND h2.dtm > date_sub(now(), INTERVAL 1 HOUR)) AS missed_hour,

                        (SELECT count(DISTINCT h1.threadid) AS missed
                         FROM chatthread t
                         INNER JOIN chatthreadhistory h1 ON h1.threadid = t.threadid
                         INNER JOIN chatthreadhistory h2 ON h2.threadid = t.threadid AND h1.number + 1 = h2.number 
                         WHERE 1=1
                           AND h1.state = "queue"
                           AND h2.state = "closed"
                           AND unix_timestamp(h2.dtm) - unix_timestamp(h1.dtm) >= ifnull((SELECT configvalue FROM chatconfig WHERE configkey = "seconds_before_visitor_missed"), 0)
                           AND h2.dtm >= DATE(NOW())) AS missed_day,

                        (SELECT avg(unix_timestamp(dtm2) - unix_timestamp(dtm1)) AS avg_answer_time
                         FROM chatthread t
                         INNER JOIN chatthreadhistoryview h ON t.threadid = h.threadid
                         WHERE state1 = "queue"
                           AND state2 = "chatting"
                           AND number1 = 1
                           AND t.created > date_sub(now(), INTERVAL 1 HOUR)) AS avg_answer_time_hour,

                        (SELECT avg(unix_timestamp(dtm2) - unix_timestamp(dtm1)) AS avg_answer_time
                         FROM chatthread t
                         INNER JOIN chatthreadhistoryview h ON t.threadid = h.threadid
                         WHERE state1 = "queue"
                           AND state2 = "chatting"
                           AND number1 = 1
                           AND t.created >= DATE((NOW()))) AS avg_answer_time_day'''  # noqa: E501
        stats_row = conn.get(query)

        stats = {
            'hour': {
                'threads': stats_row['threads_hour'],
                'missed': stats_row['missed_hour'],
                'avg_answer_time': float(stats_row['avg_answer_time_hour']) if stats_row[
                    'avg_answer_time_hour'] else 0
            },
            'day': {
                'threads': stats_row['threads_day'],
                'missed': stats_row['missed_day'],
                'avg_answer_time': float(stats_row['avg_answer_time_day']) if stats_row[
                    'avg_answer_time_day'] else 0
            },
            'chatsByOperator': self.get_prev_periods_stats_by_department_and_operator(),
            'update_interval': self.account.get_setting('dashboard_prev_periods_update_interval')
        }
        conn.execute('SET SESSION TRANSACTION ISOLATION LEVEL REPEATABLE READ')
        conn.close()

        if self.account.settings.get('extended_dashboard'):
            stats['operator_extended'] = self.get_prev_periods_stats_by_operator()
            stats['department_extended'] = self.get_prev_period_stats_by_department()

        return stats

    def get_prev_periods_stats_by_operator(self):
        result = {}

        conn = db_utils.get_connection(self.account.name)
        conn.execute('SET SESSION TRANSACTION ISOLATION LEVEL READ UNCOMMITTED')
        query = '''SELECT operatorid,
                        COUNT(*) message_count
                        FROM chatmessage
                        WHERE created > date_sub(now(), INTERVAL 1 DAY) AND kind = 2
                        GROUP BY operatorid'''
        message_count_rows = conn.query(query)
        if message_count_rows:
            for row in message_count_rows:
                result[row['operatorid']] = {
                    'message_count': int(row['message_count'])
                }

        query = '''SELECT operatorid,
                        COUNT(DISTINCT threadid) thread_count
                        FROM chatthreadhistory
                        WHERE dtm > date_sub(now(), INTERVAL 1 DAY) AND operatorid IS NOT NULL
                        GROUP BY operatorid'''
        thread_count_rows = conn.query(query)
        if thread_count_rows:
            for row in thread_count_rows:
                if row['operatorid'] not in result:
                    result[row['operatorid']] = {}
                result[row['operatorid']]['thread_count'] = int(row['thread_count'])

        query = '''SELECT operatorid,
                      SUM(TIMESTAMPDIFF(SECOND, startPeriod, endPeriod)) time_in_system,
                      SUM(IF(status = 'online', TIMESTAMPDIFF(SECOND, startPeriod, endPeriod), 0)) ready_time,
                      SUM(IF(status <> 'online', TIMESTAMPDIFF(SECOND, startPeriod, endPeriod), 0)) not_ready_time
                      FROM (
                        SELECT GREATEST(dtmfrom, date_sub(now(), INTERVAL 1 DAY)) as startPeriod,
                        dtmfrom,
                        dtmto as endPeriod,
                        status, operatorid
                        FROM chatonlineperiod
                        WHERE
                          dtmto > date_sub(now(), INTERVAL 1 DAY)
                          AND departmentid IS null
                          AND locale IS null
                      ) op
                      GROUP BY operatorid'''
        period_time_rows = conn.query(query)
        if period_time_rows:
            for row in period_time_rows:
                if row['operatorid'] not in result:
                    result[row['operatorid']] = {}
                result[row['operatorid']]['time_in_system'] = int(row['time_in_system'])
                result[row['operatorid']]['ready_time'] = int(row['ready_time'])
                result[row['operatorid']]['not_ready_time'] = int(row['not_ready_time'])

        query = '''SELECT operatorid, unix_timestamp(dtmfrom) as dtmfrom, unix_timestamp(dtmto) as dtmto, status,
                   TIMESTAMPDIFF(SECOND, dtmfrom, dtmto) as last_state_time
                   FROM chatonlineperiod op
                   JOIN (
                      SELECT MAX(id) as id
                        FROM chatonlineperiod op1
                        WHERE
                          op1.dtmto > date_sub(now(), INTERVAL 7 DAY)
                          AND op1.departmentid IS null
                          AND op1.locale IS null
                        GROUP BY op1.operatorid
                   ) sub ON op.id = sub.id'''
        last_state_rows = conn.query(query)
        if last_state_rows:
            for row in last_state_rows:
                if row['operatorid'] not in result:
                    result[row['operatorid']] = {}
                result[row['operatorid']]['last_state_time'] = int(row['last_state_time'])
                if row['dtmto'] < time.time() - 15 * 60:
                    result[row['operatorid']]['last_logout_ts'] = int(row['dtmto'])

        query = '''SELECT
                        op1.operatorid as operatorid,
                        unix_timestamp(MAX(op1.dtmto)) as dtmfrom,
                        unix_timestamp(MAX(op2.dtmfrom)) as dtmto
                    FROM
                        (
                        SELECT @row1:=@row1 + 1 as number,
                        dtmfrom, dtmto, status, operatorid
                        FROM
                            chatonlineperiod,
                            (SELECT @row1:=0) r
                        WHERE dtmto > date_sub(NOW(), interval 7 day)
                            AND departmentid IS NULL AND locale IS NULL
                        ORDER BY operatorid, id
                    ) as op1
                    JOIN (SELECT
                        @row2:=@row2 + 1 as number,
                        dtmfrom, dtmto, status, operatorid
                    FROM
                        chatonlineperiod,
                        (SELECT @row2:=0) r2
                        WHERE dtmto > date_sub(NOW(), interval 7 day)
                        AND departmentid IS NULL AND locale IS NULL
                        ORDER BY operatorid, id
                    ) op2 ON op1.operatorid = op2.operatorid AND op1.number + 1 = op2.number
                    WHERE
                        TIMESTAMPDIFF(SECOND, op1.dtmto, op2.dtmfrom) > 15 * 60
                    GROUP BY operatorid'''
        last_long_offline_rows = conn.query(query)
        if last_long_offline_rows:
            for row in last_long_offline_rows:
                if row['operatorid'] not in result:
                    result[row['operatorid']] = {}
                result[row['operatorid']]['last_login_ts'] = int(row['dtmto'])
                if 'last_logout_ts' not in result[row['operatorid']]:
                    result[row['operatorid']]['last_logout_ts'] = int(row['dtmfrom'])

        conn.execute('SET SESSION TRANSACTION ISOLATION LEVEL REPEATABLE READ')
        conn.close()

        for operator_id, operator_stat in result.iteritems():
            operator = self.account.get_operator(operator_id)
            oo = self.account.oo_manager.get(operator_id)
            if oo:
                operator_stat['id'] = operator.id
                operator_stat['fullname'] = None
                operator_stat['status'] = oo.get_status()

        return result

    def get_prev_period_stats_by_department(self):
        departments = {}
        total = {
            'department_name': None,
            'thread_count': 0,
            'chat_count': 0,
            'missed_count': 0,
            'bounce_5s_count': 0,
            'not_bounce_5s_count': 0,
            'avg_common_queue_waiting_time': 0
        }

        conn = db_utils.get_connection(self.account.name)
        conn.execute('SET SESSION TRANSACTION ISOLATION LEVEL READ UNCOMMITTED')
        query = '''select
                        count(distinct h1.threadid) as thread_count,
                        sum(if(h1.state2 = "chatting", 1, 0)) as chat_count,
                        sum(if(h1.state1 = "queue" and h1.state2 = "closed", 1, 0)) as missed_count,
                        sum(if(h1.state1 = "queue" and h1.state2 = "closed" and timestampdiff(second, h1.dtm1, h1.dtm2) <= 5, 1, 0)) as bounce_5s_count,
                        sum(if(h1.state1 = "queue" and h1.state2 = "closed" and timestampdiff(second, h1.dtm1, h1.dtm2) > 5, 1, 0)) as not_bounce_5s_count,
                        sum(
                          if(h1.state1 = "queue" and h1.operatorid1 IS NULL and (h1.state2 = "chatting" or h1.state2 = "queue" and h2.state2 = "chatting"), 
                          timestampdiff(second, h1.dtm1, h1.dtm2), 0)
                        ) as avg_common_queue_waiting_time,
                        sum(
                          if(h1.state1 = "queue" and h1.operatorid1 IS NULL and (h1.state2 = "chatting" or h1.state2 = "queue" and h2.state2 = "chatting"), 1, 0)
                        ) as avg_common_queue_waiting_time_cnt,
                        h1.departmentid2 as departmentid,
                        departmentkey
                    from
                        chatthreadhistoryview h1
                    LEFT OUTER JOIN chatthreadhistoryview h2 ON h1.threadid = h2.threadid AND h2.number1 = h1.number1 + 1
                    LEFT OUTER JOIN chatdepartment d ON d.departmentid = h1.departmentid2
                    where
                        h1.dtm1 > date_sub(now(), interval 1 day)
                    group by h1.departmentid2'''
        thread_count_rows = conn.query(query)
        if thread_count_rows:
            avg_common_queue_waiting_time_sum = 0
            avg_common_queue_waiting_time_cnt = 0
            for row in thread_count_rows:
                dep_key = row['departmentkey'] or ''
                departments[dep_key] = {
                    'department_name': None,
                    'thread_count': int(row['thread_count']),
                    'chat_count': int(row['chat_count']),
                    'missed_count': int(row['missed_count']),
                    'bounce_5s_count': int(row['bounce_5s_count']),
                    'not_bounce_5s_count': int(row['not_bounce_5s_count']),
                    'avg_common_queue_waiting_time': int(row['avg_common_queue_waiting_time'])
                }

                if int(row['avg_common_queue_waiting_time_cnt']):
                    departments[dep_key]['avg_common_queue_waiting_time'] /= int(row['avg_common_queue_waiting_time_cnt'])

                for key in departments[dep_key]:
                    if key not in ['department_name', 'avg_common_queue_waiting_time']:
                        total[key] += departments[dep_key][key]

                avg_common_queue_waiting_time_sum += int(row['avg_common_queue_waiting_time'])
                avg_common_queue_waiting_time_cnt += int(row['avg_common_queue_waiting_time_cnt'])

            if avg_common_queue_waiting_time_cnt:
                total['avg_common_queue_waiting_time'] = avg_common_queue_waiting_time_sum / avg_common_queue_waiting_time_cnt

        result = {'departments': departments, 'total': total}

        return result

    def get_prev_periods_stats_by_department_and_operator(self):
        result = {}

        conn = db_utils.get_connection(self.account.name)
        conn.execute('SET SESSION TRANSACTION ISOLATION LEVEL READ UNCOMMITTED')
        query = '''SELECT th0.departmentid, d.departmentkey, th0.operatorid,
                        count(DISTINCT th0.threadid) threads,
                        (SELECT AVG(unix_timestamp(dtm2) - unix_timestamp(dtm1)) FROM chatthreadhistoryview
                        WHERE dtm1 > date_sub(now(), INTERVAL 1 HOUR)
                            AND state1 = "queue"
                            AND state2 = "chatting"
                            AND number1 IN (1,2)
                            AND ifnull(th0.departmentid, -1) = ifnull(departmentid2, -1)
                            AND th0.operatorid=operatorid2) avg_answer_time FROM chatthreadhistory th0
                        INNER JOIN chatthread t ON t.threadid = th0.threadid AND t.threadkind NOT IN ("bounce", "skip")
                        LEFT OUTER JOIN chatdepartment d ON d.departmentid = th0.departmentid WHERE dtm > date_sub(now(), INTERVAL 1 HOUR)
                            AND th0.operatorid IS NOT NULL
                        GROUP BY th0.departmentid, th0.operatorid ORDER BY departmentorder, th0.operatorid'''
        rows = conn.query(query)
        conn.execute('SET SESSION TRANSACTION ISOLATION LEVEL REPEATABLE READ')
        conn.close()

        if rows:
            for row in rows:
                dep_key = row['departmentkey'] or ''
                if dep_key not in result:
                    result[dep_key] = {
                        'departmentName': None,
                        'operators': {}
                    }

                operator = self.account.get_operator(row['operatorid'])
                oo = self.account.oo_manager.get(row['operatorid'])
                if oo:
                    online_period = oo.lang_and_dep_to_online_period.get((None, dep_key or None))
                    result[dep_key]['operators'][operator.id] = {
                        'id': operator.id,
                        'fullname': None,
                        'status': oo.get_status(),
                        'avg_answer_time': int(row['avg_answer_time']) if row['avg_answer_time'] else 0,
                        'threads_hour': int(row['threads']),
                        'threads_now': 0,
                        'ts_diff_in_current_status': time.time() - online_period.ts_from if online_period else None
                    }

        return result


class CurrentStatisticsRequestHandler(wm_web.BaseWebimRequestHandler):
    def requires_account_not_blocked(self):
        return True

    def requires_authorized_operator(self):
        return True

    @tornado.web.asynchronous
    def get(self, *args, **kwargs):
        wm_timer.invoke_async(self._get, timer_name='current_statistics request' + (' (realtime)' if self.get_bool_argument('realtime', False) else ''))

    def _get(self):
        account = self.get_account()

        if not account.tariff_settings.get('dashboard'):
            dummy_result = {'chats': {'waiting_now': 0, 'chatting_now': 0}, 'chatsByDepartment': [{'department': {'localeToName': {u'ru': u'\u0411\u0435\u0437 \u043e\u0442\u0434\u0435\u043b\u0430'}, 'name': u'\u0411\u0435\u0437 \u043e\u0442\u0434\u0435\u043b\u0430', 'key': '', 'order': -1}, 'offline': {'waiting': 0, 'max_waiting_time': 0}, 'online': {'waiting': 0, 'in_process': 0, 'max_waiting_time': 0}}, {'department': {'localeToName': {u'ru': u'\u041e\u0442\u0434\u0435\u043b 1', u'en': u'Department 1'}, 'name': u'\u041e\u0442\u0434\u0435\u043b 1', 'key': u'department1', 'order': 100L}, 'offline': {'waiting': 0, 'max_waiting_time': 0}, 'online': {'waiting': 0, 'in_process': 0, 'max_waiting_time': 0}}, {'department': {'localeToName': {u'ru': u'\u041e\u0442\u0434\u0435\u043b 2', u'en': u'Department 2'}, 'name': u'\u041e\u0442\u0434\u0435\u043b 2', 'key': u'department2', 'order': 200L}, 'offline': {'waiting': 0, 'max_waiting_time': 0}, 'online': {'waiting': 0, 'in_process': 0, 'max_waiting_time': 0}}, {'department': {'localeToName': {u'ru': u'\u041e\u0442\u0434\u0435\u043b 3', u'en': u'Department 3'}, 'name': u'\u041e\u0442\u0434\u0435\u043b 3', 'key': u'department3', 'order': 300L}, 'offline': {'waiting': 0, 'max_waiting_time': 0}, 'online': {'waiting': 0, 'in_process': 0, 'max_waiting_time': 0}}], 'hour': {'threads': 4L, 'avg_answer_time': 0, 'missed': 3L}, 'chatsByOperator': {u'department1': {'departmentName': u'\u041e\u0442\u0434\u0435\u043b 1', 'operators': {3L: {'status': u'online', 'ts_diff_in_current_status': 0.0, 'avg_answer_time': 0, 'threads_now': 0, 'fullname': u'\u0410\u0434\u043c\u0438\u043d\u0438\u0441\u0442\u0440\u0430\u0442\u043e\u0440', 'threads_hour': 0, 'id': 1L}}}, u'department3': {'departmentName': u'\u041e\u0442\u0434\u0435\u043b 3', 'operators': {3L: {'status': u'online', 'ts_diff_in_current_status': 0.0, 'avg_answer_time': 0, 'threads_now': 0, 'fullname': u'\u0410\u0434\u043c\u0438\u043d\u0438\u0441\u0442\u0440\u0430\u0442\u043e\u0440', 'threads_hour': 0, 'id': 1L}}}, u'department2': {'departmentName': u'\u041e\u0442\u0434\u0435\u043b 2', 'operators': {3L: {'status': u'online', 'ts_diff_in_current_status': 0.0, 'avg_answer_time': 0, 'threads_now': 0, 'fullname': u'\u0410\u0434\u043c\u0438\u043d\u0438\u0441\u0442\u0440\u0430\u0442\u043e\u0440', 'threads_hour': 0, 'id': 1L}}}}, 'operators': {'online_now': 1}, 'visitors': {'online_now': 10}, 'day': {'threads': 15L, 'avg_answer_time': 0, 'missed': 5L}}  # noqa: E501
            self.finish(json.dumps({'error': 'no-tariff-option', 'dummy': dummy_result}))
            return

        realtime = self.get_bool_argument('realtime', False)

        operator = self.get_operator()
        sv_dep_ids = operator.supervised_department_ids if operator.role == 'supervisor' else set()
        context = self.get_operator_context()

        result = (account.realtime_statistics.get_formatted_stats(sv_dep_ids, context) if realtime
                  else account.prev_periods_statistics.get_formatted_stats(sv_dep_ids, context))

        wm_utils.invoke_in_ioloop(lambda: self.finish(json.dumps(result)), name='current_statistics')


class OperatorDownloadRequestHandler(BaseOperatorRequestHandler, wm_web.BaseDownloadRequestHandler):
    def requires_not_bot_request(self):
        return True

    def on_unauthorized_operator(self):
        self.redirect("/login.php")


class DisconnectAllOperatorsRequestHandler(wm_web.AdminRequestHandler):

    def get(self, *args, **kwargs):
        logging.warn('DisconnectAllOperatorsRequestHandler')
        oops = self.get_account().oo_manager.get_online_operators()
        for oop in oops:
            oop.disconnect()


class DisconnectAllDevicesRequestHandler(wm_web.AdminRequestHandler):

    def get(self, *args, **kwargs):
        result = {}
        account = self.get_account()
        operator_id = self.get_int_argument('operator-id')
        for oo in account.oo_manager.get_online_operators():
            if oo.operator_id == operator_id:
                result[oo.operator_id] = []
                for dd in oo.get_devices():
                    dd.set_status(OperatorStatus.OFFLINE)
                    result[oo.operator_id].append(dd.to_dict())
        self.write(result)


class LoginLogoutOperatorEventFireRequestHandler(wm_web.AdminRequestHandler):

    @tornado.web.asynchronous
    def get(self, *args, **kwargs):
        wm_timer.invoke_async(self._get, 'LoginLogoutOperatorRequest')

    def _get(self):
        try:
            account = self.get_account()
            action = self.get_verified_argument('action')
            account.event_dispatcher.fire(Event(e_type=Event.Type.OPERATOR_LOGIN if action == 'login' else Event.Type.OPERATOR_LOGOUT,
                                                e_object=account.get_operator(self.get_int_argument('operator-id')),
                                                e_data={'status': self.get_verified_argument('status')} if action == 'login' else {}))
        except Exception:
            pass

        self.finish(json.dumps({'result': 'ok'}))


class SpellCheckRequestHandler(BaseOperatorRequestHandler):

    def get_account(self):
        # для того, чтобы spellcheck-запросы не приводили к созданию полного аккаунта, чтобы можно было вынести
        # обработу этих запросов на отдельный инстанс сервера
        return account.BriefAccount.get(self.get_account_name())

    @staticmethod
    def check(text):
        result = []
        patterns = [
            u"пожалуйста ",
            u"здравствуйте ",
            u"добрый день ",
            u"добрый вечер ",
            u"доброе утро ",
        ]

        for match in re.finditer(re.compile("|".join(patterns), re.IGNORECASE | re.UNICODE), text):
            span = match.span()
            result.append([span[0], span[1]])
        return result

    @tornado.web.asynchronous
    def post(self, *args, **kwargs):
        wm_timer.invoke_async(self.__inner_handler, 'SpellCheckRequestHandler POST')

    def __inner_handler(self):
        result = self.check(self.get_argument('text', '', False))
        self.write(json.dumps(result))
        self.finish()


def using_split2(line, _len=len):
    words = re.compile('\w+', re.UNICODE).findall(line)
    index = line.index
    offsets = []
    append = offsets.append
    running_offset = 0
    for word in words:
        word_offset = index(word, running_offset)
        word_len = _len(word)
        running_offset = word_offset + word_len
        append((word, word_offset, running_offset - 1, word_len))
    return offsets


def yandex_spell(word):
    try:
        response = requests.get('http://speller.yandex.net/services/spellservice.json/checkText?%s' % urllib.urlencode({'text': word}), timeout=2)
        logging.info("Yandex speller said %s for %s" % (response.content, word))
        return len(json.loads(response.content)) == 0
    except Exception:
        return None


class SpellCheckRequestHandler2(BaseOperatorRequestHandler):

    def get_account(self):
        # для того, чтобы spellcheck-запросы не приводили к созданию полного аккаунта, чтобы можно было вынести
        # обработу этих запросов на отдельный инстанс сервера
        return account.BriefAccount.get(self.get_account_name())

    @staticmethod
    def check(text, lang='ru', _len=len, account=None):  # TODO other languages
        # if not lang in ['en', 'ru']:
        #     return []

        urls = re.findall(
            r'(?i)\b((?:[a-z][\w-]+:(?:/{1,3}|[a-z0-9%])|www\d{0,3}[.]|[a-z0-9.\-]+[.][a-z]{2,4}/)(?:[^\s()<>]+|\(([^\s()<>]+|(\([^\s()<>]+\)))*\))+(?:\(([^\s()<>]+|(\([^\s()<>]+\)))*\)|[^\s`!()\[\]{};:\'".,<>?«»“”‘’]))',  # noqa: E501
            text)
        for url in urls:
            url = url[0]
            url_length = _len(url)
            text = text.replace(url, " " * url_length)

        decimals = re.findall(
            r'\d[\d\.,]+',
            text)

        for dec in decimals:
            url_length = _len(dec)
            text = text.replace(dec, " " * url_length)

        s_lang = aspell.Speller(
            ('lang', lang),
            ('encoding', 'utf-8'),
            ('home-dir', '/var/pro/aspell'),
            ('personal-path', '/var/pro/aspell/aspell.%s.pws' % lang)
        )

        s_en = aspell.Speller(
            ('lang', 'en'),
            ('encoding', 'utf-8'),
            ('home-dir', '/var/pro/aspell'),
            ('personal-path', '/var/pro/aspell/aspell.en.pws')
        )

        # s_lang = hunspell.HunSpell('/usr/share/hunspell/ru_RU.dic', '/usr/share/hunspell/ru_RU.aff')
        # s_en = hunspell.HunSpell('/usr/share/hunspell/en_US.dic', '/usr/share/hunspell/en_US.aff')
        row = 0

        res = []
        row_offset = 0
        for line in text.splitlines():
            arr = using_split2(line)

            for word, offset1, offset2, length in arr:
                word_utf = word.encode('utf-8')
                s = s_en if all(ord(c) < 128 for c in word) else s_lang
                # s = s_lang
                if not s.check(word_utf):
                    word = word.lower()
                    spelling_dict = account.get_setting('spelling_dict') or {} if account else {}
                    if not spelling_dict or word not in spelling_dict:
                        if len(word) <= 100 and not wm_settings.settings.get('hostedmode') and yandex_spell(word_utf):
                            logging.info("Adding word to personal dictionary %s" % word)
                            s.addtoPersonal(word_utf)
                            s.saveAllwords()
                            continue

                        suggestions = s.suggest(word_utf)
                        # print suggestions
                        ss = []
                        for suggestion in suggestions:
                            ss.append(suggestion.decode('utf-8'))
                        out = {'code': 1, "pos": offset1 + row_offset, "col": offset1, "len": length, "row": row, "word": word, "s": ss}
                        forbidden_dict = account.get_setting('forbidden_spelling_dict') or {} if account else {}
                        if forbidden_dict and word in forbidden_dict:
                            out['not_add'] = True
                        res.append(out)

            row_offset += len(line) + 1  # "+ 1" ---> "\n" char
            row = row + 1

        return res

    @tornado.web.asynchronous
    def post(self, *args, **kwargs):
        wm_timer.invoke_async(self.__inner_handler, 'SpellCheckRequestHandler2 POST')

    def __inner_handler(self):
        # TODO: self.get_argument('lang', 'ru', False)

        result = self.check(
            self.get_argument('text', '', False), 'ru',
            account=self.get_account() if self.get_account().get_setting('server_dicts_spell_check') else None
        )

        callback = self.get_verified_argument('callback', None)
        if callback:
            self.write(u'%s([%s])' % (callback, json.dumps(result)))
        else:
            self.write(u'yandex.json.response("0", [%s])' % json.dumps(result))
        self.finish()

    @tornado.web.asynchronous
    def get(self, *args, **kwargs):
        wm_timer.invoke_async(self.__inner_handler, 'SpellCheckRequestHandler2 GET')


class OperatorDataRequestHandler(wm_web.BaseWebimRequestHandler):

    def get(self, *args, **kwargs):
        data_kind = self.get_verified_argument('kind', None)

        if data_kind == 'visitor':
            session_id = self.get_verified_argument('session_id', None)
            session = self.get_account().visit_tracker.get_session(session_id)
            if session and session.visitor:
                self.write(session.visitor.to_json())
        else:
            self.write(json.dumps({'error': 'unknown_data_kind'}))


if __name__ == "__main__":
    o = Operator('mixey', 'mixey', 36)
    print o.to_json()
    print o.department_keys
    print o.locales