import time
import threading

import tornado.web

import wm_timer
import wm_utils


__author__ = 'mixey'


class Delta(wm_utils.KeepRefs, wm_utils.Jsonable):

    class Event:
        ADD = 'add'
        UPDATE = 'upd'
        DELETE = 'del'

    def __init__(self, object_type, event, id, data):
        super(Delta, self).__init__()
        self.object_type = object_type
        self.id = id
        self.event = event
        self.data = data
        self.ts = time.time()
        self.json_cache = None

    def to_dict(self, context=None):
        result = {
            'objectType': self.object_type,
            'event': self.event,
            'id': self.id
        }
        if self.event != Delta.Event.DELETE:
            data = self.data.to_dict(context=context) if isinstance(self.data, wm_utils.Jsonable) else self.data
            result['data'] = data

        return result


class DeltaManager(wm_utils.KeepRefs):

    def __init__(self, delta_live_period):
        super(DeltaManager, self).__init__()
        self.__delta_live_period = delta_live_period
        self.delta_list = []  # contains tuples (revision, delta)
        self.revision = 1
        self.lock = threading.Lock()

#    It was supposed to use this method when operator is switched to offline
#    def reset(self):
#        self.delta_list = []
#        self.revision += 1 # this is made to be sure that client will receive fullUpdate when it will ask for delta

    def add_delta(self, delta, min_timeout=0, notify_waiters=True):
        delta_list = delta if type(delta) == list else [delta]
        with self.lock:
            for delta in delta_list:
                self.revision += 1
                self.delta_list.append((self.revision, delta))

        if notify_waiters:
            self.notify_waiters(min_timeout)

    def notify_waiters(self, min_timeout):
        pass

    def get_delta_since(self, revision):
        with self.lock:
            if revision == self.revision:
                return [], self.revision
            if len(self.delta_list) == 0 or revision < self.delta_list[0][0] - 1 or revision > self.revision:
                return None, self.revision

            result = []
            for i in range(len(self.delta_list) - 1, -1, -1):
                rev, delta = self.delta_list[i]
                if rev > revision:
                    result.append(delta)
            result.reverse()
            return result, self.revision

    def clean_old_delta(self):
        with self.lock:
            threshold = time.time() - self.__delta_live_period
            i = 0
            while i <= len(self.delta_list):
                if i == len(self.delta_list) or self.delta_list[i][1].ts > threshold:
                    break
                i += 1
            if i > 0:
                self.delta_list = self.delta_list[i:]

    @classmethod
    def clean_old_delta_in_all_managers(cls):
        for subclass in cls.__subclasses__():
            for manager in subclass.get_instances():
                manager.clean_old_delta()


class DeltaManagerStub:
    def add_delta(self, delta):
        pass


DELTA_MANAGER_STUB = DeltaManagerStub()

wm_timer.invoke_periodically(5, DeltaManager.clean_old_delta_in_all_managers, "delta cleaning")


class DeltaRequestHandler(tornado.web.RequestHandler):

    def get_delta_manager(self):
        pass

    def get_full_update(self):
        pass

    def get_since(self):
        return int(self.get_argument("since"))

    def get_context(self):
        return None

    def filter_delta(self, delta_list):
        return delta_list

    def get_response(self, since):
        delta_manager = self.get_delta_manager()

        if since == 0:
            return self.get_full_update_response(delta_manager.revision)
        else:
            delta_list, revision = delta_manager.get_delta_since(since)
            if revision == since:
                return {}
            elif delta_list is None:
                return self.get_full_update_response(delta_manager.revision)
            else:
                return self.get_delta_response(self.filter_delta(delta_list), revision)

    def get_delta_response(self, delta_list, revision):
        result = {
            'revision': revision,
            'deltaList': self.get_list_for_json(delta_list, self.get_context())
        }

        return result

    def get_full_update_response(self, revision):
        result = {
            'revision': revision,
            'fullUpdate': {
                'currentTime': time.time()
            }
        }

        full_update = self.get_full_update()
        context = self.get_context()

        for name, data in full_update.items():
            result['fullUpdate'][name] = self.get_item_for_json(data, context)

        return result

    def get_list_for_json(self, lisst, context=None):
        return [self.get_item_for_json(data, context) for data in lisst]

    def get_item_for_json(self, data, context):
        if isinstance(data, wm_utils.Jsonable):
            return data.to_dict(context=context)
        elif type(data) == list:
            return self.get_list_for_json(data, context)
        else:
            return data