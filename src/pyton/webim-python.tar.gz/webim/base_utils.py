__author__ = 'mixey'


class __EmptyDict(dict):

    def update(self, other=None, **kwargs):
        raise Exception()

    def __setitem__(self, key, value):
        raise Exception()


EMPTY_DICT = __EmptyDict()
