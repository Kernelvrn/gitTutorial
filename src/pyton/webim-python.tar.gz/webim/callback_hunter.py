# coding=UTF-8
__author__ = 'abezroukov'

import time
from uuid import uuid4

import tornado

import db_utils
from wm_web import BaseWebimRequestHandler


class CallbackHunterEventRequestHandler(BaseWebimRequestHandler):

    @tornado.web.asynchronous
    def get(self, *args, **kwargs):
        callback_uid = self.get_argument('callback_uid', '')
        event = self.get_argument('event', None)
        record_filename = self.get_argument('record_filename', None)
        bill_seconds = self.get_argument('duration', None)
        connection = db_utils.get_connection(self.get_account_name())
        callback_row = connection.get("select * from callback where uid = %s", callback_uid)
        if callback_row and event:
            state = CallbackHistory.State.UNKNOWN
            if event == 'callback.queue_call_to_operator':
                state = CallbackHistory.State.QUEUE
            elif event == 'callback.operator_answered':
                state = CallbackHistory.State.WAITING
            elif event == 'callback.dial_to_visitor':
                state = CallbackHistory.State.CALLING
            elif event in ['callback.visitor_answered', 'callback.visitor_busy', 'callback.visitor_not_answered',
                           'callback.operator_cancelled', 'callback.hangup', 'callback.number_not_recognised']:
                state = CallbackHistory.State.HANGUP
            self.get_account().background_storager.add_object_to_store(CallbackHistory(callback_uid, state, event))
            callback = Callback(
                callback_row['operatorphone'],
                callback_row['visitorphone'],
                callback_row['visitsessionid'],
                callback_row['referrerurl'],
                callback_row['id']
            )
            callback.uid = callback_uid
            callback.bill_seconds = bill_seconds
            callback.record_uri = record_filename
            callback.modification_ts = time.time()
            self.get_account().background_storager.store(callback, background=False)
            result = 'ok'
        else:
            result = 'error'

        self.send_result({'result': result})


class Callback:

    def __init__(self, operator_phone, visitor_phone, session_id, referrer_url, callback_id=None):
        self.id = callback_id
        self.uid = uuid4()
        self.operator_phone = operator_phone
        self.visitor_phone = visitor_phone
        self.session_id = session_id
        self.creation_ts = self.modification_ts = time.time()
        self.referrer_url = referrer_url
        self.bill_seconds = None
        self.record_uri = None


class CallbackHistory:
    class State:
        UNKNOWN = 'unknown'
        ORDER = 'order'
        QUEUE = 'queue'
        WAITING = 'waiting'
        CALLING = 'calling'
        HANGUP = 'hangup'

    def __init__(self, callback_uid, state, event):
        self.callback_uid = callback_uid
        self.state = state
        self.event = event
        self.creation_ts = time.time()
