# -*- coding: utf-8 -*-
import math

__author__ = 'mixey'

import weakref
import urllib
import urllib2
import logging
import threading
import time
import os
import json
import uuid
import urlparse
import base64
import datetime
import socket
import inspect
import hashlib
import hmac
import random
import re
from collections import defaultdict

import magic
import pytz
import requests
import tornado.options
from tornado.ioloop import IOLoop
from PIL import Image, ExifTags

import db_utils
import wm_settings
import account
import wm_timer


tornado_instance_id = uuid.uuid4().hex

emoji_pattern = re.compile(
    u"["
    u"\U0001F600-\U0001F64F"        # emoticons
    u"\U0001F300-\U0001F5FF"        # symbols & pictographs
    u"\U0001F680-\U0001F6FF"        # transport & map symbols
    u"\u2600-\u26FF\u2700-\u27BF"   # uncategorized
    u"\U0001F1E0-\U0001F1FF"        # flags (iOS)
    u"]+",
    flags=re.UNICODE
)

MARKDOWNS_REGEXP = {
    'hyperlink': re.compile('\[(.*?)\]\((.*?)\)')
}


class InstanceCountTracker(object):
    pass


class KeepRefs(InstanceCountTracker):
    __refs__ = defaultdict(list)

    def __init__(self, clazz=None):
        super(KeepRefs, self).__init__()
        self.__refs__[clazz if clazz else self.__class__].append(weakref.ref(self))

    @classmethod
    def get_instances(cls):
        orig_refs = cls.__refs__[cls]
        copied_refs = orig_refs[:]
        for inst_ref in copied_refs:
            inst = inst_ref()
            if inst is not None:
                yield inst
            else:
                try:
                    orig_refs.remove(inst_ref)
                except ValueError:
                    logging.warn('KeepRefs: get_instances list.remove(x): x not in list')

    @classmethod
    def clear_old_refs(cls):
        orig_refs = cls.__refs__[cls]
        copied_refs = orig_refs[:]
        for inst_ref in copied_refs:
            inst = inst_ref()
            if inst is None:
                try:
                    orig_refs.remove(inst_ref)
                except ValueError:
                    logging.warn('KeepRefs: get_instances list.remove(x): x not in list')

#    @classmethod
#    def get_instances_count(cls):
#        return len(cls.__refs__[cls])


# TODO: move to base_utils
class DictExt(dict):

    def __init__(self, create_value):
        self.createValue = create_value

    def get(self, k, d=None):
        result = dict.get(self, k, d)
        if not result:
            result = self.createValue(k)
            self[k] = result
        return result


class BaseCache(KeepRefs):

    def __init__(self, timeout, reload_immediately_after_reset=False):
        super(BaseCache, self).__init__(BaseCache)
        self._last_update_ts = 0

        self._reload_required = False  # Флаг для перезагрузки кэша при следующем обращении к кэшу
        self.__reload_immediately_after_reset = reload_immediately_after_reset

        self._update_lock = threading.Lock()

        self.__timeout = timeout
        self._timeout_random_factor = random.random() / 10 + 1  # Для размазывания времени жизни кэша

    def is_reload_required(self):
        timeout = self.get_timeout()
        return self._reload_required or time.time() > self._last_update_ts + timeout

    def get_timeout(self):
        """
        Метод для получения таймаута жизни кэша.
        Можно переопределить, если логика получения таймаута какая-то очень сложная.
        Должен возвращать int.
        """

        sys_timeout = self.__timeout or wm_settings.settings.get('python_cache_timeout', 5 * 60)
        return sys_timeout * self._timeout_random_factor

    def reset(self):
        if self._reload_required:
            return

        self._reload_required = True

        if self.__reload_immediately_after_reset:
            self._reload_now()

    def _reload_now(self):
        pass

    @classmethod
    def reset_all(cls):
        for cache in cls.get_instances():
            cache.reset()


class CachedData(BaseCache):

    CACHE_TOO_OLD_TIMEOUT_MULTIPLIER = 10

    def __init__(self, timeout=None, autoupdate=False, reload_immediately_after_reset=False):
        super(CachedData, self).__init__(timeout=timeout, reload_immediately_after_reset=reload_immediately_after_reset)
        self._cached = None

        if autoupdate:
            self.start_autoupdate_timer()

    def get_data(self, force_from_cache=False):
        if force_from_cache:
            return self._cached

        if self.is_reload_required():
            if self._last_update_ts == 0 or time.time() - self._last_update_ts > self.get_timeout() * self.CACHE_TOO_OLD_TIMEOUT_MULTIPLIER:
                # Обновляем кэш в главном потоке только один раз или если кэш ну уж ооочень старый.
                # Все остальные обновления - в других потоках.
                self.__update_data(ensure_fresh=True)
            else:
                if not self._update_lock.locked():  # Если lock залочен, это значит, что уже идет обновление, и нет необходимости запускать еще одно
                    wm_timer.invoke_async(self.__update_data, '%s update_data async' % self.__class__.__name__)

        return self._cached

    def __update_data(self, ensure_fresh=False):
        """
        Если не удалось получить lock, то ничего не делаем (кэш уже обновляется в другом потоке).
        Есть исключения (ensure_fresh == True):
            1. Первый запрос данных из кэша (в кэше ничего не лежит)
            2. Кэш очень старый (таймаут превышен в CACHE_TOO_OLD_TIMEOUT_MULTIPLIER раз)
            3. Reset
        """

        if self._update_lock.acquire(ensure_fresh):
            try:
                if not self.is_reload_required():
                    return

                try:
                    start_ts = time.time()

                    # Сбрасываем флаг до получения данных, чтобы поднятие флага гарантировало свежие данные при следующем update_data.
                    # Флаг проставляется при reset.
                    self._reload_required = False

                    obtained = self.obtain_data()

                    ts_diff = time.time() - start_ts
                    if ts_diff > 5:
                        logging.warn('Cache %s renew took too much: %d sec', type(self).__name__, ts_diff)

                    old_cached = self._cached
                    self._cached = obtained
                    self.on_data_renewed(old_cached, obtained)
                except Exception:
                    if not self._last_update_ts:
                        raise
                    logging.error("Failed to renew the cache (%s)" % self.__class__.__name__, exc_info=True)

                # Если обновление кэша упало (например, пропал коннект к базе), то использовать будем старый кэш.
                self._last_update_ts = time.time()
            finally:
                self._update_lock.release()

    def obtain_data(self):
        return None

    def on_data_renewed(self, cached, obtained):
        pass

    def _reload_now(self):
        wm_timer.invoke_async(lambda: self.__update_data(ensure_fresh=True), '%s update_data async' % self.__class__.__name__)

    def start_autoupdate_timer(self):
        wm_timer.invoke_periodically(self.get_timeout(), lambda: self.reset(), "cached data autoupdate")


class CachedDBData(CachedData):

    def __init__(self, account_name, timeout=None, autoupdate=False, reload_immediately_after_reset=False):
        CachedData.__init__(self, timeout, autoupdate, reload_immediately_after_reset=reload_immediately_after_reset)
        self.__account_name = account_name

    def obtain_data(self):
        connection = db_utils.get_connection(self.__account_name)
        result = self.load_data(connection)
        connection.close()
        return result

    def load_data(self, connection):
        return None


class MultiCache(BaseCache):

    """
    Хранилище кэша, реализующее логику хранения словаря закэшированных объектов {object_id: object}.

    Автоматически обновляется по таймеру (кроме первого обращения).

    Умеет обновлять, как весь кэш сразу, так и определенные объекты по отдельности.
    Чтобы обновить весь кэш - reset.
    Чтобы обновить один объект - reset_one.

    Для примера можно посмотреть реализацию wm_operator.CachedOperators.

    """

    def __init__(self, account=None, timeout=None, reload_immediately_after_reset=True):
        super(MultiCache, self).__init__(timeout=timeout, reload_immediately_after_reset=reload_immediately_after_reset)
        self.account = account
        self._cached = {}

        self.start_autoupdate()

    def start_autoupdate(self):
        wm_timer.invoke_periodically(self.get_timeout() / 10, self.__update_all, "MultiCache {class_name} autoupdate @{account_name}".format(class_name=self.__class__.__name__, account_name=self.account and self.account.name))

    def get_one(self, object_id):
        return self.get_data().get(object_id)

    def get_data(self):
        if not self._last_update_ts:
            # Кэш обновляется один раз при первом обращении к нему, после этого - по таймеру.
            self.__update_all()

        return self._cached

    def __update_all(self):
        recheck = False

        with self._update_lock:
            if self.is_reload_required():
                self._reload_required = False
                try:
                    obtained = self.obtain_all()

                    for obtained_obj_id, obtained_obj in obtained.items():
                        cached_obj = self._cached.get(obtained_obj_id)
                        recheck = self.__update_object_in_cache(obtained_obj_id, cached_obj, obtained_obj) or recheck

                    deleted_object_ids = list(set(self._cached.keys()) - set(obtained.keys()))  # Для случая, когда объекты удалялись
                    for obj_id in deleted_object_ids:
                        cached_obj = self._cached.get(obj_id)
                        recheck = self.__update_object_in_cache(obj_id, cached_obj, None) or recheck
                except Exception:
                    if not self._last_update_ts:
                        raise
                    logging.exception("@{account_name}: Failed to renew MultiCache ({cache_type})".format(
                        account_name=self.account.name, cache_type=self.__class__.__name__))

                self._last_update_ts = time.time()

        if recheck:
            self.recheck_after_update()

    def _reload_now(self):
            wm_timer.invoke_async(self.__update_all, 'MultiCache reload_now')

    def obtain_all(self):
        connection = db_utils.get_connection(self.account.name if self.account else None)
        result = self.load_all_objects(connection)
        connection.close()

        return result

    def __update_one(self, object_id):
        if not object_id:
            return

        with self._update_lock:
            cached_obj = self.get_one(object_id)
            obtained_obj = self.obtain_one(object_id)

            recheck = self.__update_object_in_cache(object_id, cached_obj, obtained_obj)

        if recheck:
            self.recheck_after_update()

    def __update_object_in_cache(self, object_id, cached_obj, obtained_obj):
        if cached_obj and not obtained_obj:
            del self._cached[object_id]
        else:
            self._cached[object_id] = obtained_obj
        recheck = self.on_one_renewed(cached_obj, obtained_obj)

        return recheck

    def obtain_one(self, object_id):
        connection = db_utils.get_connection(self.account.name if self.account else None)
        result = self.load_one_object(connection, object_id)
        connection.close()

        return result

    def reset_one(self, object_id):
        if not object_id:
            logging.error("@{account_name} MultiCache ({cache_type}): reset_one executed without object_id".format(
                account_name=self.account.name,
                cache_type=self.__class__.__name__
            ))
            return

        wm_timer.invoke_async(lambda: self.__update_one(object_id), 'MultiCache reset_one async')

    def load_all_objects(self, connection):
        """
        Метод для подгрузки из базы всех объектов сразу.
        Должен возвращать dict {object_id: object}.
        """
        pass

    def load_one_object(self, connection, object_id):
        """
        Метод для подгрузки из базы одного объекта по его идентификатору.
        Должен возвращать сам объект.
        """
        pass

    def on_one_renewed(self, cached_obj, obtained_obj):
        """
        Метод дергается при обновлении кэша.

        :param cached_obj: объект, который лежал в кэше до обновления.
        :param obtained_obj: объект, загруженный из базы при обновлении.

        Метод может возвращать bool-значение.
        Если вернет True, то в конце обновления вызовется метод ``recheck_after_update``
        """
        return False

    def recheck_after_update(self):
        """
        Метод дергается после обновления кэша, если хоть один вызов ``on_one_renewed`` вернул True.
        В нём лучше всего делать какие-то апдейты, которые достаточно сделать только один раз после
        обновления кэша.
        """
        pass


class CachedDict(CachedDBData):

    def __init__(self, account_name, sql, timeout=None):
        CachedDBData.__init__(self, account_name, timeout)
        self.sql = sql

    def load_data(self, connection):
        result = {}
        rows = connection.query(self.sql)
        for r in rows:
            result[r['key']] = r['value']
        return result

    def get(self, key, default=None):
        return self.get_data().get(key, default)


class Jsonable:

    def to_json(self, context=None, indent=None):
        ensure_ascii = not (context and context.get('mode') in ['db', 'visitor'])

        if context and context.get('account') and context.get('account').name == 'webimru069':
            ensure_ascii = not (context and context.get('mode') in ['db', 'visitor', 'operator'])

        result = json.dumps(self.to_dict(context=context), ensure_ascii=ensure_ascii, indent=indent)

        if context and context.get('mode') == 'db' and check_for_4_byte_characters(result):
            result = json.dumps(self.to_dict(context=context), ensure_ascii=True, indent=indent)

        return result

    def to_dict(self, context=None):
        pass

    def prepare_ts(self, ts, context):
        if context and 'ts_offset' in context and ts:
            return ts + context['ts_offset']
        return ts


class DateTimeJSONEncoder(json.JSONEncoder):
    def default(self, obj):
        if isinstance(obj, datetime.datetime) or isinstance(obj, datetime.date):
            return obj.isoformat()
        else:
            return super(DateTimeJSONEncoder, self).default(obj)


class AliveTracker:

    def __init__(self, interval, on_alive_changed_handler):
        self.__alive = False
        self.__timer = None
        self.interval = interval
        self.on_alive_changed_handler = on_alive_changed_handler

    def is_alive(self):
        return self.__alive

    def ping(self):
        self.__set_alive(True)
        self.__cancel_timer()

    def delayed_set_dead(self):
        if self.__alive and self.__timer is None:
            self.__timer = wm_timer.timers_manager.add_timer(self.interval, self.__on_timer, "operator delayed killing")

    def set_dead(self):
        self.__set_alive(False)

    def __set_alive(self, value):
        if self.__alive != value:
            self.__alive = value
            self.on_alive_changed_handler(value)

    def __on_timer(self):
        self.__set_alive(False)
        self.__timer = None

    def __cancel_timer(self):
        if self.__timer is not None:
            self.__timer.cancel()
            self.__timer = None


class WebimException(Exception):
    def __init__(self):
        logging.warn('Exception: WebimException was raised')


class MissingFileException(Exception):
    def __init__(self, guid):
        logging.warn('Exception: Missing file with guid %s' % guid)


class MissingThumbnailKeyException(Exception):
    def __init__(self, guid, thumb):
        logging.warn('Exception: Missing thumbnail size for key %s. File guid %s' % (thumb, guid))


class SelectedPeriods:
    def __init__(self, raw_periods, timezone=None):
        """json, example::

            [{u'timeIntervals': u'10:00-14:30,15:30-22:00', u'weekDays': [1, 2, 3, 4, 5]},
             {u'timeIntervals': u'12:00-20:00', u'weekDays': [6]}]

        """

        self.raw_periods = raw_periods
        self.converted_periods = {}
        self.timezone = pytz.timezone(timezone) if timezone else None

    def __str__(self):
        return str(self.converted_periods) if self.converted_periods else str(self.raw_periods)

    def get_converted_periods(self):
        return self.converted_periods if self.converted_periods else self.__convert_time_periods()

    def __convert_time_periods(self):
        """format raw_periods in something more usable (periods for every weekday)"""
        for days in self.raw_periods:
            converted_intervals = self.__convert_string_with_time_intervals(days['timeIntervals'])
            for day in days['weekDays']:
                self.converted_periods[day] = converted_intervals
        return self.converted_periods

    def __convert_string_with_time_intervals(self, time_intervals_string):

        # in - 'hh1:mm1-hh2:mm2, ... '
        # out - [{'from': datetime.time(hh1, mm1), 'to': datetime.time(hh2, mm2)}, ... ],

        split_intervals = time_intervals_string.split(',')
        converted_intervals = []
        for interval in split_intervals:

            interval_dict = {}
            from_to = interval.split('-')

            interval_dict['from'] = self.__convert_time_string_to_time(from_to[0])
            interval_dict['to'] = self.__convert_time_string_to_time(from_to[1])

            converted_intervals.append(interval_dict)

        return converted_intervals

    def __convert_time_string_to_time(self, time_string):
        if ':' not in time_string:
            converted_time = datetime.time(hour=time.strptime(time_string, '%H').tm_hour,
                                           minute=0)
        else:
            converted_time = datetime.time(hour=time.strptime(time_string, '%H:%M').tm_hour,
                                           minute=time.strptime(time_string, '%H:%M').tm_min)
        return converted_time

    def check_if_time_in_time_periods(self, dtm_to_check):
        # check_dtm - datetime type
        day_periods = self.get_converted_periods()

        time_to_check = dtm_to_check.time()
        weekday_to_check = dtm_to_check.date().isoweekday()

        in_interval = False

        if weekday_to_check in day_periods:
            for interval in day_periods[weekday_to_check]:
                if interval['from'] <= time_to_check <= interval['to']:
                    in_interval = True
                    break

        return in_interval

    def check_if_current_time_in_time_periods(self):
        if self.timezone:
            return self.check_if_time_in_time_periods(datetime.datetime.now(tz=pytz.utc).astimezone(self.timezone))
        else:
            return self.check_if_time_in_time_periods(datetime.datetime.now())


class SlackBot:
    def __init__(self, token):
        self.token = token

    def send(self, text, channel, bot_name=None, icon_url=None):
        url = 'https://slack.com/api/chat.postMessage?token=' + self.token

        data = {'text': str(text),
                'channel': channel,
                'username': bot_name or 'WebimSlackBot',
                'icon_url': icon_url or 'https://webim.webim.ru/webim/images/navigation/webim-status.png',
                'link_names': 1}
        try:
            requests.post(url, data, timeout=1.0)
        except requests.exceptions.Timeout:
            # send e-mail?
            pass

    def send_paypal_payment_notification(self, text):
        self.send(text, 'webim_sales', 'PayPal Notificator')


def convert_date_to_string(data):
    if isinstance(data, list):
        for i, value in enumerate(data):
            if isinstance(value, (list, dict)):
                convert_date_to_string(value)
            elif isinstance(value, (datetime.date, datetime.datetime)):
                data[i] = int(value.strftime('%s'))
    elif isinstance(data, dict):
        for key, value in data.items():
            if isinstance(value, (datetime.date, datetime.datetime)):
                data[key] = str(value)
            elif isinstance(value, (list, dict)):
                data[key] = convert_date_to_string(value)
    return data


def _get_version():
    f = open(os.path.join(wm_settings.public_html_dir, 'webim/classes/version.php'), "r")
    try:
        s = f.read()
        start_idx = s.index('\'WEBIM_VERSION\', \'') + 18
        return s[start_idx: s.index('\'', start_idx)]
    except Exception:
        return ''
    finally:
        f.close()


version = _get_version()


def _get_branch():
    try:
        f = open(os.path.join(wm_settings.public_html_dir, 'webim/service/branch.txt'), "r")
        s = f.read()
        f.close()
        return s
    except Exception:
        return ''


branch = _get_branch()


def decode_url(url):
    if url is None:
        return url
    try:
        result = url.encode('utf-8') if type(url) == unicode else url
        result = urllib.unquote_plus(result)
        try:
            result = unicode(result, "utf-8")
        except UnicodeDecodeError:
            result = unicode(result, "cp1251")
        return result
    except Exception:
        logging.warn(u'Could not decode url: %s' % url, exc_info=True)
        return url


def get_ts(datetime, default=None):
    return int(datetime.strftime('%s')) if datetime else default


def microseconds_to_seconds(ns, return_int=True):
    return int(math.floor(ns / 1e6)) if return_int else ns / 1e6


def cut_string(s, length):
    if s is None or len(s) <= length:
        return s
    if length <= 3:
        return s[0: length]
    return s[0: length - 3] + "..."


def filter_4_byte_characters(unicode_string):
    """filter characters which become 4-byte characters after encoding to utf-8 and involves db storing errors"""
    return emoji_pattern.sub(u'', unicode_string)


def check_for_4_byte_characters(unicode_string):
    for uc in unicode_string:
        if uc < u'\ud800' or u'\ue000' <= uc <= u'\uffff':
            continue
        else:
            return True

    return False


def check_if_ip_matches_subnet(ip, subnet_ip, subnet_mask):
    if type(ip) == str:
        ip = [int(part) for part in ip.split('.')]

    for i, n, m in zip(ip, subnet_ip, subnet_mask):
        if i & m != n:
            return False

    return True


def check_if_ip_in_list(ip, ip_string_list):
    for item in ip_string_list.split(','):
        item = item.strip()
        r = item.split('-')
        if len(r) == 2:
            if check_if_ip_matches_range(ip, [r[0], r[1]]):
                return True
        else:
            if ip == item:
                return True
    return False


def ip2long(ip):
    hexn = ''.join(["%02X" % long(i) for i in ip.split('.')])
    return long(hexn, 16)


def check_if_ip_matches_range(ip, ip_range):
    ip_range[0] = ip_range[0].strip()
    ip_range[1] = ip_range[1].strip()
    ip = ip2long(ip)
    return True if ip >= ip2long(ip_range[0]) and ip <= ip2long(ip_range[1]) else False


tvoe_tv_subnet_ip_and_mask_pairs = [
    ((192, 168, 100, 0), (255, 255, 255, 0)),
    ((77, 241, 32, 0), (255, 255, 240, 0)),
    ((87, 237, 112, 0), (255, 255, 248, 0)),
    ((93, 185, 176, 0), (255, 255, 240, 0)),
    ((109, 205, 248, 0), (255, 255, 248, 0))
]


def check_if_ip_matches_tvoe_tv_subnet(ip):
    try:
        if type(ip) == str:
            ip = [int(part) for part in ip.split('.')]
    except Exception:
        return False

    for subnet_ip, subnet_mask in tvoe_tv_subnet_ip_and_mask_pairs:
        if check_if_ip_matches_subnet(ip, subnet_ip, subnet_mask):
            return True

    return False


def merge_dict(dict1, dict2):
    for k, v in dict2.items():
        dict1[k] = v
    return dict1


def store_visitor_avatar(file_info, account_name):
    path = os.path.join(wm_settings.settings['client-data-dir'], account_name, 'images', 'visitor_avatars')
    if not os.path.exists(path):
        os.mkdir(path)

    file_path = os.path.join(path, file_info['filename'])

    with open(file_path, 'wb') as f:
        f.write(file_info['body'])


def security_check_file_type(file_type, account):
    allowed_types = []
    restricted_types = []

    if account.get_setting('allowed_upload_file_types'):
        allowed_types = [
            ext.strip().lower()
            for ext in account.get_setting('allowed_upload_file_types').split(',')
            if ext.strip()
        ]

    if account.get_setting('restricted_upload_file_types'):
        restricted_types = [
            ext.strip().lower()
            for ext in account.get_setting('restricted_upload_file_types').split(',')
            if ext.strip()
        ]

    if allowed_types and file_type not in allowed_types or not allowed_types and file_type in restricted_types:
        return False

    return True


def store_client_file(file_content, path, account_name):
    full_path = os.path.join(wm_settings.settings['client-data-dir'], account_name, path)
    if not os.path.exists(os.path.dirname(full_path)):
        os.mkdir(os.path.dirname(full_path))

    client_file = open(full_path, 'wb')
    client_file.write(file_content)
    client_file.close()


def remove_client_file(path, account_name):
    full_path = os.path.join(wm_settings.settings['client-data-dir'], account_name, path)
    if os.path.exists(full_path):
        os.remove(full_path)


def get_client_files_content(path, account_name):
    files_content = {}
    full_path = os.path.join(wm_settings.settings['client-data-dir'], account_name, path)
    if os.path.exists(full_path):
        for filename in os.listdir(full_path):
            client_file = open(os.path.join(full_path, filename), 'rb')
            files_content[filename] = client_file.read()

    return files_content


def store_file(file_info, visitor_id, account_name):
    path = os.path.join(wm_settings.settings['client-data-dir'], account_name, 'files')
    if not os.path.exists(path):
        os.mkdir(path)
    filename = uuid.uuid4().hex
    file_path = os.path.join(path, filename)
    desc_path = file_path + '.desc'

    with open(file_path, 'wb') as f:
        f.write(file_info['body'])

    descriptor = {
        'guid': filename,
        'filename': clear_filename(file_info['filename'].split('\\')[-1].split('/')[-1]),  # for infop and security reasons
        'content_type': magic.from_buffer(file_info['body'], mime=True),
        'client_content_type': file_info['content_type'],
        'size': len(file_info['body']),
        'visitor_id': visitor_id
    }

    if file_info['content_type'].startswith('image'):
        rotated = False

        image = Image.open(file_path)

        try:
            exif = {
                ExifTags.TAGS[k]: v
                for k, v in image._getexif().items()
                if k in ExifTags.TAGS
            }

            if 'Orientation' in exif:
                rotated = exif['Orientation'] in [5, 6, 7, 8]
        except Exception:
            pass

        descriptor['image'] = {
            'size': {
                'width': image.size[0] if not rotated else image.size[1],
                'height': image.size[1] if not rotated else image.size[0]
            }
        }

    desc_json = json.dumps(descriptor)

    with open(desc_path, 'wb') as f:
        f.write(desc_json)

    return descriptor


DEFAULT_THUMBNAIL_SIZES = {
    "ios": [300, 300],
    "android": [300, 300],
    "web": [300, 300]
}


def clear_filename(filename):
    for symbol in '\n\r+:;<>?\x08\t !#%&@=*':
        filename = filename.replace(symbol, '_')
    return filename


def get_uploaded_file(account_name, guid, thumb=None):
    files_path = os.path.join(wm_settings.settings['client-data-dir'], account_name, 'files')
    file_path = os.path.join(files_path, guid)
    desc_path = file_path + '.desc'

    if not os.path.exists(desc_path):
        raise MissingFileException(guid)

    with open(desc_path, 'r') as f:
        file_desc = json.loads(f.read())

    if thumb:
        if "image" not in file_desc['content_type']:
            raise MissingFileException(guid)

        a = account.Account.get(account_name)
        defaults = DEFAULT_THUMBNAIL_SIZES.copy()
        thumbnail_sizes = merge_dict(defaults, a.get_setting('custom_thumbnail_sizes')) if a.get_setting('custom_thumbnail_sizes') else defaults

        if thumb not in thumbnail_sizes:
            raise MissingThumbnailKeyException(guid, thumb)

        size = thumbnail_sizes[thumb]

        thumb_file_path = file_path + "_" + str(size[0]) + 'x' + str(size[1])

        if os.path.exists(thumb_file_path):
            file_path = thumb_file_path
        else:
            resized_image = Image.open(file_path)

            try:
                exif = {
                    ExifTags.TAGS[k]: v
                    for k, v in resized_image._getexif().items()
                    if k in ExifTags.TAGS
                }

                if 'Orientation' in exif:
                    if exif['Orientation'] == 3:
                        resized_image = resized_image.rotate(180, expand=True)
                    elif exif['Orientation'] == 6:
                        resized_image = resized_image.rotate(270, expand=True)
                    elif exif['Orientation'] == 8:
                        resized_image = resized_image.rotate(90, expand=True)
            except Exception:
                # at least we tried...
                pass

            resized_image.thumbnail(size, Image.ANTIALIAS)

            resized_image.save(thumb_file_path, file_desc['content_type'].split('/')[-1])
            file_path = thumb_file_path

    with open(file_path, 'rb') as f:
        result = f.read()

    return {'content': result,
            'content_type': file_desc['content_type'],
            'content_length': os.path.getsize(file_path),
            'filename': file_desc['filename'],
            'visitor_id': file_desc.get('visitor_id')}


def get_uploaded_file_path(account_name, guid):
    files_path = os.path.join(wm_settings.settings['client-data-dir'], account_name, 'files')
    file_path = os.path.join(files_path, guid)
    desc_path = file_path + '.desc'

    if not os.path.exists(desc_path):
        raise MissingFileException(guid)

    return file_path


def delete_uploaded_file(account_name, guid):
    files_path = os.path.join(wm_settings.settings['client-data-dir'], account_name, 'files')
    file_path = os.path.join(files_path, guid)
    desc_path = file_path + '.desc'

    if not os.path.exists(desc_path):
        raise MissingFileException(guid)

    try:
        os.remove(desc_path)
        os.remove(file_path)
        return {'result': 'ok'}
    except Exception as e:
        logging.error('DeleteFile failed: account_name=%s, file_path=%s' % (account_name, file_path))
        logging.error(str(e), exc_info=True)
        return {'error': 'unknown'}


def calc_file_url_hash(account, guid, expires, hash_key=None):
    key = hash_key or account.get_setting('file_url_hash_key')
    if not key:
        key = new_key()
        account.settings.set('file_url_hash_key', key, False)

    return hmac.new(str(key), guid + str(expires), digestmod=hashlib.sha256).hexdigest()


def new_key():
    uid_as_string = str(uuid.uuid4())
    key = hashlib.md5()
    key.update(uid_as_string)

    return key.hexdigest()


def get_download_file_url(account, file_desc, public=False):
    domain = ('alenyashin.olegb.ru' if account.name == 'alenyashin'
              else 'artur.olebo.ru' if account.name == 'artur'
              else 'devwebimdevru.olegb.ru' if account.name == 'devwebimdevru'
              else wm_settings.get_full_domain(account, public=public))

    guid = file_desc.get('guid')
    filename = file_desc['filename']
    expires = time.time() + account.get_setting('file_url_expiring_timeout')
    file_hash = calc_file_url_hash(account, guid, expires)

    return '{}://{}/l/c/download/{}/{}?expires={}&hash={}'.format(wm_settings.get_protocol(public=public), domain, guid, filename, expires, file_hash)


def request_php_service(account_name, uri, partner_name=None, **params):
    return request_internal(account_name, '/webim/service/' + uri, partner_name=partner_name, **params)


def request_internal(account_name, uri, partner_name=None, **params):
    params_str = '&'.join([name + '=' + str(value) for name, value in params.items()])
    params_str = '?' + params_str if len(params_str) else ''
    url = "http://" + wm_settings.get_full_domain_by_account_name(account_name, partner_name=partner_name) + uri + params_str
    logging.warn('requesting ' + url)
    password_mgr = urllib2.HTTPPasswordMgrWithDefaultRealm()
    password_mgr.add_password(None, url, wm_settings.settings.get('service_user'), wm_settings.settings.get('service_password'))
    handler = urllib2.HTTPBasicAuthHandler(password_mgr)
    response = urllib2.build_opener(handler).open(url).read()
    return response


def external_request(full_url, post_data=None, timeout=10):
    auth = None
    parse = urlparse.urlparse(full_url)
    if parse.username:
        auth = {'user': parse.username, 'password': parse.password}
    url = urlparse.urlunparse((
        parse.scheme,
        '%s:%s' % (parse.hostname, parse.port) if parse.port else parse.hostname,
        parse.path,
        parse.params,
        parse.query,
        parse.fragment
    ))

    req = urllib2.Request(url)
    if post_data:
        if type(post_data) == dict:
            req.add_data(urllib.urlencode(post_data))
        else:
            req.add_data(post_data)
    if auth:
        req.add_header('Authorization', 'Basic ' + base64.urlsafe_b64encode("%s:%s" % (auth['user'], auth['password'])))
    try:
        return urllib2.urlopen(req, timeout=timeout).read()
    except urllib2.URLError as e:
        logging.error('Url %s is not available for reason: %s' % (url, str(e)))
        return None


def urlencode_utf8(params):
    for k in params:
        params[k] = params[k].encode('utf-8') if type(params[k]) == unicode else params[k]
    return urllib.urlencode(params)


slack = SlackBot('xoxp-2308015588-2308015590-2353602210-c0bafc')


def invoke_in_ioloop(callback, name=''):
    if threading.current_thread().ident == IOLoop.current()._thread_ident:
        callback()
        return

    add_ioloop_callback(callback, name=name)


def add_ioloop_callback(callback, name=''):
    def f():
        start = time.time()
        callback()
        duration = time.time() - start
        wm_timer.timer_stats.update({'timer_name': 'ioloop_cb: ' + name, 'func_name': callback.__name__, 'execution_time': duration})
    IOLoop.current().add_callback(f)


def get_current_env():
    current_filename = inspect.getfile(inspect.currentframe())
    env = current_filename[:current_filename.rfind('/webim/')]
    env = env[env.rfind('/') + 1:]
    return env


def get_current_tornado_descriptor():
    return {
        'instance_id': tornado_instance_id,
        'host': socket.gethostname(),
        'env': get_current_env(),
        'port': tornado.options.options.port
    }


class InsecureFileTypeException(Exception):
    pass


def download_and_store_file(account, file_url, visitor_id, filename=None):
    if not file_url:
        return None

    file_name = filename or file_url.split('/')[-1].split('?')[0]
    if not security_check_file_type(file_name.split('.')[-1], account):
        req = requests.get(file_url)
        file_type = req.headers.get('content-type').split('/')[-1]
        allowed_types = [ext.strip().lower() for ext in account.get_setting('allowed_upload_file_types').split(',') if
                         ext.strip()] if account.get_setting('allowed_upload_file_types') else []
        restricted_types = [ext.strip().lower() for ext in
                            account.get_setting('restricted_upload_file_types').split(',') if
                            ext.strip()] if account.get_setting('restricted_upload_file_types') else []

        if file_type in allowed_types and file_type not in restricted_types:
            file_name = file_name + '.' + file_type
        else:
            raise InsecureFileTypeException

    req = requests.get(file_url)
    file_info = {
        'filename': file_name,
        'content_type': req.headers.get('content-type'),
        'body': req.content
    }

    file_desc = store_file(file_info, visitor_id, account.name)
    return json.dumps(file_desc)


if __name__ == '__main__':
    print check_if_ip_matches_subnet('192.168.1.123', (192, 168, 0, 0), (255, 255, 0, 0))
    print check_if_ip_matches_subnet('192.169.1.123', (192, 168, 0, 0), (255, 255, 0, 0))
    print check_if_ip_matches_subnet('192.168.11.123', (192, 168, 0, 0), (255, 255, 0, 0))
    print check_if_ip_matches_subnet('87.237.112.123', (87, 237, 112, 0), (255, 255, 248, 0))
    print '-'
    print check_if_ip_matches_tvoe_tv_subnet('87.237.112.123')
    print check_if_ip_matches_tvoe_tv_subnet('93.185.176.0')
    print check_if_ip_matches_tvoe_tv_subnet('93.185.177.0')
    print check_if_ip_matches_tvoe_tv_subnet('93.185.191.0')
    print check_if_ip_matches_tvoe_tv_subnet('93.185.192.0')
    print check_if_ip_matches_tvoe_tv_subnet((93, 185, 176 + 64, 0))
    print check_if_ip_matches_tvoe_tv_subnet((93, 185, 176, 0))
