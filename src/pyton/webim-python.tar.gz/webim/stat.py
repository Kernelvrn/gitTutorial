import time

__author__ = 'mixey'


class StatsByPeriod(object):

    def __init__(self, name='', on_reset_callback=None, stats_type=None, period=None):
        self.name = name
        self.last_reset_ts = time.time()
        self.period = period or 60
        self.stats_type = stats_type
        self.prev_collected_stats = self.get_new_collected_stats_instance()
        self.current_collected_stats = self.get_new_collected_stats_instance()
        self.on_reset_callback = on_reset_callback

    def get_new_collected_stats_instance(self):
        if self.stats_type == 'timers':
            return CollectedTimerStats()
        elif self.stats_type == 'failed_timers':
            return CollectedFailedTimerStats()
        elif self.stats_type == 'errors_stat':
            return CollectedErrorsStats()
        elif self.stats_type == 'channels_errors_stat':
            return ChannelsCollectedErrorsStats()
        else:
            return CollectedStats()

    def check_if_need_reset(self):
        now = time.time()
        if now >= self.last_reset_ts + self.period * 2:
            if self.on_reset_callback:
                self.on_reset_callback(self.name, self.current_collected_stats)
            self.last_reset_ts = now
            self.prev_collected_stats = self.get_new_collected_stats_instance()
            self.current_collected_stats = self.get_new_collected_stats_instance()
        elif now >= self.last_reset_ts + self.period:
            if self.on_reset_callback:
                self.on_reset_callback(self.name, self.current_collected_stats)
            self.last_reset_ts = now
            self.prev_collected_stats = self.current_collected_stats
            self.current_collected_stats = self.get_new_collected_stats_instance()

    def update(self, value):
        self.check_if_need_reset()

        # self.prev_collected_stats.update(value)
        self.current_collected_stats.update(value)

    def get_average(self):
        self.check_if_need_reset()
        return self.prev_collected_stats.get_average()

    def get_n(self):
        self.check_if_need_reset()
        return self.prev_collected_stats.n


class CollectedStats(object):

    def __init__(self):
        self.sum = 0
        self.n = 0
        self.max = None

    def update(self, value):
        self.sum += value
        self.n += 1
        if self.max is None or value > self.max:
            self.max = value

    def get_average(self):
        return 1.0 * self.sum / self.n if self.n else 0

    def get_max(self):
        return self.max

    def __str__(self):
        return "max: " + str(self.max if self.max else 0) + ", avg: " + str(self.get_average()) + ", n:" + str(self.n)


class CollectedTimerStats(CollectedStats):

    def __init__(self):
        super(CollectedTimerStats, self).__init__()
        self.data = {}

    def update(self, value):
        if not self.data.get(value['timer_name']):
            self.data[value['timer_name']] = {'count': 0, 'execution_times': []}

        self.data[value['timer_name']]['count'] += 1
        self.data[value['timer_name']]['func_name'] = value['func_name']
        self.data[value['timer_name']]['execution_times'].append(value['execution_time'])

    def get_average(self):
        return 0


class CollectedFailedTimerStats(CollectedStats):

    def __init__(self):
        super(CollectedFailedTimerStats, self).__init__()
        self.data = []

    def update(self, value):
        self.data.append(value)


class CollectedErrorsStats(CollectedStats):

    def __init__(self):
        super(CollectedErrorsStats, self).__init__()
        self.data = {}

    def update(self, value):
        if not self.data.get(value['type']):
            self.data[value['type']] = {value['name']: {'error_cnt': 0}}

        self.data[value['type']][value['name']]['error_cnt'] += 1

    def get_average(self):
        return 0


class ChannelsCollectedErrorsStats(CollectedErrorsStats):

    def __init__(self):
        super(ChannelsCollectedErrorsStats, self).__init__()
        self.data = {
            'channels': {
                'viber': {'error_cnt': 0},
                'telegram': {'error_cnt': 0},
                'whatsapp': {'error_cnt': 0},
                'vk': {'error_cnt': 0},
                'odnoklassniki': {'error_cnt': 0},
                'fb': {'error_cnt': 0},
                'xmpp': {'error_cnt': 0},
                'custom': {'error_cnt': 0}
            }
        }

    def update(self, channel_type):
        super(ChannelsCollectedErrorsStats, self).update(
            {"type": "channels",
             "name": channel_type})