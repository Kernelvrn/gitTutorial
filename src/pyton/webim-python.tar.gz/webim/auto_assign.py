# coding=utf-8

import random
import threading
import logging

import wm_timer
import wm_utils
import wm_callbacks


__author__ = 'mixey'


class AutoAssignController:

    def __init__(self, account, offline):
        self.account = account
        self.offline = offline

        self.__lock = threading.Lock()
        self.__auto_assign_required_flag = False

        self.__next_run_callbacks = wm_callbacks.Callbacks(once=True)

        wm_timer.invoke_periodically(1, self.__run_auto_assign, 'try_auto_assign_chats_in_queue__ offline=' + str(offline))

    def __enabled(self):
        if self.offline:
            auto_assign_offline = self.account.get_setting('auto_assign_offline')
            if auto_assign_offline is not None:
                return auto_assign_offline
        return self.account.get_setting('auto_assign')

    def set_auto_assign_required(self):
        if not self.__enabled():
            return
        self.__auto_assign_required_flag = True

    def add_next_run_callback(self, callback):
        self.__next_run_callbacks.add(callback)

    def __run_auto_assign(self):
        if not self.__enabled():
            return

        if not self.__auto_assign_required_flag:
            return

        self.__auto_assign_required_flag = False

        with self.__lock:

            callbacks = None
            if not self.__next_run_callbacks.is_empty():
                callbacks = self.__next_run_callbacks
                self.__next_run_callbacks = wm_callbacks.Callbacks(once=True)

            try:
                if self.account.get_setting('operator_department_prioritization'):
                    self.__run_auto_assign_department_prioritization_logic(self.__calc_operator_id_to_chats_cnt_and_vacant_places_cnt())
                else:
                    self.__run_auto_assign_regular_logic(self.__calc_operator_id_to_chats_cnt_and_vacant_places_cnt())

            except Exception:
                logging.error('auto_assign failed offline=' + str(self.offline), exc_info=True)

            finally:
                self.update_overlimit_chat_availibility_for_operators()
                if callbacks:
                    callbacks.fire()

    def __run_auto_assign_regular_logic(self, operator_id_to_chats_cnt_and_vacant_places_cnt):
        queues = self.account.queue_manager.get_queues(offline=self.offline)

        while queues:
            min_chat, min_queue = self.__find_min_chat_and_queue(self.account.queue_manager.chat_in_queue_order_key_function, queues)

            if min_chat:
                try:
                    assigned_operator_id = self.__auto_assign_chat(min_chat, operator_id_to_chats_cnt_and_vacant_places_cnt)
                except ChatAutoAssignException:
                    min_queue.remove_chat(min_chat)
                    continue

                if assigned_operator_id:
                    self.__decrease_vacant_places_cnt(operator_id_to_chats_cnt_and_vacant_places_cnt, assigned_operator_id)
                    if not operator_id_to_chats_cnt_and_vacant_places_cnt:
                        return
                else:
                    queues.remove(min_queue)

    def __run_auto_assign_department_prioritization_logic(self, operator_id_to_chats_cnt_and_vacant_places_cnt):
        # logging_prefix = '#auto_assign @ ' + self.account.name
        # logging.warn(logging_prefix + ' operator_id_to_chats_cnt_and_vacant_places_cnt: ' + str(operator_id_to_chats_cnt_and_vacant_places_cnt))
        priority_to_dep_and_lang_to_operator_ids = self.__build_priority_to_dep_and_lang_to_operator_ids(operator_id_to_chats_cnt_and_vacant_places_cnt.keys())
        # logging.warn(logging_prefix + ' priority_to_dep_and_lang_to_operator_ids: ' + str(priority_to_dep_and_lang_to_operator_ids))
        priorities = sorted(priority_to_dep_and_lang_to_operator_ids.keys())

        # priority == 1 -> highest priority
        for priority in priorities:
            dep_and_lang_to_operator_ids = priority_to_dep_and_lang_to_operator_ids.get(priority)
            queues = [q for q in self.account.queue_manager.get_queues(offline=self.offline) if (q.dep_key, q.lang) in dep_and_lang_to_operator_ids]
            # logging.warn(logging_prefix + ' priority: ' + str(priority) + ', queues: ' + str([(q.dep_key, q.lang) for q in queues]))

            while queues:
                min_chat, min_queue = self.__find_min_chat_and_queue(self.account.queue_manager.chat_in_queue_order_key_function, queues)

                if min_chat:
                    _operator_id_to_chats_cnt_and_vacant_places_cnt = {}
                    for operator_id in dep_and_lang_to_operator_ids[(min_queue.dep_key, min_queue.lang)]:
                        if operator_id in operator_id_to_chats_cnt_and_vacant_places_cnt:
                            _operator_id_to_chats_cnt_and_vacant_places_cnt[operator_id] = operator_id_to_chats_cnt_and_vacant_places_cnt.get(operator_id)
                    # logging.warn(logging_prefix + ' min_chat: ' + str(min_chat.id) + ',' + str(min_chat.session.id)
                    #              + ', min_queue: ' + str((min_queue.dep_key, min_queue.lang))
                    #              + ', _operator_id_to_chats_cnt_and_vacant_places_cnt: ' + str(_operator_id_to_chats_cnt_and_vacant_places_cnt))
                    if not _operator_id_to_chats_cnt_and_vacant_places_cnt:
                        queues.remove(min_queue)
                        continue

                    try:
                        assigned_operator_id = self.__auto_assign_chat(min_chat, _operator_id_to_chats_cnt_and_vacant_places_cnt)
                    except ChatAutoAssignException:
                        min_queue.remove_chat(min_chat)
                        continue
                    # logging.warn(logging_prefix + ' min_chat: ' + str(min_chat.id) + ','
                    #  + str(min_chat.session.id) + ', assigned_operator_id: ' + str(assigned_operator_id))
                    if assigned_operator_id:
                        self.__decrease_vacant_places_cnt(operator_id_to_chats_cnt_and_vacant_places_cnt, assigned_operator_id)
                        if not operator_id_to_chats_cnt_and_vacant_places_cnt:
                            return
                    else:
                        queues.remove(min_queue)

    def __auto_assign_chat(self, ch, operator_id_to_chats_cnt_and_vacant_places_cnt, produce_delta=True):
        account = self.account
        # if not self.__enabled():
        #     return None

        # if operator_id_to_chats_cnt_and_vacant_places_cnt is None:
        #     operator_id_to_chats_cnt_and_vacant_places_cnt = self.__calc_operator_id_to_chats_cnt_and_vacant_places_cnt(
        #         ch.offline, lambda o: o.matches((ch.session.lang, ch.session.department_key)))

        operator_id = None

        if account.get_setting('auto_assign_to_last_chat_operator') and ch.session.visitor.last_chat_operator_id:
            oo = account.oo_manager.get(ch.session.visitor.last_chat_operator_id)
            if oo and oo.is_online():
                o = oo.get_operator()
                if o and o.matches((ch.session.lang, ch.session.department_key)):
                    if account.get_setting('auto_assign_to_last_chat_operator_if_busy') or \
                            operator_id_to_chats_cnt_and_vacant_places_cnt.get(o.id, (0, 0))[1] > 0:
                        operator_id = o.id
                        # logging.warn('#auto_assign @ ' + account.name + ' chat: ' + str(ch.id) + ',' + str(ch.session.id)
                        #              + ', auto_assign_to_last_chat_operator, operator_id: ' + str(operator_id))

        if not operator_id:

            min_count = None
            operator_ids_with_min_count = None
            for operator_id, (cnt, vacant_cnt) in operator_id_to_chats_cnt_and_vacant_places_cnt.items():
                o = account.get_operator(operator_id)
                if o and o.matches((ch.session.lang, ch.session.department_key)):
                    if vacant_cnt <= 0:
                        continue
                    if min_count is None or cnt < min_count:
                        min_count = cnt
                        operator_ids_with_min_count = [operator_id]
                    elif cnt == min_count:
                        operator_ids_with_min_count.append(operator_id)

            if not operator_ids_with_min_count:
                return None

            if account.get_setting('auto_assign_priority_by_last_chat_assigned_ts'):
                operator_id = min(operator_ids_with_min_count, key=lambda op_id: account.oo_manager.get(op_id).last_chat_assigned_ts)
            elif account.get_setting('auto_assign_priority_by_operator_order'):
                operator_id = min(operator_ids_with_min_count, key=lambda op_id: account.get_operator(op_id).order)
            else:
                operator_id = random.choice(operator_ids_with_min_count)

        if not operator_id:
            return None

        ch.process_event('sys.auto_assign', {'operator_id': operator_id}, produce_delta)

        if ch.get_operator_id() != operator_id:
            logging.warn('Failed to auto_assign chat through sys.auto_assign event. Chat id: ' + str(ch.id) +
                         ' chat state: ' + str(ch.state) + ' session_id: ' + ch.session.id)
            raise ChatAutoAssignException

        return operator_id

    @staticmethod
    def __find_min_chat_and_queue(key_function, queues):
        min_chat = None
        min_queue = None
        for queue in list(queues):
            ch = queue.get_first()
            if not ch:
                queues.remove(queue)
                continue
            if not min_chat or key_function(ch) < key_function(min_chat):
                min_chat = ch
                min_queue = queue

        return min_chat, min_queue

    def __build_priority_to_dep_and_lang_to_operator_ids(self, operator_ids):
        result = wm_utils.DictExt(lambda k: wm_utils.DictExt(lambda k: []))
        default_priority = self.account.get_setting('default_operator_department_priority')
        for operator_id in operator_ids:
            o = self.account.get_operator(operator_id)
            for dep_key, priority in o.department_key_to_priority.items():
                for lang in o.locales:
                    result.get(priority or default_priority).get((dep_key, lang)).append(operator_id)
        return result

    def __calc_operator_id_to_chats_cnt_and_vacant_places_cnt(self):
        account_max_chats_per_operator = self.account.get_setting('max_chats_per_operator')
        operator_id_to_chats_count = self.account.visit_tracker.count_chats_per_operator(offline=self.offline)
        result = {}
        for oo in self.account.oo_manager.get_alive_online_operators():
            o = oo.get_operator()
            if o.is_robot():
                continue
            max_chats_per_operator = o.get_setting('max_chats_per_operator') or account_max_chats_per_operator
            cnt = operator_id_to_chats_count.get(o.id, 0)
            if cnt < max_chats_per_operator:
                result[o.id] = (cnt, max_chats_per_operator - cnt)
        return result

    @staticmethod
    def __decrease_vacant_places_cnt(operator_id_to_chats_cnt_and_vacant_places_cnt, operator_id):
        cnt, vacant_cnt = operator_id_to_chats_cnt_and_vacant_places_cnt[operator_id]
        if vacant_cnt <= 1:
            del operator_id_to_chats_cnt_and_vacant_places_cnt[operator_id]
        else:
            operator_id_to_chats_cnt_and_vacant_places_cnt[operator_id] = (cnt + 1, vacant_cnt - 1)

    def assign_overlimit_chat(self, operator):
        with self.__lock:
            if not self.check_overlimit_chat_abilitity(operator):
                return

            operator_id_to_chats_count = self.account.visit_tracker.count_chats_per_operator()
            cnt = operator_id_to_chats_count.get(operator.id, 0)
            operator_id_to_chats_cnt_and_vacant_places_cnt = {operator.id: (cnt, 1)}
            try:
                if self.account.get_setting('operator_department_prioritization'):
                    self.__run_auto_assign_department_prioritization_logic(operator_id_to_chats_cnt_and_vacant_places_cnt)
                else:
                    self.__run_auto_assign_regular_logic(operator_id_to_chats_cnt_and_vacant_places_cnt)

            except Exception:
                logging.error('assign_overlimit_chat failed', exc_info=True)

            finally:
                self.update_overlimit_chat_availibility_for_operators()

    def check_overlimit_chat_abilitity(self, operator):
        account = self.account
        operator_id_to_chats_count = account.visit_tracker.count_chats_per_operator()
        cnt = operator_id_to_chats_count.get(operator.id, 0)
        max_chats_per_operator = operator.get_setting('max_chats_per_operator') or account.get_setting('max_chats_per_operator')
        max_overlimit_chats_per_operator = operator.get_setting('max_overlimit_chats_per_operator') or account.get_setting('max_overlimit_chats_per_operator')
        if max_chats_per_operator + max_overlimit_chats_per_operator <= cnt:
            return False

        queues = account.queue_manager.get_queues(offline=self.offline)
        for queue in list(queues):
            for ch in queue.chats_in_queue:
                if account.get_setting('auto_assign_to_last_chat_operator') and ch.session.visitor.last_chat_operator_id:
                    oo = account.oo_manager.get(ch.session.visitor.last_chat_operator_id)
                    if oo and oo.is_online():
                        o = oo.get_operator()
                        if o and o.matches((ch.session.lang, ch.session.department_key)):
                            if o.id == operator.id:
                                return True
                            continue

                if operator.matches((ch.session.lang, ch.session.department_key)):
                    return True

        return False

    def update_overlimit_chat_availibility_for_operators(self):
        """Метод проверки и обновления возможности добавления чатов сверх лимита

        Каждый оператор в онлайне проверяется на возможность присоединения чата сверх лимита max_chats_per_operator.
        В результате проверки для каждого из этих операторов вызывается метод update_overlimit_chat_availibility,
        отправляющий дельту OVERLIMIT_CHAT с bool-значением возможности присоединения.
        Такая возможность есть, если есть чаты, которые могут быть распределены на оператора,
        и количество чатов оператора меньше max_overlimit_chats_per_operator
        """
        account = self.account
        operators_to_check = set()
        operator_id_to_chats_count = account.visit_tracker.count_chats_per_operator()

        for oo in account.oo_manager.get_alive_online_operators():
            o = oo.get_operator()
            cnt = operator_id_to_chats_count.get(o.id, 0)
            max_chats_per_operator = o.get_setting('max_chats_per_operator') or account.get_setting('max_chats_per_operator')
            max_overlimit_chats_per_operator = o.get_setting('max_overlimit_chats_per_operator') or account.get_setting('max_overlimit_chats_per_operator')
            if max_chats_per_operator + max_overlimit_chats_per_operator > cnt:
                operators_to_check.add(o.id)
            else:
                oo.update_overlimit_chat_availibility(False)

        queues = account.queue_manager.get_queues(offline=self.offline)
        for queue in list(queues):
            if not operators_to_check:
                break
            for ch in queue.chats_in_queue:
                if not operators_to_check:
                    break
                if account.get_setting('auto_assign_to_last_chat_operator') and ch.session.visitor.last_chat_operator_id:
                    oo = account.oo_manager.get(ch.session.visitor.last_chat_operator_id)
                    if oo and oo.is_online():
                        o = oo.get_operator()
                        if o and o.id in operators_to_check and o.matches((ch.session.lang, ch.session.department_key)):
                            oo.update_overlimit_chat_availibility(True)
                            operators_to_check.remove(o.id)
                            continue

                for operator_id in list(operators_to_check):
                    o = account.get_operator(operator_id)
                    if o and o.id in operators_to_check and o.matches((ch.session.lang, ch.session.department_key)):
                        account.oo_manager.get(o.id).update_overlimit_chat_availibility(True)
                        operators_to_check.remove(o.id)

        for operator_id in operators_to_check:
            account.oo_manager.get(operator_id).update_overlimit_chat_availibility(False)


class ChatAutoAssignException(wm_utils.WebimException):
    pass
