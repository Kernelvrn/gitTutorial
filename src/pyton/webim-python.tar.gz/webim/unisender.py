# -*- coding: utf8 -*-
__author__ = 'agorodishenin'
import json
import logging
import urllib2

import tornado.web

import db_utils
import wm_operator
import wm_timer
from wm_utils import urlencode_utf8


class ExportContactsToUnisenderRequestHandler(wm_operator.BaseOperatorRequestHandler):
    @tornado.web.asynchronous
    def get(self, *args, **kwargs):
        def async_import_all_contacts():
            account = self.get_account()
            unisender = Unisender(account)
            self.finish(unisender.import_all_contacts())

        wm_timer.invoke_async(async_import_all_contacts, "export_contacts_to_unisender")


class Unisender:
    def __init__(self, account):
        self.url = "https://api.unisender.com/ru/api/{method}?format=json"
        self.account = account
        self.settings = None
        self.opener = urllib2.build_opener()

    def check_settings(self):
        self.settings = self.account.get_setting('unisender')
        return True if self.settings and self.settings.get('unisender_api_key') else False

    def create_list(self):
        return self.__do_request('createList', {'title': self.settings['unisender_list_name']},
                                 lambda data: data.get('result', {}).get('id'))

    def get_lists(self):
        result = {}
        lists = self.__do_request('getLists', None,
                                  lambda data: data.get('result'))
        for item in lists:
            result[item['title']] = item['id']
        return result

    def do_import_contacts(self, list_id, contacts):
        post_data = {
            'field_names[0]': 'email',
            'field_names[1]': 'Name',
            'field_names[2]': 'phone',
            'field_names[3]': 'email_list_ids',
            'field_names[4]': 'tags',
            'double_optin': 1
        }

        for i, item in enumerate(contacts):
            post_data["data[%s][0]" % i] = item['email']
            post_data["data[%s][1]" % i] = item['name']
            post_data["data[%s][2]" % i] = item.get('phone', '')
            post_data["data[%s][3]" % i] = list_id
            post_data["data[%s][4]" % i] = 'webim'

        return self.__do_request('importContacts', post_data,
                                 lambda data: data.get('result', {}))

    def get_contacts(self):
        connection = db_utils.get_connection(self.account.name)
        rows = connection.query('SELECT json FROM chatvisitsession WHERE json IS NOT NULL')
        connection.close()
        result = []
        for row in rows:
            data = json.loads(row.get('json', '{}'))
            if data.get('visitor', {}).get('fields', {}).get('email'):
                result.append({
                    'email': data.get('visitor', {}).get('fields', {}).get('email'),
                    'phone': data.get('visitor', {}).get('fields', {}).get('phone'),
                    'name': data.get('visitor', {}).get('fields', {}).get('name'),
                })
        return result

    def import_all_contacts(self):
        if not self.check_settings():
            return

        list_id = self.get_lists().get(self.settings['unisender_list_name']) or self.create_list()
        contacts = self.get_contacts()
        if list_id:
            return self.do_import_contacts(list_id, contacts)

    def do_add_contact(self, visitor):
        list_id = self.get_lists().get(self.settings['unisender_list_name']) or self.create_list()
        post_data = {'list_ids': list_id,
                     'double_optin': 1,
                     'fields[email]': visitor['email'],
                     'fields[Name]': visitor['name'],
                     'fields[phone]': visitor.get('phone'),
                     'tags': 'webim'}
        return self.__do_request('subscribe', post_data,
                                 lambda data: data.get('result', {}).get('person_id'))

    def add_contact(self, chat):
        if not self.check_settings():
            return
        visitor = chat.session.visitor.get_merged_fields()
        if visitor.get('email'):
            self.do_add_contact(visitor)

    def __do_request(self, method, post_data, get_response_value):
        url = self.url.format(method=method)
        params = {'api_key': self.settings['unisender_api_key']}
        params.update(post_data if post_data else {})
        request = urllib2.Request(url, urlencode_utf8(params))
        try:
            response_text = urllib2.urlopen(request).read()
            try:
                response_data = json.loads(response_text)
                if response_data.get('error'):
                    logging.error('Unisender failed method %s: %s' % (method, response_text))
                    return None
                return get_response_value(response_data)
            except ValueError, error:
                logging.error('Unisender failed method %s. Wrong JSON response: %s' % (method, error))
                return None
        except urllib2.HTTPError, error:
            logging.error('Unisender failed method %s. HTTP Error: %s ' % (method, error.read()))
            return None