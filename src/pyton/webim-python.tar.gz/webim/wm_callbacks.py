__author__ = 'mixey'

import threading

import wm_timer


class Callbacks:

    def __init__(self, once=False, memory=False):
        self.lock = threading.Lock()
        self.callbacks = []
        self.fired = False
        self.once = once
        self.memory = memory

    def add(self, callback):
        with self.lock:
            if not self.once or not self.fired:
                self.callbacks.append(callback)
            if self.memory and self.fired:
                self.__invoke_callback(callback)

    def is_empty(self):
        return len(self.callbacks) == 0

    def fire(self):
        with self.lock:
            if self.once and self.fired:
                return
            self.fired = True
            for callback in self.callbacks:
                self.__invoke_callback(callback)
            if self.once:
                self.callbacks = []

    def __invoke_callback(self, callback):
        wm_timer.invoke_async(callback, 'callbacks')