import logging
import copy

import sleekxmpp

import wm_channels
from .. import chat
from .. import wm_timer
from .. import delta
from .. import visitor_tracking


class XMPPBot(sleekxmpp.ClientXMPP):

    channel_settings = wm_channels.BaseChannelRequestHandler.Settings(
        channel_type='xmpp',
        for_hash=None,
        start_page_url='https://xmpp.org/',
        start_page_title='XMPP',
        location='xmpp',
        ua='XMPP',
    )

    def __init__(self, jid, password, host, port, account, channel_id):
        if not jid or not password:
            return

        sleekxmpp.ClientXMPP.__init__(self, jid, password)

        self.account = account
        self.channel_id = channel_id

        self.jid = jid
        self.host = host
        self.port = port
        self.password = password

        self.online_status = False

        self.register_plugin('xep_0030')  # Service Discovery
        self.register_plugin('xep_0004')  # Data Forms
        self.register_plugin('xep_0060')  # PubSub
        self.register_plugin('xep_0199')  # XMPP Ping
        self.register_plugin('xep_0092')
        self.register_plugin('xep_0184')

        self['feature_mechanisms'].unencrypted_plain = True

        self['xep_0092'].software_name = 'Webim XMPP Bot'
        self['xep_0092'].version = '0.1'

        self.auth_status = True

        if self.do_connect(host, port):
            self.process(block=False)
            self.connect_status = True
            self.update_online_status()
            logging.warn('XMPP | Client and server connect: Done')
        else:
            self.connect_status = False
            self.update_online_status()
            logging.warn('XMPP | Client and server connect: Unable')

        # self.auto_authorize = True
        self.auto_subscribe = True

        self.add_event_handler("session_start", self.on_start)
        self.add_event_handler("message", self.on_message)

        self.add_event_handler('no_auth', self.on_auth_failed)
        self.add_event_handler('disconnected', self.on_disconnected)

    def do_connect(self, host=None, port=None):
            return self.connect(address=(host, port), use_tls=False) if host and port else self.connect(use_tls=False)

    def on_auth_failed(self, event):
        logging.warn('XMPP | Authorisation failed for %s' % self.jid)
        self.auth_status = False
        self.update_online_status()

    def on_disconnected(self, event):
        self.connect_status = False
        self.update_online_status()
        logging.warn('XMPP | Lost connect')
        self.recreate_bot()

    def recreate_bot(self):
        self.disconnect(wait=True)
        new_bot = XMPPBot(self.jid, self.password, self.host, self.port, self.account, self.channel_id)
        del(self.account.xmpp_bot_manager.bots[self.channel_id])
        self.account.xmpp_bot_manager.bots[self.channel_id] = new_bot

    def update_online_status(self):
        if self.auth_status and self.connect_status:
            self.online_status = True
        else:
            self.online_status = False

    def on_start(self, event):
        self.send_presence()
        # self.get_roster()

    def on_message(self, msg):
        # Ignore anything from ourself
        if msg['from'].bare == self.boundjid.bare:
            return

        channel = self.account.get_setting('channels').get(self.channel_id)
        if not channel:
            return

        msg_from = str(msg['from']).split('/')[0]

        session = self.get_visit_session(msg, msg_from, self.channel_id, channel)

        if not session.chat:
            wm_channels.channel_visitor_helper.create_and_set_chat(channel, session)

        if msg['type'] == 'error':
            return

        chat.Message.create(
            session.chat,
            chat.Message.Kind.VISITOR,
            session.visitor.channel_user_id,
            msg['body']
        )

        # DEBUG disconnected
        # self.disconnect(wait=True)

    def get_visit_session(self, data, channel_user_id, channel_id, channel):
        visit_session = self.account.visit_tracker.get_session_by_visitor_id(channel_user_id)
        return visit_session or self.create_new_visit_session(channel_user_id, data, channel, channel_id)

    def create_new_visit_session(self, visitor_id, data, channel, channel_id):
        visited_page = visitor_tracking.VisitedPage.create(
            url=self.channel_settings.start_page_url,
            referer=None,
            title=self.channel_settings.start_page_title,
            lang='ru',
            department_key=channel.get('dep_key'),
            location=self.channel_settings.location
        )

        channel_user_id, fields, user_name = self.get_visitor_info(data, channel)

        visitor = visitor_tracking.Visitor(
            self.account,
            visitor_id,
            fields=fields,
            channel_type=self.channel_settings.channel_type,
            channel_id=channel_id,
            channel_user_id=channel_user_id,
            channel_user_name=user_name
        )

        session = visitor_tracking.VisitSession.create(self.account, '', self.channel_settings.ua, 'web',
                                                       None, visited_page, visitor, None, False)

        self.account.visit_tracker.id_to_visited_page[visited_page.id] = visited_page
        session.add_page(visited_page)
        self.account.visit_tracker.add_session(session)
        visited_page.ping(10)

        logging.warn('%s: new session created' % self.channel_settings.channel_type)

        wm_timer.invoke_async(lambda: self.update_visitor_avatar(session), timer_name='xmpp update_visitor_avatar')

        return session

    def get_visitor_info(self, data, channel):
        return str(data['from']).split('/')[0], {'name': str(data['from']).split('/')[0]}, str(data['from']).split('/')[0]

    def update_visitor_avatar(self, session):
        pass

    def get_username(self, msg):
        return str(msg['from']).split('@')[0]

    def get_params(self):
        return {'jid': self.jid, 'password': self.password, 'host': self.host, 'port': self.port}

    def set_params(self, params):
        self.jid = params.get('jid')
        self.password = params.get('password')
        self.host = params.get('host')
        self.port = params.get('port')
        self.account = params.get('account')
        self.channel_id = params.get('channel_id')


class XMPPBotManager(wm_channels.BaseChannelAPI):

    def __init__(self, account):
        super(XMPPBotManager, self).__init__(account)
        self.bots = {}
        self.account = account

    def update_bots(self):
        channels = self.account.get_setting('channels')
        if not channels or type(channels) != dict:
            return

        self.create_bots(channels)
        self.kill_bots(channels)

    def create_bots(self, channels):
        for channel_id, channel in channels.items():
            if channel.get('type') != 'xmpp':
                continue

            if not self.bots.get(channel_id):
                self.bots[channel_id] = XMPPBot(channel.get('jid'), channel.get('password'),
                                                channel.get('host'), channel.get('port'),
                                                self.account, channel_id)
            else:
                params = self.bots[channel_id].get_params()
                for key, param in params.items():
                    if param == channel.get(key):
                        continue

                    del(self.bots[channel_id])
                    self.bots[channel_id] = XMPPBot(channel.get('jid'), channel.get('password'),
                                                    channel.get('host'), channel.get('port'),
                                                    self.account, channel_id)

                    break

    def kill_bots(self, channels):
        if not self.bots:
            return

        for bot_id in self.bots.keys():
            if bot_id not in channels.keys():
                del(self.bots[bot_id])

    def process_delta(self, d, session):
        channel = self.account.get_setting('channels').get(session.visitor.channel_id)
        if not channel:
            return

        if d.object_type == 'CHAT_MESSAGE':
            if d.event == delta.Delta.Event.ADD:
                message = self.message_preprocessor(copy.copy(d.data))

                if message.kind == chat.Message.Kind.OPERATOR:
                    self.xmpp_send_message(session, message.text)

    def xmpp_send_message(self, session, text):
        bot_id = session.visitor.channel_id
        user_jid = session.visitor.channel_user_id
        msg_type = 'normal' if text == 'Your request will be switch to operator' else 'chat'
        bot = self.bots.get(bot_id)
        bot.send_message(user_jid, text, mtype=msg_type)
