__author__ = 'andrew'

import json
import logging
import time
import os
import copy

import requests

import wm_channels
from .. import chat
from .. import wm_timer
from .. import delta
from .. import wm_utils
from .. import wm_settings


class BlingerWhatsappWebhookRequestHandler(wm_channels.BaseChannelRequestHandler):

    SETTINGS = wm_channels.BaseChannelRequestHandler.Settings(
        channel_type='blinger_whatsapp',
        for_hash=None,
        start_page_url='https://www.whatsapp.com/',
        start_page_title='Whatsapp',
        location='whatsapp',
        ua='BlingerWhatsapp',
    )

    def __init__(self, request, application, **kwargs):
        super(BlingerWhatsappWebhookRequestHandler, self).__init__(self.SETTINGS, request, application, **kwargs)

    def get(self):
        self.post()

    def post(self):
        logging.warn('BlingerWhatsapp: request processing start')
        data = json.loads(self.request.body)
        logging.warn('BlingerWhatsapp: request %s' % str(data))
        bot_user_id = data.get('to_user_id')

        channel, channel_id = self.get_channel_by_user_id(bot_user_id)

        if not channel:
            logging.warn('BlingerWhatsapp: not channel')
            return

        # no secret for whatsapp
        # if not self.check_secret(channel, channel_id, secret):
        #     return

        logging.warn('BlingerWhatsapp: before invoke_async __on_message')
        wm_timer.invoke_async(lambda: self.__on_message(data, channel_id, channel), timer_name='whatsapp on_message',
                              order_importance_key='channel_req_%s_%s' % (str(channel_id), str(self.request_user_id)))
        self.finish()

    def get_channel_by_user_id(self, user_id):
        channels = self.get_account().get_setting('channels')
        if not channels or not user_id:
            logging.warn('BlingerWhatsapp: not channels')
            return None, None

        channel = None
        channel_id = None

        for id, ch in channels.items():
            if ch['type'] == 'whatsapp' and str(ch['user_id']) == str(user_id):
                channel = ch
                channel_id = id
                break

        return channel, channel_id

    def __on_message(self, data, channel_id, channel):
        session = self.get_visit_session(data, channel_id, channel)
        logging.warn('BlingerWhatsapp: request session %s, data %s' % (session.id, str(data)))

        if not session.chat:
            self.create_and_set_chat(channel, session)

        message_data = data.get('message')

        if message_data['type'] == 'default':
            self.__on_text(message_data, session)
        elif message_data['type'] == 'image':
            self.__on_image(message_data, session)

    def __on_text(self, message_data, session):
        chat.Message.create(
            session.chat,
            chat.Message.Kind.VISITOR,
            session.visitor.get_name(),
            message_data.get('message')
        )

    def __on_image(self, message_data, session):
        file_name = message_data['url'].split('/')[-1]

        if not wm_utils.security_check_file_type(file_name.split('.')[-1], session.account):
            logging.warning('BlingerWhatsappWebhookRerquestHandler %s: security_check_file_type for %s failed' % (session.account.name, file_name))
            return

        req = requests.get(message_data['url'])
        file_info = {
            'filename': file_name,
            'content_type': req.headers.get('content-type'),
            'body': req.content
        }

        file_desc = wm_utils.store_file(file_info, session.visitor.id, session.account.name)
        if file_desc:
            chat.Message.create(session.chat, chat.Message.Kind.FILE_VISITOR, session.visitor.get_name(), json.dumps(file_desc))

    def get_visitor_info(self, data, channel):
        user_id = data['from_user_id']

        user_data = self.get_account().blinger_whatsapp_api.get_user_data(data['from_user_id'], channel)
        fields = {
            'name': user_data.get('name'),
            'phone': user_data.get('phone_number')
        }

        user_name = user_data.get('phone_number')

        return user_id, fields, user_name

    def update_visitor_avatar(self, session):
        session.account.blinger_whatsapp_api.update_visitor_avatar(session)

    @staticmethod
    def _get_user_id_from_request_body(request_body):
        data = json.loads(request_body)
        return data.get('from_user_id')

    def _get_channel_id(self):
        data = json.loads(self.request.body)
        bot_user_id = data.get('to_user_id')

        channel, channel_id = self.get_channel_by_user_id(bot_user_id)

        return channel_id

    def requires_ban_status_checking(self):
        return True


class BlingerWhatsappAPI(wm_channels.BaseChannelAPI):

    def __init__(self, account):
        super(BlingerWhatsappAPI, self).__init__(account)

    def process_delta(self, d, visit_session):
        channel = self.account.get_setting('channels').get(visit_session.visitor.channel_id)
        if not channel or not channel.get('token'):
            return

        if type(d) == list:
            for dd in d:
                self.process_delta(dd, visit_session)
            return

        if d.object_type == 'CHAT_MESSAGE':
            if d.event == delta.Delta.Event.ADD:
                message = self.message_preprocessor(copy.copy(d.data))

                if message.kind == chat.Message.Kind.OPERATOR:
                    self.send_message(message.text, visit_session)

                if message.kind == chat.Message.Kind.FILE_OPERATOR:
                    file_desc = json.loads(message.text)
                    self.send_file(file_desc, visit_session)

        if d.object_type == 'CHAT_OPERATOR_TYPING':
            if d.event == delta.Delta.Event.UPDATE and d.data:
                pass
                # self.send_operator_typing(visit_session)

    def make_request(self, method_name, session, params):
        channel = self.account.get_setting('channels').get(session.visitor.channel_id)

        if not channel:
            return

        h = {
            "Authorization": "Bearer %s" % channel.get('token')
        }

        start = time.time()
        r = requests.post('https://api.blinger.ru/1.0/%s' % method_name, json=params, headers=h)
        logging.warn('Request %s took %s seconds' % (method_name, str(time.time() - start)))

        response = r.json()

        if r.status_code == 200 and not response.get('errors'):
            logging.warn('BlingerWhatsappAPI: success request {} {}. Response: {}'.format(method_name, str(params), str(response)))
            return response
        else:
            logging.error('BlingerWhatsappAPI error: account={}, method={}, params={}, error_msg={}, status_code={}, text={}'
                          .format(self.account.name,
                                  method_name,
                                  str(params),
                                  str(response.get('errors')),
                                  r.status_code,
                                  r.text))

            return {}

    def get_user_data(self, user_id, channel):
        h = {
            "Authorization": "Bearer %s" % channel.get('token')
        }
        start = time.time()
        r = requests.post('https://api.blinger.ru/1.0/%s' % 'user.get', json={'user_id': int(user_id)}, headers=h)
        logging.warn('Request %s took %s seconds' % ('user.get', str(time.time() - start)))

        response = r.json()
        if response.get('errors'):
            logging.error(
                'BlingerWhatsappAPI error: account={}, method={}, params={}, error_msg={}, status_code={}, text={}'
                .format(self.account.name,
                        'user.get',
                        str({'user_id': int(user_id)}),
                        str(response.get('errors')),
                        r.status_code,
                        r.text))
            return {}
        else:
            logging.warn('BlingerWhatsappAPI: success request {} {}. Response: {}'.format({'user.get'}, str({'user_id': int(user_id)}), str(response)))
            return response.get('response').get('user_whatsapp')

    def get_message(self, message_id, session):
        resp = self.make_request('message.get', session, {'message_id': int(message_id)})

        return resp.get('response')

    def send_file(self, file_desc, session):
        channel = self.account.get_setting('channels').get(session.visitor.channel_id)

        resp = self.make_request('message.sendFile', session, {
            'from_user_id': int(channel.get('user_id')),
            'to_user_id': int(session.visitor.channel_user_id),
            'url': wm_utils.get_download_file_url(self.account, file_desc, public=True)
        })

        return resp

    def send_message(self, message, session):
        channel = self.account.get_setting('channels').get(session.visitor.channel_id)

        resp = self.make_request('message.sendText', session, {
            'from_user_id': int(channel.get('user_id')),
            'to_user_id': int(session.visitor.channel_user_id),
            'message': message
        })

        return resp

    def update_visitor_avatar(self, session):
        dir_path = os.path.join(wm_settings.settings['client-data-dir'], self.account.name, 'images', 'visitor_avatars')
        file_name = '%s_%s.jpg' % (self.account.name, session.visitor.id)

        if not os.path.isdir(dir_path):
            os.mkdir(dir_path)

        channel = self.account.get_setting('channels').get(session.visitor.channel_id)

        if not channel:
            return

        if os.path.exists(os.path.join(dir_path, file_name)):
            session.visitor.set_avatar_url('/images/visitor_avatars/' + '%s_%s-40x40.jpg' % (self.account.name, session.visitor.id))
            return

        user_data = self.get_user_data(session.visitor.channel_user_id, channel)

        if user_data.get('profile_picture'):
            req = requests.get(
                user_data.get('profile_picture')
            )

            file_info = {
                'filename': file_name,
                'content_type': req.headers.get('content-type'),
                'body': req.content
            }

            wm_utils.store_visitor_avatar(file_info, self.account.name)
            session.visitor.set_avatar_url('/images/visitor_avatars/' + '%s_%s-40x40.jpg' % (self.account.name, session.visitor.id))

    def set_webhook(self, channel, url=None):
        h = {
            "Authorization": "Bearer %s" % channel['token']
        }

        r = requests.post('https://api.blinger.ru/1.0/customer.info', headers=h)
        r = r.json().get('response')

        requests.post('https://api.blinger.ru/1.0/customer.webhook.delete', json={'id': [wh['id'] for wh in r.get('webhooks', [])]}, headers=h)

        if url:
            requests.post('https://api.blinger.ru/1.0/customer.webhook.create', json={'url': url, 'event': 'on_incoming_message', 'format': 'json'}, headers=h)


wm_channels.channel_type_to_settings[BlingerWhatsappWebhookRequestHandler.SETTINGS.channel_type] = BlingerWhatsappWebhookRequestHandler.SETTINGS
wm_channels.channel_type_to_settings['whatsapp'] = BlingerWhatsappWebhookRequestHandler.SETTINGS  # for blinger_whatsapp and whatsapp
