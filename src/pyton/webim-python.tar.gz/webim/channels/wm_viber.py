# -*- coding: utf-8 -*-
import json
import os
import logging
import hmac
import hashlib
import copy

import requests

import wm_channels
from .. import chat
from .. import wm_timer
from .. import delta
from .. import wm_utils
from .. import wm_settings


__author__ = 'andrew'


class ViberRequestHandler(wm_channels.BaseChannelRequestHandler):

    SETTINGS = wm_channels.BaseChannelRequestHandler.Settings(
        channel_type='viber',
        for_hash=None,
        start_page_url='http://www.viber.com/',
        start_page_title='Viber',
        location='viber',
        ua='Viber',
    )

    def __init__(self, request, application, **kwargs):
        super(ViberRequestHandler, self).__init__(self.SETTINGS, request, application, **kwargs)

    def get(self, channel_id):
        self.post(channel_id)

    def post(self, channel_id):
        logging.warn('ViberRequestHandler: got request')

        account = self.get_account()

        channel = self.get_channel(channel_id)
        if not channel:
            logging.warn('ViberRequestHandler: channel not found {}'.format(str(channel_id)))
            return

        data = json.loads(self.request.body)
        logging.warn('ViberRequestHandler: request data {}'.format(str(data)))

        if (not account.get_setting('viber_api_endpoint') and not self.check_secret(channel, channel_id, self.request.headers['X-Viber-Content-Signature'])):
                return

        if data.get('event') == 'message':
            wm_timer.invoke_async(lambda: self.__on_message(data, channel_id, channel),
                                  order_importance_key='channel_req_%s_%s' % (str(channel_id), str(self.request_user_id)))

    def check_secret(self, channel, channel_id, secret):
        account = self.get_account()
        if not channel:
            logging.error('Channel not found')
            return False

        # Need to convert token to byte string, cause hmac doesn't support unicode value as key.
        calculated_content_signature = hmac.new(str(channel['token']), msg=self.request.body,
                                                digestmod=hashlib.sha256).hexdigest()

        if calculated_content_signature != secret:
            logging.error('Channel {} {} {}: wrong secret key - {}'
                          .format(channel.get('type'), channel_id, account.name, secret))
            return False

        return True

    def __on_message(self, data, channel_id, channel):
        session = self.get_visit_session(data, channel_id, channel)
        logging.warn('ViberRequestHandler: request session {}, data {}'.format(session.id, str(data)))

        if not session.chat:
            self.create_and_set_chat(channel, session)

        message = data.get('message', {})

        if message['type'] in ['text', 'contact']:
            self.__on_text_message(message, session)
        elif message['type'] in ['picture', 'file', 'sticker', 'video']:
            self.__on_file_message(message, session)
        elif message['type'] in ['location']:
            self.__on_location_message(message, session)
        elif message['type'] in ['url']:
            self.__on_url_message(message, session)

    @staticmethod
    def __on_text_message(msg, session):
        chat.Message.create(
            session.chat,
            chat.Message.Kind.VISITOR,
            session.visitor.get_name(),
            msg.get('text')
        )

    def __on_file_message(self, msg, session):
        file_url = msg.get('media')
        file_name = file_url.split('/')[-1].split('?')[0]
        self._download_file_and_send_message_for_operator(file_url, session, file_name)

        if msg.get('text'):
            self.__on_text_message(msg, session)

    def __on_location_message(self, msg, session):
        if not msg.get('location'):
            chat.Message.create(
                session.chat,
                chat.Message.Kind.FOR_OPERATOR,
                None,
                session.get_resource('viber.location.no_coords')
            )
            return

        self.post_coordinates_message([msg['location']['lat'], msg['location']['lon']], session)

    def __on_url_message(self, msg, session):
        chat.Message.create(
            session.chat,
            chat.Message.Kind.VISITOR,
            session.visitor.get_name(),
            msg.get('url')
        )

    def get_visitor_info(self, data, channel):
        user = data.get('sender')

        user_id = user['id']
        fields = {}
        if user.get('name'):
            fields['name'] = user.get('name')

        return user_id, fields, user_id

    def requires_ban_status_checking(self):
        return True

    @staticmethod
    def _get_user_id_from_request_body(request_body):
        data = json.loads(request_body)
        if data.get('event') == 'message':
            return data['sender']['id'] if data.get('sender') else None

    def _get_channel_id(self):
        return self.path_kwargs['channel_id']


class ViberAPI(wm_channels.BaseChannelAPI):

    def __init__(self, account):
        super(ViberAPI, self).__init__(account)

    def make_request(self, method_name, session, params):
        channel = self.account.get_setting('channels').get(session.visitor.channel_id)
        if not channel:
            return

        params['type'] = method_name

        logging.warn('Viber - make_request, params: {}'.format(params))

        if self.account.get_setting('viber_api_endpoint'):
            r = requests.post(
                url=self.account.get_setting('viber_api_endpoint'),
                json=params
            )
        else:
            r = requests.post(
                url='https://chatapi.viber.com/pa/send_message',
                json=params,
                headers={'X-Viber-Auth-Token': channel['token']},
                proxies=self.get_proxy_settings()
            )

        response = r.json()

        if r.status_code == 200 and response.get('status_message') == 'ok':
            logging.warn('ViberAPI: success request {} {}. Response: {}'.format(method_name, str(params), str(response)))
            return response
        else:
            error_msg = 'ViberAPI error: account={}, method={}, params={}, error_msg={}, status_code={}, text={}'\
                .format(self.account.name, method_name, str(params), str(response.get('status_message', '')), r.status_code, r.text)
            logging.error(error_msg)
            raise wm_channels.ChannelAPIError(error_msg)

    def get_sender_from_delta(self, session, delta):
        operator = None
        if delta and delta.object_type == 'CHAT_MESSAGE':
            message = delta.data
            operator = self.account.get_operator(message.author_id)
        else:
            if session.chat and session.chat.get_operator():
                operator = session.chat.get_operator()

        if not operator:
            return {
                'name': u'Operator'
            }

        return {
            'name': operator.get_visible_name('ru'),
            'avatar': '%s://%s%s' % (wm_settings.get_protocol(public=True),
                                     wm_settings.get_full_domain(self.account, public=True),
                                     operator.get_operator_avatar_url())
        }

    def process_delta(self, d, visit_session):
        channel = self.account.get_setting('channels').get(visit_session.visitor.channel_id)
        if not channel:
            return

        if type(d) == list:
            for dd in d:
                self.process_delta(dd, visit_session)
            return
        try:
            if d.object_type == 'CHAT_MESSAGE':
                if d.event == delta.Delta.Event.ADD:
                    message = self.message_preprocessor(copy.copy(d.data))

                    if message.kind == chat.Message.Kind.OPERATOR:
                        self.send_message(message.text, visit_session, delta=d)

                    if message.kind == chat.Message.Kind.FILE_OPERATOR:
                        file_desc = json.loads(message.text)
                        self.send_file(file_desc, visit_session)

                    if message.kind == chat.Message.Kind.CONT_REQ:
                        self.send_message(message.text, visit_session, delta=d)

            if d.object_type == 'CHAT_OPERATOR_TYPING':
                if d.event == delta.Delta.Event.UPDATE and d.data:
                    self.send_operator_typing(visit_session)
        except Exception:
            logging.error('ViberAPI: process delta error, delta - %s' % str(d.to_json()), exc_info=True)
            wm_channels.channel_errors.update(visit_session.visitor.channel_type)

    def send_message(self, text, session, delta=None):
        params = {
            'sender': self.get_sender_from_delta(session, delta),
            'receiver': session.visitor.channel_user_id,
            'text': text
        }

        r = self.make_request('text', session, params)
        if not r:
            self.on_message_not_sended(session)

    def send_file(self, file_desc, session):
        if 'jpeg' in file_desc['content_type']:
            self.__send_picture(file_desc, session)
        else:
            self.__send_file(file_desc, session)

    def __send_picture(self, file_desc, session):
        r = self.make_request('picture', session, {
            'receiver': session.visitor.channel_user_id,
            'media': wm_utils.get_download_file_url(self.account, file_desc, public=True),
        })

        if not r:
            self.on_file_not_sended(session)

    def __send_file(self, file_desc, session):
        r = self.make_request('file', session, {
            'receiver': session.visitor.channel_user_id,
            'media': wm_utils.get_download_file_url(self.account, file_desc, public=True),
            'size': os.path.getsize(wm_utils.get_uploaded_file_path(self.account.name, file_desc['guid'])),
            'file_name': file_desc.get('filename')
        })

        if not r:
            self.on_file_not_sended(session)

    def send_operator_typing(self, session):
        pass

    def set_webhook(self, auth_token, url=''):
        response = requests.post('https://chatapi.viber.com/pa/set_webhook',
                                 headers={'X-Viber-Auth-Token': auth_token},
                                 json={'url': url},
                                 proxies=self.get_proxy_settings()).json()
        if response['status'] != 0:
            logging.error('Couldn\'t set webhook. Error message: {}'.format(response['status_message']))
        else:
            if url:
                logging.info('Webhook successfully set.')
            else:
                logging.info('Webhook successfully removed.')


wm_channels.channel_type_to_settings[ViberRequestHandler.SETTINGS.channel_type] = ViberRequestHandler.SETTINGS
