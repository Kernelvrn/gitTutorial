__author__ = 'andrew'

import logging
import hashlib
import copy

from .. import visitor_tracking
from .. import chat
from .. import wm_web
from .. import wm_timer
from .. import wm_resources
from .. import stat
from .. import wm_utils


channel_type_to_settings = {}


class ChannelVisitorHelper(object):

    def get_visit_session_and_created_flag(self, account, settings, visitor_data, add_session_to_visit_tracker=True):
        visitor_id = self.get_visitor_id(settings, visitor_data.get('user_id'), visitor_data.get('channel'))

        visit_session = account.visit_tracker.get_session_by_visitor_id(visitor_id)
        if visit_session:
            return (visit_session, False)

        return (self.create_new_visit_session(account, settings, visitor_id, visitor_data,
                                              add_session_to_visit_tracker=add_session_to_visit_tracker), True)  # (session, bool(created))

    def get_visitor_id(self, settings, channel_user_id, channel):
        m = hashlib.md5()
        m.update(str(channel_user_id).encode('utf-8'))
        m.update(settings.for_hash or settings.channel_type)
        key = channel.get('provided_id_key')
        if key:
            m.update(key)
        return m.hexdigest()

    def create_new_visit_session(self, account, settings, visitor_id, visitor_data, add_session_to_visit_tracker=True):
        visited_page = visitor_tracking.VisitedPage.create(
            account=account,
            url=settings.start_page_url,
            referer=None,
            title=settings.start_page_title,
            lang='ru',
            department_key=visitor_data.get('channel').get('dep_key'),
            location=settings.location,
        )

        visitor = visitor_tracking.Visitor(
            account,
            visitor_id,
            default_visitor_name=wm_resources.get_resource(account, 'ru', 'chat.default.visitorname'),
            fields=visitor_data.get('fields'),
            channel_type=settings.channel_type,
            channel_id=visitor_data.get('channel').get('id'),
            channel_user_id=visitor_data.get('user_id'),
            channel_user_name=visitor_data.get('user_name')
        )

        session = visitor_tracking.VisitSession.create(account, '', settings.ua, 'web', None, visited_page, visitor, None, False)

        if add_session_to_visit_tracker:
            account.visit_tracker.id_to_visited_page[visited_page.id] = visited_page
            session.add_page(visited_page)
            account.visit_tracker.add_session(session)
            visited_page.ping(10)

        logging.warn('%s: new session created' % settings.channel_type)

        # wm_timer.invoke_async(lambda: self.update_visitor_avatar(session), timer_name='wm_channels update_visitor_avatar')

        return session

    def create_and_set_chat(self, channel, session):
        session.set_department(channel.get('dep_key'), session.account.get_setting('default_lang'))
        session.create_and_set_chat (session.landing_page, None, None)
        session.landing_page.ping(10)



class BaseChannelRequestHandler(wm_web.BaseWebimRequestHandler):

    class Settings:
        def __init__(self, channel_type, for_hash, start_page_url, start_page_title, location, ua):
            self.channel_type = channel_type
            self.for_hash = for_hash
            self.start_page_url = start_page_url
            self.start_page_title = start_page_title
            self.location = location
            self.ua = ua

    def __init__(self, channel_settings, request, application, **kwargs):
        self.channel_settings = channel_settings
        super(BaseChannelRequestHandler, self).__init__(request, application, **kwargs)
        self.request_user_id = None

    def prepare(self):
        super(BaseChannelRequestHandler, self).prepare()
        self.request_user_id = self._get_user_id_from_request_body(self.request.body)

        if self.requires_ban_status_checking():
            channel_id = self._get_channel_id()
            if self.request_user_id and channel_id:
                if self.get_account().is_banned_visitor(user_and_channel_id=(self.request_user_id, channel_id)):
                    logging.warning('BaseChannelRequestHandler: request from banned user. Channel: {}, user id: {}'.format(channel_id, self.request_user_id))
                    self.on_request_from_banned_user()

    def check_secret(self, channel, channel_id, secret):
        account = self.get_account()
        if not channel:
            logging.error('Channel not found')
            return False

        if not channel.get('token') or not channel.get('secret_key') == secret:
            logging.error('Channel %s %s %s: wrong secret key - %s' % (channel.get('type'), channel_id, account.name, secret))
            return False

        return True

    def get_visit_session(self, data, channel_id, channel):
        channel_user_id, fields, user_name = self.get_visitor_info(data, channel)
        channel['id'] = channel_id

        visitor_data = {
            'user_id': channel_user_id,
            'channel': channel,
            'fields': fields,
            'user_name': user_name
        }
        channel_settings = copy.deepcopy(self.channel_settings)
        channel_settings.start_page_title = self.get_channel_page_title(channel)

        session, created = channel_visitor_helper.get_visit_session_and_created_flag(
            self.get_account(),
            channel_settings,
            visitor_data)

        if created:
            wm_timer.invoke_async(lambda: self.update_visitor_avatar(session), timer_name='wm_channels update_visitor_avatar')

        return session

    def create_and_set_chat(self, channel, session):
        channel_visitor_helper.create_and_set_chat(channel, session)

    def on_finish(self):
        account = self.get_account()

        if self.get_status() != 200:
            logging.error('BaseChannelRequestHandler @{}: error channel - {}, channel_id - {}, request - {}'
                          .format(account.name,
                                  self.channel_settings.channel_type,
                                  self._get_channel_id(),
                                  self.request.body
                                  )
                          )
            channel_errors.update(self.channel_settings.channel_type)

    @staticmethod
    def post_coordinates_message(coordinates, session):
        if not coordinates:
            no_coordinates_text = session.get_resource('chat.message.location.incorrect_coordinates')
            chat.Message.create(session.chat, chat.Message.Kind.FOR_OPERATOR, None, no_coordinates_text)
            return
        geo_url = 'https://maps.yandex.ru/?text={},{}'.format(coordinates[0], coordinates[1])
        coordinates_text = session.chat.get_resource('chat.message.location.visitor_share', **{'geo_url': geo_url})
        chat.Message.create(session.chat, chat.Message.Kind.VISITOR, session.visitor.get_name(), coordinates_text)

    def get_visitor_info(self, data, channel):
        return None, {}, None

    def update_visitor_avatar(self, session):
        pass

    def requires_ban_status_checking(self):
        return False

    def on_request_from_banned_user(self):
        self.finish()

    def is_request_need_to_be_handled(self, request_data):
        return True

    def get_channel(self, channel_id):
        channels = self.get_account().get_setting('channels') or {}
        channel = channels.get(channel_id)
        if not channel:
            logging.error('{}RequestHandler @{}: channel {} not found'.format(self.channel_settings.channel_type, self.get_account().name, channel_id))
            channel_errors.update(self.channel_settings.channel_type)

        return channel

    @staticmethod
    def _get_user_id_from_request_body(request_body):
        return None

    def _get_channel_id(self):
        return None

    def get_channel_page_title(self, channel):
        return self.channel_settings.start_page_title

    def _download_file_and_send_message_for_operator(self, file_url, session, filename=None):
        try:
            file_desc = wm_utils.download_and_store_file(session.account, file_url, session.visitor.id, filename)
            if file_desc:
                chat.Message.create(session.chat, chat.Message.Kind.FILE_VISITOR, session.visitor.get_name(), file_desc)
        except wm_utils.InsecureFileTypeException:
            self._on_insecure_file_type(file_url, session)

    def _on_insecure_file_type(self, file_url, session):
        text = session.get_resource('chat.message.visitor_file_type_is_not_safe')
        chat.Message.create(session.chat, chat.Message.Kind.FOR_OPERATOR, None, text)
        logging.warning(
            '{}: insecure file type (file_url={}, account={})'.format(
                self.__class__.__name__,
                file_url,
                session.account.name
            )
        )


class BaseChannelAPI(object):

    def __init__(self, account):
        self.account = account

    @staticmethod
    def on_message_not_sended(session):
        chat.Message.create(
            session.chat,
            chat.Message.Kind.FOR_OPERATOR,
            None,
            session.get_resource('chat.error_message.message_not_sended')
        )

    @staticmethod
    def message_preprocessor(message):
        if message.data and message.data.get('markdowns'):
            for markdown_type in message.data.get('markdowns'):
                regex = wm_utils.MARKDOWNS_REGEXP[markdown_type]
                message.text = regex.sub(lambda match: message.replace_markdown_if_not_supported(match, markdown_type), message.text)

        return message

    @staticmethod
    def on_file_not_sended(session):
        chat.Message.create(
            session.chat,
            chat.Message.Kind.FOR_OPERATOR,
            None,
            session.get_resource('chat.error_message.file_not_sended')
        )

    def get_proxy_settings(self):
        return self.account.settings.get_proxy_settings('channels')


class ChannelAPIError(Exception):

    def __init__(self, error_msg):
        self.message = error_msg


channel_errors = stat.StatsByPeriod(name="channels_errors_stat", stats_type="channels_errors_stat")
channel_visitor_helper = ChannelVisitorHelper()
