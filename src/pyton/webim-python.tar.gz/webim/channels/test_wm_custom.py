# -*- coding: utf-8 -*-

import copy

import requests


class Message(object):

    class Type(object):
        text = 'text'
        photo = 'photo'
        file = 'file'
        action = 'action'

    def __init__(self, message_type, text):

        # Write secret and channel id for already created channel.
        self.__base_request_body = {
          'from': {
            'id': 'user',
          },
          'secret': 'Our secret key',
          'channel_id': 'Channel id'
        }

        # Write your base url. https://name.wedibmdev.ru
        base_url = ''
        self.__url = base_url + '/l/ch'

        self.type = message_type
        self.text = text
        self.response = None

    def __make_request(self, request_body):
        response = requests.post(
            self.__url,
            json=request_body,
        )
        return response

    def send(self):
        request_body = copy.deepcopy(self.__base_request_body)
        request_body[self.type] = self.text

        self.response = self.__make_request(request_body)


class Action(object):
    user_typing = 'user-typing'


def main():
    """
    Write method calls here.
    """
    text_msg = Message(Message.Type.text, 'Hello from file')
    text_msg.send()
    print text_msg.response.json()

    photo_msg = Message(Message.Type.photo, 'https://cdn.pixabay.com/photo/2014/03/29/09/17/cat-300572_1280.jpg')
    photo_msg.send()
    print photo_msg.response.json()

    file_msg = Message(Message.Type.file, 'https://cdn.pixabay.com/photo/2014/03/29/09/17/cat-300572_1280.jpg')
    file_msg.send()
    print file_msg.response.json()

    action_msg = Message(Message.Type.action, Action.user_typing)
    action_msg.send()
    print action_msg.response.json()


if __name__ == '__main__':
    main()
