# -*- coding: utf-8 -*-

__author__ = 'andrew'

import json
import os
import logging
import re
import copy

import requests

import wm_channels
from .. import chat
from .. import wm_timer
from .. import delta
from .. import wm_utils
from .. import wm_settings


class VkontakteCallbackAPIRequestHandler(wm_channels.BaseChannelRequestHandler):

    SETTINGS = wm_channels.BaseChannelRequestHandler.Settings(
        channel_type='vk',
        for_hash='vkontakte',
        start_page_url='https://vk.com/',
        start_page_title='vk.com',
        location='vk',
        ua='Vkontakte',
    )

    def __init__(self, request, application, **kwargs):
        super(VkontakteCallbackAPIRequestHandler, self).__init__(self.SETTINGS, request, application, **kwargs)

    def get(self, page_id, *args, **kwargs):
        self.post(page_id, *args, **kwargs)

    def post(self, channel_id, *args, **kwargs):
        data = json.loads(self.request.body)
        logging.warn('VkontakteCallbackAPIRequestHandler: request data  %s' % str(data))

        channel = self.get_channel(channel_id)
        if not channel:
            return

        # TODO BUGZTASKS-3722
        # channel = channels.get(page_id)
        #
        # if 'group_id' not in channel:
        #     channels[page_id]['group_id'] = data.get('group_id')
        #     account.settings.set('channels', json.dumps(channels), async=False)

        if not self.check_secret(channel, channel_id, data.get('secret')):
            return

        if data.get('type') == 'confirmation':
            if channel.get('confirmation_code'):
                self.finish(channel.get('confirmation_code'))
            return
        if data.get('type') == 'message_new':
            wm_timer.invoke_async(lambda: self.__process_message(data, channel_id, channel),
                                  timer_name='vk process_message',
                                  order_importance_key='channel_req_%s_%s' % (str(channel_id), str(self.request_user_id)))

        self.finish('ok')

    def on_request_from_banned_user(self):
        self.finish('ok')

    def emodji_replace(self, match):
        hx = match.group(0)[2:]
        return unichr(int(hx, 16))

    def __process_message(self, data, channel_id, channel, name_by_id=None):
        session = self.get_visit_session(data, channel_id, channel)

        if not session.chat:
            self.create_and_set_chat(channel, session)

        if data['object'].get('body'):
            text = data['object']['body']
            text = re.sub(r'\\u\w\w\w\w\w', self.emodji_replace, text)
            chat.Message.create(session.chat, chat.Message.Kind.VISITOR, session.visitor.get_name(), text)

        if data['object'].get('fwd_messages'):
            text = self.make_message_with_forwarded_messages(data['object'], name_by_id, session)
            if text:
                chat.Message.create(
                    session.chat,
                    chat.Message.Kind.VISITOR,
                    session.visitor.get_name(),
                    session.get_resource('chat.message.forwarded_messages') + text
                )

        self.__process_attachments(data['object'], session)

    def __process_attachments(self, data, session):
        if data.get('geo'):
            self.__on_geo(data['geo'], session)

        if data.get('attachments'):
            for att in data.get('attachments'):
                att_type = att.get('type')
                if att_type == 'photo':
                    self.__on_photo(att['photo'], session)
                elif att_type == 'doc':
                    self.__on_document(att['doc'], session)
                elif att_type == 'link':
                    self.__on_link(att['link'], session)
                elif att_type == 'sticker':
                    self.__on_sticker(att['sticker'], session)
                elif att_type == 'audio':
                    self.__on_audio(att['audio'], session)
                elif att_type == 'video':
                    self.__on_video(att['video'], session)

        if data.get('fwd_messages'):
            for fwd_msg in data.get('fwd_messages'):
                self.__process_attachments(fwd_msg, session)

    def __on_photo(self, photo, session):
        for k in ['photo_2560', 'photo_1280', 'photo_807', 'photo_604', 'photo_130', 'photo_75']:
            if photo.get(k):
                file_url = photo.get(k)
                self._download_file_and_send_message_for_operator(file_url, session)
                break

    def __on_document(self, document, session):
        file_url = document.get('url')
        file_name = document.get('title')
        self._download_file_and_send_message_for_operator(file_url, session, file_name)

    def __on_link(self, link, session):
        link_url = link.get('url')
        if link_url:
            chat.Message.create(session.chat, chat.Message.Kind.VISITOR, session.visitor.get_name(), link_url)

    def __on_audio(self, audio, session):
        audio_url = audio.get('url')
        text = "%s – %s: %s" % (audio.get('artist', ''), audio.get('title'), audio_url)
        chat.Message.create(session.chat, chat.Message.Kind.VISITOR, session.visitor.get_name(), text)

    def __on_video(self, video, session):
        headers = requests.utils.default_headers()
        headers.update({'User-Agent': ''})

        # TODO: решить, что делать с видео, т.к. токен сообщества не позволяет получать ссылки на видяхи
        # этот токен позволяет, но он левый
        # video_access_token = '2f96ae3d66be4c17458b0a7f1fcfc722080bd10a3b5da961bb7c63e99620cb0442af0510207ab964323cb'

        video_url = 'https://vk.com/video%s_%s' % (video.get('owner_id'), video.get('id'))
        title = video['title'] if video.get('title') else session.chat.get_resource('chat.message.default_video_title')
        text = '%s: %s' % (title, video_url)
        chat.Message.create(session.chat, chat.Message.Kind.VISITOR, session.visitor.get_name(), text)

    def __on_sticker(self, sticker, session):
        for k in ['photo_512', 'photo_352', 'photo_256', 'photo_128', 'photo_64']:
            if sticker.get(k):
                file_url = sticker.get(k)
                self._download_file_and_send_message_for_operator(file_url, session)
                break

    def __on_geo(self, geo, session):
        self.post_coordinates_message(geo['coordinates'].split(' '), session)

    def get_visitor_info(self, data, channel):
        user_id = data['object']['user_id']

        user_data = self.get_account().vk_api.get_user_data(user_id, channel)
        fields = {'name': "%s %s" % (user_data.get('first_name', ''), user_data.get('last_name', ''))}

        user_name = user_data.get('screen_name')

        return user_id, fields, user_name

    def update_visitor_avatar(self, session):
        user_data = self.get_account().vk_api.get_user_data(session.visitor.channel_user_id,
                                                            self.get_account().get_setting('channels').get(session.visitor.channel_id))
        session.account.vk_api.update_visitor_avatar(session, vk_photo_url=user_data.get('photo_100'))

    @staticmethod
    def _get_user_id_from_request_body(request_body):
        if request_body:
            data = json.loads(request_body)
            return data['object']['user_id'] if data.get('object') else ''
        else:
            return None

    def _get_channel_id(self):
        return self.path_kwargs['channel_id']

    def requires_ban_status_checking(self):
        return True

    def get_user_ids(self, data):
        ids = set()
        ids.add(data['user_id'])

        if data.get('fwd_messages'):
            new_data = copy.deepcopy(data)
            for new_object in new_data.get('fwd_messages'):
                new_data = new_object
                ids.update(self.get_user_ids(new_data))

        return ids

    def get_name_by_id(self, ids, session):
        vk_api = self.get_account().vk_api

        users = vk_api.make_request('users.get', {'user_ids': ','.join(str(id) for id in ids if id > 0)}, session)
        groups = vk_api.make_request('groups.getById', {'group_ids': ','.join((str(abs(id))) for id in ids if id < 0)}, session)

        name_by_id = {user.get('id'): '%s %s' % (user.get('first_name'), user.get('last_name')) for user in users.get('response')}

        if groups:
            for group in groups.get('response'):
                name_by_id[-group['id']] = group['name']

        return name_by_id

    def make_message_with_forwarded_messages(self, data, name_by_id, session, is_recursion_first_step=True):
        text = ''

        if is_recursion_first_step:
            name_by_id = self.get_name_by_id(self.get_user_ids(data), session)

        if data.get('fwd_messages'):
            for fwd_msg in data.get('fwd_messages'):
                if fwd_msg.get('body'):
                    text += '\n%s: %s' % (name_by_id.get(fwd_msg.get('user_id')), fwd_msg.get('body'))
                text += self.make_message_with_forwarded_messages(fwd_msg, name_by_id, session, False)
        text = re.sub(r'\\u\w\w\w\w\w', self.emodji_replace, text)
        return text


class VkontakteAPI(wm_channels.BaseChannelAPI):

    def __init__(self, account):
        super(VkontakteAPI, self).__init__(account)

    def make_request(self, method, params, session=None, add_access_token=True, channel=None):
        if add_access_token:
            channel = channel or (self.account.get_setting('channels').get(session.visitor.channel_id) if session else None)
            if channel:
                params['access_token'] = channel.get('token')

        params['v'] = '5.52'

        r = requests.post('https://api.vk.com/method/%s' % method, params)
        response = r.json()

        if r.status_code == 200 and not response.get('error'):
            logging.warn('VkontakteAPI: success request {} {}. Response: {}'.format(method, str(params), str(response)))
            return response
        else:
            error_msg = 'VkontakteAPI error: account={}, method={}, params={}, error_code={}, error_msg={}'\
                .format(self.account.name, method, str(params), str(response['error'].get('error_code', '')), response['error'].get('error_msg', ''))
            logging.warn(error_msg)
            raise wm_channels.ChannelAPIError(error_msg)

    def get_user_data(self, vk_id, channel):
        user_data = {}
        response = self.make_request('users.get', {'user_ids': str(vk_id), 'fields': 'photo_100, screen_name'}, session=None, add_access_token=True,
                                     channel=channel)

        if response.get('response') and response.get('response')[0]:
            user_data = response.get('response')[0]

        return user_data

    def process_delta(self, d, visit_session):
        if type(d) == list:
            for dd in d:
                self.process_delta(dd, visit_session)
            return

        try:
            if d.object_type == 'CHAT_MESSAGE':
                if d.event == delta.Delta.Event.ADD:
                    message = self.message_preprocessor(copy.copy(d.data))

                    if message.kind == chat.Message.Kind.OPERATOR:
                        self.send_message(message.text, visit_session.visitor.channel_user_id, visit_session)

                    if message.kind == chat.Message.Kind.FILE_OPERATOR:
                        file_desc = json.loads(message.text)
                        self.send_file(file_desc, visit_session.visitor.channel_user_id, visit_session)

            if d.object_type == 'CHAT_STATE':
                if d.data == chat.Chat.State.CLOSED_BY_OPERATOR:
                    self.mark_chat_as_answered(visit_session.visitor.channel_user_id, visit_session)
                    self.mark_chat_as_read(visit_session.visitor.channel_user_id, visit_session)

            if d.object_type == 'CHAT_OPERATOR_TYPING':
                if d.event == delta.Delta.Event.UPDATE and d.data:
                    self.send_operator_typing(visit_session.visitor.channel_user_id, visit_session)
        except Exception:
            logging.error('VkontakteAPI: process delta error, delta - %s' % str(d.to_json()), exc_info=True)
            wm_channels.channel_errors.update(visit_session.visitor.channel_type)

    def send_message(self, text, vk_id, session):
        try:
            self.make_request('messages.send', {'user_id': vk_id, 'message': text}, session)
        except Exception:
            self.on_message_not_sended(session)
            raise

    def send_file(self, file_desc, vk_id, session):
        self.send_message(wm_utils.get_download_file_url(self.account, file_desc, public=True), vk_id, session)

    def send_operator_typing(self, vk_id, session):
        # no access for pages and groups auth
        pass

    def mark_chat_as_answered(self, vk_id, session):
        params = {
            'peer_id': vk_id
        }
        self.make_request('messages.markAsAnsweredDialog', params, session)

    def mark_chat_as_read(self, vk_id, session):
        params = {
            'peer_id': vk_id
        }

        self.make_request('messages.markAsRead', params, session)

    def update_visitor_avatar(self, session, vk_photo_url=None):
        dir_path = os.path.join(wm_settings.settings['client-data-dir'], self.account.name, 'images', 'visitor_avatars')

        if not os.path.isdir(dir_path):
            os.mkdir(dir_path)

        file_name = '%s_%s.jpg' % (self.account.name, session.visitor.id)

        if os.path.exists(os.path.join(dir_path, file_name)):
            session.visitor.set_avatar_url('/images/visitor_avatars/' + '%s_%s-40x40.jpg' % (self.account.name, session.visitor.id))
            return

        if not vk_photo_url:
            return

        req = requests.get(vk_photo_url)

        file_info = {
            'filename': file_name,
            'content_type': req.headers.get('content-type'),
            'body': req.content
        }

        wm_utils.store_visitor_avatar(file_info, self.account.name)
        session.visitor.set_avatar_url('/images/visitor_avatars/' + '%s_%s-40x40.jpg' % (self.account.name, session.visitor.id))


wm_channels.channel_type_to_settings[VkontakteCallbackAPIRequestHandler.SETTINGS.channel_type] = VkontakteCallbackAPIRequestHandler.SETTINGS
