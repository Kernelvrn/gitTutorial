# -*- coding: utf-8 -*-
import json
import logging
import copy

import tornado.web
import requests

from . import wm_channels
from .. import wm_timer
from .. import chat
from .. import wm_utils
from .. import delta


class CustomChannelRequestHandler(wm_channels.BaseChannelRequestHandler):

    SETTINGS = wm_channels.BaseChannelRequestHandler.Settings(
        channel_type='custom',
        for_hash=None,
        start_page_url='',
        start_page_title='Custom',
        location='',
        ua='',
    )

    def __init__(self, request, application, **kwargs):
        super(CustomChannelRequestHandler, self).__init__(self.SETTINGS, request, application, **kwargs)

    @tornado.web.asynchronous
    def post(self):
        if self.get_header('Content-Type') != 'application/json':
            self.__send_error('wrong-content-type')
            return

        data = json.loads(self.request.body)
        logging.info('CustomChannelRequestHandler: got request. data: ' + str(data))

        channel_id = data.get('channel_id')
        channel = self.get_channel(channel_id)
        if not channel:
            self.__send_error('channel-not-found')
            return

        if not self.check_secret(channel, channel_id, data.get('secret')):
            raise tornado.web.HTTPError(403)

        wm_timer.invoke_async(lambda: self.__on_message(data, channel_id, channel), timer_name='custom on_message')

    def get_visitor_info(self, data, channel):
        user_id = data['from']['id']
        fields = data['from'].get('fields', {})
        user_name = None

        return user_id, fields, user_name

    def __on_message(self, data, channel_id, channel):
        session = self.get_visit_session(data, channel_id, channel)
        logging.warn('CustomChannelRequestHandler: request session %s, data %s' % (session.id, str(data)))

        if not session.chat:
            self.create_and_set_chat(channel, session)

        if data.get('text'):
            self.__on_text_message(data.get('text'), session)
        elif data.get('file'):
            self.__on_file_message(data.get('file'), session)
        elif data.get('photo'):
            self.__on_photo_message(data.get('photo'), session)
        elif data.get('action'):
            self.__on_action_message(data.get('action'), session)

    def __on_text_message(self, text, session):
        session.chat.set_visitor_typing(False)
        chat.Message.create(
            session.chat,
            chat.Message.Kind.VISITOR,
            session.visitor.get_name(),
            text
        )
        self.__send_result()

    def __on_file_message(self, url, session):
        try:
            file_desc = wm_utils.download_and_store_file(session.account, url, session.visitor.id)
            if file_desc:
                chat.Message.create(session.chat, chat.Message.Kind.FILE_VISITOR,
                                    session.visitor.get_name(), file_desc)
                self.__send_result()
        except wm_utils.InsecureFileTypeException:
            self.__send_error('wrong-file-type')

    # For now just call __on_file_message. But in future preview will be added.
    def __on_photo_message(self, url, session):
        self.__on_file_message(url, session)

    def __on_action_message(self, action, session):
        if action == 'user-typing':
            session.chat.set_visitor_typing(True)

        self.__send_result()

    def check_secret(self, channel, channel_id, secret):
        if not channel.get('secret_key') == secret:
            logging.error('CustomChannelRequestHandler type: {}, id: {}, account name: {} has wrong secret key: {}'
                          .format(channel.get('type'), channel_id, self.get_account().name, secret))
            return False

        return True

    def __send_error(self, error):
        response = {'error': error}
        self.finish(json.dumps(response))

    def __send_result(self, result='ok'):
        response = {'result': result}
        self.finish(json.dumps(response))

    @staticmethod
    def _get_user_id_from_request_body(request_body):
        data = json.loads(request_body)
        return data['from']['id']

    def _get_channel_id(self):
        data = json.loads(self.request.body)
        return data.get('channel_id')

    def requires_ban_status_checking(self):
        return True

    def on_request_from_banned_user(self):
        self.__send_error('user-banned')

    def get_channel_page_title(self, channel):
        return channel.get('name') or self.channel_settings.start_page_title


class CustomChannelAPI(wm_channels.BaseChannelAPI):

    def __init__(self, account):
        super(CustomChannelAPI, self).__init__(account)

    def process_delta(self, d, visit_session):
        channel = self.account.get_setting('channels').get(visit_session.visitor.channel_id)
        if not channel:
            return

        if type(d) == list:
            for dd in d:
                self.process_delta(dd, visit_session)
            return

        if d.object_type == 'CHAT_MESSAGE':
            if d.event == delta.Delta.Event.ADD:
                message = self.message_preprocessor(copy.copy(d.data))

                if message.kind == chat.Message.Kind.OPERATOR:
                    self.send_message(visit_session, message.text)

                if message.kind == chat.Message.Kind.FILE_OPERATOR:
                    file_desc = json.loads(message.text)
                    self.send_file(visit_session, file_desc)

        if d.object_type == 'CHAT_OPERATOR_TYPING':
            if d.event == delta.Delta.Event.UPDATE and d.data:
                self.send_operator_typing(visit_session)

    def get_base_request_body(self, session):
        operator = session.chat.get_operator()
        channel = self.account.get_setting('channels').get(session.visitor.channel_id)

        base_request_body = {
            'to': {
                'id': session.visitor.channel_user_id
            },
            'secret': channel['creators_secret_key'],
            'from': {
                'name': operator.fullname,
                'id': operator.id,
                'email': operator.email
            },
            'channel_id': session.visitor.channel_id
        }

        return base_request_body

    def send_message(self, session, text):
        data = {'text': text}
        self.make_request(session, data)

    def send_file(self, session, file_desc):
        file_type = str(file_desc.get('content_type').split('/')[0])

        message_type = 'photo' if file_type == 'image' else 'file'

        data = {message_type: wm_utils.get_download_file_url(self.account, file_desc, public=True)}
        self.make_request(session, data)

    def send_operator_typing(self, session):
        data = {'action': 'operator-typing'}
        self.make_request(session, data)

    def make_request(self, session, data):
        request_data = wm_utils.merge_dict(data, self.get_base_request_body(session))
        channel = self.account.get_setting('channels').get(session.visitor.channel_id)

        url = channel['callback_url']

        try:
            req = requests.post(
                url,
                json=request_data,
                timeout=5
            )

            if req.status_code != 200:
                logging.warn('CustomChannelRequestHandler: failed request, request body: {}. Response code: {}'.format(request_data, req.status_code))
            else:
                logging.warn('CustomChannelRequestHandler: success request, request body: {}'.format(request_data))
        except requests.ConnectionError:
            logging.warn('CustomChannelRequestHandler: failed request, request body: {}. Couldn\'t connect to url.'.format(request_data))
        except requests.Timeout:
            logging.warn('CustomChannelRequestHandler: failed request, request body: {}. Timeout.'.format(request_data))
#
# class CustomTest(tornado.web.RequestHandler):
#
#     def post(self, *args, **kwargs):
#         print json.loads(self.request.body)