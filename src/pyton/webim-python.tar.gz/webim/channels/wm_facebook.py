# -*- coding: utf-8 -*-

__author__ = 'artur'
import json
import os
import logging
import copy

import requests

import wm_channels

from .. import chat
from .. import wm_timer
from .. import delta
from .. import wm_utils
from .. import wm_settings


class FacebookWebhookRequestHandler(wm_channels.BaseChannelRequestHandler):

    SETTINGS = wm_channels.BaseChannelRequestHandler.Settings(
        channel_type='fb',
        for_hash='facebook',
        start_page_url='https://facebook.com/',
        start_page_title='facebook.com',
        location='fb',
        ua='Facebook',
    )

    def __init__(self, request, application, **kwargs):
        super(FacebookWebhookRequestHandler, self).__init__(self.SETTINGS, request, application, **kwargs)

    def get(self, channel_id):
        channels = self.get_account().get_setting('channels')
        channel = channels.get(channel_id)
        if self.get_argument('hub.mode') == 'subscribe' and self.get_argument('hub.verify_token') == channel.get('confirmation_code'):
            self.finish(self.get_argument('hub.challenge'))

    def post(self, channel_id):
        channel = self.get_channel(channel_id)
        if not channel:
            return

        logging.warn('FacebookWebhookRequestHandler: POST request %s' % self.request.body)
        data = json.loads(self.request.body)

        for entry in data.get('entry'):
            for message in entry.get('messaging'):
                user_id = message['sender']['id']
                if user_id and channel_id:
                    if self.get_account().is_banned_visitor(user_and_channel_id=(user_id, channel_id)):
                        logging.error('{}: request from banned user. Channel: {}, user id: {}'.format(
                            self.__class__.__name__, channel_id, user_id))
                    else:
                        wm_timer.invoke_async(lambda: self.__process_message(message, channel_id, channel),
                                              order_importance_key='channel_req_%s_%s' % (str(channel_id), str(self.request_user_id)),
                                              timer_name='facebook process_message')
        self.finish()

    def __process_message(self, msg, channel_id, channel):
        session = self.get_visit_session(msg, channel_id, channel)

        if not session.chat:
            self.create_and_set_chat(channel, session)

        if msg['message'].get('text'):
            text = msg['message']['text']
            chat.Message.create(session.chat, chat.Message.Kind.VISITOR, session.visitor.get_name(), text)

        if msg['message'].get('attachments'):
            attachments = msg['message']['attachments']
            for att in attachments:
                att_type = att.get('type')
                if att_type in ['file', 'image', 'audio']:
                    self.__on_file(att['payload']['url'], session)

    def __on_file(self, file_url, session):
        self._download_file_and_send_message_for_operator(file_url, session)

    def get_visitor_info(self, msg, channel):
        logging.warn('FacebookWebhookRequestHandler: msg %s' % str(msg))
        user_id = msg['sender']['id']
        account = self.get_account()
        user_data = account.fb_api.get_user_data(user_id, channel)
        fields = {'name': u'{} {}'.format(user_data.get('first_name', ''), user_data.get('last_name', ''))}
        return user_id, fields, None

    def update_visitor_avatar(self, session):
        channel = self.get_account().get_setting('channels').get(session.visitor.channel_id)
        if not channel or not channel.get('token'):
            return

        user_data = self.get_account().fb_api.get_user_data(session.visitor.channel_user_id, channel)
        session.account.fb_api.update_visitor_avatar(session, fb_photo_url=user_data.get('profile_pic'))

    def _get_user_id_from_request_body(self, request_body):
        try:
            data = json.loads(request_body)
            if data.get('sender') and data.get('sender').get('id'):
                return data.get('sender').get('id')
        except Exception:
            pass

        return None


class FacebookAPI(wm_channels.BaseChannelAPI):

    def __init__(self, account):
        super(FacebookAPI, self).__init__(account)

    def get_user_data(self, user_id, channel):
        response = requests.get(
            'https://graph.facebook.com/v2.6/%s' % user_id,
            params={'fields': 'first_name,last_name,profile_pic,locale', 'access_token': channel.get('token')}
        )
        return response.json()

    def process_delta(self, d, visit_session):
        if type(d) == list:
            for dd in d:
                self.process_delta(dd, visit_session)
            return
        try:
            if d.object_type == 'CHAT_MESSAGE':
                if d.event == delta.Delta.Event.ADD:
                    message = self.message_preprocessor(copy.copy(d.data))

                    if message.kind in [chat.Message.Kind.OPERATOR, chat.Message.Kind.CONT_REQ]:
                        self.send_message(message.text, visit_session.visitor.channel_user_id, visit_session)

                    if message.kind == chat.Message.Kind.FILE_OPERATOR:
                        file_desc = json.loads(message.text)
                        self.send_file(file_desc, visit_session.visitor.channel_user_id, visit_session)

            if d.object_type == 'CHAT_OPERATOR_TYPING':
                if d.event == delta.Delta.Event.UPDATE and d.data:
                    self.send_operator_typing(True, visit_session)
                else:
                    self.send_operator_typing(False, visit_session)
        except Exception:
            logging.error('FacebookAPI: process delta error, delta - %s' % str(d.to_json()), exc_info=True)
            wm_channels.channel_errors.update(visit_session.visitor.channel_type)

    def send_operator_typing(self, typing, session):
        params = {"recipient": {"id": str(session.visitor.channel_user_id)},
                  "sender_action": "typing_on" if typing else "typing_off"}

        self.make_request(params, session)

    def make_request(self, params, session):
        response_data = self.__do_request(params, session)

        error = response_data.get('error')
        if error:
            error_msg = 'FacebookAPI Error {}: error_code={}, error_msg={}'.format(self.account.name, error.get('code'), error.get('message'))
            logging.error(error_msg)
            if error.get('code') == 190:  # Token has expired
                self.update_access_token(session.visitor.channel_id)
                response_data = self.__do_request(params, session)
            else:
                raise wm_channels.ChannelAPIError(error_msg)
        return response_data

    def __do_request(self, params, session):
        channels = self.account.get_setting('channels')
        channel = channels.get(session.visitor.channel_id)
        response = requests.post('https://graph.facebook.com/v2.6/me/messages?access_token=' + channel.get('token'), json=params)
        return response.json()

    def send_message(self, text, fb_id, session):
        json_data = {"recipient": {"id": fb_id}, "message": {"text": text}}

        channel = self.account.get_setting('channels').get(session.visitor.channel_id)
        if not channel or not channel.get('token'):
            return

        r = self.make_request(json_data, session)
        if not r:
            self.on_message_not_sended(session)

    def send_file(self, file_desc, fb_id, session):

        channel = self.account.get_setting('channels').get(session.visitor.channel_id)
        if not channel or not channel.get('token'):
            return

        file_type = str(file_desc.get('content_type').split('/')[0])

        if file_type not in ('audio', 'image'):
            file_type = 'file'

        json_data = {
            "recipient": {"id": fb_id},
            "message": {
                "attachment": {
                    "type": file_type,
                    "payload": {"url": wm_utils.get_download_file_url(self.account, file_desc, public=True)}
                }
            }
        }

        r = self.make_request(json_data, session)
        if not r:
            self.on_file_not_sended(session)

    def update_visitor_avatar(self, session, fb_photo_url=None):
        dir_path = os.path.join(wm_settings.settings['client-data-dir'], self.account.name, 'images', 'visitor_avatars')

        if not os.path.isdir(dir_path):
            os.mkdir(dir_path)

        file_name = '%s_%s.jpg' % (self.account.name, session.visitor.id)

        if os.path.exists(os.path.join(dir_path, file_name)):
            session.visitor.set_avatar_url('/images/visitor_avatars/' + '%s_%s.jpg' % (self.account.name, session.visitor.id))
            return

        if not fb_photo_url:
            return

        req = requests.get(fb_photo_url)

        file_info = {
            'filename': file_name,
            'content_type': req.headers.get('content-type'),
            'body': req.content
        }

        wm_utils.store_visitor_avatar(file_info, self.account.name)
        session.visitor.set_avatar_url('/images/visitor_avatars/' + '%s_%s.jpg' % (self.account.name, session.visitor.id))

    def update_access_token(self, channel_id):
        logging.warn('FacebookAPI. Update token')
        channels = self.account.get_setting('channels')
        channel = channels.get(channel_id)

        user_id = self.get_user_id(channel)
        if not user_id:
            logging.warn('FacebookAPI. Failed to obtain user_id'.format(channel.get('token')))
            return

        response = requests.get('https://graph.facebook.com/{}/accounts?access_token={}'.format(user_id, channel.get('token')))
        response_data = response.json()
        if response_data.get('data'):
            for item in response_data['data']:
                access_token = item.get('access_token')
                if access_token:
                    channel['token'] = access_token
                    self.account.settings.set('channels', json.dumps(channels), async=False)
                    logging.warn('FacebookAPI. New token={}'.format(access_token))

    def get_user_id(self, channel):
        response = requests.get('https://graph.facebook.com/debug_token?input_token={}&access_token={}'.format(channel.get('token'), channel.get('token')))
        response_data = response.json()
        return response_data['data'].get('user_id') if response_data.get('data') else None


wm_channels.channel_type_to_settings[FacebookWebhookRequestHandler.SETTINGS.channel_type] = FacebookWebhookRequestHandler.SETTINGS
