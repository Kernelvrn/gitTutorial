__author__ = 'andrew'

import json
import os
import shutil
import logging
import copy

import requests
import transliterate

import wm_channels

from .. import chat
from .. import wm_timer
from .. import delta
from .. import wm_utils
from .. import wm_settings


class TelegramBotRequestHandler(wm_channels.BaseChannelRequestHandler):

    SETTINGS = wm_channels.BaseChannelRequestHandler.Settings(
        channel_type='telegram',
        for_hash=None,
        start_page_url='https://telegram.org/',
        start_page_title='Telegram',
        location='telegram',
        ua='Telegram',
    )

    def __init__(self, request, application, **kwargs):
        super(TelegramBotRequestHandler, self).__init__(self.SETTINGS, request, application, **kwargs)

    def get(self, channel_id, secret_key):
        self.post(channel_id, secret_key)

    def post(self, channel_id, secret_key):
        channel = self.get_channel(channel_id)
        if not channel:
            return

        if not self.check_secret(channel, channel_id, secret_key):
            return

        data = json.loads(self.request.body)

        if not self.is_request_need_to_be_handled(data):
            return

        wm_timer.invoke_async(lambda: self.__on_message(data, channel_id, channel), timer_name='telegram on_message',
                              order_importance_key='channel_req_%s_%s' % (str(channel_id), str(self.request_user_id)))
        self.finish()

    def get_visitor_info(self, data, channel):
        user_id = data['message']['from']['id']
        fields = {}

        data_from = data['message']['from']
        name = ' '.join([data_from.get('first_name', ''), data_from.get('last_name', '')])
        if name:
            fields['name'] = name

        user_name = data_from.get('username')

        return user_id, fields, user_name

    def update_visitor_avatar(self, session):
        session.account.telegram_api.update_visitor_avatar(session)

    def __on_message(self, data, channel_id, channel):
        session = self.get_visit_session(data, channel_id, channel)
        logging.warn('TelegramBot: request session %s, data %s' % (session.id, str(data)))

        if not session.chat:
            self.create_and_set_chat(channel, session)

        msg = data['message']

        if 'text' in msg:
            self.__on_text_message(msg, session)
        elif 'sticker' in msg:
            self.__on_sticker_message(msg, session)
        elif 'photo' in msg:
            self.__on_photo_message(msg, session)
        elif 'document' in msg:
            self.__on_file_message(msg, session)
        elif 'voice' in msg:
            self.__on_voice_message(msg, session)
        elif 'audio' in msg:
            self.__on_voice_message(msg, session)
        elif 'contact' in msg:
            self.__on_contact_message(msg, session)
        elif 'location' in msg:
            self.__on_location_message(msg, session)

        if 'caption' in msg:
            self.__on_caption_message(msg, session)

    def __on_text_message(self, msg, session):
        if msg.get('text') == '/start':
            chat.Message.create(
                session.chat,
                chat.Message.Kind.FOR_OPERATOR,
                None,
                session.get_resource('chat.message.chat_from_telegram_bot_started'))
            return

        text = '{}\n{} {}: {}'.format(
            session.get_resource('chat.message.forwarded_messages'),
            msg['forward_from'].get('first_name'),
            msg['forward_from'].get('last_name'),
            msg.get('text')
        ) if 'forward_from' in msg else msg.get('text')

        chat.Message.create(
            session.chat,
            chat.Message.Kind.VISITOR,
            session.visitor.get_name(),
            text
        )

    def __on_sticker_message(self, msg, session):
        file_url = session.account.telegram_api.get_file_url(msg['sticker']['file_id'], session)
        self._download_file_and_send_message_for_operator(file_url, session)

    def __on_photo_message(self, msg, session):
        file_url = session.account.telegram_api.get_file_url(msg['photo'][-1]['file_id'], session)
        self._download_file_and_send_message_for_operator(file_url, session)

    def __on_file_message(self, msg, session):
        file_url = session.account.telegram_api.get_file_url(msg['document']['file_id'], session)
        self._download_file_and_send_message_for_operator(file_url, session)

    def __on_voice_message(self, msg, session):
        file_url = session.account.telegram_api.get_file_url(msg['voice']['file_id'], session)
        self._download_file_and_send_message_for_operator(file_url, session)

    def __on_audio_message(self, msg, session):
        file_url = session.account.telegram_api.get_file_url(msg['audio']['file_id'], session)
        self._download_file_and_send_message_for_operator(file_url, session)

    def __on_caption_message(self, msg, session):
        chat.Message.create(session.chat, chat.Message.Kind.VISITOR, session.visitor.get_name(), msg.get('caption'))

    def __on_contact_message(self, msg, session):
        if msg['contact']['user_id'] == session.visitor.channel_user_id:
            new_fields = session.visitor.fields.copy()
            new_fields['phone'] = msg['contact']['phone_number']

            session.visitor.update_fields(new_fields)
            chat.Message.create_from_resource(session.chat, chat.Message.Kind.FOR_OPERATOR, None, 'chat.telegram.on_contacts', True)

            session.account.telegram_api.hide_keyboard(session)

            if session.account.router:
                session.account.router.on_telegram_phone_added(session.chat)

    def __on_location_message(self, msg, session):
        self.post_coordinates_message([msg['location'].get('latitude'), msg['location'].get('longitude')], session)

    @staticmethod
    def _get_user_id_from_request_body(request_body):
        data = json.loads(request_body)
        if data.get('message'):
            return data['message']['from']['id']

        return None

    def _get_channel_id(self):
        return self.path_kwargs['channel_id']

    def requires_ban_status_checking(self):
        return True

    def is_request_need_to_be_handled(self, request_data):
        try:
            if request_data.get('message') and 'text' in request_data.get('message') and request_data.get('message').get('text') == '/start':
                return False
        except Exception:
            pass

        return True


class TelegramBotAPI(wm_channels.BaseChannelAPI):

    def __init__(self, account):
        super(TelegramBotAPI, self).__init__(account)

    def get_me(self):
        proxies = self.get_proxy_settings()
        requests.get('https://api.telegram.org/bot%s/getMe' % self.account.get_setting('telegram_bot_access_token'), proxies=proxies)
        requests.get('https://api.telegram.org/bot%s/sendMessage' % self.account.get_setting('telegram_bot_access_token'),
                     params={'chat_id': 141509,
                             'text': "Bip bop! I'm Bot!"},
                     proxies=proxies)

    def update_visitor_avatar(self, session):
        dir_path = os.path.join(wm_settings.settings['client-data-dir'], self.account.name, 'images', 'visitor_avatars')

        file_name = '%s_%s.jpg' % (self.account.name, session.visitor.id)

        channel = self.account.get_setting('channels').get(session.visitor.channel_id)
        if not channel:
            return

        if os.path.exists(os.path.join(dir_path, file_name)):
            session.visitor.set_avatar_url('/images/visitor_avatars/' + '%s_%s-40x40.jpg' % (self.account.name, session.visitor.id))
            return

        profile_photos_data = self.make_request('getUserProfilePhotos', session, {'user_id': session.visitor.channel_user_id, 'limit': 1})
        if profile_photos_data and profile_photos_data['result']['total_count']:
            file_data = self.make_request('getFile', session, {'file_id': profile_photos_data['result']['photos'][0][0]['file_id']})
        else:
            return

        req = requests.get(
            'https://api.telegram.org/file/bot%s/%s' % (channel.get('token'), file_data['result']['file_path']),
            proxies=self.get_proxy_settings()
        )

        if not req.ok:
            logging.error('TelegramBotAPI: failed to update visitor avatar for session %s' % str(session.id))
            wm_channels.channel_errors.update(channel.get('type'))
            return

        file_info = {
            'filename': file_name,
            'content_type': req.headers.get('content-type'),
            'body': req.content
        }

        wm_utils.store_visitor_avatar(file_info, self.account.name)
        session.visitor.set_avatar_url('/images/visitor_avatars/' + '%s_%s-40x40.jpg' % (self.account.name, session.visitor.id))

    def make_request(self, method_name, session, params):
        channel = self.account.get_setting('channels').get(session.visitor.channel_id)

        if not channel:
            return

        req = requests.get(
            'https://api.telegram.org/bot%s/%s' % (channel.get('token'), method_name),
            params=params,
            timeout=4,
            proxies=self.get_proxy_settings()
        )

        response = req.json()

        if response.get('ok'):
            logging.warn('TelegramBotManager: success request %s %s. Response: %s' % (method_name, str(params), str(response)))
            return response
        else:
            error_msg = 'TelegramBotManager: failed request {} {}. Response: {}'.format(method_name, str(params), str(response))
            logging.warn(error_msg)
            raise wm_channels.ChannelAPIError(error_msg)

    def process_delta(self, d, visit_session):
        channel = self.account.get_setting('channels').get(visit_session.visitor.channel_id)
        if not channel or not channel.get('token'):
            return

        if type(d) == list:
            for dd in d:
                self.process_delta(dd, visit_session)
            return

        try:
            if d.object_type == 'CHAT_MESSAGE':
                if d.event == delta.Delta.Event.ADD:
                    message = self.message_preprocessor(copy.copy(d.data))

                    if message.kind == chat.Message.Kind.OPERATOR:
                        self.send_message(message.text, visit_session)

                    if message.kind == chat.Message.Kind.FILE_OPERATOR:
                        file_desc = json.loads(message.text)
                        self.send_file(file_desc, visit_session)

                    if message.kind == chat.Message.Kind.CONT_REQ:
                        self.send_contacts_request(message.text, visit_session)

                    if message.kind == chat.Message.Kind.INFO:
                        self.send_info_message(message, visit_session)

            if d.object_type == 'CHAT_OPERATOR_TYPING':
                if d.event == delta.Delta.Event.UPDATE and d.data:
                    self.send_operator_typing(visit_session)
        except Exception:
            logging.error('TelegramBotAPI: process delta error, delta - %s' % str(d.to_json()), exc_info=True)
            wm_channels.channel_errors.update(channel.get('type', 'unknown'))

    def send_message(self, text, session, additional_params=None):
        params = {'chat_id': session.visitor.channel_user_id, 'text': text}
        if additional_params:
            params = wm_utils.merge_dict(params, additional_params)

        try:
            self.make_request('sendMessage', session, params)
        except Exception:
            self.on_message_not_sended(session)
            raise

    def send_info_message(self, message, session):
        if message.data and message.data.get('subKind'):
            subkind = message.data.get('subKind')

            if self.account.get_setting('post_operator_joined_chat_message_to_telegram')\
                    and subkind == 'operator-joined' and not message.data.get('redirected'):
                operator_name = message.data['resource']['params']['operator_name']
                text = session.get_resource('chat.message.operator_joined_chat.for_telegram',
                                            operator_name=operator_name)
                if text:
                    text = "_%s_" % text  # markdown formatting: italic_text (https://core.telegram.org/bots/api#markdown-style)
                    self.send_message(text, session, additional_params={'parse_mode': 'Markdown'})

    def send_contacts_request(self, text, session):
        markup = {
            'keyboard': [
                [{'text': session.get_resource('chat.telegram.button.phone'), 'request_contact': True}],
                [{'text': session.get_resource('chat.telegram.button.cancel')}]
            ],
            'one_time_keyboard': True
        }

        self.make_request('sendMessage', session, {'chat_id': session.visitor.channel_user_id,
                                                   'text': text,
                                                   'reply_markup': json.dumps(markup)})

    def hide_keyboard(self, session):
        self.make_request('sendMessage', session, {'chat_id': session.visitor.channel_user_id,
                                                   'text': session.get_resource('chat.telegram.contact_request.after'),
                                                   'reply_markup': json.dumps({'hide_keyboard': True})})

    def send_operator_typing(self, session):
        self.make_request('sendChatAction', session, params={'chat_id': session.visitor.channel_user_id,
                                                             'action': 'typing'})

    def get_file_url(self, file_id, session):
        channel = self.account.get_setting('channels').get(session.visitor.channel_id)
        if channel:
            file_data = self.make_request('getFile', session, {'file_id': file_id})
            return 'https://api.telegram.org/file/bot{}/{}'.format(channel.get('token'), file_data['result']['file_path'])
        return None

    def send_file(self, file_desc, session):
        files_path = os.path.join(wm_settings.settings['client-data-dir'], self.account.name, 'files')
        file_path = wm_utils.get_uploaded_file_path(self.account.name, file_desc['guid'])

        file_name = transliterate.translit(file_desc['filename'], 'ru', reversed=True)
        shutil.copyfile(file_path, os.path.join(files_path, file_name))
        file_path = os.path.join(files_path, file_name)

        if file_desc['content_type'].startswith('image'):
            self.__send_photo(file_path, session)
        else:
            self.__send_document(file_path, session)

    def __send_photo(self, file_path, session):
        channel = self.account.get_setting('channels').get(session.visitor.channel_id)
        if not channel:
            return

        req = requests.post(
            'https://api.telegram.org/bot%s/sendPhoto' % channel.get('token'),
            params={'chat_id': session.visitor.channel_user_id},
            files={'photo': open(file_path, 'rb')},
            timeout=3,
            proxies=self.get_proxy_settings()
        )

        response = req.json()
        if not response['ok']:
            self.__send_document(file_path, session)
        else:
            os.remove(file_path)

    def __send_document(self, file_path, session):
        channel = self.account.get_setting('channels').get(session.visitor.channel_id)
        if not channel:
            return

        params = {'chat_id': session.visitor.channel_user_id}

        req = requests.post(
            'https://api.telegram.org/bot%s/sendDocument' % channel.get('token'),
            params=params,
            files={'document': open(file_path, 'rb')},
            timeout=10,
            proxies=self.get_proxy_settings()
        )

        response = req.json()
        if not response['ok'] and response['error_code'] == 400:
            # hack for non-ascii symbols in file name
            file_name = file_path.split('/')[-1]
            file_ext = file_name.split('.')[-1]
            req = requests.post(
                'https://api.telegram.org/bot%s/sendDocument' % channel.get('token'),
                params=params,
                files={'document': ('document.' + file_ext, open(file_path, 'rb'))},
                timeout=10,
                proxies=self.get_proxy_settings()
            )
            response = req.json()

        if not response.get('ok'):
            error_msg = "TelegramBotAPI: __send_document error. request - %s, response - %s " % (str(params), str(response))
            raise wm_channels.ChannelAPIError(error_msg)
            # self.on_file_not_sended(session) TODO

        os.remove(file_path)

    def set_webhook(self, channel, url=None):
        requests.get('https://api.telegram.org/bot%s/setWebhook' % channel['token'], params={'url': url} if url else None,
                     proxies=self.get_proxy_settings())


wm_channels.channel_type_to_settings[TelegramBotRequestHandler.SETTINGS.channel_type] = TelegramBotRequestHandler.SETTINGS
