# -*- coding: utf-8 -*

import json
import logging
import copy

import requests

import wm_channels

from .. import chat
from .. import wm_timer
from .. import delta
from .. import wm_utils


class OdnoklassnikiCallbackAPIRequestHandler(wm_channels.BaseChannelRequestHandler):

    SETTINGS = wm_channels.BaseChannelRequestHandler.Settings(
        channel_type='odnoklassniki',
        for_hash='odnoklassniki',
        start_page_url='https://ok.ru/',
        start_page_title='ok.ru',
        location='odnoklassniki',
        ua='Odnoklassniki'
    )

    def __init__(self, request, application, **kwargs):
        super(OdnoklassnikiCallbackAPIRequestHandler, self).__init__(self.SETTINGS, request, application, **kwargs)

    def get(self, channel_id, *args, **kwargs):
        self.post(channel_id, *args, **kwargs)

    def post(self, channel_id, *args, **kwargs):
        channel = self.get_channel(channel_id)
        if not channel:
            return

        data = json.loads(self.request.body)

        wm_timer.invoke_async(lambda: self.__process_message(data, channel_id, channel),
                              timer_name='odnoklassniki process_message',
                              order_importance_key='channel_req_%s_%s' % (str(channel_id), str(self.request_user_id)))
        self.finish()

    def __process_message(self, data, channel_id, channel):
        session = self.get_visit_session(data, channel_id, channel)

        account = self.get_account()
        logging.warn('OkBot: account={}, request session {}, data {}'.format(account.name, session.id, str(data)))

        if not session.chat:
            self.create_and_set_chat(channel, session)

        if data['message'].get('text'):
            chat.Message.create(
                session.chat,
                chat.Message.Kind.VISITOR,
                session.visitor.get_name(),
                data['message'].get('text')
            )

        if data['message'].get('attachments'):
            for att in data['message'].get('attachments'):
                att_type = att.get('type')
                if att_type == 'IMAGE':
                    self.__on_image(att['payload'], session)
                elif att_type == 'SHARE':
                    self.__on_link(att['payload'], session)
                elif att_type == 'VIDEO':
                    self.__on_video(att['payload'], session)
                elif att_type == 'AUDIO':
                    self.__on_audio(att['payload'], session)

    def __on_image(self, image, session):
        file_url = image.get('url')
        self._download_file_and_send_message_for_operator(file_url, session)

    def __on_link(self, link, session):
        if link.get('url'):
            chat.Message.create(session.chat, chat.Message.Kind.VISITOR, session.visitor.get_name(), link.get('url'))

    def __on_video(self, video, session):
        file_url = video.get('url')
        title = session.chat.get_resource('chat.message.default_video_title')
        text = '{}: {}'.format(title, file_url)
        chat.Message.create(session.chat, chat.Message.Kind.VISITOR, session.visitor.get_name(), text)

    def __on_audio(self, audio, session):
        file_url = audio.get('url')
        self._download_file_and_send_message_for_operator(file_url, session)

    def get_visitor_info(self, data, channel):
        user_id = data['recipient'].get('chat_id')

        fields = {'name': data['sender'].get('name')}
        user_name = data['sender'].get('name')

        return user_id, fields, user_name

    def requires_ban_status_checking(self):
        return True

    @staticmethod
    def _get_user_id_from_request_body(request_body):
        data = json.loads(request_body)
        if data['sender'].get('user_id'):
            return data['sender'].get('user_id')

        return None


class OdnoklassnikiAPI(wm_channels.BaseChannelAPI):

    def __init__(self, account):
        super(OdnoklassnikiAPI, self).__init__(account)

    def make_request(self, method, params, session=None):
        channel = self.account.get_setting('channels').get(session.visitor.channel_id)

        if not channel:
            return

        r = requests.post('https://api.ok.ru/graph/me/{}?access_token={}'.format(method, channel.get('token')),
                          data=json.dumps(params), headers={'Content-Type': 'application/json;charset=utf-8'})
        response = r.json()

        if response.get('error'):
            error_msg = 'OdnoklassnikiAPI Error {}: method={}, params={}, error={}, message={}'.format(self.account.name,
                                                                                                       method,
                                                                                                       str(params),
                                                                                                       response.get('error'),
                                                                                                       response.get('message'))
            logging.error(error_msg)
            raise wm_channels.ChannelAPIError(error_msg)
        else:
            logging.warn('OdnoklassnikiAPI: success request %s %s. Response: %s' % (method, str(params), str(response)))
            return response

    def process_delta(self, d, visit_session):
        if type(d) == list:
            for dd in d:
                self.process_delta(dd, visit_session)
            return

        try:
            if d.object_type == 'CHAT_MESSAGE':
                if d.event == delta.Delta.Event.ADD:
                    message = self.message_preprocessor(copy.copy(d.data))

                    if message.kind == chat.Message.Kind.OPERATOR:
                        self.send_message(message.text, visit_session.visitor.channel_user_id, visit_session)

                    if message.kind == chat.Message.Kind.FILE_OPERATOR:
                        file_desc = json.loads(message.text)
                        self.send_file(file_desc, visit_session.visitor.channel_user_id, visit_session)

            if d.object_type == 'CHAT_OPERATOR_TYPING':
                if d.event == delta.Delta.Event.UPDATE and d.data:
                    self.send_operator_typing(visit_session.visitor.channel_user_id, visit_session)
        except Exception:
            logging.error('OdnoklassnikiAPI: process delta error, delta - %s' % str(d.to_json()), exc_info=True)
            wm_channels.channel_errors.update(visit_session.visitor.channel_type)

    def send_message(self, text, chat_id, session):
        params = {
            'recipient': {'chat_id': chat_id},
            'message': {
                'text': text
            }
        }
        r = self.make_request('messages', params, session)
        if not r:
            self.on_message_not_sended(session)

    def send_file(self, file_desc, chat_id, session):
        if file_desc['content_type'].startswith('image'):
            self.send_photo(file_desc, chat_id, session)
        else:
            self.send_document(file_desc, chat_id, session)

    def send_document(self, file_desc, chat_id, session):
        self.send_message(wm_utils.get_download_file_url(self.account, file_desc, public=True), chat_id, session)

    def send_operator_typing(self, ok_id, session):
        pass
        # params = {
        #     'recipient': {'chat_id': ok_id},
        #     'sender_action': 'typing_on'
        # }
        # self.make_request('messages', params, session)

    def send_photo(self, file_desc, chat_id, session):
        url = wm_utils.get_download_file_url(self.account, file_desc, public=True)
        params = {
            'recipient': {'chat_id': chat_id},
            'message': {
                'attachment': {
                    'type': 'image',
                    'payload': {'url': url}
                }
            }
        }
        r = self.make_request('messages', params, session)

        if not r:
            self.on_file_not_sended(session)

    def set_webhook(self, channel, url, method='subscribe'):
        requests.post('https://api.ok.ru/graph/me/{}?access_token={}'.format(method, channel['token']),
                      json={'url': url})
