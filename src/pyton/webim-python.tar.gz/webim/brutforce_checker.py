# coding=UTF-8

import time
import threading

DEFAULT_COUNT = 10
DEFAULT_PERIOD = 10 * 60


class BrutforceChecker(object):
    """
        Реализация простейшей защиты от брутфорса.
        Хранит в себе словарь {key: [attempt_ts1, attempt_ts2, ...]}
        Ничего проще придумать нельзя.

        check: для проверки по ключу. (автоматически чистит старые попытки)
        add:  для добавления фейла.
        clear: для ручной очистки.

    """
    def __init__(self, count=None, period=None):
        """
        :param int count: Количество зафейленных попыток, после которых чекер будет ругаться
        :param int period: Время жизни зафейленной попытки в секундах
        """
        self.attempts = dict()
        self.count = int(count or DEFAULT_COUNT)
        self.period = int(period or DEFAULT_PERIOD)

        self._lock = threading.Lock()

    def check(self, key):
        with self._lock:
            if not self.attempts.get(key):
                return True

            now = time.time()
            self.attempts[key] = [at for at in self.attempts[key] if now - at <= self.period]
            attempts_count = len(self.attempts[key])
            if attempts_count == 0:
                del(self.attempts[key])

        return attempts_count < self.count

    def add(self, key):
        with self._lock:
            if key not in self.attempts:
                self.attempts[key] = []

            self.attempts[key].append(time.time())

    def clear(self, key):
        with self._lock:
            if key in self.attempts:
                del self.attempts[key]