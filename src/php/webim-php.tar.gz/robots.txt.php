<?php
define('AVOID_SESSION_START', 1);
define('VISITOR_SIDE', 1);
define('AVOID_SET_LOCALE', 1);

header('Content-type: text/plain');

require_once(dirname(__FILE__) . '/webim/autoload.php');
require_once(dirname(__FILE__) . '/webim/classes/functions.php');

$rootDomain = Helper::getRootDomain();

if ($rootDomain != 'webim.ru') {
  echo  <<<EOT
User-agent: *
Disallow: /

User-agent: Googlebot
Disallow: /

user-agent: Yandex
Disallow: /
EOT;
  die();
}

if (getAccountId() === null && getBrandPartner() === null) {
  echo  <<<EDT
User-agent: *
Disallow: *?

User-agent: Yandex
Disallow: *?
Host: https://login.webim.ru

User-agent: Googlebot
Disallow: *?
EDT;


} else {
  echo  <<<EOT
User-agent: *
Disallow: /
EOT;

}
?>