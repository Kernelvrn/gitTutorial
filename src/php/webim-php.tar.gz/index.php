<?php
header("Location: /operator/");
die();
?>