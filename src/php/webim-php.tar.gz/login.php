<?php
header("Location: /webim/operator/login.php");
die();
?>