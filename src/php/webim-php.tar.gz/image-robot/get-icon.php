<?php
/**
 * Create visitor icon.
 * Author: Alexander Bezroukov
 * Date: 8/24/12
 * Time: 4:32 AM
 */
define('SKIP_PROTOCOL_SWITCH', 1);
define('AVOID_SESSION_START', 1);
define('AVOID_SET_LOCALE', 1);

require_once(dirname(__FILE__) . '/../webim/classes/config.php');
require_once(dirname(__FILE__) . '/../webim/classes/class.helper.php');
require_once(dirname(__FILE__) . '/../webim/classes/class.browser.php');

$storeDir = READY_IMAGES_DIR . '/vicons';
if (!file_exists($storeDir)) {
  mkdir($storeDir, 0777, true);
}
$shapeDir = dirname(__FILE__) . '/../webim/images/vicons';

$height = Helper::getParam('height', '\d*', '30');
$width = Helper::getParam('width', '\d*', '30');
$bgcolor = Helper::getParam('bgcolor', '[#\w]*', '#000000');
$shape = Helper::getParam('shape', '\w*', 'plus');
$round = '4';

$iconFullFilename = $storeDir . '/' . $shape . '_' . $bgcolor . '_' . $width . 'x' . $height . '_round'. $round .'.png';
$shapeFullFilename = $shapeDir . '/' . $shape . '-30x30.png';

if (!file_exists($iconFullFilename)) {
    $cmdCreateCanvas = MAGICHOME . "/convert -size {$width}x{$height} xc:\"{$bgcolor}\" {$iconFullFilename}";
    `$cmdCreateCanvas`;
    $cmdCreateIcon = MAGICHOME . "/composite -gravity center  {$shapeFullFilename} {$iconFullFilename} {$iconFullFilename}";
    `$cmdCreateIcon`;
    $cmdCreateRoundIcon = MAGICHOME . "/convert {$iconFullFilename} \\( +clone -alpha extract -draw \"fill black polygon 0,0 0,{$round} {$round},0 fill white circle {$round},{$round} {$round},0 \" \\( +clone -flip \\) -compose Multiply -composite \\( +clone -flop \\) -compose Multiply -composite \\) -alpha off -compose CopyOpacity -composite {$iconFullFilename}";
    `$cmdCreateRoundIcon`;
}

if (file_exists($iconFullFilename)) {
    Browser::outputImage($iconFullFilename);
} else {
    header("HTTP/1.0 404 Not Found");
}

?>