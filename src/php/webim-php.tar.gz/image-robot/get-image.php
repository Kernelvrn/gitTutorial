<?php
/**
 * Created by JetBrains PhpStorm.
 * User: oleg
 * Date: 6/26/11
 * Time: 2:03 PM
 * To change this template use File | Settings | File Templates.
 */
define('SKIP_PROTOCOL_SWITCH', 1);
define('AVOID_SESSION_START', 1);
define('AVOID_SET_LOCALE', 1);

require_once(dirname(__FILE__) . '/../webim/classes/config.php');
require_once(dirname(__FILE__) . '/../webim/classes/class.fileslocation.php');
require_once(dirname(__FILE__) . '/../webim/classes/class.browser.php');

$imageExtensions = array('png', 'jpg', 'gif', 'jpeg', 'svg');

$verbose = isset($_REQUEST['verbose']);
$r = $_REQUEST['r'];
$type = null;
$extension = null;

if (preg_match('/\/(avatar|department_logo)\/(.+)$/', $r, $matches)) {
    $type = $matches[1];
    $tmpName = $matches[2];
    if (preg_match('/^([^\.]+)_(\d+)-(\d+)x(\d+)\.([^\.]+)$/', $tmpName, $matches)) {
        $accountId = $matches[1];
        $id = $matches[2];
        $resolutionW = $matches[3];
        $resolutionH = $matches[4];
        $extension = $matches[5];
    } else {
        preg_match('/^([^\.]+)_(\d+)\.([^\.]+)$/', $tmpName, $matches);

        $accountId = $matches[1];
        $id = $matches[2];
        $extension = $matches[3];
        $resolutionW = '100';
        $resolutionH = '100';
    }
    $origFileName = $accountId . '_' . $id;
} elseif (preg_match('/\/([^\/]+)_ainvite_avatar([^\.]*)\.(.+)$/', $r, $matches)) {
    $type = 'ainvite_avatar';
    $accountId = $matches[1];
    $suffix = $matches[2];
    $extension = $matches[3];
    $resolutionW = '100';
    $resolutionH = '100';
    if ($accountId == 'bankliferu') {
        $resolutionH = '150';
    }

    $origFileName = $accountId . '_ainvite_avatar' . $suffix;

} elseif (preg_match('/\/([^\/]+)_site_logo([-x\d\.]+)(.+)$/', $r, $matches)) {
    $type = 'site_logo';

    $nameParts = explode('-', $matches[1], 2);
    $accountId = $nameParts[0];
    $namePart = $matches[1];
    $extension = $matches[3];

    if (preg_match('/(\d+)x(\d+)/', $matches[2], $matches)) {
        $resolutionW = $matches[1];
        $resolutionH = $matches[2];
    } else {
        $resolutionW = 100;
        $resolutionH = 100;
    }

    $origFileName = $namePart . '_site_logo';
} elseif (preg_match('/\/site_preview([-x\d\.]+)(.+)$/', $r, $matches)) {
    $type = 'site_preview';

    $nameParts = explode('-', $matches[1], 2);
    $accountId = $nameParts[0];
    $namePart = $matches[1];


    $accountId = getAccountId();
    $namePart = $accountId;
    $extension = $matches[2];
    if (preg_match('/(\d+)x(\d+)/', $matches[1], $matches)) {
        $resolutionW = $matches[1];
        $resolutionH = $matches[2];
    } else {
        $resolutionW = 600;
        $resolutionH = 600;
    }

    $origFileName = $namePart . '_site_preview';
} elseif (preg_match('/\/visitor_avatars\/(.+)$/', $r, $matches)) {
    $type = 'visitor_avatar';

    $tmpName = $matches[1];
    if (preg_match('/^([^\.]+)_([^\.]+)-(\d+)x(\d+)\.([^\.]+)$/', $tmpName, $matches)) {
        $accountId = $matches[1];
        $id = $matches[2];
        $resolutionW = $matches[3];
        $resolutionH = $matches[4];
        $extension = $matches[5];
    } else {
        preg_match('/^([^\.]+)_([^\.]+)\.([^\.]+)$/', $tmpName, $matches);
        $accountId = $matches[1];
        $id = $matches[2];
        $extension = $matches[3];
        $resolutionW = '100';
        $resolutionH = '100';
    }
    $origFileName = $accountId . '_' . $id;
}

if ($type === null) {
    throw new Exception('could not find type');
}


$resolutionH = isset($_REQUEST['height']) ? $_REQUEST['height'] : $resolutionH;
$resolutionW = isset($_REQUEST['width']) ? $_REQUEST['width'] : $resolutionW;

$resolution = $resolutionW . 'x' . $resolutionH;

$dir = READY_IMAGES_DIR;
if (!file_exists(READY_IMAGES_DIR)) {
    mkdir(READY_IMAGES_DIR, 0777, true);
}


$readyFullFileName = $dir . '/' . (isset($namePart) ? $namePart : $accountId) . (isset($id) ? '_' . $id : '') . '_' . $type . (isset($suffix) ? $suffix : '') . '-' . $resolution . ($extension == 'svg' ? '.svg' : '.png');

$origDir = getDirectoryOfImage($type, $accountId, $origFileName, $imageExtensions);

$origFullFileName = $origDir . '/' . $origFileName;
$fileFound = false;
foreach ($imageExtensions as $ext) {
    $fileName = $origFullFileName . '.' . $ext;
    doMyLog("Checking #$fileName#");
    if (file_exists($fileName)) {
        $origFullFileName .= '.' . $ext;
        $fileFound = true;
        doMyLog("Found #$fileName#");
        break;
    } else {
        doMyLog("Not found #$fileName#");
    }
}

if (!$fileFound) {
    header('HTTP/1.0 404 Not Found');
    doMyLog("Could not find image " . $origFullFileName);
    immediatelyNotifyAboutProblem(array('orig name' => $origFullFileName, 'server' => $_SERVER), "Could not find image");
    die();
}


if (file_exists($readyFullFileName) && time() - filemtime($readyFullFileName) < 60 * 60 * 24 * 7 && !isDevMode()) { // cache for 7 days only
    doMyLog("Outputing 1: " . $readyFullFileName);
    if (!$verbose) {
        Browser::outputImage($readyFullFileName, $origFullFileName);
    }
    die();
}

if ($extension == 'svg' && substr($origFullFileName, -3) == 'svg') {
    if (makeSvgPicture($origFullFileName, $readyFullFileName, $resolutionW, $resolutionH) && !$verbose) {
        Browser::outputImage($readyFullFileName, $origFullFileName);
    }
    die();
}

$cmdIdentify = MAGICHOME . "/identify $origFullFileName";
//echo $cmdIdentify;
$out = `$cmdIdentify`;
preg_match('/(\d+)x(\d+)/', $out, $matches);
//var_dump($matches);
//die();
$w = $matches[1];
$h = $matches[2];

if ($w == $resolutionW && $h == $resolutionH && $extension == 'png') {
    myExec("cp $origFullFileName $readyFullFileName");
    if (!$verbose) {
        Browser::outputImage($readyFullFileName, $origFullFileName);
    }
    die();
}

$tmpFullName = '/tmp/image-robot-' . time() . '-' . rand(0, 1000000) . '-' . md5($r) . '.png';
$tmpFullName2 = '/tmp/image-robot-2-' . time() . '-' . rand(0, 1000000) . '-' . md5($r) . '.png';
$tmpFullName3 = '/tmp/image-robot-3-' . time() . '-' . rand(0, 1000000) . '-' . md5($r) . '.png';

if ($w != $h) {
    $wResize = $resolutionW . "x";
    $hResize = " x" . $resolutionH;
    $doCrop = 1;
    $resize = null;
    $ratio = $w / $h;
    $targetRatio = $resolutionW / $resolutionH;

    $doPad = true;
    switch ($type) {
        case 'avatar':
        case 'department_logo':
            $resize = $w < $h ? $wResize : $hResize;
            $doCrop = 1;
            break;
        case 'site_logo':
            $resize = $ratio > $targetRatio ? $wResize : $hResize;
            $c = $ratio / $targetRatio;
            $doPad = false;
            $doCrop = 0;
            break;
        case 'site_preview':
            $resize = $ratio > $targetRatio ? $wResize : $hResize;
            $c = $ratio / $targetRatio;
            $doPad = false;
            $doCrop = 0;
            break;
        case 'ainvite_avatar';
            $resize = $w > $h ? $wResize : $hResize;
            $doCrop = 0;
            break;
    }

    $cmdResize = MAGICHOME . "/convert " . $origFullFileName . " -resize " . $resize . " -gravity Center " . $tmpFullName;
    myExec($cmdResize);
    myExec("cp $tmpFullName $tmpFullName2");


    if ($doCrop) {
        $command = MAGICHOME . "/convert " . $tmpFullName2 . " -gravity Center -crop " . $resolution . "+0+0 " . $tmpFullName3;
    } elseif ($doPad) {
        $command = MAGICHOME . "/convert -size " . $resolution . " xc:transparent -gravity center -draw \"image over 0,0 0,0 '" . $tmpFullName2 . "'\" " . $tmpFullName3;
    } else {
        $command = "cp " . $tmpFullName2 . " " . $tmpFullName3;
    }
} else {
    $command = MAGICHOME . "/convert " . $origFullFileName . " -resize " . $resolutionH . " -gravity Center " . $tmpFullName3;
}
$out = myExec($command);

$cmdRepage = MAGICHOME . "/convert " . $tmpFullName3 . " -repage " . $resolutionW . "x" . $resolutionH . '+0+0   -gravity Center  ' . $readyFullFileName;
myExec($cmdRepage);

if (file_exists($tmpFullName)) {
    unlink($tmpFullName);
}

if (file_exists($tmpFullName2)) {
    unlink($tmpFullName2);
}

if (file_exists($tmpFullName3)) {
    unlink($tmpFullName3);
}

if (isMyIP() && $verbose) {
    die();
}

if (!$verbose) {
    if (file_exists($readyFullFileName)) {
        Browser::outputImage($readyFullFileName, $origFullFileName);
    } else {
        $protocol = (isset($_SERVER['SERVER_PROTOCOL']) ? $_SERVER['SERVER_PROTOCOL'] : 'HTTP/1.0');
        header($protocol . ' 500 Internal Server Error');
        doMyLog('Could not make resize for ' . $origFullFileName . ' with name ' . $readyFullFileName);
    }
}
die();


function myExec($cmd) {
    global $verbose;

    if ($verbose) {
        echo $cmd;
        echo '<br/>';
    }

    return `$cmd`;
}

function getDirectoryOfImage($type, $accountId, $origFileName, $imageExtensions) {
    switch (strtoupper($type)) {
        case 'AVATAR':
            return FilesLocation::getAccountOperatorAvatarsPath($accountId, $origFileName, $imageExtensions);
        case 'SITE_LOGO':
            return FilesLocation::getAccountLogotypesPath($accountId, $origFileName, $imageExtensions);
        case 'SITE_PREVIEW':
            return FilesLocation::getAccountSitePreviewPath($accountId, $origFileName, $imageExtensions);
        case 'AINVITE_AVATAR':
            return FilesLocation::getAccountAinviteAvatarsPath($accountId, $origFileName, $imageExtensions);
        case 'VISITOR_AVATAR':
            return FilesLocation::getAccountVisitorAvatarsPath($accountId, $origFileName, $imageExtensions);
        case 'DEPARTMENT_LOGO':
            return FilesLocation::getAccountDepartmentLogosPath($accountId, $origFileName, $imageExtensions);
    }
}

function makeSvgPicture($filename, $readyFileName, $width, $height) {
    if (file_exists($filename)) {
        $svg = new SimpleXMLElement(file_get_contents($filename));
        $svg->registerXPathNamespace('svg', 'http://www.w3.org/2000/svg');
        $svg->registerXPathNamespace('xlink', 'http://www.w3.org/1999/xlink');
        $targetRatio = $width / $height;

        $attributes = $svg->attributes();
        if (isset($attributes['width']) && isset($attributes['height'])) {
            $ratio = $attributes['width'] / $attributes['height'];
        } else {
            if (isset($attributes['viewBox'])) {
                preg_match_all('/([\d\.]+)/', $attributes['viewBox'], $matches);
                $ratio = $matches[0][2] / $matches[0][3];
            } else {
                $ratio = $targetRatio;
            }
        }
        $newWidth = intval(($ratio > $targetRatio) ? $width : $height * $ratio);
        $newHeight = intval(($ratio < $targetRatio) ? $height : $width / $ratio);
        if (isset($attributes['width'])) {
            $areaWidth = floatval($attributes['width']);
            $attributes['width'] = $newWidth;
        } else {
            $areaWidth = $width;
            $svg->addAttribute('width', $newWidth);
        }

        if (isset($attributes['height'])) {
            $areaHeight = floatval($attributes['height']);
            $attributes['height'] = $newHeight;
        } else {
            $areaHeight = $height;
            $svg->addAttribute('height', $newHeight);
        }

        if (!isset($attributes['viewBox'])) {
            $svg->addAttribute('viewBox', "0 0 $areaWidth, $areaHeight");
        }
        return $svg->asXML($readyFileName);
    } else {
        return false;
    }
}
