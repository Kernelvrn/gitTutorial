<?php

class Controller_ReportDownload extends CRUDRequestHandler {
    protected $defaultAction = 'read';

    protected $readParams = array('filename');

    protected $readValidateRules = array(
        'filename' => array('not_empty')
    );

    protected function readAction($params, $errors) {
       if (empty($errors)) {
            $filePath = FilesLocation::getAccountReportsPath() . DIRECTORY_SEPARATOR . $params['filename'];
            if (file_exists($filePath)) {
                $this->setOutputType('File');
                $this->responseData['filePath'] = $filePath;
            }
        }
    }
}