<?php
require_once(dirname(__FILE__). '/../../autoload.php');

class OperatorRequestHandler extends BaseRequestHandler {
    protected $defaultAction = 'showAddForm';

    protected $securedActions = array('create', 'saveOperatorJSON', 'removeImageJSON', 'saveOperatorDepartmentsJSON');

    protected $createParams = array();
    protected $createPreParamParsers = array();
    protected $createValidateRules = array();
    protected $saveOperatorJSONParams = array();
    protected $saveOperatorJSONValidateRules = array();
    protected $saveOperatorJSONCanProcessPartParams = TRUE;

    protected $operatorUpdated = FALSE;
    protected $actionLogTarget = 'operator';

    protected $showEditFormParams = array('operatorid');
    protected $getOperatorJSONParams = array('operatorid');
    protected $removeImageJSONParams = array('operatorid');

    protected $allOperatorFieldConfigs = array(
        'name' => array(
            'setting_type' => 'input',
            'input_type' => 'text',
            'label_key' => 'form.field.agent_name',
            'description_key' => 'form.field.agent_name.description',
            'placeholder_key' => 'form.field.agent_name.placeholder',
            'mandatory' => TRUE
        ),
        'visible_name' => array(
            'setting_type' => 'input',
            'input_type' => 'text',
            'label_key' => 'form.field.visible_name',
            'description_key' => 'form.field.visible_name.description',
            'placeholder_key' => 'form.field.visible_name.placeholder',
        ),
        'email' => array(
            'setting_type' => 'input',
            'input_type' => 'email',
            'label_key' => 'form.field.agent_email',
            'description_key' => 'form.field.agent_email.description',
            'placeholder_key' => 'form.field.agent_email.placeholder',
            'mandatory' => TRUE
        ),
        'password' => array(
            'setting_type' => 'input',
            'input_type' => 'password',
            'label_key' => 'form.field.password',
            'description_key' => 'form.field.password.leaveEmpty',
            'mandatory' => TRUE
        ),
        'password_confirm' => array(
            'setting_type' => 'input',
            'input_type' => 'password',
            'label_key' => 'form.field.password_confirm',
            'description_key' => 'form.field.password_confirm.description',
            'mandatory' => TRUE
        ),
        'operator_order' => array(
            'setting_type' => 'input',
            'input_type' => 'number',
            'label_key' => 'form.field.operatororder',
            'description_key' => 'form.field.operatororder.description'
        ),
        'backend_locale' => array(
            'setting_type' => 'select',
            'data_type' => 'languages',
            'label_key' => 'form.field.backend_lang',
            'description_key' => 'form.field.backend_lang.description',
            'options' => array() //Fill in constructor
        ),
        'chat_locales' => array(
            'setting_type' => 'checkbox_list',
            'data_type' => 'languages',
            'label_key' => 'form.field.agent_locales',
            'description_key' => 'form.field.agent_locales.description',
            'options' => array() //Fill in constructor
        ),
        'is_admin' => array(
            'setting_type' => 'checkbox',
            'label_key' => 'form.field.is_admin',
            'description_key' => 'form.field.is_admin.description'
        ),
        'departments' => array(
            'setting_type' => 'select',
            'multiple' => TRUE,
            'label_key' => 'form.field.departments',
            'description_key' => 'form.field.departments.description',
            'options' => array() //Fill in constructor
        ),
        'avatar' => array(
            'setting_type' => 'image',
            'label_key' => 'form.field.avatar.upload',
            'description_key' => 'form.field.avatar.upload.description'
        ),
        'answers' => array(
	    'setting_type' => 'none',
            'label_key' => 'form.field.predefined_answers',
            'description_key' => 'form.field.predefined_answers.description',
            'type' => 'operator'
        ),
        'send_email' => array(
            'setting_type' => 'checkbox',
            'label_key' => 'form.field.sendEmail',
            'default_value' => TRUE
        ),
        'assigned_operators' => array(
            'setting_type' => 'select',
            'multiple' => TRUE,
            'label_key' => 'form.field.assigned_operators',
            'description_key' => 'form.field.assigned_operators.description',
            'options' => array() //Fill in constructor
        ),
        'supervised_depts' => array(
          'setting_type' => 'select',
          'multiple' => TRUE,
          'label_key' => 'form.field.supervised_depts',
          'description_key' => 'form.field.supervised_depts.description',
          'options' => array() //Fill in constructor
        ),
        'office' => array(
          'setting_type' => 'select',
          'label_key' => 'form.field.office',
          'description_key' => 'form.field.office.description',
          'options' => array() //Fill in constructor
        ),
        'workhours' => array(
	  'setting_type' => 'none',
          'label_key' => 'form.field.workhours',
          'description_key' => 'form.field.workhours.description',
        ),
        'new_visitor_notification' => array(
          'setting_type' => 'select',
          'label_key' => 'form.field.new_visitor_notification',
          'description_key' => 'form.field.new_visitor_notification.description',
          'options' => array() //Fill in constructor
        ),
        'max_chats_per_operator' => array(
            'setting_type' => 'input',
            'input_type' => 'number',
            'label_key' => 'form.field.max_chats_per_operator',
            'description_key' => 'form.field.max_chats_per_operator.description'
        ),
        'max_overlimit_chats_per_operator' => array(
            'setting_type' => 'input',
            'input_type' => 'number',
            'label_key' => 'form.field.max_overlimit_chats_per_operator',
            'description_key' => 'form.field.max_overlimit_chats_per_operator.description'
        ),
    );
    protected $allValidateRules = array(
        'name' => array('not_empty', 'not_longer_than' => array('length' => 64), 'not_danger_symbols'),
        'visible_name' => array('not_longer_than' => array('length' => 30), 'not_danger_symbols'),
        'email' => array('not_empty', 'email', 'not_exist_operator_email'),
        'password' => array('one_word'),
        'operator_order' => array('numeric'),
        'max_chats_per_operator' => array('numeric'),
        'max_overlimit_chats_per_operator' => array('numeric'),
        'backend_locale' => array('backend_locale'),
        'chat_locales' => array('chat_locales')
    );
    protected $allPreParamParsers = array(
        'departments' => 'to_array',
        'chat_locales' => 'to_array',
        'assigned_operators' => 'to_array',
        'supervised_depts' => 'to_array',
        'is_admin' => 'to_boolean',
        'send_email' => 'to_boolean',
        'max_chats_per_operator' => 'to_int_or_null',
        'max_overlimit_chats_per_operator' => 'to_int_or_null'
    );
    protected $addOperatorFieldConfigs = array();

    protected $editOperatorFieldConfigs = array();
    protected $tabs2Fields = array(
        'general' => array(
            'backend_locale', 'name', 'visible_name', 'email', 'avatar',
            'chat_locales', 'departments', 'assigned_operators', 'supervised_depts', 'operator_order', 'is_admin', 'office'
        ),
        'password' => array(
            'password', 'password_confirm'
        ),
        'templates' => array(
            'answers'
        ),
        'additional' => array(
            'new_visitor_notification', 'max_chats_per_operator', 'max_overlimit_chats_per_operator'
        ),
        'workhours' => array(
            'workhours'
        ),
    );
    protected $group2FieldConfigs = array();

    public function __construct() {
        parent::__construct();
        if (
          $this->currentOperator['supervisor']
          && ($this->getParam('operatorid') != '')
          && !in_array($this->getParam('operatorid'), array_merge($this->currentOperator['supervised_operators'], array($this->currentOperator['operatorid'])))
          && (
            Operator::getInstance()->isOperatorAdmin(MapperFactory::getOperatorMapper()->getById($this->getParam('operatorid')))
            || Operator::getInstance()->isOperatorSupervisor(MapperFactory::getOperatorMapper()->getById($this->getParam('operatorid')))
          )
        ) {
          header('Location: ' . WEBIM_ROOT . '/operator/operators.php');
          exit();
        }

        if ($this->getParam('operatorid') && !$this->getParam('action')) {
            $this->setCurrentAction('showEditForm');
        }

        if (Settings::Get('operator_department_prioritization')) {
            $this->tabs2Fields = Helper::removeValueFromArray('departments', $this->tabs2Fields);
            $this->tabs2Fields['departments'] = array('departments');
        }

        if (!Tariff::getInstance()->hasTariffOption('workhours')) {
            $this->tabs2Fields = Helper::removeValueFromArray('workhours', $this->tabs2Fields);
            unset($this->tabs2Fields['workhours']);
        }

        $this->allOperatorFieldConfigs['answers']['current_lang'] = Resources::getCurrentLocale();
        $this->allOperatorFieldConfigs['answers']['lang_options'] = Resources::getAvailableLocales();
        $this->allOperatorFieldConfigs['answers']['id'] = $this->getParam('operatorid');

        if (Settings::Get('offices') && !Settings::areOfficesByGeo()) {
            $offices = Settings::Get('offices');
            $this->allOperatorFieldConfigs['office']['options'][0] = Resources::Get('form.field.office.without_office');
            foreach ($offices as $office) {
                $this->allOperatorFieldConfigs['office']['options'][$office['id']] = $office['name'];
            }
        } else {
            unset($this->allOperatorFieldConfigs['office']);
            $this->tabs2Fields = Helper::removeValueFromArray('office', $this->tabs2Fields);
        }

        $this->allOperatorFieldConfigs['new_visitor_notification']['options'] = array_combine(array(0, 1, 2),
            array(Resources::Get('form.field.new_visitor_notification.account'), Resources::Get('form.field.new_visitor_notification.on'), Resources::Get('form.field.new_visitor_notification.off')));


        if (Settings::Get('multilang')) {
            $this->allOperatorFieldConfigs['chat_locales']['options'] = array_combine(Resources::GetAvailableLocales(), Resources::GetAvailableLocales());
        } else {
            unset($this->allOperatorFieldConfigs['chat_locales']);
            $this->tabs2Fields = Helper::removeValueFromArray('chat_locales', $this->tabs2Fields);
        }
        if (Settings::Get('admin_multilang')) {
            $this->allOperatorFieldConfigs['backend_locale']['options'] = array_combine(Resources::getBackendAvailableLocales(), Resources::getBackendAvailableLocales());
        } else {
            unset($this->allOperatorFieldConfigs['backend_locale']);
            $this->tabs2Fields = Helper::removeValueFromArray('backend_locale', $this->tabs2Fields);
        }

        $tmpDepts = MapperFactory::getDepartmentMapper()->enumDepartments(Resources::getCurrentLocale());
        $departments = array();
        if ($this->currentOperator['supervisor']) {
            foreach ($tmpDepts as $dept) {
                if (in_array($dept['departmentid'], $this->currentOperator['supervised_depts'])) {
                    $departments[] = $dept;
                }
            }
            unset($this->allOperatorFieldConfigs['assigned_operators']);
            unset($this->allOperatorFieldConfigs['supervised_depts']);
            unset($this->allOperatorFieldConfigs['is_admin']);
            $this->tabs2Fields = Helper::removeValueFromArray('assigned_operators', $this->tabs2Fields);
            $this->tabs2Fields = Helper::removeValueFromArray('supervised_depts', $this->tabs2Fields);
            $this->tabs2Fields = Helper::removeValueFromArray('is_admin', $this->tabs2Fields);
        } else {
            $departments = $tmpDepts;
        }

        if (!empty($departments)) {
            $this->allOperatorFieldConfigs['departments']['options'] = array_combine(Helper::getColumnFromArray($departments, 'departmentid'), Helper::getColumnFromArray($departments, 'departmentname'));
        }

        $this->addOperatorFieldConfigs = $this->allOperatorFieldConfigs;
        unset(
            $this->addOperatorFieldConfigs['backend_locale'],
            $this->addOperatorFieldConfigs['answers'],
            $this->addOperatorFieldConfigs['password_confirm'],
            $this->addOperatorFieldConfigs['assigned_operators'],
            $this->addOperatorFieldConfigs['new_visitor_notification']
        );
        $this->createParams = array_keys($this->addOperatorFieldConfigs);
        foreach ($this->allValidateRules as $paramKey => $rules) {
            if (in_array($paramKey, $this->createParams)) {
                $this->createValidateRules[$paramKey] = $rules;
            }
        }
        $this->createPreParamParsers = $this->allPreParamParsers;

        $this->editOperatorFieldConfigs = $this->allOperatorFieldConfigs;
        $this->editOperatorFieldConfigs['password']['label_key'] = 'form.field.new_password';
        $this->editOperatorFieldConfigs['password']['description_key'] = 'form.field.new_password_or_leave.description';
        unset(
            $this->editOperatorFieldConfigs['send_email']
        );
        if (!Tariff::getInstance()->hasTariffOption('has_supervisors')) {
            unset($this->editOperatorFieldConfigs['assigned_operators']);
            $this->tabs2Fields = Helper::removeValueFromArray('assigned_operators', $this->tabs2Fields);
            unset($this->editOperatorFieldConfigs['supervised_depts']);
            $this->tabs2Fields = Helper::removeValueFromArray('supervised_depts', $this->tabs2Fields);
        }

        $this->saveOperatorJSONParams = array_keys($this->editOperatorFieldConfigs);
        $this->saveOperatorJSONParams[] = 'operatorid';
        foreach ($this->allValidateRules as $paramKey => $rules) {
            if (in_array($paramKey, $this->saveOperatorJSONParams)) {
                $this->saveOperatorJSONValidateRules[$paramKey] = $rules;
            }
        }
        $this->saveOperatorJSONPreParamParsers = $this->allPreParamParsers;
        $this->group2FieldConfigs = array();
        foreach ($this->editOperatorFieldConfigs as $fieldKey => $fieldConfig) {
            if (!empty($fieldConfig['group'])) {
                $this->group2FieldConfigs[$fieldConfig['group']][$fieldKey] = &$this->editOperatorFieldConfigs[$fieldKey];
            }
        }
    }

    protected function showAddFormAction() {
        $this->viewConfig['content_template'] = 'backend/content/operator.create.tpl';
        $this->responseData['titleKey'] = 'page_agent.title';
        $this->responseData['descriptionKey'] = 'page_agent.create_new';
        if ($this->currentOperator['is_admin']) {
          $this->addOperatorFieldConfigs['supervised_depts']['description_key'] = 'form.field.supervised_depts.descr_while_create';
        }

        $this->responseData['operatorFields2Config'] = $this->addOperatorFieldConfigs;
    }

    protected function createAction($params, $errors) {
        $this->responseData['operatorFields2Value'] = $params;
        if (!empty($errors['email']) && !empty($errors['email']['not_exist_operator_email'])
            && in_array($this->currentAccount['accountname'], array('proskater', 'a1shop', 'camelotonline'))
        ) {
            unset($errors['email']['not_exist_operator_email']);
            if (empty($errors['email'])) {
                unset($errors['email']);
            }
        }
        if (!empty($params['password'])) {
            $res = Operator::getInstance()->checkPasswordStrength($this->currentAccount['accountname'], $params['password']);
            if ($res['result'] === FALSE) {
                $errors['password'] = $res['errors'];
            }
        }
        if ($this->currentOperator['supervisor']) {
          if (empty($params['departments'])) {
            $errors['departments'] = Resources::Get('errors.supervisors.operator_must_be_in_dept');
          }
        }
        $this->responseData['operatorErrors'] = $errors;
        if (!empty($this->responseData['operatorErrors'])) {
            unset($this->responseData['operatorFields2Value']['avatar']);
            $this->showAddFormAction();
            return;
        }
        $this->createOperator($params);
        ActionLog::getInstance()->createAction($this->actionLogTarget, $params);
        header('Location: ' . AdminURL::getInstance()->getURL('operators'));
        exit();
    }

    protected function removeImageJSONAction($params) {
        $this->setOutputType('JSON');
        $this->responseData['stored'] = array();
        $this->responseData['errors'] = array();
        if (!empty($params['operatorid']) && empty($this->editOperatorFieldConfigs['avatar']['disabled'])) {
            Helper::clearAvatarImages($params['operatorid']);
            Operator::getInstance()->UpdateOperator($params['operatorid'], array('avatar' => NULL));
            $this->responseData['stored']['avatar'] = '';
            KeyValueCache::clearKind('operators');
            KeyValueCache::clearKind('getOperatorById');
            Helper::clearOperatorCache($params['operatorid']);
            if ($params['operatorid'] == $this->currentOperator['operatorid']) {
                Operator::getInstance()->refreshSessionOperator();
            }
        }
    }

    protected function showEditFormAction($params) {
        $operator = Operator::getInstance()->getOperatorById($params['operatorid']);
        $this->responseData['operator'] = $operator;
//        TRACEVAR('operator', $operator);
        if (empty($operator)) {
            header('Location: ' . WEBIM_ROOT . '/operator/operators.php');
            exit();
        }
        if (Tariff::getInstance()->hasTariffOption('has_supervisors')) {
            if (!Operator::getInstance()->isOperatorAdmin($operator)) {
                $operators = MapperFactory::getOperatorAccountViewMapper()->listOperatorsByAccount(getAccountId());
                foreach ($operators as $assignedOperator) {
                    if ($operator['operatorid'] != $assignedOperator['operatorid']) {
                        $this->editOperatorFieldConfigs['assigned_operators']['options'][$assignedOperator['operatorid']] = $assignedOperator['fullname'];
                    }
                }
                $departments = MapperFactory::getDepartmentMapper()->enumDepartments(Resources::getCurrentLocale());
                if (!empty($departments)) {
                    $this->editOperatorFieldConfigs['supervised_depts']['options'] = array_combine(Helper::getColumnFromArray($departments, 'departmentid'), Helper::getColumnFromArray($departments, 'departmentname'));
                }
            } else {
                $this->editOperatorFieldConfigs['assigned_operators']['description_key'] = 'form.field.assigned_operators.descr_for_admin';
                $this->editOperatorFieldConfigs['supervised_depts']['description_key'] = 'form.field.supervised_depts.descr_for_admin';
            }
        }

        if ($this->currentOperator['operatorid'] == $operator['operatorid']) {
            $this->editOperatorFieldConfigs['is_admin']['disabled'] = TRUE;
        }

        $this->viewConfig['content_template'] = 'backend/content/operator.edit.tpl';
        $this->responseData['titleKey'] = 'page_agent.title';
        $this->responseData['descriptionKey'] = 'page_agent.intro';

        $this->responseData['tab2OperatorFields'] = $this->tabs2Fields;
        $this->responseData['operatorFields2Config'] = $this->editOperatorFieldConfigs;
        $this->responseData['groupConfigs'] = $this->group2FieldConfigs;
    }

    protected function getOperatorData($operator) {
        $result = array();
        if (!empty($operator)) {
            $operatorDepartments = MapperFactory::getOperatorDepartmentMapper()->enumDepartmentsByOperator($operator['operatorid']);
            $operatorConfig = !empty($operator['config']) ? json_decode($operator['config'], TRUE) : array();
            $result = array(
                'id' => $operator['operatorid'],
                'visible_name' =>  !empty($operatorConfig['visible_name']) ? $operatorConfig['visible_name'] : $operator['fullname'],
                'max_chats_per_operator' => !empty($operatorConfig['max_chats_per_operator']) ? $operatorConfig['max_chats_per_operator'] : NULL,
                'max_overlimit_chats_per_operator' => !empty($operatorConfig['max_overlimit_chats_per_operator']) ? $operatorConfig['max_overlimit_chats_per_operator'] : NULL,
                'name' => $operator['fullname'],
                'email' => $operator['email'],
                'operator_order' => $operator['operatororder'],
                'chat_locales' => !empty($operator['locales']) ? explode(',', $operator['locales']) : array(),
                'is_admin' => Operator::getInstance()->isOperatorAdmin($operator),
                'departments' => Helper::getColumnFromArray($operatorDepartments, 'departmentid'),
                'department_to_priority' => array_combine(Helper::getColumnFromArray($operatorDepartments, 'departmentid'), Helper::getColumnFromArray($operatorDepartments, 'priority')),
                'answers' => $operator['answers'],
                'avatar' => $operator['avatar'],
                'office' => $operator['officeid'],
                'new_visitor_notification' => 0
            );

            if (Tariff::getInstance()->hasTariffOption('has_supervisors')) {
                $assignedOperatorIds = MapperFactory::getOperatorSupervisorMapper()->getAssignedOperatorIds($operator['operatorid']);
                $supervisedDepts = MapperFactory::getOperatorDepartmentMapper()->getOperatorSupervisedDeptsIds($operator['operatorid']);
                $result['assigned_operators'] = !empty($assignedOperatorIds) ? $assignedOperatorIds : array();
                $result['supervised_depts'] = !empty($supervisedDepts) ? $supervisedDepts : array();
            }
            if (Settings::Get('admin_multilang')) {
                $result['backend_locale'] = !empty($operatorConfig['backend_locale']) ? $operatorConfig['backend_locale'] : Resources::getCurrentLocale();
            }

            if (array_key_exists('new_visitor_notification', $operatorConfig)) {
                if ($operatorConfig['new_visitor_notification'] === NULL) {
                    $result['new_visitor_notification'] = 0;
                }

                if ($operatorConfig['new_visitor_notification'] === TRUE) {
                    $result['new_visitor_notification'] = 1;
                }

                if ($operatorConfig['new_visitor_notification'] === FALSE) {
                    $result['new_visitor_notification'] = 2;
                }
            }
        }
        return $result;
    }

    protected function getOperatorJSONAction($params) {
        $this->setOutputType('JSON');
        $operator = Operator::getInstance()->getOperatorById($params['operatorid']);
        $this->responseData = $this->getOperatorData($operator);
    }

    protected function saveOperatorDepartmentsJSONAction() {
        $this->setOutputType('JSON');

        $params = $this->getParams();
        $operator = Operator::getInstance()->getOperatorById($params['operatorid']);
        $departments = array();
        $priorities = array();
        try {
        if (isset($params['departments'])) {
            foreach ($params['departments'] as $department) {
                array_push($departments, $department['id']);
                $priorities[$department['id']] = $department['priority'];
            }
        }

            Operator::getInstance()->setOperatorDepartments($operator['operatorid'], $departments, $priorities);
            $this->responseData['result'] = 'ok';

        } catch (Exception $e) {
            $this->responseData['result'] = 'error';
        }


        KeyValueCache::clearKind('operators');
        Helper::clearOperatorCache($operator['operatorid']);

    }

    protected function saveOperatorJSONAction($params, $errors) {
        $this->setOutputType('JSON');
        $this->responseData['stored'] = array();

        if (!empty($errors['email']) && !empty($errors['email']['not_exist_operator_email'])
            && MapperFactory::getOperatorMapper()->getByEmail($params['email'])['operatorid'] == $params['operatorid']
        ) {
            unset($errors['email']['not_exist_operator_email']);
            if (empty($errors['email'])) {
                unset($errors['email']);
            }
        }

        $this->responseData['errors'] = $errors;

        if ($this->currentOperator['operatorid'] == $params['operatorid']) {
            $this->editOperatorFieldConfigs['is_admin']['disabled'] = TRUE;
        }

        $fieldsForSave = array();
        foreach ($params as $key => $value) {
            if (!array_key_exists($key, $errors) &&
                (empty($this->editOperatorFieldConfigs[$key]) || empty($this->editOperatorFieldConfigs[$key]['disabled']))
            ) {
//                if ($key == 'name') {
//                    $value = preg_replace("/(\<|\>|\[|\])/", '', $value);
//                }
                $fieldsForSave[$key] = $value;

            }
        }

        $actionLogOldValue = $this->getOperatorData(Operator::getInstance()->getOperatorById($params['operatorid']));

        $this->saveOperator($fieldsForSave);
        $this->operatorUpdated = TRUE;
        KeyValueCache::clearKind('getOperatorById');
        KeyValueCache::clearKind('operators');

        $actionLogNewValue = $this->getOperatorData(Operator::getInstance()->getOperatorById($params['operatorid']));
        ActionLog::getInstance()->updateAction($this->actionLogTarget, $actionLogOldValue, $actionLogNewValue);
    }

    protected function createOperator($params) {
        $password = !empty($params['password']) ? $params['password'] : substr(md5(time()), 0, 10);
        $newOperatorFields = array(
            'email' => $params['email'],
            'fullname' => $params['name'],
            'operatororder' => $params['operator_order'],
            'password' => Operator::getInstance()->getDbPassword($password)
        );

        if (!empty($params['visible_name'])) {
            $newOperatorFields['config']['visible_name'] = $params['visible_name'];
        }

        if (!empty($params['max_chats_per_operator'])) {
            $newOperatorFields['config']['max_chats_per_operator'] = $params['max_chats_per_operator'];
        }

        if (!empty($params['max_overlimit_chats_per_operator'])) {
            $newOperatorFields['config']['max_overlimit_chats_per_operator'] = $params['max_overlimit_chats_per_operator'];
        }

        if (!empty($params['office'])) {
            $newOperatorFields['officeid'] = $params['office'];
        }

        if (isset($newOperatorFields['config'])) {
            $newOperatorFields['config'] = json_encode_readable($newOperatorFields['config']);
        }

        $operatorId = Operator::getInstance()->save($newOperatorFields);
        if (!empty($params['send_email'])) {
            MailNotifications::sendPasswordToOperator($newOperatorFields['email'], $password, $newOperatorFields['fullname']);
        }

        $localesFields = array(
            'operatorid' => $operatorId,
            'locales' => !empty($params['chat_locales']) ? implode(',', $params['chat_locales']) : NULL
        );

        MapperFactory::getOperatorLastAccessMapper()->save($localesFields);

        if (!empty($params['departments'])) {
            Operator::getInstance()->setOperatorDepartments($operatorId, $params['departments']);
        }

        $operatorAccountRoles = MapperFactory::getOperatorAccountViewMapper()->getByOperatorIdAndAccount($operatorId, $this->currentAccount['accountname']);
        $isPartner = FALSE;
        if (!empty($operatorAccountRoles)) {
            $isPartner = strpos($operatorAccountRoles['roles'], 'partner') !== FALSE;
        }
        $roles[] = (isset($params['is_admin']) && $params['is_admin']) ? 'admin' : 'operator';
        if ($isPartner) {
            $roles[] = 'partner';
        }
        MapperFactory::getOperatorAccountMapper()->setOperatorRolesForAccount($operatorId, implode(',', $roles), $this->currentAccount['accountname']);

        $avatarFile = $this->getFile('avatar');
        if (!empty($avatarFile) && !empty($avatarFile['name']) && $avatarFile['size'] > 0 && $avatarFile['error'] == 0) {

            $uploadErrors = Operator::getInstance()->UploadOperatorAvatar($operatorId, $avatarFile);

            if (empty($uploadErrors)) {
                $newOperatorAvatarField['avatar'] = Operator::getInstance()->makeAvatarURL($operatorId);
                Operator::getInstance()->UpdateOperator($operatorId, $newOperatorAvatarField);
            }
        }

        Authtoken::clearOtherOperatorTokens($operatorId);
        KeyValueCache::clearKind('operators');
        Helper::clearOperatorCache($operatorId);
    }

    protected function saveOperator($params) {
        $operator = Operator::getInstance()->getOperatorById($params['operatorid']);
        if (!empty($operator)) {
            $operatorConfig = array();
            if (!empty($operator['config'])) {
                $operatorConfig = json_decode($operator['config'], TRUE);
            }
            $updatedFields = array();
            foreach ($params as $key => $value) {
                switch (strtolower($key)) {
                    case 'name':
                        $updatedFields['fullname'] = $value;
                        $this->responseData['stored'][$key] = $value;
                        break;
                    case 'visible_name':
                        if ($value == '') {
                            $value = array_key_exists('name', $params) ? $params['name'] : $operator['fullname'];
                        }
                        $operatorConfig['visible_name'] = $value;
                        $updatedFields['config'] = json_encode_readable($operatorConfig);
                        $this->responseData['stored'][$key] = $value;
                        break;
                    case 'max_chats_per_operator':
                        $operatorConfig['max_chats_per_operator'] = $value;
                        $updatedFields['config'] = json_encode_readable($operatorConfig);
                        $this->responseData['stored'][$key] = $value;
                        break;
                    case 'max_overlimit_chats_per_operator':
                        $operatorConfig['max_overlimit_chats_per_operator'] = $value;
                        $updatedFields['config'] = json_encode_readable($operatorConfig);
                        $this->responseData['stored'][$key] = $value;
                        break;
                    case 'operator_order':
                        $updatedFields['operatororder'] = $value;
                        $this->responseData['stored'][$key] = $value;
                        break;
                    case 'email':
                    case 'answers':
                        $updatedFields[$key] = $value;
                        $this->responseData['stored'][$key] = $value;
                        break;
                    case 'password':
                        if (!empty($params['password_confirm']) && $params['password'] === $params['password_confirm']) {
                            $res = Operator::getInstance()->checkPasswordStrength($this->currentAccount['accountname'], $params['password']);
                            if ($res['result'] === false) {
                                $this->responseData['errors']['password'] = $res['errors'];
                            } else {
                                $updatedFields['password'] = Operator::getInstance()->getDbPassword($params['password']);
                                $this->responseData['stored'][$key] = $value;
                                Authtoken::clearOtherOperatorTokens($operator['operatorid']);
                            }
                        } else {
                            $this->responseData['errors']['password_confirm']['must_eq'] = Resources::Get('errors.passwords.different');
                        }
                        break;
                    case 'chat_locales':
                        $localesFields = array(
                            'operatorid' => $operator['operatorid'],
                            'locales' => !empty($value) ? implode(',', $value) : NULL
                        );
                        MapperFactory::getOperatorLastAccessMapper()->save($localesFields);
                        $this->responseData['stored'][$key] = $value;
                        break;
                    case 'departments':
                        if ($this->currentOperator['supervisor'] && empty($value)) {
                            $this->responseData['errors']['departments'][]= Resources::Get('errors.supervisors.operator_must_be_in_dept');
                            break;
                        }
                        Operator::getInstance()->setOperatorDepartments($operator['operatorid'], $value);
                        $this->responseData['stored'][$key] = $value;
                        break;
                    case 'assigned_operators':
                        if (Tariff::getInstance()->hasTariffOption('has_supervisors')) {
                            if((
                                    !empty($params['is_admin']) || (!array_key_exists('is_admin', $params) && Operator::getInstance()->isOperatorAdmin($operator))
                                ) && !empty($value)) {
                                $this->responseData['errors']['assigned_operators'][] = Resources::Get('errors.supervisors.operator_is_admin');
                                break;
                            }

                            MapperFactory::getOperatorSupervisorMapper()->deleteAssignedOperators($operator['operatorid']);
                            if (!empty($value)) {
                                foreach ($value as $assignedOperatorId) {
                                    MapperFactory::getOperatorSupervisorMapper()->save(array('operator_id' => $assignedOperatorId, 'supervisor_id' => $operator['operatorid']));
                                }
                            }
                            $this->responseData['stored'][$key] = $value;
                        }
                        break;
                    case 'supervised_depts':
                        if (Tariff::getInstance()->hasTariffOption('has_supervisors')) {
                          foreach ($value as $sDept) {
                            if (!MapperFactory::getOperatorDepartmentMapper()->isOperatorInDepartment($operator['operatorid'], $sDept)) {
                              $this->responseData['errors']['supervised_depts'][] = Resources::Get('errors.supervisors.operator_not_in_dept');
                              break 2;
                            }
                          }
                          if((
                                  !empty($params['is_admin']) || (!array_key_exists('is_admin', $params) && Operator::getInstance()->isOperatorAdmin($operator))
                              ) && !empty($value)) {
                            $this->responseData['errors']['supervised_depts'][] = Resources::Get('errors.supervisors.operator_is_admin');
                            break;
                          }

                          Operator::getInstance()->setOperatorSupervisedDepts($operator['operatorid'], $value);

                          if (!empty($value)) {
                              $operatorAccountRoles = MapperFactory::getOperatorAccountViewMapper()->getByOperatorIdAndAccount($operator['operatorid'], $this->currentAccount['accountname']);
                              if (!empty($operatorAccountRoles)) {
                                  $roles = array();
                                  $isPartner = strpos($operatorAccountRoles['roles'], 'partner') !== FALSE;
                                  $isAdmin = strpos($operatorAccountRoles['roles'], 'admin') !== FALSE;
                                  $roles[] = $isAdmin ? 'admin' : 'supervisor';
                                  if ($isPartner) {
                                      $roles[] = 'partner';
                                  }
                                  MapperFactory::getOperatorAccountMapper()->setOperatorRolesForAccount($operator['operatorid'], implode(',', $roles), $this->currentAccount['accountname']);
                              }
                          }
                          $this->responseData['stored'][$key] = $value;
                        }
                        break;
                    case 'backend_locale':
                        $operatorConfig['backend_locale'] = $value;
                        $updatedFields['config'] = json_encode_readable($operatorConfig);
                        $this->responseData['stored'][$key] = $value;
                        break;
                    case 'new_visitor_notification':
                        switch ($value) {
                            case 0:
                                $operatorConfig['new_visitor_notification'] = NULL;
                                break;
                            case 1:
                                $operatorConfig['new_visitor_notification'] = TRUE;
                                break;
                            case 2:
                                $operatorConfig['new_visitor_notification'] = FALSE;
                                break;
                        }
                        $updatedFields['config'] = json_encode_readable($operatorConfig);
                        $this->responseData['stored'][$key] = $value;
                        break;

                    case 'is_admin':
                        $operatorAccountRoles = MapperFactory::getOperatorAccountViewMapper()->getByOperatorIdAndAccount($operator['operatorid'], $this->currentAccount['accountname']);
                        $isPartner = FALSE;
                        if (!empty($operatorAccountRoles)) {
                            $isPartner = strpos($operatorAccountRoles['roles'], 'partner') !== FALSE;
                        }

                        $roles[] = $value ? 'admin' : 'operator';
                        if ($isPartner) {
                            $roles[] = 'partner';
                        }
                        MapperFactory::getOperatorAccountMapper()->setOperatorRolesForAccount($operator['operatorid'], implode(',', $roles), $this->currentAccount['accountname']);
                        $this->responseData['stored'][$key] = $value;
                        break;
                    case 'subscribe':
                        $updatedFields['subscribed'] = $value;
                        $this->responseData['stored'][$key] = $value;
                        break;
                    case 'office':
                        $updatedFields['officeid'] = $value ? $value : null;
                        $this->responseData['stored'][$key] = $value;
                        break;
                }
            }

            $avatarFile = $this->getFile('avatar');
            if (empty($this->editOperatorFieldConfigs['avatar']['disabled']) && !empty($avatarFile)  && !empty($avatarFile['name']) && $avatarFile['size'] > 0 && $avatarFile['error'] == 0) {
                $res = Operator::getInstance()->UploadOperatorAvatar($operator['operatorid'], $avatarFile);

                if (!empty($res)) {
                    $this->responseData['errors']['avatar']['error'] = $res;
                } else {
                    Helper::clearAvatarImages($operator['operatorid']);
                    $updatedFields['avatar'] = Operator::getInstance()->makeAvatarURL($operator['operatorid']);
                    $this->responseData['stored']['avatar'] = $updatedFields['avatar'];
                }
            } elseif (isset($avatarFile['error']) && $avatarFile['error'] == 1) {
                $this->responseData['errors']['avatar']['error'] = Resources::Get('upload.error');
            }

            if (!empty($updatedFields)) {
                Operator::getInstance()->UpdateOperator($operator['operatorid'], $updatedFields);
            }

            KeyValueCache::clearKind('operators');
            KeyValueCache::clearKind('getOperatorById');
            Helper::clearOperatorCache($operator['operatorid']);

            if ($operator['operatorid'] == $this->currentOperator['operatorid']) {
                Operator::getInstance()->refreshSessionOperator();
            }
        }
    }
}

?>