<?php
#TODO Не забыть про безопасность, доступ только для админов, вероятно.
class Controller_BackgroundTask extends CRUDRequestHandler {
    protected $defaultAction = 'read';

    protected $readParams = array('id', 'key', 'last' => true);

    protected $createParams = array('key', 'config');
    protected $createValidateRules = array(
        'key' => array('not_empty', 'in_list' => array('ThreadReport'))
    );

    /**
     * @var null|Repository_BackgroundTask
     */
    protected $tasksRepository = NULL;

    public function __construct() {
        parent::__construct();
        $this->tasksRepository = Factory_Repository::create('BackgroundTask');
    }

    protected function readAction($params) {
        $this->setOutputType('JSON');
        if (!empty($params['id'])) {
            $task = $this->tasksRepository->findById($params['id']);
            if ($task) {
                $this->checkTask($task);
                $this->responseData = $task;
            }
        } elseif (!empty($params['key'])) {
            if ($params['last']) {
                $task = $this->tasksRepository->findLastByKey($params['key']);
                if ($task) {
                    $this->checkTask($task);
                    $this->responseData = $task;
                }
            } else {
                $this->responseData = $this->tasksRepository->findByKey($params['key']);
            }
        } else {
            $this->responseData = $this->tasksRepository->getAll();
        }
    }

    protected function updateAction($params, $errors) {}

    protected function checkTask(Model_BackgroundTask_Base $task) {
        if ($task->getState() === Model_BackgroundTask_Base::$STATES['RUNNING']
            && !$task->isReallyRunning()
            && (abs($task->getUpdated()->getTimestamp() - time()) > 30)
        ) {
            $task->fail();
            $this->tasksRepository->save($task);
        }
    }
}