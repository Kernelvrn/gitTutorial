<?php
require_once('common.php');
require_once('models/generic/class.mapperfactory.php');
require_once('functions.php');
require_once(dirname(__FILE__) . '/class.allsettings.php');

class AutoInvite  {
  private static $instance = NULL;

  static function getInstance() {
    if (self::$instance == NULL) {
      self::$instance = new AutoInvite();
    }
    return self::$instance;
  }

  private function __construct() {
    
  }

  private function __clone() {
  }

  public function save($hash) {
    $res = MapperFactory::getAutoInviteMapper()->save($hash);
    AllSettings::reset();
//    $this->updateFile();
    return $res;
  }

  public function delete($id) {
    $res = MapperFactory::getAutoInviteMapper()->delete($id);
    AllSettings::reset();
//    $this->updateFile();
    return $res;
  }

  public function getAll() {
    return MapperFactory::getAutoInviteMapper()->getAll();
  }

//  public function getAll() {
//    if (!@file_exists(AUTOINVITE_RULES_FILE)) {
//      $this->saveToFile();
//    }
//    return @unserialize(@file_get_contents(AUTOINVITE_RULES_FILE));
//  }
//
//  private function saveToFile() {
//    $rules = MapperFactory::getAutoInviteMapper()->getAll();
//    write_file_value(AUTOINVITE_RULES_FILE, serialize($rules));
//  }

//  private function updateFile() {
//    @unlink(AUTOINVITE_RULES_FILE);
//    $this->saveToFile();
//  }

}

?>
