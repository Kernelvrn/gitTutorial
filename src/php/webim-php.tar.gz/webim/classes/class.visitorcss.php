<?php
require_once(__DIR__ . '/common.php');
require_once(__DIR__ . '/../autoload.php');


class VisitorCSS {
    static public function getVisitorCSS($location) {
        $cssFilePath = FilesLocation::getVisitorCSSPath(self::getThemeByLocation($location));
        $css = file_get_contents($cssFilePath);

        if ($addCSSFilePath = FilesLocation::getVisitorAdditionalCSSPath()) {
            $css .= PHP_EOL . PHP_EOL . file_get_contents($addCSSFilePath);
        }

        return self::prependUrlsByWebimRoot($css);
    }

    static private function getThemeByLocation($location) {
        $locationParams = Location::getLocation($location);
        return !empty($locationParams['chat']['theme']) ? $locationParams['chat']['theme'] : 'default';
    }

    static private function prependUrlsByWebimRoot($css) {
        $prefix = Helper::getServerRootURL(true);
        return preg_replace('/url\([\'"]?(\/[^\'"]+)[\'"]?\)/i', 'url(\'' . $prefix . '${1}\')', $css);
    }
}