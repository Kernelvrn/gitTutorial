<?php
/**
 * Created by JetBrains PhpStorm.
 * User: versus
 * Date: 25.04.13
 * Time: 19:07
 * Base class for operator page handlers
 *
 * Main method - makeResponse. We try to get two request params: 'action' and 'type'
 * and execute local method [action_value]Action and process result via [output_value]Output
 *
 */
require_once(dirname(__FILE__) . '/../autoload.php');

abstract class BaseRequestHandler {
    private $params = NULL; //Request params
    private $paramsForDebugging = array(
        'debug_print'
    );
    private $files = NULL; //Request files
    private $action = '';
    private $outputType = 'HTML';

    protected $defaultAction = 'default';

    protected $responseData = array(); //Fill in actions
    protected $viewConfig = array(); //Fill in actions

    protected $securedActions = array(); //Array for actions which modify account data (delete operators, change settings, etc.)

    protected $currentAccount = NULL;
    protected $currentOperator = NULL;

    public function __construct() {
        $this->loadParams();
        $this->loadFiles();

        $this->initCurrentAction();

        if (getAccountId()) {
            $this->currentAccount = Account::getInstance()->getCurrentAccount();
            $this->initCurrentOperator();
        }
    }

    /**
     * Process url-params, execute action (by 'action' from params) and return output (type by 'type' from params)
     */
    public function makeResponse() {
        if (in_array($this->action, $this->securedActions)) {
            $csrfToken = $this->getParam('security_token');
            Csrf::check($csrfToken);
        }

        $debugParams = $this->getDebugParams();
        $actionParams = $this->getActionParams($this->action);
        $actionParams = $this->preParseActionParams($this->action, $actionParams);
        $paramErrors = $this->validateActionParams($this->action, $actionParams);
        $actionParams = $this->postParseActionParams($this->action, $actionParams, array_keys($paramErrors));
        $actionMethodName = $this->getActionMethodName($this->action);
        $this->$actionMethodName($actionParams, $paramErrors);

        $view = Factory_View::create($this->getOutputType(), array_merge($this->viewConfig, array('debug' => $debugParams)));
        $view->output($this->responseData);
    }

    protected function initCurrentOperator() {
        $operator = Operator::getInstance()->silentGetCurrentOperator();
        if (!empty($operator)) {
            $operator['is_admin'] = Operator::getInstance()->isOperatorAdmin();
            if (!$operator['is_admin']) {
                $data = Operator::getInstance()->getSupervisedDeptsAndOperators();
                $operator['supervised_depts'] = $data['depts'];
                $operator['supervised_operators'] = $data['operators'];
                $operator['supervisor'] = (!empty($operator['supervised_depts'])) ? true : false;
            } else {
                $operator['supervisor'] = false;
            }

            $this->currentOperator = $operator;
        }
    }

    protected function initCurrentAction() {
        $action = preg_replace('/\s+/', '', $this->getParam('action'));
        if (empty($action) || !method_exists($this, $this->getActionMethodName($action))) {
            $action = $this->defaultAction;
        }
        $this->setCurrentAction($action);
    }

    protected function defaultAction() {
        $this->responseData = array('text' => 'This is default action!');
    }

    protected function getParams() {
        return $this->params;
    }

    protected function getFiles() {
        return $this->files;
    }

    protected function getParam($key, $default = NULL) {
        return isset($this->params[$key]) ? $this->params[$key] : $default;
    }

    protected function getFile($key, $default = NULL) {
        return !empty($this->files[$key]) ? $this->files[$key] : $default;
    }

    protected function getOutputType() {
        return $this->outputType;
    }

    protected function setOutputType($outputType = 'HTML') {
        $this->outputType = $outputType;
    }

    protected function getActionParams($actionName) {
        $actionParams = array();
        $actionParamNames = $actionName . 'Params';
        if (!empty($this->$actionParamNames)) {
            if (!$this->canActionProcessPartOfParameters($actionName)) {
                $actionParams = $this->getActionParamsTree($this->$actionParamNames);
            }
            foreach ($this->$actionParamNames as $paramName => $defaultValue) {
                if (!is_string($paramName)) {
                    $paramName = $defaultValue;
                    $defaultValue = NULL;
                }
                $paramPath = $this->getActionParamPath($paramName);
                if (Helper::arrayKeyExistsByPath($paramPath, $this->getParams())) {
                    $value = Helper::getValueFromArrayByPath($paramPath, $this->getParams());
                    Helper::setValueToArrayByPath($value, $paramPath, $actionParams);
                } elseif (isset($defaultValue)) {
                    Helper::setValueToArrayByPath($defaultValue, $paramPath, $actionParams);
                }
            }
        }
        return $actionParams;
    }

    protected function validateActionParams($actionName, array $actionParams) {
        $errors = array();
        $paramName2ValidateRules = $actionName . 'ValidateRules';
        if (!empty($this->$paramName2ValidateRules)) {
            foreach ($this->$paramName2ValidateRules as $paramName => $validateRules) {
                $paramPath = $this->getActionParamPath($paramName);
                if (Helper::arrayKeyExistsByPath($paramPath, $actionParams)) {
                    $value = Helper::getValueFromArrayByPath($paramPath, $actionParams);
                    $notPassed = Validator::check($value, $validateRules);
                    if (!empty($notPassed)) {
                        $errors[$paramName] = $notPassed;
                    }
                }
            }
        }
        return $errors;
    }

    protected function preParseActionParams($actionName, array $actionParams) {
        $paramName2ParseRules = $actionName . 'PreParamParsers';
        return !empty($this->$paramName2ParseRules) ? $this->parseActionParams($this->$paramName2ParseRules, $actionParams) : $actionParams;
    }

    protected function postParseActionParams($actionName, array $actionParams, array $exceptParamNames = array()) {
        $paramName2ParseRules = $actionName . 'PostParamParsers';
        return !empty($this->$paramName2ParseRules) ? $this->parseActionParams($this->$paramName2ParseRules, $actionParams, $exceptParamNames) : $actionParams;
    }

    protected function getCurrentAction() {
        return $this->action;
    }

    protected function setCurrentAction($action) {
        $this->action = $action;
    }

    private function parseActionParams(array $paramName2parseRules, array $actionParams, array $exceptParamNames = array()) {
        foreach ($paramName2parseRules as $paramName => $parserName) {
            if (!in_array($paramName, $exceptParamNames)) {
                $paramPath = $this->getActionParamPath($paramName);
                if (Helper::arrayKeyExistsByPath($paramPath, $actionParams)) {
                    $value = Helper::getValueFromArrayByPath($paramPath, $actionParams);
                    $value = Parser::parseTo($parserName, $value);
                    Helper::setValueToArrayByPath($value, $paramPath, $actionParams);
                }
            }
        }

        return $actionParams;
    }

    private function canActionProcessPartOfParameters($actionName) {
        $checkVarName = $actionName . 'CanProcessPartParams';
        return !empty($this->$checkVarName) ? TRUE : FALSE;
    }

    private function loadParams() {
        $requestBody = file_get_contents('php://input');
        $params = $this->unFlattenArr(array_merge($_POST, $_GET));
        //TODO: In php://input can be not only json, but now it doesn't matter;
        $payload = !empty($requestBody) ? json_decode($requestBody, TRUE) : array();
        if (is_array($payload)) {
            $params = array_merge($payload, $params);
        }

        $this->params = array_merge($params, $_FILES);
    }

    //When we send FormData with flatten json objects. (Necessary for send json and files in same time)
    private function unFlattenArr($arr) {
        if (!is_array($arr)) {
            return $arr;
        }
        $result = array();
        foreach ($arr as $key => $value) {
            $path = explode('[', $key);
            Helper::setValueToArrayByPath($this->unFlattenArr($value), $path, $result);
        }
        return $result;
    }

    private function loadFiles() {
        $this->files = $_FILES;
    }

    protected function getActionMethodName($action) {
        return $action . 'Action';
    }

    private function getActionParamPath($actionParamName) {
        return explode('.', $actionParamName);
    }

    private function getActionParamsTree(array $actionParams, $fillValue = NULL) {
        $tree = array();
        foreach ($actionParams as $paramName) {
            Helper::setValueToArrayByPath($fillValue, $this->getActionParamPath($paramName), $tree);
        }
        return $tree;
    }

    private function getDebugParams() {
        $params = $this->getParams();
        $debugParams = array();
        foreach ($this->paramsForDebugging as $paramName) {
            if (array_key_exists($paramName, $params)) {
                $debugParams[$paramName] = $params[$paramName];
            }
        }

        return $debugParams;
    }
}

?>