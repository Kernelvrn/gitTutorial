<?php

require_once(__DIR__ . '/models/generic/class.mapperfactory.php');
require_once(__DIR__ . '/functions.php');
require_once(__DIR__ . '/../autoload.php');

class Settings {
  const SETTINGS_KEY = 'all_config';
  const SETTINGS_CACHE_TTL = 6000;
  private $storedSettings = NULL;
  private $storedDepartmentSettings = NULL;
  private $settings = NULL;
  private $departmentSettings = NULL;
  private $descriptor = NULL;

  protected $tableName = 'chatconfig';
  protected $uniqueTableKey = 'configid';

  private static $instance = NULL;

  private $settingsForWhichGetDefaultIfMissing = array('answers');

  public static function getInstance() {
    if (self::$instance == NULL) {
      self::$instance = new Settings();
    }
    return self::$instance;
  }

  private function __construct() {
      $this->descriptor = Settings::getAccountConfigDescriptor();
  }

    public static function getAccountConfigDescriptor() {
        $result = array();

        $jsonDescriptor = @file_get_contents(dirname(__FILE__) . '/account-config-descriptor.json');
        if (!empty($jsonDescriptor)) {
            $result = json_decode($jsonDescriptor, TRUE);
        }
        $accountId = getAccountId();
        if ($accountId != NULL) {
            $accountSpecificDescriptorPath = dirname(__FILE__) . '/../account-specific/' . getAccountId() . '/configs/account-config-descriptor.json';
            if (file_exists($accountSpecificDescriptorPath)) {
                $accountSpecificDescriptor = @file_get_contents($accountSpecificDescriptorPath);
                $accountSpecificDescriptor = json_decode($accountSpecificDescriptor, TRUE);
                if ($accountSpecificDescriptor) {
                    $result = array_merge($result, $accountSpecificDescriptor);
                } else {
                    doMyLog('@' . $accountId . ': Failed to load account-specific descriptor');
                }
            }
        }

        return $result;
    }

    public static function areOfficesByGeo() {
        $offices = Settings::Get('offices');
        if (!empty($offices)) {
            foreach ($offices as $o) {
                if (!empty($o['geo'])) {
                    return true;
                }
            }
        }
        return false;
    }

    private function __clone() {}

  public static function Get($key, $skipCache = FALSE, $departmentId = NULL) {
    if ($key == 'multilang' || $key == 'admin_multilang') {
      if (in_array(getBrandPartnerFromHeaders(), array('v2chatnet', 'v2chat'))) {
        return true;
      } elseif (getBrandPartnerFromHeaders() == 'infotellchatru') {
        return false;
      }
    }

    if ($key == 'admin_multilang') {
        $key = 'multilang';
    }

    if ($key == 'include_dvigus_js') {
        return false;
    }

    if ($key == 'track_every_visitor_department') {
        return true;
    }

    $res = self::getInstance()->_get($key, $skipCache, $departmentId);

    if ($key == 'hosturl' && !empty($res)) {
      if (!preg_match('/^http/', $res)) {
        $res = 'http://' . $res;
      }
    } elseif ($key == 'low_balance_warning_threshold' && empty($res)) {
      $res = 138;
    } elseif ($key == 'private_key' && empty($res)) {
      $res = array(strtolower(md5(uniqid())));
      self::Set($key, $res);
    } elseif ($key == 'telegram_secret_key' && empty($res)) {
      $res = strtolower(md5(uniqid()));
      self::Set($key, $res);
    } elseif ($key == 'vk_secret_key' && empty($res)) {
      $res = strtolower(md5(uniqid()));
      self::Set($key, $res);
    } elseif ($key == 'vk_provided_id_key' && empty($res)) {
      $res = strtolower(md5(uniqid()));
      self::Set($key, $res);
    } elseif ($key == 'telegram_provided_id_key' && empty($res)) {
      $res = strtolower(md5(uniqid()));
      self::Set($key, $res);
    } elseif ($key == 'vk_callback_url' && empty($res)) {
      $res = Helper::getServerProtocol() . getAccountId() . "." . Helper::getRootDomain() . "/l/v/vk";
      self::Set($key, $res);
    } elseif ($key == 'logo') {
      $res = str_replace(WEBIM_ROOT . '/', '/', $res);
    }

    return $res;
  }

  public static function canUse($key) {
      return self::getInstance()->_canUse($key);
  }

  public static function Set($key, $value) {
    self::getInstance()->_set($key, $value);
  }

    /**
     * @return array|null
     */
  public static function GetCategories() {
    $categoriesValue = trim(self::Get('categories'));
    return !empty($categoriesValue) ? self::text2Categories($categoriesValue) : NULL;
  }

  public static function GetPredefinedAnswers($lang, $depId = null, $skipCache = FALSE) {
      $answers = self::Get('answers', $skipCache, $depId) ? self::Get('answers', $skipCache, $depId) : array();
      $result = isset($answers[$lang]) ? $answers[$lang] : array();
      return $result;

  }

  public static function GetOfficeName($officeId) {
      $offices = self::Get('offices');
      if (!empty($offices)) {
          foreach ($offices as $office) {
              if ($officeId == $office['id']) {
                  return $office['name'];
              }
          }
      }
      return NULL;
  }

  /**
   * Check that settings stored in config (department) table
   * @param string $key
   * @param null $departmentId
   * @return bool
   */
  public static function isStored($key, $departmentId = NULL) {
    if (empty($departmentId)) {
      return self::getInstance()->isStoredAccountSetting($key);
    } else {
      return self::getInstance()->isStoredDepartmentSetting($key, $departmentId);
    }
  }

  private function isStoredAccountSetting($key) {
    if (empty($this->storedSettings)) {
      $this->storedSettings = MapperFactory::getConfigMapper()->enumPairs();
    }

    return isset($this->storedSettings[$key]);
  }

  private function isStoredDepartmentSetting($key, $departmentId) {
    if (!isset($this->storedDepartmentSettings[$departmentId])) {
      $department = MapperFactory::getDepartmentMapper()->getById($departmentId);
      $this->storedDepartmentSettings[$departmentId] = !empty($department['config']) ? json_safe_decode($department['config']) : array();
    }

    return isset($this->storedDepartmentSettings[$departmentId][$key]);
  }

  private function _get($key, $skipCache = FALSE, $departmentId = NULL) {
    if (getAccountId() == NULL) {
      return $this->processViaDescriptorForGet($key, NULL);
    }
    $this->ensureLoaded($skipCache, $departmentId);
    $settings = $departmentId ? $this->departmentSettings[$departmentId] : $this->settings;
    $value = isset($settings[$key]) ? $settings[$key] : NULL;
    return $this->processViaDescriptorForGet($key, $value);
  }

  private function _set($key, $value) {
    $value = $this->processViaDescriptorForSet($key, $value);

    if ($this->processViaDescriptorForGet($key, $value) === self::Get($key)) {
        return;
    }

    MapperFactory::getConfigMapper()->save(array(
        'configkey' => $key,
        'configvalue' => $value
      )
    );
    $this->ensureLoaded();
    $this->settings[$key] = $value;
    KeyValueCache::put(self::SETTINGS_KEY, $this->settings, 'settings', self::SETTINGS_CACHE_TTL);
    AllSettings::reset();
    @touch(DATA_UPDATED_FILE);
  }

  private function _canUse($key) {
      if (isset($this->descriptor[$key]['tariff_option_dependancy'])) {
          return Tariff::getInstance()->hasTariffOption($this->descriptor[$key]['tariff_option_dependancy']['required_option']);
      } else {
          return TRUE;
      }
    }

  private function processViaDescriptorForGet($key, $value) {
    $result = $value;
    if (!empty($this->descriptor[$key])) {
        if (!$this->_canUse($key)) {
            $result = $this->descriptor[$key]['tariff_option_dependancy']['value_without_option'];
        } else {
            if ($value === NULL) {
                $result = $this->descriptor[$key]['default'];
            } else {
                switch (strtolower($this->descriptor[$key]['type'])) {
                    case 'boolean':
                        $result = $this->isTrue($value) ? TRUE : FALSE;
                        break;
                    case 'integer':
                        $result = (int)$value;
                        break;
                    case 'json':
                        $result = json_decode($value, TRUE);
                        if ($result === null) {
                          doMyLog("Could not decode " . $value);
                        }
                        break;
                    case 'comma-separated':
                        $result = convertCommaSeparatedStringToArray($value);
                        break;
                    case 'string':
                    default:
                        $result = (string)$value;
                }
            }
        }
    }
    return $result;
  }

  private function processViaDescriptorForSet($key, $value) {
    if ($value === null) {
          return null;
    }
    $result = $value;
      $prevValue = $this->_get($key, true);

    if (!empty($this->descriptor[$key])) {
      switch (strtolower($this->descriptor[$key]['type'])) {
        case 'boolean':
          $result = $this->isTrue($value) ? 'true' : 'false';
          break;
        case 'integer':
          $value = (int)$value;
          $result = (string)$value;
          break;
        case 'json':
          if (is_array($value)) {
              $result = json_encode_readable($value);
          } elseif (empty($value)) {
              $result = NULL;
          } else {
              $tmp = @json_decode($value);
              $result = $tmp !== null ? $value : json_encode_readable($prevValue);
          }
          break;
        case 'comma-separated':
            if (is_string($value)){
                $result = $value;
            } else {
                $result = implode(',', $value);
            }
            break;
        case 'string':
          if (!$value) {
              return null;
          }
        default:
          $result = (string)$value;
      }
    }

    if (strlen($result) > 500000) {
      immediatelyNotifyAboutProblem('Settings->Set->processViaDescriptorForSet: value for key ' . $key . ' too long ' . strlen($result));
//        throw new Exception('Settings->Set->processViaDescriptorForSet: value for key ' . $key . ' too long ' . strlen($result));
    }

    return $result;
  }

  private function isTrue($value) {
      if ($value === TRUE
      || (is_string($value) && strtolower($value) === 'true')
      || (is_numeric($value) && $value)) {
          return TRUE;
      }
      return FALSE;
  }

  private static function text2Categories($text) {
    $categoryMaxLength = 128;
    $categories = array();
    $lines = explode(PHP_EOL, trim($text));
    if (!empty($lines)) {
      $curCategory = array(
        'name' => mb_substr(trim(array_shift($lines)), 0, $categoryMaxLength, WEBIM_ENCODING)
      );

      foreach ($lines as $line) {
        if (preg_match('/^\s/', $line)) {
          $curCategory['children'][] = array(
            'name' => mb_substr(trim($line), 0, $categoryMaxLength, WEBIM_ENCODING)
          );
        } else {
          $categories[] = $curCategory;
          $curCategory = array(
            'name' => mb_substr(trim($line), 0, $categoryMaxLength, WEBIM_ENCODING)
          );
        }
      }

      $categories[] = $curCategory;
    }

    return $categories;
  }

  private function ensureLoaded($skipCache = FALSE, $departmentId = NULL) {
    if (!empty($departmentId)) {
      $this->getDepartmentSettings($departmentId, $skipCache);
    } else {
      $this->getAccountSettings($skipCache);
    }
  }

  private function getAccountSettings($skipCache = FALSE) {
    if ($this->settings === NULL && !$skipCache && ($fromCache = KeyValueCache::get(self::SETTINGS_KEY, 'settings', FALSE)) !== FALSE) {
      $this->settings = $fromCache;
    } elseif ($this->settings === NULL || $skipCache) {
      $this->settings = array();
      $stored = MapperFactory::getConfigMapper()->enumPairs();
      foreach ($stored as $key => $value) {
        $this->settings[$key] = $value;
      }

      doMyLog('Storing settings cache for ' . getAccountId() . ' skip cache: ' . $skipCache);
      KeyValueCache::put(self::SETTINGS_KEY, $this->settings, 'settings', self::SETTINGS_CACHE_TTL);
    }
    return $this->settings;
  }

  private function getDepartmentSettings($departmentId, $skipCache = FALSE) {
    if (empty($this->departmentSettings[$departmentId]) && !$skipCache && ($fromCache = KeyValueCache::get(self::SETTINGS_KEY, 'settings_department_' . $departmentId, FALSE)) !== FALSE) {
      $this->departmentSettings[$departmentId] = $fromCache;
    } elseif (empty($this->departmentSettings[$departmentId])) {
      $settings = $this->getAccountSettings($skipCache);

      // Write defaults for certain keys, instead of account value. It will be later
      // overwritten by department settings value if key is present in department settings.
      $defaults = $this->getDefaults();
      foreach ($this->settingsForWhichGetDefaultIfMissing as $setting) {
          $settings[$setting] = $defaults[$setting];
      }

      $department = MapperFactory::getDepartmentMapper()->getById($departmentId);
      if (!empty($department['config'])) {
        $departmentSettings = json_safe_decode($department['config']);
        foreach ($departmentSettings as $key => $value) {
          $settings[$key] = $value;
        }
        doMyLog('Storing settings cache for ' . getAccountId() . ', department ' . $departmentId . ' skip cache: ' . $skipCache);
        KeyValueCache::put(self::SETTINGS_KEY, $settings, 'settings_department_' . $departmentId, self::SETTINGS_CACHE_TTL);
      }

      $this->departmentSettings[$departmentId] = $settings;
    }
    return $this->departmentSettings[$departmentId];
  }

  private function getDefaults() {
    $defaults = array();
    foreach ($this->descriptor as $key => $conf) {
      $defaults[$key] = $conf['default'];
    }
    return $defaults;
  }

  /**
   *    Get product name depending on package(lite/pro)
   */
  public static function GetProductName() {
    $product = Resources::Get('webim.pro.title');
    return $product;
  }

  public static function GetProduct() {
    $product = 'pro';
    return $product;
  }

  public static function GetProductAndVersion() {
    return self::GetProductName() . ' ' . WEBIM_VERSION;
  }

  public static function GetDBVersion() {
    return self::Get('version', true);
  }

}

?>
