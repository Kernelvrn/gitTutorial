<?php

/**
 * Created by JetBrains PhpStorm.
 * User: versus
 * Date: 15.01.14
 * Time: 17:59
 * Base class for views (MVC) of Webim backend
 *
 * @example ./html.php Example of usage.
 */
abstract class View_Base {
    protected $type = '';
    protected $defaultParams = array();
    protected $params = array();
    protected $headers = array();

    public function __construct($params) {
    	$nameParts = explode('_', get_class($this));
        $this->type = array_pop($nameParts);
        $this->params = array_merge($this->defaultParams, $params);
    }

    /**
     * Render make string for output
     * @param array $data Data for output
     * @return string
     * @throws
     */
    final public function render($data) {
        $tmpFileName = tempnam(sys_get_temp_dir(), 'view_');
        $writer = $this->createWriter($tmpFileName);
        $this->outputTo($data, $writer);
        unset($writer);
        $content = file_get_contents($tmpFileName);
        unlink($tmpFileName);

        return $content;
    }

    /**
     * Print render result in std_output
     * @param array $data
     */
    final public function output($data) {
        if (!empty($this->params['debug']) && !empty($this->params['debug']['debug_print'])) {
            $this->printDebugHeaders();
        } else {
            $this->printHeaders($data);
        }

        $this->outputTo($data, $this->createWriter('php://output'));
    }

    /**
     * Выводит результат в файл
     * @param mixed $data данные для вывода
     * @param string $filePath путь к файлу
     */
    final public function outputToFile($data, $filePath) {
        $this->outputTo($data, $this->createWriter($filePath));
    }

    protected function createWriter($streamName) {
        return new View_Writer_Raw($streamName);
    }

    protected function outputTo($data, $writer) {
        throw new Exception('Not implemented');
    }

    protected function outputObject($object, $writer) {
        $subView = Factory_SubView::create($this->type, get_class($object));
        $subView->outputTo($object, $writer);
    }

    protected function getHeaders() {
        return $this->headers;
    }

    private function printDebugHeaders() {
        header('Content-Type: text/html;charset=utf-8');
    }

    private function printHeaders($data) {
        foreach ($this->getHeaders($data) as $header) {
            header($header);
        }
    }
}