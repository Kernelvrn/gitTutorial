<?php

class View_Csv extends View_Base {
    protected $defaultParams = array(
        'headers' => array(),
        'output_filename' => 'csv.csv',
        'not_encode' => false
    );

    protected function createWriter($streamName) {
        return new View_Writer_Csv($streamName, array('encoding' => $this->params['not_encode'] ? WEBIM_ENCODING : 'UTF-16LE'));
    }

    protected function outputTo($data, $writer) {
        if (is_object($data)) {
            $this->outputObject($data, $writer);
        } elseif (is_array($data)) {
            foreach ($data as $block) {
                if (is_object($block)) {
                    $this->outputObject($block, $writer);
                } else {
                    $writer->write($block);
                }
            }
        } else {
            $writer->write($data);
        }
    }

    protected function getHeaders($data) {
        return array(
            'Content-type: text/csv;charset=' . ($this->params['not_encode'] ? WEBIM_ENCODING : 'UTF-16LE'),
            'Content-disposition: attachment;filename=' . $this->params['output_filename']
        );
    }
}