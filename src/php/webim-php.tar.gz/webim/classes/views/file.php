<?php

class View_File extends View_Base {
    protected function outputTo($data, $writer) {
        $writer->write(file_get_contents($data['filePath']));
    }

    protected function getHeaders($data) {
        $info = finfo_open(FILEINFO_MIME_TYPE);
        $mimeType =  finfo_file($info, $data['filePath']);
        finfo_close($info);
        $fileSize = filesize($data['filePath']);
        return array(
            'Content-Type: ' . $mimeType,
            'Content-Length: ' . $fileSize,
            'Content-disposition: attachment;filename=' . basename($data['filePath'])
        );
    }
}
