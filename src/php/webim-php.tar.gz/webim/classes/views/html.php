<?php
class View_Html extends View_Base {
    protected $defaultParams = array(
        'smarty_version' => 3
    );

    protected $headers = array(
        'Content-Type: text/html; charset=utf-8'
    );

    protected function createWriter($streamName) {
        return new View_Writer_Raw($streamName);
    }

    protected function outputTo($data = array(), $writer) {
        if($this->params['smarty_version'] == 2) {
            $smarty = new SmartyClass($this->params['title_key']);
            $smarty->assign($data);
            $writer->write($smarty->display($this->params['template_name'], $display = FALSE));
        } else {
            $smarty = new SmartyWrapper();
            $smarty->assign($data);
            $writer->write($smarty->fetch(
                !empty($this->params['content_template'])
                ? $this->params['content_template']
                : 'backend/layouts/one_page.tpl'
            ));
        }
    }
}