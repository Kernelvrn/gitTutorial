<?php

/**
 * Class View_Json
 * Класс для вывода данных в формате json. Умеет выводить встроенные типы данных,
 * а также наши объекты (для которых есть subview), если переданы в качетсве корневого, или массивом.
 */
class View_Json extends View_Base {
    protected $headers = array(
        'Content-Type: application/json'
    );

    protected function createWriter($streamName) {
        return new View_Writer_Json($streamName);
    }

    /**
     * @param $data mixed
     * @param $writer View_Writer_Json
     */
    protected function outputTo($data, $writer) {
        $writer->startObject();
        $writer->writeObjectFieldKey('responseData');
        $this->outputElement($data, $writer);
        $writer->endObject();
    }

    /**
     * @param $data mixed
     * @param $writer View_Writer_Json
     */
    protected function outputElement($data, $writer) {
        if (is_object($data) && in_array('Traversable', class_implements($data))) {
            $first = true;
            $writer->startArray();
            foreach($data as $element) {
                !$first && $writer->writeSeparator();
                $this->outputElement($element, $writer);
                $first = false;
            }
            $writer->endArray();
        } elseif (is_object($data)) {
            $this->outputObject($data, $writer);
        } elseif (is_array($data) && !empty($data)) {
            reset($data);
            if (is_int(key($data))) {
                $first = true;
                $writer->startArray();
                foreach($data as $element) {
                    !$first && $writer->writeSeparator();
                    $this->outputElement($element, $writer);
                    $first = false;
                }
                $writer->endArray();
            } else {
                $first = true;
                $writer->startObject();
                foreach ($data as $key => $element) {
                    !$first && $writer->writeSeparator();
                    $writer->writeObjectFieldKey($key);
                    $this->outputElement($element, $writer);
                    $first = false;
                }
                $writer->endObject();
            }
        } else {
            $writer->writeValue($data);
        }
    }
}