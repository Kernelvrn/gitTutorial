<?php

class View_Text extends View_Base {
    protected $defaultParams = array(
        'output_filename' => 'info.txt'
    );

    protected function createWriter($streamName) {
        return new View_Writer_Text($streamName);
    }

    protected function outputTo($data, $writer) {
        if (is_object($data)) {
            $this->outputObject($data, $writer);
        } elseif (is_array($data)) {
            foreach ($data as $block) {
                $this->outputTo($block, $writer);
            }
        } else {
            $writer->write($data);
        }
    }

    protected function getHeaders($data) {
        return array(
            'Content-Type: text/html; charset=utf-8',
            'Content-disposition: attachment;filename=' . $this->params['output_filename']
        );
    }
}