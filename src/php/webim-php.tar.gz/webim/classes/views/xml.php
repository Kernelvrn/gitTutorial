<?php

class View_Xml extends View_Base {
    protected $defaultParams = array(
        'version' => '1.0',
        'encoding' => WEBIM_ENCODING,
        'root_name' => 'root',
        'output_filename' => 'xml.xml'
    );

    public function __construct(array $params = array()) {
        parent::__construct($params);
    }

    protected function createWriter($streamName) {
        return new View_Writer_Xml($streamName);
    }

    /**
     * @param array $data
     * @param XMLWriter $writer
     */
    protected function outputTo($data, $writer) {
        $writer->start($this->params);
        $this->writeXML($data, $this->params['root_name'], $writer);
        $writer->end();

    }

    protected function outputObject($object, $key, $writer) {
        $subViewName = 'View_SubView_' . $this->type . '_' . get_class($object);
        if (class_exists($subViewName)) {
            $subView = new $subViewName();
            $subView->outputTo($object, $key, $writer);
        }
    }

    protected function getHeaders($data) {
        return array(
            'Content-Type: text/xml;charset=' . $this->params['encoding'],
            'Content-disposition: attachment;filename=' . $this->params['output_filename']
        );
    }

    protected function writeXML($data, $key,  $writer) {
        if (is_numeric($key)) {
            $key = $data instanceof Model_Thread ? 'thread_' . $key : 'key'.$key; //TODO: backward capability
        }
        if (is_array($data) || is_object($data) && in_array('Traversable', class_implements($data))) {
            $writer->startElement($key);
            foreach ($data as $subKey => $block) {
                $this->writeXML($block, $subKey, $writer);
            }
            $writer->endElement();
        } elseif (is_object($data)) {
            $this->outputObject($data, $key, $writer);
        } else {
            $writer->write($data, $key);
        }
    }
}