<?php

abstract class View_SubView_Json_Statistic_Vector_Base {}