<?php
class View_SubView_Json_Model_BackgroundTask_Base extends View_SubView_Json_Model_Base {
    /**
     * @param $model Model_BackgroundTask_Base
     * @param $writer View_Writer_Json
     */
    public function outputTo($model, $writer) {
        $writer->writeValue(array(
            'id' => $model->getId(),
            'key' => $model->getKey(),
            'state' => $model->getState(),
            'created' => $model->getCreated()->getTimestamp(),
            'started' => $model->getStarted() ? $model->getStarted()->getTimestamp() : NULL,
            'finished' => $model->getFinished() ? $model->getFinished()->getTimestamp() : NULL,
            'progress' => $model->getProgress(),
            'result' => $model->getResult(),
            'config' => $model->getConfig()
        ));
    }
}