<?php
class View_SubView_Json_Model_Department extends View_SubView_Json_Model_Base {
    /**
     * @param $model Model_Department
     * @param $writer View_Writer_Json
     */
    public function outputTo($model, $writer) {
        $writer->writeValue(array(
            'departmentid' => $model->getId() ? (int)$model->getId() : NULL,
            'departmentname' => $model->getNameByLocale(Resources::getCurrentLocale()),
            'departmentorder' => $model->getOrder(),
            'ishidden' => (boolean)$model->isHidden(),
            'departmentkey' => $model->getKey(),
            'logo' => $model->getLogo(),
            'departmentgeo' => $model->getGeo(),
            'answers' => $model->getAnswers() ?: NULL,
            'routing' => $model->getRouting(),
            'callback_hunter_number' => $model->getCallbackHunterNumber(),
            'public_callback_hunter_number' => $model->getPublicCallbackHunterNumber(),
            'deleted' => $model->isDeleted(),
            'agent_hello_text' => $model->getAgentHelloText(),
            'agent_cant_pick_timeout' => $model->getAgentCantPickTimeout(),
            'agent_busy_timeout' => $model->getAgentBusyTimeout(),
            'agent_busy_text' => $model->getAgentBusyText(),
            'timeout_for_chat_auto_close_if_chat_is_inactive' => $model->getTimeoutForChatAutoCloseIfChatIsInactive(),
            'timeout_for_chat_auto_close_if_closed_by_operator' => $model->getTimeoutForChatAutoCloseIfClosedByOperator()
        ));
    }
}