<?php
abstract class View_SubView_Json_Base extends View_SubView_Base {}