<?php
class View_SubView_Json_Statistic_Vector_OperatorTime extends View_SubView_Json_Statistic_Vector_Base {
    /**
     * @param $vector Statistic_Vector_OperatorTime
     * @param $writer View_Writer_Json
     */
    public function outputTo($vector, $writer) {
        $writer->writeValue(array(
            'onlineTime' => $vector->getOnlineTime()->getValue(),
            'dinnerTime' => $vector->getDinnerTime()->getValue()
        ));
    }
}