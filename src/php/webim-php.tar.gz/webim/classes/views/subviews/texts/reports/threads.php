<?php
class View_SubView_Text_Report_Threads extends View_SubView_Text_Report_Base {
    protected function getFieldContent(Report_Field_Base $field, Report_Field_Base $header) {
        $content = null;
        switch ($field->getType()) {
            case Report_Field_Base::TYPE_MESSAGES:
                $content = str_pad('', 50, '-') . "\r\n";
                foreach ($field->getValue() as $message) {
                    $messageContent = $this->getMessageContent($message);
                    if (!empty($messageContent)) {
                        $content .= $this->getMessageContent($message) . "\r\n";
                    }
                }
                $content .= str_pad('', 50, '-');
                break;
            case Report_Field_Base::TYPE_KIND:
                if(!$field->getValue()) {
                    $content = Resources::Get('mail.statistics.thread.in_process');
                }
                break;
            case Report_Field_Base::TYPE_CATEGORY:
                $catArr = $field->getValue();
                $content = !empty($catArr['subcategory']) ? $catArr['category'] . '->' . $catArr['subcategory'] :
                    !empty($catArr['category']) ? $catArr['category'] : '';
                if (!empty($content)) {
                    $content = $header->getValue() . ': ' . $content;
                }
                break;
            default:
                $content = parent::getFieldContent($field, $header);
        }

        return $content;
    }

    protected function getMessageContent(Model_Message_Base $message) {
        $messageContent = null;
        $messageTime = $message->getCreated()->format('H:i:s');
        switch ($message->getKind()) {
            case Model_Message_Base::$KINDS['CONTACTS']:
                $j = $message->getContent();
                $availableFieldNames = getVisitorFieldNames();
                $pieces = array();
                foreach ($j as $fieldName => $value) {
                    if (in_array($fieldName, $availableFieldNames)) {
                        $pieces[] = Resources::Get('visitor_field.'.$fieldName).': '.$value;
                    }
                }
                $messageContent = implode(', ', $pieces);
                break;
            case Model_Message_Base::$KINDS['FILE_OPERATOR']:
                $j = $message->getContent();
                $messageContent = $messageTime . ' [' . Resources::Get('chat.operator_sent_file') . ': ' . $j['filename'] . ' (' . Helper::getServerProtocol() . $_SERVER['HTTP_HOST'] . '/l/o/download/' . $j['guid'] . '/' . $j['filename'] .')' . ']';
                break;
            case Model_Message_Base::$KINDS['FILE_VISITOR']:
                $j = $message->getContent();
                $messageContent = $messageTime . ' [' . Resources::Get('chat.visitor_sent_file') . ': ' . $j['filename'] . ' (' . Helper::getServerProtocol() . $_SERVER['HTTP_HOST'] . '/l/o/download/' . $j['guid'] . '/' . $j['filename'] .')' . ']';
                break;
            case Model_Message_Base::$KINDS['INFO']:
                $messageContent = $messageTime . ' ' . $message->getContent();
                break;
            default:
                $messageContent = $messageTime . ($message->getSenderName() ? ' ' . $message->getSenderName() : '') . ':' . $message->getContent();
        }

        return $messageContent;
    }
}