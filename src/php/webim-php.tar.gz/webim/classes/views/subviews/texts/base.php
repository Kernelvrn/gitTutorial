<?php
abstract class View_SubView_Text_Base extends View_SubView_Base {}