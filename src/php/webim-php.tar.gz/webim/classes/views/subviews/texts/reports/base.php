<?php
abstract class View_SubView_Text_Report_Base extends View_SubView_Text_Base {
    /**
     * @param Report_Base $report
     * @param View_Writer_Text $writer
     */
    public function outputTo(Report_Base $report, $writer) {
        foreach ($report->getRows() as $row) {
            foreach ($report->getHeaders() as $header) {
                $field = current($row);
                if (is_bool($field)) {
                    $a = $field;
                }
                $fieldContent = $this->getFieldContent($field, $header);
                if (!empty($fieldContent)) {
                    $writer->write($fieldContent);
                }
                next($row);
            }

            for ($i = 0; $i < 3; $i++) {
                $writer->write('');
            }
        }
    }

    protected function getFieldContent(Report_Field_Base $field, Report_Field_Base $header) {
        $content = null;
        if ($field->getValue()) {
            switch ($field->getType()) {
                case Report_Field_Base::TYPE_STRING:
                case Report_Field_Base::TYPE_INT:
                case Report_Field_Base::TYPE_EMAIL:
                case Report_Field_Base::TYPE_PHONE:
                    $content = $header->getValue() . ': ' . $field->getValue();
                    break;
                case Report_Field_Base::TYPE_DATE:
                    $content = $header->getValue() . ': ' . $field->getValue()->format(Helper::getDateFormat());
                    break;
                case Report_Field_Base::TYPE_TIME:
                    $content = $header->getValue() . ': ' . $field->getValue()->format(Helper::getTimeFormat());
                    break;
                case Report_Field_Base::TYPE_DATETIME:
                    $content = $header->getValue() . ': ' . $field->getValue()->format(Helper::getDateTimeFormat());
                    break;
                case Report_Field_Base::TYPE_DURATION:
                    $content = $header->getValue() . ': ' . $field->getValue() ? sec2hms($field->getValue()) : null;
                    break;
            }
        }

        return $content;
    }
}