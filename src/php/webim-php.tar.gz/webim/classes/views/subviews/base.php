<?php
abstract class View_SubView_Base {
    public function outputTo($block, $writer) {}
}