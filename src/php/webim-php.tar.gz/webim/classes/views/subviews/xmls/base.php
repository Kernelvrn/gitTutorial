<?php
abstract class View_SubView_Xml_Base extends View_SubView_Base {}