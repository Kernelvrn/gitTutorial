<?php
class View_SubView_Xml_Model_Thread extends View_SubView_Xml_Model_Base {
    /**
     * @param $model Model_Thread
     * @param $key string
     * @param $writer XMLWriter
     */
    public function outputTo($model, $key, $writer) {
        $visitor = $model->getVisitor();
        $category = $model->getCategory();
        $catArr = array(
            'category' => NULL,
            'subcategory' => NULL
        );
        if ($category) {
            /** @var $category Model_Category */
            if ($category->getParent()) {
                $catArr['category'] = $category->getParent()->getTitle();
                $catArr['subcategory'] = $category->getTitle();
            } else {
                $catArr['category'] = $category->getTitle();
            }
        }
        $location = $model->getLocation();
        $messages = array();
        foreach ($model->getMessages() as $message) {
            $messages[] = array(
                'messageid' => $message->getId(),
                'kind' => $message->getKind(),
                'operatorid' => $message->getOperatorId(),
                'message' => $message->getText(),
                'created' => $message->getCreated()->getTimestamp(),
                'sendername' => $message->getSenderName()
            );
        }
        $arr = array(
            'id' => $model->getId(),
            'created' => $model->getCreated()->format(Helper::getDateFormat()),
            'modified' => $model->getModified()->format(Helper::getDateFormat()),
            'duration' => $model->getDuration() ? sec2hms($model->getDuration()) : '',
            'operator' => array(
                'name' => $model->getOperatorOwnerName()
            ),
            'visitor' => array(
                'name' => !empty($visitor) ? $visitor->getName() : NULL,
                'email' => !empty($visitor) ? $visitor->getEmail() : NULL,
                'phone' => !empty($visitor) ? $visitor->getPhone() : NULL,
                'location' => null
            ),
            'remote' => $model->getRemote(),
            'kind' => $model->getKind(),
            'category' => $catArr['category'],
            'subcategory' => $catArr['subcategory'],
            'departments' => implode(',', $model->getDepartmentNames()),
            'city' => $location['city'],
            'country' => $location['country'],
            'messages' => $messages
        );

        $writer->write($arr, $key);
    }
}