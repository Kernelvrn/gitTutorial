<?php
abstract class View_SubView_Xml_Model_Base extends View_SubView_Xml_Base {}