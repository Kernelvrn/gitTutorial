<?php
class View_SubView_Csv_Report_Visitors extends View_SubView_Csv_Report_Base {}