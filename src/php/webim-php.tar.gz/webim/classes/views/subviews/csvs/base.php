<?php
abstract class View_SubView_Csv_Base extends View_SubView_Base {
    public function outputTo($block, $stream) {}
}