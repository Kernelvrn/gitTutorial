<?php
abstract class View_SubView_Csv_Report_Base extends View_SubView_Csv_Base {
    public function outputTo(Report_Base $report, $writer) {
        $headers = array();
        foreach ($report->getHeaders() as $header) {
            $headers[] = $header->getValue();
        }
        if (!empty($headers)) {
            $writer->write($headers);
        }

        foreach ($report->getRows() as $row) {
            $fields = array();
            foreach ($row as $field) {
                $fields[] = $this->getFieldContent($field);
            }
            if (!empty($fields)) {
                $writer->write($fields);
            }
        }
    }

    protected function getFieldContent(Report_Field_Base $field) {
        $content = null;
        if ($field->getValue()) {
            switch ($field->getType()) {
                case Report_Field_Base::TYPE_STRING:
                case Report_Field_Base::TYPE_INT:
                case Report_Field_Base::TYPE_EMAIL:
                case Report_Field_Base::TYPE_PHONE:
                    $content = $field->getValue();
                    break;
                case Report_Field_Base::TYPE_DATE:
                    $content = $field->getValue()->format(Helper::getDateFormat());
                    break;
                case Report_Field_Base::TYPE_TIME:
                    $content = $field->getValue()->format(Helper::getTimeFormat());
                    break;
                case Report_Field_Base::TYPE_DATETIME:
                    $content = $field->getValue()->format(Helper::getDateTimeFormat());
                    break;
                case Report_Field_Base::TYPE_DURATION:
                    $content = $field->getValue() ? sec2hms($field->getValue()) : null;
                    break;
            }
        }

        return $content;
    }
}