<?php
class View_SubView_Excel_Report_Base extends View_SubView_Excel_Base {
    /**
     * @param $report Report_Base
     * @param $writer View_Writer_Excel
     */
    public function outputTo($report, $writer) {
        $writer->addSheet(mb_substr($report->getTitle(), 0, 30, WEBIM_ENCODING)); //Максимальная длина для названия страницы - 31 символ
        $headers = array();
        foreach ($report->getHeaders() as $header) {
            $headers[] = array(
                'type' => 'string',
                'value' => $header->getValue(),
                'background' => 'f9e4b8',
                'align' => $header->getStyle('align')
            );
        }
        $writer->addRow($headers);

        foreach ($report->getRows() as $thread) {
            $writer->addRow(static::reportFieldsToRow($thread));
        }
        if ($report->getTotal()) {
            $writer->addRow(static::reportFieldsToRow($report->getTotal()));
        }
        $writer->autoSizeActiveSheet();
    }

    /**
     * @param Report_Field_Base[] $fields
     * @return array
     */
    protected static function reportFieldsToRow(array $fields) {
        $row = array();
        foreach ($fields as $field) {
            /**
             * @var $field Report_Field_Base
             */
            $type = 'string';
            $value = $field->getValue();
            $explicit = false;
            switch ($field->getType()) {
                case Report_Field_Base::TYPE_PERCENTAGE:
                    $type = 'percent';
                    $value = $field->getValue();
                    break;
                case Report_Field_Base::TYPE_INT:
                    $type = 'int';
                    $value = (int)$field->getValue();
                    break;
                case Report_Field_Base::TYPE_FLOAT:
                    $type = 'float';
                    $value = $field->getValue();
                    break;
                case Report_Field_Base::TYPE_BOOLEAN:
                    $type = 'string';
                    $value = $field->getValue() ? 'Y' : '';
                    break;
                case Report_Field_Base::TYPE_CATEGORY:
                    $type = 'string';
                    /** @var Model_Category $category */
                    $category = $field->getValue();
                    if ($category) {
                        $value = $category->getParent()
                            ? $category->getParent()->getTitle() . '->' . $category->getTitle()
                            : $category->getTitle();
                    } else {
                        $value = Resources::Get('report.bycategories.without_category');
                    }
                    break;
                case Report_Field_Base::TYPE_DEPARTMENT:
                    $type = 'string';
                    /** @var Model_Department $department */
                    $department = $field->getValue();
                    if ($department) {
                        $value = $department->getNameByLocale(Resources::getCurrentLocale());
                    } else {
                        $value = Resources::Get('report.bydepartments.without_department');
                    }
                    break;
                case Report_Field_Base::TYPE_OFFICE:
                    $type = 'string';
                    /** @var Model_Office $office */
                    $office = $field->getValue();
                    if ($office) {
                        $value = $office->getName();
                    } else {
                        $value = Resources::Get('report.byoffice.without_office');
                    }
                    break;
                case Report_Field_Base::TYPE_OPERATOR:
                    $type = 'string';
                    /** @var Model_Operator $operator */
                    $operator = $field->getValue();
                    $value = '-';
                    if ($operator) {
                        $value = $operator->getFullName();
                    }
                    break;
                case Report_Field_Base::TYPE_DATE:
                    $type = 'date';
                    break;
                case Report_Field_Base::TYPE_TIME:
                    $type = 'time';
                    break;
                case Report_Field_Base::TYPE_DATETIME:
                    $type = 'datetime';
                    break;
                case Report_Field_Base::TYPE_DURATION:
                    $type = 'seconds';
                    break;
                case Report_Field_Base::TYPE_PHONE:
                    $value = htmlspecialchars($value);
                    $explicit = true;
                    break;
                case Report_Field_Base::TYPE_START_MESSAGES:
                    $messageStr = '';
                    foreach ($value as $message) {
                        /** @var $message Model_Message_Base */
                        $messageStr .= $message->getText() . PHP_EOL;
                    }

                    $value = mb_substr($messageStr, 0, min(2800, strlen($messageStr)), WEBIM_ENCODING);
                    break;
                case Report_Field_Base::TYPE_HOUR_INTERVAL:
                    $value = sprintf('%02d - %02d', $value, $value + 1);
                    break;
                default:
                    $value = htmlspecialchars($value);
		            $explicit = true;
            }
            $row[] = array(
                'type' => $type,
                'value' => $value,
                'explicit' => !empty($explicit) ? true : false,
                'align' => $field->getStyle('align'),
                'link' => array(
                    'type' => $field->getLinkParam('type'),
                    'url' => $field->getLinkParam('url'),
                    'onclick' => $field->getLinkParam('onclick')
                )
            );
        }

        return $row;
    }
}