<?php

/**
 * Class View_Writer_Json
 * Позволяет с некоторыми неудобствами выводить в JSON объекты с константным занятием памяти.
 */
class View_Writer_Json {
    protected $stream = null;

    public function __construct($streamName) {
        $this->stream = fopen($streamName, 'wb');
    }

    public function writeSeparator() {
        fwrite($this->stream, ',');
    }

    public function writeValue($data) {
        fwrite($this->stream, json_encode($data));
    }

    public function writeObjectFieldKey($key) {
        fwrite($this->stream, json_encode((string)$key) . ':');
    }

    public function startObject() {
        fwrite($this->stream, '{');
    }

    public function endObject() {
        fwrite($this->stream, '}');
    }

    public function startArray() {
        fwrite($this->stream, '[');
    }

    public function endArray() {
        fwrite($this->stream, ']');
    }

    public function __destruct() {
        fclose($this->stream);
    }
}