<?php
class View_Writer_Csv {
    protected $stream = null;

    public function __construct($streamName, array $params = array()) {
        $this->stream = fopen($streamName, 'wb');

        if (!empty($params['encoding']) && $params['encoding'] !== WEBIM_ENCODING) {
            stream_filter_register(StreamFilter_ConvertMbstringEncoding::getFilterName(), 'StreamFilter_ConvertMbstringEncoding');
            stream_filter_append($this->stream, StreamFilter_ConvertMbstringEncoding::FILTER_NAMESPACE . WEBIM_ENCODING . ':' . $params['encoding']);
        }

        fwrite($this->stream, chr(255) . chr(254));
    }

    public function write($data) {
        switch (gettype($data)) {
            case 'string':
            case 'int':
            case 'double':
                fputcsv($this->stream, array($data));
                break;
            case 'boolean':
                fputcsv($this->stream, array(($data ? 'TRUE' : 'FALSE')));
                break;
            case 'array':
                fputcsv($this->stream, $data);
        }
    }

    public function __destruct() {
        fclose($this->stream);
    }
}