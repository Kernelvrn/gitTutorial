<?php
class View_Writer_Raw {
    protected $stream = null;

    public function __construct($streamName) {
        $this->stream = fopen($streamName, 'wb');
    }

    public function write($data) {
        fwrite($this->stream, $data);
    }

    public function __destruct() {
        fclose($this->stream);
    }
}