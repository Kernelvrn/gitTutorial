<?php
class View_Writer_Text {
    protected $stream = null;

    public function __construct($streamName) {
        $this->stream = fopen($streamName, 'wb');
    }

    public function write($data) {
        switch (gettype($data)) {
            case 'string':
            case 'int':
            case 'double':
                fwrite($this->stream, $data . "\r\n");
                break;
            case 'boolean':
                fwrite($this->stream, ($data ? 'TRUE' : 'FALSE') . PHP_EOL);
                break;
        }
    }

    public function __destruct() {
        fclose($this->stream);
    }
}