<?php
class View_Writer_Xml {
    protected $xmlWriter = null;

    public function __construct($streamName) {
        $this->xmlWriter = new XMLWriter();
        $this->xmlWriter->openUri($streamName);
    }

    public function start($params) {
        $this->xmlWriter->startDocument($params['version'], $params['encoding']);
    }

    public function end() {
        $this->xmlWriter->endDocument();
    }

    public function write($data, $key) {
        if (is_numeric($key)) {
            $key = 'key'.$key;
        }
        if (is_array($data) || is_object($data) && in_array('Traversable', class_implements($data))) {
            $this->xmlWriter->startElement($key);
            foreach ($data as $subKey => $block) {
                $this->write($block, $subKey);
            }
            $this->xmlWriter->endElement();
        } else {
            $this->xmlWriter->writeElement($key, $data);
        }
    }

    public function startElement($key) {
        $this->xmlWriter->startElement($key);
    }

    public function endElement() {
        $this->xmlWriter->endElement();
    }
}