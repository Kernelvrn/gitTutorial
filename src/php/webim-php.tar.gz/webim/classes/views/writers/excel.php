<?php
require_once(dirname(__FILE__) . '/../../../../vendor/autoload.php');

class View_Writer_Excel {
    protected $phpExcel = null;
    protected $currentRow = 1;
    protected $streamName = null;

    protected $headerCellTemplate = array(
        'background' => 'f9e4b8'
    );

    protected $sheetDataTemplate = array(
        'params' => array(
            'titleKey' => 'excel.default.sheet.title'
        ),
        'tables' => array()
    );

    protected $tableDataTemplate = array(
        'params' => array(),
        'headers' => array(),
        'data' => array(),
        'total' => array(),
    );

    public function __construct($streamName, $params) {
        $cacheMethod = PHPExcel_CachedObjectStorageFactory::cache_to_phpTemp;
        $cacheSettings = array(
            'memoryCacheSize' => '8MB'
        );
        PHPExcel_Settings::setCacheStorageMethod($cacheMethod, $cacheSettings);
        PHPExcel_Settings::setLocale(Resources::getCurrentLocale());

        $this->streamName = $streamName;
        $this->phpExcel = new PHPExcel();
        foreach ($params['meta'] as $metaName => $metaValue) {
            $metaMethod = 'set' . ucfirst($metaName);
            $this->phpExcel->getProperties()->$metaMethod($metaValue);
        }

        $this->phpExcel->removeSheetByIndex(0); //Remove unnecessary default sheet
    }

    public function write() {
        $objWriter = new PHPExcel_Writer_Excel2007($this->phpExcel);
        $objWriter->setOffice2003Compatibility(true);
        $objWriter->save($this->streamName);
    }

    public function addWorkSheetAndTables(array $sheetData) {
        $sheetData = array_replace_recursive($this->sheetDataTemplate, $sheetData);
        $workSheet = new PHPExcel_Worksheet($this->phpExcel, Resources::Get($sheetData['params']['titleKey']));
        $this->phpExcel->addSheet($workSheet);
        foreach ($sheetData['tables'] as $tableData) {
            $this->addTableToWorkSheet($tableData, $workSheet);
        }
    }

    public function addSheet($sheetName) {
        $this->phpExcel->addSheet(new PHPExcel_Worksheet($this->phpExcel, $sheetName));
        $this->phpExcel->setActiveSheetIndex($this->phpExcel->getSheetCount() - 1);
        $this->currentRow = 1;
    }

    public function autoSizeActiveSheet() {
        $cellIterator = $this->phpExcel->getActiveSheet()->getRowIterator()->current()->getCellIterator();
        $cellIterator->setIterateOnlyExistingCells(true);
        /** @var PHPExcel_Cell $cell */
        foreach ($cellIterator as $cell) {
            $this->phpExcel->getActiveSheet()->getColumnDimension($cell->getColumn())->setAutoSize(true);
        }
    }


    public function addRow($row = array()) {
        $columnIndex = 0;
        foreach ($row as $cellConfig) {
            $this->addCell($cellConfig, $this->currentRow, $columnIndex++);
        }
        $this->currentRow++;
    }

    protected function addCell($cellConfig, $rowIndex, $columnIndex) {
        $sheet = $this->phpExcel->getActiveSheet();
        $value = '';

        switch ($cellConfig['type']) {
            case 'int':
                $value = sprintf('%d', $cellConfig['value']);
                break;
            case 'percent':
                $sheet->getStyleByColumnAndRow($columnIndex, $rowIndex)->getNumberFormat()->setFormatCode(PHPExcel_Style_NumberFormat::FORMAT_PERCENTAGE_00);
                $value = $cellConfig['value'];
                break;
            case 'date':
                $sheet->getStyleByColumnAndRow($columnIndex, $rowIndex)->getNumberFormat()->setFormatCode(PHPExcel_Style_NumberFormat::FORMAT_DATE_DDMMYYYY);
                if (!empty($cellConfig['value'])) {
                    $value = PHPExcel_Shared_Date::PHPToExcel($cellConfig['value']);
                }
                break;
            case 'datetime':
                $sheet->getStyleByColumnAndRow($columnIndex, $rowIndex)->getNumberFormat()->setFormatCode(PHPExcel_Style_NumberFormat::FORMAT_DATE_DDMMYYYY . ' ' . PHPExcel_Style_NumberFormat::FORMAT_DATE_TIME4);
                if (!empty($cellConfig['value'])) {
                    $value = PHPExcel_Shared_Date::PHPToExcel($cellConfig['value']);
                }
                break;
            case 'time':
                $sheet->getStyleByColumnAndRow($columnIndex, $rowIndex)->getNumberFormat()->setFormatCode(PHPExcel_Style_NumberFormat::FORMAT_DATE_TIME4);
                if (!empty($cellConfig['value'])) {
                    $value = PHPExcel_Shared_Date::PHPToExcel($cellConfig['value']);
                }
                break;
            case 'hour_range':
                $value = sprintf('%02d - %02d', $cellConfig['value'], $cellConfig['value'] + 1);
                break;
            case 'operator':
            case 'department':
            case 'office':
                $value = $cellConfig['value']['name'];
                break;
            case 'seconds':
                $sheet->getStyleByColumnAndRow($columnIndex, $rowIndex)->getNumberFormat()->setFormatCode('[hh]:mm:ss');
                $hours = floor($cellConfig['value'] / 3600);
                $minutes = floor(($cellConfig['value'] - $hours * 60 * 60) / 60);
                $seconds = $cellConfig['value'] % 60;
                $value = $hours / 24 + $minutes / (24 * 60) + $seconds / (24 * 60 * 60);
                break;
            default:
                $value = $cellConfig['value'];
        }

        if (!empty($cellConfig['indent'])) {
            $value = '        ' . $value;
        }

        if (!empty($cellConfig['link']) && !empty($cellConfig['link']['url'])) {
            $url = $cellConfig['link']['type'] == 'email' ? 'mailto:' . $cellConfig['link']['url'] : $cellConfig['link']['url'];
            $sheet->getCellByColumnAndRow($columnIndex, $rowIndex)->getHyperlink()->setUrl(strip_tags($url));
        }

        if (empty($cellConfig['explicit'])) {
            $sheet->setCellValueByColumnAndRow($columnIndex, $rowIndex, $value);
        } else {
            $sheet->getStyleByColumnAndRow($columnIndex, $rowIndex)->getNumberFormat()->setFormatCode(PHPExcel_Style_NumberFormat::FORMAT_TEXT);
            $explicit = PHPExcel_Cell_DataType::TYPE_STRING;
            $sheet->getCellByColumnAndRow($columnIndex, $rowIndex)->setValueExplicit($value, $explicit);
        }

        if (!empty($cellConfig['background'])) {
            $sheet->getStyleByColumnAndRow($columnIndex, $rowIndex)->getFill()->applyFromArray(array(
                'type' => PHPExcel_Style_Fill::FILL_SOLID,
                'color' => array('rgb' => $cellConfig['background'])
            ));
        }
    }

    protected function addTableToWorkSheet(array $tableData, PHPExcel_Worksheet $workSheet) {
        $tableData = array_replace_recursive($this->tableDataTemplate, $tableData);
        if (!empty($tableData['params']['titleKey'])) {
            $titleRow = $workSheet->getHighestRow() > 1 ? $workSheet->getHighestRow() + 2 : 1;
            $workSheet->setCellValueByColumnAndRow(0, $titleRow, Resources::Get($tableData['params']['titleKey']));
            $workSheet->mergeCellsByColumnAndRow(0, $titleRow, 10, $titleRow);
        }

        if (!empty($tableData['headers'])) {
            $headerRowIndex = $workSheet->getHighestRow() + 2;
            $headerColumnIndex = 0;
            foreach ($tableData['columnOrder'] as $columnName) {
                $headerCell = $tableData['headers'][$columnName];
                $headerCell = array_merge_recursive($this->headerCellTemplate, $headerCell);
                $this->addCellToWorkSheet($headerColumnIndex++, $headerRowIndex, $headerCell, $workSheet);
            }
        }

        foreach ($tableData['data'] as $row) {
            $rowIndex = $workSheet->getHighestRow() + 1;
            if (!empty($row['_divider'])) {
                $this->addCellToWorkSheet(0, $rowIndex, $row['_divider'], $workSheet);
                $workSheet->mergeCellsByColumnAndRow(0, $rowIndex, count($tableData['columnOrder']) - 1, $rowIndex);
                $workSheet->getStyleByColumnAndRow(0, $rowIndex)->getAlignment()->setHorizontal(PHPExcel_Style_Alignment::HORIZONTAL_CENTER);
            } else {
                $columnIndex = 0;
                foreach ($tableData['columnOrder'] as $columnName) {
                    $cellConfig = $row[$columnName];
                    $this->addCellToWorkSheet($columnIndex++, $rowIndex, $cellConfig, $workSheet);
                }
            }
        }

        if (!empty($tableData['total']) && !empty($tableData['data'])) {
            $totalRowIndex = $workSheet->getHighestRow() + 1;
            $totalColumnIndex = 0;
            foreach ($tableData['columnOrder'] as $columnName) {
                $totalCell = $tableData['total'][$columnName];
                if ($totalColumnIndex == 0) {
                    $totalCell['resourceKey'] = 'report.bydate.total';
                }
                $this->addCellToWorkSheet($totalColumnIndex++, $totalRowIndex, $totalCell, $workSheet);
            }
        }
    }

    protected function addCellToWorkSheet($columnIndex, $rowIndex, array $cellConfig, PHPExcel_Worksheet $workSheet) {
        $value = '';
        $explicit = FALSE;
        if (!empty($cellConfig['resourceKey'])) {
            $value = Resources::Get($cellConfig['resourceKey']);
        } else {
            switch ($cellConfig['type']) {
                case 'int':
                    $value = sprintf('%d',$cellConfig['value']);
                    break;
                case 'percent':
                    $workSheet->getStyleByColumnAndRow($columnIndex, $rowIndex)->getNumberFormat()->setFormatCode(PHPExcel_Style_NumberFormat::FORMAT_PERCENTAGE_00);
                    $value = $cellConfig['value'];
                    break;
                case 'date':
                    $workSheet->getStyleByColumnAndRow($columnIndex, $rowIndex)->getNumberFormat()->setFormatCode(PHPExcel_Style_NumberFormat::FORMAT_DATE_DDMMYYYY);
                    $value = PHPExcel_Shared_Date::PHPToExcel($cellConfig['value']);
                    break;
                case 'hour_range':
                    $value = sprintf('%02d - %02d', $cellConfig['value'], $cellConfig['value'] + 1);
                    break;
                case 'operator':
                case 'department':
                case 'office':
                    $value = $cellConfig['value']['name'];
                    break;
                case 'seconds':
                    $workSheet->getStyleByColumnAndRow($columnIndex, $rowIndex)->getNumberFormat()->setFormatCode('[hh]:mm:ss');
                    $hours = floor($cellConfig['value'] / 3600);
                    $minutes = floor(($cellConfig['value'] - $hours * 60 * 60) / 60);
                    $seconds = $cellConfig['value'] % 60;
                    $value = $hours / 24 + $minutes / (24 * 60) + $seconds / (24 * 60 * 60);
                    break;
                case 'explicit_text':
                    $workSheet->getStyleByColumnAndRow($columnIndex, $rowIndex)->getNumberFormat()->setFormatCode(PHPExcel_Style_NumberFormat::FORMAT_TEXT);
                    $value = $cellConfig['value'];
                    $explicit = PHPExcel_Cell_DataType::TYPE_STRING;
                    break;
                default:
                    $value = $cellConfig['value'];
            }
        }

        if (!empty($cellConfig['indent'])) {
            $value = '        ' . $value;
        }

        if (!empty($cellConfig['link']) && !empty($cellConfig['link']['url'])) {
            $workSheet->getCellByColumnAndRow($columnIndex, $rowIndex)->getHyperlink()->setUrl(strip_tags($cellConfig['link']['url']));
        }

        if (!$explicit) {
            $workSheet->setCellValueByColumnAndRow($columnIndex, $rowIndex, $value);
        } else {
            $workSheet->getCellByColumnAndRow($columnIndex, $rowIndex)->setValueExplicit($value, $explicit);
        }

        if (!empty($cellConfig['background'])) {
            $workSheet->getStyleByColumnAndRow($columnIndex, $rowIndex)->getFill()->applyFromArray(array(
                'type' => PHPExcel_Style_Fill::FILL_SOLID,
                'color' => array('rgb' => $cellConfig['background'])
            ));
        }
    }
}