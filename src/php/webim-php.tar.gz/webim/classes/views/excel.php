<?php
class View_Excel extends View_Base {
    public function __construct(array $params) {
        $this->defaultParams = array(
            'output_filename' => 'excel.xlsx',
            'meta' => array(
                'creator' => Resources::Get('service.name'),
                'lastModifiedBy' => Resources::Get('service.name'),
                'title' => Resources::Get('excel.default.title')
            )
        );

        parent::__construct($params);
    }

    protected function createWriter($streamName) {
        return new View_Writer_Excel($streamName, $this->params);
    }

    /**
     * @param $data
     * @param $writer View_Writer_Excel
     */
    protected function outputTo($data, $writer) {
        if (is_array($data) || is_object($data) && in_array('Traversable', class_implements($data))) {
            foreach ($data as $sheet) {
                if (is_array($sheet)) {
                    $writer->addWorkSheetAndTables($sheet);
                } elseif (is_object($sheet)) {
                    $this->outputObject($sheet, $writer);
                }
            }
        } elseif (is_object($data)) {
            $this->outputObject($data, $writer);
        }

        $writer->write();
    }

    protected function getHeaders($data) {
        return array(
            'Content-type: application/vnd.ms-excel',
            'Content-disposition: attachment;filename=' . $this->params['output_filename']
        );
    }
}