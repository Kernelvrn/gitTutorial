<?php

class View_Image extends View_Base {
    protected $defaultParams = array(
        'mime-type' => ''
    );

    protected function outputTo($data, $writer) {
        $writer->write(!empty($data['filename']) && file_exists($data['filename']) ? file_get_contents($data['filename']) : null);
    }

    protected function getHeaders($data) {
        return array(
            'Content-Type: ' . !empty($this->params['mime-type']) ? $this->params['mime-type'] : 'image/png'
        );
    }
}
