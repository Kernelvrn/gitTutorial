<?php
/**
 * Created by JetBrains PhpStorm.
 * User: oleg
 * Date: 12/23/11
 * Time: 12:44 PM
 * To change this template use File | Settings | File Templates.
 */

class RareRunner {
  private function _getDirName($key) {
    create_dir(ONLINE_FILES_DIR);
    $dir = ONLINE_FILES_DIR . '/rare-runner-' . $key;
    return $dir;
  }


  public static function run($key, $periodInSeconds, $f) {
    $fileName = self::_getDirName($key) . '/' . $key;
    $t = get_modified_time($fileName);
    if (time() - $t < $periodInSeconds) {
      return false;
    }
    $f($key);
    touch($fileName);
    return true;
  }
}