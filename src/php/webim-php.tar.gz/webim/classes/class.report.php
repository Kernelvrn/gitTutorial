<?php
/**
 * Created by JetBrains PhpStorm.
 * User: versus
 * Date: 05.03.14
 * Time: 14:17
 * For various reports (statistics general)
 */


//use StatsMapper;

require_once('/usr/share/php/phpQuery/phpQuery/phpQuery.php');
require_once(__DIR__ . '/../autoload.php');

class Report {
    static protected $reportTemplate = array(
        'headers' => array(),
        'data' => array(),
        'total' => array(),
        'params' => array(
            'size' => 'default'
        ),
        'filters' => array(
            'date_range' => array('start' => NULL, 'end' => NULL),
            'department' => NULL,
            'locale' => NULL
        )
    );

    static private $baseFieldConfigs = array(
        'category' => array(
            'category' => array(
                'header' => array('resourceKey' => 'report.bycategories.category'),
                'type' => 'string',
                'src' => 'category'
            ),
            'subcategory' => array(
                'header' => array('resourceKey' => 'report.bycategories.subcategory'),
                'type' => 'string',
                'src' => 'subcategory',
            ),
            'requestCount' => array(
                'header' => array('resourceKey' => 'report.bycategories.requests'),
                'type' => 'int',
                'src' => 'category_cnt',
                'total_type' => 'sum'
            ),
            'percentage' => array(
                'header' => array('resourceKey' => 'report.bycategories.percentage'),
                'type' => 'percent'
            )
        ),
        'startpage' => array(
            'startpage' => array(
                'header' => array('resourceKey' => 'report.bystartpage.startpage'),
                'type' => 'string',
                'src' => 'startpage'
            ),
            'requestCount' => array(
                'header' => array('resourceKey' => 'report.bycategories.requests'),
                'type' => 'int',
                'src' => 'startpage_cnt',
                'total_type' => 'sum'
            ),
            'percentage' => array(
                'header' => array('resourceKey' => 'report.bycategories.percentage'),
                'type' => 'percent'
            )
        ),
        'department' => array(
            'department' => array(
                'header' => array('resourceKey' => 'report.bydepartments.department'),
                'type' => 'department',
                'src' => array(
                    'name' => 'departmentname',
                    'id' => 'departmentid'
                )
            ),
            'requestCount' => array(
                'header' => array('resourceKey' => 'report.bydepartments.requests'),
                'type' => 'int',
                'src' => 'department_cnt'
            ),
            'closedCount' => array(
                'header' => array('resourceKey' => 'report.bydepartments.closed_requests'),
                'type' => 'int',
                'src' => 'department_closed',
                'total_type' => 'sum'
            ),
            'avgCommonQueueWaitingTime' => array(
                'header' => array('resourceKey' => 'report.bydepartments.operator_avg_common_queue_waiting_time'),
                'type' => 'seconds',
                'src' => 'operator_avg_common_queue_waiting_time',
                'src_type' => 'avg',
                'total_type' => 'avg'
            )
        ),
        'office' => array(
            'office' => array(
                'header' => array('resourceKey' => 'report.byoffices.office'),
                'type' => 'office',
                'src' => array(
                    'name' => 'officename',
                    'id' => 'officeid'
                )
            ),
            'requestCount' => array(
                'header' => array('resourceKey' => 'report.bydepartments.requests'),
                'type' => 'int',
                'src' => 'office_cnt',
                'total_type' => 'sum'
            ),
            'closedCount' => array(
                'header' => array('resourceKey' => 'report.bydepartments.closed_requests'),
                'type' => 'int',
                'src' => 'office_closed',
                'total_type' => 'sum'
            )
        ),
        'geo' => array(
            'country' => array(
                'header' => array('resourceKey' => 'report.bygeo.country'),
                'type' => 'string',
                'src' => 'country'
            ),
            'region' => array(
                'header' => array('resourceKey' => 'report.bygeo.region'),
                'type' => 'string',
                'src' => 'region'
            ),
            'city' => array(
                'header' => array('resourceKey' => 'report.bygeo.city'),
                'type' => 'string',
                'src' => 'city'
            ),
            'requestCount' => array(
                'header' => array('resourceKey' => 'report.bygeo.requests'),
                'type' => 'int',
                'src' => 'geo_cnt',
                'total_type' => 'sum'
            ),
            'percentage' => array(
                'header' => array('resourceKey' => 'report.bygeo.percentage'),
                'type' => 'percent'
            )
        ),
        'dateOrHour' => array(
            'requestCount' => array(
                'header' => array('resourceKey' => 'report.bydate.2tries'),
                'type' => 'int',
                'src' => 'threads',
                'total_type' => 'sum'
            ),
            'newRequestCount' => array(
                'header' => array('resourceKey' => 'report.bydate.new_threads'),
                'type' => 'int',
                'src' => 'new_threads',
                'total_type' => 'sum'
            ),
            'operatorMessageCount' => array(
                'header' => array('resourceKey' => 'report.bydate.3'),
                'type' => 'int',
                'src' => 'operator_messages',
                'total_type' => 'sum'
            ),
            'visitorMessageCount' => array(
                'header' => array('resourceKey' => 'report.bydate.4'),
                'type' => 'int',
                'src' => 'visitor_messages',
                'total_type' => 'sum'
            ),
            'avgWaitingTime' => array(
                'header' => array('resourceKey' => 'report.bydate.5'),
                'type' => 'seconds',
                'src' => 'avg_answer_time_online_queue',
                'src_type' => 'avg',
                'total_type' => 'avg'
            ),
            'avgOperatorQueueOnline' => array(
                'header' => array('resourceKey' => 'report.byoperator.operator_avg_queue_waiting_time_offline'),
                'type' => 'seconds',
                'src' => 'operator_avg_queue_waiting_time_online',
                'src_type' => 'avg',
                'total_type' => 'avg'
            ),
            'avgMissedTime' => array(
                'header' => array('resourceKey' => 'report.lostvisitors.3'),
                'type' => 'seconds',
                'src' => 'avg_missed_time',
                'src_type' => 'avg',
                'total_type' => 'avg'
            ),
            'avgMessageAnswerTime' => array(
                'header' => array('resourceKey' => 'report.bydate.avg_message_answer_time'),
                'type' => 'seconds',
                'src' => 'avg_message_answer_time',
                'src_type' => 'avg',
                'total_type' => 'avg'
            ),
            'chatCount' => array(
                'header' => array('resourceKey' => 'report.bydate.45'),
                'type' => 'int',
                'src' => 'chats',
                'total_type' => 'sum'
            ),
            'quickAnsweredCount' => array(
                'header' => array('resourceKey' => 'report.bydate.quick_answered'),
                'type' => 'int',
                'src' => 'quick_answered',
                'total_type' => 'sum'
            ),
            'answeredIn10SecondsPercent' => array(
                'header' => array('resourceKey' => 'report.bydate.answered_in_10_seconds'),
                'type' => 'percent',
                'src' => 'answered_in_10_sec',
                'percent_base' => 'answered_in_base',
                'total_type' => 'avg'
            ),
            'answeredIn20SecondsPercent' => array(
                'header' => array('resourceKey' => 'report.bydate.answered_in_20_seconds'),
                'type' => 'percent',
                'src' => 'answered_in_20_sec',
                'percent_base' => 'answered_in_base',
                'total_type' => 'avg'
            ),
            'answeredIn30SecondsPercent' => array(
                'header' => array('resourceKey' => 'report.bydate.answered_in_30_seconds'),
                'type' => 'percent',
                'src' => 'answered_in_30_sec',
                'percent_base' => 'answered_in_base',
                'total_type' => 'avg'
            ),
            'answeredIn40SecondsPercent' => array(
                'header' => array('resourceKey' => 'report.bydate.answered_in_40_seconds'),
                'type' => 'percent',
                'src' => 'answered_in_40_sec',
                'percent_base' => 'answered_in_base',
                'total_type' => 'avg'
            ),
            'missedCount' => array(
                'header' => array('resourceKey' => 'report.bydate.6'),
                'type' => 'int',
                'src' => 'missed',
                'total_type' => 'sum'
            ),
            'bounceRate' => array(
                'header' => array('resourceKey' => 'report.bydate.bounce_rate'),
                'type' => 'int',
                'src' => 'bounce_rate',
                'total_type' => 'sum'
            ),
            'rejectedInvitationCount' => array(
                'header' => array('resourceKey' => 'report.bydate.rejected_invitation'),
                'type' => 'int',
                'src' => 'rejected_invitation',
                'total_type' => 'sum'
            ),
            'operatorPeak' => array(
                'header' => array('resourceKey' => 'report.bydate.operator_peak'),
                'type' => 'int',
                'src' => 'operator_peak',
                'total_type' => 'max'
            ),
        ),
        'dateOrHourOffline' => array(
            'newOfflineQueueCount' => array(
                'header' => array('resourceKey' => 'report.bydate.new_offlines_queue'),
                'type' => 'int',
                'src' => 'new_offlines_queue',
                'total_type' => 'sum'
            ),
            'newOfflineOperatorCount' => array(
                 'header' => array('resourceKey' => 'report.bydate.new_offlines_operator'),
                 'type' => 'int',
                 'src' => 'new_offlines_operator',
                'total_type' => 'sum'
            ),
            'closedOfflineCount' => array(
                'header' => array('resourceKey' => 'report.bydate.closed_offline'),
                'type' => 'int',
                'src' => 'closed_offlines',
                'total_type' => 'sum'
            ),
            'operatorMessageCount' => array(
                'header' => array('resourceKey' => 'report.bydate.3'),
                'type' => 'int',
                'src' => 'operator_messages',
                'total_type' => 'sum'
            ),
            'avgWaitingTime' => array(
                'header' => array('resourceKey' => 'report.bydate.offline_queue_wating'),
                'type' => 'seconds',
                'src' => 'avg_answer_time_offline_queue',
                'src_type' => 'avg',
                'total_type' => 'avg'
            ),
            'avgOperatorQueueOffline' => array(
                'header' => array('resourceKey' => 'report.byoperator.operator_avg_queue_waiting_time_offline'),
                'type' => 'seconds',
                'src' => 'operator_avg_queue_waiting_time_offline',
                'src_type' => 'avg',
                'total_type' => 'avg'
            ),
            'avgVisitorGotAnswerTimeOffline' => array(
                'header' => array('resourceKey' => 'report.visitor_got_answer_time_offline'),
                'type' => 'seconds',
                'src' => 'visitor_got_answer_time_offline',
                'src_type' => 'avg',
                'total_type' => 'avg'
            ),
            'operatorPeak' => array(
                'header' => array('resourceKey' => 'report.bydate.operator_peak'),
                'type' => 'int',
                'src' => 'operator_peak',
                'total_type' => 'max'
            ),
        ),
        'operator' => array(
            'operator' => array(
                'header' => array('resourceKey' => 'report.byoperator.1'),
                'type' => 'operator',
                'src' => array(
                    'name' => 'fullname',
                    'id' => 'operatorid',
                    'email' => 'email',
                    'deleted' => 'deleted'
                )
            ),
            'chatCount' => array(
                'header' => array('resourceKey' => 'report.byoperator.2'),
                'type' => 'int',
                'src' => 'closed_onlines',
//                'total_type' => 'sum'
            ),
            'quickAnsweredCount' => array(
                'header' => array('resourceKey' => 'report.byoperator.quick_answered'),
                'type' => 'int',
                'src' => 'quick_answered',
//                'total_type' => 'sum'
            ),
	        'newOfflineOperatorCount' => array(
                'header' => array('resourceKey' => 'report.bydate.new_offlines_operator'),
                'type' => 'int',
                'src' => 'new_offlines_operator',
                'total_type' => 'sum'
            ),
	        'closedOfflineCount' => array(
                'header' => array('resourceKey' => 'report.bydate.closed_offline'),
                'type' => 'int',
                'src' => 'closed_offlines',
                'total_type' => 'sum'
            ),
            'operatorMessageCount' => array(
                'header' => array('resourceKey' => 'report.byoperator.3'),
                'type' => 'int',
                'src' => 'operator_messages',
                'total_type' => 'sum'
            ),
            'avgMessageLength' => array(
                'header' => array('resourceKey' => 'report.byoperator.4'),
                'type' => 'float',
                'src' => 'operator_avglen',
                'src_type' => 'avg',
                'total_type' => 'avg'
            ),
            'avgOperatorRate' => array(
                'header' => array('resourceKey' => 'report.byoperator.5'),
                'type' => 'operator_rate',
                'src' => array(
                    'rate' => 'avg_rate_sum',
                    'count' => 'cnt_rate',
                    'rate1' => 'rate1_cnt',
                    'rate2' => 'rate2_cnt',
                    'rate3' => 'rate3_cnt',
                    'rate4' => 'rate4_cnt',
                ),
                'total_type' => 'avg_rate'
            ),
            'avgOperatorQueueOnline' => array(
                'header' => array('resourceKey' => 'report.byoperator.operator_avg_queue_waiting_time_offline'),
                'type' => 'seconds',
                'src' => 'operator_avg_queue_waiting_time_online',
                'src_type' => 'avg',
                'total_type' => 'avg'
            ),
            'invitedVisitorCount' => array(
                'header' => array('resourceKey' => 'report.byoperator.11'),
                'type' => 'int',
                'src' => 'invited_users1',
                'total_type' => 'sum'
            ),
            'rejectedInvitationCount' => array(
                'header' => array('resourceKey' => 'report.bydate.rejected_invitation'),
                'type' => 'int',
                'src' => 'rejected_invitation',
                'total_type' => 'sum'
            ),
            'transferredToAnotherDepartmentCount' => array(
                'header' => array('resourceKey' => 'report.byoperator.15'),
                'type' => 'int',
                'src' => 'transfered_to_another_department',
                'total_type' => 'sum'
            ),
            'transferredFromAnotherDepartmentCount' => array(
                'header' => array('resourceKey' => 'report.byoperator.16'),
                'type' => 'int',
                'src' => 'transfered_from_another_department',
                'total_type' => 'sum'
            ),
            'busyMessageCount' => array(
                'header' => array('resourceKey' => 'report.byoperator.13'),
                'type' => 'int',
                'src' => 'agentbusy',
                'total_type' => 'sum'
            )
        ),
        'operatorLostVisitor' => array(
            'operator' => array(
                'header' => array('resourceKey' => 'report.byoperator.1'),
                'type' => 'operator',
                'src' => array(
                    'name' => 'fullname',
                    'id' => 'operatorid',
                    'email' => 'email',
                    'deleted' => 'deleted'
                )
            ),
            'missedCount' => array(
                'header' => array('resourceKey' => 'report.byoperator.12'),
                'type' => 'int',
                'src' => 'operator_missed',
                'total_type' => 'sum'
            ),
            'avgMissedTime' => array(
                'header' => array('resourceKey' => 'report.lostvisitors.3'),
                'type' => 'seconds',
                'src' => 'operator_avg_missed_time',
                'src_type' => 'avg',
                'total_type' => 'avg'
            )
        ),
        'operatorInterceptVisitor' => array(
            'operator' => array(
                'header' => array('resourceKey' => 'report.byoperator.1'),
                'type' => 'operator',
                'src' => array(
                    'name' => 'fullname',
                    'id' => 'operatorid',
                    'email' => 'email',
                    'deleted' => 'deleted'
                )
            ),
            'interceptedCount' => array(
                'header' => array('resourceKey' => 'report.interceptedvisitors.2'),
                'type' => 'int',
                'src' => 'intercepted',
                'total_type' => 'sum'
            ),
            'avgInterceptedTime' => array(
                'header' => array('resourceKey' => 'report.interceptedvisitors.3'),
                'type' => 'seconds',
                'src' => 'avg_intercepted_time',
                'src_type' => 'avg',
                'total_type' => 'sum'
            )
        ),
        'operatorsTime' => array(
            'operator' => array(
                'header' => array('resourceKey' => 'report.byoperator.1'),
                'type' => 'operator',
                'src' => array(
                    'name' => 'fullname',
                    'id' => 'operatorid',
                    'email' => 'email',
                    'deleted' => 'deleted'
                )
            ),
            'onlineTime' => array(
                'header' => array('resourceKey' => 'report.byoperator.6'),
                'type' => 'seconds',
                'src' => 'online_time',
                'total_type' => 'sum'
            ),
            'chattingTime' => array(
                'header' => array('resourceKey' => 'report.byoperator.7'),
                'type' => 'seconds',
                'src' => 'chatting_time',
                'total_type' => 'sum'
            ),
            'summaryChattingTime' => array(
                'header' => array('resourceKey' => 'report.byoperator.8'),
                'type' => 'seconds',
                'src' => 'avg_chatting_time_sum',
                'total_type' => 'sum'
            ),
            'oneChatTime' => array(
                'header' => array('resourceKey' => 'report.byoperator.one_chat_time'),
                'type' => 'seconds',
                'src' => 'one_chat_time',
                'total_type' => 'sum'
            ),
            'twoChatTime' => array(
                'header' => array('resourceKey' => 'report.byoperator.two_chat_time'),
                'type' => 'seconds',
                'src' => 'two_chats_time',
                'total_type' => 'sum'
            ),
            'threeAndMoreChatTime' => array(
                'header' => array('resourceKey' => 'report.byoperator.three_and_more_chat_time'),
                'type' => 'seconds',
                'src' => 'three_and_more_chats_time',
                'total_type' => 'sum'
            ),
            'avgChattingTime' => array(
                'header' => array('resourceKey' => 'report.byoperator.9'),
                'type' => 'seconds',
                'src' => 'avg_chatting_time',
                'src_type' => 'avg',
                'total_type' => 'avg'
            ),
            'preDinnerTime' => array(
                'header' => array('resourceKey' => 'report.byoperator.pre_dinner_time'),
                'type' => 'seconds',
                'src' => 'pre_dinner_time',
                'total_type' => 'sum'
            ),
            'dinnerTime' => array(
                'header' => array('resourceKey' => 'report.byoperator.dinner_time'),
                'type' => 'seconds',
                'src' => 'dinner_time',
                'total_type' => 'sum',
            ),
            'coachingBreakTime' => array(
                'header' => array('resourceKey' => 'report.byoperator.coaching_break_time'),
                'type' => 'seconds',
                'src' => 'coaching_break_time',
                'total_type' => 'sum',
            ),
            'technicalBreakTime' => array(
                'header' => array('resourceKey' => 'report.byoperator.technical_break_time'),
                'type' => 'seconds',
                'src' => 'technical_break_time',
                'total_type' => 'sum',
            ),
            'meetingBreakTime' => array(
                'header' => array('resourceKey' => 'report.byoperator.meeting_break_time'),
                'type' => 'seconds',
                'src' => 'meeting_break_time',
                'total_type' => 'sum',
            ),
            'shortBreakTime' => array(
                'header' => array('resourceKey' => 'report.byoperator.short_break_time'),
                'type' => 'seconds',
                'src' => 'short_break_time',
                'total_type' => 'sum',
            ),
            'privateTime' => array(
                'header' => array('resourceKey' => 'report.byoperator.private_time'),
                'type' => 'seconds',
                'src' => 'private_time',
                'total_type' => 'sum'
            ),
            'invisibleTime' => array(
                'header' => array('resourceKey' => 'report.byoperator.invisible_time'),
                'type' => 'seconds',
                'src' => 'invisible_time',
                'total_type' => 'sum'
            ),
        ),
        'cbhSummary' => array(
            'callCount' => array(
                'header' => array('resourceKey' => 'cbh_summary_stats.call_count'),
                'type' => 'int',
                'src' => 'call_cnt'
            ),
            'talkCount' => array(
                'header' => array('resourceKey' => 'cbh_summary_stats.talk_count'),
                'type' => 'int',
                'src' => 'talk_cnt'
            ),
            'talkLengthSum' => array(
                'header' => array('resourceKey' => 'cbh_summary_stats.talk_length_sum'),
                'type' => 'seconds',
                'src' => 'talk_length_sum'
            ),
            'avgTalkLength' => array(
                'header' => array('resourceKey' => 'cbh_summary_stats.talk_length_avg'),
                'type' => 'seconds',
                'src' => 'talk_length',
                'src_type' => 'avg',
                'total_type' => 'avg'
            )

        ),
    );

    /**
     * Get report with thread counts by categories
     *
     * @param $currentCategories
     * @param $filters
     * @param bool use data from stats table (cached)
     * @return array Report
     */
    static public function getReportByCategory($currentCategories, array $filters, $useCachedData = TRUE) {
        $categoriesForStats = array();
        foreach ($currentCategories as $categoryArr) {
            $category = $categoryArr['name'];
            $categoriesForStats[] = array(
                'category' => $category,
                'subcategory' => NULL
            );
            if (!empty($categoryArr['children'])) {
                foreach ($categoryArr['children'] as $subcategoryArr) {
                    $categoriesForStats[] = array(
                        'category' => $category,
                        'subcategory' => $subcategoryArr['name']
                    );
                }
            }
        }

        $mapper = $useCachedData ? MapperFactory::getStatsMapper() : MapperFactory::getTmpStatsThreadHistory2Mapper();
        $stats = $mapper->getStats('categories', $filters, self::getStatsAccountParams(), $categoriesForStats);


        $reportFieldConfigs = self::getBaseFieldConfigs('category');
        $report = self::makeBaseReport($stats, $reportFieldConfigs, $filters);

        $totalCount = !empty($report['total']['requestCount']['value']) ? $report['total']['requestCount']['value'] : 1;
        foreach ($report['data'] as &$dataRow) {
            $dataRow['percentage']['value'] = $dataRow['requestCount']['value']/$totalCount;
            if (empty($dataRow['category']['value'])) {
                $dataRow['category']['resourceKey'] = 'report.bycategories.without_category';
            }
        }
        $report['total']['percentage']['value'] = 1;
        return $report;
    }

    /**
     * Get report with thread counts by department
     *
     * @param $currentDepartments
     * @param $filters
     * @param bool use data from stats table (cached)
     * @param bool isOffline for offline or online
     * @return array Report
     */
    static public function getReportByDepartment($currentDepartments, array $filters, $useCachedData = TRUE, $isOffline = FALSE) {
        $mode = 'departments_' . ($isOffline ? 'offline' : 'online');
        $mapper = $useCachedData ? MapperFactory::getStatsMapper() : MapperFactory::getTmpStatsThreadHistory2Mapper();
        $stats = $mapper->getStats($mode, $filters, self::getStatsAccountParams(), $currentDepartments);
        Helper::sortTwoDimensionalArray($stats, 'departmentname', SORT_ASC);

        $reportFieldConfigs = self::getBaseFieldConfigs('department');
        $report = self::makeBaseReport($stats, $reportFieldConfigs, $filters);
        foreach ($report['data'] as &$dataRow) {
            if (empty($dataRow['department']['value']['name'])) {
                $dataRow['department']['resourceKey'] = 'report.bydepartments.without_department';
            }
        }

        return $report;
    }

    /**
     * Get report with thread counts by office
     *
     * @param $currentOffices
     * @param $filters
     * @param bool use data from stats table (cached)
     * @param bool isOffline for offline or online
     * @return array Report
     */
    static public function getReportByOffice($currentOffices, array $filters, $useCachedData = TRUE, $isOffline = FALSE) {
        $mode = 'offices_' . ($isOffline ? 'offline' : 'online');
        $mapper = $useCachedData ? MapperFactory::getStatsMapper() : MapperFactory::getTmpStatsThreadHistory2Mapper();
        foreach ($currentOffices as $office) {
            $preparedOffices[] = array(
                'officeid' => $office['id'],
                'officename' => $office['name'],
            );
        }
        $stats = $mapper->getStats($mode, $filters, self::getStatsAccountParams(), $preparedOffices);

        $reportFieldConfigs = self::getBaseFieldConfigs('office');
        $report = self::makeBaseReport($stats, $reportFieldConfigs, $filters);
        foreach ($report['data'] as &$dataRow) {
            if (empty($dataRow['office']['value']['name'])) {
                $dataRow['office']['resourceKey'] = 'report.byoffice.without_office';
            }
        }
        return $report;
    }

    /**
     * Get report with thread counts by country, region and city
     *
     * @param $filters
     * @param bool use data from stats table (cached)
     * @return array Report
     */
    static public function getReportByGeo(array $filters, $useCachedData = TRUE) {
        $mapper = $useCachedData ? MapperFactory::getStatsMapper() : MapperFactory::getTmpStatsThreadHistory2Mapper();
        $stats = $mapper->getStats('geo', $filters, self::getStatsAccountParams());

        $reportFieldConfigs = self::getBaseFieldConfigs('geo');
        Helper::sortTwoDimensionalArray($stats, array('geo_cnt.value', 'country', 'region', 'city'), SORT_DESC);
        $report = self::makeBaseReport($stats, $reportFieldConfigs, $filters);

        $totalCount = !empty($report['total']['requestCount']['value']) ? $report['total']['requestCount']['value'] : 1;
        foreach ($report['data'] as &$dataRow) {
            $dataRow['percentage']['value'] = $dataRow['requestCount']['value']/$totalCount;
            if (empty($dataRow['country']['value'])) {
                $dataRow['country']['resourceKey'] = 'report.bygeo.without_geo';
            }
        }
        $report['total']['percentage']['value'] = 1;
        Helper::sortTwoDimensionalArray($report['data'], 'requestCount.value', SORT_DESC);
        return $report;
    }

    /**
     * Get report with working stats for online chats
     * threads count, operator messages count, visitor messages count, avg answer time, chats count, missed chats count, etc.
     * by date
     *
     * @param array $filters
     * @param bool $useCachedData
     * @param bool $forOffline
     * @return array Report
     */
    static public function getReportUsingSystemByDate(array $filters, $useCachedData = TRUE, $forOffline = FALSE) {
        $reportFieldConfigs = array(
            'date' => array(
                'header' => array('resourceKey' => 'report.bydate.1'),
                'type' => 'date',
                'src' => 'd'
            )
        );

        if ($forOffline) {
            $mode = 'dates_offline';
            $baseFieldConfigs = self::getBaseFieldConfigs('dateOrHourOffline');
        } else {
            $mode = 'dates_online';
            $baseFieldConfigs = self::getBaseFieldConfigs('dateOrHour');
        }
        $reportFieldConfigs = array_merge($reportFieldConfigs, $baseFieldConfigs);

        $mapper = $useCachedData ? MapperFactory::getStatsMapper() : MapperFactory::getTmpStatsThreadHistory2Mapper();
        $accountSpecificParams = self::getStatsAccountParams();
        $stats = $mapper->getStats($mode, $filters, $accountSpecificParams);
        if (isMyIP() && self::isParamIncluded('unclosed')) {
            $unclosedThreads = MapperFactory::getThreadMapper()->getUnclosedThreadStats($filters, 'date', !empty($accountSpecificParams['timezone']) ? $accountSpecificParams['timezone'] : NULL, $forOffline);
            if (!empty($unclosedThreads)) {
                Helper::arraySpliceWithKeysPreserve($reportFieldConfigs, 2, 0, array('unclosedRequestCount' => array(
                    'header' => array('resourceKey' => 'report.bydate.unclosed_threads'),
                    'type' => 'int',
                    'src' => 'unclosed',
                    'total_type' => 'sum'
                )));

                $date2RowUnclosed = Helper::arrayColumnToKeys($unclosedThreads, 'd');
                foreach ($stats as &$dataRow) {
                    if (!empty($date2RowUnclosed[$dataRow['d']])) {
                        $dataRow['unclosed'] = $date2RowUnclosed[$dataRow['d']]['unclosed'];
                    }
                }
            }
        }

        $report = self::makeBaseReport($stats, $reportFieldConfigs, $filters);
        Helper::sortTwoDimensionalArray($report['data'], 'date.value', SORT_DESC);
        return $report;
    }


    /**
     * Get report with working stats
     * threads count, operator messages count, visitor messages count, avg answer time, chats count, missed chats count, offline threads count
     * by hours in day
     *
     * @param array $filters
     * @param bool use data from statstable (cached)
     * @param bool $forOffline
     * @return array Report
     */
    static public function getReportUsingSystemByHour(array $filters, $useCachedData = TRUE, $forOffline = FALSE) {
        $mapper = $useCachedData ? MapperFactory::getStatsMapper() : MapperFactory::getTmpStatsThreadHistory2Mapper();

        $reportFieldConfigs['hour'] = array(
            'header' => array('resourceKey' => 'report.byhour.1'),
            'type' => 'hour_range',
            'src' => 'h'
        );

        if ($forOffline) {
            $mode = 'hours_offline';
            $baseFieldConfigs = self::getBaseFieldConfigs('dateOrHourOffline');
            if (array_key_exists('operatorPeak', $baseFieldConfigs)) {
                unset($baseFieldConfigs['operatorPeak']);
            }
        } else {
            $mode = 'hours_online';
            $baseFieldConfigs = self::getBaseFieldConfigs('dateOrHour');
        }

        $reportFieldConfigs = array_merge($reportFieldConfigs, $baseFieldConfigs);

        $stats = $mapper->getStats($mode, $filters, self::getStatsAccountParams());
        $report = self::makeBaseReport($stats, $reportFieldConfigs, $filters);
        Helper::sortTwoDimensionalArray($report['data'], 'hour.value', SORT_ASC);
        return $report;
    }


    /**
     * chats count, operator messages count, avg length of message, avg operator rating, avg chat time, avg answer time, invited visitors count, missed visitors count,
     * agent busy messages count, avg waiting time of missed visitors, avg waiting time of intercepted visitors
     * by operators
     *
     * @param string $reportName
     * @param array $filters
     * @param bool use data from statstable (cached)
     * @param bool $daily
     * @return array Report
     */
    static public function getReportByOperator($reportName, array $filters, $useCachedData = TRUE, $daily = FALSE) {
        $mapper = $useCachedData ? MapperFactory::getStatsMapper() : MapperFactory::getTmpStatsThreadHistory2Mapper();
        switch ($reportName) {
            case 'operators_time':
                $mode = 'operators_time';
                $baseFieldConfigs = self::getBaseFieldConfigs('operatorsTime');
                break;
            case 'operators_lost_visitor':
                $mode = 'operators_lost_visitor';
                $baseFieldConfigs = self::getBaseFieldConfigs('operatorLostVisitor');
                break;
            case 'operators_intercepted_visitor':
                $mode = 'operators_intercepted_visitor';
                $baseFieldConfigs = self::getBaseFieldConfigs('operatorInterceptVisitor');
                break;
            case 'operators':
            case 'operators_daily':
            default:
                $mode = 'operators';
                $baseFieldConfigs = self::getBaseFieldConfigs('operator');
                break;
        }

        $stats = $mapper->getStats($mode, $filters, self::getStatsAccountParams(), Operator::getInstance()->enumOperatorsWithRelativeData(getAccountId()), $daily);
        if ($daily) {
            Helper::sortTwoDimensionalArray($stats, array('d', 'fullname'), SORT_ASC);
        } else {
            Helper::sortTwoDimensionalArray($stats, 'fullname', SORT_ASC);
        }
        $report = self::makeBaseReport($stats, $baseFieldConfigs, $filters, $daily);

        return $report;
    }

    /**
     * Get Webim reports prepared for various view
     * @param array $filters
     * @param bool $useCache use data from stats table
     * @return array
     */
    static public function getStatisticsReports(array $filters, $useCache = TRUE) {
        $filters['date_range']['start']->setTime(0, 0, 0);
        $filters['date_range']['end']->setTime(23, 59, 59);
        $reports = array();
        $reportsName = array(
            'categories', 'departments_online', 'departments_offline', 'offices_online', 'offices_offline',
            'dates_online', 'dates_offline', 'hours_online', 'hours_offline', 'operators_daily', 'operators',
            'operators_lost_visitor', 'operators_intercepted_visitor', 'operators_time', 'geo', 'startpages',
            'callback_hunter_summary'
        );

        foreach ($reportsName as $reportName) {
            if (self::areIncludeStatisticsReport($reportName)) {
                switch ($reportName) {
                    case 'categories':
                        if (Settings::GetCategories() !== NULL && empty($filters['category'])) {
                            $reports[$reportName] = self::getReportByCategory(Settings::GetCategories(), $filters, $useCache);
                        }
                        break;
                    case 'departments_online':
                    case 'departments_offline':
                        if (Tariff::getInstance()->hasTariffOption('departments') && empty($filters['department'])) {
                            $departments = MapperFactory::getDepartmentMapper()->enumDepartments(Resources::getCurrentLocale());
                            if (!empty($departments)) {
                                $reports[$reportName] = self::getReportByDepartment($departments, $filters, $useCache,
                                    $isOffline = $reportName == 'departments_offline' ? TRUE : FALSE);
                            }
                        }
                        break;
                    case 'offices_online':
                    case 'offices_offline':
                        if ($offices = Settings::Get('offices')) {
                            $reports[$reportName] = self::getReportByOffice($offices, $filters, $useCache,
                                $isOffline = $reportName == 'offices_offline' ? TRUE : FALSE);
                        }
                        break;
                    case 'dates_online':
                        $reports[$reportName] = self::getReportUsingSystemByDate($filters, $useCache);
                        break;
                    case 'dates_offline':
                        $reports[$reportName] = self::getReportUsingSystemByDate($filters, $useCache, $forOffline = TRUE);
                        break;
                    case 'hours_online':
                        if (Tariff::getInstance()->hasTariffOption('stats_by_hours') || isMyIP()) {
                            $reports[$reportName] = self::getReportUsingSystemByHour($filters, $useCache);
                        }
                        break;
                    case 'hours_offline':
                        if (Tariff::getInstance()->hasTariffOption('stats_by_hours') || isMyIP()) {
                            $reports[$reportName] = self::getReportUsingSystemByHour($filters, $useCache, $forOffline = TRUE);
                        }
                        break;
                    case 'operators_daily':
                        if ($filters['date_range']['end']->diff($filters['date_range']['start'])->days > 7) {
                            $reports[$reportName] = array(
                                'insteadDataResourceKey' => 'statistics.operators_daily.not_show_for_period'
                            );
                        } else {
                            $reports[$reportName] = self::getReportByOperator($reportName, $filters, $useCache, TRUE);
                        }
                        break;
                    case 'operators':
                        $reports[$reportName] = self::getReportByOperator($reportName, $filters, $useCache);
                        break;
                    case 'operators_lost_visitor':
                        $reports[$reportName] = self::getReportByOperator($reportName, $filters, $useCache);
                        break;
                    case 'operators_intercepted_visitor':
                        $reports[$reportName] = self::getReportByOperator($reportName, $filters, $useCache);
                        break;
                    case 'operators_time':
                        $reports[$reportName] = self::getReportByOperator($reportName, $filters, $useCache);
                        break;
                    case 'geo':
                        if (Tariff::getInstance()->hasTariffOption('stats_by_geo') || isMyIP()) {
                            $reports[$reportName] = self::getReportByGeo($filters, $useCache);
                        }
                        break;
                    case 'startpages':
                        $reports[$reportName] = self::getReportByStartPage($filters, $useCache);
                        break;
                    case 'callback_hunter_summary':
                        if (Tariff::getInstance()->hasTariffOption('callback_hunter') || isMyIP()) {
                            $reports[$reportName] = self::getCallbackHunterReport($filters);
                        }
                        break;
                }
            }
        }

        if (!empty($reports['hours_offline']) && !empty($reports['dates_offline'])) {
            //Total for hours correct, but for reason not = total for dates. Client wait that they will be equal.
            $reports['hours_offline']['total'] = $reports['dates_offline']['total'];
        }

        if (!empty($reports['hours']) && !empty($reports['dates'])) {
            //Total for hours correct, but for reason not = total for dates. Client wait that they will be equal.
            $reports['hours']['total'] = $reports['dates']['total'];
        }

        return $reports;
    }


    /**
     * Get report with thread counts by start page
     *
     * @param $filters
     * @param bool use data from stats table (cached)
     * @return array Report
     */
    static public function getReportByStartPage(array $filters, $useCachedData = TRUE) {
        $mapper = $useCachedData ? MapperFactory::getStatsMapper() : MapperFactory::getTmpStatsThreadHistory2Mapper();
        $stats = $mapper->getStats('startpages', $filters, self::getStatsAccountParams());

        $reportFieldConfigs = self::getBaseFieldConfigs('startpage');

        $report = self::makeBaseReport($stats, $reportFieldConfigs, $filters);
        $totalCount = !empty($report['total']['requestCount']['value']) ? $report['total']['requestCount']['value'] : 1;
        foreach ($report['data'] as &$dataRow) {
            $dataRow['percentage']['value'] = $dataRow['requestCount']['value']/$totalCount;
        }
        $report['total']['percentage']['value'] = 1;
        Helper::sortTwoDimensionalArray($report['data'], 'requestCount.value', SORT_DESC);
        return $report;
    }

    static public function getCallbackHunterReport(array $filters) {
        $stats = MapperFactory::getCallbackMapper()->getStats($filters);
        if (empty($stats[0]['call_cnt'])) {
            $stats = array();
        }
        $reportFieldConfigs = self::getBaseFieldConfigs('cbhSummary');
        return self::makeBaseReport($stats, $reportFieldConfigs, $filters);
    }

    /**
     * TODO: Find a better place for converters
     * @param array $reports
     * @param bool use dummy values
     * @return array
     */
    static public function convertReportsToTables(array $reports,  $dummyReport = FALSE) {
        $tables = array();
        foreach ($reports as $reportKey => $report) {
            switch ($reportKey) {
                case 'categories':
                    $table = self::convertCategoryReportToTable($report);
                    $table['params']['titleKey'] = 'reports.' . $reportKey . '.title';
                    break;
                case 'startpages':
                    $table = self::convertStartPageReportToTable($report);
                    $table['params']['titleKey'] = 'reports.' . $reportKey . '.title';
                    break;
                case 'departments_online':
                case 'departments_offline':
                    $table = self::convertDepartmentReportToTable($report);
                    $table['params']['size'] = 'small';
                    $table['params']['titleKey'] = 'reports.' . $reportKey . '.title';
                    break;
                case 'offices_online':
                case 'offices_offline':
                    $table = self::convertOfficeReportToTable($report);
                    $table['params']['size'] = 'small';
                    $table['params']['titleKey'] = 'reports.' . $reportKey . '.title';
                break;
                case 'geo':
                    $table = self::convertGeoReportToTable($report);
                    $table['params']['titleKey'] = 'reports.' . $reportKey . '.title';
                    break;
                case 'dates_online':
                case 'dates_offline':
                    $table = self::convertDateReportToTable($report);
                    $table['params']['titleKey'] = 'reports.' . $reportKey . '.title';
                    break;
                case 'hours_online':
                case 'hours_offline':
                    $table = self::convertHourReportToTable($report);
                    $table['params']['titleKey'] = 'reports.' . $reportKey . '.title';
                    break;
                case 'operators_daily':
                    $table = self::convertDailyOperatorReportToTable($report);
                    $table['params']['titleKey'] = 'reports.' . $reportKey . '.title';
                    break;
                case 'operators':
                    $table = self::convertSummaryOperatorReportToTable($report);
                    $table['columnOrder'] = Helper::removeValueFromArray(
                        array('missedCount'),
                        $table['columnOrder']
                    );
                    $table['params']['titleKey'] = 'reports.' . $reportKey . '.title';
                    $table['params']['dummy'] = $dummyReport;
                    break;
                case 'operators_lost_visitor':
                    $table = self::convertSummaryOperatorReportToTable($report);
                    $table['columnOrder'] = array('operator', 'missedCount', 'avgMissedTime');
                    $table['params']['size'] = 'small';
                    $table['params']['titleKey'] = 'reports.' . $reportKey . '.title';
                    $table['params']['dummy'] = $dummyReport;
                  break;
              case 'operators_intercepted_visitor':
                    $table = self::convertSummaryOperatorReportToTable($report);
                    $table['columnOrder'] = array('operator', 'interceptedCount', 'avgInterceptedTime');
                    $table['params']['size'] = 'small';
                    $table['params']['titleKey'] = 'reports.' . $reportKey . '.title';
                    $table['params']['dummy'] = $dummyReport;
                    break;
                case 'operators_time':
                    $table = self::convertOperatorsTimeReportToTable($report);
                    $table['params']['titleKey'] = 'reports.' . $reportKey . '.title';
                    break;
                case 'callback_hunter_summary':
                    $table = self::convertCbhSummaryReportToTable($report);
                    $table['params']['titleKey'] = 'cbh_summary_stats.summary.title';
                    break;
                default:
                    $table = $report;
                    $table['columnOrder'] = array_keys($table['headers']);
            }
            $table['params']['dummy'] = $dummyReport;
            $table = self::addHistoryLinkToTable($table);
            $table = self::addTooltipsToTable($reportKey, $table);

            $tables[$reportKey] = $table;
        }

        return $tables;
    }

    static public function convertTopUrlReportToTable(array $report) {
        $table = $report;
        $table['params']['size'] = 'small';
        $table['headers']['url']['align'] = 'left';
        foreach ($table['data'] as &$dataRow) {
            $dataRow['url']['align'] = 'left';
            $dataRow['url']['link'] = array(
                'type' => 'url',
                'url' => $dataRow['url']['value']
            );
            $dataRow['url']['processors'] = array(
                'crop' => array(
                    'limit' => 100
                )
            );
        }
        $table['columnOrder'] = array_keys($table['headers']);
        return $table;
    }

    static public function convertCbhSummaryReportToTable(array $report) {
        $table = $report;
        $table['params']['size'] = 'small';
        $table['columnOrder'] = array_keys($table['headers']);
        return $table;
    }

    static public function convertCategoryReportToTable(array $report) {
        $table = $report;
        $table['headers']['category']['align'] = 'left';
        foreach ($table['data'] as &$dataRow) {
            if (!empty($dataRow['subcategory']['value'])) {
                $dataRow['category']['value'] = $dataRow['subcategory']['value'];
                $dataRow['category']['indent'] = TRUE;
            }
            $dataRow['category']['align'] = 'left';
        }

        $table['params']['size'] = 'small';
        $table['columnOrder'] = array_keys($table['headers']);
        $table['columnOrder'] = Helper::removeValueFromArray('subcategory', $table['columnOrder']);
        return $table;
    }

    static public function convertStartPageReportToTable(array $report) {
        $table = $report;
        $table['headers']['startpage']['align'] = 'left';
        foreach ($table['data'] as &$dataRow) {
            $dataRow['startpage']['align'] = 'left';
            $dataRow['startpage']['link'] = array(
                'type' => 'url',
                'url' => $dataRow['startpage']['value']
            );
            $dataRow['startpage']['processors'] = array(
                'crop' => array(
                    'limit' => 100
                )
            );
        }
        if (!empty($table['total'])) {
            $table['total']['startpage']['align'] = 'left';
        }
        $table['params']['size'] = 'small';
        $table['columnOrder'] = array_keys($table['headers']);
        return $table;
    }

    static public function convertDepartmentReportToTable(array $report) {
        $table = $report;
        $table['headers']['department']['align'] = 'left';
        foreach ($table['data'] as &$dataRow) {
            $dataRow['department']['align'] = 'left';
        }

        $table['params']['size'] = 'small';
        $table['columnOrder'] = array_keys($table['headers']);
        return $table;
    }

    static public function convertOfficeReportToTable(array $report) {
        $table = $report;
        $table['headers']['office']['align'] = 'left';
        foreach ($table['data'] as &$dataRow) {
            $dataRow['office']['align'] = 'left';
        }

        $table['params']['size'] = 'small';
        $table['columnOrder'] = array_keys($table['headers']);
        return $table;
    }

    static public function convertGeoReportToTable(array $report) {
        $table = $report;
        $table['headers']['country']['align'] = 'left';
        $table['headers']['region']['align'] = 'left';
        $table['headers']['city']['align'] = 'left';
        foreach ($table['data'] as &$dataRow) {
            $dataRow['country']['align'] = 'left';
            $dataRow['region']['align'] = 'left';
            $dataRow['city']['align'] = 'left';
        }
        if (!empty($table['total'])) {
            $table['total']['country']['align'] = 'left';
            $table['total']['region']['align'] = 'left';
            $table['total']['city']['align'] = 'left';
        }
        $table['params']['size'] = 'small';
        $table['columnOrder'] = array_keys($table['headers']);
        unset($table['columnOrder'][array_search('city', $table['columnOrder'])]);
        return $table;
    }

    static public function convertDateReportToTable(array $report) {
        return self::convertDateOrHourReportToTable($report, 'date');
    }

    static public function convertHourReportToTable(array $report) {
        return self::convertDateOrHourReportToTable($report, 'hour');
    }

    static public function convertDailyOperatorReportToTable(array $report) {
        return self::convertDailyOrSummaryOperatorReportToTable($report, 'daily');
    }

    static public function  calcCachedStatsForFilters($filters) {
        self::prepareBeforeCalcCached($filters['date_range']['end']);
        MapperFactory::getStatsMapper()->loadStatsCacheForFilters($filters, self::getStatsAccountParams());
    }

    static public function calcCachedStatsForAll($endDate) {
        self::prepareBeforeCalcCached($endDate);
        MapperFactory::getStatsMapper()->loadAllStatsCache($endDate, self::getStatsAccountParams());
    }

    static protected function prepareBeforeCalcCached($endDate) {
        MapperFactory::getThreadMapper()->checkAndSetType($endDate, Settings::Get('seconds_before_visitor_missed'));
        MapperFactory::getThreadMapper()->setThreadOperatorAndOffice($endDate);
    }

    static protected function getStatsAccountParams() {
        $account = Account::getInstance()->getCurrentAccount();
        $params = array(
            'auto_assign' => Settings::Get('auto_assign'),
            'stats_reports_include' => Settings::Get('stats_reports_include'),
            'stats_reports_exclude' => Settings::Get('stats_reports_exclude'),
            'stats_fields_include' => Settings::Get('stats_fields_include'),
            'stats_fields_exclude' => Settings::Get('stats_fields_exclude')
        );
        if (!empty($account['timezone'])) {
            $params['timezone'] = $account['timezone'];
        }

        return $params;
    }

    static public function convertSummaryOperatorReportToTable(array $report) {
        return self::convertDailyOrSummaryOperatorReportToTable($report, 'summary');
    }

    static public function convertOperatorsTimeReportToTable($report){
        $table = $report;

        foreach ($table['data'] as $key => $dataRow) {
            $table['data'][$key] = $dataRow;
            $table['data'][$key]['operator']['align'] = 'left';
        }
        if (!empty($table['total'])) {
            $table['total']['operator']['align'] = 'left';
        }

        $table['columnOrder'] = array_keys($table['headers']);
        return $table;
    }


    static protected function convertDateOrHourReportToTable(array $report, $type) {
        if ($type == 'date') {
            $timeField = 'date';
        } else {
            $timeField = 'hour';
        }
        $table = $report;

        foreach ($table['data'] as $key => $dataRow) {
            $filters = $table['filters'];
            if ($type == 'date') {
                $filters['date_range'] = array(
                    'start' => $dataRow['date']['value'],
                    'end' => $dataRow['date']['value']
                );
            }
            if(array_key_exists('unclosedRequestCount', $table['data'][$key])) {
                $table['data'][$key]['unclosedRequestCount']['context'] = 'warning';
            }
        }

        if (!empty($table['total'])) {
            $table['total'][$timeField]['align'] = 'left';
            if(array_key_exists('unclosedRequestCount', $table['total'])) {
                $table['total']['unclosedRequestCount']['context'] = 'warning';
            }
        }
        $table['columnOrder'] = array_keys($table['headers']);
        return $table;
    }

    static protected function addTooltipsToTable($reportName, $table) {
        $tooltips = self::getReportTooltips();
        if (!empty($tooltips[$reportName])) {
            foreach ($tooltips[$reportName] as $headerKey => $tooltip) {
                if (!empty($table['headers'][$headerKey])) {
                    $table['headers'][$headerKey]['tooltip'] = $tooltip . (isMyIP() ? '(' . $headerKey . ')' : '');
                }
            }
        }
        return $table;
    }

    static protected function addHistoryLinkToTable($table) {
        if (!empty($table['data'])) {
            foreach ($table['data'] as $key => $row) {
                $table['data'][$key] = self::addHistoryLinkToTableRow($row);
            }
        }

        if (!empty($table['total'])) {
            $table['total'] = self::addHistoryLinkToTableRow($table['total']);
        }

        return $table;
    }

    static protected function addHistoryLinkToTableRow($row) {
        foreach ($row as $fieldName => $field) {
            if (!empty($field['statsIds'])) {
                $row[$fieldName]['statsIds'] = $field['statsIds'];
            }
            if (!empty($field['statsIds']) && !empty($field['hasThreads'])) {
                $row[$fieldName]['link'] = array(
                    'type' => 'url',
                    'url' => self::getHistoryUrl($field)
                );
            }
        }

        return $row;
    }

    static protected function convertDailyOrSummaryOperatorReportToTable($report, $type) {
        $table = $report;

        if ($type == 'daily') {
            $table['data'] = array();
            if (!empty($report['data'])) foreach ($report['data'] as $dateStr => $level) {
                $table['data'][] = array('_divider' => array('value' => new DateTime($dateStr), 'type' => 'date'));
                foreach ($level as $row) {
                    $table['data'][] = $row;
                }
            }
        } else {
            if (!empty($table['total'])) {
                $table['total']['operator']['align'] = 'left';
            }
        }
        $table['columnOrder'] = !empty($table['headers']) ? array_keys($table['headers']) : array();
        return $table;
    }

    static protected function getReportTooltips() {
        if (isHostedMode()) {
            return array();
        }
        $tooltips = KeyValueCache::get('statistics-tooltips', 'key-value', array());
        if (empty($tooltips) && getBrandPartner() === null && !isHostedMode()) {
            $content = Helper::getWebPage('http://blog.webim.ru/pro/doc-stats/');
            if (!empty($content)) {
                phpQuery::newDocument($content);
                $tableClassPrefix = 'webimtips-report-';
                $tooltipClassPrefix = 'webimtips-';
                foreach (pq('table[class^="' . $tableClassPrefix . '"]') as $table) {
                    $tableClasses = preg_split('/[\s]+/', pq($table)->attr('class'));
                    foreach ($tableClasses as $class) {
                        $class = strtolower($class);
                        if (strpos($class, $tableClassPrefix) === 0) {
                            $blockName = substr($class, strlen($tableClassPrefix));
                            foreach(pq($table)->find('td[class^="' . $tooltipClassPrefix .'"]') as $tooltipElement) {
                                $tooltipName = substr(pq($tooltipElement)->attr('class'), strlen($tooltipClassPrefix));
                                $tooltipValue = pq($tooltipElement)->text();
                                $tooltips[$blockName][$tooltipName] = smarticonv('utf-8', WEBIM_ENCODING, $tooltipValue);
                            }
                        }
                    }
                }
                KeyValueCache::put('statistics-tooltips', $tooltips, 'key-value', 7*24*60*60);
            }
        }
        return $tooltips;
    }

    static private function areIncludeStatisticsReport($reportName) {
        if (in_array($reportName, array('operators_intercepted_visitor', 'startpages'))) {
            return false;
        }
        $result = FALSE;
        $includedReports = Settings::Get('stats_reports_include');
        $excludedReports = Settings::Get('stats_reports_exclude');
        if (
            (empty($includedReports) || !empty($includedReports) && in_array($reportName, $includedReports))
            && (empty($excludedReports) || !empty($excludedReports) && !in_array($reportName, $excludedReports))
        ) {
            $result = TRUE;
        }

        return $result;
    }

    static private function operatorRate($rateSum, $count, $rate2Cnt = array()) {
        if (empty($count)) {
            return '';
        }
        $result = Resources::Get('report.rate_count', array(sprintf('%.2f', $rateSum/$count), sprintf('%d' ,$count)));
        if ($rate2Cnt) {
            $subResult = array();
            foreach ($rate2Cnt as $rate => $subCount) {
                if ($subCount) {
                    $subResult[] = Resources::Get('report.rate_subcount', array('rate' => $rate, 'count' => (int)$subCount));
                }
            }
            $result .= ' (' . implode(',' . PHP_EOL, $subResult) . ')';
        }
        return $result;
    }

    static private function makeBaseReport(array $stats, array $fieldConfigs, array $filters, $daily = FALSE) {
        $report = self::$reportTemplate;
        foreach ($fieldConfigs as $fieldKey => $fieldConfig) {
            $report['headers'][$fieldKey] = $fieldConfig['header'];
        }
        if ($daily) {
            $currentDay = NULL;
            $currentDayReport = array();
            foreach ($stats as $dataKey => $dataRow) {
                if ($currentDay !== $dataRow['d']) {
                    if (!empty($currentDayReport)) {
                        $report['data'][$currentDay] = $currentDayReport;
                        $currentDayReport = array();
                    }

                    $currentDay = $dataRow['d'];
                }

                $currentDayReport[$dataKey] = self::rawReportRowToReportRow($dataRow, $fieldConfigs);
            }
            if (!empty($currentDayReport)) {
                $report['data'][$currentDay] = $currentDayReport;
            }
        } else {
            foreach ($stats as $dataKey => $dataRow) {
                $report['data'][$dataKey] = self::rawReportRowToReportRow($dataRow, $fieldConfigs);
            }
        }

        if (!$daily) {
            $report['total'] = self::calcTotalRow($stats, $fieldConfigs);
        }


        $report['filters'] = $filters;
        $report['params']['twoLevels'] = $daily;
        return $report;
    }

    static private function rawReportRowToReportRow(array $rawReportRow, array $fieldConfigs) {
        $reportRow = array();
        foreach ($fieldConfigs as $fieldKey => $fieldConfig) {
            $reportRow[$fieldKey] = self::getFieldData($fieldConfig, $rawReportRow);
        }

        return $reportRow;
    }

    static protected function calcTotalRow(array $stats, array $fieldConfigs) {
        $total = array();
        $totalNecessary = FALSE;
        foreach ($fieldConfigs as $fieldKey => $fieldConfig) {
            $total[$fieldKey] = array(
                'value' => 0,
                'type' => $fieldConfig['type'],
                'statsIds' => NULL,
                'threadIds' => NULL
            );

            if (!empty($fieldConfig['total_type'])) {
                $totalNecessary = TRUE;
            }
        }

        if (!$totalNecessary) {
            return array();
        }

        $rate2Cnt = array(1 => 0, 2 => 0, 3 => 0, 4 => 0, 5 => 0);
        foreach ($stats as $statsRow) {
            foreach ($fieldConfigs as $fieldKey => $fieldConfig) {
                if (!empty($fieldConfig['total_type'])) {
                    $fieldData = self::getFieldData($fieldConfig, $statsRow);
                    switch ($fieldConfig['total_type']) {
                        case 'sum':
                            $total[$fieldKey]['value'] += $fieldData['value'];
                            break;
                        case 'avg_rate':
                            for ($i = 1; $i <= 4; $i++) {
                                $field = self::getFieldBySrc($fieldConfig['src']['rate' . $i], $statsRow, 0);
                                $rate2Cnt[$i] += $field['value'];
                            }
                        case 'avg':
                            if (!empty($fieldData['cnt'])) {
                                if (empty($total[$fieldKey]['cnt'])) {
                                    $total[$fieldKey]['sum'] = $fieldData['sum'];
                                    $total[$fieldKey]['cnt'] = $fieldData['cnt'];
                                } else {
                                    $total[$fieldKey]['sum'] += $fieldData['sum'];
                                    $total[$fieldKey]['cnt'] += $fieldData['cnt'];
                                }
                            }
                            break;
                        case 'max':
                            $total[$fieldKey]['value'] = max($total[$fieldKey]['value'], $fieldData['value']);
                            break;
                    }

                    if (!empty($fieldData['statsIds'])) {
                        $total[$fieldKey]['statsIds'] .=  (!empty($total[$fieldKey]['statsIds']) ? ',' : '') . $fieldData['statsIds'];
                    }
                    $total[$fieldKey]['hasThreads'] = !empty($total[$fieldKey]['hasThreads']) || !empty($fieldData['threadIds']) || !empty($fieldData['hasThreads']);
                }
            }
        }

        foreach ($fieldConfigs as $fieldKey => $fieldConfig) {
            if (!empty($fieldConfig['total_type'])) {

                switch ($fieldConfig['total_type']) {
                    case 'avg':
                        if (!empty($total[$fieldKey]['cnt'])) {
                            $total[$fieldKey]['value'] = $total[$fieldKey]['sum']/$total[$fieldKey]['cnt'];
                        }
                        break;
                    case 'avg_rate':
                        if (!empty($total[$fieldKey]['cnt'])) {
                            $rate2Cnt[5] = $total[$fieldKey]['cnt'] - array_sum($rate2Cnt);
                            $total[$fieldKey]['value'] = self::operatorRate($total[$fieldKey]['sum'],$total[$fieldKey]['cnt'], $rate2Cnt);
                        }
                        break;
                }
            }
        }

        return $total;
    }

    protected static function getFieldData(array $fieldConfig, array $row) {
        $type2defaultValue = array(
            'int' => 0,
            'float' => 0,
            'money' => 0,
            'percent' => 0,
            'string' => '',
            'date' => NULL,
            'datetime' => NULL,
            'seconds' => 0,
            'hour_range' => 0,
            'operator' => array(
                'id' => 0,
                'name' => '',
                'email' => '',
                'deleted' => NULL
            ),
            'department' => array(
                'id' => 0,
                'name' => ''
            ),
            'office' => array(
                'id' => 0,
                'name' => ''
            ),
            'operator_rate' => 0,
            'bool' => false
        );

        $fieldData = array(
            'type' => $fieldConfig['type'],
            'value' => Helper::getField($fieldConfig['type'], $type2defaultValue),
            'statsIds' => NULL,
            'hasThreads' => NULL
        );
        if (!empty($fieldConfig['src_type'])) {
            switch ($fieldConfig['src_type']) {
                case 'avg':
                    if (array_key_exists($fieldConfig['src'], $row)) {
                        $valueData = self::getFieldBySrc($fieldConfig['src'], $row, $fieldData['value']);
                        $fieldData = array_merge($fieldData, $valueData);
                    } else {
                        $sum = self::getFieldBySrc($fieldConfig['src'] . '_sum', $row, $fieldData['value']);
                        $cnt = self::getFieldBySrc($fieldConfig['src'] . '_cnt', $row, 0);

                        $fieldData['value'] = $cnt['value'] != 0 ? $sum['value'] / $cnt['value'] : null;
                        $fieldData['statsIds'] = $sum['statsIds'];
                        $fieldData['hasThreads'] = !empty($sum['threadIds']) || !empty($sum['hasThreads']);
                        $fieldData['sum'] = $sum['value'];
                        $fieldData['cnt'] = $cnt['value'];
                    }
            }
        } else {
            switch ($fieldConfig['type']) {
                case 'date':
                case 'datetime':
                    $valueData = self::getFieldBySrc($fieldConfig['src'], $row, $fieldData['value']);
                    $fieldData = array_merge($fieldData, $valueData);
                    $fieldData['value'] = new DateTime($fieldData['value']);
                    break;
                case 'operator':
                case 'department':
                case 'office':
                    foreach ($fieldConfig['src'] as $subFieldKey => $subSrcKey) {
                        $fieldData['value'][$subFieldKey] = Helper::getField($subSrcKey, $row, $fieldData['value'][$subFieldKey]);
                    }
                    break;
                case 'operator_rate':
                    $rate = self::getFieldBySrc($fieldConfig['src']['rate'], $row, 0);
                    $count = self::getFieldBySrc($fieldConfig['src']['count'], $row, 0);
                    $rate2Cnt = array();
                    for ($i = 1; $i <= 4; $i++) {
                        $field = self::getFieldBySrc($fieldConfig['src']['rate' . $i], $row, 0);
                        $rate2Cnt[$i] = $field['value'];
                    }
                    $rate2Cnt[5] = $count['value'] - array_sum($rate2Cnt);
                    $fieldData['value'] = !empty($rate['value']) ? self::operatorRate($rate['value'], $count['value'], $rate2Cnt) : $fieldData['value'];
                    $fieldData['sum'] = $rate['value'];
                    $fieldData['cnt'] = $count['value'];
                    break;
                case 'bool':
                    $valueData = self::getFieldBySrc($fieldConfig['src'], $row, $fieldData['value']);
                    $fieldData['value'] = (bool)$valueData['value'];
                    $fieldData['statsIds'] = $valueData['statsIds'];
                    $fieldData['hasThreads'] = !empty($valueData['threadIds']) || !empty($valueData['hasThreads']);
                    $fieldData['ifTrue'] = !empty($fieldConfig['ifTrue']) ? $fieldConfig['ifTrue'] : NULL;
                    $fieldData['ifFalse'] = !empty($fieldConfig['ifFalse']) ? $fieldConfig['ifFalse'] : NULL;
                    break;
                case 'percent':
                    if (array_key_exists('src', $fieldConfig)) {
                        $valueData = self::getFieldBySrc($fieldConfig['src'], $row, $fieldData['value']);
                        $fieldData['sum'] = $valueData['value'];
                        if (array_key_exists('percent_base', $fieldConfig) && !empty($row[$fieldConfig['percent_base']])) {
                            $fieldData['cnt'] = $row[$fieldConfig['percent_base']]['value'];
                            $valueData['value'] = $valueData['value'] / $row[$fieldConfig['percent_base']]['value'];
                        } else {
                            $fieldData['cnt'] = 1;
                        }
                        $fieldData = array_merge($fieldData, $valueData);
                    }
                    break;
                default:
                    if (array_key_exists('src', $fieldConfig)) {
                        $valueData = self::getFieldBySrc($fieldConfig['src'], $row, $fieldData['value']);
                        $fieldData = array_merge($fieldData, $valueData);
                    }
            }
        }
        return $fieldData;
    }

    private static function getFieldBySrc($src, $row, $default) {
        $valueData = Helper::getField($src, $row, $default);
        if (is_array($valueData)) {
            $fieldData['value'] = $valueData['value'];
            $fieldData['statsIds'] = $valueData['statsids'];
            $fieldData['threadIds'] = !empty($valueData['threadids']) ? $valueData['threadids'] : null;
            $fieldData['hasThreads'] = !empty($valueData['threadids']);
        } else {
            $fieldData['value'] = $valueData;
            $fieldData['statsIds'] = NULL;
            $fieldData['threadIds'] = NULL;
            $fieldData['hasThreads'] = NULL;
        }

        return $fieldData;
    }

    protected static function getBaseFieldConfigs($category) {
        $fieldConfigs = self::$baseFieldConfigs[$category];
        foreach ($fieldConfigs as $fieldKey => $fieldConfig) {
            if (empty($fieldConfig['src'])) {
                continue;
            }

            $src = $fieldConfig['src'];
            $fieldIncluded = TRUE;
            switch ($fieldConfig['type']) {
                case 'operator_rate':
                    $fieldIncluded = self::isParamIncluded($src['rate']);
                    break;
                case 'avg':
                case 'int':
                case 'startpage':
                case 'seconds':
                case 'string':
                    $fieldIncluded = self::isParamIncluded($src);
                    break;
            }
            if (!$fieldIncluded) {
                unset($fieldConfigs[$fieldKey]);
            }
        }

        return $fieldConfigs;
    }

    protected static function isParamIncluded($paramName) {
        global $params;
        if (empty($params)) {
            $params = array();
        }
        $params[$paramName] = 1;

        $includedFields = Settings::Get('stats_fields_include');
        $excludedFields = Settings::Get('stats_fields_exclude');
        if (!is_array($excludedFields)) {
          immediatelyNotifyAboutProblem($excludedFields, "stats_fields_exclude was not array");
        }

        $fName = preg_replace('/_sum$/', '', $paramName);
        $fName = preg_replace('/_avg$/', '', $fName);
        $fName = preg_replace('/_std$/', '', $fName);
        $fName = preg_replace('/_cnt$/', '', $fName);

        $result = true;
        if (!empty($excludedFields)) {
            $result = !in_array($paramName, $excludedFields)  && !in_array($fName, $excludedFields);
        }

        if (!empty($includedFields) && !$result) {
            $result = in_array($paramName, $includedFields) || in_array($fName, $includedFields);
        }
        if (!$result && defined('STATS_DEBUG_PARAM') && stristr($paramName, STATS_DEBUG_PARAM)) {
            $a = 1;
        }
        return $result;
    }

    protected static function getHistoryUrl(array $fieldConfig) {
        $url = Helper::getServiceURL(getAccountId(), null, null, false) . WEBIM_ROOT . '/operator/history.php?q=';
        $queryArr = array();
        if (!empty($fieldConfig['statsIds'])) {
            $queryArr['statsids'] = $fieldConfig['statsIds'];
        } else {
            if (!empty($fieldConfig['date_range'])) {
                $queryArr['date_range'] =  $fieldConfig['date_range']['start']->format(Helper::getDateFormat()) . ' - ' . $fieldConfig['date_range']['end']->format(Helper::getDateFormat());
            }
            if (!empty($fieldConfig['subcategory']) && !empty($fieldConfig['category'])) {
                $queryArr['category'] = htmlspecialchars($fieldConfig['category']) . '|' . htmlspecialchars($fieldConfig['subcategory']);
            } elseif (!empty($fieldConfig['category'])) {
                $queryArr['category'] = htmlspecialchars($fieldConfig['category']);
            } elseif (!empty($fieldConfig['without_category'])) {
                $queryArr['category'] = '-';
            }
            if (!empty($fieldConfig['thread_type'])) {
                $queryArr['thread_types'] = array($fieldConfig['thread_type']);
            }
            if (!empty($fieldConfig['operator'])) {
                $queryArr['operators'] = array($fieldConfig['operator']);
            }
            if (!empty($fieldConfig['department'])) {
                $queryArr['departments'] = array($fieldConfig['department']);
            } elseif (!empty($fieldConfig['without_department'])) {
                $queryArr['departments'] = array('-');
            }
            if (!empty($fieldConfig['office'])) {
                $queryArr['office'] = $fieldConfig['office'];
            } elseif (!empty($fieldConfig['without_office'])) {
                $queryArr['office'] = '-';
            }
            if (!empty($fieldConfig['locale'])) {
                $queryArr['locale'] = $fieldConfig['locale'];
            }
            if (!empty($fieldConfig['office'])) {
                $queryArr['office'] = $fieldConfig['office'];
            }
        }
        $url .= '&' . http_build_query($queryArr);

        return $url;
    }
}
