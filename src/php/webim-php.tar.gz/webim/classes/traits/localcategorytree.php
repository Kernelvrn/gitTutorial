<?php

/**
 * Class Report_Trait_CategoryTree
 * При работе с рядом старых записей в БД могут попадаться категории, которые уже
 * были удалены. В такой ситуации, что бы таке категории не смешивались с существующими,
 * в рамках классов создаются копии иерархии.
 */
trait Trait_LocalCategoryTree {
    private static $categoryInstances = array();

    protected static function getCategoryModel($categoryTitle, $subcategoryTitle = NULL) {
        if (!array_key_exists($categoryTitle, self::$categoryInstances)) {
            $repository = Factory_Repository::create('category');
            self::$categoryInstances[$categoryTitle] =
                $repository->findById($categoryTitle) ?: new Model_Category($categoryTitle);

        }

        $category = self::$categoryInstances[$categoryTitle];
        if (!empty($subcategoryTitle)) {
            if (!$category->hasChildByTitle($subcategoryTitle)) {
                $category->addChildByTitle($subcategoryTitle);
            }
            $category = $category->getChildByTitle($subcategoryTitle);
        }

        return $category;
    }
}