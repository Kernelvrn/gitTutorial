<?php

/**
 * Class Iterator_Query
 * Итератор для объектов SelectQuery коллбэком на каждый fetch
 */
class Iterator_Query extends Iterator_Base {
    protected $query = NULL;
    protected $fetchCallbacks = array();
    protected $position = NULL;
    protected $positionInFetched = NULL;
    protected $fetched = NULL;
    protected $value = NULL;
    protected $inFirstFetch = false;

    /**
     * @param Wrapper_SelectQuery $query
     */
    public function __construct(Wrapper_SelectQuery $query) {
        $this->query = $query;
        $this->rewind();
    }

    public function key() {
        return $this->position;
    }

    public function current() {
        return $this->value;
    }

    public function next() {
        if ($this->valid()) {
            $this->position++;
            $this->positionInFetched++;
            if ($this->positionInFetched >= count($this->fetched)) {
                $this->nextFetch();
                $this->inFirstFetch = false;
            } else {
                $this->value = $this->fetched[$this->positionInFetched];
            }
        }
    }

    public function rewind() {
        $this->position = 0;
        if ($this->inFirstFetch) {
            $this->positionInFetched = 0;
            if ($this->valid()) {
                $this->value = $this->fetched[$this->positionInFetched];
            }
        } else {
            $this->query->rewind();
            $this->nextFetch();
            $this->inFirstFetch = true;
        }
    }

    public function valid() {
        return !empty($this->fetched) && array_key_exists($this->positionInFetched, $this->fetched);
    }

    public function addFetchCallback($callback) {
        $this->fetchCallbacks[] = $callback;
        if (isset($this->fetched)) {
            $this->fetched = call_user_func($callback, $this->fetched);
        }
    }

    public function count() {
        return $this->query->count();
    }

    protected function nextFetch() {
        $this->fetched = $this->query->fetchNext();
        foreach ($this->fetchCallbacks as $callback) {
            $this->fetched = call_user_func($callback, $this->fetched);
        }
        $this->positionInFetched = 0;
        if ($this->valid()) {
            $this->value = $this->fetched[$this->positionInFetched];
        }
    }
}