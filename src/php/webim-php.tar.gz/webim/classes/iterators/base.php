<?php

abstract class Iterator_Base implements Iterator, Countable {
    /**
     * Возвращает итератор для объекта
     * @param Array|Iterator|IteratorAggregate $var
     * @return Iterator
     * @throws Exception Если для $var нет возможности вернуть итератор
     */
    protected function getIterator($var) {
        if (is_array($var)) {
            return new ArrayIterator($var);
        } elseif (in_array('IteratorAggregate', class_implements($var))) {
            return $var->getIterator();
        } elseif (in_array('Iterator', class_implements($var))) {
            return $var;
        } else {
            throw new Exception('Can\'t make iterator');
        }
    }
}