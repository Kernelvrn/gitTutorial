<?php

/**
 * Class Iterator_Group
 * Итератор для группировки нескольких значениий другого Traversable объекта согласно
 * заданного алгоритма и возврата их в качестве одного.
 * Ключи int, начиная с 0
 */
class Iterator_Group extends Iterator_Base {
    protected $data = NULL;
    /**
     * @var Iterator
     */
    protected $dataIterator = NULL;
    /**
     * @var callable
     */
    protected $nextCallback = NULL;

    protected $value = NULL;
    protected $key = NULL;
    protected $count = NULL;

    protected $isValid = false;

    /**
     * @param Traversable|Iterator_Base $data
     * @param callable $callback Будет вызываться на каждый next c итератором $data в качестве параметра.
     * Ответом ожидается массив ['value' => ..., 'valid' => bool]
     */
    public function __construct($data, callable $callback) {
        $this->dataIterator = $this->getIterator($data);
        $this->nextCallback = $callback;
    }

    public function next() {
        $this->calcCurrent();
        $this->key++;
    }

    public function current() {
        return $this->value;
    }

    public function valid() {
        return $this->isValid;
    }

    public function key() {
        return $this->key;
    }

    public function rewind() {
        $this->key = 0;
        $this->dataIterator->rewind();
        $this->calcCurrent();
    }

    public function count() {
        if (!isset($this->count)) {
            throw new Exception('Not implemented yet');
        }

        return $this->count;
    }

    protected function calcCurrent() {
        $resultPair = call_user_func($this->nextCallback, $this->dataIterator);
        $this->isValid = $resultPair['valid'];
        $this->value = $resultPair['value'];
    }
}