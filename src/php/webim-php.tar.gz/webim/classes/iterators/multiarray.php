<?php

/**
 * Class Iterator_MultiArray
 * Итератор разворачивае двумерный массив (или иной Traversable объект) в одномерный, ключи не сохраняются
 * Создан для прозрачной работы с lazy-запросами к базе.
 * [[a,b,c], [d,e]] => [a,b,c,d,e]
 */
class Iterator_MultiArray extends Iterator_Base {
    protected $data = NULL;
    /**
     * @var null|Iterator
     */
    protected $dataIterator = NULL;
    /**
     * @var null|Iterator
     */
    protected $dataBlockIterator = NULL;
    protected $position = NULL;
    protected $value = NULL;
    protected $count = NULL;

    /**
     * @param array|Iterator_Base $data
     */
    public function __construct($data) {
        $this->data = $data;
        $this->dataIterator = $this->getIterator($data);
    }

    public function key() {
        return $this->position;
    }

    public function current() {
        return $this->dataBlockIterator->current();
    }

    public function next() {
        $this->dataBlockIterator->next();
        if (!$this->dataBlockIterator->valid()) {
            $this->toNextNotEmptyDataBlock();
        }

        if ($this->dataBlockIterator->valid()) {
            $this->position++;
        }
    }

    public function rewind() {
        $this->dataIterator->rewind();
        $this->changeDataBlockByCurrent();
        if (!$this->dataBlockIterator->valid()) {
            $this->toNextNotEmptyDataBlock();
        }
        $this->position = 0;
    }

    public function valid() {
        return $this->dataIterator->valid() && $this->dataBlockIterator->valid();
    }

    public function count() {
        if (!isset($this->count)) {
            $this->count = 0;
            foreach ($this->data as $row) {
                $this->count += count($row);
            }
        }

        return $this->count;
    }

    protected function changeDataBlockByCurrent() {
        if ($this->dataIterator->valid()) {
            $this->dataBlockIterator = $this->getIterator($this->dataIterator->current());
            $this->dataBlockIterator->rewind();
        }
    }

    protected function toNextNotEmptyDataBlock() {
        $nextBlockFound = false;
        while ($this->dataIterator->valid() && !$nextBlockFound) {
            $this->dataIterator->next();
            $this->changeDataBlockByCurrent();
            if ($this->dataBlockIterator->valid()) {
                $nextBlockFound = true;
            }
        }
    }
}