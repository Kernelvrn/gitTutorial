<?php

/**
 * Class Iterator_Callback
 * Итератор с коолбэком для обработки значения перед возвратом.
 * Позволяет прозрачно работать с lazy-запросами к базе.
 */
class Iterator_Callback extends Iterator_Base {
    protected $data = NULL;
    /**
     * @var Iterator
     */
    protected $dataIterator = null;
    /**
     * @var Callable|null
     */
    protected $callback = null;
    protected $position = null;
    protected $value = null;

    /**
     * @param array|Iterator_Base $data
     * @param Callable $callback
     */
    public function __construct($data, $callback) {
        $this->data = $data;
        $this->callback = $callback;
        $this->dataIterator = $this->getIterator($data);
    }

    public function key() {
        return $this->position;
    }

    public function current() {
        return $this->value;
    }

    public function next() {
        $this->dataIterator->next();
        if ($this->valid()) {
            $this->value = call_user_func($this->callback, $this->dataIterator->current());
            $this->position = $this->dataIterator->key();
        }
    }

    public function rewind() {
        $this->dataIterator->rewind();
        if ($this->valid()) {
            $this->value = call_user_func($this->callback, $this->dataIterator->current());
        }
        $this->position = $this->dataIterator->key();
    }

    public function valid() {
        return $this->dataIterator->valid();
    }

    public function count() {
        return count($this->data);
    }
}