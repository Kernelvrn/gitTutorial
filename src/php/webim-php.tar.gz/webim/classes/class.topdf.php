<?php
/**
 *
 * Firsty you should initialize headers and then you should print data
 *
 */
class ToPDF {

    /**
     *  requires xfvb and wkhtmltopdf applications
     *
     *
     * @param $url
     * @return string
     */
    public static function printUrl($url) {

        $file = '/tmp/webim-'. uniqid() . '.pdf';

        $commandString = "xvfb-run wkhtmltopdf $url $file";
        exec($commandString);

        $pdf = file_get_contents($file);

        unlink($file);

        return $pdf;

    }

    public static function initHeaders() {
        header("Content-type: application/pdf");
        header("Content-Disposition: attachment; filename=checkout.pdf");
    }
}