<?php

class Wrapper_SelectQuery {
    protected $db = NULL;

    protected $queryParts = NULL;
    protected $queryParams = NULL;

    protected $options = NULL;
    protected $defaultOptions = array(
        'rowsPerRequest' => 0,
        'countLimit' => 0
    );
    protected $currentStart = 0;
    protected $fetchEnded = false;

    protected $lastAllQueryResource = NULL;

    protected $count = NULL;

    /**
     * $queryParts -  конфиг запроса к базе
     *      ['fields'] string[]|string  Возвращаемые поля
     *      ['tables'] string[]|string  Используемые таблицы
     *      ['joins'] string[]|string   join-ы полностью
     *      ['where'] string[]|string   where запрос, массив будет собран через AND
     *      ['order'] string[]|string    поля для сортировки
     *      ['group'] string[]|string    поля для группировки
     *      ['limit'] int[string]|string максимальное количество строк для возврата
     *          ['start'] int               с какой позиции возвращаем
     *          ['length'] int              сколько максимум
     * $options - опции запроса
     *      ['rowsPerRequest'] int=0 количество строк запрашиваемое за один раз. Позволяет сокращать объём
     * памяти используемой единовременно увеличивая число запросов к базе. 0 - не ограничено
     *      ['countLimit'] int=0 максимальное количество строк при запросе их числа. Позволяет упрощать запросы
     * к большим таблицам, если нет необходимости в точности
     *
     *
     * @param DBDriver $db объект для доступа с базе
     * @param mixed[string] $queryParts конфиг запроса к базе
     * @param mixed[string] $queryParams параметры подставляемые в запрос
     * @param mixed[string] $options опции запроса
     */
    public function __construct(DBDriver $db, array $queryParts, array $queryParams = NULL, array $options = NULL) {
        $this->db = $db;
        $this->queryParts = $queryParts;
        if (!empty($this->queryParts['limit'])) {
            if(!is_array($this->queryParts['limit'])) {
                $limits = explode(',', $this->queryParts['limit']);
                switch (count($limits)) {
                    case 2:
                        $this->queryParts['limit'] = array(
                            'start' => intval($limits[0]),
                            'length' => intval($limits[1])
                        );
                        break;
                    case 1:
                        $this->queryParts['limit'] = array(
                            'start' => 0,
                            'length' => intval($limits[0])
                        );
                }
            }

            if (!array_key_exists('start', $this->queryParts['limit'])) {
                $this->queryParts['limit']['start'] = 0;
            }
        }
        $this->queryParams = $queryParams;
        $this->options = !empty($options) ? array_merge($this->defaultOptions, $options) : $this->defaultOptions;
    }

    /**
     * Выполняет запрос и возвращает результурующий массив, результат кэшируется в объекте после первого выполнения
     * Стоит учитывать, что дополнительных оптимизаций не проводится и на большие запросы может не хватить памяти
     * @param bool $notUseCache не использовать кэш
     * @return mixed[string]
     */
    public function fetchAll($notUseCache = false) {
        if ($notUseCache) {
            if (!empty($this->lastAllQueryResource)) {
                mysql_free_result($this->lastAllQueryResource);
            }
            $this->lastAllQueryResource = NULL;
        }

        if (empty($this->lastAllQueryResource)) {
            $this->lastAllQueryResource = $this->db->Query($this->makeSqlQuery($this->queryParts), $this->queryParams);
        } else if (mysql_num_rows($this->lastAllQueryResource)) {
            mysql_data_seek($this->lastAllQueryResource, 0);
        }

        return $this->resourceToArray($this->lastAllQueryResource);
    }

    /**
     * Возвращает очередные rowsPerRequest строк, переводя внутренний указатель на слдующий блок.
     * Если опция rowsPerRequest=0 - эквивалентно fetchAll.
     * @return array
     */
    public function fetchNext() {
        $result = array();
        if (!$this->fetchEnded) {
            if (!empty($this->options['rowsPerRequest'])) {
                $queryParts = $this->queryParts;
                if (!empty($queryParts['limit'])) {
                    $this->currentStart = $limitStart = max(
                        $queryParts['limit']['start'],
                        $this->currentStart
                    );
                    $limitLength = min(
                        !empty($queryParts['limit']['length']) ? $queryParts['limit']['length'] + $queryParts['limit']['start'] - $limitStart : $this->options['rowsPerRequest'],
                        $this->options['rowsPerRequest']
                    );

                    if (!empty($queryParts['limit']['length']) && $queryParts['limit']['length'] + $queryParts['limit']['start'] <= $limitStart) {
                        $this->fetchEnded = true;
                        return array();
                    }
                } else {
                    $limitStart = $this->currentStart;
                    $limitLength = $this->options['rowsPerRequest'];
                }

                $queryParts['limit'] = array(
                    'start' => $limitStart,
                    'length' => $limitLength
                );

                $res = $this->db->Query($this->makeSqlQuery($queryParts), $this->queryParams);
                $result = $this->resourceToArray($res);
                $this->currentStart += $limitLength;

                if (empty($result)) {
                    $this->fetchEnded = true;
                }
            } else {
                $this->fetchEnded = true;
                $result = $this->fetchAll();
            }
        }
        return $result;
    }

    /**
     * Вызываем, что бы следующие fetch снова шли с начала выборки.
     */
    public function rewind() {
        $this->currentStart = 0;
        $this->fetchEnded = false;
    }

    /**
     * Возвращает количество строк, которое можно получить в запросе.
     * @return int
     */
    public function count() {
        if (!isset($this->count)) {
            $this->count = 0;
            $this->db->Query($this->makeSqlQuery($this->queryParts, array(
                'count' => true,
                'countLimit' => $this->options['countLimit']
            )), $this->queryParams);
            if ($this->db->nextRecord()) {
                $row = $this->db->getRow();
                $this->count = $row['count'];
            }

        }

        return $this->count;
    }

    /**
     * Преобразует конфиг запроса в sql строку с учётом переданных опций
     * $options
     *      ['count'] bool=false    Возвращаем количество строк в резудьтате запроса
     *
     * @param mixed['string'] $queryParts
     * @param mixed['string'] $options
     * @return string
     */
    protected function makeSqlQuery(array $queryParts, array $options = NULL) {
        $defaultOptions = array(
            'count' => false,
            'countLimit' => 0
        );
        $options = !empty($options) ? array_merge($defaultOptions, $options) : $defaultOptions;
        foreach (array('fields', 'tables', 'joins', 'where') as $key) {
            if (array_key_exists($key, $queryParts)) {
                $queryParts[$key] = !is_array($queryParts[$key]) ? array($queryParts[$key]) : $queryParts[$key];
            }
        }
        $sqlQuery = 'SELECT ' . ($options['count'] ? 'COUNT(*) count' : implode(', ', $queryParts['fields']));

        $sqlFromWhere = ' FROM ' . implode(', ', $queryParts['tables'])
            . (!empty($queryParts['joins']) ? ' ' . implode(' ', $queryParts['joins']) : '')
            . (!empty($queryParts['where']) ? ' WHERE ' . implode(' AND ', $queryParts['where']) : '');

        if (!empty($queryParts['group'])) {
                $groupBy = ' GROUP BY ' . (is_array($queryParts['group']) ? implode(', ', $queryParts['group']) : $queryParts['group']);
        } else {
                $groupBy = '';
        }

        if ($options['countLimit']) {
            $sqlQuery .= ' FROM (SELECT ' . implode(', ', $queryParts['fields']) . $sqlFromWhere . $groupBy . ' LIMIT ' . intval($options['countLimit']) . ') st';
        } else {
            $sqlQuery .= $sqlFromWhere . $groupBy;
        }

        if (!empty($queryParts['order']) && !$options['count']) {
            $sqlQuery .= ' ORDER BY ' . (is_array($queryParts['order']) ? implode(', ', $queryParts['order']) : $queryParts['order']);
        }

        if (!empty($queryParts['limit']) && !$options['count']) {
            $sqlQuery .= ' LIMIT ' . intval($queryParts['limit']['start']) . ',' . intval($queryParts['limit']['length']);
        }

        return $sqlQuery;
    }

    protected function resourceToArray($res) {
        $result = array();
        while ($row = mysql_fetch_assoc($res)) {
            $result[] = $row;
        }

        return $result;
    }

    public function _destruct() {
        if (!empty($this->lastAllQueryResource)) {
            mysql_free_result($this->lastAllQueryResource);
        }
    }

}