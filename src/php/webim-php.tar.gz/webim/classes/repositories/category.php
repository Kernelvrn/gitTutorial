<?php

class Repository_Category extends Repository_Base {
    protected $categories;

    public function __construct() {
        $this->categories = self::makeCurrentCategoriesTree();
    }

    /**
     * @param $id
     * @return Model_Category|null
     */
    public function findById($id) {
        return array_key_exists($id, $this->categories) ? $this->categories[$id] : NULL;
    }

    /**
     * @return Model_Category[]
     */
    public function getAll() {
        return $this->categories;
    }

    /**
     * Возвращает дерево толкьо существующих на данный момент категорий,
     * без любых дополнительных связей, которые могли появится в процессе исполнения
     * (по сути создаёт новое дерево на основе настроек). Использовать для формирования
     * различных списков и меню.
     * @return Model_Category[]
     */
    public function getOnlyCurrent() {
        return self::makeCurrentCategoriesTree();
    }

    protected static function makeCurrentCategoriesTree() {
        $tree = array();
        $currentCategories = Settings::GetCategories();
        if (is_array($currentCategories)) {
            foreach ($currentCategories as $rawCategory) {
                $category = new Model_Category($rawCategory['name']);
                $tree[$category->getId()] = $category;
                if (!empty($rawCategory['children'])) {
                    foreach ($rawCategory['children'] as $child) {
                        $category->addChildByTitle($child['name']);
                        $tree[$category->getChildByTitle($child['name'])->getId()] = $category->getChildByTitle($child['name']);
                    }
                }
            }
        }
        ksort($tree);
        return $tree;
    }
}