<?php
class Repository_Rate extends Repository_Base {
    /**
     * @var null|RateMapper
     */
    protected $rateMapper = NULL;
    /**
     * @var null|Repository_Operator
     */
    protected $operatorRepository = NULL;

    public function __construct() {
        $this->rateMapper = MapperFactory::getRateMapper();
        $this->operatorRepository = Factory_Repository::create('Operator');
    }

    /**
     * @param $id
     * @return Model_Rate|null
     */
    public function findById($id) {
        $row = $this->rateMapper->getById($id);
        return !empty($row) ? new Model_Rate($row) : NULL;
    }

    /**
     * @param Model_Thread $thread
     * @return Model_Rate[]
     */
    public function findByThread(Model_Thread $thread) {
        $result = array();
        $rows = $this->rateMapper->getByThreadId($thread->getId());
        if (!empty($rows)) {
            $assocOperators = $this->findOperatorsByRateRows($rows);
            foreach ($rows as $row) {
                $row['operator'] = !empty($assocOperators[$row['operatorid']])
                    ? $assocOperators[$row['operatorid']]
                    : NULL;

                $result[] = new Model_Rate($row);
            }
        }

        return $result;
    }

    /**
     * @param array $ids
     * @return array Двумерный массив вида threadId => Model_Rate[]
     */
    public function findByThreadIds(array $ids) {
        $result = array();
        $rows = $this->rateMapper->getRatesByThreadIds($ids);
        if (!empty($rows)) {
            $assocOperators = $this->findOperatorsByRateRows($rows);
            foreach ($rows as $row) {
                $row['operator'] = !empty($assocOperators[$row['operatorid']])
                    ? $assocOperators[$row['operatorid']]
                    : NULL;
                $rate = new Model_Rate($row);
                $result[$rate->getThreadId()][] = $rate;
            }
        }
        return $result;
    }

    /**
     * @param array $rows
     * @return Model_Operator[] operatorId => Model_Operator
     */
    protected function findOperatorsByRateRows(array $rows) {
        $assocOperators = array();
        $operatorIds = array();
        foreach ($rows as $row) {
            $operatorIds[] = $row['operatorid'];
        }

        $operators = $this->operatorRepository->findByIds($operatorIds);
        foreach ($operators as $operator) {
            $assocOperators[$operator->getId()] = $operator;
        }

        return $assocOperators;
    }
}