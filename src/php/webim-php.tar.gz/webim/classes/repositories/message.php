<?php

class Repository_Message extends Repository_Base {
    /**
     * @var null|MessageMapper
     */
    protected $messageMapper = NULL;

    public function __construct() {
        $this->messageMapper = MapperFactory::getMessageMapper();
    }

    public function findById($id) {
        $row = $this->messageMapper->getById($id);
        return !empty($row) ? Factory_Message::create($row['kind'], $row) : NULL;
    }

    public function getAll() {
        $result = array();
        $rows = $this->messageMapper->getAll();
        foreach ($rows as $row) {
            $result[] = Factory_Message::create($row['kind'], $row);
        }

        return $result;
    }

    public function findByThread(Model_Thread $thread) {
        $result = array();
        $rows = $this->messageMapper->getMessagesByThreadIds(array($thread->getId()));
        foreach ($rows as $row) {
            $result[] = Factory_Message::create($row['kind'], $row);
        }

        return $result;
    }

    /**
     * @param int[] $threadIds
     * @return array Двумерный массив threadId => Model_Message[]
     */
    public function findByThreadIds(array $threadIds) {
        $result = array();
        if (!empty($threadIds)) {
            $rows = $this->messageMapper->getMessagesByThreadIds($threadIds);
            foreach ($rows as $row) {
                $message = Factory_Message::create($row['kind'], $row);
                $result[$message->getThreadId()][] = $message;
            }
        }

        return $result;
    }
}