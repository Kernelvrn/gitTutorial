<?php

class Repository_Department extends Repository_Base {
    /**
     * @var DepartmentMapper|null
     */
    protected $departmentMapper = NULL;
    /**
     * @var null|DepartmentLocaleMapper
     */
    protected $departmentLocaleMapper = NULL;

    public function __construct() {
        $this->departmentMapper = MapperFactory::getDepartmentMapper();
        $this->departmentLocaleMapper = MapperFactory::getDepartmentLocaleMapper();
    }

    public function findById($id) {
        $row = $this->departmentMapper->getById($id);
        if (!empty($row)) {
            $row = array_shift($this->addLocales(array($row)));
        }

        return !empty($row) ? new Model_Department($row) : NULL;
    }

    public function findByIds(array $ids) {
        $models = array();
        $rows = $this->departmentMapper->getDepartmentByIds($ids);
        if (!empty($rows)) {
            $rows = $this->addLocales($rows);
            foreach ($rows as $row) {
                $models[] = new Model_Department($row);
            }
        }

        return $models;
    }

    public function findByKey($key) {
        if (isset($key)) {
            $row = $this->departmentMapper->getByDepartmentKey($key);
            if (!empty($row)) {
                $row = array_shift($this->addLocales(array($row)));
            }
            return !empty($row) ? new Model_Department($row) : NULL;
        } else {
            return NULL;
        }
    }

    public function getAll() {
        $rows = $this->departmentMapper->getAll();
        return $this->rowsToModels($rows);
    }

    public function getNonDeletedDepartments() {
        $rows = $this->departmentMapper->enumDepartments(Resources::getCurrentLocale());
        return $this->rowsToModels($rows);
    }

    public function getDeletedDepartments() {
        $rows = $this->departmentMapper->enumDeletedDepartments(Resources::getCurrentLocale());
        return $this->rowsToModels($rows);
    }

    protected function rowsToModels($rows) {
        $models = array();
        if (!empty($rows)) {
            $rows = $this->addLocales($rows);
            foreach ($rows as $row) {
                $models[] = new Model_Department($row);
            }
        }
        return $models;
    }

    public function save(Model_Department $model) {
        $row = $model->toDBRow();

        if (!empty($row['departmentid'])) {
            $id = $row['departmentid'];
            $this->departmentMapper->save($row);
        } else {
            if (empty($row['departmentorder'])) {
                $row['departmentorder'] = intval($this->departmentMapper->getMaxOrder() / 100) * 100 + 100;
                $model->setOrder($row['departmentorder']);
            }
            if (empty($row['departmentkey'])) {
                $row['departmentkey'] = $this->generateUniqueDepartmentKeyByName($model->getNameByLocale(Resources::getCurrentLocale()));
                $model->setKey($row['departmentkey']);
            }
            $id = $this->departmentMapper->save($row);
            $model->setId($id);
        }
        $departmentLocaleRow = array(
            'departmentname' => $model->getNameByLocale(Resources::getCurrentLocale()),
            'locale' => Resources::getCurrentLocale()
        );
        $localeId = $this->departmentLocaleMapper->getDepartmentLocale($id, Resources::getCurrentLocale());
        if (!empty($localeId)) {
            $departmentLocaleRow['departmentlocaleid'] = $localeId['departmentlocaleid'];
        }

        $departmentLocaleRow['departmentid'] = $id;
        $this->departmentLocaleMapper->save($departmentLocaleRow);
        Helper::clearDepartmentsCache();

        return $id;
    }

    public function remove(Model_Department $model) {
        $this->departmentMapper->deleteDepartment($model->getId());
    }

    protected function addLocales(array $rows) {
        $rowsWithLocales = array();
        if (!empty($rows)) {
            $localeRows = $this->departmentLocaleMapper->getDepartmentLocalesByIds(
                Helper::getColumnFromArray($rows, 'departmentid')
            );
            $localeRowsByDepartment = array();
            foreach ($localeRows as $localeRow) {
                $departmentId = $localeRow['departmentid'];
                $locale = $localeRow['locale'];
                if (!empty($localeRow['departmentname'])) {
                    $localeRowsByDepartment[$departmentId]['names'][$locale] = $localeRow['departmentname'];
                }

                if (!empty($localeRow['answers'])) {
                    $localeRowsByDepartment[$departmentId]['answers'][$locale] = json_decode($localeRow['answers'], true);
                }
            }

            foreach ($rows as $row) {
                if (!empty($localeRowsByDepartment[$row['departmentid']])) {
                    $rowsWithLocales[] = array_merge($row, $localeRowsByDepartment[$row['departmentid']]);
                } else {
                    $rowsWithLocales[] = $row;
                }
            }
        }

        return $rowsWithLocales;
    }

    private function generateUniqueDepartmentKeyByName($name) {
        $key = strip_tags($name);
        if (function_exists('transliterator_transliterate')) {
            $key = transliterator_transliterate('Any-Latin; Latin-ASCII; Lower()', $key);
        } else {
            $key = smarticonv(WEBIM_ENCODING, 'latin', $key);
        }
        $key = preg_replace('/\s+/', '_', $key);
        $key = preg_replace('/[^\w\_\.\d]/', '', $key);
        $key = strtolower($key);

        $departments = $this->departmentMapper->enumDepartments(Resources::getCurrentLocale());
        $departmentKeys = Helper::getColumnFromArray($departments, 'departmentkey');

        if (!empty($departmentKeys)) {
            while(in_array($key, $departmentKeys)) {
                $tokens = explode('__', $key);
                $next_value = count($tokens) > 1 ? intval($tokens[1]) : 0;
                $next_value++;
                $key = $tokens[0] . '__' . $next_value;
            }
        }

        return $key;
    }
}