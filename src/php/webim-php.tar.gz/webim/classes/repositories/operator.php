<?php

/**
 * Class Repository_Operator
 * Данный репозиторий работает только с операторами текущего аккаунта.
 */
class Repository_Operator extends Repository_Base {
    /**
     * @var null|OperatorAccountViewMapper
     */
    protected $operatorAccountViewMapper = NULL;

    public function __construct() {
        $this->operatorAccountViewMapper = MapperFactory::getOperatorAccountViewMapper();
    }

    public function findById($id) {
            $row = $this->operatorAccountViewMapper->getByOperatorIdAndAccount($id, getAccountId());
            $model = !empty($row) ? new Model_Operator($row) : NULL;

        return $model;
    }

    public function findByIds(array $ids) {
        $models = array();
        $rows = $this->operatorAccountViewMapper->enumOperatorsByAccountAndIds(getAccountId(), $ids);
        foreach ($rows as $row) {
            $models[] = new Model_Operator($row);
        }

        return $models;
    }

    public function getAll() {
        $models = array();
        $rows = $this->operatorAccountViewMapper->listOperatorsByAccount(getAccountId());
        foreach ($rows as $row) {
            $models[] = new Model_Operator($row);
        }

        return $models;
    }
}