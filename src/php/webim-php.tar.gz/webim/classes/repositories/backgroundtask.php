<?php
class Repository_BackgroundTask extends Repository_Base {
    /**
     * @var BackgroundTaskMapper|null
     */
    protected $taskMapper = NULL;

    public function __construct() {
        $this->taskMapper = MapperFactory::getBackgroundTaskMapper();
    }

    /**
     * @param Model_BackgroundTask_Base|Model_BackgroundTask_Base[] $models
     * @return bool
     */
    public function save($models) {
        $forSave = is_array($models)
            ? $models
            : array($models);
        foreach ($forSave as $model) {
            $id = $this->taskMapper->save($model->toRow());
            if (!$model->getId()) {
                $model->setId($id);
            }
        }

        return true;
    }

    /**
     * @param $id
     * @return Model_BackgroundTask_Base|null
     */
    public function findById($id) {
        $row = $this->taskMapper->getById($id);
        return !empty($row) ? Factory_BackgroundTask::create($row['key'], $row) : NULL;
    }

    /**
     * @param $key
     * @return Model_BackgroundTask_Base[]
     */
    public function findByKey($key) {
        $result = array();
        $rows = $this->taskMapper->getByKey($key);
        foreach ($rows as $taskRow) {
            $result[] = Factory_BackgroundTask::create($taskRow['key'], $taskRow);
        }

        return $result;
    }

    /**
     * @param $key
     * @return Model_BackgroundTask_Base|null
     */
    public function findLastByKey($key) {
        $row = $this->taskMapper->getLastByKey($key);
        return !empty($row) ? Factory_BackgroundTask::create($row['key'], $row) : NULL;
    }

    /**
     * @return Model_BackgroundTask_Base[]
     */
    public function getAll() {
        $result = array();
        $rows = $this->taskMapper->getAll();
        foreach ($rows as $taskRow) {
            $result[] = Factory_BackgroundTask::create($taskRow['key'], $taskRow);
        }

        return $result;
    }
}