<?php
class Repository_Callback {
    public function search(array $filters) {
        $callbacks = MapperFactory::getCallbackMapper()->search($filters);

        return new Iterator_Callback($callbacks, function($callbackRow) {
            return new Model_Callback($callbackRow);
        });
    }
}