<?php

/**
 * Class Repository_Statistics
 * Возвращает векторы метрик. Работает с кэшированными данными из chatstats.
 */
class Repository_Statistics extends Repository_Base {
    /**
     * @var StatsMapper
     */
    protected $statsMapper;

    public function __construct() {
        $this->statsMapper = MapperFactory::getStatsMapper();
    }

    /**
     * @param string $type
     * @param array $filters
     * @return Traversable
     */
    public function search($type, $filters) {
        if (ucfirst($type) === 'OperatorTime') {
            return $this->getOperatorTime($filters);
        }

        if (ucfirst($type) === 'ThreadMessage') {
            return $this->getChats($filters);
        }

        if (ucfirst($type) === 'OperatorStatusTime') {
            return $this->getOperatorStatusTime($filters);
        }

        $iterator = new Iterator_Query(
            $this->statsMapper->getStatsVectorsQuery($type, $filters, self::getAccountSettings())
        );

        return new Iterator_Group($iterator, function($queryIterator) use($type) {
            /** @var $queryIterator Iterator_Query */
            $result = array(
                'value' => NULL,
                'valid' => true
            );

            $values = array();
            $dimension = NULL;
            while ($queryIterator->valid()) {
                $row = $queryIterator->current();
                if (!$dimension) {
                    $dimension = Factory_StatsDimensions::createByStatsRow($row);
                } else {
                    if ($dimension != Factory_StatsDimensions::createByStatsRow($row)) {
                        break;
                    }
                }
                $values[$row['param_name']] = $row;
                $queryIterator->next();
            }

            if (count($values)) {
                $result['value'] = Factory_StatsVector::create($type, $dimension, $values);
            } else {
                $result['valid'] = false;
            }

            return $result;
        });
    }

    public function getStatsTotal($type, $filters) {
        $queryIterator = new Iterator_Query(
            $this->statsMapper->getTotalStatsQuery($type, $filters, self::getAccountSettings())
        );

        $values = array();
        foreach ($queryIterator as $row) {
            $values[$row['param_name']] = $row;
        }

        return Factory_StatsVector::create($type, NULL, $values);
    }

    /**
     * @param Statistic_Vector|Statistic_Vector_OperatorTime[] $vectors
     * @return bool
     */
    public function save($vectors) {
        $vectors = $vectors instanceof Traversable
            ? $vectors
            : array($vectors);

        $this->operatorTimeMapper->saveRows(self::vectorsToRowsGen($vectors));
        return true;
    }

    /**
     * Прототип для проверки гипотез. потребуется полный рефакторинг
     * @param $filtersArr
     * @return Traversable|array
     */
    protected function getOperatorTime($filtersArr) {
        $filters = new Statistic_Filters($filtersArr);
        $metricNames =array('onlineTime', 'privateTime', 'dinnerTime', 'preDinnerTime', 'invisibleTime', 'chattingTime');
        $metrics = array();
        foreach ($metricNames as $metricName) {
            $metrics[$metricName] = Factory_StatsMetric::create($metricName)->calc($filters);
        }

        $vectors = array();
        $step = new DateInterval('PT' . Settings::Get('statistics_min_period') . 'S');
        foreach ($this->datePeriodGen($filters->getStartDate(), $filters->getEndDate(), $step) as $startPeriod) {
            $values = array();
            $key = $startPeriod->format('Y-m-d H:i:s');
            foreach ($metricNames as $metricName) {
                $values[$metricName] = array_key_exists($key, $metrics[$metricName])
                    ? $metrics[$metricName][$key]
                    : 0;
            }

            $vectors[] = new Statistic_Vector(
                Factory_StatsDimensions::create(array(
                    'period' => array(
                        'dtm' => clone $startPeriod,
                        'length' => $step
                    ),
                    'operators' => $filters->getOperators()
                )),
                $values
            );
        }
        return $vectors;
    }

    protected function getOperatorStatusTime($filtersArr) {
        $filters = new Statistic_Filters($filtersArr);
        $metricNames =array('onlineTime', 'privateTime', 'dinnerTime', 'preDinnerTime', 'invisibleTime');
        $values = array();
        foreach ($metricNames as $metricName) {
            $metricValues = Factory_StatsMetric::create($metricName)->calcSumStatusTime($filters);
            foreach ($metricValues as $operatorId => $statusTime) {
                $values[$operatorId][$metricName] = $statusTime;
            }
        }

        $operators = Factory_Repository::create('operator')->getAll();
        $idToOperators = array();
        foreach ($operators as $operator) {
            $idToOperators[$operator->getId()] = $operator;
        }
        $vectors = array();
        foreach ($values as $operatorId => $row) {
            $vectors[] = new Statistic_Vector(
                Factory_StatsDimensions::create(array(
                    'operators' => $idToOperators[$operatorId]
                )),
                $row
            );
        }

        return $vectors;
    }


    /**
     * @param $filtersArr
     * @return Traversable|array
     */
    protected function getChats($filtersArr) {
        $filters = new Statistic_Filters($filtersArr);
        $metricNames =array('messageLength');
        $metrics = array();
        foreach ($metricNames as $metricName) {
            $metrics[$metricName] = Factory_StatsMetric::create($metricName)->calc($filters);
        }
        $vectors = array();
        $step = new DateInterval('PT' . Settings::Get('statistics_min_period') . 'S');

        foreach ($this->datePeriodGen($filters->getStartDate(), $filters->getEndDate(), $step) as $startPeriod) {
            $values = array();
            $key = $startPeriod->format('Y-m-d H:i:s');
            foreach ($metricNames as $metricName) {
                $values[$metricName] = array_key_exists($key, $metrics[$metricName])
                    ? $metrics[$metricName][$key]
                    : 0;
            }

            $vectors[] = new Statistic_Vector(
                Factory_StatsDimensions::create(array(
                    'period' => array(
                        'dtm' => clone $startPeriod,
                        'length' => $step
                    ),
                    'operators' => $filters->getOperators()
                )),
                $values
            );
        }
        return $vectors;
    }

    protected static function getAccountSettings() {
        return array(
            'stats_fields_include' => Settings::Get('stats_fields_include'),
            'stats_fields_exclude' => Settings::Get('stats_fields_exclude')
        );
    }

    protected function datePeriodGen(DateTime $start, DateTime $end, DateInterval $step) {
        $current = clone $start;
        while ($current < $end) {
            yield $current;
            $current->add($step);
        }
    }

}

