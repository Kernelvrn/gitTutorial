<?php
class Repository_Thread extends Repository_Base {
    /**
     * @var null|Repository_Rate
     */
    protected $rateRepository = NULL;

    public function __construct() {
        $this->threadMapper = MapperFactory::getThreadMapper();
    }

    /**
     * Возвращает обращения согласно фильтрам
     * @param array $filters
     * @param bool $withRelativeData Предзагружать ли связанные с обращениями модели сообщений, операторов и т.д.
     * @return Iterator_Query
     */
    public function search(array $filters, $withRelativeData = false) {
        $iterator = new Iterator_Query($this->threadMapper->searchThreads($filters));
        $iterator->addFetchCallback(function($threadsRows) use($withRelativeData) {
            $threads = array();
            if (!empty($threadsRows)) {
                $threadIds = Helper::getColumnFromArray($threadsRows, 'threadid');
                /** @var $sessionRepository Repository_VisitorSession */
                $sessionRepository = Factory_Repository::create('VisitorSession');
                $sessions = $sessionRepository->findByThreadIds($threadIds);
                $messages = array();
                $rates = array();
                $history = array();
                if ($withRelativeData) {
                    /**
                     * @var $messageRepository Repository_Message
                     * @var $rateRepository Repository_Rate
                     * @var $threadHistoryRepository Repository_ThreadHistory
                     */
                    $messageRepository = Factory_Repository::create('Message');
                    $rateRepository = Factory_Repository::create('Rate');
                    $threadHistoryRepository = Factory_Repository::create('ThreadHistory');
                    $messages = $messageRepository->findByThreadIds($threadIds);
                    $rates = $rateRepository->findByThreadIds($threadIds);
                    $history = $threadHistoryRepository->findByThreadIds($threadIds);
                }

                foreach ($threadsRows as $threadRow) {
                    if ($withRelativeData) {
                        $threadRow['messages'] = !empty($messages[$threadRow['threadid']])
                            ? $messages[$threadRow['threadid']]
                            : array();
                        $threadRow['rates'] = !empty($rates[$threadRow['threadid']])
                            ? $rates[$threadRow['threadid']]
                            : array();
                        $threadRow['history'] = !empty($history[$threadRow['threadid']])
                            ? $history[$threadRow['threadid']]
                            : array();
                    }

                    $threadRow['session'] = !empty($sessions[$threadRow['threadid']])
                        ? $sessions[$threadRow['threadid']]
                        : NULL;

                    $threads[] = new Model_Thread($threadRow);
                }
            }
            return $threads;
        });

        return $iterator;
    }
}