<?php
class Repository_Visitor {
    public function findAll() {
        $sessions = MapperFactory::getVisitSessionMapper()->getSessionsWithVisitorsData();
        $visitors = new Iterator_Callback(new Iterator_Query($sessions), function($session) {
            $json = json_decode($session['json'], true);
            $visitorRow = array();
            if (!empty($json['visitor'])) {
                $visitorRow = array_merge(
                    array(
                        'visitorid' => $session['id'],
                        'created' => $session['created']
                    ),
                    !empty($json['visitor']['fields']) ? $json['visitor']['fields'] : array(),
                    !empty($json['visitor']['providedFields']) ? $json['visitor']['providedFields'] : array()
                );
                if (array_key_exists('crc', $visitorRow)) {
                    unset($visitorRow['crc']);
                }
            }
            return $visitorRow;
        });

        return $visitors;
    }
}