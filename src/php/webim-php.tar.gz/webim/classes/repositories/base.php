<?php

/**
 * Class Repository_Base
 * Базовый класс репозитория - коллекции по работе с объектами моделями.
 * Обеспечивает слой абстракции по доступу к хранилищу данных
 */
abstract class Repository_Base {
    /**
     * Добавляет или обновляет модель в хранилище
     * @param Object|Object[] $object
     * @return bool
     * @throws Exception
     */
    public function save($object) {
        throw new Exception('Not implement yet');
    }

    /**
     * Ищет модель по ID
     * @param $id
     * @return Model_Base|null
     * @throws Exception
     */
    public function findById($id) {
        throw new Exception('Not implement yet');
    }

    /**
     * Ищет сразу нескольо моделей по ID (имеет смысл с точки зрения сокращения количества запросов к базе)
     * @param array $ids
     * @return Model_Base[]
     * @throws Exception
     */
    public function findByIds(array $ids) {
        throw new Exception('Not implement yet');
    }

    /**
     * Возвращает сразу все доступные модели
     * @return Model_Base[]
     * @throws Exception
     */
    public function getAll() {
        throw new Exception('Not implement yet');
    }

    /**
     * Удаляет модель из хранилища
     * @param Model_Base $model
     * @return bool
     * @throws Exception
     */
    public function remove(Model_Base $model) {
        throw new Exception('Not implement yet');
    }
}