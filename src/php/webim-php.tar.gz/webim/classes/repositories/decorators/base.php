<?php

/**
 * Class Repository_Decorator_Base
 * Базовый класс для декораторов репозитория
 */
abstract class Repository_Decorator_Base extends Repository_Base {
    /**
     * @var null|Repository_Base
     */
    protected $repository = NULL;

    public function __construct(Repository_Base $repository) {
        $this->repository = $repository;
    }

    public function save($object) {
        return $this->repository->save($object);
    }

    public function findById($id) {
        return $this->repository->findById($id);
    }

    public function getAll() {
        return $this->repository->getAll();
    }

    public function remove(Model_Base $model) {
        return $this->repository->remove($model);
    }

}