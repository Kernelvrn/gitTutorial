<?php

class Repository_Decorator_Cache extends Repository_Decorator_Base {
    protected $cache = array();

    public function save($object) {
        return $this->repository->save($object);
    }

    public function findById($id) {
        if (!array_key_exists($id, $this->cache)) {
            $model = $this->repository->findById($id);
            if ($model) {
                $this->cache[$id] = $model;
            }
        }

        return array_key_exists($id, $this->cache) ? $this->cache[$id] : NULL;
    }

    public function findByIds(array $ids) {
        $result = array();
        $cacheMissed = array();
        foreach ($ids as $id) {
            if (!empty($this->cache[$id])) {
                $result[] = $this->cache[$id];
            } else {
                $cacheMissed[] = $id;
            }
        }

        if (count($cacheMissed)) {
            $models = $this->repository->findByIds($cacheMissed);
            foreach ($models as $model) {
                $this->cache[$model->getId()] = $model;
                $result[] = $model;
            }
        }

        return $result;
    }

    public function getAll() {
        if (!empty($this->cache)) {
            return $this->cache;
        }
        DoMyLog("EMPTY OPERATOR CACHE");
        $models = $this->repository->getAll();

        $this->cache = array();
        foreach ($models as $model) {
            $this->cache[$model->getId()] = $model;
        }

        return $models;
    }

    public function remove(Model_Base $model) {
        $removeResult = $this->repository->remove($model);
        if ($removeResult && isset($this->cache[$model->getId()])) {
            unset($this->cache[$model->getId()]);
        }
        return $removeResult;
    }

    public function __call($method, $parameters) {
        return call_user_func_array(array($this->repository, $method), $parameters);
    }
}