<?php

class Repository_VisitorSession extends Repository_Base {
    /**
     * @var null|VisitSessionMapper
     */
    protected $sessionMapper = NULL;

    public function __construct() {
        $this->sessionMapper = MapperFactory::getVisitSessionMapper();
    }

    /**
     * @param $id
     * @return Model_VisitorSession|null
     */
    public function findBySessionId($id) {
        $row = $this->sessionMapper->getBySessionId($id);
        return $row ? new Model_VisitorSession($row) : NULL;
    }

    /**
     * @param array $ids
     * @return Model_VisitorSession[] В качестве ключей threadid
     */
    public function findByThreadIds(array $ids) {
        $rows = $this->sessionMapper->getByThreadIds($ids);
        $sessions = array();
        foreach ($rows as $row) {
            $sessions[$row['threadid']] = new Model_VisitorSession($row);
        }

        return $sessions;
    }
}