<?php

class Repository_ThreadHistory extends Repository_Base {
    /**
     * @var null|ThreadHistoryMapper
     */
    protected $threadHistoryMapper = NULL;

    public function __construct() {
        $this->threadHistoryMapper = MapperFactory::getThreadHistoryMapper();
    }

    public function findByThread(Model_Thread $thread) {
        $result = array();
        $rows = $this->threadHistoryMapper->getThreadHistoryByThreadIds(array($thread->getId()));
        foreach ($rows as $row) {
            $result[] = new Model_ThreadHistory($row);
        }

        return $result;
    }

    public function findByThreadIds(array $ids) {
        $result = array();
        $rows = $this->threadHistoryMapper->getThreadHistoryByThreadIds($ids);
        $rows = $this->addDepartments($rows);
        $rows = $this->addOperators($rows);

        foreach ($rows as $row) {
            $model = new Model_ThreadHistory($row);
            $result[$model->getThreadId()][] = $model;
        }

        return $result;
    }

    protected function addOperators(array $rows) {
        if (!empty($rows)) {
            $rowsWithOperator = array();
            $operators = Factory_Repository::create('Operator')->findByIds(
                array_filter(array_unique(Helper::getColumnFromArray($rows, 'operatorid')))
            );

            $assocOperators = array();
            foreach ($operators as $operator) {
                $assocOperators[$operator->getId()] = $operator;
            }

            foreach ($rows as $row) {
                if (!empty($row['operatorid']) && !empty($assocOperators[$row['operatorid']])) {
                    $rowsWithOperator[] = array_merge($row, array('operator' => $assocOperators[$row['operatorid']]));
                } else {
                    $rowsWithOperator[] = $row;
                }
            }

            return $rowsWithOperator;
        }

        return $rows;
    }

    protected function addDepartments(array $rows) {
        if (!empty($rows)) {
            $rowsWithDepartment = array();
            $departments = Factory_Repository::create('Department')->findByIds(
                array_filter(array_unique(Helper::getColumnFromArray($rows, 'departmentid')))
            );
            $assocDepartments = array();
            foreach ($departments as $department) {
                $assocDepartments[$department->getId()] = $department;
            }

            foreach ($rows as $row) {
                if (!empty($row['departmentid']) && !empty($assocOperators[$row['departmentid']])) {
                    $rowsWithDepartment[] = array_merge($row, array('department' => $assocOperators[$row['departmentid']]));
                } else {
                    $rowsWithDepartment[] = $row;
                }
            }

            return $rowsWithDepartment;
        }

        return $rows;
    }
}