<?php

class Repository_Office extends Repository_Base {
    protected $offices;

    public function __construct() {
        $this->offices = array();
        $offices = Settings::Get('offices');
        if (is_array($offices)) {
            foreach ($offices as $officeRow) {
                $this->offices[$officeRow['id']] = new Model_Office($officeRow);
            }
        }
    }

    /**
     * @param $id
     * @return Model_Office|null
     */
    public function findById($id) {
        return array_key_exists($id, $this->offices) ? $this->offices[$id] : NULL;
    }

    /**
     * @return Model_Category[]
     */
    public function getAll() {
        return $this->offices;
    }
}