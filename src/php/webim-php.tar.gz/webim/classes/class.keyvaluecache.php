<?php

class KeyValueCache {

  static private $instance = null;
  static private $accountMapper;

//  static function getInstance() {
//    if (self::$instance == null) {
//      self::$instance = new Account();
//      self::$accountMapper = MapperFactory::getMapper('KeyValueCache');
//
//    }
//    return self::$instance;
//  }
//
//  private function __construct() {
//
//  }
//
//  private function __clone() {
//  }

  public static function ensureClean($kind, $accountName = null) {
    RareRunner::run('key-value-' . $kind, 60 * 60 * 24, function($kind) use (&$accountName) {
      KeyValueCache::cleanUp($kind, $accountName);
    });
  }

  public static function cleanUp($kind, $accountName = null) {
    $dirArray = self::__listAllCacheFilesForKind($kind, $accountName);

    foreach($dirArray as $fileName) {
      self::cleanFile($fileName);
    }
  }

  private static function cleanFile($fileName) {
    if (!file_exists($fileName)) {
      return;
    }

    $content = @file_get_contents($fileName);
    if (empty($content)) {
      return;
    }
    $storedData = unserialize($content);
    $t = get_modified_time($fileName);
    $ttl = $storedData['ttl'];

    if (time() - $t > $ttl) {
      @unlink($fileName);
    }
  }


  /**
   * @param $key
   * @param $data
   * @param string $kind
   * @param int $ttl seconds, -1 for unlimited time
   * @return bool
   */
  public static function put($key, $data, $kind = 'key-value', $ttl = 30000, $accountName = null) { # 30 000 seconds
//    doMyLog('putting to cache: ' . $key . ' ' . print_r($data, true));
//    self::ensureClean($key);

    if (empty($key)) {
      return false;
    }

    $dir = self::_getDirName($kind, $accountName);
    $fileName = self::_getFileName($key, $kind, $accountName);
    $toStore = array('key' => $key, 'ttl' => $ttl, 'data' => $data, 'version' => WEBIM_VERSION);

    create_dir($dir);

    file_put_contents($fileName, serialize($toStore));
    touch($fileName);
//    doMyLog('filename: ' . $fileName);
    return true;
  }

  private static function _getDirName($kind, $accountName = null) {
    global $MAIN_SETTINGS;

    $accountName = $accountName == null ? getAccountId() : $accountName;

    $dir =  $MAIN_SETTINGS['online_dir'] . DIRECTORY_SEPARATOR . substr(md5($accountName), 0, 1) . DIRECTORY_SEPARATOR . $accountName;

    $dir .=  '/key-value-' . $kind;
    return $dir;
  }

  private static function _getFileName($key, $kind, $accountName = null) {
    $dir = self::_getDirName($kind, $accountName);
    $fileName = $dir . '/' . md5($key) . '.txt';
    return $fileName;
  }

  public static function clear($key, $kind = 'key-value', $accountName = null) {
    if (empty($key)) {
      return;
    }
    $fileName = self::_getFileName($key, $kind, $accountName);
//    doMyLog('clearing cache: ' . $fileName);
    @unlink($fileName);
  }

  public static function clearKind($kind = 'key-value', $accountName = null) {
    $dirArray = self::__listAllCacheFilesForKind($kind, $accountName);

    foreach($dirArray as $fileName) {
      @unlink($fileName);
    }
  }

  public static function get($key, $kind = 'key-value', $default = null, $accountName = null) {
////    return $default; // debug
    if (empty($key)) {
      return $default;
    }

    $fileName = self::_getFileName($key, $kind, $accountName);
    if (!file_exists($fileName)) {
      return $default;
    }

    $content = @file_get_contents($fileName);
    if (empty($content)) {
      return $default;
    }
    $storedData = unserialize($content);
    $t = get_modified_time($fileName);
    $ttl = $storedData['ttl'];

    if ($storedData['key'] != $key) {
      return $default;
    }

    if ($ttl != -1 && time() - $t > $ttl) {
      self::clear($key, $kind);
      return $default;
    }

    if (empty($storedData['version']) || $storedData['version'] != WEBIM_VERSION) {
      self::clear($key, $kind);
      return $default;
    }

    return $storedData['data'];
  }

  public static function getCachedResults($key, $kind = 'key-value', $method, $timeout = 3600, $accountName = null) { # 1 hour
    $data = KeyValueCache::get($key, $kind, null, $accountName);
    if ($data !== null) {
      return $data;
    }
    $data = $method();
    KeyValueCache::put($key, $data, $kind, $timeout, $accountName);
    return $data;

  }

  /**
   * @param $kind
   * @return array
   */
  private static function __listAllCacheFilesForKind($kind, $accountName = null) {
    $dir = self::_getDirName($kind, $accountName);

    if (!is_dir($dir)) {
      return array();
    }
    $myDirectory = opendir($dir);

    $dirArray = array();
    // get each entry
    while ($entryName = readdir($myDirectory)) {
      $fileName = $dir . DIRECTORY_SEPARATOR . $entryName;
      if (!is_file($fileName)) {
        continue;
      }
      $dirArray[] = $fileName;
    }

    // close directory
    closedir($myDirectory);
    return $dirArray;
  }
}

?>
