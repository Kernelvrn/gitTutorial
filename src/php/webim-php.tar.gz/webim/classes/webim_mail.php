<?php
require_once(dirname(__FILE__) . '/class.operator.php');
require_once(dirname(__FILE__) . '/class.thread.php');
require_once(dirname(__FILE__) . '/class.visitsession.php');
require_once(dirname(__FILE__) . '/class.resources.php');
require_once(dirname(__FILE__) . '/common.php');


function webim_mail($toaddr, $reply_to, $subject, $body, $contentType = null, $attach = null) {
  global $MAIN_SETTINGS;
  if (isHostedMode()) {
      webim_mail_old($toaddr, $reply_to, $subject, $body, $contentType, $attach);
      return;
  }
  require_once('/usr/share/php/Mailgun/vendor/autoload.php');

  $mg = new Mailgun\Mailgun($MAIN_SETTINGS['mailgun_key']);
  $domain = $MAIN_SETTINGS['devmode'] ? $MAIN_SETTINGS['mailgun_dev_domain'] : Helper::getRootDomain();

//  if ($domain == 'callrf.ru') { // TODO: temp hack
//    $domain = 'webim.ru';
//  }

  if (is_array($reply_to)) {
    $newReplyTo = '';
    foreach ($reply_to as $k => $v) {
      if (is_numeric($k)) {
        $newReplyTo = $v;
      } else {
        $newReplyTo = $v . '<' . $k . '>';
      }
    }
    $reply_to =  $newReplyTo;
  }

//  doMyLog("toaddr: " . print_r($toaddr, true));
//  doMyLog("reply_to: " . $reply_to);
//  doMyLog("subject: " . $subject);
//  doMyLog("Domain: " . $domain);
//  doMyLog("body: " . $body);
//  doMyLog("Key: " . $MAIN_SETTINGS['mailgun_key']);

  # Now, compose and send your message.
//  if () {
//
//  }
//  $mg->sendMessage($domain, array('from' => $reply_to,
//    'reply' => $reply_to,
//    'to' => $toaddr,
//    'bcc' => 'servicesent@webim.ru',
//    'subject' => $subject,
//    $contentType == 'text/html' ? 'html' : 'text' => $body));

  $messageBldr = $mg->MessageBuilder();

  # Define the from address.
  $messageBldr->setFromAddress(Resources::Get("email.from"));
  # Define a to recipient.
  if (is_string($toaddr)) {
    $toaddr = preg_split('/\s*[,;]\s*/', $toaddr);
    doMyLog("Splitting toaddr: " . print_r($toaddr, true));
  }
  if (is_array($toaddr)) {
    foreach ($toaddr as $k => $v) {
      if (is_numeric($k)) {
        if (!empty($v)) {
          $messageBldr->addToRecipient($v);
        }
      } else {
        $messageBldr->addToRecipient($v . "<". $k . ">");
      }
    }
  } else {
    $messageBldr->addToRecipient($toaddr);
  }
  # Define a cc recipient.
//  if (false) { // debug
    if (!empty($MAIN_SETTINGS['email_bcc'])) {
      $messageBldr->addBccRecipient($MAIN_SETTINGS['email_bcc']);
    }
//  } // debug
  # Define the subject.
  $messageBldr->setSubject($subject);
  # Define the body of the message.
  if ($contentType == 'text/html') {
    $messageBldr->setHTMLBody($body);
  } else {
    $messageBldr->setTextBody($body);
  }

  # Other Optional Parameters.
//  $messageBldr->addCampaignId("My-Awesome-Campaign");
//  $messageBldr->setReplyToAddress('noreply@webim.ru');
//  $messageBldr->setReplyToAddress($reply_to);
//  $message = $messageBldr->getMessage();
//  $message['o:native-send'] = 'yes';
//  $message['h:Return-Path'] = 'noreply@webim.ru';
//  $message['h:Reply-To'] = 'noreply@webim.ru';
//  var_dump($message);
//  die();

  $messageBldr->addCustomParameterSingle('o:native-send', 'yes');
//  $messageBldr->addCustomParameterSingle('h:Return-Path', 'noreply@webim.ru');
  $messageBldr->addCustomParameterSingle('h:Reply-To', $reply_to);
//  $messageBldr->addCustomHeader("Return-Path", 'noreply@webim.ru');
//  $messageBldr->addCustomHeader("Reply-To", $reply_to);
//  $messageBldr->addCustomHeader("Reply-To:", 'noreply@webim.ru');
//  $messageBldr->addCustomHeader("Return-Path:", 'noreply@webim.ru');
//  $messageBldr->addCustomHeader("Reply-To", $reply_to);
//  $messageBldr->addCustomHeader("Return-Path", Resources::Get("email.from"));
//  $messageBldr->addCustomHeader("o:tracking", "False");
  $messageBldr->setClickTracking(false);
//  $messageBldr->addAttachment("@/tron.jpg");
//  $messageBldr->setDeliveryTime("tomorrow 8:00AM", "PST");
//  $messageBldr->setClickTracking(true);

  $message = $messageBldr->getMessage();
  doMyLog(print_r($message, true));
  # Finally, send the message.
//  if (isMyIP()) {
//    die();
//  }
  $mg->post("{$domain}/messages", $messageBldr->getMessage());
}

function webim_mail_old($toaddr, $reply_to, $subject, $body, $contentType = null, $attach = null) {
    global $MAIN_SETTINGS;
//  if (isMyIP()) {
//    return webim_mail_mailgun($toaddr, $reply_to, $subject, $body, $contentType, $attach);
//
//  }
//  require_once('/usr/share/php/Swift/swift_required.php');
  /*x*/
  //  if (WEBIM_ENCODING != MAIL_ENCODING) {
  //    $reply_to = smarticonv(WEBIM_ENCODING, MAIL_ENCODING, $reply_to);
  //    $body = smarticonv(WEBIM_ENCODING, MAIL_ENCODING, $body);
  //    $subject = smarticonv(WEBIM_ENCODING, MAIL_ENCODING, $subject);
  //  }
  /*end x*/

  Swift_Preferences::getInstance()->setCharset(MAIL_ENCODING);

  $message = Swift_Message::newInstance($subject);

  $message->addPart($body, $contentType, MAIL_ENCODING);

  if ($attach !== null) {
    $message->attach($attach);
  }
  //Give the message a subject
//      ->setSubject($subject)

  //Set the From address with an associative array
  if (function_exists('xdebug_disable')) {
    xdebug_disable();
  }
  try {
    $message = $message->setFrom(getEmailArray(Resources::Get("email.from")));
    $message = $message->setReplyTo(getEmailArray($reply_to));
  } catch (Swift_RfcComplianceException $ex) {
    xdebug_enable();
    $message = $message->setFrom(getEmailArray(Resources::Get("email.from")));
  } catch (Exception $ex) {
    if (function_exists('xdebug_enable')) {
      xdebug_enable();
    }
    throw $ex;
  }

  //Set the To addresses with an associative array
  $message = $message->setTo(getEmailArray($toaddr));
//  if (false) { // debug
//    $message->setBcc(array('servicesent@webim.ru'));
//  } // debug

  //Give it a body
//      ->setBody($body);
  //Create the Transport

    if (isHostedMode()) {
        $transport = Swift_SmtpTransport::newInstance($MAIN_SETTINGS['hostedmode_smtp_server'], $MAIN_SETTINGS['hostedmode_smtp_port']);

        if (!empty($MAIN_SETTINGS['hostedmode_smtp_username'])) {
          $transport = $transport->setUsername($MAIN_SETTINGS['hostedmode_smtp_username']);
        }

        if (!empty($MAIN_SETTINGS['hostedmode_smtp_password'])) {
          $transport = $transport->setPassword($MAIN_SETTINGS['hostedmode_smtp_password']);
        }

        if (!empty($MAIN_SETTINGS['hostedmode_smtp_encryption'])) {
          $transport = $transport->setEncryption($MAIN_SETTINGS['hostedmode_smtp_encryption']);
        }
        if (!empty($MAIN_SETTINGS['hostedmode_smtp_auth_mode'])) {
            $transport->setAuthMode($MAIN_SETTINGS['hostedmode_smtp_auth_mode']);
        }
        if (!empty($MAIN_SETTINGS['hostedmode_smtp_skip_ssl_checks'])) {
          $transport->setStreamOptions(array('ssl' => array('allow_self_signed' => true, 'verify_peer' => false, 'verify_peer_name' => false)));
        }
        if (!empty($MAIN_SETTINGS['hostedmode_local_domain'])) {
          $transport ->setLocalDomain($MAIN_SETTINGS['hostedmode_local_domain']);
        }

    } else {
        $transport = Swift_SendmailTransport::newInstance();
    }


   //Create the Mailer using your created Transport
  $mailer = Swift_Mailer::newInstance($transport);

  return $mailer->send($message);
}


function getFromForOperatorMails() {
  return Resources::Get("email.from");
   
}

function sendSuperviserMailWithHistory($thread, $subjectKey, $bodyKey) {
  $superviserEmail = Settings::Get('superviser_email');

  if (empty($superviserEmail)) {
    return;
  }

  $history = "";
  $lastid = -1;
  $output = Thread::getInstance()->GetMessages($thread['threadid'], "text", true, $lastid);
  foreach ($output as $msg) {
    $history .= $msg;
  }

  $visitSession = VisitSession::GetInstance()->GetVisitSessionById($thread['visitsessionid']);

  $subject = Resources::Get($subjectKey);
  $visitorName = $visitSession['visitorname'] != Resources::getDefaultVisitorName() ? ' ' . $visitSession['visitorname'] : '';

  $body = Resources::Get($bodyKey, array(
    $visitorName, $history
  ));

  webim_mail($superviserEmail, getFromForOperatorMails(), $subject, $body);
}


?>
