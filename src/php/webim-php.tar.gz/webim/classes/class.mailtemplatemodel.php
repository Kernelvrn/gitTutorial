<?php
require_once(dirname(__FILE__) . '/../autoload.php');

/**
 * Description of classmail_template_model
 *
 * @author denis
 */
class MailTemplateModel {
  private $subject;
  private $body;

  public function getSubject() {
    return $this->subject;
  }

  public function getBody() {
    return $this->body;
  }

  public function processMailTemplateSource($template_source, $params = null) {
    $smarty = new SmartyWrapper();
    if ($params === null) {
      $params = array();
    }

    $params['body_res_code'] = 'mail.' . $template_source . '.body';
    $params['subj_res_code'] = 'mail.' . $template_source . '.subject';

    $params['SITE_URL'] = Resources::Get('site.url');
    $params['SITE_TITLE'] = Resources::Get('site.title');
    $params['COMPANY_PHONE'] = Resources::Get('company.phone');
    $params['SUPPORT_EMAIL'] = Resources::Get('company.support.email');
    $params['SERVICE_NAME'] = Resources::Get('service.name');

    $smarty->assign('params', $params);

    $this->subject = $smarty->fetch(WEBIM_SMARTY_TEMPLATE_DIR . '/mail/' . $template_source . '-subject.tpl');
    $this->body = $smarty->fetch(WEBIM_SMARTY_TEMPLATE_DIR . '/mail/' . $template_source .'-body.tpl');
  }

}

?>
