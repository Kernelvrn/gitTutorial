<?php
/* p */
require_once (dirname(__FILE__) . '/models/generic/class.mapperfactory.php');
require_once (dirname(__FILE__) . '/../autoload.php');

/* end p */

class Invoice {
  static private $instance = null;

  static function getInstance() {
    if (self::$instance == null) {
      self::$instance = new Invoice();

    }
    return self::$instance;
  }

  private function __construct() {
  }

  private function __clone() {
  }

  public function makeInvoice($email, $method, $amount, $dateFrom = null, $dateTo = null, $payedAccount = null, $isPartnerTransfer = false) {

    $account = $payedAccount == null ? Account::getInstance()->getCurrentAccount() : $payedAccount;

    $org = MapperFactory::getOrganizationMapper()->getByAccountName($account['accountname']);
    $invoice['guid'] = 'service_pro-' . uniqid() . '-' . uniqid();
    $invoice['name'] = $org['organizationname'];
    $invoice['ratetype'] = $account['ratetype'];
    $invoice['price'] = $amount;

    if ($isPartnerTransfer == true) {
      $invoice['paydate'] = time();
    }

    if (!empty($account['partner'])) {
      $invoice['partner'] = $account['partner'];
    }

    $invoice['pro_payer_accountname'] = $account['accountname'];
    $invoice['email'] = $email;
    $invoice['product'] = 'service_pro';
    $invoice['address'] = $org['legaladdress'];
    $invoice['payment_method'] = $method;
    if ($dateFrom) {
      $formatedDateForm = strftime('%d.%m.%Y', strtotime($dateFrom));
      $formatedDateTo = strftime('%d.%m.%Y', strtotime($dateTo));
      if ($account['dtmcreated'] > TS_AFTER_ACCOUNT_CREATED_FOR_NEW_CONTRACT && time() > TS_OF_NEW_CONTRACT_START) {
          $invoice['purpose'] = 'Предоставление права использования на условиях простой (неисключительной) лицензии программы "Вебим" за период с ' . $formatedDateForm . ' по ' . $formatedDateTo;
          $invoice['partnames'] = 'licensiat';
      } else {
        $invoice['purpose'] = 'Услуги по использованию программы Вебим «Про» за период с ' . $formatedDateForm . ' по ' . $formatedDateTo;
      }
    } else {
      $invoice['purpose'] = 'Услуги по использованию программы Вебим «Про»';
    }
    $invoice['id'] = MapperFactory::getInvoiceMapper()->save($invoice);

    MailNotifications::clientCreateServiceProInvoiceMail( // TODO very hard again
      getAccountId(), "https://ii.webim.ru/buy/schet.php?id=" . urlencode($invoice['guid']),
      $invoice);

    return $invoice;
  }

}

?>
