<?php
require_once(dirname(__FILE__) . '/../autoload.php');
require_once(dirname(__FILE__) . '/functions.php');

class Resources {
  private static $AVAILABLE_LOCALES = 'ru,en';
  private static $AVAILABLE_BACKEND_LOCALES = 'en,ru,he';

  private static $threadStateKeys = array(
    STATE_QUEUE=> "chat.thread.state_wait",
    STATE_QUEUE_EXACT_OPERATOR => "chat.thread.state_wait_for_exact_agent",
    STATE_CHATTING_OPERATOR_BROWSER_CLOSED_REFRESHED => "chat.thread.state_wait_for_another_agent",
    STATE_CHATTING => "chat.thread.state_chatting_with_agent",
    STATE_CLOSED => "chat.thread.state_closed",
    STATE_LOADING => "chat.thread.state_loading",
    STATE_LOADING_FOR_EXACT_OPERATOR => "chat.thread.state_loading",
    STATE_INVITE => "chat.thread.state_invite",
    STATE_CHAT_VISITOR_BROWSER_CLOSED_REFRESHED => "chat.thread.state_chatting_with_agent",
    STATE_CHATTING_CLOSED_REFRESHED => "chat.thread.state_chatting_with_agent",
    STATE_REDIRECTED => "chat.thread.redirected"
  );

  private static $resources = array();

  private function __construct() {
  }

  private function __clone() {
  }

  static function GetSetByLocale($locale) {
      if (!isset(self::$resources[$locale])) {
          $existsLocales = array_map('trim', explode(',',self::$AVAILABLE_LOCALES));
          if (in_array($locale, $existsLocales)) {
              self::$resources[$locale] = self::readResources($locale);
          } else {
              self::$resources[$locale] = array();
          }
      }

      return self::$resources[$locale];
  }
  
  private static function readResources($locale) {
    $hash = array();
    Resources::readResourceFile(dirname(__FILE__)."/../locales/$locale/properties.txt", $hash);

    $fileNames = array(
      getThemesRoot().'/default/locales/'.$locale.'/resources.txt'
    );

    if (getBrandPartner() !== null) {
      $fileNames[] = dirname(__FILE__) . "/../locales." . getBrandPartner() . "/$locale/properties.txt";
    }

    if (getAccountId() !== null) {
      $partner = KeyValueCache::getCachedResults(getAccountId(), 'account-partner', function() {
        $a = Account::getInstance()->getAccountByName(getAccountId());
        return $a['partner'];
      }, 3600*24*365);


      $fileNames[] = dirname(__FILE__) . '/../account-specific.' . $partner . '/' . getAccountId() . '/locales/' . $locale . '/properties.txt';
      $fileNames[] = dirname(__FILE__) . '/../account-specific/' . getAccountId() . '/locales/' . $locale . '/properties.txt';
    }

    $fileNames[] = FilesLocation::getAccountResourcesPath($locale) . '/properties.txt';

    foreach ($fileNames as $fileName) {
      if (is_file($fileName)) {
        self::readResourceFile($fileName, $hash);
      }
    }

    return $hash;
  }

  private static function readResourceFile($fileName, &$hash) {
    if (!file_exists($fileName)) {
      return;
    }
    $fp = fopen($fileName, "r");
    if (!$fp) {
      return;
    }
    while (!feof($fp)) {
      $line = fgets($fp, 16384);
      $line = str_replace("\n", '', $line);
      $line = str_replace("\r", '', $line);
      $keyval = explode("=", $line, 2);
      if (count($keyval) == 2) {
        $key = $keyval[0];
        $value = $keyval[1];
        $hash[$key] = str_replace("\\n", "\n", $value);
      }
    }
    fclose($fp);
  }

  static function Get($key, $params = array(), $locale = null, $byPrefix = FALSE) {
    $res = self::_get($key, $params, $locale, $byPrefix);
    if (isset($res)) {
      return $res;
    }

    $substitutingLocales = Resources::getSubstitutingLocales($locale);
    foreach($substitutingLocales as $substitutingLocale) {
        $res = self::_get($key, $params, $substitutingLocale, $byPrefix);
        if (isset($res)) {
            return $res;
        }
    }
//    throw new Exception("Could not find res for ".$key); // debug
    return null;
  }

  private static function _get($key, $params = array(), $locale = null, $byPrefix = FALSE) {
    if (empty($locale)) {
      $locale = Resources::getCurrentLocale();
    }

    $current = self::GetSetByLocale($locale);
    if ($byPrefix) {
      $res = Resources::getResourcesByPrefix($current, $key);
    } else {
      $res = Resources::getResource($current, $key, $params);
    }
    if (isset($res)) {
        return $res;
    }
  }

  static function getSubstitutingLocales($locale) {
      if (empty($locale)) {
          $locale = Resources::getCurrentLocale();
      }
      if ($locale == 'ua') {
        return array('ru', 'en', 'he');
      } else {
        $arr = array('en', 'ru', 'ua', 'he');
        if (($key = array_search($locale, $arr)) !== false) {
            unset($arr[$key]);
        }
        return $arr;
      }
  }

  private static function getResource($resources, $key, $params) {
    if (isset($resources[$key])) {
      return Resources::fillPlaceholders($resources[$key], $params);
    }
  }

  private static function fillPlaceholders($str, $params = null) {
    if (empty($params)) {
      return $str;
    }
    if (!is_array($params)) {
      $params = array($params);
    }

    $patterns = array();
    $replacements = array();

    foreach ($params as $key => $value) {
      $patterns[] = "{" . $key . "}";
      $replacements[] = strpos($key, '_raw') ? $value : htmlspecialchars($value);
    }
    return str_replace($patterns, $replacements, $str);
  }

  static function compareEncodings($e1, $e2) {
    $_e1 = str_replace('-', '', strtolower($e1));
    $_e2 = str_replace('-', '', strtolower($e2));

    return $_e1 == $_e2;
  }

  static function ConvertWebIMToEncoding($encoding, $dir) {
    if (Resources::compareEncodings(WEBIM_ORIGINAL_ENCODING, $encoding)) {
      return null;
    }

    $resources = listConvertableFiles($dir);

    foreach ($resources as $item) {
      $content = file_get_contents($item);
      $w_content = smarticonv(WEBIM_ORIGINAL_ENCODING, $encoding, $content);
      $result = file_put_contents($item, $w_content);

      if ($result === FALSE) {
        return Resources::Get("errors.write.failed", array($item));
      }
    }

    return null;
  }

  static function IsLocaleAvailable($locale) {
    $res = in_array($locale, Resources::GetAvailableLocales());
//    TRACEVAR('IsLocaleAvailable', $res);
//    TRACEVAR('locale', $locale);
    return $res;
  }

  static function GetAvailableLocales() {
    static $arr;
    $arr = explode(',', Resources::$AVAILABLE_LOCALES);
//    TRACEVAR('GetAvailableLocales', $arr);
    return $arr;
  }

  static function SetLocaleLanguage() {
    if (Resources::getCurrentLocale() == 'ru') {
      $locale = 'ru_RU';
    } else {
      $locale = 'en_EN';
    }

    if (setlocale(LC_ALL, $locale.'.'.(defined('WEBIM_ENCODING') ? WEBIM_ENCODING : 'UTF-8')) === false) {
      setlocale(LC_ALL, Resources::getCurrentLocale());
    }
  }

  public static function initLocale($lang) {
    global $webimLocaleCookieIsSet;
    if (!isset($webimLocaleCookieIsSet)
      && (Settings::Get('multilang') || Settings::Get('admin_multilang'))) {
      setcookie('WEBIM_LOCALE', $_REQUEST['admin_lang'], time() + 60*60*24*1000, "/", Helper::getRootDomain());
      $webimLocaleCookieIsSet = 1;
    }

    $_SESSION['admin_lang'] = $lang;
  }

  private static $currentLocale = NULL;
  public static function getCurrentLocale() {
      if (empty(self::$currentLocale)) {
          if (defined('VISITOR_SIDE')) {
              self::$currentLocale = self::getVisitorCurrentLocale();
          } elseif(!getAccountId()) {
              self::$currentLocale = self::getLocaleForExternalPage();
          } else {
              self::$currentLocale = self::getOperatorCurrentLocale();
          }
      }

      return self::$currentLocale;
  }

  public static function getLocaleForExternalPage() {
    if (!empty($_REQUEST['admin_lang']) && Resources::isBackendLocaleAvailable($_REQUEST['admin_lang'])) {
        $lang = $_REQUEST['admin_lang'];
    } elseif (isset($_COOKIE['WEBIM_LOCALE']) && Resources::isBackendLocaleAvailable($_COOKIE['WEBIM_LOCALE'])) {
        $lang = $_COOKIE['WEBIM_LOCALE'];
    } elseif (isset($_SERVER['X_GEOIP_JSON']) && !empty($_SERVER['X_GEOIP_JSON']) && Resources::GetLocaleByGeo()) {
        $lang = Resources::GetLocaleByGeo();
    } else {
        $lang = Settings::Get('default_lang');
    }
    if (!isset($lang)) {
        $lang = 'ru';
    }

    if (isset($_SERVER['HTTP_HOST']) && !empty($_SERVER['HTTP_HOST'])) {
        setcookie('WEBIM_LOCALE', $lang, time() + 60*60*24*1000, "/", Helper::getRootDomain());
    }
    return $lang;
  }

  public static function getVisitorCurrentLocale() {
      $lang = Settings::Get('default_lang');
      if(Settings::Get('multilang')) {
          if (!empty($_REQUEST['lang']) && Resources::IsLocaleAvailable($_REQUEST['lang'])) {
              $lang = $_REQUEST['lang'];
          } else {
              $location = verify_param('location', '/^[-\w]+$/', 'default');
              $buttonParams = Location::getLocation($location);
              if (!empty($buttonParams['chat'])  && !empty($buttonParams['chat']['lang'])) {
                  $lang = $buttonParams['chat']['lang'];
              }
          }
      }
      return $lang;
  }

  public static function getOperatorCurrentLocale() {
      if (defined('LOCALE')) {
          return LOCALE;
      }
      if (!Settings::Get('admin_multilang')) {
          return Settings::Get('default_lang'); //locale_support_switched_off_marker
      }
      $lang = DEFAULT_LOCALE;
      if (getAccountId()) {
          $operator = Operator::getInstance()->silentGetCurrentOperator();
          if (!empty($operator) && !empty($operator['config'])) {
              $operatorConfig = json_decode($operator['config'], TRUE);
          }
      }

      if (!empty($_REQUEST['admin_lang']) && Resources::isBackendLocaleAvailable($_REQUEST['admin_lang'])) {
//          TRACEVAR("setting locale to session and cookie", $_REQUEST['admin_lang']);
          self::initLocale($_REQUEST['admin_lang']);
          $lang = $_REQUEST['admin_lang'];
      } elseif (!empty($operatorConfig) && !empty($operatorConfig['backend_locale'])) {
          $lang = $operatorConfig['backend_locale'];
      } elseif (isset($_SESSION['admin_lang']) && Resources::isBackendLocaleAvailable($_SESSION['admin_lang']) && Settings::Get('admin_multilang')) { // check session
          $lang = $_SESSION['admin_lang'];
      } elseif (isset($_COOKIE['WEBIM_LOCALE']) && Resources::isBackendLocaleAvailable($_COOKIE['WEBIM_LOCALE']) && Settings::Get('admin_multilang')) { // check cookie
          $lang = $_COOKIE['WEBIM_LOCALE'];
      } elseif (isset($_SERVER['HTTP_ACCEPT_LANGUAGE']) && Settings::Get('admin_multilang')) { // check accept language
          $requested_langs = explode(",", $_SERVER['HTTP_ACCEPT_LANGUAGE']);
          foreach ($requested_langs as $requested_lang) {
              if (strlen($requested_lang) > 2) {
                  $requested_lang = substr($requested_lang, 0, 2);
              }
              if (Resources::IsLocaleAvailable($requested_lang)) {
                  $lang = $requested_lang;
                  break;
              }
          }

      } elseif (Resources::isBackendLocaleAvailable(DEFAULT_LOCALE)) { // check the default locale
          $lang = DEFAULT_LOCALE;
      } else { // can't find lang
          $lang = 'ru';
      }

      global $argc;
      if ((!isset($_COOKIE['WEBIM_LOCALE']) || $_COOKIE['WEBIM_LOCALE'] != $lang) && php_sapi_name() !== 'cli') {
        setcookie('WEBIM_LOCALE', $lang, time() + 60*60*24*1000, "/", Helper::getRootDomain());
      }
      if (!empty($operator) && (empty($operatorConfig) || empty($operatorConfig['backend_locale']))) {
          $operatorConfig['backend_locale'] = $lang;
          $operator['config'] = json_encode($operatorConfig);
          Operator::getInstance()->UpdateOperator($operator['operatorid'], array('config' => $operator['config']));
      }
      return $lang;
  }

  static function GetStateName($state) {
    if (!array_key_exists($state, self::$threadStateKeys)) {
      return $state;
    }
    $key = self::$threadStateKeys[$state];
    return self::Get($key);
  }

  public static function getDefaultVisitorName() {
    return Resources::Get('chat.default.visitorname');
  }

  private static function getResourcesByPrefix($resources, $prefix) {
    $result = array();
    foreach ($resources as $key => $resource) {
      if (strpos($key, $prefix . '.') === 0) {
        $result[substr($key, strlen($prefix . '.'))] = $resource;
      } elseif ($key == $prefix) {
          $result = $resource;
      }
    }

    if (!empty($result)) {
      return $result;
    }
  }

  private static function isBackendLocaleAvailable($locale) {
    $res = in_array($locale, Resources::getBackendAvailableLocales());
//    TRACEVAR('IsBackendLocaleAvailable', $res);
//    TRACEVAR('locale', $locale);
    return $res;
  }

  public static function getBackendAvailableLocales() {
    static $arr;
    $arr = explode(',', Resources::$AVAILABLE_BACKEND_LOCALES);
//    TRACEVAR('GetBackendAvailableLocales', $arr);
    return $arr;
  }

  /**
   * Add value to multidemension array by string path.
   * Example: for path 'days.monday.morning' value will be add like $arr['days']['monday']['morning'] = $val
   * (all subarrays will be created if neccesary)
   * @param mixed $val
   * @param array $arr
   * @param string $path
   */
  public static function addValueToArrayByPath($val, array &$arr, $path) {
      $pathParts = explode('.', trim($path));
      $curSubarray = &$arr;
      while (($pathPart = array_shift($pathParts)) !== NULL) {
          if (!empty($pathParts)) {
              if (!isset($curSubarray[$pathPart])) {
                $curSubarray[$pathPart] = array();
                }
              $curSubarray = &$curSubarray[$pathPart];
          } else {
              $curSubarray[$pathPart] = $val;
          }
      }
  }

  /**
   * Convert flat resource array ('key.subkey' => 'val') into tree ('key' => array('subkey' => 'val'))
   * @param array $resources
   * @return array
   */
  public static function resourcesToTree(array $resources) {
      $resourcesTree = array();
      foreach($resources as $key => $resource) {
          $resource = preg_replace('/\n/', '\n', $resource);
          Resources::addValueToArrayByPath($resource, $resourcesTree, $key);
      }
      return $resourcesTree;
  }

  public static function GetDefaultVisitorNames() {
      $names = array();
      foreach (Resources::GetAvailableLocales() as $locale) {
          $names[$locale] = Resources::Get('chat.default.visitorname', array(), $locale);
      }
      return $names;
  }

  public static function getLocaleByGeo() { // TODO add other langs
      $locale = null;
      if (isset($_SERVER['X_GEOIP_JSON']) && !empty($_SERVER['X_GEOIP_JSON'])) {
          $geo = get_object_vars(json_decode($_SERVER['X_GEOIP_JSON']));
          if (in_array($geo['country_code'], array('RU', 'UA'))) {
              $locale = 'ru';
          }
      }
      return $locale;
  }
}
?>