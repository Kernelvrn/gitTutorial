<?php
require_once('common.php');
require_once(dirname(__FILE__).'/class.account.php');
require_once(dirname(__FILE__).'/class.tariff.php');
require_once(dirname(__FILE__).'/../autoload.php');

 
/* pl */
if (is_dir('/usr/share/php/smarty2')) {
  define('SMARTY_DIR', '/usr/share/php/smarty2/');
} else {
  define('SMARTY_DIR', '/usr/share/php/smarty/');
}
/* end pl */

require_once(SMARTY_DIR.'Smarty.class.php');
require_once('class.browser.php');
require_once('class.settings.php');
require_once('class.operator.php');

class SmartyClass extends Smarty {
  function SmartyClass($titleKey = null) {
    $this->Smarty();

    $this->template_dir = array();
    $this->template_dir[] = WEBIM_SMARTY_TEMPLATE_DIR;
    $this->plugins_dir[] = WEBIM_SMARTY_PLUGINS_DIR;
    $this->trusted_dir[] = WEBIM_SMARTY_TRUSTED_DIR;

    $this->template_dir[] = $_SERVER['DOCUMENT_ROOT'].WEBIM_ROOT.'/themes/default/templates';

    $this->compile_dir = WEBIM_SMARTY_COMPILE_DIR;
    $this->left_delimiter = '<!--{';
    $this->right_delimiter = '}-->';
    $this->debugging = false;
//    //$this->debugging = true; // debug
    $this->force_compile = true;
    
    if (!empty($titleKey)) {
      $this->assign('title_key', $titleKey);
      $this->assign('title', Resources::Get($titleKey));
    }

//    $isOldIE = false;
//    if (!empty($_SERVER['HTTP_USER_AGENT'])) {
//          $browser = get_browser($_SERVER['HTTP_USER_AGENT'], true);
//          if (!empty($browser) && $browser['browser'] == 'IE' && intval($browser['majorver']) <= 8) {
//              $isOldIE = true;
//          }
//    }
//
//    $this->assign('is_old_ie', $isOldIE);
    $this->assign('is_tray', Browser::isTray());
    $this->assign('hosted_mode', isHostedMode());
  }

  private function __prepareMenu() {
    $operatorRoles = Helper::getCurrentRoles();
    $operator = Operator::getInstance()->silentGetCurrentOperator();

    $restrictedDep = false; //TODO remove teztour hardcode after BUGZTASKS-1987
    $restricted = array(
          'depId' => 4,
          'options' => array('operators' => array('supervisor', 'admin'), 'blocked' => array('admin'), 'dashboard' => array('admin'))
    );

    $menu = array();

    if (getAccountId() == 'teztourcom') {
        if (Operator::getInstance()->isOperatorInDepartment($operator['operatorid'], $restricted['depId'])) {
            $restrictedDep = true;
        }

    }

    foreach (AdminURL::$ADMIN_MENU as $i) {
      if (!isset($i['section'])) {
        continue;
      }
      $section = $i['section'];

      if (isset($i['tariff_option'])) {
        $t = $i['tariff_option'];
        if (!is_array($t)) {
          $t = array($t);
        }
        $flag = false;
        foreach ($t as $to) {
          if (Tariff::getInstance()->hasTariffOption($to)&& !Helper::checkIfOptionRestricted($to)) {
            $flag = true;
          }
        }
        if (!$flag) {
          continue;
        }

          if ($restrictedDep) {
              if (array_key_exists($i['link_name'], $restricted['options']) && !array_intersect($operatorRoles, $restricted['options'][$i['link_name']])) {
                  continue;
              }
          }
          //    if (isMyIP()) {
    //      var_dump($i['tariff_option']);
    //      die();
    //    }
      }

      $roles = is_array($i['roles']) ? $i['roles'] : array($i['roles']);
      $inter = array_intersect($roles, $operatorRoles);

      if (empty($inter)) {
        continue;
      }
      $i['link'] = AdminURL::getInstance()->getURL($i['link_name']);
      if (!isset($menu[$section])) {
        $menu[$section] = array();
      }
      $menu[$section][] = $i;
    }
    return $menu;
  }

  function display($path, $display = true, $addProductInfo = true, $sendHeadsers = true, $skipDbFields = false) {

//    MYLOG('Smarty display');
    $this->assign('current_locale', Resources::getCurrentLocale(), false);
    $this->assign('available_locales', Resources::GetAvailableLocales(), false);
    $this->assign('backend_locales', Resources::getBackendAvailableLocales(), false);
    $this->assign('current_time', time());

    $this->assign('webim_sip_domain', WEBIM_SIP_DOMAIN);
    $this->assign('webim_sip_proxy', WEBIM_SIP_PROXY);
    $this->assign('hostedMode', isHostedMode() ? 1 : 0);

    if (!$skipDbFields) {
      $currentAccount = Account::getInstance()->getCurrentAccount();

      $this->assign('account', $currentAccount, false);
      $this->assign('tariff', Tariff::getInstance());

      $o = Operator::getInstance()->silentGetCurrentOperator();
      if ($o !== null) {
        $accounts_orig = MapperFactory::getOperatorAccountViewMapper()->getAccountsByOperatorId($o['operatorid']);
        $accounts = array();
        foreach ($accounts_orig as $a) {
          $a['service_url'] = Helper::getServiceURL($a['accountname'], null, null, null, !empty($a['partner']) ? $a['partner'] : '') ;
          $accounts[] = $a;
        }
        $this->assign('accounts', $accounts, false);

        $this->assign('operator_name', $o['fullname']);
        $this->assign('operator_avatar', $o['avatar']);

        $o['is_admin'] = Operator::getInstance()->isOperatorAdmin();
        $this->assign('operator', $o);
        $this->assign('operator_name', $o['fullname']);
        $this->assign('show_stats_by_hours', Tariff::getInstance()->getTariffOptionValue('stats_by_hours'));
        if (getAccountId() !== null) {
          $this->assign('top_menu', $this->__prepareMenu());
        }
      }

      if (getAccountId() !== null) {
        $this->assign('loop_visitors_sound', Settings::Get('loop_visitors_sound'), false);
        $this->assign('settings', Settings::getInstance());
        $this->assign('menu_logo', Settings::Get('logo') ? Settings::Get('logo') : false);
        $this->assign('message_editing', Settings::Get('message_editing'));
        $this->assign('use_yandex_spellcheck', Settings::Get('use_yandex_spellcheck') ? 1 : 0);

        $statuses = Account::getInstance()->getAvailableOperatorStatuses();
        $this->assign('available_operator_statuses', $statuses);

        $shownKeys = array(
            'auto_assign',
            'multilang',
            'chat_intercept',
            'spell_check_force',
            'default_lang',
            'visitor_dep_answers',
            'visitors_subsections',
            'section_table_view',
            'operator_chat',
            'crm_url_template',
            'stop_typing_timeout',
            'message_editing',
            'operator_websockets',
            'enable_capitalization_correction',
            'disable_spell_check',
            'operator_iframe_allowed_parent_origin',
            'spelling_pass_button_autofocus_and_pass_all',
            'previous_chats_label_time_interval',
            'server_dicts_spell_check',
            'chatting_timer',
            'operator_status_timer'
        );
        $accountSettings = array();
        foreach ($shownKeys as $fieldName) {
          $value = Settings::Get($fieldName);
          $accountSettings[] = $fieldName . ': ' . json_safe_encode($value);
        }
        $account_config_filtered_for_operator = '{' . PHP_EOL . '  ' . implode(',' . PHP_EOL . '  ', $accountSettings) . PHP_EOL . '}';

        $this->assign('account_config_filtered_for_operator', $account_config_filtered_for_operator);
        if (Settings::Get('calls') && !empty($o)) {
          $this->assign('operator_sip', $o['sip']);
          if (array_key_exists('sip_password', $o)) {
            $this->assign('operator_sip_password', $o['sip_password']);
          }
        }
      }
    }

    $this->assign('operator_id', !empty($o) ? $o['operatorid'] : null);

    $this->assign('webim_root', '', false);
    $this->assign('root_domain', Helper::getRootDomain(), false);
    $this->assign('domain', $_SERVER['HTTP_HOST'], false);
    $this->assign('http', Helper::getServerProtocol(), false);

    $this->assign('webim_encoding', strtolower(WEBIM_ENCODING), false);

    if (isMyIP()) {
      $this->assign('is_my_ip', true, false);
      $this->assign('is_https', !empty($_SERVER['HTTPS']), false);
    }

    $this->assign('http', Helper::getServerProtocol(), false);


    $this->assign('service_url', Helper::getServiceURL(getAccountId(), null, null, false), false);
//    $this->assign('service_url', Helper::getServiceURL(), false);
    $this->assign('service_prodomain', Helper::getProServiceDomain(), false);
    $this->assign('service_domain', Helper::getServiceDomain(), false);

    $this->assign('brand_partner', getBrandPartner(), false);
    /* p */
    $this->assign('webim_themes_root', WEBIM_ROOT.'/themes/', false);
    /* end p */
    /* s */
    $this->assign('webim_account_id', getAccountId(), false);
    $this->assign('account_name', getAccountId(), false);

    global $MAIN_SETTINGS;

    $this->assign('webim_themes_root', WEBIM_ROOT.'/themes/', false);
//    $this->assign('webim_themes_root', WEBIM_ROOT.'/accounts/'.getAccountId().'/themes/', false); TODO Pavel, is it supposed to be working?
    /* end s */
    $this->assign('browser_charset', BROWSER_CHARSET, false);
    if ($addProductInfo) {
      $this->assign('product_and_version', Settings::GetProductAndVersion());
    }
    $this->assign('version_date', WEBIM_VERSION_DATE);
    $this->assign('version', WEBIM_VERSION);

    $php_self_url = $_SERVER['PHP_SELF'] . Helper::getUrlParams();

    $php_self_url = str_replace(WEBIM_ROOT, '', $php_self_url);

    $this->assign('php_self', $php_self_url);
    $this->assign('php_self_prepared',$php_self_url . (strstr($php_self_url, '?') ? '&' : '?'));

    /* pl */
    if ($sendHeadsers) {
      Browser::SendHtmlHeaders();
    }
    /* end pl */
//    MYLOG('calling parent display');

    return parent::fetch($path, null, null, $display);
  }

  function assignCompanyInfoAndTheme($departmentkey='') {
  	$url = null;
  	$company = null;
  	$logo = null;
  	
  	/* x */
  	
  	if($departmentkey!=''){
  		$department = MapperFactory::getDepartmentMapper()->getByDepartmentKey($departmentkey);
  		$departmentlocale = MapperFactory::getDepartmentLocaleMapper()->getDepartmentLocale($department['departmentid'], Resources::getCurrentLocale());
//  		$url = $department['departmenturl'];
//  		$company = $departmentlocale['departmentname'];
//  		$logo = $department['departmentlogo'];
  	}
  	/* end x */
  	
//    $this->assign('url', $url ? $url :Settings::Get('hosturl', Resources::Get('site.url')));
    $this->assign('poweredbylink', "http://" . Helper::getRootDomain() . "/?pp=" . urlencode(getAccountId()) . "&utm_source=webim-client-embedded-chat&utm_medium=webim&utm_campaign=" . urlencode(getAccountId()));
//    $this->assign('company', $company ? $company : Settings::Get('company_name', Resources::Get('company.webim')));
//    $this->assign('logo', $logo ? $logo : Settings::Get('logo', WEBIM_ROOT.'/themes/default/images/logo.gif'));
    $postfix = !in_array(getAccountId(), array('komusru001', 'robozru', 'youmagiccom001')) || !in_array($departmentkey, array('sf', 'tm', 'od', 'to', 'ympro', 'ymru', 'ymcom')) ? '' : ('-' . $departmentkey);

    $url = Settings::Get('hosturl' . $postfix) != NULL ? Settings::Get('hosturl' . $postfix) : Resources::Get('site.url');
    $this->assign('url', $url);
    $this->assign('company', $company ? $company : Settings::Get('company_name' . $postfix));
    $this->assign('logo', $logo ? $logo : Settings::Get('logo' . $postfix));

    $this->assign('theme', Browser::getCurrentTheme());
    $this->assign('counter_code', Settings::Get('counter_code'));
  }

}

?>