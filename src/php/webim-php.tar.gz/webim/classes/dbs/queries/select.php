<?php

/**
 * Class Db_Query_Select
 * Абстракция для управление select запросами.
 * В качестве элементов для подстановки запросов можно использовать другие Db_Query_Select
 */
class Db_Query_Select extends Db_Query_Base {
    /**
     * @var array
     */
    protected $fields;
    /**
     * @var string|Db_Query_Select
     */
    protected $table;

    /**
     * @var array[]|null
     * @example [
     *  ['INNER', 'anotherTable', 'someKey']
     *  ['OUTER', Db_Query_Select, ['someKey1', 'someKey2']]
     * ]
     */
    protected $joins;

    /**
     * @var string|null
     */
    protected $where;

    /**
     * @var string[]|null
     */
    protected $groups;

    /**
     * @var string[]|null
     */
    protected $orders;

    protected $limit = array(
        'start' => 0,
        'length' => 0
    );

    /**
     * Query_Select constructor.
     * @param string[]|string $fields список полей для извлечения
     * @param Db_Query_Select|string $table таблица (или подзапрос) для секции FROM
     */
    public function __construct($fields, $table) {
        $this->fields = is_array($fields)
            ? array_values($fields)
            : Helper::trimExplode(',', $fields);

        $this->table = $table;
    }

    /**
     * @return array[string|Db_Query_Select]
     */
    public function getFields() {
        return $this->fields;
    }

    /**
     * @return string|Db_Query_Select
     */
    public function getTable() {
        return $this->table;
    }

    /**
     * Добавляет к запросу join
     * @param string $type тип join ('INNER', 'INNER LEFT', 'OUTER', etc.)
     * @param string|Db_Query_Select $table Таблица или подзапрос для join
     * @param string[]|string|null $using Поля по которым определяются сочетания строк
     */
    public function join($type, $table, $using = NULL) {
        $this->joins[] = array($type, $table, $using);
    }

    /**
     * @return array[]|null
     */
    public function getJoins() {
        return $this->joins;
    }

    /**
     * Добавляет условиее в where. Будет добавлено к основной части через AND.
     * Подзапросы можно вставлять как параметры и позднее передавать для биндинга. Например 'id IN :subQuery1'
     * @param string|array $condition логическое выражение или их массив
     * @param string $op В случае передачи массива в $condition этот оператор будет применяться для склейки
     */
    public function whereAnd($condition, $op = 'OR') {
        $this->addWhere('AND', $condition, $op);
    }

    /**
     * Добавляет условиее в where. Будет добавлено к основной части через OR.
     * Подзапросы можно вставлять как параметры и позднее передавать для биндинга. Например 'id IN :subQuery1'
     * @param string|array $condition логическое выражение или их массив
     * @param string $op В случае передачи массива в $condition этот оператор будет применяться для склейки
     */
    public function whereOr($condition, $op = 'AND') {
        $this->addWhere('OR', $condition, $op);
    }

    protected function addWhere($mainWhereOp, $condition, $subOp = 'AND') {
        $this->where .= ($this->where ? ' ' . $mainWhereOp . ' ' : '')
            . (is_array($condition) ? sprintf('(%s)', implode(' ' . $subOp . ' ', $condition)) : $condition);
    }

    /**
     * @return null|string
     */
    public function getWhere() {
        return $this->where;
    }

    public function groupBy($key) {
        $this->groups[] = $key;
    }

    /**
     * @return null|string[]
     */
    public function getGroupBy() {
        return $this->groups;
    }

    public function orderBy($key) {
        $this->orders[] = $key;
    }

    public function getOrderBy() {
        return $this->orders;
    }

    /**
     * @param int $length
     * @param int $start
     */
    public function setLimit($length, $start = 0) {
        $this->limit = array(
            'start' => $start,
            'length' => $length
        );
    }

    /**
     * @return array
     */
    public function getLimit() {
        return $this->limit;
    }
}