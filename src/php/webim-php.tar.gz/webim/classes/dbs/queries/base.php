<?php

abstract class Db_Query_Base {

}