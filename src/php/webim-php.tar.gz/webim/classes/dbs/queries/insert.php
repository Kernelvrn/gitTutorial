<?php

class Db_Query_Insert extends Db_Query_Base {
    /** @var string */
    protected $table;
    /** @var array */
    protected $fields;
    /** @var  array */
    protected $values;

    /**
     * Query_Insert constructor.
     * @param string $table таблица для вставки
     * @param array $values
     * @param array|string|NULL $fields Поля в которые будут вставляться данные
     */
    public function __construct($table, array $values, $fields = NULL) {
        $this->table = $table;
        $this->fields = is_array($fields)
            ? $fields
            : Helper::trimExplode(',', $fields);
        $this->values = is_array(current($values))
            ? $values
            : array($values);
    }

    /**
     * @return string
     */
    public function getTable() {
        return $this->table;
    }

    /**
     * @return array|NULL
     */
    public function getFields() {
        return $this->fields;
    }

    /**
     * @return array Всегда в виде многомерного массива независимо от количества вставляемых записей
     */
    public function getValues() {
        return $this->values;
    }
}