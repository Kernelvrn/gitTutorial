<?php

/**
 * Class Db_Base
 * Базовый класс с обязательным API низкоуровнего (в рамках системы) взаимодействия с базой
 * По идее инстансами этого класса должны пользоваться только классы группы Mapper_Base
 */
abstract class Db_Base {
    protected $dbName;
    protected $login;
    protected $password;
    protected $host;
    protected $port;
    protected $options;

    private $connectTryBeforeException = 5;

    /**
     * @param string $dbName
     * @param string $login
     * @param string $password
     * @param string $host
     * @param array $options
     * @throws DBNotFoundException|Exception
     */
    public function __construct($dbName, $login, $password, $host, array $options = NULL) {
        $this->dbName = $dbName;
        $this->login = $login;
        $this->password = $password;
        $hostParts = Helper::trimExplode(':', $host);
        $this->host = $hostParts[0];
        $this->port = count($hostParts) > 1 ? $hostParts[1] : NULL;
        $this->options = $options;
    }

    abstract public function connect();
    abstract protected function disconnect();

    /**
     * Выполняет select запрос к базе (возможно отложенный)
     * @param Db_Query_Select $query
     * @param array $queryParams ассоциативный массив для подстановки заэскейпленых параметров в итоговый запрос.
     * Заменяться будут литералы вида :paramName с добавлением кавычек и всего прочего
     * @return Traversable
     */
    abstract public function select(Db_Query_Select $query, array $queryParams = NULL);

    /**
     * Возвращает одну строку из результат запроса (без гарантий какую именно, если их больше одной)
     * @param Db_Query_Select $query
     * @param array $queryParams
     * @return array|null
     */
    abstract public function selectOne(Db_Query_Select $query, array $queryParams = NULL);

    /**
     * Выполняет вставку
     * @param Db_Query_Insert $query
     * @return mixed
     */
    abstract public function insert(Db_Query_Insert $query);

    /**
     * @return int
     */
    public function getConnectTryBeforeException() {
        return $this->connectTryBeforeException;
    }

    public function __destruct() {
        $this->disconnect();
    }
}