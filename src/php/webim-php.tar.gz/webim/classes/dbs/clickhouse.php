<?php

class Db_ClickHouse extends Db_Base {
    protected $clickHouseClient;

    public function __construct($dbName, $login, $password, $host, array $options = NULL) {
        parent::__construct($dbName, $login, $password, $host, $options);

        $this->clickHouseClient = new \ClickHouseDB\Client(array(
            'host' => $this->host,
            'port' => $this->port ?: '8123',
            'username' => $this->login,
            'password' => $this->password
        ));
        $this->clickHouseClient->database($this->dbName);
        $this->clickHouseClient->setTimeout(10);
    }

    /**
     * @param Db_Query_Select $query
     * @param array|NULL $params
     * @return array
     */
    public function select(Db_Query_Select $query, array $params = NULL) {
        return $this->selectStatement($query, $params)->rows();
    }

    /**
     * @param Db_Query_Select $query
     * @param array|NULL $params
     * @return array|null
     */
    public function selectOne(Db_Query_Select $query, array $params = NULL) {
        return $this->selectStatement($query, $params)->fetchOne();
    }

    public function insert(Db_Query_Insert $query) {
        $this->clickHouseClient->insert(
            $query->getTable(),
            $query->getValues(),
            $query->getFields()
        );
    }

    public function connect() {
        $tries = 0;
        $connect = false;
        while($tries < $this->getConnectTryBeforeException() && !$connect) {
            $tries++;
            try {
                $this->clickHouseClient->ping();
                $connect = true;
            } catch (\ClickHouseDB\QueryException $exception) {
                doMyLog('Can\'t ping ClickHouse. Error message: ' . $exception->getMessage());
            }
        }

        if (!$connect) {
            throw new CouldNotConnectException('Can\'t connect to ClickHouse');
        } elseif ($tries > 1) {
            doMyLog('Connect to ClickHouse on ' . $this->host . ' after ' . $tries . ' attempts');
        }
    }

    protected function selectStatement(Db_Query_Select $query, array $params = NULL) {
        return $this->clickHouseClient->select(
            $this->selectQueryObjToString($query, $params)
        );
    }

    protected function disconnect() {
        // Работаем с ClickHouse через Http без установки постоянной сессии, так что разъединение не требуется
    }

    protected function selectQueryObjToString(Db_Query_Select $query, array $params = NULL) {
        $str = 'SELECT ';
        $fields = array();
        foreach ($query->getFields() as $key => $field) {
            $fields[] = $field instanceof Db_Query_Select
                ? '(' . $this->selectQueryObjToString($field) . ') AS ' . $key
                : $field . (is_string($key) ? ' AS ' . $key : '');
        }
        $str .= implode(', ', $fields);

        $str .= ' FROM ' . (
            $query->getTable() instanceof Db_Query_Select
                ? '(' . $this->selectQueryObjToString($query->getTable()) . ')'
                : $query->getTable()
        );

        if ($joins = $query->getJoins()) {
            if (count($joins) > 1) {
                throw new InvalidArgumentException('Only one join per level possible for ClickHouse.');
            }
            list($type, $table, $using) = $joins[0];
            if ($type) {
                $str .= ' ' . $type . ' JOIN';
            }

            $str .= $table instanceof Db_Query_Select
                ? ' (' . $this->selectQueryObjToString($table) .')'
                : ' ' . $table;

            if ($using) {
                $str .= ' USING ' . (is_array($using)
                    ? implode(', ', $using)
                    : $using
                );
            }
        }

        if ($query->getWhere()) {
            $str .= ' WHERE ' . $query->getWhere();
        }

        if ($query->getGroupBy()) {
            $str .= ' GROUP BY ' . implode(',', $query->getGroupBy());
        }

        if ($query->getOrderBy()) {
            $str .= ' ORDER BY ' . implode(',', $query->getOrderBy());
        }

        $limit = $query->getLimit();
        if ($limit['length']) {
            $str .= ' LIMIT ' . $limit['start'] . ', ' . $limit['length'];
        }

        if ($params) {
            $patterns = array();
            $replaces = array();
            foreach ($params as $key => $paramValue) {
                $patterns[] = '/([^\\\]):' . $key . '\b/';
                if ($paramValue instanceof Db_Query_Select) {
                    $replace = $this->selectQueryObjToString($paramValue);
                } else {
                    $replace = $this->escape($paramValue);
                    if (is_string($replace)) {
                        $replace = str_replace(':', '\:', $replace); //Блокируем возможность делать рекурсивные подставновки
                    }
                }

                $replaces[] = '${1}' . $replace;
            }

            $str = preg_replace($patterns, $replaces, $str);
            $str = str_replace('\:', ':', $str);
        }

        return $str;
    }

    protected function escape($value) {
        if (is_numeric($value)) {
            return $value;
        } elseif (is_string($value)) {
            return '\'' . addcslashes($value, '\'\\') . '\'';
        } elseif (is_bool($value)) {
            return $value ? 1 : 0;
        } elseif (is_array($value)) {
            $arr = array();
            foreach ($value as $sub) {
                $arr[] = $this->escape($sub);
            }
            return implode(',', $arr);
        } else {
            throw new InvalidArgumentException('Invalid param for ClickHouse escape: "' . $value . '" type ' . gettype($value));
        }
    }
}