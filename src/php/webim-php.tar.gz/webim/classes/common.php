<?php

/*
* Application path on server
*/

$CHECK_ERROR_LOG_COMMAND = "grep -v uninitialized /var/log/pro/error.log|grep -v upstream |grep -v notice|grep -v 'Primary script unknown'|grep -v 'recv()'|grep -v 'connect()'|grep -v buffered|grep -v zeta|grep -v 'No such file or directory'|grep -v forbidden|grep -v SSL_do_handshake|grep -v /client.php/index.html|grep -v client.php/trackback/index.html | grep -v 'is not found' | grep -v SSL3_GET_RECORD | head";

$HTTPS_PLATFORMS = array('MacOSX', 'Win2003', 'Win7', 'Linux', 'iOS', 'Android');
// , 'WinXP'

$MYIPS = null;


// TODO EM change to '' later
define('WEBIM_ROOT', '/webim');

define('PASSWORD_RECOVER_TIMEOUT', 24 * 60 * 60 * 1000);

define('MAX_TIME_INTERVAL_FOR_FILTERS', 12*31*24*60*60);

define('MAX_AGE_FOR_STATS_CALC', 'first day of previous month'); //for DateTime

define('TS_OF_NEW_CONTRACT_START', strtotime('2013-10-01 00:01'));
define('TS_AFTER_ACCOUNT_CREATED_FOR_NEW_CONTRACT', strtotime('2013-02-20 12:10'));

define('DEFAULT_TIMEZONE_ID', 'Europe/Moscow');
/*
*  MySQL Database parameters
*/
define("SITE_DB_TABLE_PREFIX", "chat");
define('DB_DATETIME_FORMAT_STRF', '%Y-%m-%d %H:%M:%S');
define('DB_DATETIME_FORMAT', 'Y-m-d H:i:s');

define("PASSWORD_MIN_LENGTH", "6");

define("WEBIM_CONNECTION_TIMEOUT", 60); // seconds

define("STATE_QUEUE", 'queue');
define("STATE_REDIRECTED", 'redirected');
define("STATE_CHATTING", 'chatting');
define("STATE_CLOSED", 'closed');
define("STATE_LOADING", 'loading');
define("STATE_INVITE", 'invite');
define("STATE_CHAT_VISITOR_BROWSER_CLOSED_REFRESHED", 'chat_visitor_browser_closed_refreshed');
define("STATE_CHATTING_CLOSED_REFRESHED", 'chatting_closed_refreshed');
define("STATE_CHATTING_OPERATOR_BROWSER_CLOSED_REFRESHED", 'operator_browswer_closed_refreshed');
define("STATE_QUEUE_EXACT_OPERATOR", 'queue_exact_operator');
define("STATE_LOADING_FOR_EXACT_OPERATOR", 'loading_for_exact_operator');


define("KIND_USER", 1);
define("KIND_AGENT", 2);
define("KIND_FOR_AGENT", 3);
define("KIND_INFO", 4);
define("KIND_CONN", 5);
define("KIND_EVENTS", 6);
define("KIND_AVATAR", 7);
define("KIND_RATE", 8);
define("KIND_AGENT_BUSY", 9);
define("KIND_CONT_REQ", 10);
define("KIND_CONTACTS", 11);
define("KIND_FIRST_AUX_MESSAGE", 12);
define("KIND_FILE_OPERATOR", 13);
define("KIND_FILE_VISITOR", 14);
define("KIND_OPERATOR_NOTE", 16);

define("VISITED_PAGE_TIMEOUT", 45);
define("TIMEOUT_VISITOR_PING", 60); // seconds
define("TIMEOUT_OPERATOR_PING", 60 * 3); // seconds
define("TIMEOUT_REFRESH", 60); // seconds
define("INVITE_ANIMATION_DURATION", 90); // seconds
define("TIMEOUT_EXACT_OPERATOR", 60 * 3); // seconds

/* pb */
define("INVITATION_START", 'start');
define("INVITATION_IDLE", 'idle');
define("INVITATION_SHOWING", 'showing');
define("INVITATION_SHOWING_AUTO", 'showing-auto');
define("INVITATION_SHOWING_BY_URL_PARAM", 'showing-by-url-param');
define("INVITATION_IDLE_AFTER_CHAT", 'idle-after-chat');
define("INVITATION_SHOWING_AFTER_CHAT", 'showing-after-chat');
define("INVITATION_CHAT", 'chat');
define("INVITATION_END", 'end');
/* end pb */

/* pb */
define("VISITED_PAGE_LOADING", 0);
define("VISITED_PAGE_OPENED", 1);
define("VISITED_PAGE_CLOSED", 2);

define("ONE_IP_MAX_SESSIONS", 5);
/* end pb */

define("PROCESS_THREADS_DELAY", 30); // seconds


define('WEBIM_COOKIE_VISITOR_NAME', 'WEBIM_VISITOR_NAME'); // 1.0.9+
define('WEBIM_COOKIE_VISITOR_INFO', 'WEBIM_VISITOR_INFO');
define('WEBIM_COOKIE_VISITOR_ID', 'WEBIM_VISITOR_ID');
define('WEBIM_COOKIE_PARTNER_REF', 'WEBIM_PARTNER_REFERENCE');
define('WEBIM_COOKIE_VISITOR_IN_CHAT', 'WEBIM_VISITOR_IN_CHAT');

define("OPERATOR_STATUS_OFFLINE", 0);
define("OPERATOR_STATUS_ONLINE", 1);

define("WEBIM_WHOIS_LINK", "https://www.nic.ru/whois/?query=");

define('WEBIM_SIP_PROXY', 'c2c.webim.ru');
define('WEBIM_SIP_DOMAIN', WEBIM_SIP_PROXY);

/* pl */

require_once(dirname(__FILE__) . '/config.php');
require_once(dirname(__FILE__) . '/version.php');
/* end pl */

/**
 * Online operators files dir
 */
$accountId = getAccountId() !== null ? getAccountId() : 'login';

global $MAIN_SETTINGS;

define("ONLINE_FILES_DIR", $MAIN_SETTINGS['online_dir'] . DIRECTORY_SEPARATOR . substr(md5($accountId), 0, 1) . DIRECTORY_SEPARATOR . $accountId);

define(
"ONLINE_VISITORS_FILES_DIR",
    ONLINE_FILES_DIR . DIRECTORY_SEPARATOR .
    "visitors"
);

define(
"ONLINE_THREADS_FILES_DIR",
    ONLINE_FILES_DIR . DIRECTORY_SEPARATOR .
    "threads"
);

define(
"TRACKER_FILES_DIR",
    ONLINE_FILES_DIR . DIRECTORY_SEPARATOR .
    "tracker_pages"
);
define("VISITSESSION_FILE_TTL", 2 * 24 * 60 * 60);
define("CURRENT_PAGE_FILE_TTL", VISITSESSION_FILE_TTL);

/* s */
define("ACCOUNT_STATUS_FILE_EXT", ".account.status");
/* end s */

define(
"OPERATOR_ONLINE_FILES_DIR",
    ONLINE_FILES_DIR . DIRECTORY_SEPARATOR .
    "online_operators"
);

define("OPERATOR_ONLINE_FILE_EXT", "online");


define(
"OPERATOR_CACHE_FILES_DIR",
    ONLINE_FILES_DIR . DIRECTORY_SEPARATOR .
    "operators_cache"
);

define("OPERATOR_CACHE_FILE_EXT", "operator");


define(
"OPERATOR_ONLINE_STATS_FILES_DIR",
    ONLINE_FILES_DIR . DIRECTORY_SEPARATOR .
    "online_stats"
);

define("OPERATOR_ONLINE_STATS_FILE_MAX_SIZE", 4096);

define("OPERATOR_ONLINE_STATS_FILE_EXT", "time");

define(
"HAS_ACTIVE_THREADS_FILE",
    ONLINE_FILES_DIR . DIRECTORY_SEPARATOR .
    "has.threads");

define(
"SESSION_ACTIVE_THREADS_DIR",
    ONLINE_FILES_DIR . DIRECTORY_SEPARATOR .
    "session_active_threads");

define("SESSION_ACTIVE_THREAD_FILE_EXT", "active_thread");

define(
"MAX_REVISION_FILE",
    ONLINE_FILES_DIR . DIRECTORY_SEPARATOR .
    "revision.txt");

define(
"LAST_IDLE_FILE",
    ONLINE_FILES_DIR . DIRECTORY_SEPARATOR .
    "last.idle");

define(
"OPERATOR_VIEW_TRACKER_FILE",
    ONLINE_FILES_DIR . DIRECTORY_SEPARATOR .
    "tracker");

define(
"HAS_DEPARTMENTS_FILE",
    ONLINE_FILES_DIR . DIRECTORY_SEPARATOR .
    "has.departments");

define(
"AUTOINVITE_RULES_FILE",
    ONLINE_FILES_DIR . DIRECTORY_SEPARATOR .
    "autoinvites.txt");


define('MAIL_STATISTICS_FILE', ONLINE_FILES_DIR . DIRECTORY_SEPARATOR . 'mail.sent');

define('DATA_UPDATED_FILE', ONLINE_FILES_DIR . DIRECTORY_SEPARATOR . 'config-updated.txt');

define("HAS_MESSAGES_OPERATOR_FILE_POSTFIX", ".operator.thread");
define("HAS_MESSAGES_VISITOR_FILE_POSTFIX", ".visitor.thread");

define('WEBIM_SMARTY_TEMPLATE_DIR', dirname(__FILE__) . '/../templates');
define('WEBIM_SMARTY_PLUGINS_DIR', dirname(__FILE__) . '/../templates/.plugins');
define('WEBIM_SMARTY_TRUSTED_DIR', dirname(__FILE__) . '/../classes/function');
//define('WEBIM_SMARTY_COMPILE_DIR', $_SERVER['DOCUMENT_ROOT']. WEBIM_ROOT .'/compiles');

$dir = '/var/cache/webim/compiles';
if (!is_dir($dir)) {
  mkdir($dir, 0777, true);
}
define('WEBIM_SMARTY_COMPILE_DIR', $dir);


 

 

if (!defined('WEBIM_ENCODING') || WEBIM_ENCODING == 'CP1251') {
  define('SITE_DB_CHARSET', 'cp1251');
  define('SITE_DB_COLLATION', 'cp1251_general_ci');
  define('BROWSER_CHARSET', 'windows-1251');
  define('MAIL_ENCODING', 'windows-1251');
} else {
  define('SITE_DB_CHARSET', 'utf8mb4');
  define('SITE_DB_COLLATION', 'utf8mb4_general_ci');
  define('BROWSER_CHARSET', 'UTF-8');
  define('MAIL_ENCODING', 'UTF-8');
}

/*invitation*/
/*
* Encoding of the invitation message.
*/

//$invitation_encoding = "cp1251";
//define('INVITATION_ENCODING', 'cp1251');
/*e_invitation*/

/* s */
if (!defined('INVITATION_ENCODING')) {
  define('INVITATION_ENCODING', WEBIM_ENCODING);
}
/* end s */

/*
*   Locales
*/

define('DEFAULT_LOCALE', 'ru');


define('WEBIM_ORIGINAL_ENCODING', 'CP1251');

/*
*   How to build presentable visitor name from {name}, {id} or {addr}. Default: {name}
*/


/*
*   Timeout(in seconds) when online operator becomes offline.
*/

//$online_timeout = 30;
define('ONLINE_TIMEOUT', '30');

// visitor files removal
//define('OLD_FILES_TIMEOUT', 60*60*24*7); // one week
define('OLD_FILES_TIMEOUT', 60 * 60 * 24); // one day
//define('OLD_FILES_TIMEOUT', 60); // one minute

/* p */
//  Maximum uploaded file size.
define('MAX_UPLOADED_FILE_SIZE', 1 * 1024 * 1024);
/* end p */

define('DEFAULT_ITEMS_PER_PAGE', 15);

define('USE_X_FORWARDED_FOR', false);

define('MAIL_STATISTICS_HOUR', 20);

function getAvailableLocalesForChat() {
  $available_locales_for_chat = Resources::GetAvailableLocales();

  $locales = array();
  foreach ($available_locales_for_chat as $l) {
    $locales[] = array('localeid' => $l, 'localename' => $l);
  }
  return $locales;
}

function getFrontends() {
  global $FRONTENDIPS;

  if ($FRONTENDIPS === null) {
    if (!file_exists('/etc/webim/main.ini')) {
      $FRONTENDIPS = array();
    } else {
      $arr = parse_ini_file('/etc/webim/main.ini');
      $FRONTENDIPS = $arr['frontend_ips'];
    }
  }

  return $FRONTENDIPS;
}
function isMyIP() {
//  return true; //debug
  if (Helper::getRemoteAddress() === null) {
    return false;
  }

  global $MAIN_SETTINGS;

  if (in_array(Helper::getRemoteAddress(), $MAIN_SETTINGS['my_ips'])) {
    return true;
  }

  if (Helper::getRemoteAddress() == $_SERVER["SERVER_ADDR"]) {
    return true;
  }
// TODO: hopefuly not needed
//  for ($i = 1; $i < 30; $i++) {
//    $hostname =  Helper::getServerDomainByNumber($i);
//    $ip = gethostbyname($hostname);
//    if ($ip == Helper::getRemoteAddress()) {
//      return true;
//    }
//  }
  return false;
}

/*serviceonly*/
/*
* Use Web Messenger as service.
*/
$webim_as_service = false;

if ($webim_as_service) {
  require_once(dirname(__FILE__) . '/service.php');
}
/*e_serviceonly*/

function getVisitorFieldNames() {
  return array('name', 'phone', 'email', 'icq', 'login', 'company', 'passport_number', 'codeword');
}

////function MYLOG($messageToShow, $highlight = true) { // debug
//  $message = ''; // debug
//  if ($highlight) { // debug
//    $message .= "<strong>"; // debug
//  } // debug
//  $message .= $messageToShow; // debug

//  if ($highlight) { // debug
//    $message .= "</strong>"; // debug
//  } // debug

//  $message .= "<br/>"; // debug

//  if (!isset($_SESSION['WEBIM_TRACELOG'])) {
//      $_SESSION['WEBIM_TRACELOG'] = '';
//  }
//  $_SESSION['WEBIM_TRACELOG'] .= $message;
//  if (defined('DEBUG')) { // debug
//    echo $message; // debug
//  } // debug
//} // debug

//function PRINTSESSIONLOG() {
//  echo $_SESSION['WEBIM_TRACELOG'];
//}
////function TRACEVAR($message, $var) { // debug
////  MYLOG($message); // debug
////  MYLOG(print_r($var, true)); // debug
////  MYLOG("<br/>"); // debug
//} // debug

////function PRINTSTACKTRACE() { // debug
//  if (!defined('DEBUG')) { // debug
//    return; // debug
//  } // debug

//  $trace = debug_backtrace(); // debug
//  foreach ($trace as $i) { // debug
//    echo "<p>"; // debug
//    echo "file: <strong>" . $i['file'] . "<br/>"; // debug
//    echo "line: <strong>" . $i['line'] . "<br/>"; // debug
//    echo "</p>"; // debug
//  } // debug
//} // debug

require_once('class.resources.php');

if (PHP_SAPI !== 'cli') { // using deploy.sh -> flush.php via 'cli'
  WebIMInit::Init();
}

function exception_handler($exception) {
    header($_SERVER['SERVER_PROTOCOL'] . ' 500 Internal Server Error', true, 500);
}

class WebIMInit {
  static function Init() {
    global $MAIN_SETTINGS;
    if (!defined('SKIP_ACCOUNT_EXISTS_CHECK') && getAccountId() !== null) {
      $dir = FilesLocation::getClientDataDirPath(getAccountId());
      if (!file_exists($dir)) {
        if (isset($_SERVER['HTTP_USER_AGENT']) && !stristr($_SERVER['HTTP_USER_AGENT'], 'bot') && !isMyIP()) {
          immediatelyNotifyAboutProblem("Could not find account " . getAccountId() . " so redirecting to login.*");
        }
        $a = Account::getInstance()->getAccountByName(getAccountId());
        $partner = null;
        if (!empty($a)) {
          $partner = $a['partner'];
        }
        $domain = Helper::getRootDomain($a['accountname'], $a['partner']);
        $https = Helper::isDomainHttpsEnabled($domain) ? 'https' : 'http';

        $url = $https . (isHostedMode() ? $MAIN_SETTINGS['hosted_accountname'] : "://login." . $domain);
//          die($url);
        header("Location: " . $url);
//        header("HTTP/1.0 404 Not Found");
        die();
      }

    }

      if (!isHostedMode()  && !$MAIN_SETTINGS['devmode']) {
          $params = array('tags' => array('version' => WEBIM_VERSION, 'account_name' => getAccountId()));
          if (function_exists('xdebug_disable')) {
            xdebug_disable();
          }

          //set_exception_handler('exception_handler');

          if (php_sapi_name() !== 'cli') {
              if (empty($_SERVER['X_CONFIG_VERSION']) || version_compare($_SERVER['X_CONFIG_VERSION'], '2.0.0') < 0) {
                  immediatelyNotifyAboutProblem('Nginx configs are too old');
              }
          }

      }

    self::doRedirect();
    self::checkXSS();

    /* pl */
    if (!defined('AVOID_SET_LOCALE')) {
      Resources::SetLocaleLanguage();
    }
//    ob_start(); // debug
    if (!defined('AVOID_SESSION_START')) {
      my_session_start();
    }
    /* end pl */
//    if (isset($_SESSION['WEBIM_TRACELOG']) && strlen($_SESSION['WEBIM_TRACELOG']) > 200*200) {
////      unset($_SESSION['WEBIM_TRACELOG']); // debug
//    }

    if (!defined('AVOID_SET_LOCALE')) {
      $locale = Resources::getCurrentLocale();
      define('WEBIM_CURRENT_LOCALE', $locale);
    } else {
      define('WEBIM_CURRENT_LOCALE', 'ru');
    }

    self::initRequests();

    if (function_exists("date_default_timezone_set") and function_exists("date_default_timezone_get")) {
      @date_default_timezone_set(@date_default_timezone_get());
    }

//    WebIMInit::setupDebug(); // debug

//    if (defined('DEBUG')) { // debug
//      set_error_handler("fire_error_handler"); // debug
//    } // debug

    if (!isAccountBlocked()) {
      self::storeAccountnameToCache('server-accounts');

      if (Tariff::getInstance()->hasTariffOption('chat') && Tariff::getInstance()->hasTariffOption('stats')) {
        self::storeAccountnameToCache('server-accounts-for-stats');
      }
    }
  }

  private static function doRedirect() {
    global $HTTPS_PLATFORMS;

    if (empty($_SERVER['HTTP_HOST'])) {
      return;
    }
    $fullUrl = $_SERVER['HTTP_HOST'] . $_SERVER['REQUEST_URI'];
    $host = $_SERVER['HTTP_HOST'];

    $isTray = false;

    if (!defined('VISITOR_SIDE')) {
      if ((!empty($_SERVER['HTTP_USER_AGENT']) && stristr($_SERVER['HTTP_USER_AGENT'], 'tray'))
          || (!empty($_REQUEST['mode']) && $_REQUEST['mode'] == 'tray')
      ) {
        $isTray = true;
        $isOld = true;
        if (preg_match('/([\d\.]+)/', $_SERVER['HTTP_USER_AGENT'], $matches)) {
          $trayVersion = $matches[1];
          $isOld = version_compare(WEBIM_VERSION, '6.1') >= 0
              && version_compare($trayVersion, '5.0') < 0;
        }
        if ($isOld) {
          header('Location: http://webim.ru/tray/expired/');
          die();
        }
      }
    }


    if (getAccountId() !== null && strstr($host, '.pro-service.') && !empty($_SERVER['HTTPS'])) {
      header('Location: http://' . $fullUrl);
      die();
    }

    if (defined('SKIP_PROTOCOL_SWITCH')) { // TOOD: very hard
      return;
    }

    if (preg_match('/\/operator/', $_SERVER['PHP_SELF'])){
      // removing pro-service
      if (strstr($host, '.pro-service.')) {
        $url = str_replace('.pro-service.', '.', $fullUrl);
        header('Location: https://' . $url);
        die();
      }

      $platform = null;

      $isHttpsPlatform = true;
      $isHttpsPlatform = $isTray || $isHttpsPlatform;

      $isHttpsPlatform = (getAccountId() === null || !Settings::Get('http_only')) && $isHttpsPlatform;


      $mustBeHttps = $isHttpsPlatform
//              && empty($_SERVER['HTTP_X_FORWARDED_FOR'])
              && Helper::isDomainHttpsEnabled()
              && preg_match('/^\/webim\/operator/', $_SERVER['PHP_SELF']);

//      if ($isTray) {
//        doMyLog("Dumping HTTP_X_FORWARDED_FOR for tray:");
//        if (!empty($_SERVER['HTTP_X_FORWARDED_FOR'])) {
//          doMyLog($_SERVER['HTTP_X_FORWARDED_FOR']);
//        }
//      }
        if (!empty($_SERVER['HTTP_X_FORWARDED_FOR'])) {
          global $MAIN_SETTINGS;
          doMyLog("Forwarded");
          doMyLog($_SERVER['HTTP_X_FORWARDED_FOR']);
          doMyLog(print_r($_SERVER, true));

          if (in_array($_SERVER['HTTP_X_FORWARDED_FOR'], $MAIN_SETTINGS['my_ips']) // for our proxy
          || in_array($_SERVER['REMOTE_ADDR'], $MAIN_SETTINGS['my_ips'])) {
            $mustBeHttps = !empty($_SERVER['HTTPS']); // don't redirect
          }
        }

      if (empty($_SERVER['HTTPS'])
          && $mustBeHttps
      ) {
        doMyLog('Forwarded https://' . $fullUrl);
        header('Location: https://' . $fullUrl);
        die();
      } elseif (!empty($_SERVER['HTTPS']) && !$mustBeHttps) {
        doMyLog('Forwarded http://' . $fullUrl);
        header('Location: http://' . $fullUrl);
        die();
      }
    }
  }

  private static function checkXSS() {
    if (defined('SKIP_XSS')) {
      return;
    }

    foreach ($_REQUEST as $k => $v) {
      if (is_string($v) && (strstr($v, '<') || strstr($v, '<'))) {
//        @mail('server.monitoring@webim.ru', 'XSS suspected', print_r(array('request' => $_REQUEST, 'server' => $_SERVER), true));
      }
    }
  }

//  private static function setupDebug() { // debug
//    if (isset($_REQUEST['__debug'])) { // debug
//      if ($_REQUEST['__debug'] == 1) { // debug
//        $_SESSION['DEBUG'] = 1; // debug
//        define('DEBUG', 1); // debug
//      } elseif ($_REQUEST['__debug'] == 0) { // debug
//        unset($_SESSION['DEBUG']); // debug
//      } // debug
//    } elseif (isset($_SESSION['DEBUG'])) { // debug
//      define('DEBUG', 1); // debug
//    } // debug
//  } // debug

  private static function recursiveStripSlashes($value) {
    $result = $value;

    if (is_string($value)) {
      $result = stripslashes($value);
    }

    if (is_array($value)) {
      $result = array();
      foreach ($value as $i => $v) {
        $result[$i] = self::recursiveStripSlashes($v);
      }
    }

    return $result;
  }

  private static function initRequests() {
    if ((function_exists("get_magic_quotes_gpc") && get_magic_quotes_gpc()) ||
        (ini_get('magic_quotes_sybase') && (strtolower(ini_get('magic_quotes_sybase')) != "off"))
    ) {
      $_GET = self::recursiveStripSlashes($_GET);
      $_POST = self::recursiveStripSlashes($_POST);
      $_COOKIE = self::recursiveStripSlashes($_COOKIE);
      $_REQUEST = self::recursiveStripSlashes($_REQUEST);
    }
  }

  /**
   * @param $arr_name
   */
  public static function storeAccountnameToCache($arr_name) {
    $accounts = KeyValueCache::get($arr_name, getPHPEnvLetter(), array(), 'login');
    if (getAccountId() !== null && !in_array(getAccountId(), $accounts)) {
      $accounts[] = getAccountId();
      KeyValueCache::put($arr_name, $accounts, getPHPEnvLetter(), 24 * 60 * 60 * 1000, 'login');
    }
  }
}


?>