<?php

class MailChimp {

    private static $api_key;
    private static $api_endpoint = 'https://<dc>.api.mailchimp.com/2.0';
    private static $verify_ssl = false;
    private static $instance = null;

    function __construct() {
        global $MAIN_SETTINGS;
        self::$api_key = $MAIN_SETTINGS['mailchimp_key'];
        list(, $datacentre) = explode('-', self::$api_key);
        self::$api_endpoint = str_replace('<dc>', $datacentre, self::$api_endpoint);
    }

    static function getInstance() {
        if (self::$instance === null) {
            self::$instance = new MailChimp();
        }
        return self::$instance;
    }

    private static function call($method, $args = array(), $timeout = 10) {
        return self::makeRequest($method, $args, $timeout);
    }

    private static function makeRequest($method, $args = array(), $timeout = 10) {
        $args['apikey'] = self::$api_key;

        $url = self::$api_endpoint . '/' . $method . '.json';

        if (function_exists('curl_init') && function_exists('curl_setopt')) {
            $ch = curl_init();
            curl_setopt($ch, CURLOPT_URL, $url);
            curl_setopt($ch, CURLOPT_HTTPHEADER, array('Content-Type: application/json'));
            curl_setopt($ch, CURLOPT_USERAGENT, 'PHP-MCAPI/2.0');
            curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
            curl_setopt($ch, CURLOPT_TIMEOUT, $timeout);
            curl_setopt($ch, CURLOPT_POST, true);
            curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, self::$verify_ssl);
            curl_setopt($ch, CURLOPT_POSTFIELDS, json_encode($args));
            $result = curl_exec($ch);
            curl_close($ch);
        } else {
            $json_data = json_encode($args);
            $result = file_get_contents($url, null, stream_context_create(array(
                'http' => array(
                    'protocol_version' => 1.1,
                    'user_agent' => 'PHP-MCAPI/2.0',
                    'method' => 'POST',
                    'header' => "Content-type: application/json\r\n" .
                        "Connection: close\r\n" .
                        "Content-length: " . strlen($json_data) . "\r\n",
                    'content' => $json_data,
                ),
            )));
        }

        return $result ? json_decode($result, true) : false;
    }
    private static function getListId($listName) {
        $res = self::call('lists/list',array('filters'=>array('list_name'=>$listName)));
        return (isset($res['total']) && $res['total'] > 0) ? $res['data'][0]['id'] : false;
    }

    public function subscribe($email) {
        global $MAIN_SETTINGS;

        if (empty($MAIN_SETTINGS['mailchimp_subscribe_lists'])) {
          return true;
        }
        $result = array();
        foreach ($MAIN_SETTINGS['mailchimp_subscribe_lists'] as $listName) {
            $listId = self::getListId($listName);
            $result[$listName] = ($listId !== false) ? self::call('/lists/subscribe', array('id'=>$listId,
                                                                'email'=>array('email'=>$email)))
                                                     : false;
        }

        return $result;
    }
}