<?php
require_once(__DIR__ . '/functions.php');
require_once(__DIR__ . '/models/generic/class.mapperfactory.php');
require_once(__DIR__ . '/../autoload.php');

class Button {
    protected static $oldSystemButtons = array('slider_left', 'slider_right', 'slider1_left', 'corner', 'corner_lb', 'webim', 'maria', 'simple', 'simple1', 'simple2', 'simple3', 'simple4', 'empty');

    public static function getParameters() {
        $departments = MapperFactory::getDepartmentMapper()->enumDepartments(Resources::getCurrentLocale());
        $departmentsParam = array(array('key' => '', 'value' => Resources::Get('page.gen.anydepartment')));

        foreach ($departments as $d) {
            $item = array();
            $item['key'] = $d['departmentkey'];
            $item['value'] = $d['departmentname'];
            $departmentsParam[] = $item;
        }

        $localesParam = array();
        $locales = getAvailableLocalesForChat();
        foreach ($locales as $d) {
            $item = array();
            $item['key'] = $d['localeid'];
            $item['value'] = $d['localename'];
            $localesParam[] = $item;
        }

        $params = array(
            'invitation_theme' => array(
                'name_key' => 'page.gen.choose_invitation_theme',
                'type' => 'list',
                'values' => array(
                    array('key' => 'static', 'value' => Resources::Get('page.gen.choose_invitation_theme.static')),
                    array('key' => 'slider', 'value' => Resources::Get('page.gen.choose_invitation_theme.slider'))
                ),
                'default' => 'static'
            ),
            'invitation_position' => array(
                'name_key' => 'page.gen.invitation_position',
                'type' => 'list',
                'values' => array(
                    array('key' => 'top-left', 'value' => Resources::Get('page.gen.invitation_position.tl')),
                    array('key' => 'top-right', 'value' => Resources::Get('page.gen.invitation_position.tr')),
                    array('key' => 'bottom-left', 'value' => Resources::Get('page.gen.invitation_position.bl')),
                    array('key' => 'bottom-right', 'value' => Resources::Get('page.gen.invitation_position.br'))
                ),
                'default' => 'tl'
            ),
            'invitation_bg_color' => array(
                'name_key' => 'page.gen.invitation_bg_color',
                'type' => 'list',
                'values' => array(
                    array('key' => 'default', 'value' => Resources::Get('page.gen.color.default')),
                    array('key' => 'green', 'value' => Resources::Get('page.gen.color.green')),
                    array('key' => 'red', 'value' => Resources::Get('page.gen.color.red')),
                    array('key' => 'blue', 'value' => Resources::Get('page.gen.color.blue')),
                    array('key' => 'yellow', 'value' => Resources::Get('page.gen.color.yellow')),
                    array('key' => 'orange', 'value' => Resources::Get('page.gen.color.orange')),
                    array('key' => 'cyan', 'value' => Resources::Get('page.gen.color.cyan')),
                    array('key' => 'pink', 'value' => Resources::Get('page.gen.color.pink')),
                    array('key' => 'black', 'value' => Resources::Get('page.gen.color.black')),
                    array('key' => 'white', 'value' => Resources::Get('page.gen.color.white')),
                    array('key' => 'custom', 'value' => Resources::Get('page.gen.color.custom'))
                ),
                'default' => 'default'
            ),
            'invitation_bg_custom_color' => array(
                'name_key' => 'page.gen.invitation_bg_custom_color',
                'type' => 'text',
                'default' => ''
            ),
            'invitation_font_color' => array(
                'name_key' => 'page.gen.invitation_font_color',
                'type' => 'list',
                'values' => array(
                    array('key' => 'default', 'value' => Resources::Get('page.gen.color.default')),
                    array('key' => 'green', 'value' => Resources::Get('page.gen.color.green')),
                    array('key' => 'red', 'value' => Resources::Get('page.gen.color.red')),
                    array('key' => 'blue', 'value' => Resources::Get('page.gen.color.blue')),
                    array('key' => 'yellow', 'value' => Resources::Get('page.gen.color.yellow')),
                    array('key' => 'orange', 'value' => Resources::Get('page.gen.color.orange')),
                    array('key' => 'cyan', 'value' => Resources::Get('page.gen.color.cyan')),
                    array('key' => 'pink', 'value' => Resources::Get('page.gen.color.pink')),
                    array('key' => 'black', 'value' => Resources::Get('page.gen.color.black')),
                    array('key' => 'white', 'value' => Resources::Get('page.gen.color.white')),
                    array('key' => 'custom', 'value' => Resources::Get('page.gen.color.custom'))
                ),
                'default' => 'default'
            ),
            'invitation_font_custom_color' => array(
                'name_key' => 'page.gen.invitation_font_custom_color',
                'type' => 'text',
                'default' => ''
            ),
            'chat_header_color' => array(
                'name_key' => 'page.gen.chat_header_color',
                'type' => 'list',
                'values' => array(
                    array('key' => 'default', 'value' => Resources::Get('page.gen.color.default')),
                    array('key' => 'green', 'value' => Resources::Get('page.gen.color.green')),
                    array('key' => 'red', 'value' => Resources::Get('page.gen.color.red')),
                    array('key' => 'blue', 'value' => Resources::Get('page.gen.color.blue')),
                    array('key' => 'yellow', 'value' => Resources::Get('page.gen.color.yellow')),
                    array('key' => 'orange', 'value' => Resources::Get('page.gen.color.orange')),
                    array('key' => 'cyan', 'value' => Resources::Get('page.gen.color.cyan')),
                    array('key' => 'pink', 'value' => Resources::Get('page.gen.color.pink')),
                    array('key' => 'black', 'value' => Resources::Get('page.gen.color.black')),
                    array('key' => 'white', 'value' => Resources::Get('page.gen.color.white')),
                    array('key' => 'custom', 'value' => Resources::Get('page.gen.color.custom'))
                ),
                'default' => 'default'
            ),
            'chat_header_custom_color' => array(
                'name_key' => 'page.gen.chat_header_custom_color',
                'type' => 'text',
                'default' => ''
            ),
            'chat_header_color2' => array(
                'name_key' => 'page.gen.chat_header_color2',
                'type' => 'list',
                'values' => array(
                    array('key' => 'default', 'value' => Resources::Get('page.gen.color.default')),
                    array('key' => 'green', 'value' => Resources::Get('page.gen.color.green')),
                    array('key' => 'red', 'value' => Resources::Get('page.gen.color.red')),
                    array('key' => 'blue', 'value' => Resources::Get('page.gen.color.blue')),
                    array('key' => 'yellow', 'value' => Resources::Get('page.gen.color.yellow')),
                    array('key' => 'orange', 'value' => Resources::Get('page.gen.color.orange')),
                    array('key' => 'cyan', 'value' => Resources::Get('page.gen.color.cyan')),
                    array('key' => 'pink', 'value' => Resources::Get('page.gen.color.pink')),
                    array('key' => 'black', 'value' => Resources::Get('page.gen.color.black')),
                    array('key' => 'white', 'value' => Resources::Get('page.gen.color.white')),
                    array('key' => 'custom', 'value' => Resources::Get('page.gen.color.custom'))
                ),
                'default' => 'default'
            ),
            'chat_header_custom_color2' => array(
                'name_key' => 'page.gen.chat_header_custom_color2',
                'type' => 'text',
                'default' => ''
            ),
            'chat_bg_color' => array(
                'name_key' => 'page.gen.chat_bg_color',
                'type' => 'list',
                'values' => array(
                    array('key' => 'default', 'value' => Resources::Get('page.gen.color.default')),
                    array('key' => 'green', 'value' => Resources::Get('page.gen.color.green')),
                    array('key' => 'red', 'value' => Resources::Get('page.gen.color.red')),
                    array('key' => 'blue', 'value' => Resources::Get('page.gen.color.blue')),
                    array('key' => 'yellow', 'value' => Resources::Get('page.gen.color.yellow')),
                    array('key' => 'orange', 'value' => Resources::Get('page.gen.color.orange')),
                    array('key' => 'cyan', 'value' => Resources::Get('page.gen.color.cyan')),
                    array('key' => 'pink', 'value' => Resources::Get('page.gen.color.pink')),
                    array('key' => 'black', 'value' => Resources::Get('page.gen.color.black')),
                    array('key' => 'white', 'value' => Resources::Get('page.gen.color.white')),
                    array('key' => 'custom', 'value' => Resources::Get('page.gen.color.custom'))
                ),
                'default' => 'default'
            ),
            'chat_bg_custom_color' => array(
                'name_key' => 'page.gen.chat_bg_custom_color',
                'type' => 'text',
                'default' => ''
            ),
            'chat_button_color' => array(
                'name_key' => 'page.gen.chat_button_color',
                'type' => 'list',
                'values' => array(
                    array('key' => 'default', 'value' => Resources::Get('page.gen.color.default')),
                    array('key' => 'green', 'value' => Resources::Get('page.gen.color.green')),
                    array('key' => 'red', 'value' => Resources::Get('page.gen.color.red')),
                    array('key' => 'blue', 'value' => Resources::Get('page.gen.color.blue')),
                    array('key' => 'yellow', 'value' => Resources::Get('page.gen.color.yellow')),
                    array('key' => 'orange', 'value' => Resources::Get('page.gen.color.orange')),
                    array('key' => 'cyan', 'value' => Resources::Get('page.gen.color.cyan')),
                    array('key' => 'pink', 'value' => Resources::Get('page.gen.color.pink')),
                    array('key' => 'black', 'value' => Resources::Get('page.gen.color.black')),
                    array('key' => 'white', 'value' => Resources::Get('page.gen.color.white')),
                    array('key' => 'custom', 'value' => Resources::Get('page.gen.color.custom'))
                ),
                'default' => 'default'
            ),
            'chat_button_custom_color' => array(
                'name_key' => 'page.gen.chat_button_custom_color',
                'type' => 'text',
                'default' => ''
            ),
            'chat_button_color2' => array(
                'name_key' => 'page.gen.chat_button_color2',
                'type' => 'list',
                'values' => array(
                    array('key' => 'default', 'value' => Resources::Get('page.gen.color.default')),
                    array('key' => 'green', 'value' => Resources::Get('page.gen.color.green')),
                    array('key' => 'red', 'value' => Resources::Get('page.gen.color.red')),
                    array('key' => 'blue', 'value' => Resources::Get('page.gen.color.blue')),
                    array('key' => 'yellow', 'value' => Resources::Get('page.gen.color.yellow')),
                    array('key' => 'orange', 'value' => Resources::Get('page.gen.color.orange')),
                    array('key' => 'cyan', 'value' => Resources::Get('page.gen.color.cyan')),
                    array('key' => 'pink', 'value' => Resources::Get('page.gen.color.pink')),
                    array('key' => 'black', 'value' => Resources::Get('page.gen.color.black')),
                    array('key' => 'white', 'value' => Resources::Get('page.gen.color.white')),
                    array('key' => 'custom', 'value' => Resources::Get('page.gen.color.custom'))
                ),
                'default' => 'default'
            ),
            'chat_button_custom_color2' => array(
                'name_key' => 'page.gen.chat_button_custom_color2',
                'type' => 'text',
                'default' => ''
            ),
            'choose_department' => array(
                'name_key' => 'page.gen.choosedepartment',
                'type' => 'list',
                'values' => array(
                    array('key' => 'N', 'value' => Resources::Get('choosedepartment.no')),
                    array('key' => 'geo', 'value' => Resources::Get('choosedepartment.geo')),
                    array('key' => 'Y', 'value' => Resources::Get('choosedepartment.mandatory'))
                ),
                'default' => 'N',
            ),
            'departments_sort' => array(
                'name_key' => 'page.gen.choosedepartmentsort',
                'type' => 'list',
                'values' => array(
                    array('key' => 'id', 'value' => Resources::Get('choosedepartmentsort.id')),
                    array('key' => 'name', 'value' => Resources::Get('choosedepartmentsort.name'))
                ),
                'default' => 'id'
            ),
            'department_key' => array(
                'name_key' => 'page.gen.department',
                'type' => 'list',
                'values' => $departmentsParam,
                'default' => ''
            ),
            'chat_lang' => array(
                'name_key' => 'page.gen.locale',
                'type' => 'list',
                'values' => $localesParam,
                'default' => ''
            ),
            'choose_operator' => array(
                'name_key' => 'page.gen.chooseoperator',
                'type' => 'list',
                'values' => array(
                    array('key' => 'N', 'value' => Resources::Get('choose_operator.no')),
                    array('key' => 'optional', 'value' => Resources::Get('choose_operator.optional')),
                    array('key' => 'Y', 'value' => Resources::Get('choose_operator.mandatory'))
                ),
                'default' => 'N',
            ),
            'operators_sort' => array(
                'name_key' => 'page.gen.chooseoperatorssort',
                'type' => 'list',
                'values' => array(
                    array('key' => 'id', 'value' => Resources::Get('chooseoperatorssort.id')),
                    array('key' => 'name', 'value' => Resources::Get('chooseoperatorssort.name'))
                ),
                'default' => 'id'
            ),
            'chat_enter_first_message' => array(
                'name_key' => 'page.gen.enterfirstmessage',
                'type' => 'checkbox',
                'default' => 'N',
            ),
            'chat_hints_enabled' => array(
                'name_key' => 'page.gen.enterfirstmessage',
                'type' => 'checkbox',
                'default' => 'N',
            )
        );

        if (!Tariff::getInstance()->hasTariffOption('chat_colors')) {
            unset($params['invitation_bg_color']);
            unset($params['invitation_bg_custom_color']);
            unset($params['invitation_font_color']);
            unset($params['chat_header_color']);
            unset($params['chat_header_color2']);
            unset($params['chat_header_custom_color']);
            unset($params['chat_header_custom_color2']);
            unset($params['chat_bg_color']);
            unset($params['chat_bg_custom_color']);
            unset($params['chat_button_color']);
            unset($params['chat_button_custom_color']);
            unset($params['chat_button_color2']);
            unset($params['chat_button_custom_color2']);
        }

        if (!Settings::Get('multilang')) {
            unset($params['chat_lang']);
        }

        return $params;
    }

    private static function __getImageNameFromParam($pImage, $pDepartmentKey = NULL, $pLang = NULL, $pImagePostfix = NULL, $hasOnline = NULL, $absolutePath = false) {
        if (!preg_match('/\.(gif|jpg|png|swf)$/i', $pImage)) {
            $image = $pImage . '.gif';
        } else {
            $image = $pImage;
        }

        if (empty($pLang) || !Resources::IsLocaleAvailable($pLang)) {
            $lang = Resources::getCurrentLocale();
        } else {
            $lang = $pLang;
        }

        if (empty($pImagePostfix)) {
            if (empty($hasOnline)) {
                $image_postfix = Operator::getInstance()->hasOnlineOperators($pDepartmentKey, $lang) ? 'on' : 'off';
            } else {
                $image_postfix = $hasOnline ? 'on' : 'off';
            }
        } else {
            $image_postfix = $pImagePostfix;
        }

        $image = preg_replace('/\.(gif|jpg|png|swf)/i', '_' . $image_postfix . '.\\1', $image);

        $fileName = ($absolutePath ? getButtonsLocation() : '/themes/.buttons/') . $lang . '/' . $image;
        return $fileName;
    }

    public static function getImageNameFromParam($pImage, $pDepartmentKey = NULL, $pLang = NULL, $pImagePostfix = NULL, $hasOnline = NULL, $absolutePath = false) {
        $fileName = self::__getImageNameFromParam($pImage, $pDepartmentKey, $pLang, $pImagePostfix, $hasOnline, $absolutePath);

        if (!file_exists($fileName)) { # TODO very hardcode for empty button
            $fileName = self::__getImageNameFromParam('empty', $pDepartmentKey, $pLang, $pImagePostfix, $hasOnline, $absolutePath);
        }
        return $fileName;
    }

    protected static function getClientButtons($locale) {
        $buttons = array();
        if ($locale) {
            $path = FilesLocation::getAccountButtonsPath($locale);
            $buttons = self::getButtonsByPath($path, $locale, self::getButtonFilePrefix());
        } else {
            foreach (Resources::GetAvailableLocales() as $locale) {
                $path = FilesLocation::getAccountButtonsPath($locale);
                $buttons = array_merge($buttons, self::getButtonsByPath($path, $locale, self::getButtonFilePrefix()));
            }
        }
        foreach ($buttons as &$button) {
            $button['type'] = 'client';
        }
        return $buttons;
    }

    protected static function getSystemButtons($locale) {
        $systemButtonNames = join('|', self::$oldSystemButtons);
        $buttons = array();
        if ($locale) {
            $path = getButtonsLocation() . $locale;
            $buttons = self::getButtonsByPath($path, $locale, $systemButtonNames);
        } else {
            foreach (Resources::GetAvailableLocales() as $locale) {
                $path = getButtonsLocation() . $locale;
                $buttons = array_merge($buttons, self::getButtonsByPath($path, $locale, $systemButtonNames));
            }
        }
        foreach ($buttons as &$button) {
            $button['type'] = 'system';
        }

        return $buttons;
    }

    protected static function getButtonsByPath($buttonsPath, $locale, $buttonNamePrefix) {
        $buttons = array();
        if ($handleButtonsDir = @opendir($buttonsPath)) {
            while (false !== ($file = readdir($handleButtonsDir))) {
                $button = self::makeButtonArray($buttonsPath . DIRECTORY_SEPARATOR . $file, $locale, $buttonNamePrefix);
                if (!empty($button)) {
                    if (
                        getBrandPartner() !== 'nethouseru'
                        || empty($button['params']['kind']) || $button['params']['kind'] !== 'simple'
                    ) {
                        $buttons[] = $button;
                    }
                }
            }
            closedir($handleButtonsDir);
        }
        return $buttons;
    }

    protected static function makeButtonArray($buttonFilePath, $locale, $buttonPrefix) {
        $buttonArr = array();
        $filename = pathinfo($buttonFilePath, PATHINFO_BASENAME);
        $dirName = pathinfo($buttonFilePath, PATHINFO_DIRNAME);

        if (preg_match('/^(' . $buttonPrefix . '.*)_on.(gif|jpg|png|swf)$/i', $filename, $matches)) {
            $name = $matches[1] . '.' . $matches[2];
            $buttonArr['name'] = $name;

            $buttonArr['propsFile'] = $dirName . '/' . $matches[1] . '.txt';
            $buttonArr['onFile'] = $dirName . '/' . $matches[1] . '_on.' . $matches[2];
            $buttonArr['onlineButton'] = WEBIM_ROOT . '/button.php?button-name=' . urlencode($matches[1] . '.' . $matches[2]) . '&locale=' . urlencode($locale) . '&force-status=on';
            $buttonArr['ext'] = $matches[2];

            $buttonArr['params'] = Button::getButtonSettings($name, $locale);
            $buttonArr['lang'] = $locale;

            $offlineFileName = $dirName . '/' . $matches[1] . '_off.' . $matches[2];
            if (file_exists($offlineFileName)) {
                $buttonArr['offFile'] = $offlineFileName;
                $buttonArr['offlineButton'] = WEBIM_ROOT . '/button.php?button-name=' . urlencode($matches[1] . '.' . $matches[2]) . '&locale=' . urlencode($locale) . '&force-status=off';
            }
        }
        return $buttonArr;
    }

    protected static function getButtonSettings($buttonName, $locale) {
        $buttonSettings = array('kind' => 'simple');
        $image = $buttonName;
        if (preg_match('/^(.+)\.(gif|jpg|png|swf)$/i', $image, $matches)) {
            $image = $matches[1];
        }
        if (in_array($image, self::$oldSystemButtons)) {
            $dir = getButtonsLocation() . $locale;
        } else {
            $dir = FilesLocation::getAccountButtonsPath($locale);
        }
        $fileName = $dir . '/' . $image . '.txt';
        $buttonSettings = file_exists($fileName) ? json_decode(file_get_contents($fileName), true) : $buttonSettings;
        return $buttonSettings;
    }

    public static function getButton($name, $locale) {
        $buttons = self::enumButtons($locale, 'all');
        $buttons = Helper::arrayColumnToKeys($buttons, 'name');

        return !empty($buttons[$name]) ? $buttons[$name] : NULL;
    }

    public static function enumButtons($locale = NULL, $mode = 'all') {
        $buttons = array();
        switch ($mode) {
            case 'all':
                $buttons = array_merge(self::getClientButtons($locale), self::getSystemButtons($locale));
                break;
            case 'client':
                $buttons = self::getClientButtons($locale);
                break;
            case 'system':
                $buttons = self::getSystemButtons($locale);
                break;
        }

        usort($buttons, function ($v1, $v2) {
            $w = array('corner' => 0, 'slider' => 5, 'simple' => 10);

            $w1 = isset($v1['params']['kind']) ? $w[$v1['params']['kind']] : $w['simple'];
            $w2 = isset($v2['params']['kind']) ? $w[$v2['params']['kind']] : $w['simple'];

            return $w1 != $w2 ? $w1 > $w2 : $v1['name'] > $v2['name'];
        });
        return $buttons;
    }

    protected static function getButtonFilePrefix() {
        return getAccountId() . '_';
    }

    public static function deleteButton($name, $lang) {
        $buttons = self::enumButtons($lang, 'client');

        foreach ($buttons as $b) {
            if ($b['name'] == $name) {
                @unlink($b['onFile']);
                @unlink($b['offFile']);
                @unlink($b['propsFile']);
                return true;
            }
        }

        return false;
    }

    public static function updateButton($button) {

    }

    public static function createButton($onlineButtonArr, $offlineButtonArr = NULL, $lang = NULL, array $params = array()) {
        $lang = $lang ? $lang : Resources::getVisitorCurrentLocale();
        $dir = FilesLocation::getAccountButtonsPath($lang) . DIRECTORY_SEPARATOR;
        $fileInfo = new finfo(FILEINFO_MIME_TYPE);
        $ext = array_search(
            $fileInfo->file($onlineButtonArr['tmp_name']),
            array(
                'jpg' => 'image/jpeg',
                'png' => 'image/png',
                'gif' => 'image/gif'
            ),
            true
        );
        $buttonName = self::getButtonFilePrefix() . time();

        $index = 1;
        $nameSuffix = '';
        $path = $dir . $buttonName . '_on.' . $ext;
        while (file_exists($path)) {
            $nameSuffix = $index++;
            $path = $dir . $buttonName . $nameSuffix . '_on.' . $ext;
        }
        $buttonName .= $nameSuffix;

        if (!empty($params)) {
            file_put_contents($dir . $buttonName . '.txt', json_encode($params));
        }

        move_uploaded_file($onlineButtonArr['tmp_name'], $dir . $buttonName . '_on.' . $ext);
        if (!empty($offlineButtonArr)) {
            move_uploaded_file($offlineButtonArr['tmp_name'], $dir . $buttonName . '_off.' . $ext);
        }

        return self::makeButtonArray($dir . $buttonName . '_on.' . $ext, $lang, self::getButtonFilePrefix());
    }
}
