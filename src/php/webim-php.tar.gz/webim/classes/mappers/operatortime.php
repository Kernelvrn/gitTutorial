<?php

class Mapper_OperatorTime extends Mapper_Base {
    protected static $tableName = 'operatorTime';

    public function getLastDateWithMaxOnlinePeriodId() {
        $maxDateQuery = new Db_Query_Select('max(date)', self::$tableName);
        $maxOnlinePeriodIdQuery = new Db_Query_Select('any(date) as lastDate, max(onlinePeriodId) AS onlinePeriodId', self::$tableName);
        $maxOnlinePeriodIdQuery->whereAnd('date IN (:maxDateQuery)');
        $maxOnlinePeriodIdQuery->groupBy('date');
        return $this->db->selectOne($maxOnlinePeriodIdQuery, array('maxDateQuery' => $maxDateQuery));
    }

    public function getStatsRowsForStatus(Statistic_Filters $filters, $status) {
        $query = new Db_Query_Select(array(
            'dtmFrom - toUInt32(toTime(dtmFrom)) % (:step) + arrayJoin(
                range(toUInt16(intDiv(dtmTo - toUInt32(toTime(dtmTo)) % (:step) - (dtmFrom - toUInt32(toTime(dtmFrom)) % (:step)), :step) + 1))
            ) * (:step) as periodStart',
            ':step as periodLength',
            'sumIf(
                (dtmTo > periodStart + periodLength ? periodStart + periodLength : dtmTo)
                -
                (dtmFrom < periodStart ? periodStart : dtmFrom),
                dtmFrom < periodStart + periodLength and dtmTo > periodStart
            ) as value'
        ), self::$tableName);
        $params = array(
            'startDate' => $filters->getStartDate()->format('Y-m-d'),
            'endDate' => $filters->getEndDate()->format('Y-m-d'),
            'step' => (int)Settings::Get('statistics_min_period'),
            'status' => $status
        );
        $query->whereAnd(array(
            'date BETWEEN :startDate AND :endDate',
            'status = :status'
        ), 'AND');

        if ($filters->getOperators()) {
            $operatorIds = array();
            foreach ($filters->getOperators() as $operator) {
                $operatorIds[] = (int)$operator->getId();
            }
            $query->whereAnd('operatorId IN (:operatorIds)');
            $params['operatorIds'] = $operatorIds;
        }

        if ($filters->getDepartments()) {
            $departmentIds = array();
            foreach ($filters->getDepartments() as $department) {
                $departmentIds[] = (int)$department->getId();
            }
            $query->whereAnd('departmentId IN (:departmentIds)');
            $params['departmentIds'] = $departmentIds;
        } else {
            $query->whereAnd('departmentId = 0');
        }

        if ($filters->getLocales()) {
            $query->whereAnd('locale IN (:locales)');
            $params['locales'] = $filters->getLocales();
        } else {
            $query->whereAnd('locale = \'\'');
        }

        $query->groupBy('periodStart');
        $query->orderBy('periodStart');

        return $this->db->select($query, $params);
    }

    public function getStatsRowsForStatusBySumStatusTime(Statistic_Filters $filters, $status) {
        $query = new Db_Query_Select(array(
            'operatorId,
            SUM(dtmTo - dtmFrom) AS statusTime'
        ), self::$tableName);

        $params = array(
            'startDate' => $filters->getStartDate()->format('Y-m-d'),
            'endDate' => $filters->getEndDate()->format('Y-m-d'),
            'status' => $status
        );

        $query->whereAnd(array(
            'date BETWEEN :startDate AND :endDate',
            'status = :status'
        ), 'AND');

        if ($filters->getOperators()) {
            $operatorIds = array();
            foreach ($filters->getOperators() as $operator) {
                $operatorIds[] = (int)$operator->getId();
            }
            $query->whereAnd('operatorId IN (:operatorIds)');
            $params['operatorIds'] = $operatorIds;
        }

        if ($filters->getDepartments()) {
            $departmentIds = array();
            foreach ($filters->getDepartments() as $department) {
                $departmentIds[] = (int)$department->getId();
            }
            $query->whereAnd('departmentId IN (:departmentIds)');
            $params['departmentIds'] = $departmentIds;
        } else {
            $query->whereAnd('departmentId = 0');
        }

        if ($filters->getLocales()) {
            $query->whereAnd('locale IN (:locales)');
            $params['locales'] = $filters->getLocales();
        } else {
            $query->whereAnd('locale = \'\'');
        }

        $query->groupBy('operatorId');

        return $this->db->select($query, $params);
    }
}