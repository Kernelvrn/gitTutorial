<?php

abstract class Mapper_Base {
    /** @var  Db_Base */
    protected $db;

    protected static $tableName;

    public function __construct(Db_Base $db) {
        $this->db = $db;
    }

    /**
     * @param Traversable|array $rows
     */
    public function saveRows($rows) {
        $values = array();
        $fields = array();

        foreach ($rows as $row) {
            $fields = $fields ?: array_keys($row);
            $values[] = $row;
        }

        $this->db->insert(new Db_Query_Insert(
            static::$tableName,
            $values,
            $fields
        ));
    }
}