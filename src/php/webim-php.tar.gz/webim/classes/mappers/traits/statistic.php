<?php

trait Mapper_Trait_Statistic {
    protected static function filtersToWhere(array $filters) {
        $where = array();
        $params = array();

        if (!empty($filters['dateRange'])) {
            $where[] = 'date BETWEEN :startDate AND :endDate';
            $params['startDate'] = $filters['dateRange']['start']->format('Y-m-d');
            $params['endDate'] = $filters['dateRange']['end']->format('Y-m-d');
        }

        foreach (array('operators', 'departments', 'offices') as $filterKey) {
            if (!empty($filters[$filterKey])) {
                $params[$filterKey] = self::filterToWhereParam($filters[$filterKey]);
                $where[] = sprintf('filter%s IN (:%s)', ucfirst($filterKey), $filterKey);
            }
        }

        if (!empty($filters['categories'])) {
            $categories = is_array($filters['categories']) && !array_key_exists('category', $filters['categories'])
                ? $filters['categories']
                : array($filters['categories']);
            $catWhere = array();
            $catIndex = 0;
            foreach ($categories as $category) {
                $catWhere[] = sprintf('(filterCategory = :category_%d AND filterSubCategory = :subcategory_%d)', $catIndex, $catIndex);
                if ($category instanceof Model_Category) {
                    $params['category_' . $catIndex] = $category->getParent()
                        ? $category->getParent()->getTitle()
                        : $category->getTitle();
                    $params['subcategory_' . $catIndex] = $category->getParent()
                        ? $category->getTitle()
                        : '';
                }
                $catIndex++;
                $where[] = implode(' OR ', $catWhere);
            }
        }

        if (!empty($filters['locales'])) {
            $params['locales'] = is_array($filters['locales'])
                ? $filters['locales']
                : array($filters['locales']);

            $where[] = 'filterLocale IN (:locales)';
        }

        return array($where, $params);
    }

    private static function filterToWhereParam($filterValue) {
        $params = array();
        $filterValue = is_array($filterValue) ? $filterValue : array($filterValue);
        foreach ($filterValue as $value) {
            $params[] = $value instanceof Model_Base ? $value->getId() : $value;
        }

        return $params;
    }
}