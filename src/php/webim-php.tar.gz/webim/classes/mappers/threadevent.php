<?php

class Mapper_ThreadEvent extends Mapper_Base {
    protected static $tableName = 'threadEvent';

    public function getLastSyncedId() {
        $row = $this->db->selectOne($query = new Db_Query_Select('MAX(threadHistoryId) as threadHistoryId', self::$tableName));
        return $row ? $row['threadHistoryId'] : NULL;
    }

    /**
     * Возвращает массив временых отрезков шедших чатов согласно фильтрам с ра3бивкой по периодам
     * @todo Реализовано для событий, разделённых не более чем на сутки, требуется переделать для всех случаев
     * @param Statistic_Filters $filters
     * @return Traversable [[
     *  periodStart => 0,
     *  periodLength => 900,
     *  chatFrom => 10,
     *  chatTo => 900
     * ],[
     *  periodStart => 0,
     *  periodLength => 900,
     *  chatFrom => 40,
     *  chatTo => 550
     * ]...]
     */
    public function getPeriodsRowsWithChats(Statistic_Filters $filters) {
        $segmentStart = (clone $filters->getStartDate());
        $segmentStart->sub(new DateInterval('P1D'));
        $segmentEnd = (clone $filters->getEndDate());
        $segmentEnd->add(new DateInterval('P1D'));
        $leftTable = new Db_Query_Select(array(
            'eventDtm as dtmFrom',
            'eventNumber',
            'operatorId',
            'departmentId',
            'locale',
            'officeId',
            'eventThreadId'
        ), self::$tableName);
        $leftTable->whereAnd('threadState IN (\'chatting\', \'offline_process\')');
        $leftTable->whereAnd('date BETWEEN :segmentStart AND :endDate');

        $rightTable = new Db_Query_Select(array(
            'eventDtm as dtmTo',
            'toUInt16(eventNumber - 1) as eventNumber',
            'eventThreadId'
        ), self::$tableName);
        $rightTable->whereAnd('date BETWEEN :startDate AND :segmentEnd');

        $query = new Db_Query_Select(array(
            'dtmFrom - toUInt32(toTime(dtmFrom)) % (:step) + arrayJoin(
                range(toUInt16(intDiv(dtmTo - toUInt32(toTime(dtmTo)) % (:step) - (dtmFrom - toUInt32(toTime(dtmFrom)) % (:step)), :step) + 1))
            ) * (:step) as periodStart',
            ':step as periodLength',
            'toUInt32(dtmFrom > periodStart ? dtmFrom : periodStart) as segmentFrom',
            'toUInt32(dtmTo > periodStart + periodLength ? periodStart + periodLength : dtmTo) as segmentTo'
        ), $leftTable);
        $query->join('ANY INNER', $rightTable, 'eventThreadId, eventNumber');
        $query->orderBy('periodStart ASC');
        $query->orderBy('dtmFrom ASC');

        $params = array(
            'startDate' => $filters->getStartDate()->format('Y-m-d'),
            'startTs' => $filters->getStartDate()->getTimestamp(),
            'endDate' => $filters->getEndDate()->format('Y-m-d'),
            'endTs' => $filters->getEndDate()->getTimestamp(),
            'segmentStart' => $segmentStart->format('Y-m-d'),
            'segmentEnd' => $segmentEnd->format('Y-m-d'),
            'step' => (int)Settings::Get('statistics_min_period')
        );
        $query->whereAnd(array(
            'segmentFrom BETWEEN :startTs AND :endTs',
            'segmentTo BETWEEN :startTs AND :endTs'
        ), 'AND');

        if ($filters->getOperators()) {
            $operatorIds = array();
            foreach ($filters->getOperators() as $operator) {
                $operatorIds[] = (int)$operator->getId();
            }
            $query->whereAnd('operatorId IN (:operatorIds)');
            $params['operatorIds'] = $operatorIds;
        }

        if ($filters->getDepartments()) {
            $departmentIds = array();
            foreach ($filters->getDepartments() as $department) {
                $departmentIds[] = (int)$department->getId();
            }
            $query->whereAnd('departmentId IN (:departmentIds)');
            $params['departmentIds'] = $departmentIds;
        }

        if ($filters->getLocales()) {
            $query->whereAnd('locale IN (:locales)');
            $params['locales'] = $filters->getLocales();
        }

        return $this->db->select($query, $params);
    }
}