<?php

class Mapper_ThreadMessage extends Mapper_Base {
    protected static $tableName = 'threadMessage';

    public function getLastSyncedId() {
        $row = $this->db->selectOne($query = new Db_Query_Select('MAX(messageId) as messageId', self::$tableName));
        return $row ? $row['messageId'] : NULL;
    }

    public function getStatsRows(Statistic_Filters $filters) {
        $query = new Db_Query_Select(array(
            'created - toUInt32(toTime(created)) % (:step) as periodStart',
            ':step as periodLength',
            'avg(messageLength) as value'
        ), self::$tableName);


        $query->whereAnd(array(
            'date BETWEEN :startDate AND :endDate'
        ), 'AND');
        $params = array(
            'startDate' => $filters->getStartDate()->format('Y-m-d'),
            'endDate' => $filters->getEndDate()->format('Y-m-d'),
            'step' => (int)Settings::Get('statistics_min_period')
        );

        if ($filters->getOperators()) {
            $operatorIds = array();
            foreach ($filters->getOperators() as $operator) {
                $operatorIds[] = (int)$operator->getId();
            }
            $query->whereAnd('operatorId IN (:operatorIds)');
            $params['operatorIds'] = $operatorIds;
        }

        if ($filters->getDepartments()) {
            $departmentIds = array();
            foreach ($filters->getDepartments() as $department) {
                $departmentIds[] = (int)$department->getId();
            }
            $query->whereAnd('departmentId IN (:departmentIds)');
            $params['departmentIds'] = $departmentIds;
        };

        if ($filters->getLocales()) {
            $query->whereAnd('locale IN (:locales)');
            $params['locales'] = $filters->getLocales();
        };

        $query->groupBy('periodStart');
        $query->orderBy('periodStart');
        return $this->db->select($query, $params);
    }
}