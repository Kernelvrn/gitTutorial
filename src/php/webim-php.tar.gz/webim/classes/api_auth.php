<?php

require_once('../classes/common.php');
require_once('../classes/functions.php');
require_once('../classes/class.operator.php');

if (function_exists('xdebug_disable')) {
  xdebug_disable();
}

function unauthorized() {
  header('WWW-Authenticate: Basic realm="Enter user name and password to get access to the page"');
  header('HTTP/1.0 401 Unauthorized');
  echo json_safe_encode(array('error' => 'unauthorized'));
  exit();
}

if (!isset($_SERVER['PHP_AUTH_USER']) || !isset($_SERVER['PHP_AUTH_PW'])) {
  unauthorized();
}

global $MAIN_SETTINGS;

$salt = $MAIN_SETTINGS['password_salt'];
$private_key = Settings::Get('private_key');
$operator = MapperFactory::getOperatorAccountViewMapper()->getByEmailAndAccountName($_SERVER['PHP_AUTH_USER'], getAccountId());
if ($operator == null || $operator['password'] != md5($salt . $_SERVER['PHP_AUTH_PW']) || !in_array('admin', explode(',', $operator['roles']))) {
  unauthorized();
}