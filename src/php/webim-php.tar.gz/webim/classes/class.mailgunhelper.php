<?php

/**
 * Created by PhpStorm.
 * User: oleg
 * Date: 22.01.16
 * Time: 20:52
 */
class MailgunHelper {
  private static $instance = null;

  static function getInstance() {
    if (self::$instance === null) {
      self::$instance = new MailgunHelper();
    }
    return self::$instance;
  }

  public function subscribe($email, $name, $account_name) {
    $result = '';
    global $MAIN_SETTINGS;
    if (!empty($MAIN_SETTINGS['mailgun_subscribe_lists'])) {
      foreach ($MAIN_SETTINGS['mailgun_subscribe_lists'] as $list) {

        $ch = curl_init();
        curl_setopt($ch, CURLOPT_HTTPAUTH, CURLAUTH_BASIC);
        curl_setopt($ch, CURLOPT_USERPWD, 'api:' . $MAIN_SETTINGS['mailgun_key']);
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
        curl_setopt($ch, CURLOPT_CUSTOMREQUEST, 'POST');
        curl_setopt($ch, CURLOPT_URL, 'https://api.mailgun.net/v3/lists/' . $list . '/members');

        curl_setopt($ch, CURLOPT_POSTFIELDS,
          array('address' => $email,
            'name' => $name,
            'vars' => json_safe_encode(array('account_name' => $account_name)),
            'upsert' => 'yes'
          ));

        $result .= curl_exec($ch);
        curl_close($ch);
      }

    }
    return $result;
  }


}