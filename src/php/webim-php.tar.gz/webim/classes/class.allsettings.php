<?php

require_once(dirname(__FILE__) . '/class.location.php');
require_once(dirname(__FILE__) . '/common.php');


class AllSettings {

  private static $instance = NULL;

  public static function getInstance() {
    if (self::$instance == NULL) {
      self::$instance = new AllSettings();
    }
    return self::$instance;
  }

    public static function get($location)
    {
        return self::getInstance()->_get($location);
  }

    public static function reset($location = null)
    {
        self::getInstance()->_reset($location);
  }

  public function _get($location) {
    $content = $this->generateContent($location);
    file_put_contents($this->getFileName($location), $content);
    return $content;
  }

    public function _reset($location)
    {
    if ($location) {
        $fileName = $this->getFileName($location);
      if (file_exists($fileName)) {
        unlink($fileName);
      }
    } else {
      $locations = Location::enumLocationNames();
      foreach ($locations as $l) {
        $this->_reset($l);
      }
    }
  }

    private function getFileName($location)
    {
    global $MAIN_SETTINGS;
        $dir = $MAIN_SETTINGS['web_cache_dir'] . DIRECTORY_SEPARATOR . getAccountId() . '/x/js/v';
    if (!file_exists($dir)) {
      mkdir($dir, 0777, true);
    }
    return $dir . '/all-settings-' . $location . '.js';
  }

  private function generateContent($location) {
    $data = array(
      'accountBlocked' => isAccountBlocked(),
      'locationSettings' => $this->getLocationSettings($location),
      'accountConfig' => $this->getAccountConfig(),
      'accountFields' => $this->getAccountFields(),
      'ainviteRules' => $this->getAInviteRules(),
      'tariffOptions' => $this->getTariffOptions(),
      'channels' => $this->getChannels()
    );
    return 'webimApplyServerSideSettings(' . json_encode_readable($data) . ');';
  }


  private function getLocationSettings($location) {
    return Location::getLocation($location);
  }

  private function getAccountConfig() {
    $accountSettingFields = array(
      'calls', 'multilang', 'chatting_timer', 'google_analytics', 'yandex_metrika_counter_id', 'teleport',
      'v2chat_calls_enabled', 'v2chat_call_url', 'client_php_url', 'hide_referrer',
      'force_visitor_https', 'visitor_tracking', 'force_visitor_disable',
      'visitor_enabling_probability', 'default_lang', 'rate_operator',
      'max_visitor_upload_file_size', 'allowed_upload_file_types', 'callback_hunter_enabled',
      'visitor_websockets', 'visitor_upload_file', 'operator_check_status_online',
      'visitor_hints_api_endpoint', 'file_url_expiring_timeout_for_web_and_mobile',
      'operator_status_timer', 'hide_robot_presence');

    $result = array();
    foreach ($accountSettingFields as $fieldName) {
      $result[$fieldName] = Settings::Get($fieldName);

    }
    return $result;
  }

  private function getChannels(){
      return array();
  }

  private function getAccountFields() {
    $result = array();
    if (Settings::Get('calls')) {
      $account = Account::getInstance()->getCurrentAccount();
      $result['sip'] = $account['sip'];
    }
    return $result;
  }

  private function getAInviteRules() {
    $rules = AutoInvite::getInstance()->getAll();
    $result = array();
    foreach ($rules as $rule) {
      $result[] = array('id' => $rule['autoinviteid'], 'text' => smarticonv(WEBIM_ENCODING, 'utf-8', $rule['text']), 'conditions' => json_decode($rule['conditions']));
    }
    return $result;
  }

  private function getTariffOptions() {
    $allowedOptionNames = array('hide_poweredby_link', 'chat_colors', 'push_url', 'operator_file_upload', 'invitation', 'offline_message');
    $result = array();
    foreach ($allowedOptionNames as $optionName) {
        $result[$optionName] = Tariff::getInstance()->getTariffOptionValue($optionName);
    }
    return $result;
  }
}
