<?php

class Csrf {
    static public function getHash() {
        global $MAIN_SETTINGS;
        return md5(
            $_SERVER['HTTP_USER_AGENT'] .
            $_SERVER['SCRIPT_NAME'] .
            $_COOKIE[COOKIE_AUTH_TOKEN] .
            $MAIN_SETTINGS['csrf_salt']
        );
    }

    static public function check($hash) {
        global $MAIN_SETTINGS;
        if (self::getHash() !== $hash) {
            $message = 'Csrf attack on ' . $_SERVER['PHP_SELF'] . PHP_EOL
                . 'user token: ' . $_COOKIE[COOKIE_AUTH_TOKEN] . PHP_EOL
                . 'user agent: ' . $_SERVER['HTTP_USER_AGENT'] . PHP_EOL
                . 'script name: ' . $_SERVER['SCRIPT_NAME'] . PHP_EOL
                . 'salt: ' . $MAIN_SETTINGS['csrf_salt'] . PHP_EOL
                . 'recived token: ' . $hash . PHP_EOL
                . 'correct token: ' . self::getHash()
                . print_r($_REQUEST, true) . PHP_EOL
                . print_r($_SERVER, true);

            immediatelyNotifyAboutProblem($message);
            throw new Exception($message);
        }
        return true;
    }
}

?>