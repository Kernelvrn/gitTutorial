<?php
/* pl */
require_once(dirname(__FILE__) . '/functions.php');
require_once(dirname(__FILE__).'/../autoload.php');
/* end pl */

class MailStatistics {
  const FIELD_LENGTH = 14;

  private static $instance = NULL;

  static function getInstance() {
    if (self::$instance == NULL) {
      self::$instance = new MailStatistics(); // TODO make methods not static
    }
    return self::$instance;
  }

  private function __construct() {
  }

  private function __clone() {
  }

    public static function getText($dateStart, $dateEnd, $departmentId = NULL) {
        doMyLog('Getting data for: ');
        doMyLog($dateStart . ' - ' . $dateEnd);
        $mailData = array();
        $mailData['filters'] = array(
            'date_range' => array(
                'start' => new DateTime('@' . $dateStart),
                'end' => new DateTime('@' . $dateEnd)
            ),
            'department' => $departmentId,
            'locale' => NULL
        );
        $startMonthDate = clone $mailData['filters']['date_range']['start'];
        $startMonthDate->modify('first day of this month');
        $mailData['filters']['start_month_date'] = $startMonthDate;

        $threads = self::formatThreads($dateStart, $dateEnd, $departmentId);

        if (!empty($threads)) {
            if (Tariff::getInstance()->hasTariffOption('stats')) {
                if (!Settings::Get('stats_display_only')) {
                  Report::calcCachedStatsForFilters($mailData['filters']);
                }
                $reports = Report::getStatisticsReports($mailData['filters'], Settings::Get('new_stats_mode'));
                $mailData['reportTables'] = Report::convertReportsToTables($reports);
                $mailData['reportTables']['monthly'] = Report::convertDateReportToTable(
                    Report::getReportUsingSystemByDate(array(
                            'date_range' => array(
                                'start' => $mailData['filters']['start_month_date'],
                                'end' => $mailData['filters']['date_range']['end']
                            ),
                            'department' => $mailData['filters']['department']
                    ), Settings::Get('new_stats_mode'))
                );
                $mailData['reportTables']['monthly']['data'] = array();
                $mailData['reportTables']['monthly_operators'] = Report::convertSummaryOperatorReportToTable(
                    Report::getReportByOperator('operators', array(
                        'date_range' => array(
                            'start' => $mailData['filters']['start_month_date'],
                            'end' => $mailData['filters']['date_range']['end']
                        ),
                        'department' => $mailData['filters']['department']
                    ), Settings::Get('new_stats_mode'))
                );
                //logging for BUGZTASKS-1714
                if (empty($mailData['reportTables']['monthly']['total'])) {
                    doMyLog('Error at statmail sending:');
                    doMyLog(getAccountId());
                }
            }
            $viewer = new View_Html(array(
                'content_template' => 'mail/content/statistics.tpl'
            ));

            if (Settings::Get('stats_w_chats') and !empty($threads) and count($threads) < 100) {
              $mailData['chats'] = empty($threads) ? null : self::formatThreadsByThreadsHTML($threads);
            }
            return $viewer->render($mailData);
        } else {
            return NULL;
        }
    }

  public static function sendStatsIfNeeded() {
    $filename = MAIL_STATISTICS_FILE;
    $accountName = getAccountId();
    echo("Account " . $accountName);

//    $isZero = true;
////    $isZero = in_array($accountName, array('pecomru', 'promo', 'webim'));
//    if ($isZero) {
//      $hour = 0;
//    } else {
//      $hour = MAIL_STATISTICS_HOUR;
//    }
//    $launch_ts = mktime(0, 0, 0, @date('m'), @date('d'), @date('Y')) + $hour * 60 * 60;
//
//    if (time() < $launch_ts) {
//      echo "No need to send because today it's to early";
//      return false;
//    }

//    if ($isZero) {
    $date = mktime(0, 0, 0, @date('m'), @date('d'), @date('Y')) - 1 * 60 * 60; // previous day
//    $date = new DateTime(date('Y-m-d', time() - 24 * 60 * 60));
//    $date = $date->getTimestamp();
//    $date = strtotime('yesterday');
//    var_dump($date);
//    echo gmdate("Y-m-d", $date);
//    die();
//    } else {
//      $date = $launch_ts;
//    }

    $period = 'daily';

    if (Settings::Get('send_weekly_stats')) {
      if (date('w') == "1") {
        $date = array();
        $date['start'] = strtotime('today -1 week');
        $date['end'] = strtotime('today -1 minute');
        $period = 'weekly';
      } else {
        echo "No need to send because it's weekly stats and it's not monday";
      }
    }
    if (Settings::Get('send_monthly_stats')) {
      if (date('d') == "1") {
        $date = array();
        $date['start'] = strtotime('today -1 month');
        $date['end'] = strtotime('today -1 minute');
        $period = 'monthly';
      } else {
        echo "No need to send because it's monthly stats and it's not 1st day of month";
        return false;
      }
    }

    $lastSent = get_modified_time($filename);

//    echo "Launch TS " . date(DATE_RFC2822, $launch_ts);
//    echo PHP_EOL;
    echo "Last sent " . date(DATE_RFC2822, $lastSent);
    echo PHP_EOL;

    if (date("Y-m-d", $lastSent) > date("Y-m-d", $date)) {
      echo "No need to send";
      return false;
    }

    echo("seems we need to send, last launch " . $lastSent);

//    echo("Need to send");

    $res = self::sendStatsForDate($date, $period);
    touch_online_file($filename);
    return $res;
  }

  public static function sendChatToOperator($operatorId, $threadId) {
    $operator = MapperFactory::getOperatorAccountViewMapper()->getByOperatorIdAndAccount($operatorId, getAccountId());
    $thread = MapperFactory::getThreadMapper()->getByIdDefault($threadId);
    $mailData = array();
    $mailData['chat'] = self::formatThreadsByThreadsHTML(array($thread));
    $mailData['url'] = Helper::getServiceURL(null, null, null, null) . WEBIM_ROOT . "/operator/threadprocessor.php?threadid=" . urlencode($threadId);
    $viewer = new View_Html(array(
        'content_template' => 'mail/content/chat_to_operator.tpl'
    ));
    $body = $viewer->render($mailData);
    $serviceName = Resources::Get('service.name');
    $subject = $serviceName . ': ' . Resources::Get('mail.chat.subject', $operator['fullname']);
    require_once(dirname(__FILE__) . '/webim_mail.php');
    webim_mail($operator['email'], Resources::Get('email.from'), $subject, $body, 'text/html');
  }

  public static function sendStatsForDate($date, $period) {
    $res = true;
    if (is_array($date) && isset($date['start']) && isset($date['end'])) {
      $dateStart = $date['start'];
      $dateEnd = $date['end'];
    } else {
      $dateStart = $date;
      $dateEnd = $date;
    }
    //We can't use all locales, because our l18t system can change system lang one per execution (via define)
    //$possibleLocalesForStats = Resources::GetAvailableLocales();
    $possibleLocaleForStats = array('ru', 'en'); //Todo: hardcode!

    $localesDepartmentEmails[] = array(
        'locales' => getAccountId() == 'laredouteru' ? array('ru', 'en') : Helper::trimExplode(',', Settings::Get('lang_in_stats_by_mail')),
        'departmentId' => NULL, //For all departments
        'email' => Settings::Get('stats_email')
    );
    $departments = MapperFactory::getDepartmentMapper()->getAll();
    foreach ($departments as $department) {
      if (Settings::isStored('stats_email', $department['departmentid'])) {
          $email = Settings::Get('stats_email', FALSE, $department['departmentid']);
          $localesDepartmentEmails[] = array(
          'locales' => Helper::trimExplode(',', Settings::Get('lang_in_stats_by_mail', FALSE, $department['departmentid'])),
          'department' => $department,
          'email' => $email
        );
      }
    }

    var_dump($possibleLocaleForStats);
    echo PHP_EOL;

    foreach ($possibleLocaleForStats as $locale) {
      if ($locale == 'en') {
        define('LOCALE', $locale);
      }
      switch ($period) {
          case 'weekly':
              $subject = Resources::Get('mail.statistics.weekly.subject', array(date(Helper::getDateFormat(), $dateStart),date(Helper::getDateFormat(), $dateEnd)));
              break;
          case 'monthly':
              $subject = Resources::Get('mail.statistics.monthly.subject', array(date(Helper::getDateFormat(), $dateStart),date(Helper::getDateFormat(), $dateEnd)));
              break;
          case 'manual':
          case 'daily' :
          default:
              $subject = Resources::Get('mail.statistics.subject', array(date(Helper::getDateFormat(), $dateEnd)));
              break;
      }

      $from = Resources::Get('email.from');

      var_dump($localesDepartmentEmails);
      echo PHP_EOL;

      foreach ($localesDepartmentEmails as $localesDepartmentEmail) {
        if (in_array($locale, $localesDepartmentEmail['locales'])) {
          $departmentId = $departmentKey = NULL;
          if (!empty($localesDepartmentEmail['department'])) {
            $departmentId = $localesDepartmentEmail['department']['departmentid'];
            $departmentKey = $localesDepartmentEmail['department']['departmentkey'];
          }
          $email = $localesDepartmentEmail['email'];

          echo "Sending stats to $email for ". gmdate("Y-m-d", $dateStart). " " . gmdate("Y-m-d", $dateEnd) . " $departmentId" . PHP_EOL;
          $body = self::getText($dateStart, $dateEnd, $departmentId);
          if (empty($body)) {
            echo PHP_EOL . "Empty body so skipping seems we don't need to send anything";
            echo PHP_EOL;
            continue;
          }
          if (!self::sendStats($email, $from, $subject . (!empty($departmentKey) ? ' (' . $departmentKey . ')' : ''), $body, $dateEnd, $period)) {
            immediatelyNotifyAboutProblem("Could not send stats", "Could not send stats");
            echo(PHP_EOL . 'Error while sending' . (!empty($departmentKey) ? ' for department ' . $departmentKey : ''));
            echo(PHP_EOL);
            $res = false;
          }
        }
      }
      echo('Done with locale ' . $locale);
      echo '<br/>' . PHP_EOL;
    }
    return $res;
  }

  private static function sendStats($toaddr, $reply_to, $subject, $body, $date, $period) {
    if (defined('STATS_MAIL')) {
      $toaddr = STATS_MAIL;
    }
    echo('To ');
    echo($toaddr);
//    if (isMyIP()) {
//
//      die($toaddr);
//    }

    if (empty($toaddr) || empty($body)) {
      echo('Body ');
      echo($body);
      return false;
    }

    $attach = null;
//    $contentType = 'text/html';
    if (Tariff::getInstance()->getTariffOptionValue('thread_search_leads_excel_export')) {
//      require_once ('/usr/share/php/Swift/swift_required.php');

      $url = Helper::getServiceURL(null, null, null, false) . WEBIM_ROOT . '/operator/history.php?q=&date_range=' . date(Helper::getDateFormat(), $date) . '-' . date(Helper::getDateFormat(), $date) . '&operators=&rate=&departments=&locale=&offline=&mode=leads_excel';
//      if (isMyIP()) {
//        die($url);
//      }
      $fileName = 'webim_chats_' . getAccountId() . '_' . date('Y_m_d', $date) . '.xlsx'; // previous date
      $attach = Swift_Attachment::newInstance(file_get_contents($url), $fileName, 'application/vnd.ms-excel');
//      $contentType = 'multipart/mixed';
    }

    require_once(dirname(__FILE__) . '/webim_mail.php');
    $res = webim_mail($toaddr, $reply_to, $subject, $body, 'text/html', $attach);

    echo("Res was: " . $res);

    $hash = array(
        'accountname' => getAccountId(),
        'address' => $toaddr,
        'subject' => $subject,
        'period' => $period,
        'dtm' => time()
    );
  MapperFactory::getAccountSentStatsMapper()->save($hash);

    if (isMyIP()) {
      echo $res;
    }
    return true;
  }

  public static function formatThreads($dateStart, $dateEnd, $departmentId = NULL) {
    $account = Account::getInstance()->getCurrentAccount();
    return MapperFactory::getThreadMapper()->enumNotEmptyByDate($dateStart, $dateEnd, $departmentId, !empty($account['timezone']) ? $account['timezone'] : '');
  }

  public static function formatThreadsByThreads($threads) {
    $result = "";
    foreach ($threads as $thread) {
      $result .= "#" . $thread['threadid'] . " " . date(Helper::getDateTimeFormat(), $thread['created']) . "\r\n";
      if (empty($thread['threadkind'])) {
        $result .= Resources::Get('mail.statistics.thread.in_process') . PHP_EOL;
      }
      if (!empty($thread['userid'])) {
        $result .= Resources::Get('page.analysis.search.head_id') . ': ' . $thread['userid'] . PHP_EOL;
      }
      if (!empty($thread['visitorname'])) {
        $result .= Resources::Get('page_analysis.search.visitor.name')  .' ' . $thread['visitorname'] . PHP_EOL;
      }
      if (!empty($thread['departmentnames'])) {
        $result .= Resources::Get('page.analysis.search.head_department_names') . ': ' . $thread['departmentnames'] . PHP_EOL;
      }
      if (!empty($thread['departmentkeys'])) {
        $result .= Resources::Get('page.analysis.search.head_department_keys') . ': ' . $thread['departmentkeys'] . PHP_EOL;
      }
      $result .= "-----------------------------------------------\r\n";
      $lastid = "-1";
      $result .= implode("\r\n", Thread::getInstance()->GetMessages($thread['threadid'], "text", false, $lastid, true));
      $result .= "-----------------------------------------------\r\n\r\n\r\n\r\n";
    }

    return empty($threads) ? null : $result;
  }


  public static function formatThreadsByThreadsHTML($threads) {
    $result = "";
    foreach ($threads as $thread) {
      $result .= "\n<p>";
      $result .= '#' . $thread['threadid'] . ' ' . Helper::accountStrftime($thread['created']) . '<br/>';
      if (empty($thread['threadkind'])) {
        $result .= Resources::Get('mail.statistics.thread.in_process') . '<br/>' . PHP_EOL;
      }
      $result .= "</p><hr/><p>";
      $lastid = "-1";
      $m = implode("\n", Thread::getInstance()->GetMessages($thread['threadid'], "html", false, $lastid, true));
      $m = preg_replace('/<span.+?>/m', '', $m);
      $m = preg_replace('/<\/span>/m', '', $m);
      $m = preg_replace('/target="_blank"/m', '', $m);
      $result .= $m;

      $result .= "</p>\n";
      $result .= "<hr/>\n";
    }

    return empty($threads) ? null : $result;
  }
}
?>
