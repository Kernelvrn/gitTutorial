<?php
/**
 * Created by JetBrains PhpStorm.
 * User: versus
 * Date: 20.01.14
 * Time: 19:25
 *
 * General class for parse and convert various data.
 */

class Parser {
    static public function parseTo($parserName, $value) {
        $methodName = self::parserNameToMethodName($parserName);
        return self::$methodName($value);
    }

    static public  function toDateRange($value) {
        if (!empty($value)) {
            $dateRangeRegExp = '@^(\d{1,4}[-./]\d{1,2}[-./]\d{1,4})\s*[-\s]\s*(\d{1,4}[-./]\d{1,2}[-./]\d{1,4})$@i';
            $matches = array();
            if (preg_match($dateRangeRegExp, trim($value), $matches)) {
                $startDate = self::toDate($matches[1]);
                $endDate = self::toDate($matches[2]);

                if ($startDate && $endDate) {
                    return array(
                        'start' => $startDate,
                        'end' => $endDate
                    );
                }
            }
        }
        return NULL;
    }

    static public function toLower($value) {
        return $value !== NULL ? strtolower($value) : $value;
    }

    static public function toDate($value) {
        return date_create($value);
    }

    static public function toDatetime($value) {
        return self::toDate($value);
    }

    static public function toDatetimeOrNull($value) {
        return is_null($value) || $value === '' ? NULL : self::toDatetime($value);
    }

    static public function toBoolean($value) {
        if (is_string($value) && strtolower($value) == 'false') {
            return FALSE;
        }
        return (bool)$value;
    }

    static public function toArray($value) {
        if (is_array($value)) {
            return $value;
        }

        if (empty($value)) {
            return array();
        }
        return array($value);
    }

    static public function tryToUrl($value) {
        $value = (string)$value;
        if (stripos($value, 'http://') !== 0 && stripos($value, 'https://') !== 0 && Validator::isUrl('http://' . $value)) {
            return 'http://' . $value;
        }
        return $value;
    }

    static public function removeEmptyStrings($value) {
        $strArr = explode(PHP_EOL, $value);
        $strArr = array_filter($strArr);
        return implode(PHP_EOL, $strArr);
    }

    static public function trimEmptyElements(array $value) {
        return array_filter($value);
    }

    static public function emptyToNull($value) {
        return empty($value) ? NULL : $value;
    }

    static public function emptyStringToNull($value) {
        return $value === '' ? NULL : $value;
    }

    static public function toIntOrNull($value) {
        return is_null($value) || $value === '' ? NULL : (int)$value;
    }

    static public function toInt($value) {
        return (int)$value;
    }

    static private function parserNameToMethodName($parserName) {
        $methodName = str_replace(' ', '', ucwords(str_replace('_', ' ', $parserName)));
        if (!method_exists(get_called_class(), $methodName)) {
            throw new Exception('Parser error: try to use not existed parser: ' . $parserName);
        }

        return $methodName;
    }
}

?>