<?php

class AdminURL {
    private static $instance = NULL;

    public static $ADMIN_MENU = array(
        array(
            'name' => 'leftMenu.client_visitors',
            'link_name' => 'track',
            'description' => 'admin.content.client_visitors',
            'roles' => array('operator', 'supervisor', 'admin'),
            'cssclass' => 'b-visitors', 'tariff_option' => 'chat'
        ),
        array(
            'name' => 'page_analysis.search.title',
            'link_name' => 'history',
            'description' => 'content.history',
            'roles' => array('operator', 'supervisor', 'admin'),
            'tariff_option' => 'chat', 'section' => 'history'
        ),
        array(
            'name' => 'page_analysis.actions.title',
            'link_name' => 'actions',
            'description' => 'content.actions',
            'roles' => array('admin'),
            'tariff_option' => 'chat', 'section' => 'actions'
        ),
        array(
            'name' => 'statistics.title',
            'link_name' => 'statistics',
            'description' => 'statistics.description',
            'roles' => array('admin', 'report', 'supervisor'),
            'tariff_option' => 'stats',
            'section' => 'stats'
        ),
        array(
            'name' => 'online_periods.title',
            'link_name' => 'online-periods',
            'description' => 'online_periods.description',
            'roles' => array('admin', 'report', 'supervisor'),
            'tariff_option' => 'online_periods',
            'section' => 'stats'
        ),
        array(
            'name' => 'topMenu.finance',
            'link_name' => 'payments',
            'description' => 'admin.content.finance',
            'roles' => array('admin'),
            'tariff_option' => array('chat'),
            'section' => 'settings'
        ),
        array(
            'name' => 'topMenu.partner',
            'link_name' => 'partner',
            'description' => 'admin.content.partner',
            'roles' => array('admin'),
            'tariff_option' => 'partner',
            'section' => 'settings'
        ),
        array(
            'name' => 'leftMenu.client_agents',
            'link_name' => 'operators',
            'description' => 'admin.content.client_agents',
            'roles' => array('operator', 'supervisor', 'admin'),
            'tariff_option' => 'operators_list', 'section' => 'settings'
        ),
        array(
            'name' => 'menu.blocked',
            'link_name' => 'blocked',
            'description' => 'content.blocked',
            'roles' => array('operator', 'supervisor', 'admin'),
            'tariff_option' => 'ban',
            'more' => array('ban'),
            'section' => 'settings'
        ),
        array(
            'name' => 'leftMenu.auto_invites',
            'link_name' => 'auto_invites',
            'description' => 'admin.content.auto_invites',
            'roles' => 'admin',
            'more' => array('auto_invite'),
            'tariff_option' => 'chat',
            'section' => 'settings'
        ),
        array(
            'name' => 'leftMenu.departments',
            'link_name' => 'departments',
            'description' => 'page_departments.intro',
            'roles' => array('admin', 'supervisor'),
            'more' => array('department'),
            'section' => 'settings',
            'tariff_option' => 'departments'
        ),
        array(
            'name' => 'leftMenu.client_gen_button',
            'link_name' => 'getcode',
            'description' => 'admin.content.client_gen_button',
            'roles' => 'admin',
            'tariff_option' => 'chat',
            'section' => 'settings'
        ),
        array(
            'name' => 'leftMenu.client_settings',
            'link_name' => 'settings',
            'description' => 'admin.content.client_settings',
            'roles' => 'admin',
            'tariff_option' => 'chat',
            'section' => 'settings'
        ),
        array(
            'name' => 'leftMenu.callback_history',
            'link_name' => 'callback_history',
            'description' => 'admin.content.callback_history', 
            'roles' => array('operator', 'supervisor', 'admin'), 
            'tariff_option' => 'callback_hunter', 'section' => 'history'
        ),
        array(
            'name' => 'topMenu.logoff',
            'link_name' => 'logout',
            'description' => 'content.logoff',
            'roles' => array('operator', 'supervisor', 'admin', 'report')
        ),
    );


    public static function getInstance() {
        if (self::$instance == NULL) {
            self::$instance = new AdminURL();
        }
        return self::$instance;
    }

    private function __construct() {
    }

    private function __clone() {
    }

    public function getURL($name, $lang = NULL, $isWithParamPostfix = NULL) {
        if ($lang === NULL) {
            $langParam = '';
            $postfix = $isWithParamPostfix ? '?' : '';
        } else {
            $langParam = '?lang=' . $lang;
            $postfix = $isWithParamPostfix ? '&' : '';
        }

        return '/operator/' . $name . '.php' . $langParam . $postfix;
    }

}

?>
