<?php
require_once('common.php');
require_once('models/generic/class.mapperfactory.php');
require_once ("class.operator.php");

class OnlinePeriodsUpdater {

    private static $instance;
    private static $OPERATOR_STATUS = 'operator_last_status';

    public static function getInstance() {
        if (empty(self::$instance)) {
            self::$instance = new OnlinePeriodsUpdater();
        }

        return self::$instance;
    }

    private function __construct() {
    }

    private function  __clone() {
    }

    public function operatorOnlineStatusChanged($operator, $status, $departments, $locales) {
        /* @var $mapper <OnlinePeriodsMapper> */
        try {
            if ($status == OPERATOR_STATUS_ONLINE) {
                if (!isset($_SESSION['operator_last_status']) || !$_SESSION['operator_last_status'] == OPERATOR_STATUS_ONLINE) {
                    $_SESSION['operator_last_status'] = OPERATOR_STATUS_ONLINE;
                    $mapper = MapperFactory::getOnlinePeriodsMapper();
                    $mapper->setOnlineStatus($operator);
                }                
            } else {
                $_SESSION['operator_last_status'] = OPERATOR_STATUS_OFFLINE;
                $mapper = MapperFactory::getOnlinePeriodsMapper();
                $mapper->setOfflineStatus($operator);
            }
        } catch (Exception $e) {}
    }

}
?>
