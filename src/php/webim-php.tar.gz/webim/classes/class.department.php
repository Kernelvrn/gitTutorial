<?php 
require_once('common.php');
require_once('models/generic/class.mapperfactory.php');

class Department {
  private static $instance = NULL;

  /**
   * @return Department
   */
  static function getInstance() {
    if (self::$instance == NULL) {
      self::$instance = new Department();
    }
    return self::$instance;
  }

  private function __construct() {
  }
  
  private function __clone() {
  }

  function save($hash, $locale) {
    $d['departmentkey'] = $hash['departmentkey'];
    $d['departmentorder'] = $hash['departmentorder'];
    $d['departmentgeo'] = $hash['departmentgeo'];
    $d['ishidden'] = $hash['ishidden'];
    $d['config'] = json_encode($hash['config']);
	$dl = array('departmentname' => $hash['departmentname'], 'locale' => $locale);

    $id = null;

    if (empty($d['config'])){
        $d['config'] = '{"answers":"{}"}';
    }
    
    if (isset($hash['departmentid'])) { // existing department
      $d['departmentid'] = $hash['departmentid'];
      $id = $d['departmentid'];
      
      MapperFactory::getDepartmentMapper()->save($d);
    } else { // new department
      if(empty($d['departmentorder'])) {
        $max_order = MapperFactory::getDepartmentMapper()->getMaxOrder();
        $next_order = intval($max_order / 100) * 100 + 100;
        $d['departmentorder'] = $next_order;  
      }
      
      $id = MapperFactory::getDepartmentMapper()->save($d);
    }

    // check if locale exists
    $localeid = MapperFactory::getDepartmentLocaleMapper()->getDepartmentLocale($id, $locale);
    if (!empty($localeid)) {
      $dl['departmentlocaleid'] = $localeid['departmentlocaleid'];
    } 

    $dl['departmentid'] = $id;
    MapperFactory::getDepartmentLocaleMapper()->save($dl);
    Helper::clearDepartmentsCache();
    return $id;
  }
  
  
  function getById($id, $locale) {
    $department = MapperFactory::getDepartmentMapper()->getById($id);
    $hash2 = MapperFactory::getDepartmentLocaleMapper()->getDepartmentLocale($id, $locale);

    if (!empty($hash2)) {
       $department = array_merge($department, $hash2);
    }

    $department['config'] = !empty($department['config']) ? json_decode($department['config'], true) : array();

    return $department;
  }

  public function departmentsExist() {
      return MapperFactory::getDepartmentMapper()->departmentsExist();
  }

  public function deleteDepartment($departmentid) {
    MapperFactory::getDepartmentMapper()->deleteDepartment($departmentid);
  }

  public function updateDepartmentDeletedStatus($departmentId, $deleted) {
      MapperFactory::getDepartmentMapper()->save(array('departmentid' => $departmentId, 'deleted' => $deleted));
      KeyValueCache::clearKind('settings_department_' . $departmentId);
      Helper::clearDepartmentsCache();
      Helper::clearOperatorsCache();
  }

  public function updateDepartmentAnswers($departmentId, $newAnswers, $lang) {
      $dep = Department::getById($departmentId, $lang);
      $answers = Settings::Get('answers', FALSE, $departmentId);
      $answers[$lang] = $newAnswers;
      $dep['config']['answers'] = json_encode($answers);

      $jsonConfig = json_encode($dep['config']);
      if (strlen($jsonConfig) > 500000) {
          throw new Exception('Department->updateDepartmentAnswers: Department predefined answers too long');
      }

      MapperFactory::getDepartmentMapper()->save(array('departmentid' => $departmentId, 'config' => $jsonConfig));
      KeyValueCache::clearKind('settings_department_' . $departmentId);
      KeyValueCache::clearKind('settings');

  }

  public function uploadDepartmentLogo($departmentid, $requestFile) {
//      MYLOG('uploadDepartmentLogo');
      $dir = FilesLocation::getAccountDepartmentLogosPath();
      $res = uploadFile($requestFile, $dir . '/', getAccountId() . '_' . $departmentid, true, 1 * 1024 * 1024);
      return $res;
  }

  public function makeLogoURL($departmentid) {
      return WEBIM_ROOT . '/images/department_logo/' . getAccountId() . '_' . $departmentid . '.' . DEFAULT_IMAGE_EXT;
  }
}
?>