<?php
require_once(dirname(__FILE__) . '/models/generic/class.mapperfactory.php');
require_once(dirname(__FILE__) . '/../autoload.php');
//require_once (dirname(__FILE__) . '/partner_functions.php');

/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 * Special singletone class.
 *
 * @author denis
 */
class Account {

  static private $instance = null;
  /**
   * @var AccountMapper
   */
  static private $accountMapper;

  static function getInstance() {
    if (self::$instance == null) {
      self::$instance = new Account();
      self::$accountMapper = MapperFactory::getAccountMapper();

    }
    return self::$instance;
  }

  protected $accounts = array();
  protected $currentAccount = array();

  private function __construct() {

  }

  private function __clone() {


  }

  /**
   * Checks if account with the $name exists in the DB.
   *
   * @param string $name name of the account
   * @return boolean true if account exists or false
   */
//  private function isAccountExists($name) {
//    return self::$accountMapper->isValueExists("accountname", $name);
//  }


  /**
   * Checks if account with this $name is activated.
   *
   * @param string $name name of the account
   * @return boolean true if account active or false
   */
  public function isAccountConfirmed($name) {
    return self::$accountMapper->isAccountActive($name);
  }


  /**
   * Create new account with the specific $name and $email and send
   * registration information to the recipient.
   *
   * @param string $name name of the account.
   * @param string $passwordOrOperator password of the current account.
   * @param string $email email of the account.
   * @param string $partner partner accountname in case if account is created
   * for the client of partner.
   */
  public function createAccount($email, $person, $phone, $site, $passwordOrOperator, $partner = null, $skipActivation = false, $hideFinance = false, $test_period = true, $promocode = NULL, $timezoneId = DEFAULT_TIMEZONE_ID) {
//    if (!strstr($site, '.')) {
//      return 'error';
//    }
    if (seems_utf8($site)) {
       $site = iconv('utf-8', WEBIM_ENCODING, $site);
     }
    $siteEN = smarticonv(WEBIM_ENCODING, 'latin', $site);
    $accountName = $this->generateAccountName($siteEN);
    $token = md5(uniqid());

    if (is_array($passwordOrOperator)) {
      $o = $passwordOrOperator;
    } else {
      $o = MapperFactory::getOperatorMapper()->createOperator($email, $person, $passwordOrOperator, TRUE);
    }

    if (!empty($promocode)) {
        $promo = MapperFactory::getPromocodeMapper()->getByCode($promocode);
    }

    $userinfo = array();
    if (isset($_SERVER['HTTP_USER_AGENT'])) {
      $userinfo['useragent'] =  $_SERVER['HTTP_USER_AGENT'];
    }
    if (isset($_COOKIE['WEBIM_REFERAL'])) {
      $userinfo['WEBIM_REFERAL'] = urldecode($_COOKIE['WEBIM_REFERAL']);
    }
    if (isset($_COOKIE['WEBIM_LANDING'])) {
      $userinfo['WEBIM_LANDING'] = urldecode($_COOKIE['WEBIM_LANDING']);
    }

    $accountData = array(
      'accountname' => $accountName,
      'phone' => $phone,
      'site' => $site,
      'timezone' => $timezoneId,
      'userinfo' => json_encode($userinfo)
    );
    if (!empty($promo)) {
      $accountData['profreedate'] = getCurrentDBTime() +
          (!empty($promo['free_period']) ? $promo['free_period'] * 24 * 60 * 60 : 365 * 24 * 60 * 60);
      $accountData['promocode'] = $promo['promocode'];
    } elseif ($test_period) {
      $accountData['profreedate'] = getCurrentDBTime() + 7 * 24 * 60 * 60;
    } else {
      $accountData['profreedate'] = getCurrentDBTime() - 24 * 60 * 60;
    }
    if (!$skipActivation) {
      $accountData['registertoken'] = $token;
    }

    if ($hideFinance === true) {
        $accountData['is_partner_client'] = 1;
    }

    if ($partner !== null) {
      $accountData['partner'] = $partner;
    } elseif (!empty($promo)) {
      $accountData['partner'] = $promo['partner_accountname'];
      $accountData['tariff'] = $promo['tariff'];
    } else {
      $accountData['partner'] = 'webim';
    }

    $res = MapperFactory::getAccountMapper()->addAccount($accountData);

    MapperFactory::getOperatorAccountMapper()->setOperatorRolesForAccount($o['operatorid'], 'admin', $accountName);

    if ($res !== null && !$skipActivation) {
      MailNotifications::sendRegistrationMail($accountName, $email, $person, $token);
    }
    //      $partner == null ?
    //          MailNotifications::sendRegistrationMailToPartnersClient($accountName,
    //            $email, $token, $password);
    //    }
    return $res;
  }

  public function generateAccountName($site) {
    $accountName = strtolower(trim(substr($site, 0, min(50, strlen($site)))));
    $accountName = preg_replace('/\W/', '', $accountName);
    $accountName = preg_replace('/^https/', '', $accountName);
    $accountName = preg_replace('/^http/', '', $accountName);
    $accountName = preg_replace('/^www/', '', $accountName);

    if (function_exists('transliterator_transliterate')) {
      $accountName = transliterator_transliterate('Any-Latin; Latin-ASCII; Lower()', $accountName);
    } else {
      $accountName = smarticonv(WEBIM_ENCODING, 'latin', $accountName);
    }

    if (self::$accountMapper->ifAccountExists($accountName) > 0) {
      $count = self::$accountMapper->countAccountsForSite($accountName);
      $origAccountname = $accountName;

      for (;;) {
        $accountName = $origAccountname. sprintf("%03d", $count ++);
        if (!self::$accountMapper->ifAccountExists($accountName) > 0) {
          break;
        }
      }
    }
    return $accountName;
  }

  public function getAccountByName($accountname) {
      if (empty($this->accounts[$accountname])) {
          $this->accounts[$accountname] = self::$accountMapper->getAccountByField($accountname, 'accountname');
      }
      return $this->accounts[$accountname];
  }

  public function getCurrentAccount() {
    if (empty($this->currentAccount)) {
        $this->currentAccount = KeyValueCache::getCachedResults('current', 'accounts', function () {
            $account = Account::getInstance()->getAccountByName(getAccountId());
            $url = Helper::getServiceURL(getAccountId(), SERVICE_USER, SERVICE_PASSWORD) . '/l/i/account-state?action=get_state';
            try {
                $ch = curl_init();
                curl_setopt($ch, CURLOPT_URL, $url);
                curl_setopt($ch, CURLOPT_TIMEOUT, 3);
                curl_setopt($ch, CURLOPT_RETURNTRANSFER, true); // Saving a curl response into a php variable
                $result = curl_exec($ch);
                curl_close($ch);
                $response = json_decode($result, true);
                $account['isblocked'] = $response['blocked'];
            } catch (Exception $e) {
                $account['isblocked'] = false;
            }

            return $account;
        });
    }
    return $this->currentAccount;
  }

  public function getAccountById($id) {
    return self::$accountMapper->getAccountByField($id, 'accountid');
  }

  public function getAccountByEmail($email) {
    return self::$accountMapper->getAccountByField($email, 'email');
  }

//  public function getAccountByRegisterToken($token) {
//    return self::$accountMapper->getAccountByField($token, 'registertoken');
//  }

  public function updateAccount($data) {
    return self::$accountMapper->save($data);
  }

  /**
   *  Checks if session exists for the current user connection or
   * WEBIM_PROFILE_AUTH cookie is set.
   *
   * @return boolean true if exists or false.
   */
  public function ensureUserIsAuthorized1() {
    if (isset($_SESSION[SESSION_OPERATOR]) && is_array($_SESSION[SESSION_OPERATOR])) {
      return true;

    } else if (isset($_COOKIE['WEBIM_PROFILE_AUTH'])) {
      list($login, $pwd) = preg_split(',', $_COOKIE['WEBIM_PROFILE_AUTH'], 2);

      if (self::$accountMapper->isAccountExists($login, $pwd)) {
        $this->createSessionForUser($login);
        return true;
      } else {
        return false;
      }
    } else {
      return false;
    }
  }


  /**
   * Gets bookkeeping card for account with $id.
   *
   * @param int $id id of the account.
   * @return array information about this account or null.
   */
  public function getOrganizationByAccountName() {
    $mapper = MapperFactory::getBuhCardMapper();
    return $mapper->getBuhCardByField($_SESSION[SESSION_OPERATOR]['accountid'], 'accountid');
  }

  public function getServiceProFreePeriod() {
    return MapperFactory::getAccountMapper()->getServiceProFreePeriod(
      $_SESSION[SESSION_OPERATOR]['accountname']);
  }

  public function getAccountWithRateFullDescription() {
    $result = $this->getAccountById($_SESSION
                                    [SESSION_OPERATOR]['accountid']);

    if (is_array($result) && !empty($result['ratetype'])) {
      return array_merge($result, MapperFactory::getProRateMapper()->
                                    getDescription($result['ratetype']));
    }
  }

  public function acceptClientPayment($pro_service_invoice) {
    return MapperFactory::getInvoiceMapper()->createServiceProInvoice($pro_service_invoice);
  }

  public function getRatesListExludeCurrent($current_client_rate) {
    return MapperFactory::getProRateMapper()->getRatesListExcludeCurrentAndFreeRate($current_client_rate);
  }

  public function setupIpAndPortFilesForAccounts() {
    self::setupIpAndPortForAccounts(isMyIP());

    $myip = $_SERVER['SERVER_ADDR'];
    $accounts = MapperFactory::getAccountMapper()->enumAccountsByIP($myip);
    foreach ($accounts as $a) {
      if (empty($a['tornado_port'])) {
        continue;
      }
      $rmCmd = 'rm ' . FilesLocation::getAccountPortsPath($a['accountname']) .'/' . $a['accountname'] . '-port-*'; //New path
      `$rmCmd`;
      $rmCmd = 'rm ' . FilesLocation::getAccountPortsPath($a['accountname'], 'port') .'/' . $a['accountname'] . '-port-*'; //Old path
      `$rmCmd`;
      touch(FilesLocation::getAccountPortsPath($a['accountname']) .'/' . $a['accountname'] . '-port-' . $a['tornado_port']);
    }
  }

  public function setupIpAndPortForAccounts($verbose = false) {
    global $TORNADO_PORTS;
    $accounts = MapperFactory::getAccountMapper()->enumNotBlockedAccounts();

    usort($accounts, function($a1, $a2) {
        return (isset($a1['load_weight']) ? ($a1['load_weight'] + 0) : 100) < (isset($a2['load_weight']) ? ($a2['load_weight'] + 0)
            : 100);
      });

    if ($verbose) {
      echo 'Got accounts';
      var_dump($accounts);
    }

    $arr = array();

    foreach ($accounts as $a) {
      if (empty($a['server_ip'])) {
        continue;
      }

      $weight = $a['load_weight'];
      $ip = $a['server_ip'];
      $port = $a['tornado_port'];
      if (empty($arr[$ip][$port])) {
        foreach ($TORNADO_PORTS as $p) {
          $arr[$ip][$p] = 0;
        }

      }
      if (empty($arr[$ip][$port])) {
        $arr[$ip][$port] = $weight;
      } else {
        $arr[$ip][$port] += $weight;
      }
    }

    if ($verbose) {
      var_dump($arr);
    }


    foreach ($accounts as $a) {
      $accountName = $a['accountname'];

      if (!empty($a['tornado_port'])) {
        continue;
      }


      $ip = empty($a['server_ip']) ? gethostbyname(Helper::getServiceDomain($accountName)) : $a['server_ip'];

      //      $verbose = $ip == '46.4.107.118';

      if ($verbose) {
        echo 'Working with ';
        var_dump($a);
        echo "\n";
      }

      // looking for less loaded port
      $min = null;
      $p = null;
      if (isset($arr[$ip])) {
        foreach ($TORNADO_PORTS as $port) {
          $load = $arr[$ip][$port];

          $min = $min === null ? $load : min($min, $load);
          if ($min == $load) {
            $p = $port;
          }
        }
      } else {
        foreach ($TORNADO_PORTS as $p) {
          $arr[$ip][$p] = 0;
        }
      }

      if ($verbose) {
        echo 'Found port ' + $p;
        echo "\n";
      }


      if ($p === null) {
        $p = $TORNADO_PORTS[rand(0, 100000) % count($TORNADO_PORTS)];
      }

      $a['tornado_port'] = $p;
      $a['server_ip'] = $ip;
      $a['load_weight'] = isset($a['load_weight']) ? $a['load_weight'] : 100;

      MapperFactory::getAccountMapper()->save($a);

      $arr[$ip][$p] += $a['load_weight'];

      if ($verbose) {
        echo 'Arr became ';
        var_dump($arr);
        echo "\n";
      }

    }


  }

  public function installServiceProForClient($accountName, $email, $person, $site) {
    global $DBSETTINGS;
    $s = $DBSETTINGS['pro'];

    $res = MapperFactory::getAccountCreatorMapper()->createAccountDatabase($accountName);
    if ($res === null) {
      return null;
    }

//    self::setupIpAndPortForAccounts();
      $this->createPortFiles($accountName);
//    touch("/etc/nginx/ports/$accountName-eta");
//    touch("/etc/nginx/ports/$accountName-port-8260");

    $url = Helper::getServiceURL($accountName, SERVICE_USER, SERVICE_PASSWORD, false) . '/webim/install/';
    $url = str_replace('https://', 'http://', $url);
    //$url = str_replace("{accountname}", $accountname, SERVICE_PRO_ROOT_ADDRESS).'/webim'.'/install/';
    $post_content = 'key=partnerka&dbhost=' . $s['host'] .
                    '&dbname=webim_service_pro_' .
                    urlencode($accountName) .
                    '&dbuser=' . urlencode($s['user']) .
                    '&dbpassword=' . urlencode($s['password']) .
                    '&name=' . urlencode($person) .
                    '&site=' . urlencode($site) .
                    '&lang=' . (isset($_COOKIE['WEBIM_LOCALE']) ? $_COOKIE['WEBIM_LOCALE'] : Settings::Get('default_lang')) .
                    '&adminemail=' . urlencode($email) .
                    '&encoding=' . WEBIM_ENCODING . '&dbtype=' . SITE_DB_TYPE .
                    '&act=step2&submitted=true';

    doMyLog("Trying to register for url $url");
    doMyLog("Trying to register for post $post_content");

//    if (isMyIP()) {
//      var_dump($post_content);
//      die();
//    }

      $response = $this->useCURLForProCreating($url, $post_content);

      //$response = useStreamContextForProCreating($url, $post_content);
      doMyLog("got response $response");


  //      if (isMyIP()) {
  //        var_dump($post_content);
  //        var_dump($response);
  //        die();
  //      }
    $response = json_decode($response, true);

    if ($response === null or $response['result'] != 'ok') {
      doMyLog("Sending failures");
      MailNotifications::serviceProCreationFailureMail($accountName, $url, $response, $post_content);
      return false;
    } else {
      doMyLog("Creating files");
      $fileName = FilesLocation::getAccountStatusFilePath($accountName) . '/' . $accountName . ACCOUNT_STATUS_FILE_EXT;
      $res = touch($fileName);
      if (!$res) {
        doMyLog("Could not touch file");
        MailNotifications::serviceProCreationFailureMail($accountName, $url, $response, $fileName);
        return false;
      }
      doMyLog("Everyting is fine sending email");
      MailNotifications::serviceProCreationSuccessMail($accountName, $url);
    }

    doMyLog("Return true");
    return true;
  }

  private function  useCURLForProCreating($url, $post_content) {
    $ch = curl_init();
    curl_setopt($ch, CURLOPT_URL, $url); // set url to post to
    curl_setopt($ch, CURLOPT_FAILONERROR, 1);
    curl_setopt($ch, CURLOPT_FOLLOWLOCATION, 1); // allow redirects
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1); // return into a variable
    curl_setopt($ch, CURLOPT_TIMEOUT, 60); // times out after 4s
    curl_setopt($ch, CURLOPT_POST, 1); // set POST method
    curl_setopt($ch, CURLOPT_POSTFIELDS, $post_content); // add POST fields
    $result = curl_exec($ch); // run the whole process
    curl_close($ch);

    return $result;
  }

  private function createPortFiles($accountName) {
    $port = $_SERVER['X_TORNADO_PORT'];

    $serverLetter = NULL;
    $matches = array();
    if (preg_match('/\/public_html\.(\w+)\//', $_SERVER['SCRIPT_FILENAME'], $matches)) {
      $serverLetter = $matches[1];
    }

    if (!empty($port) && !empty($serverLetter)) {
      touch(FilesLocation::getAccountPortsPath($accountName) . '/' . $accountName . '-port-' . $port);
      touch(FilesLocation::getAccountPortsPath($accountName) . '/' . $accountName . '-' . $serverLetter);
    } else {
      touch(FilesLocation::getAccountPortsPath($accountName) . '/' . $accountName . '-eta');
      touch(FilesLocation::getAccountPortsPath($accountName) . '/' . $accountName . '-port-8260');
//      Throw new Exception('Error: can\'t define port or server name for account "' . $accountName . '". Found port = "' . $port . '", server name = "' . $serverLetter .'"');
    }
  }

    public function getAvailableOperatorStatuses($lang = null) {
        $availableStatuses = Tariff::getInstance()->getTariffOptionValue('available_operator_statuses');

        $result = array();

        $statusValues = $availableStatuses ? explode(',', $availableStatuses) : array('online', 'invisible', 'offline');
        foreach($statusValues as $status) {
            $status = trim($status);
            $result[] = array(
                'value' => $status,
                'name' => Resources::Get('operator_status.' . $status, array(), $lang),
                'color' => $status == 'online' ? '#4f8a00' : ($status == 'offline' ? '#808080' : '#ffb400'));
        }

        return $result;
    }

    public function calcTimeOffset(DateTime $date) {
      $timezone = $this->getCurrentAccount();
      $timezone = $timezone['timezone'];
      if (empty($timezone)) {
          return 0;
      }
      $baseTimezone = new DateTimeZone(date_default_timezone_get());
      $accountTimezone = new DateTimeZone($timezone);
      $timeOffset = $accountTimezone->getOffset($date) - $baseTimezone->getOffset($date);

      return $timeOffset;
    }
}

?>
