<?php
require_once(dirname(__FILE__) . '/functions.php');
require_once(dirname(__FILE__) . '/common.php');
require_once(dirname(__FILE__) . '/class.helper.php');

class Authtoken {

  public static function getTokenInfo($authToken) {
    $info = KeyValueCache::get($authToken, 'auth-token', null);
    if ($info === null) {
      $decoded = base64_decode($authToken);
      list ($operatorId, $token) = explode('|', $decoded);
      $info = MapperFactory::getAuthtokenMapper()->getTokenInfo($operatorId, $authToken);
      KeyValueCache::put($authToken, $info, 'auth-token', 300);
    }
    return $info;
  }

  public static function addToken($operatorId, $authToken, $userAgent, $persistent, $created_time = null) {
    MapperFactory::getAuthtokenMapper()->addToken($operatorId, $authToken, $userAgent, $persistent, $created_time);
  }

  public static function deleteToken($token) {
    MapperFactory::getAuthtokenMapper()->delete($token['id']);
    KeyValueCache::clear($token['authtoken'], 'auth-token');
  }

  public static function clearOtherOperatorTokens($operatorId) {
    $tokens = MapperFactory::getAuthtokenMapper()->makeSearch('operatorid = :operator',
      array('operator' => $operatorId));
    foreach ($tokens as $token) {
      if (isset($_COOKIE[COOKIE_AUTH_TOKEN]) && ($token['authtoken'] != $_COOKIE[COOKIE_AUTH_TOKEN])) {
        self::deleteToken($token);
      }
    }
    $url = Helper::getServiceURL(getAccountId(), SERVICE_USER, SERVICE_PASSWORD) . '/l/i/disconnect-devices?operator-id='.$operatorId;
    @file_get_contents($url);
  }

}
