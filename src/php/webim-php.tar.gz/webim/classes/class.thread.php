<?php
require_once ('class.settings.php');
require_once ('class.browser.php');
require_once ('class.visitsession.php');
require_once ('class.operator.php');
require_once ('class.department.php');
require_once (dirname(__FILE__).'/class.keyvaluecache.php');
require_once('models/generic/class.mapperfactory.php');
require_once ('webim_mail.php');

/* p */
require_once 'class.geoiplookup.php';
/* end p */

class Thread  {
  private static $kindToString = array(
    KIND_USER => 'visitor',
    KIND_AGENT => 'agent',
    KIND_FOR_AGENT => 'hidden',
    KIND_INFO => 'inf',
    KIND_CONN => 'conn',
    KIND_EVENTS => 'event',
    KIND_RATE => 'rate',
    KIND_AVATAR => 'avatar',
    KIND_AGENT_BUSY=> 'agentbusy',
    KIND_CONT_REQ => 'agent',
    KIND_CONTACTS => 'visitor',
    KIND_FIRST_AUX_MESSAGE => 'visitor',                
  );

  private static $kindToPythonString = array (
        1 => 'visitor',
        2 => 'operator',
        3 => 'for_operator',
        4 => 'info',
        9 => 'operator_busy',
        10 => 'cont_req',
        11 => 'contacts',
        13 => 'file_operator',
        14 => 'file_visitor',
        16 => 'operator_note',
        17 => 'action_request'

  );

  private static $instance = NULL;

  /**
   * @return Thread
   */  
  static function getInstance() {
  // TODO: mind the casing
    if(self::$instance == NULL) {
      self::$instance = new Thread();
    }
    return self::$instance;
  }

  private function __construct() {

  }

  private function __clone() {
  }

  public static function shouldCheckDepartmentAccess($operatorId) {
    if (Operator::getInstance()->isOperatorAdmin()) {
      return false;
    }

    return Department::getInstance()->departmentsExist();
  }


    /**
     * @deprecated getMessagesByThread should be used instead
     * @param $threadId
     * @param $method
     * @param $isForVisitor
     * @param $lastId
     * @param bool $forceShowingRates
     * @param bool $isHasAlertMessages
     * @return array
     */
    function GetMessages($threadId, $method, $isForVisitor, &$lastId, $forceShowingRates = false, &$isHasAlertMessages = false) {
        if ($forceShowingRates || ($isForVisitor == false && Operator::getInstance()->isOperatorAdmin())) {
            $crm = MapperFactory::getRateMapper();
            $rates = $crm->getByThreadidWithOperator($threadId);
            $currentRate = array_shift($rates);
        } else {
            $rates = array();
            $currentRate = null;
        }

        $res = MapperFactory::getMessageMapper()->getListMessages($threadId, $lastId, $isForVisitor);

        $messages = array();
        $prevDate = null;

        $operatorFullNames = $this->getOperatorFullNames();

        foreach ($res as $msg) {
            $messageJson = json_decode($msg['json'], true);
            if (isset($messageJson['deleted']) && $messageJson['deleted'] == TRUE) {
                continue;
            }

            $date = date(Helper::getDateFormat(), $msg['created']);
            if ($prevDate <> $date) {
                $newDateText = $date;
                $prevDate = $date;
            } else {
                $newDateText = null;
            }

            $isHasAlertMessages = $isHasAlertMessages || $msg['kind'] != KIND_FOR_AGENT;

            $message = '';
            switch ($method) {
                case 'xml':
                    if ($msg['kind'] == KIND_AVATAR) {
                        $message = '<avatar>' . Browser::AddCdata($msg['message']) . '</avatar>';
                    } else {
                        $message = '<message>' . Browser::AddCdata($this->messageToHtml($msg)) . '</message>\n';
                    }
                    break;
                case 'text':
                    if ($newDateText !== null) {
                        $newDateText .= PHP_EOL;
                    }
                    $message = $this->messageToText($msg);
                    break;
                case 'html':
                    if ($newDateText !== null) {
                        $newDateText = "<p style='font-weight: bold'>$newDateText</p>";
                    }
                    if ($currentRate && $currentRate['date'] < $msg['created']) {
                        $messages[] = $this->rateToHtml($currentRate);
                        $currentRate = array_shift($rates);
                    }

                    $isForVisitor = verify_param('visitor', '/^true$/', 'false') == 'true';
                    $cleanupSpecialTags = !$isForVisitor;

                    $message = $this->messageToHtml($msg, $cleanupSpecialTags, $operatorFullNames);
                    break;
                case 'json':
                    $message = $this->messageToJson($msg);
                    break;
            }

            if ($newDateText !== null && $method != 'json') {
                $messages[] = $newDateText;
            }
            if (!empty($message)) {
                $messages[] = $message;
            }

            if ($msg['messageid'] > $lastId) {
                $lastId = $msg['messageid'];
            }
        }

        if ($method == 'html') {
            if ($currentRate) {
                $messages[] = $this->rateToHtml($currentRate);
            }
            foreach ($rates as $rate) {
                $messages[] = $this->rateToHtml($rate);
            }
        }

        return $messages;
    }

  public function getMessagesByThread(array $threadIds, $method = 'text', $forceDeleted = FALSE) {
      $messages = MapperFactory::getMessageMapper()->getMessagesByThread($threadIds);
      $messagesByThread = array();
      foreach ($messages as $message) {
          $messagesByThread[$message['threadid']]['messages'][] = $message;
      }
      if (Operator::getInstance()->isOperatorAdmin()) {
          $rates = MapperFactory::getRateMapper()->getRatesByThreadIds($threadIds);
          foreach ($rates as $rate) {
              if (array_key_exists($rate['threadid'], $messagesByThread)) {
                  $messagesByThread[$rate['threadid']]['rates'][] = $rate;
              }
          }
      }

      $processedMessagesByThread = array();
      foreach ($messagesByThread as $threadId => $thread) {
          $processedMessagesByThread[$threadId] = $this->processThread($thread, $method, $forceDeleted);
      }

      return $processedMessagesByThread;
  }

  protected function processThread(array $thread, $method = 'text', $forceDeleted = FALSE) {
      $processedMessages = array();
      $rates = !empty($thread['rates']) ? $thread['rates'] : array();
      $currentRate = !empty($rates) ? array_shift($rates) : null;
      foreach ($thread['messages'] as $message) {
          $messageJson = json_decode($message['json'], true);
          if (isset($messageJson['deleted']) && $messageJson['deleted'] == TRUE && !$forceDeleted) {
              continue;
          }

          switch ($method) {
              case 'xml':
                  if ($message['kind'] == KIND_AVATAR) {
                      $processedMessage = '<avatar>' . Browser::AddCdata($message['message']) . '</avatar>';
                  } else {
                      $processedMessage = '<message>' . Browser::AddCdata($this->messageToHtml($message)) . '</message>\n';
                  }
                  break;
              case 'text':
                  $processedMessage = $this->messageToText($message);
                  break;
              case 'html':
                  if ($currentRate && $currentRate['date'] < $message['created']) {
                      $processedMessages[] = $this->rateToHtml($currentRate);
                      $currentRate = array_shift($rates);
                  }
                  $processedMessage = $this->messageToHtml($message, true);
                  break;
              case 'json':
                  $processedMessage = $this->messageToJson($message);
                  break;
          }

          if (!empty($processedMessage)) {
              $processedMessages[] = $processedMessage;
          }
      }

      if ($method == 'html') {
          if ($currentRate) {
              $processedMessages[] = $this->rateToHtml($currentRate);
          }
          foreach ($rates as $rate) {
              $processedMessages[] = $this->rateToHtml($rate);
          }
      }

      return $processedMessages;
  }

  function GetThreadById($threadid) {
    return MapperFactory::getThreadMapper()->getById($threadid);
  }

  function removeRate($rateid) {
    MapperFactory::getRateMapper()->removeRate($rateid);
  }

  /** Helper methods **/
  private function rateToHtml($rate) {
    $message = "<span>" . date("H:i:s", $rate['date']) . "</span> ";
    $message .=  "<span class='m".self::$kindToString[KIND_RATE]."'>" .
            Resources::Get(
                'chat.window.admin.history.user_rate',
                    array(
                        $rate['operator'],
                        Resources::Get('rate.' . $rate['rate'])
                    )
            );

    $message .= " <a onclick=\"return confirm('".Resources::Get('chat.window.admin.history.remove_rate.confirm')."');\"


        	href=\"
    ".WEBIM_ROOT."/operator/threadprocessor.php?act=removerate&threadid={$rate['threadid']}&rateid={$rate['rateid']}\">" .
            Resources::Get('chat.window.admin.history.remove_rate') .
            "</a>";

    $message .= "</span><br />";
    return $message;
  }

  private function messageToHtml($msg, $cleanup_special_tags = false, $operatorFullNames = null) {
    if($msg['kind'] == KIND_AVATAR) {
      return '';
    }
    $msgJson = json_decode($msg['json'], true);

    $kind = isset(self::$kindToString[$msg['kind']]) ? self::$kindToString[$msg['kind']] : '';
    $message = "<span class='t$kind'>" . Helper::accountStrftime($msg['created'], '%H:%M:%S') . '</span> ';

    if($msg['sendername']) {
        $name = $msg['sendername'];
        $operatorId = $msg['operatorid'];
            if (!empty($operatorFullNames) && $operatorId && !empty($operatorFullNames[$operatorId])) {
                $name = $operatorFullNames[$operatorId];
        }
        $message .= "<span class='n$kind'>" . htmlspecialchars(removeSpecialSymbols($name)) . ':</span> ';
    }

    if ($msg['kind'] == KIND_CONTACTS) {
      $j = json_decode(iconv(WEBIM_ENCODING,'utf-8', $msg['message']), true);
      $availableFieldNames = getVisitorFieldNames();
      $pieces = array();
      foreach ($j as $fieldName => $value) {
        if (in_array($fieldName, $availableFieldNames)) {
          $pieces[] = Resources::Get('visitor_field.'.$fieldName).': '.$value;
        }
      }
      $inner = join(', ', $pieces);
    } elseif ($msg['kind'] == KIND_FILE_OPERATOR) {
      $j = json_decode(iconv(WEBIM_ENCODING,'utf-8', $msg['message']), true);
      return $message . "<span class='m$kind'>" . Resources::Get('chat.operator_sent_file') . ': ' . ' <a href="' . Helper::getServerRootURL() . '/l/o/download/' . $j['guid'] . '/' . $j['filename'] .'" target="_blank" rel="nofollow noopener">' . htmlspecialchars($j['filename']) . '</a></span><br/>';
    } elseif ($msg['kind'] == KIND_FILE_VISITOR) {
      $j = json_decode(iconv(WEBIM_ENCODING,'utf-8', $msg['message']), true);
      return $message . "<span class='m$kind'>" . Resources::Get('chat.visitor_sent_file') . ': ' . ' <a href="' . Helper::getServerRootURL() . '/l/o/download/' . $j['guid'] . '/' . $j['filename'] .'" target="_blank" rel="nofollow noopener">' . htmlspecialchars($j['filename']) . '</a></span><br/>';
    } elseif ($msg['kind'] == KIND_AGENT) {
      return $message . "<span class='m$kind'>" . $this->PrepareHtmlMessage($msg['message'], $cleanup_special_tags) . ' <a href="' . Helper::getServerRootURL() . '/operator/history.php?at_datetime=' . Helper::accountStrftime($msg['created'], '%d.%m.%Y %H:%M:%S') . '&operators[]=' . $msg['operatorid'] . '" target="_blank" rel="nofollow noopener" title="' . htmlspecialchars(Resources::Get('thread.operator_message.link_to_other')) . '"><img src="'. Helper::getServerRootURL() .'/images/icons/link.gif" /></a></span><br/>';
    } elseif($msg['kind'] == KIND_OPERATOR_NOTE) {
        $inner = $msg['message'];
        return $message . "<span class='m$kind'><span class='webim-icon webim-icon-note'></span>" . $this->PrepareHtmlMessage($inner, $cleanup_special_tags) . '</span><br/>';
    } else {
      $inner = $msg['message'];
    }
    if (isset($msgJson['deleted']) && $msgJson['deleted'] == TRUE) {
        $message .= "<span class='m'>" .  Resources::Get('chat.message_deleted_by_operator'). '</span><br/>';
    } else {
        $message .= "<span class='m$kind'>" . $this->PrepareHtmlMessage($inner, $cleanup_special_tags) . '</span><br/>';
    }

    return $message;
  }

  public function messageToJson($msg) {
      $message = array(
          'authorId' => $msg['operatorid'],
          'name' => $msg['sendername'],
          'text' => $msg['message'],
          'ts' => $msg['created'],
          'kind' => self::$kindToPythonString[$msg['kind']]
      );
      if (!empty($msg['json'])) {
          $messageJSON = json_decode($msg['json'], true);
          if (array_key_exists('data', $messageJSON) && !empty($messageJSON['data'])) {
              $message['data'] = $messageJSON['data'];
          }
      }
      return $message;
  }


  public function messageToText($msg) {
    if($msg['kind'] == KIND_AVATAR) {
      return '';
    }

    if ($msg['kind'] == KIND_CONTACTS) {
      $j = json_decode(iconv(WEBIM_ENCODING,'utf-8', $msg['message']), true);
      $availableFieldNames = getVisitorFieldNames();
      $pieces = array();
      foreach ($j as $fieldName => $value) {
        if (in_array($fieldName, $availableFieldNames)) {
          $pieces[] = Resources::Get('visitor_field.'.$fieldName).': '.$value;
        }
      }
      $messageText = self::processSpecialTags(join(', ', $pieces), 'text', true);
    } elseif ($msg['kind'] == KIND_FILE_OPERATOR) {
      $j = json_decode(iconv(WEBIM_ENCODING,'utf-8', $msg['message']), true);
      $messageText = Resources::Get('chat.operator_sent_file') . ': ' . $j['filename'] . ' (' . Helper::getServerRootURL() . '/l/o/download/' . $j['guid'] . '/' . $j['filename'] .')';
      self::processSpecialTags($messageText, 'text', true);
    } elseif ($msg['kind'] == KIND_FILE_VISITOR) {
      $j = json_decode(iconv(WEBIM_ENCODING,'utf-8', $msg['message']), true);
      $messageText = Resources::Get('chat.visitor_sent_file') . ': ' . $j['filename'] . ' (' . Helper::getServerRootURL() . '/l/o/download/' . $j['guid'] . '/' . $j['filename'] .')';
      self::processSpecialTags($messageText, 'text', true);
    } else {
      $messageText = self::processSpecialTags($msg['message'], 'text', true /*$cleanup_special_tags = true*/);
    }
    $message_time = Helper::accountStrftime($msg['created'], '%H:%M:%S');
    if($msg['kind'] == KIND_USER || $msg['kind'] == KIND_AGENT) {
      if($msg['sendername'])
        return $message_time . $msg['sendername'] . ': ' . $messageText . PHP_EOL;
      else
      return $message_time . $messageText . PHP_EOL;
    } elseif($msg['kind'] == KIND_INFO) {
      return $message_time . $messageText . PHP_EOL;
    } else {
      return $message_time . '[' . $messageText . ']' . PHP_EOL;
    }
  }

  private static function processSpecialTags($message, $format, $hideSpecialTags) {
    $protocol = '(http|ftp|https):\/\/';
    $domain = '[\w]+(.[\w]+)';
    $subdir = '([\w\-\.,@?^=%&:;\/~\+#]*[\w\-\@?^=%&\/~\+#])?';
    $pattern = $protocol . $domain . $subdir;
    $mail_pattern = '[\.\-\d\w]+@[\.\-\d\w]+\.[\w]{2,3}';
    switch ($format) {
    case "text":
      if(preg_match("/\!($pattern)/i", $message)) {
        $result = preg_replace("/\!($pattern)/i", Resources::Get('push.page.invitation')." $1", $message);
      } else {
        if(preg_match('/\?\@/', $message)) {
          $result = preg_replace('/\?\@/', Resources::Get('visitor.contacts.message'), $message);
        } else {
          $result = $message;
        }
      }
      break;
    case "html":
        $message = preg_replace("/($mail_pattern)/", '<a href="mailto:$0" target="_blank" rel="nofollow noopener">$0</a>', $message);
//        $result = $message;

        if (preg_match("/\!($pattern)/i", $message)) {
          $link = Resources::Get('push.page.invitation') .
              ' <a href=' . ($hideSpecialTags ? '"$1"' : '"!$1"') . ' target="_blank" rel="nofollow noopener">$1</a>';
          $result = preg_replace("/\!($pattern)/i", $link, $message);
        } elseif (preg_match('/\?\@/', $message)) {
          $contactRequest = $hideSpecialTags ? Resources::Get('visitor.contacts.message') :
              '?@' . Resources::Get('visitor.contacts.message');
          $result = preg_replace('/\?\@/', $contactRequest, $message);
        } else {
            $message = preg_replace_callback('/(https?:\/\/\S+)|\[(.*?)\]\((.*?)\)/', function($matches) {
                $maxlen = strlen('Посетитель открыл окно диалога со страницы Главная');
                if (preg_match('/^\[/', $matches[0])) {
                    $text = $matches[2];
                    $url = $matches[3];
                } else {
                    $text = $matches[1];
                    $url = $matches[1];
                }
                if (strlen($text) > $maxlen) {
                    $newText = substr($text, 0, $maxlen) . '...';
                    return '<a href="' . $url . '" target="_blank" rel="nofollow noopener">' . $newText . '</a>';
                } else {
                    return '<a href="' . $url . '" target="_blank" rel="nofollow noopener">' . $text . '</a>';
                }
            }, $message);

          $result = $message;
        }


        break;
    }

    return $result;
  }

  private function PrepareHtmlMessage($text, $cleanup_special_tags = false) {
    $message = removeSpecialSymbols(htmlspecialchars($text));
    $message = self::replaceEmojiWithImg($message);
    return str_replace("\n", "<br/>", self::processSpecialTags($message, "html", $cleanup_special_tags));
  }

   private function replaceEmojiWithImg($text) {
       return preg_replace_callback('/[\x{1F600}-\x{1F64F}]|[\x{1F300}-\x{1F5FF}]|[\x{1F680}-\x{1F6FF}]|[\x{1F1E0}-\x{1F1FF}]/u', function($matches) {
           $filename = dechex(unpack('V', iconv('UTF-8', 'UCS-4LE', $matches[0]))[1]) . '.png';
           return '<img src ="/images/emoji/' . $filename . '" class="emoji">';
       }, $text);
   }

  public function removeHistory($threadid) {
    MapperFactory::getMessageMapper()->removeHistory($threadid);
    MapperFactory::getThreadMapper()->removeHistory($threadid);
  }

  public function hasThreadAccess($operatorid,  $threadid) {
    if (empty($operatorid)) {
      return false;
    }

    $op = Operator::getInstance()->getOperatorWhithLastAccessInfoById($operatorid);
    if (empty($op)) {
      return false;
    }

    if (Operator::getInstance()->isOperatorAdmin($op)) {
      return true;
    }

    if (!Department::getInstance()->departmentsExist()) {
      return true;
    }

    $thread = $this->GetThreadById($threadid);

    if (empty($thread)) {
      return false;
    }

    if ($thread['departmentid'] === null) {
      return true;
    }

    return MapperFactory::getOperatorDepartmentMapper()->isOperatorInDepartment($operatorid, $thread['departmentid']);
  }

  public function getOperatorFullNames() {
      $repository = Factory_Repository::create('operator');
      $operators = $repository->getAll();

      $result = array();

      foreach ($operators as $operatorId => $operator) {
          $result[$operator->getId()] = $operator->getFullName();
      }
      return $result;
  }
}
