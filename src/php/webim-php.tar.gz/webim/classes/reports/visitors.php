<?php
class Report_Visitors extends Report_Base {
    protected $visitors = null;

    public function __construct($visitors) {
        parent::__construct($visitors);

        $headers = array();
        foreach ($visitors as $visitor) {
            $headers = array_merge($headers, array_diff(array_keys($visitor), $headers));
        }

        $fullRow = array_fill_keys($headers, null);
        $data = array();
        foreach ($this->rows as $row) {
            $data[] = array_merge($fullRow, $row);
        }
        $this->rows = $data;

        foreach ($headers as $header) {
            $this->headers[$header] = Factory_ReportField::create(Report_Field_Base::TYPE_HEADER, array(
                'value' => $header
            ));
        }
    }

    public function getRows() {
        return new Iterator_Callback($this->rows, function($visitorRow) {
            $visitor = array();
            foreach ($visitorRow as $columnName => $columnValue) {
                switch ($columnName) {
                    case 'visitorid':
                        $visitor[$columnName] = Factory_ReportField::create(Report_Field_Base::TYPE_INT, array(
                            'value' => $columnValue
                        ));
                        break;
                    case 'created':
                        $visitor[$columnName] = Factory_ReportField::create(Report_Field_Base::TYPE_DATETIME, array(
                            'value' => $columnValue
                        ));
                        break;
                    default:
                        $visitor[$columnName] = Factory_ReportField::create(Report_Field_Base::TYPE_STRING, array(
                            'value' => $columnValue
                        ));
                }
            }

            return $visitor;
        });
    }

    public function getTitle() {
        return Resources::Get('reports.all_visitors.title');
    }
}