<?php
class Report_Callbacks extends Report_Base {
    protected static $columns = array(
        'id' => array(
            'resourceKey' => 'callbacks_report.callback_id',
            'align' => 'center',
            'type' => Report_Field_Base::TYPE_INT
        ),
        'visitor.name' => array(
            'resourceKey' => 'page.analysis.search.head_name',
            'align' => 'left',
            'type' => Report_Field_Base::TYPE_STRING
        ),
        'visitor.id' => array(
            'resourceKey' => 'page.analysis.search.head_id',
            'align' => 'center',
            'type' => Report_Field_Base::TYPE_STRING
        ),
        'visitor.email' => array(
            'resourceKey' => 'page.analysis.search.head_email',
            'align' => 'left',
            'type' => Report_Field_Base::TYPE_EMAIL
        ),
        'visitorPhone' => array(
            'resourceKey' => 'callbacks_report.visitor_phone',
            'align' => 'left',
            'type' => Report_Field_Base::TYPE_PHONE
        ),
        'remote' => array(
            'resourceKey' => 'page.analysis.search.head_host',
            'align' => 'center',
            'type' => Report_Field_Base::TYPE_STRING
        ),
        'operatorPhone' => array(
            'resourceKey' => 'callbacks_report.operator_phone',
            'align' => 'left',
            'type' => Report_Field_Base::TYPE_PHONE
        ),
        'created' => array(
            'resourceKey' => 'callbacks_report.created',
            'align' => 'center',
            'type' => Report_Field_Base::TYPE_DATETIME
        ),
        'duration' => array(
            'resourceKey' => 'callbacks_report.duration',
            'align' => 'center',
            'type' => Report_Field_Base::TYPE_DURATION
        ),
        'referrerUrl' => array(
            'resourceKey' => 'callbacks_report.referrer_url',
            'align' => 'center',
            'type' => Report_Field_Base::TYPE_URL
        ),
        'kind' => array(
            'resourceKey' => 'callbacks_report.kind',
            'align' => 'center',
            'type' => Report_Field_Base::TYPE_CALLBACK_KIND
        ),
        'recordFilename' => array(
            'resourceKey' => 'callbacks_report.record',
            'align' => 'center',
            'type' => Report_Field_Base::TYPE_AUDIO
        )
    );

    public function getRows() {
        $configs = $this->orderedColumns;
        return new Iterator_Callback($this->rows, function($callback) use($configs) {
            /* @var $callback Model_Callback */
            $row = array();
            $centeredFields = array('remote', 'duration', 'recordFilename');
            foreach ($configs as $columnName => $config) {
                $nameParts = explode('.', $columnName);
                $fieldName = array_shift($nameParts);
                $getter = 'get' . strtoupper($fieldName[0]) . substr($fieldName, 1);
                $subField = !empty($nameParts) ? array_shift($nameParts) : null;
                $value = $callback->$getter();
                if (!empty($subField)) {
                    $value = $value[$subField];
                }
                $row[$columnName] = Factory_ReportField::create($config['type'], array(
                    'value' => $value,
                    'params' => array(
                        'styles' => array(
                            'align' => in_array($columnName, $centeredFields) ? 'center' : 'left'
                        )
                    )
                ));
            }
            return $row;
        });
    }

    public function getTitle() {
        return 'Callbacks';
    }
}