<?php

/**
 * Class Report_Threads
 * Спроектирован с идеей использовать константый объём памяти независимо от количества чатов
 */
class Report_Threads extends Report_Base {
    /**
     * @var array
     * @const
     */
    protected static $columns = array(
        'id' => array(
            'resourceKey' => 'page.analysis.search.dialog_id',
            'align' => 'center',
            'type' => Report_Field_Base::TYPE_INT
        ),
        'visitor.name' => array(
            'resourceKey' => 'page.analysis.search.head_name',
            'align' => 'left',
            'type' => Report_Field_Base::TYPE_STRING
        ),
        'visitor.userId' => array(
            'resourceKey' => 'page.analysis.search.head_id',
            'align' => 'center',
            'type' => Report_Field_Base::TYPE_STRING
        ),
        'visitor.email' => array(
            'resourceKey' => 'page.analysis.search.head_email',
            'align' => 'left',
            'type' => Report_Field_Base::TYPE_EMAIL
        ),
        'visitor.phone' => array(
            'resourceKey' => 'page.analysis.search.head_phone',
            'align' => 'left',
            'type' => Report_Field_Base::TYPE_PHONE
        ),
        'remote' => array(
            'resourceKey' => 'page.analysis.search.head_host',
            'align' => 'center',
            'type' => Report_Field_Base::TYPE_STRING
        ),
        'operatorOwnerName' => array(
            'resourceKey' => 'page.analysis.search.head_operator',
            'align' => 'left',
            'type' => Report_Field_Base::TYPE_STRING
        ),
        'office.name' => array(
            'resourceKey' => 'page.analysis.search.head_office',
            'align' => 'left',
            'type' => Report_Field_Base::TYPE_STRING
        ),
        'messagesCount' => array(
            'resourceKey' => 'page.analysis.search.head_messages',
            'align' => 'center',
            'type' => Report_Field_Base::TYPE_INT
        ),
        'category' => array(
            'resourceKey' => 'page.analysis.search.head_category',
            'align' => 'left',
            'type' => Report_Field_Base::TYPE_CATEGORY
        ),
        'departmentNames' => array(
            'resourceKey' => 'page.analysis.search.head_department_names',
            'align' => 'left',
            'type' => Report_Field_Base::TYPE_STRING
        ),
        'departmentKeys' => array(
            'resourceKey' => 'page.analysis.search.head_department_keys',
            'align' => 'left',
            'type' => Report_Field_Base::TYPE_STRING
        ),
        'created' => array(
            'resourceKey' => 'page.analysis.search.created',
            'align' => 'center',
            'type' => Report_Field_Base::TYPE_DATETIME
        ),
        'duration' => array(
            'resourceKey' => 'page.analysis.search.head_time',
            'align' => 'center',
            'type' => Report_Field_Base::TYPE_DURATION
        ),
        'kind' => array(
            'resourceKey' => 'page.analysis.search.kind',
            'align' => 'center',
            'type' => Report_Field_Base::TYPE_KIND
        ),
        'messages' => array(
            'align' => 'left',
            'type' => Report_Field_Base::TYPE_MESSAGES
        )
    );

    public function getRows() {
        $configs = $this->orderedColumns;
        return new Iterator_Callback($this->rows, function($thread) use($configs) {
            /* @var $thread Model_Thread */
            $row = array();
            $centeredFields = array('messageCount', 'remote', 'duration');
            foreach ($configs as $columnName => $config) {
                $nameParts = explode('.', $columnName);
                $fieldName = array_shift($nameParts);
                $getter = 'get' . ucfirst($fieldName);
                $subField = !empty($nameParts) ? array_shift($nameParts) : null;

                switch ($columnName) {
                    case 'id':
                        $row[$columnName] = Factory_ReportField::create($config['type'], array(
                            'value' => $thread->getId(),
                            'params' => array(
                                'styles' => array(
                                    'align' => 'center',
                                ),
                                'link' => array(
                                    'url' => Helper::getServerRootURL() . '/operator/threadprocessor.php?threadid=' . htmlspecialchars($thread->getId()) . '#thread' . htmlspecialchars($thread->getId()),
                                    'onclick' => 'window.open(\'/operator/threadprocessor.php?threadid=' . htmlspecialchars($thread->getId()) . '#thread' . htmlspecialchars($thread->getId()) . '\', \'\', \'toolbar=0, scrollbars=1, location=0, status=1, menubar=0, width=600, height=420, resizable=1, noopener\'); if (event != null) { event.returnValue=false; } return false;',
                                    'type' => 'url'
                                )
                            )
                        ));

                        break;
                    case 'visitor.name':
                        $visitor = $thread->getVisitor();
                        if ($visitor) {
                            $row[$columnName] = Factory_ReportField::create($config['type'], array(
                                'value' => $visitor->getDisplayName() ?: $visitor->getName(),
                                'params' => array(
                                    'link' => array(
                                        'url' => Helper::getServerRootURL() . '/operator/threadprocessor.php?threadid=' . htmlspecialchars($thread->getId()) . '#thread' . htmlspecialchars($thread->getId()),
                                        'onclick' => 'window.open(\'/operator/threadprocessor.php?threadid=' . htmlspecialchars($thread->getId())  . '#thread' . htmlspecialchars($thread->getId()) . '\', \'\', \'toolbar=0, scrollbars=1, location=0, status=1, menubar=0, width=600, height=420, resizable=1, noopener\'); if (event != null) { event.returnValue=false; } return false;',
                                        'type' => 'url'
                                    )
                                )
                            ));
                        } else {
                            $row[$columnName] = Factory_ReportField::create($config['type']);
                        }
                        break;
                    case 'departmentNames':
                        $row[$columnName] = Factory_ReportField::create($config['type'], array(
                            'value' => implode(', ', $thread->getDepartmentNames())
                        ));
                        break;
                    case 'departmentKeys':
                        $row[$columnName] = Factory_ReportField::create($config['type'], array(
                            'value' => implode(', ', $thread->getDepartmentKeys()
                            )
                        ));
                        break;
                    case 'messages':
                        $row[$columnName] = Factory_ReportField::create($config['type'], array(
                            'value' => $thread->getMessages()
                        ));
                        break;
                    default:
                        $value = $thread->$getter();
                        if (!empty($subField) && !empty($value)) {
                            if (is_array($value)) {
                                $value = $value[$subField];
                            } else {
                                $subGetter = 'get' . ucfirst($subField);
                                $value = $value->$subGetter();
                            }
                        }
                        $row[$columnName] = Factory_ReportField::create($config['type'], array(
                            'value' => $value,
                            'params' => array(
                                'styles' => array(
                                    'align' => in_array($columnName, $centeredFields) ? 'center' : 'left'
                                )
                            )
                        ));
                }
            }

            return $row;
        });
    }

    public function getTitle() {
        return Resources::Get('search.excel.sheet.title');
    }
}