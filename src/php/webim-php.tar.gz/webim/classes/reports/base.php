<?php

abstract class Report_Base {
    /**
     * @var array
     * @const
     */
    protected static $columns = array();
    /**
     * @var array
     */
    protected $orderedColumns = array();
    /**
     * @var Report_Field_Header[]
     */
    protected $headers;
    /**
     * @var array|Iterator_Base
     */
    protected $rows = array();
    /**
     * @var array
     */
    protected $total;

    /**
     * @param array|Iterator_Base $data
     * @param array $preCalcTotal
     * @param array $params
     * @param array $params.columnOrder
     */
    public function __construct($data, $preCalcTotal = NULL, array $params = array()) {
        $this->rows = $data;
        $this->total = $preCalcTotal;
        $this->orderedColumns = $this->prepareOrderedColumns(!empty($params['columnOrder']) ? $params['columnOrder'] : NULL);
    }

    /**
     * @return Report_Field_Header[]
     */
    final public function getHeaders() {
        if (!isset($this->headers)) {
            $this->headers = array();
            foreach ($this->orderedColumns as $columnName => $config) {
                $fieldRow = array();
                if (!empty($config['title'])) {
                    $fieldRow['value'] = $config['title'];
                } elseif (!empty($config['resourceKey'])) {
                    $fieldRow['params']['resourceKey'] = $config['resourceKey'];
                }
                if (!empty($config['align'])) {
                    $fieldRow['params']['styles']['align'] = $config['align'];
                }
                $this->headers[$columnName] = Factory_ReportField::create(Report_Field_Base::TYPE_HEADER, $fieldRow);
            }
        }
        return $this->headers;
    }

    abstract public function getTitle();

    /**
     * @return Iterator_Callback
     */
    abstract public function getRows();

    public function isEmpty() {
        return !count($this->rows);
    }

    public static function getColumnNames() {
        return array_keys(static::$columns);
    }

    /**
     * Может быть полностью переопределена в потомке
     * @return array
     */
    public function getTotal() {
        return $this->total !== NULL ? $this->total : array();
    }

    protected function prepareOrderedColumns(array $columnOrder = NULL) {
        $orderedColumns = array();
        if (empty($columnOrder)) {
            $columnOrder = array_keys(static::$columns);
        }

        foreach ($columnOrder as $columnName) {
            $orderedColumns[$columnName] = static::$columns[$columnName];
        }

        return $orderedColumns;
    }
}