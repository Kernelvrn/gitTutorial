<?php
class Report_Leads extends Report_Base {
    protected static $columns = array(
        'FirstName' => array(
            'title' => 'FirstName',
            'type' => Report_Field_Base::TYPE_STRING,
            'src' => 'visitor.name'
        ),
        'LastName' => array(
            'title' => 'LastName',
            'type' => Report_Field_Base::TYPE_STRING,
        ),
        'Email' => array(
            'title' => 'Email',
            'type' => Report_Field_Base::TYPE_STRING,
            'src' => 'visitor.email'
        ),
        'Phone' => array(
            'title' => 'Phone',
            'type' => Report_Field_Base::TYPE_PHONE,
            'src' => 'visitor.phone'
        ),
        'LeadNote' => array(
            'title' => 'LeadNote',
            'type' => Report_Field_BASE::TYPE_START_MESSAGES,
            'src' => 'messages'
        )
    );

    public function getRows() {
        $configs = $this->orderedColumns;
        return new Iterator_Callback($this->rows, function($thread) use($configs) {
            /* @var $thread Model_Thread */
            $row = array();
            foreach ($configs as $columnName => $config) {
                if (!empty($config['src'])) {
                    $nameParts = explode('.', $config['src']);
                    $fieldName = array_shift($nameParts);
                    $getter = 'get' . ucfirst($fieldName);
                    $subField = !empty($nameParts) ? array_shift($nameParts) : null;
                    $value = $thread->$getter();
                    if (!empty($subField) && !empty($value)) {
                        if (is_array($value)) {
                            $value = $value[$subField];
                        } else {
                            $subGetter = 'get' . ucfirst($subField);
                            $value = $value->$subGetter();
                        }
                    }
                    $row[$columnName] = Factory_ReportField::create($config['type'], array(
                        'value' => $value
                    ));
                } else {
                    $row[$columnName] = Factory_ReportField::create(Report_Field_Base::TYPE_STRING);
                }

            }
            return $row;
        });
    }

    public function getTitle() {
        return Resources::Get('search.excel_leads.sheet.title');
    }
}