<?php

class Report_Field_Phone extends Report_Field_Base {
    protected static $type = Report_Field_Base::TYPE_PHONE;
    protected static $defaultStyles = array(
        'align' => 'center',
    );
}