<?php
class Report_Field_Duration extends Report_Field_Base {
    protected static $type = Report_Field_Base::TYPE_DURATION;
    protected static $defaultStyles = array(
        'align' => 'center',
    );
}