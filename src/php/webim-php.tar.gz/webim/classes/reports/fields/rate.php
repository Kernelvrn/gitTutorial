<?php

class Report_Field_Rate extends Report_Field_Base {
    protected static $type = Report_Field_Base::TYPE_RATE;
}