<?php

class Report_Field_Int extends Report_Field_Base {
    protected static $type = Report_Field_Base::TYPE_INT;
}