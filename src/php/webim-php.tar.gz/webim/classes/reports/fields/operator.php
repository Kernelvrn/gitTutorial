<?php

class Report_Field_Operator extends Report_Field_Base {
    protected static $type = Report_Field_Base::TYPE_OPERATOR;
    protected static $defaultStyles = array(
        'align' => 'left',
    );
}