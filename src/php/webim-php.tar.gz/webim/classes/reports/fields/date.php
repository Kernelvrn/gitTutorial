<?php

class Report_Field_Date extends Report_Field_Datetime {
    protected static $type = Report_Field_Base::TYPE_DATE;
}