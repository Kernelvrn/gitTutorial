<?php

class Report_Field_CallbackKind extends Report_Field_Base {
    protected $type = Report_Field_Base::TYPE_CALLBACK_KIND;
    protected $defaultStyles = array(
        'align' => 'center',
    );
}