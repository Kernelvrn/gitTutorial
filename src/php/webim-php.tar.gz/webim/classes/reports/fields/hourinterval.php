<?php

class Report_Field_HourInterval extends Report_Field_Base {
    protected static $type = Report_Field_Base::TYPE_HOUR_INTERVAL;
    protected static $defaultStyles = array(
        'align' => 'center',
    );
}