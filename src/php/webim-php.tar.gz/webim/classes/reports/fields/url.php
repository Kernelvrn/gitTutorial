<?php
class Report_Field_Url extends Report_Field_Base {
    protected $type = Report_Field_Base::TYPE_URL;
}