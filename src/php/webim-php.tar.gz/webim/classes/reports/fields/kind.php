<?php

class Report_Field_Kind extends Report_Field_Base {
    protected static $type = Report_Field_Base::TYPE_KIND;
}