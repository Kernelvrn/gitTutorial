<?php

abstract class Report_Field_Base {
    const TYPE_INT = 'int';
    const TYPE_FLOAT = 'float';
    const TYPE_STRING = 'string';
    const TYPE_EMAIL = 'email';
    const TYPE_PHONE = 'phone'; //explicit
    const TYPE_DATETIME = 'datetime';
    const TYPE_DATE = 'date';
    const TYPE_TIME = 'time';
    const TYPE_DURATION = 'duration';
    const TYPE_BOOLEAN = 'boolean';
    const TYPE_HEADER = 'header';
    const TYPE_MESSAGES = 'messages';
    const TYPE_KIND = 'kind';
    const TYPE_CATEGORY = 'category';
    const TYPE_RATE = 'rate';
    const TYPE_START_MESSAGES = 'startMessages';
    const TYPE_URL = 'url';
    const TYPE_HOUR_INTERVAL = 'hourInterval';
    const TYPE_PERCENTAGE = 'percentage';
    const TYPE_DEPARTMENT = 'department';
    const TYPE_OFFICE = 'office';
    const TYPE_OPERATOR = 'operator';
    const TYPE_CALLBACK_KIND = 'callbackKind';
    const TYPE_AUDIO = 'audio';

    protected $value = null;
    protected $resourceKey = null;
    protected static $type = null;
    protected $styles = array();
    protected static $defaultStyles = array(
        'align' => 'left',
    );
    protected $link = array();

    public function __construct($value, array $params = NULL) {
        $this->value = $value;

        $params = !is_array($params) ? array() : $params;

        $this->styles = !empty($params['styles'])
            ? array_merge(static::$defaultStyles, $params['styles'])
            : static::$defaultStyles;


        if (static::$type === Report_Field_Base::TYPE_EMAIL) {
            $this->link = array(
                'type' => 'email',
                'url' => $value
            );
        } elseif (static::$type == Report_Field_Base::TYPE_URL) {
            $this->link = array(
                'type' => 'url',
                'url' => $value
            );
        }

        if (!empty($params['link'])) {
            $this->link = $params['link'];
        }

        if (!empty($params['resourceKey'])) {
            $this->resourceKey = $params['resourceKey'];
        }
    }

    public function getValue() {
        return empty($this->resourceKey) ? $this->value : Resources::Get($this->resourceKey);
    }

    public function getType() {
        return static::$type;
    }

    public function getStyle($styleName) {
        $lowerStyleName = strtolower($styleName);
        return !empty($this->styles[$lowerStyleName]) ? $this->styles[$lowerStyleName] : NULL;
    }

    public function getLinkParam($paramName) {
        return !empty($this->link[$paramName]) ? $this->link[$paramName] : NULL;
    }
}