<?php

class Report_Field_Audio extends Report_Field_Base {
    protected $type = Report_Field_Base::TYPE_AUDIO;
    protected $defaultStyles = array(
        'align' => 'center',
    );
}