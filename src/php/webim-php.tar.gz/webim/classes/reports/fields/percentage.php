<?php
class Report_Field_Percentage extends Report_Field_Base {
    protected static $type = Report_Field_Base::TYPE_PERCENTAGE;
    protected static $defaultStyles = array(
        'align' => 'center',
    );
}