<?php

class Report_Field_StartMessages extends Report_Field_Base {
    protected static $type = Report_Field_Base::TYPE_START_MESSAGES;
}