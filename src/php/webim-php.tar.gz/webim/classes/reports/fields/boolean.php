<?php

class Report_Field_Boolean extends Report_Field_Base {
    protected static $type = Report_Field_Base::TYPE_BOOLEAN;
    protected static $defaultStyles = array(
        'align' => 'center',
    );

    public function __construct($value, array $params = NULL) {
        parent::__construct($value, $params);
        $this->value = (boolean) $value;
    }
}