<?php

class Report_Field_Datetime extends Report_Field_Base {
    protected static $type = Report_Field_Base::TYPE_DATETIME;
    protected static $defaultStyles = array(
        'align' => 'center',
    );

    public function __construct($value, array $params = NULL) {
        parent::__construct($value, $params);
        if ($value instanceof DateTime) {
            $this->value = $value;
        } elseif (isset($value)) {
            $this->value = Helper::getAccountDateTime($value);
        }
    }
}