<?php

class Report_Field_Email extends Report_Field_Base {
    protected static $type = Report_Field_Base::TYPE_EMAIL;
    protected static $defaultStyles = array(
        'align' => 'center',
    );

    public function __construct($value, array $params = NULL) {
        $this->link = array(
            'type' => 'email',
            'url' => $value
        );

        parent::__construct($value, $params);
    }
}