<?php

class Report_Field_Time extends Report_Field_Datetime {
    protected static $type = Report_Field_Base::TYPE_TIME;
}