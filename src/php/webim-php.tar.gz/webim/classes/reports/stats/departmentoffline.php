<?php

class Report_Stat_DepartmentOffline extends Report_Stat_DepartmentOnline  {
    public function getTitle() {
        return Resources::Get('reports.departments_offline.menu.title');
    }
}