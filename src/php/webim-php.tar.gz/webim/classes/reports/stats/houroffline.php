<?php

class Report_Stat_HourOffline extends Report_Stat_Base {
    protected static $columns = array(
        'dimensions.period' => array(
            'resourceKey' => 'report.byhour.1',
            'align' => 'center',
            'type' => Report_Field_Base::TYPE_HOUR_INTERVAL
        ),
        'newOfflineQueueCount' => array(
            'resourceKey' => 'report.bydate.new_offlines_queue',
            'type' => Report_Field_Base::TYPE_INT,
            'inSettings' => 'new_offlines_queue',
        ),
        'newOfflineOperatorCount' => array(
            'resourceKey' => 'report.bydate.new_offlines_operator',
            'type' => Report_Field_Base::TYPE_INT,
            'inSettings' => 'new_offlines_operator',
        ),
        'closedOfflineCount' => array(
            'resourceKey' => 'report.bydate.closed_offline',
            'type' => Report_Field_Base::TYPE_INT,
            'inSettings' => 'closed_offlines',
        ),
        'operatorMessageCount' => array(
            'resourceKey' => 'report.bydate.3',
            'type' => Report_Field_Base::TYPE_INT,
            'inSettings' => 'operator_messages',
        ),
        'avgWaitingTime' => array(
            'resourceKey' => 'report.bydate.offline_queue_wating',
            'type' => Report_Field_Base::TYPE_DURATION,
            'inSettings' => 'avg_answer_time_offline_queue',
        ),
        'avgOperatorQueueOffline' => array(
            'resourceKey' => 'report.byoperator.operator_avg_queue_waiting_time_offline',
            'type' => Report_Field_Base::TYPE_DURATION,
            'inSettings' => 'operator_avg_queue_waiting_time_offline',
        ),
        'avgVisitorGotAnswerTimeOffline' => array(
            'resourceKey' => 'report.visitor_got_answer_time_offline',
            'type' => Report_Field_Base::TYPE_DURATION,
            'inSettings' => 'visitor_got_answer_time_offline',
        ),
        'operatorPeak' => array(
            'resourceKey' => 'report.bydate.operator_peak',
            'type' => Report_Field_Base::TYPE_INT,
            'inSettings' => 'operator_peak',
        )
    );

    public function getTitle() {
        return Resources::Get('reports.hours_offline.menu.title');
    }
}