<?php

class Report_Stat_OperatorTime extends Report_Stat_Base {
    protected static $columns = array(
        'dimensions.operator' => array(
            'resourceKey' => 'report.byoperator.1',
            'align' => 'left',
            'type' => Report_Field_Base::TYPE_OPERATOR
        ),
        'onlineTime' => array(
            'resourceKey' => 'report.byoperator.6',
            'type' => Report_Field_Base::TYPE_DURATION,
            'inSettings' => 'online_time'
        ),
        'chattingTime' => array(
            'resourceKey' => 'report.byoperator.7',
            'type' => Report_Field_Base::TYPE_DURATION,
            'inSettings' => 'chatting_time'
        ),
        'summaryChattingTime' => array(
            'resourceKey' => 'report.byoperator.8',
            'type' => Report_Field_Base::TYPE_DURATION,
            'inSettings' => 'avg_chatting_time_sum'
        ),
        'avgChattingTime' => array(
            'resourceKey' => 'report.byoperator.9',
            'type' => Report_Field_Base::TYPE_DURATION,
            'inSettings' => 'avg_chatting_time'
        ),
        'preDinnerTime' => array(
            'resourceKey' => 'report.byoperator.pre_dinner_time',
            'type' => Report_Field_Base::TYPE_DURATION,
            'inSettings' => 'pre_dinner_time'
        ),
        'dinnerTime' => array(
            'resourceKey' => 'report.byoperator.dinner_time',
            'type' => Report_Field_Base::TYPE_DURATION,
            'inSettings' => 'dinner_time'
        ),
        'coachingBreakTime' => array(
            'resourceKey' => 'report.byoperator.coaching_break_time',
            'type' => Report_Field_Base::TYPE_DURATION,
            'inSettings' => 'coaching_break_time'
        ),
        'technicalBreakTime' => array(
            'resourceKey' => 'report.byoperator.technical_break_time',
            'type' => Report_Field_Base::TYPE_DURATION,
            'inSettings' => 'technical_break_time'
        ),
        'meetingBreakTime' => array(
            'resourceKey' => 'report.byoperator.meeting_break_time',
            'type' => Report_Field_Base::TYPE_DURATION,
            'inSettings' => 'meeting_break_time'
        ),
        'shortBreakTime' => array(
            'resourceKey' => 'report.byoperator.short_break_time',
            'type' => Report_Field_Base::TYPE_DURATION,
            'inSettings' => 'short_break_time'
        ),
        'privateTime' => array(
            'resourceKey' => 'report.byoperator.private_time',
            'type' => Report_Field_Base::TYPE_DURATION,
            'inSettings' => 'private_time'
        ),
    );

    public function __construct($data, $preCalcTotal = NULL, array $params = array()) {
        $assocData = array();
        foreach ($data as $operatorTimeVector) {
            /** @var Statistic_Vector_OperatorTime $operatorTimeVector */
            if ($operatorTimeVector->getDimensions()) {
                $assocData[$operatorTimeVector->getDimensions()->getOperator()->getFullName()] = $operatorTimeVector;
            }
        }
        ksort($assocData);
        parent::__construct($assocData, $preCalcTotal, $params);
    }

    public function getTitle() {
        return Resources::Get('reports.operators_time.menu.title');
    }
}