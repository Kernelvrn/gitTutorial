<?php

abstract class Report_Stat_Base extends Report_Base {
    protected $totalValues;

    public function getRows() {
        $configs = $this->orderedColumns;
        return new Iterator_Callback($this->rows, function($statVector) use ($configs) {
            /** @var $statVector Statistic_Vector */
            $row = array();
            foreach ($configs as $columnName => $config) {
                $value = $this->getValueFromVectorByConfig($statVector, $columnName, $config);
                $row[] = Factory_ReportField::create($config['type'], array(
                    'value' => $value
                ));
            }

            return $row;
        });
    }

    public function getTotal() {
        $total = array();
        if ($this->total) {
            $total = array(
                Factory_ReportField::create(Report_Field_Base::TYPE_STRING, array('params' => array(
                    'resourceKey' => 'report.bydate.total'
                )))
            );

            $columnsWithoutDimension = array_slice($this->orderedColumns, 1);

            foreach ($columnsWithoutDimension as $columnName => $config) {
                $value = $this->getValueFromVectorByConfig($this->total, $columnName, $config);
                $total[] = Factory_ReportField::create($config['type'], array(
                    'value' => $value
                ));
            }
        }

        return $total;
    }

    protected function prepareOrderedColumns(array $columnOrder = NULL) {
        $orderedColumns = parent::prepareOrderedColumns($columnOrder);
        $include = Settings::Get('stats_fields_include') ?: array();
        $exclude = Settings::Get('stats_fields_exclude') ?: array();
        $filteredColumns = array_filter($orderedColumns, function ($columnConfig) use($include, $exclude) {
            if (!array_key_exists('inSettings', $columnConfig)) {
                return true;
            }

            if ($include && !in_array($columnConfig['inSettings'], $include)) {
                return false;
            }

            if ($exclude && in_array($columnConfig['inSettings'], $exclude)) {
                return false;
            }

            return true;
        });

        return $filteredColumns;
    }

    /**
     * @param Statistic_Vector $vector
     * @param string $columnName
     * @param array $config
     * @return mixed
     */
    protected function getValueFromVectorByConfig(Statistic_Vector $vector, $columnName, array $config) {
        if (!empty($config['getter'])) {
            $methodName = $config['getter'];
            $value = $this->$methodName($vector);
        } else {
            $parts = explode('.', $columnName);
            $value = $vector;
            foreach ($parts as $part) {
                $value = $value->get($part);
            }

        }

        return $value instanceof Statistic_Value_Base
            ? $value->getValue()
            : $value;
    }
}