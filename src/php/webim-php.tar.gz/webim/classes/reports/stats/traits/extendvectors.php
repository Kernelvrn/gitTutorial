<?php

/**
 * Trait Report_Trait_ExtendRows
 * Набор методов для дополнения стат отчётов векторами с измерениями для которых нет данных,
 * но клиенту удобно их видеть (отчёты по категориям, отделами и т.д.)
 */
trait Report_Stat_Trait_ExtendVectors {
    /**
     * Возвращает тип векторов в отчёте
     * @return string
     */
    abstract protected function getDummyVectorType();

    /**
     * Дополняет $vectors пустыми векторами из измерений согласно $dimensions
     * Например ([aV,bV,dV], [a,b,c,d,e]) => [aV,bV,cV,dV,eV], где cV и eV вектора-пустышки.
     * @param Iterator_Base|Statistic_Vector[] $vectors Векторы с измерением равным null должны быть в конце
     * @param array $dimensions массив измерений, которые должны быть в результирующем массиве.
     * Сортировка векторов и измерений должна совпадать.
     * @param callable $getKeyFromDimension - функция для получения ключа из измерения,
     * который будет использоваться для определения соответсвий между $vectors и $dimensions
     * @return Statistic_Vector[]
     */
    protected function extendVectorsByDimension($vectors, array $dimensions, callable $getKeyFromDimension) {
        $mixedVectors = array();
        foreach ($dimensions as $dimension) {
            $mixedVectors[$getKeyFromDimension($dimension)] = Factory_StatsVector::create($this->getDummyVectorType(),
                $dimension,
                array()
            );
        }
        foreach ($vectors as $vector) {
            $mixedVectors[$getKeyFromDimension($vector->getDimensions())] = $vector;
        }
        ksort($mixedVectors);

        return $mixedVectors;
    }
}