<?php

class Report_Stat_Messages extends Report_Stat_Base { //renamed to
    protected static $columns = array(
        'dimensions.periodStart' => array(
            'resourceKey' => 'report.byoperator.period_start',
            'align' => 'left',
            'type' => Report_Field_Base::TYPE_TIME,
            'getter' => 'getPeriodStart'
        ),
        'message.length' => array(
            'resourceKey' => 'report.message.length',
            'type' => Report_Field_Base::TYPE_FLOAT,
            'align' => 'center',
            'getter' => 'getMessageLength'
        )
    );

    public function getTitle() {
        return "Report_Messages";
    }

    protected function getMessageLength($vector) {
        /** @var $vector Statistic_Vector */
        return $vector->get('messageLength');
    }

    protected function getPeriodStart($vector) {
        /** @var $vector Statistic_Vector */
        return $vector->getDimensions()->getPeriodStart();
    }

}