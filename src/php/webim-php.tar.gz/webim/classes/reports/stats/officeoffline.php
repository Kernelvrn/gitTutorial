<?php

class Report_Stat_OfficeOffline extends Report_Stat_OfficeOnline  {
    public function getTitle() {
        return Resources::Get('reports.offices_offline.menu.title');
    }
}