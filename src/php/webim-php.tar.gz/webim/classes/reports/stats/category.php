<?php

class Report_Stat_Category extends Report_Stat_Base {
    use Report_Stat_Trait_ExtendVectors;

    protected static $columns = array(
        'dimensions.category' => array(
            'resourceKey' => 'report.bycategories.category',
            'align' => 'center',
            'type' => Report_Field_Base::TYPE_CATEGORY
        ),
        'requestCount' => array(
            'resourceKey' => 'report.bycategories.requests',
            'type' => Report_Field_Base::TYPE_INT,
            'inSettings' => 'category_cnt'
        ),
        'percentage' => array(
            'resourceKey' => 'report.bycategories.percentage',
            'type' => Report_Field_Base::TYPE_PERCENTAGE,
            'getter' => 'getRequestCountPercentage',
        )
    );

    public function __construct($data, $preCalcTotal = NULL, array $params = array()) {
        /** @var Repository_Category $repository */
        $repository = Factory_Repository::create('category');
        $categories = array();
        foreach ($repository->getAll() as $category) {
            $categories[$category->getId()] = Factory_StatsDimensions::create(array('category' => $category));
        }
        $data = $this->extendVectorsByDimension($data, $categories, function ($dimension) {
            /** @var Statistic_Dimensions $dimension */
            return $dimension ? $dimension->getCategory()->getId() : NULL;
        });
        parent::__construct($data, $preCalcTotal, $params);
    }

    public function getTitle() {
        return Resources::Get('reports.categories.menu.title');
    }

    /**
     * @param Statistic_Vector_Category $vector
     * @return Statistic_Value_Float
     */
    protected function getRequestCountPercentage($vector) {
        $totalCount = $this->total->getRequestCount()->getValue();
        $value = $totalCount !== 0
            ? $vector->getRequestCount()->getValue() / $totalCount
            : 0;
        return Factory_StatsValue::createByType('float', $value, $vector->getRequestCount()->getStatsIds());
    }

    protected function getDummyVectorType() {
        return 'category';
    }
}