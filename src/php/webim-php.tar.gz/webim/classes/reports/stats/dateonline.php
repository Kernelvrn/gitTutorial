<?php

class Report_Stat_DateOnline extends Report_Stat_Base {
    protected static $columns = array(
        'dimensions.periodStart' => array(
            'resourceKey' => 'report.bydate.1',
            'align' => 'center',
            'type' => Report_Field_Base::TYPE_DATE
        ),
        'requestCount' => array(
            'resourceKey' => 'report.bydate.2tries',
            'type' => Report_Field_Base::TYPE_INT,
            'inSettings' => 'threads'
        ),
        'newRequestCount' => array(
            'resourceKey' => 'report.bydate.new_threads',
            'type' => Report_Field_Base::TYPE_INT,
            'inSettings' => 'new_threads'
        ),
        'operatorMessageCount' => array(
            'resourceKey' => 'report.bydate.3',
            'type' => Report_Field_Base::TYPE_INT,
            'inSettings' => 'operator_messages'
        ),
        'visitorMessageCount' => array(
            'resourceKey' => 'report.bydate.4',
            'type' => Report_Field_Base::TYPE_INT,
            'inSettings' => 'visitor_messages'
        ),
        'avgWaitingTime' => array(
            'resourceKey' => 'report.bydate.5',
            'type' => Report_Field_Base::TYPE_DURATION,
            'inSettings' => 'avg_answer_time_online_queue'
        ),
        'avgOperatorQueueOnline' => array(
            'resourceKey' => 'report.byoperator.operator_avg_queue_waiting_time_offline',
            'type' => Report_Field_Base::TYPE_DURATION,
            'inSettings' => 'operator_avg_queue_waiting_time_online'
        ),
        'avgMissedTime' => array(
            'resourceKey' => 'report.lostvisitors.3',
            'type' => Report_Field_Base::TYPE_DURATION,
            'inSettings' => 'avg_missed_time'
        ),
        'chatCount' => array(
            'resourceKey' => 'report.bydate.45',
            'type' => Report_Field_Base::TYPE_INT,
            'inSettings' => 'chats'
        ),
        'missedCount' => array(
            'resourceKey' => 'report.bydate.6',
            'type' => Report_Field_Base::TYPE_INT,
            'inSettings' => 'missed'
        ),
        'bounceRate' => array(
            'resourceKey' => 'report.bydate.bounce_rate',
            'type' => Report_Field_Base::TYPE_INT,
            'inSettings' => 'bounce_rate'
        ),
        'rejectedInvitationCount' => array(
            'resourceKey' => 'report.bydate.rejected_invitation',
            'type' => Report_Field_Base::TYPE_INT,
            'inSettings' => 'rejected_invitation'
        ),
        'operatorPeak' => array(
            'resourceKey' => 'report.bydate.operator_peak',
            'type' => Report_Field_Base::TYPE_INT,
            'inSettings' => 'operator_peak'
        )
    );

    public function getTitle() {
        return Resources::Get('reports.dates_online.menu.title');
    }
}