<?php

class Report_Stat_StartPage extends Report_Stat_Base {
    protected static $columns = array(
        'dimensions.startPage' => array(
            'resourceKey' => 'report.bystartpage.startpage',
            'align' => 'left',
            'type' => Report_Field_Base::TYPE_STRING
        ),
        'requestCount' => array(
            'resourceKey' => 'report.bycategories.requests',
            'type' => Report_Field_Base::TYPE_INT,
            'inSettings' => 'startpage'
        ),
        'percentage' => array(
            'resourceKey' => 'report.bycategories.percentage',
            'type' => Report_Field_Base::TYPE_PERCENTAGE,
            'getter' => 'getRequestCountPercentage',
        )
    );

    public function getTitle() {
        return Resources::Get('reports.startpages.menu.title');
    }

    /**
     * @param Statistic_Vector_Category $vector
     * @return Statistic_Value_Float
     */
    protected function getRequestCountPercentage($vector) {
        $totalRow = $this->getTotalValues();
        $totalCount = $totalRow['requestCount']->getValue();
        $value = $totalCount !== 0
            ? $vector->getRequestCount()->getValue() / $totalCount
            : 0;
        return Factory_StatsValue::createByType('float', $value, $vector->getRequestCount()->getStatsIds());
    }
}