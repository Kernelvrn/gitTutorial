<?php

class Report_Stat_DepartmentOnline extends Report_Stat_Base {
    use Report_Stat_Trait_ExtendVectors;

    protected static $columns = array(
        'dimensions.department' => array(
            'resourceKey' => 'report.bydepartments.department',
            'align' => 'left',
            'type' => Report_Field_Base::TYPE_DEPARTMENT
        ),
        'requestCount' => array(
            'resourceKey' => 'report.bydepartments.requests',
            'type' => Report_Field_Base::TYPE_INT,
            'inSettings' => 'department'
        ),
        'closedCount' => array(
            'resourceKey' => 'report.bydepartments.closed_requests',
            'type' => Report_Field_Base::TYPE_INT,
            'inSettings' => 'department_closed'
        ),
        'avgCommonQueueWaitingTime' => array(
            'resourceKey' => 'report.bydepartments.operator_avg_common_queue_waiting_time',
            'type' => Report_Field_Base::TYPE_DURATION,
            'inSettings' => 'operator_avg_common_queue_waiting_time'
        )
    );

    public function __construct($data, $preCalcTotal = NULL, array $params = array()) {
        /** @var Repository_Department $repository */
        $repository = Factory_Repository::create('department');
        $departments = array();
        foreach ($repository->getAll() as $department) {
            $departments[$department->getId()] = Factory_StatsDimensions::create(array('department' => $department));
        }
        $data = $this->extendVectorsByDimension($data, $departments, function ($dimension) {
            /** @var  Statistic_Dimensions $dimension */
            return $dimension ? $dimension->getDepartment()->getId() : NULL;
        });

        parent::__construct($data, $preCalcTotal, $params);
    }

    public function getTitle() {
        return Resources::Get('reports.departments_online.menu.title');
    }

    protected function getDummyVectorType() {
        return 'DepartmentOnline';
    }
}