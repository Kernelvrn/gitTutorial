<?php

class Report_Stat_OfficeOnline extends Report_Stat_Base {
    use Report_Stat_Trait_ExtendVectors;

    protected static $columns = array(
        'dimensions.office' => array(
            'resourceKey' => 'report.byoffices.office',
            'align' => 'left',
            'type' => Report_Field_Base::TYPE_OFFICE
        ),
        'requestCount' => array(
            'resourceKey' => 'report.bydepartments.requests',
            'type' => Report_Field_Base::TYPE_INT,
            'inSettings' => 'office_cnt'
        ),
        'closedCount' => array(
            'resourceKey' => 'report.bydepartments.closed_requests',
            'type' => Report_Field_Base::TYPE_INT,
            'inSettings' => 'office_closed'
        )
    );

    public function __construct($data, $preCalcTotal = NULL, array $params = array()) {
        parent::__construct($data, $preCalcTotal, $params);
        /** @var Repository_Office $repository */
        $repository = Factory_Repository::create('office');
        $offices = array();
        foreach ($repository->getAll() as $office) {
            $offices[$office->getId()] = Factory_StatsDimensions::create(array('office' => $office));
        }
        $this->rows = $this->extendVectorsByDimension($this->rows, $offices, function ($dimension) {
            /** @var Statistic_Dimensions $dimension */
            return $dimension ? $dimension->getOffice()->getId() : NULL;
        });
    }

    public function getTitle() {
        return Resources::Get('reports.offices_online.menu.title');
    }

    protected function getDummyVectorType() {
        return 'OfficeOnline';
    }
}