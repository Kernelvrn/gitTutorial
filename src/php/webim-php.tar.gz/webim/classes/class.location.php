<?php
require_once(__DIR__ . '/functions.php');
require_once(__DIR__ . '/../autoload.php');

class Location {
    public static function getLocation($locationName = 'default') {
        $location = self::getSystemDefaultLocation();

        if ($locationName !== 'default') {
            $location = array_replace_recursive($location, self::getExactlyThisLocation('default'));
        }

        $location = array_replace_recursive($location, self::getExactlyThisLocation($locationName));
        if (!empty($location['button']['name'])) {
            $button = Button::getButton($location['button']['name'], $location['chat']['lang']);
            if (!empty($button['params'])) {
                $location['button'] = array_replace_recursive($location['button'], $button['params']);
            }
        }

        return $location;
    }

    public static function isLocationExist($locationName) {
        if (file_exists(FilesLocation::getAccountLocationsPath() . '/' . $locationName)) {
            return TRUE;
        }

        return FALSE;
    }

    public static function enumLocationNames() {
        $locationDir = FilesLocation::getAccountLocationsPath();
        $handle = opendir($locationDir);
        $locationNames = array();

        while (FALSE !== ($filename = readdir($handle))) {
            if (!preg_match('/^(demo|\.)/', $filename) && is_dir($locationDir . '/' . $filename)) {
                $locationNames[] = $filename;
            }
        }

        sort($locationNames);
        return $locationNames;
    }

    public static function updateLocation($locationName, array $params) {
        if (self::isLocationExist($locationName)) {
            $prevLocation = self::getExactlyThisLocation($locationName);
            $location = array_replace_recursive($prevLocation, $params);
            $location['chat']['availableDepartmentKeys'] = $params['chat']['availableDepartmentKeys'];
            self::storeLocation($locationName, $location);
            return TRUE;
        }

        return FALSE;
    }

    public static function createLocation($locationName, array $params = array()) {
        if (!self::isLocationExist($locationName)) {
            $defaultAccountLocation = self::getExactlyThisLocation('default');
            $location = array_replace_recursive($defaultAccountLocation, $params);
            self::storeLocation($locationName, $location);
            return TRUE;
        }

        return FALSE;
    }

    public static function getLocationCodeForSite($locationName = 'default', $addNoCache = FALSE) {
        $params = array();
        $locVar = '';

        if ($locationName != 'default') {
            $params[] = 'location=' . urlencode($locationName);
            $locVar = ',' . PHP_EOL . '    location: "' . $locationName . '"';
        }

        if ($addNoCache) {
            $params[] = urlencode(rand());
        }

        $paramsUrl = !empty($params) ? '?' . implode('&', $params) : '';


            $template = '<!-- webim button generation date: %STAMP% version: %VERSION% -->
<a class="webim_button" href="#" rel="webim"><img src="%PROTOCOL%://%MAINURL%/button.php%PARAMS%" border="0"/></a>
<script type="text/javascript">

  webim = {
    accountName: "%ACCOUNTNAME%",
    domain: "%DOMAIN%"%LOCVAR%
  };
  (function () {
      var s = document.createElement("script");
      s.type = "text/javascript";
      s.src = "%PROTOCOL%://%MAINURL%/js/button.js";
      document.getElementsByTagName("head")[0].appendChild(s);
  })();
</script>
<!-- /webim button -->';
        if (isHostedMode()) {
            $domain = Helper::getServiceDomain();
        } else {
            $domain = $_SERVER['HTTP_HOST'];
        }

        return str_replace(
            array('%MAINURL%',
                '%DOMAIN%',
                '%STAMP%',
                '%VERSION%',
                '%LOCVAR%',
                '%ACCOUNTNAME%',
                '%PARAMS%',
                '%PROTOCOL%'
            ),
            array($domain,
                $domain,
                date('Y-m-d'),
                WEBIM_VERSION,
                $locVar,
                getAccountId(),
                $paramsUrl,
                Helper::isDomainHttpsEnabled() ? 'https' : 'http'
            ),
            $template);
    }

    protected static function getExactlyThisLocation($locationName) {
        $params = self::getJSONLocation($locationName);
        if (empty($params)) {
            $params = self::getOldLocation($locationName);
        }

        return $params;
    }

    protected static function getJSONLocation($locationName) {
        $params = array();
        $locationFilename = self::getLocationFilename($locationName);
        if (file_exists($locationFilename)) {
            $params = json_decode(file_get_contents($locationFilename), TRUE);
        }

        return $params;
    }

    protected static function getOldLocation($locationName) {
        $params = array();
        $locationFilenameJS = self::getLocationFilename($locationName, 'js');
        if (file_exists($locationFilenameJS)) {
            $content = file_get_contents($locationFilenameJS);
            $idx = strpos($content, '{');
            $content = substr($content, $idx, strrpos($content, '}') + 1 - $idx);
            $params = json_decode($content, TRUE);
        }

        $locationFilenameTXT = self::getLocationFilename($locationName, 'txt');
        if (file_exists($locationFilenameTXT)) {
            $content = file_get_contents($locationFilenameTXT);
            $json = json_decode($content, TRUE);
            if (!empty($json['button'])) {
                $params['button']['name'] = $json['button'];
            }

            $offlineEnabled = 'Y';
            if (!empty($json['offline_enabled'])) {
                $offlineEnabled = $json['offline_enabled'];
            } elseif (!empty($json['hide_button'])) {
                $offlineEnabled = strtoupper($json['hide_button']) == 'Y' ? 'N' : 'Y';
            }
            $params['button']['offlineEnabled'] = $offlineEnabled;
        }

        return $params;
    }

    protected static function getLocationFilename($locationName, $type = 'json') {
        return FilesLocation::getAccountLocationPath($locationName) . '/settings.' . $type;
    }

    protected static function getSystemDefaultLocation() {
        static $defaultLocation = array();
        if (empty($defaultLocation)) {
            $defaultLocation = json_decode(file_get_contents(__DIR__ . '/location-default.json'), TRUE);
        }
        
        return $defaultLocation;
    }

    protected static function storeLocation($locationName, array $location = array()) {
        file_put_contents(
            self::getLocationFilename($locationName),
            json_encode_readable($location)
        );
    }
}