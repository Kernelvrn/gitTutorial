<?php
require_once('class.resources.php');
require_once '../classes/class.browser.php';

class Images
{
	private function __construct ()
	{
	}

	private function __clone ()
	{
	}

	static function get ($image, $locale, $theme)
	{
		// TODO: Check for correct locale & theme name
		if (empty($locale) || ! (Resources::IsLocaleAvailable($locale)))
		{
			$locale = Resources::getCurrentLocale();
		}
		if (empty($theme))
		{
			$theme = Browser::getCurrentTheme();
		}
		if (! (in_array($theme,enumAvailableThemes()))) // TODO this check should be inside of getCurrentTheme method
		{
			$theme = 'default';
			// TODO: correct call
		}


		if ( ! Images::fileExists($image, $locale, $theme))
		{
			Images::redrawFile($image, $locale, $theme);
		}
		$imageURL = Images::getImageUrl($image, $locale, $theme);
		header("Location: $imageURL");
		return;
	}

	static function getFilePath($image, $locale, $theme)
	{
		return str_replace('//', '/', $_SERVER['DOCUMENT_ROOT'] . WEBIM_ROOT) . '/themes/' . $theme . '/locales/' . $locale . '/images/' . $image . '.gif';
	}

	static function getImageUrl($image, $locale, $theme)
	{
		return WEBIM_ROOT . '/themes/' . $theme . '/locales/' . $locale . '/images/' . $image . '.gif';
	}

	static function getTemplatePath ($image, $locale, $theme)
	{
    // TODO don't think using str_replace('//', '/', $_SERVER['DOCUMENT_ROOT'] . WEBIM_ROOT) piece of code 4 times is good practice
		return str_replace('//', '/', $_SERVER['DOCUMENT_ROOT'] . WEBIM_ROOT) . '/themes/' . $theme . '/locales/' . $locale . '/images/btn-' . $image . '.gif';
	}

	static function getFontPath ()
	{
		return str_replace('//', '/', $_SERVER['DOCUMENT_ROOT'] . WEBIM_ROOT) . '/images/trebuc.ttf';
		// TODO: move font file
	}

	static function redrawFile ($imageName, $locale, $theme)
	{
		$text = iconv(WEBIM_ENCODING,'UTF-8', Resources::Get('chat.window.' . $imageName, null, $locale)); // TODO webim encoding can be differnt from cp1251 and you can determine it by using WEBIM_ENCOINDG
		$templatePath = Images::getTemplatePath($imageName, $locale, $theme);
		$font = Images::getFontPath();
		$resultImage = Images::drawGif($templatePath, $font, $text);
		Images::storeFile($imageName, $locale, $theme, $resultImage);
	}

	static function drawGif ($templatePath, $font, $text)
	{
		$image = imagecreatefromgif($templatePath);
		$fontSize = 10;
		$angle = 90;
		$is = getimagesize($templatePath);
		$x = 18;			// $is[0] for width;
		$y = $is[1] - 10;	// $is[1] for height
		$white = imagecolorallocate($image, 255, 255, 255);
		imagettftext($image, $fontSize, $angle, $x, $y, $white, $font, $text);
		return $image;
	}

	static function storeFile($imageName, $locale, $theme, $resultImage)
	{
		imagegif($resultImage, Images::getFilePath($imageName, $locale, $theme));
	}

	static function fileExists ($image, $locale, $theme)
	{
		// TODO: check for framework-specific function
		return file_exists(Images::getFilePath($image, $locale, $theme));
	}

}
?>