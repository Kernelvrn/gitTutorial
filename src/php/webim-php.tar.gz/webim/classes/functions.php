<?php
/* pl */

use enshrined\svgSanitize\Sanitizer;

require_once(dirname(__FILE__) . '/common.php');
require_once(dirname(__FILE__) . '/models/generic/class.mapperfactory.php');

require_once(dirname(__FILE__) . '/../autoload.php');

/* end pl */

function load_db_class($class_name) {
    $db_class_name = $class_name . 'DB';
    $file_name = 'class.' . strtolower($class_name) . '.db.php';
    include_once($file_name);
    return new $db_class_name();
}

function call_method( /* $object, $MethodName,  params[] */) {
    $inputarr = func_get_args();
    $obj = array_shift($inputarr);
    $method_name = array_shift($inputarr);
    if (method_exists($obj, $method_name)) {
        $rs = call_user_func_array(array($obj, $method_name), $inputarr);
        return $rs;
    }
}

function verify_param($name, $regexp, $default = null, $from = null) {
    if ($from == null) {
        $from = $_REQUEST;
    }

    if (!strstr($regexp, '/')) {
        $regexp = '/^' . $regexp . '$/i';
    }

    if (!empty($from[$name])) {
        $val = $from[$name];
        if (preg_match($regexp, $val)) {
            return $val;
        } else {
//            @mail(SERVICE_NOTIF_EMAIL, 'verify param: param doesnt match', 'param ' . $name . ' (' . $from[$name] . ') doesnt match regex ' . $regexp . ' ' . getDebugInfoArrayAsString());
            immediatelyNotifyAboutProblem('param ' . $name . ' (' . $from[$name] . ') doesnt match regex ' . $regexp, 'verify param: param doesnt match');
            return $default;
        }
    } elseif (isset($default)) {
        return $default;
    }
}

function smarticonv($in_enc, $out_enc, $string) {
    if ($in_enc == $out_enc) {
        return $string;
    }

    if ($out_enc == 'latin') {
        if (!function_exists('strtr_utf8')) {
            function strtr_utf8($str, $from, $to = array()) {
                $keys = array();
                $values = array();
                if(!is_array($from)) {
                    preg_match_all('/./u', $from, $keys);
                    preg_match_all('/./u', $to, $values);
                    $mapping = array_combine($keys[0], $values[0]);
                } else {
                    $mapping=$from;
                }
                return strtr($str, $mapping);
            }
        }

        $string = strtr_utf8($string, 'абвгдеёзийклмнопрстуфхъыэ_', 'abvgdeeziyklmnoprstufh\'iei');
        $string = strtr_utf8($string, 'АБВГДЕЁЗИЙКЛМНОПРСТУФХЪЫЭ_', 'ABVGDEEZIYKLMNOPRSTUFH\'IEI');
        $string = strtr_utf8($string, array(
                'ж' => 'zh', 'ц' => 'ts', 'ч' => 'ch', 'ш' => 'sh',
                'щ' => 'shch', 'ь' => '', 'ю' => 'yu', 'я' => 'ya',
                'Ж' => 'ZH', 'Ц' => 'TS', 'Ч' => 'CH', 'Ш' => 'SH',
                'Щ' => 'SHCH', 'Ь' => '', 'Ю' => 'YU', 'Я' => 'YA',
                'ї' => 'i', 'Ї' => 'Yi', 'є' => 'ie', 'Є' => 'Ye'
            )
        );
        return $string;
    }


    if (function_exists('iconv')) {
        $converted = @iconv($in_enc, $out_enc . '//TRANSLIT', $string);
        return $converted;
    }

    require_once(dirname(__FILE__) . '/converter.php');
    $in_enc = trim($in_enc);
    $out_enc = trim($out_enc);
    if (strtolower($in_enc) == 'cp1251' && strtolower($out_enc) == 'utf-8') {
        return strtr($string, $GLOBALS['_win1251utf8']);
    }
    if (strtolower($in_enc) == 'utf-8' && strtolower($out_enc) == 'cp1251') {
        return strtr($string, $GLOBALS['_utf8win1251']);
    }


    return $string;
}

function is_agent_opera95() {
    if (empty($_SERVER['HTTP_USER_AGENT'])) {
        return false;
    }
    $useragent = strtolower($_SERVER['HTTP_USER_AGENT']);
    if (strstr($useragent, "opera")) {
        if (preg_match("/opera[\\s\/]?(\\d+(\\.\\d+)?)/", $useragent, $matches)) {
            $ver = $matches[1];

            if ($ver >= "9.5")
                return true;
        }
    }
    return false;
}


function getEmailArray($email) {
    if (is_array($email)) {
        return $email;
    }

    if (strstr($email, ',')
        || strstr($email, ';')
    ) {

        if (strstr($email, ',')) {
            $tos = explode(',', $email);
        } elseif (strstr($email, ';')) {
            $tos = explode(';', $email);
        }
        $res = array();
        foreach ($tos as $to) {
            $tmp = getEmailArray($to);
            if (is_array($tmp)) {
                $res = array_merge($res, $tmp);
            } else {
                $res[] = $tmp;
            }
        }
        return $res;
    }

    $strpos = strpos($email, '<');
    if ($strpos > 0) {
        $name = trim(substr($email, 0, $strpos));
        $email = trim(substr($email, $strpos + 1, strpos($email, '>') - $strpos - 1));
        $res = array($email => $name);
        return $res;
    }

    return $email;
}

function encodeForEmailAddress($string, $encoding) {
    $pos = strpos($string, '<');
    if ($pos > 0) {
        $name = trim(substr($string, 0, $pos));
        return encodeForEmail($name, $encoding) . substr($string, $pos);
    }
    return $string;
}

function encodeForEmail($string, $encoding) {
    return "=?" . $encoding . "?B?" . base64_encode($string) . "?=";
}

function div($a, $b) {
    return ($a - ($a % $b)) / $b;
}

function generate_get($params) {
    $servlet = $params['servlet_root'] . $params['servlet'];
    $p = $params['path_vars'];
    $infix = '?';

    if (strstr($servlet, $infix) !== FALSE) {
        $infix = '&';
    }

    if (is_array($p)) {
        foreach ($p as $k => $v) {
            $servlet .= $infix . $k . "=" . urlencode($v);
            $infix = '&';
        }
    }

    return $servlet;
}

function get_months_list($fromtime, $totime) {
    $start = getdate($fromtime);
    $month = $start['mon'];
    $year = $start['year'];
    $result = array();
    do {
        $current = mktime(0, 0, 0, $month, 1, $year);
        $result[date("m.y", $current)] = strftime("%B, %Y", $current);
        $month++;
        if ($month > 12) {
            $month = 1;
            $year++;
        }
    } while ($current < $totime);
    return $result;
}

function get_form_date($day, $month) {
    if (preg_match('/^(\d{2}).(\d{2})$/', $month, $matches)) {
        return mktime(0, 0, 0, $matches[1], $day, $matches[2]);
    }
    return 0;
}


function get_month_selection($fromtime, $totime) {
    $start = getdate($fromtime);
    $month = $start['mon'];
    $year = $start['year'];
    $result = array();

    do {
        $current = mktime(0, 0, 0, $month, 1, $year);
        $result[date("m.y", $current)] = strftime("%B, %Y", $current);
        $month++;
        if ($month > 12) {
            $month = 1;
            $year++;
        }
    } while ($current < $totime);
//    TRACEVAR('get_month_selection result month: ', $result);
    return $result;
}

function get_popup($href, $message, $title, $wndName, $options, $realHref = false, $class = null) {
    $class_string = !empty($class) ? "class=\"$class\"" : "";
    $title_string = !empty($title) ? "title=\"$title\" " : "";
//  $popup = get_popup_onclick($href, $wndName, $options);
    $linkHref = $href;
//  $linkHref = $realHref ? $href : '#';
    return "<a $class_string href='" . $linkHref . "' target='_blank' rel='nofollow noopener webim' $title_string>$message</a>";
}

function get_popup_onclick($href, $wndName, $options, $ainvite = false) {
    $href .= strstr($href, '?') ? '&' : '?';
    $pos = strpos($href, '/', 1);
    $href1 = substr($href, 0, $pos);
    $href2 = substr($href, $pos);

    return "if (navigator.userAgent.toLowerCase().indexOf('opera') != -1 && window.event.preventDefault) window.event.preventDefault();this.newWindow = window.open('$href1'+'$href2'+'opener='+encodeURIComponent(document.location.href) + '&openertitle='+encodeURIComponent(document.title.substring(0, document.title.length > 50 ? 50 : document.title.length).replace(/" . ($ainvite ? "%x22%" : "\\x22") . "/gi,''))" . ($ainvite ? "+'&autoinviteid=' + autoinviteid" : "") . " , '$wndName', '$options');if (this.newWindow==null)return false;this.newWindow.focus();this.newWindow.opener=window;return false";
}

function webim_date_diff($seconds) {

    $minutes = div($seconds, 60);
    $seconds = $seconds % 60;
    if ($minutes < 60) {
        return sprintf("%02d:%02d", $minutes, $seconds);
    } else {
        $hours = div($minutes, 60);
        $minutes = $minutes % 60;
        return sprintf("%02d:%02d:%02d", $hours, $minutes, $seconds);
    }
}

function get_app_location($showhost, $issecure) {
    if ($showhost) {
        $protocol = $issecure ? "https://" : "http://";
        return $protocol . $_SERVER['HTTP_HOST'] . WEBIM_ROOT;
    } else {
        return WEBIM_ROOT;
    }
}

function generateVisitorId() {
    return str_replace(',', '.', time() + microtime()) . rand(0, 99999999);
}

/*
* Is called from bitrix installation Wizard when WebIMInit is not yet
* called and thus no locales and resources required by CheckKey are
* initialized.
*/
function IsValidKey($pkey) {
//    return true; // debug
    $key = trim($pkey);
     
    /*p*/
    $ver = 'P';
    /*end p*/
     
    $url = "htt" . "p://k" . "ey.w" . "ebi" . "m." . "ru/ch" . "ec" . "k_k" . "ey.p" . "hp?ver=" . urlencode($ver) . "&key=" . urlencode($key);
    $arr = file($url);
    if ((strpos($pkey, $ver) === 0) && ("TRUE" == strtoupper(trim($arr[0])))) {
        return true;
    } else {
        return false;
    }
}

function subst($orig, $params) {
    $res = $orig;
    foreach ($params as $p => $value) {
        $res = preg_replace('/@' . $p . '@/mi', $value, $res);
    }
    return $res;
}

function listConvertableFiles($dir, &$arFiles = array()) {
    $convertable = array("php", "tpl", "txt");

    if ($handler = opendir($dir)) {
        while (($sub = readdir($handler)) !== FALSE) {
            if ($sub != "." && $sub != "..") {
                if (is_file($dir . "/" . $sub)) {
                    $pathParts = pathinfo($sub);
                    if (isset($pathParts["extension"]) && in_array($pathParts['extension'], $convertable)) {
                        $arFiles[] = $dir . "/" . $sub;
                    }
                } elseif (is_dir($dir . "/" . $sub)) {
                    listConvertableFiles($dir . "/" . $sub, $arFiles);
                }
            }
        }
        closedir($handler);
    }

    return $arFiles;
}

function getWindowNameSuffix() {
    return preg_replace('/[-:.\/]/', "_", $_SERVER['HTTP_HOST']);
}

function enumAvailableThemes() {

    $themes = array();
    $path = getThemesRoot();

    if ($handle = opendir($path)) {
        while (false !== ($file = readdir($handle))) {
            if (!preg_match('/^\./', $file)) {
                $themes[] = $file;
            }
        }
        closedir($handle);
    }

    sort($themes);
    return $themes;
}

function removeSpecialSymbols($text) {
    return preg_replace("/[\\x0-\\x9\\xb\\xc\\xe-\\x1f]+/", "", $text);
}


function uploadFile($requestFile, $dir, $fileName, $convertToDefaultFormat = FALSE, $maxUploadedFileSize = MAX_UPLOADED_FILE_SIZE) {
    $valid_types = array("gif", "jpg", "png", "jpeg", "swf", "svg");
    $filename = $requestFile['name'];
    $ext = $convertToDefaultFormat ? DEFAULT_IMAGE_EXT : pathinfo($filename, PATHINFO_EXTENSION);

    if ($requestFile['size'] > $maxUploadedFileSize) {
        return Resources::Get('errors.failed.uploading.file', array($filename, Resources::Get('errors.file.size.exceeded')));
    } elseif (!in_array(strtolower($ext), $valid_types)) {
        return Resources::Get('errors.failed.uploading.file', array($filename, Resources::Get('errors.invalid.file.type')));
    }

    $destFilename = strtolower($fileName . "." . $ext);
    $path = $dir . $destFilename;
    if (file_exists($path)) {
//        MYLOG('Path exists');
//        TRACEVAR('Path', $path);
        if (!unlink($path)) {
            return Resources::Get('errors.failed.uploading.file', array($destFilename, Resources::Get('errors.file.remove')));
        }
    }

    $movePath = $convertToDefaultFormat ? sys_get_temp_dir() . '/' . uniqid(true) . '.' . DEFAULT_IMAGE_EXT : $path;
    if (!move_uploaded_file($requestFile['tmp_name'], $movePath)) {
//        MYLOG('Failed to upload');
//        TRACEVAR('Path', $movePath);
        return Resources::Get('errors.failed.uploading.file', array($destFilename, Resources::Get('errors.file.move')));
    }

    if ($convertToDefaultFormat) {
        $image = new Imagick($movePath);
        if (!$image->writeImage($path)) {
//            MYLOG('Failed to convert to ' . DEFAULT_IMAGE_EXT);
//            TRACEVAR('Path', $path);
            return Resources::Get('errors.failed.uploading.file', array($destFilename, Resources::Get('errors.file.convert')));
        }
    } else if (strtolower(pathinfo($filename, PATHINFO_EXTENSION)) == 'svg') {
        $sanitizer = new Sanitizer();
        $sanitizer->setAllowedTags(new AllowedSvgTags());
        $sanitizer->minify(true);
        $sanitizer->removeRemoteReferences(true);
        $dirtySVG = file_get_contents($movePath);
        $cleanSVG = $sanitizer->sanitize($dirtySVG);
        if (!$cleanSVG) {
//            MYLOG('Failed to sanitize SVG image');
//            TRACEVAR('Path', $path);
            return Resources::Get('errors.failed.uploading.file', array($destFilename, Resources::Get('errors.file.convert')));
        }
        file_put_contents($path, $cleanSVG);
    }
}

function constructFileNameFromUploadedFile($requestFile, $fileNamePrefix, $useDefaultExt = FALSE) {
    $filename = $requestFile['name'];
    $ext = $useDefaultExt ? DEFAULT_IMAGE_EXT : substr($filename, 1 + strrpos($filename, "."));
    return strtolower($fileNamePrefix . "." . $ext);
}

function getCurrentDBTime() {
     
    /* s */
    return time();
    /* end s */
}


function create_basedir($file) {
    $dir = dirname($file);
    return create_dir($dir);
}

function create_dir($dir) {
    umask(0000);
    if (!is_dir($dir) && !is_file($dir)) {
        @mkdir($dir, 0777, true);
        return true;
    }

    return false;
}

function touch_online_file($file) {
    create_basedir($file);
    touch($file);
//	chmod($file, 0777);
}

function get_modified_time($file) {
    $stat = @stat($file);
    if ($stat) {
        return $stat[9];
    }

    return -1;
}

function write_file_value($file, $value) {
    create_basedir($file);
    $fd = fopen($file, 'w');

    if (!$fd)
        return false;

    if (!flock($fd, LOCK_EX)) {
        fclose($fd);
        return false;
    }

    if (!fwrite($fd, $value)) {
        $result = false;
    }

    flock($fd, LOCK_UN);
    fclose($fd);

    $result = true;
    return $result;
}

function has_file_value_or_empty($file) {
    $v = @file_get_contents($file);

    return $v == "1" || $v === false;
}

function has_file_value($file, $value = '1') {
    $v = @file_get_contents($file);

    return $v == $value;
}

function set_file_value($file, $value = '1') {
    return write_file_value($file, $value);
}

function is_since_eq_max_revision($file, $since) {
    $v = @file_get_contents($file);

    return $v == $since;
}

function set_max_revision($file, $revision) {
    return write_file_value($file, $revision);
}

function get_max_revision($file) {
    $val = @file_get_contents(MAX_REVISION_FILE);
    return $val === false || $val == 0 ? -1 : $val;
}

function unset_file_value($file) {
    return write_file_value($file, "0");
}

function translit($cp1251_str) {
    $table = array(
        168 => 'E', 184 => 'e', 192 => 'A', 193 => 'B', 194 => 'V', 195 => 'G',
        196 => 'D', 197 => 'E', 198 => 'J', 199 => 'Z', 200 => 'I', 201 => 'I',
        202 => 'K', 203 => 'L', 204 => 'M', 205 => 'N', 206 => 'O', 207 => 'P',
        208 => 'R', 209 => 'S', 210 => 'T', 211 => 'Y', 212 => 'F', 213 => 'H',
        214 => 'C', 215 => 'CH', 216 => 'SH', 217 => 'SH', 218 => '', 219 => 'Y',
        220 => '', 221 => 'E', 222 => 'U', 223 => 'IA', 224 => 'a', 225 => 'b',
        226 => 'v', 227 => 'g', 228 => 'd', 229 => 'e', 230 => 'j', 231 => 'z',
        232 => 'i', 233 => 'i', 234 => 'k', 235 => 'l', 236 => 'm', 237 => 'n',
        238 => 'o', 239 => 'p', 240 => 'r', 241 => 's', 242 => 't', 243 => 'y',
        244 => 'f', 245 => 'h', 246 => 'c', 247 => 'ch', 248 => 'sh', 249 => 'sh',
        250 => '', 251 => 'y', 252 => '', 253 => 'e', 254 => 'u', 255 => 'ia'
    );

    $result = $cp1251_str;
    foreach ($table as $k => $v) {
        $result = str_replace(chr($k), $v, $result);
    }

    return $result;
}

function parseReferrer($ref, $code) {
    if (
        strpos($ref, "yandex.ru") !== false &&
        preg_match("/text=([^&]+)/", $ref, $m)
    ) {
        $query = urldecode($m[1]);
        if (WEBIM_ENCODING != 'UTF-8') {
            $query = smarticonv('utf-8', 'cp1251', $query);
        }

        return Resources::Get($code . '.yandex', array($query, $ref));

    } else if (
        strpos($ref, "rambler.ru") !== false &&
        preg_match("/query=([^&]+)/", $ref, $m)
    ) {
        $query = urldecode($m[1]);
        if (WEBIM_ENCODING != 'UTF-8') {
            $query = smarticonv('utf-8', 'cp1251', $query);
        }

        return Resources::Get($code . '.rambler', array($query, $ref));

    } elseif (
        (strpos($ref, "google.ru") !== false || strpos($ref, "google.com") !== false) &&
        preg_match("/q=([^&]+)/", $ref, $m)
    ) {
        $query = urldecode($m[1]);
        if (WEBIM_ENCODING != 'UTF-8') {
            $query = smarticonv('utf-8', 'cp1251', $query);
        }

        return Resources::Get($code . '.google', array($query, $ref));

    } else if (
        (strpos($ref, "bing.com") !== false) &&
        preg_match("/q=([^&]+)/", $ref, $m)
    ) {
        $query = urldecode($m[1]);
        if (WEBIM_ENCODING != 'UTF-8') {
            $query = smarticonv('utf-8', 'cp1251', $query);
        }

        return Resources::Get($code . '.bing', array($query, $ref));
    }

    return $ref;
}

function getUsersStatsFromCookie() {
    $json = new Json(SERVICES_JSON_LOOSE_TYPE);
    $statistics = isset($_COOKIE['WEBIM_STATS']) ? $json->decode($_COOKIE['WEBIM_STATS']) : null;
    return $statistics;
}

function dateCompareBackwards($date1, $date2) {
    $d1 = strtotime($date1);
    $d2 = strtotime($date2);
    return $d1 < $d2;
}

function sortOperatorsByFullname($a, $b) {
    return strcmp($a['fullname'], $b['fullname']);
}

function sortOperatorsByOperatorsOrder($a, $b) {
    return $b['operatororder'] - $a['operatororder'];
}

function json_encode_readable($var) {
    if (PHP_VERSION_ID >= 50400) {
        return json_encode($var, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES | JSON_PRETTY_PRINT);
    } else {
        return json_encode($var);
    }
}

function json_safe_encode($var) {
    return json_encode(json_fix_cyr($var));
}

function json_safe_decode($var) {
    $res = json_decode($var, true);
    return json_fix_cyr($res, 'utf-8', 'windows-1251');
}

function json_fix_cyr($var, $from = WEBIM_ENCODING, $to = 'utf-8') {
    if (is_array($var)) {
        $new = array();
        foreach ($var as $k => $v) {
            $new[json_fix_cyr($k, $from, $to)] = json_fix_cyr($v, $from, $to);
        }
        $var = $new;
    } elseif (is_object($var)) {
        $vars = get_object_vars($var);
        foreach ($vars as $m => $v) {
            $var->$m = json_fix_cyr($v, $from, $to);
        }
    } elseif (is_string($var)) {
        $var = smarticonv($from, $to, $var);
    }
    return $var;
}

/**
 * @param $matches
 * @return mixed
 */
function getPHPEnvLetter() {
  global $argc, $argv;
  $matches = null;
  $phpLocation = '';
  $str = $argc > 0 ? realpath($argv[0]) : $_SERVER['SCRIPT_FILENAME'];
  if (preg_match('/public_html\.(.+?)\//', $str, $matches)) {
      $phpLocation = $matches[1];
  };
  return $phpLocation;
}


function getPythonPort() {
    return $_SERVER['X_TORNADO_PORT'];
//  global $PYTHON_PORTS;
//  static $account2port = null;
//  static $defaultPort = null;
//
//  if ($account2port === null) {
//    foreach ($PYTHON_PORTS as $port => $val) {
//      if ($val == 'default') {
//        $defaultPort = $port;
//      } else {
//        foreach ($val as $a) {
//          $account2port[$a] = $port;
//        }
//      }
//    }
//  }

//  return isset($account2port[getAccountId()]) ? $account2port[getAccountId()] : $defaultPort;
}


function requestPyServerUseCache($uri, $key, $kind, $ttl, $post = false, $serverPriority = false) {
    if ($serverPriority) {
        $data = requestPyServer($uri, $post);
        if ($data !== false) {
            KeyValueCache::put($key, $data, $kind, $ttl);
            return $data;
        } else {
            return KeyValueCache::get($key, $kind);
        }
    }

    $c = KeyValueCache::get($key, $kind, false);

    if ($c !== false) {
        return $c;
    }

    $data = requestPyServer($uri, $post);

    if ($data !== false) {
        KeyValueCache::put($key, $data, $kind, $ttl);
    }

    return $data;
}

function requestPyServer($uri, $post = false) {
    $doLog = true;

//  $base = Helper::getServerProtocol() . getAccountId() . '.pro-service.' . Helper::getRootDomain();
    $base = 'http://127.0.0.1:' . getPythonPort();
    $result = null;
    $ch = null;
    $fullUrl = null;
    $time = time();
    $info = null;

    for ($i = 0; $i < 1; $i++) {
        $ch = curl_init();
        $fullUrl = $base . $uri . '&account-name=' . urlencode(getAccountId()) . '&retry=' . $i;
        curl_setopt($ch, CURLOPT_URL, $fullUrl);
        curl_setopt($ch, CURLOPT_TIMEOUT, 2);
        curl_setopt($ch, CURLOPT_CONNECTTIMEOUT, 2);
        if ($post) {
            curl_setopt($ch, CURLOPT_POST, 1);
        }
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
        $result = curl_exec($ch);
        $info = curl_getinfo($ch);
        if ($result !== false && $info['http_code'] == 200) {
            curl_close($ch);
            break;
        }
    }
    $time -= time();

    if (($result === false || $doLog) && strstr($fullUrl, 'l/i/visit-session')) {
//  if ($doLog) {

        $stringData = "was going to " . $fullUrl . "\n";
        $stringData .= "retries  " . $i . "\n";
        $stringData .= "it took " . $time . "\n";
        $stringData .= "info " . print_r($info, true) . "\n";
        if (!$result) {
            $stringData .= curl_error($ch) . ' ' . curl_errno($ch);
        }
        $stringData .= "response was " . print_r($result, true) . "\n\n\n";


        doMyLog($stringData, true);


//    throw new Exception("failed to process url " . $fullUrl . " error: " . curl_error($ch) . ' number: ' . curl_errno($ch) . ' info: '. print_r(curl_getinfo($ch), true));

//    return null;
//    throw new Exception("failed to process url " . $fullUrl . " error: " . curl_error($ch) . ' number: ' . curl_errno($ch) . ' info: '. print_r(curl_getinfo($ch), true));
    }
//  var_dump($fullUrl);
//  var_dump('Got result');
//  var_dump($result);
//  die();
    return $result;
}

function microtime_float() {
    list($usec, $sec) = explode(" ", microtime());
    return ((float)$usec + (float)$sec);
}

function getTs($timeDiff=null) {
    $ts = time();
    if (isset($timeDiff)) {
        $ts = $ts + $timeDiff;
    }
    return $ts;
}

function doStatsLog($message) {
    if (php_sapi_name() !== 'cli') {
        return;
    }

    echo "\n" . date("Y-m-d\TH:i:s") . substr((string)microtime(), 1, 8) . ': ' . (is_array($message) ? print_r($message, true) : $message);
}

function doMyLog($message, $doIPCheck = false, $addStackTrace = false, $myFile = null) {
    global $urlPrinted;
    if ($myFile === null) {
        $myFile = "my_php.log";
    }
    if (!isMyIP() && $doIPCheck) {
        return;
    }
    if (is_array($message)) {
        $message = print_r($message, true);
    }
    if ($myFile !== 'stdout') {
        $fileName = "/var/log/pro/" . $myFile;
        $fh = fopen($fileName, 'a+');
    }

    $message = "\n\n" . date("Y-m-d\TH:i:s") . substr((string)microtime(), 1, 8) . ': ' . (is_array($message) ? print_r($message, true) : $message);
//  $message .= "\n";


    if (isset($_SERVER['HTTP_HOST']) && isset($_SERVER['REQUEST_URI']) && empty($urlPrinted)) {
        $url = (empty($_SERVER['HTTPS']) ? 'http' : 'https') . '://' . $_SERVER['HTTP_HOST'] . $_SERVER['REQUEST_URI'];
        $message .= "\n\nURL:\n";
        $message .= $url . "\n";
        $urlPrinted = true;
    }

    if (isset($_SERVER['SCRIPT_FILENAME']) && $myFile === null) {
        $message .= "\n\nScript:\n";
        $message .= $_SERVER['SCRIPT_FILENAME'] . "\n";
    }

    if ($addStackTrace) {
        $message .= "\n\nStack trace:\n";
        $message .= print_r(debug_backtrace(true), true);
    }

    if ($myFile !== 'stdout') {
        fwrite($fh, $message);
        fclose($fh);
    } else {
        echo $message;
    }
}

function immediatelyNotifyAboutProblem($val, $subject = null, $email = null) {
    if ($subject === null && is_string($val) && strlen($val) < 40) {
        $subject = "Got problem: " . $val;
    }
    global $MAIN_SETTINGS;
    if (is_array($val)) {
        $val = print_r($val, true);
    }

  if (isset($_SERVER['HTTP_HOST']) && isset($_SERVER['REQUEST_URI'])) {
    $url = (empty($_SERVER['HTTPS']) ? 'http' : 'https') . '://' . $_SERVER['HTTP_HOST'] . $_SERVER['REQUEST_URI'];
    $val .= "\n\nURL:\n";
    $val .= $url . "\n";
  }

  if (isset($_SERVER['SCRIPT_FILENAME'])) {
    $val .= "\n\nScript:\n";
    $val .= $_SERVER['SCRIPT_FILENAME'] . "\n";
  }

  $val .= "\n\nStack trace:\n";
  $val .= print_r(debug_backtrace(), true);

    if ($email === null) {
        $email = $MAIN_SETTINGS['server_monitoring_email'];
    }
    if (isDevMode()) {
        die($val);
    }
//    @mail($email, $subject, $val . "\n" . getDebugInfoArrayAsString());
}

function isHostedMode() {
    global $MAIN_SETTINGS;
    return isset($MAIN_SETTINGS['hostedmode']) && $MAIN_SETTINGS['hostedmode'];
}

function array_copy($a) {
    $result = array();
    foreach ($a as $k => $v) {
        $result[$k] = $v;
    }
    return $result;
}

function getDebugInfoArrayAsString() {
  $myRequest = $_REQUEST;
  if (!empty($myRequest['password'])) {
    $myRequest['password'] = "***";
  }
  if (!empty($myRequest['password_conf'])) {
    $myRequest['password_conf'] = "***";
  }

  if (!empty($myRequest['password_repeat'])) {
    $myRequest['password_repeat'] = "***";
  }

  $url = (empty($_SERVER['HTTPS']) ? 'http' : 'https') . '://' . $_SERVER['HTTP_HOST'] . $_SERVER['REQUEST_URI'];
  return print_r(array('url' => $url, 'server' => $_SERVER, 'request' => $myRequest, 'cookie' => $_COOKIE, 'session' => !empty($_SESSION) ? $_SESSION : ''), true);
}

function sec2hms($sec, $padHours = false, $padSeconds = false) {
    if ($sec == 0 && !$padSeconds) {
        return '';
    }


    // start with a blank string
    $hms = "";

    // do the hours first: there are 3600 seconds in an hour, so if we divide
    // the total number of seconds by 3600 and throw away the remainder, we're
    // left with the number of hours in those seconds
    $hours = intval(intval($sec) / 3600);

    // add hours to $hms (with a leading 0 if asked for)
    if ($hours > 0) {
        $hms .= ($padHours)
            ? str_pad($hours, 2, "0", STR_PAD_LEFT) . ":"
            : $hours . ":";
    }

    // dividing the total seconds by 60 will give us the number of minutes
    // in total, but we're interested in *minutes past the hour* and to get
    // this, we have to divide by 60 again and then use the remainder
    $minutes = intval(($sec / 60) % 60);

    // add minutes to $hms (with a leading 0 if needed)
    $hms .= str_pad($minutes, 2, "0", STR_PAD_LEFT) . ":";

    // seconds past the minute are found by dividing the total number of seconds
    // by 60 and using the remainder
    $seconds = intval($sec % 60);

    // add seconds to $hms (with a leading 0 if needed)
    $hms .= str_pad($seconds, 2, "0", STR_PAD_LEFT);

    // done!
    return $hms;

}

function is_function($f) {
    return (is_string($f) && function_exists($f)) || (is_object($f) && ($f instanceof Closure));
}

function calcHash($fields, $expires, $privateKey, $algorithm) {
    $s = '';
    $keys = array_keys($fields);
    sort($keys);

    foreach ($keys as $k) {
        $s .= $fields[$k];
    }

    $s .= $expires;

//    return md5($s . $privateKey);
    if ($algorithm == 'hmac-sha256') {
        return hash_hmac('sha256', $s, $privateKey);
    } else {
        return hash($algorithm, $s . $privateKey);
    }
}

// todo remove and use calcHash
function calcCRC($fields, $privateKey) {
    $crc = '';
    $keys = array_keys($fields);
    sort($keys);

    foreach ($keys as $k) {
        $crc .= $fields[$k];
    }

    $crc = md5($crc . $privateKey);

    return $crc;
}

function getBrandPartner() {
    $result = getBrandPartnerFromHeaders();
    return $result;
}

function getBrandPartnerFromHeaders() {
    if (!isset($_SERVER['X_BRAND_PARTNER'])) {
        return null;
    }
    $brandPartner = $_SERVER['X_BRAND_PARTNER'];
    if (empty($brandPartner)) {
        return null;
    }
    return $brandPartner;
}


function seems_utf8($str) {
    # get length, for utf8 this means bytes and not characters
    $length = strlen($str);

    # we need to check each byte in the string
    for ($i = 0; $i < $length; $i++) {

        # get the byte code 0-255 of the i-th byte
        $c = ord($str[$i]);

        # utf8 characters can take 1-6 bytes, how much
        # exactly is decoded in the first character if
        # it has a character code >= 128 (highest bit set).
        # For all <= 127 the ASCII is the same as UTF8.
        # The number of bytes per character is stored in
        # the highest bits of the first byte of the UTF8
        # character. The bit pattern that must be matched
        # for the different length are shown as comment.
        #
        # So $n will hold the number of additonal characters

        if ($c < 0x80) $n = 0; # 0bbbbbbb
        elseif (($c & 0xE0) == 0xC0) $n = 1; # 110bbbbb
        elseif (($c & 0xF0) == 0xE0) $n = 2; # 1110bbbb
        elseif (($c & 0xF8) == 0xF0) $n = 3; # 11110bbb
        elseif (($c & 0xFC) == 0xF8) $n = 4; # 111110bb
        elseif (($c & 0xFE) == 0xFC) $n = 5; # 1111110b
        else return false; # Does not match any model

        # the code now checks the following additional bytes
        # First in the if checks that the byte is really inside the
        # string and running over the string end.
        # The second just check that the highest two bits of all
        # additonal bytes are always 1 and 0 (hexadecimal 0x80)
        # which is a requirement for all additional UTF-8 bytes

        for ($j = 0; $j < $n; $j++) { # n bytes matching 10bbbbbb follow ?
            if ((++$i == $length) || ((ord($str[$i]) & 0xC0) != 0x80))
                return false;
        }
    }
    return true;
}

function getLastModifiedTs($fileNames) {
    $result = 0;
    foreach ($fileNames as $fileName) {
        $ts = 0;
        if (is_dir($fileName)) {
            $subFiles = array_diff(scandir($fileName), array('..', '.'));
            array_walk($subFiles,function(&$item, $key, $dirName) {
                $item = $dirName . '/' . $item;
            }, $fileName);
            $ts = getLastModifiedTs($subFiles);
        } elseif (file_exists($fileName)) {
            $ts = filemtime($fileName);
        }
        $result = max($ts, $result);
    }
    return $result;
}


/**
 * @param $fileNames
 */
function makeLastModifiedHeader($fileNames = null) {
    if (isset($fileNames) && is_string($fileNames)) {
      $fileNames = array($fileNames);
    }

    $lastModified = null;
    $files = array(dirname(__FILE__) . '/version.php', $_SERVER['SCRIPT_FILENAME'], DATA_UPDATED_FILE);
    if ($fileNames !== null) {
        $files = array_merge($fileNames, $files);
    }
    $lastModified = getLastModifiedTs($files);
    $lastModifiedStr = gmdate('D, d M Y H:i:s', $lastModified) . ' GMT';
    header('Last-Modified: ' . $lastModifiedStr);
    return $lastModifiedStr;
}

function isBigAccount($accountName = null) {
    global $MAIN_SETTINGS;
    if (empty($MAIN_SETTINGS['big_accounts'])) {
        return false;
    }

    if ($accountName === null) {
        $accountName = getAccountId();
    }

    return in_array($accountName, $MAIN_SETTINGS['big_accounts']);
}

function my_session_start() {
  session_set_cookie_params(0, '/', $_SERVER['HTTP_HOST'], Helper::isCookieHttps(), true);

  $sessid = '';
  if (ini_get('session.use_cookies') && isset($_COOKIE['PHPSESSID'])) {
    $sessid = $_COOKIE['PHPSESSID'];
  } elseif (!ini_get('session.use_only_cookies') && isset($_GET['PHPSESSID'])) {
    $sessid = $_GET['PHPSESSID'];
  }
  if (!preg_match('/^[a-z0-9]+$/', $sessid)) {
    doMyLog("Making new session: " . $sessid, true, true, null);
    $cookieDomain = isHostedMode() ? '.' . Helper::getRootDomain() : '.' . Helper::getRootDomain();
    session_set_cookie_params(0, '/', $cookieDomain, Helper::isCookieHttps(), true);
    session_id(uniqid());
    session_start();
    session_regenerate_id();
  } else {
    doMyLog("Just staring: " . $sessid, true);

    session_start();
  }
}

function isDevMode() {
  global $MAIN_SETTINGS;
  return $MAIN_SETTINGS['devmode'] == 1;
}

function ip_in_range($ip, $range) {
    if (strpos($range, '/') == false) {
        $range .= '/32';
    }
    // $range is in IP/CIDR format eg 127.0.0.1/24
    list($range, $netmask) = explode('/', $range, 2);
    $range_decimal = ip2long($range);
    $ip_decimal = ip2long($ip);
    $wildcard_decimal = pow(2, (32 - $netmask)) - 1;
    $netmask_decimal = ~$wildcard_decimal;
    return (($ip_decimal & $netmask_decimal) == ($range_decimal & $netmask_decimal));
}

function convertCommaSeparatedStringToArray($str) {
    if (trim($str) === '') {
        return array();
    }

    $result = explode(',', $str);
    foreach ($result as $i => $v) {
        $result[$i] = trim($v);
    }
    return $result;
}

function getButtonJsCacheFileName($accountId = null) {
    global $MAIN_SETTINGS;

    $dir = $MAIN_SETTINGS['web_cache_dir'] . DIRECTORY_SEPARATOR . ($accountId ?: getAccountId()) . '/js';
    if (!file_exists($dir)) {
        mkdir($dir, 0777, true);
    }
    return $dir . '/button.js';
}
?>
