<?php
require_once(dirname(__FILE__) . '/functions.php');
require_once(dirname(__FILE__) . '/../autoload.php');

class MailNotifications {

  public static function sendRegistrationUsageBitrixMail($accountName, $email, $person) {
    self::_sendRegistrationMail($accountName, $email, $person, null, 'reg_mail_usage_bitrix_templ');
  }
  public static function sendPasswordToOperator($email, $password, $name) {
    self::sendMail($email, Resources::Get("email.from"), 'operator_creation_password', array('NAME' => $name, 'PASSWORD' => $password, 'EMAIL' => $email));
  }
  public static function sendRegistrationMail($accountName, $email, $person, $token) {
    self::_sendRegistrationMail($accountName, $email, $person, $token, 'reg_mail_temp');
  }

  private static function _sendRegistrationMail($accountName, $email, $person, $token, $template) {
    $params = array(
      'LINK' => Helper::getServerProtocol() . 'login.' . Helper::getRootDomain() . WEBIM_ROOT
          . '/activate.php?token=' . urlencode($token).'&accountname='.urlencode($accountName),
      'NAME' => $accountName,
      'PERSON' => $person,
      'BUTTON_CODE' => Location::getLocationCodeForSite(),
      'SERVICE_LINK' =>  Helper::getServiceURL($accountName, null, null, false),
     'APP_STORE_INFO' => Resources::Get('app_store.info'),
     'ANDROID_INFO' => Resources::Get('android.info')
    );

    self::sendMail(array($email => $person), Resources::Get("email.from"), $template, $params);
  }

  public static function sendLowBalanceWarningMail($email, $balance) {
    $params = array(
      'BALANCE' => $balance
    );

    self::sendMail($email, Resources::Get("email.from"), 'low_balance_warning_email', $params);
  }

  public static function sendNewVersionTransferAndNewTrial($email, $accountname) {
    $params = array(
      'ACCOUNTNAME' => $accountname,
      'EMAIL' => $email,
    );
    self::sendMail($email, Resources::Get("email.from"), 'transfer_to_new_version_email', $params);
  }

  public static function sendNewVersionTransfer2($email, $accountname) {
    $params = array(
      'ACCOUNTNAME' => $accountname,
      'EMAIL' => $email,
    );
    self::sendMail($email, Resources::Get("email.from"), 'transfer_to_new_version_email2', $params);
  }

  public static function sendMoneyDeposit($email, $amount, $balance) {
    $params = array(
      'AMOUNT' => $amount,
      'BALANCE' => $balance
    );

    self::sendMail($email, Resources::Get("email.from"), 'money_deposit', $params);
  }

  public static function sendReActivationMail($toaddr, $token) {
    $params = array('LINK' => Helper::getServerProtocol() . $_SERVER['HTTP_HOST'] . WEBIM_ROOT .
        '/activate.php?token=' . $token);

    self::sendMail($toaddr, Resources::Get("email.from"), 'reactivation_mail_temp', $params);
  }

  public static function sendRegistrationMailToPartnersClient($name, $toaddr, $token, $password) {
    $params = array('LINK' => Helper::getServerProtocol() . $_SERVER['HTTP_HOST'] . WEBIM_ROOT .
        '/activate.php?token=' . $token, 'NAME' => $name, 'PASSWORD' => $password);

    self::sendMail($toaddr, Resources::Get("email.from"), 'partner_create_account_for_client_mail', $params);
  }

  public static function sendRecoverPasswordMail($email, $token, $fullname) {
    $link = Helper::getServerProtocol() . $_SERVER['HTTP_HOST'] .WEBIM_ROOT. '/operator/recover-password.php' .
        '?action=showNewPasswordForm&user_email=' . urlencode($email) . '&token=' . urlencode($token);

    self::sendMail(array($email => $fullname), Resources::Get("email.from"), 'recover_password_mail_temp', array('NAME' => $fullname, 'LINK' => $link));
  }

  public static function confirmNewPartnerMail($partner_card, $info_to_webim) {
    $params = array('LINK' => Helper::getServerProtocol() . $_SERVER['HTTP_HOST'] .
        WEBIM_ROOT . '/partner/partner_activ.php?token=' .
        $partner_card['activationtoken'], 'DATA' => print_r($partner_card, true),
      'INFO_TO_WEBIM' => $info_to_webim);

    $bodyAppendix = "\n\r\n\rREQUEST Array:" . print_r($_REQUEST, true) .
        "\n\r\n\rSERVER Array:" . print_r($_SERVER, true) .
        "\n\r\n\rCOOKIE Array:" . print_r($_COOKIE, true);
    self::sendMail(SERVICE_NOTIF_EMAIL, Resources::Get("email.from"),
      'partner_conf_mail_temp', $params, $bodyAppendix);
  }

  public static function sendMailPartnerConfirmed($data) {
    $params = array('LINK' => Helper::getServerProtocol() . $_SERVER['HTTP_HOST'] . WEBIM_ROOT . '/');
    self::sendMail($data['email'], Resources::Get("email.from"), 'partner_activated_mail', $params);
  }

  public static function partnerChangedInformationMail($partner_card, $info_to_webim) {
    $partner_data = PartnerData::getInstance();

    $id = $_SESSION[SESSION_OPERATOR]['accountid'];

    $params = array('ACCOUNT' => $_SESSION[SESSION_OPERATOR]['accountname'],
      'OLD_DATA' => print_r($partner_data->getCardByAccountId($id), true),
      'NEW_DATA' => print_r($partner_card, true),
      'INFO_TO_WEBIM' => $info_to_webim);

    self::sendMail(SERVICE_NOTIF_EMAIL, Resources::Get("email.from"),
      'partner_changed_info_mail_temp', $params);
  }

  public static function serviceProCreatedMail($account_pro_address, $password, $to_email) {
    $params = array('service_pro_host' => $account_pro_address, 'password' => $password, 'button_code' => Location::getLocationCodeForSite());

    self::sendMail($to_email, Resources::Get("email.from"), 'service_pro_created_mail', $params);
  }

  public static function serviceProCreationFailureMail($accountName, $address, $error, $post_content) {
    $params = array('ACCOUNT' => $accountName, 'ADDRESS' => $address, 'ERROR' => $error, 'POST' => $post_content);

    immediatelyNotifyAboutProblem($params, "registration failure");
  }

  public static function serviceProCreationSuccessMail($accountname, $address) {
    $params = array('ACCOUNT' => $accountname, 'ADDRESS' => $address);
    if (isset($_REQUEST['password'])) {
      unset($_REQUEST['password']);
    }
    if (isset($_REQUEST['password_repeat'])) {
      unset($_REQUEST['password_repeat']);
    }
    $bodyAppendix = "\n\r\n\rREQUEST Array:" . print_r($_REQUEST, true) .
        "\n\r\n\rSERVER Array:" . print_r($_SERVER, true) .
        "\n\r\n\rCOOKIE Array:" . print_r($_COOKIE, true);

    self::sendMail(SERVICE_NOTIF_EMAIL, Resources::Get("email.from"),
      'service_pro_creation_success_mail', $params, $bodyAppendix);
//    return; // debug
//    self::sendMail('alltrade@webim.ru', $DEFAULT_FROM, // TODO very hard code
//      'service_pro_creation_success_mail', $params, $bodyAppendix);
  }

  public static function clientCreateServiceProInvoiceMail($accountname, $invoice_link, $invoice = null) {
    $params = array('ACCOUNT' => $accountname, 'INVOICE_LINK' => $invoice_link, 'DATA' => print_r($invoice, true));

    self::sendMail(SERVICE_NOTIF_EMAIL, Resources::Get("email.from"),
      'client_create_service_pro_invoice_mail', $params);
//    return; // debug
//    self::sendMail('alltrade@webim.ru', $DEFAULT_FROM, // TODO very hard
//      'client_create_service_pro_invoice_mail', $params);
  }

  public static function partnerCreateInvoiceToWebimMail($accountname, $invoice_link) {
    $params = array('ACCOUNT' => $accountname, 'INVOICE_LINK' => $invoice_link);

    self::sendMail(SERVICE_NOTIF_EMAIL, Resources::Get("email.from"),
      'partner_create_invoice_to_webim_mail', $params);
  }

  private static function sendMail($to, $from, $templateSource, $params = null, $bodyAppendix = null) {
    $mailModel = new MailTemplateModel();
    $params['SERVICE_NAME'] = Resources::Get('service.name');
    if (!isset($params['SERVICE_LINK'])) {
      $params['SERVICE_LINK'] =  Helper::getServerRootURL();
    }
    $mailModel->processMailTemplateSource($templateSource, $params);

    require_once(dirname(__FILE__) . '/webim_mail.php');
    webim_mail($to, $from, $mailModel->getSubject(),
        $mailModel->getBody() . (!empty($bodyAppendix) ? $bodyAppendix : ''));
  }

  public static function sendRegistrationMailJira($email, $params) {
    self::sendMail($email, Resources::Get("email.from"), 'registration_mail_jira', $params);
  }


}

?>
