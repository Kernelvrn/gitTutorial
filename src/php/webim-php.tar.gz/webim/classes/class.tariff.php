<?php
require_once(dirname(__FILE__).'/models/generic/class.mapperfactory.php');

class Tariff  {
  private static $instance = NULL;

  static function getInstance() {
    if(self::$instance == NULL) {
      self::$instance = new Tariff();
    }
    return self::$instance;
  }

  private function __construct() {

  }

  private function __clone() {
  }

  public function hasTariffOption($option, $accountName = null) {
    return $this->getTariffOptionValue($option, $accountName);
  }

  public function getTariffOptionValue($option, $accountName = null) {
    if ($accountName === null) {
      $accountName = getAccountId();
    }
    $zone = 'tariff' . ($accountName !== null ? '-' . $accountName : '');
    $tariff_settings = KeyValueCache::get($zone, 'tariff', false);
    if ($tariff_settings === false) {
      $tariff_settings = $this->loadTariffSettings($accountName);
      KeyValueCache::put($zone, $tariff_settings, 'tariff', 15 * 60);
    }

    return isset($tariff_settings[$option]) ? $tariff_settings[$option] : FALSE;
  }

  function loadTariffSettings($accountName) {
    $account = MapperFactory::getAccountMapper()->getByName($accountName);
    $tariff_rows = MapperFactory::getTariffMapper()->getAccountTariffs($accountName, $account['tariff']);

    $tariff_settings = array();

    foreach($tariff_rows as $row) {
      $this->mergeTariffSettings($tariff_settings, $row['settings']);
    }
    $this->mergeTariffSettings($tariff_settings, $account['tariff_settings']);

    return $tariff_settings;
  }

  function mergeTariffSettings(&$tariff_settings, $settings_json) {
    $settings = ($settings_json == null or $settings_json == '') ? array() : json_decode($settings_json, true);
    foreach ($settings as $k => $v) {
        $tariff_settings[$k] = $v;
    }
  }
}

?>
