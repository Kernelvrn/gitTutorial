<?php 

define('KEY', 'P-D1280876-96D35D10-31B46408-050FEF43');


$TORNADO_PORTS = array('8262', '8263', '8264', '8265', '8266', '8267', '8268'); // used for default 8250


define('DEFAULT_IMAGE_EXT', 'png');
define('MAGICHOME', '/usr/bin');


define("PRO_FREE_PERIOD", 7);
define("RATE_SCHEME_FREE",'free');

define('DB_CONFIG_PATH', '/etc/webim/db.json');
define('DB_CONFIG_EXT_PATH', '/etc/webim/db.json.d');


//define('SALT','makesomenoise34556');
//define('COOKIE_SALT','makesomenoise34556');
define('COOKIE_SALT','');
define('COOKIE_KEY_ENCRYPTION', 'sdfasdfv');
define('WEBIM_ENCODING', 'UTF-8');

global $MAIN_SETTINGS;

$MAIN_SETTINGS = parse_ini_file('/etc/webim/main.ini');

if ($handle = @opendir('/etc/webim/main.ini.d')) {
  while (false !== ($entry = readdir($handle))) {
    if ($entry != "." && $entry != "..") {
      $tmp = parse_ini_file('/etc/webim/main.ini.d/' . $entry);
      $MAIN_SETTINGS = merge_arrays($MAIN_SETTINGS, $tmp);
    }
  }
  closedir($handle);
}

define('SERVICE_USER', $MAIN_SETTINGS['service_user']);
define('SERVICE_PASSWORD', $MAIN_SETTINGS['service_password']);

$DBSETTINGS = readDbConfig();

define('READY_IMAGES_DIR', $MAIN_SETTINGS['ready_images_dir']);

define('SERVICE_NOTIF_EMAIL', $MAIN_SETTINGS['service_notifications_emails']); 
define('COOKIE_AUTH_TOKEN', 'WEBIM_AUTH_TOKEN');
define('COOKIE_WEBIM_URL', 'WEBIM_URL');
define('SESSION_OPERATOR', 'CURRENT_OPERATOR');
define('SESSION_ROLES', 'ROLES');
define('SESSION_CURRENT_THREAD_ID', 'CURRENT_THREAD_ID');
define('SITE_DB_TYPE', 'mysql');

define('AUTH_TOKEN_SALT', $MAIN_SETTINGS['auth_token_salt']);
define('LOGGED_OPERATORS_DIR', $MAIN_SETTINGS['logged_operators_dir']);



define('ACCOUNT_DIR', dirname(__FILE__) . '/../accounts/' . getAccountId() . "/");

define('GEODB_DIR', '/var/pro/geodb');
//define('PYTHON_PORT', 8235);

    
//$PYTHON_PORTS = array(8235 => 'default', 8236 => array('webim', 'testcompany'), 8238 => array('promo', 'a1shop', 'proskater', 'camelotonline', 'lapsi', 'okonti', 'limoworld', 'satserv', 'ainsideru'));
//define('BUTTON_PARAMS_FILE', CLIENT_DATA_DIR.'/button-params.txt');

@include_once(ACCOUNT_DIR . 'account_config.php');

function is_array_assoc($array) {
    foreach (array_keys($array) as $k => $v) {
        if ($k !== $v)
            return true;
    }
    return false;
}

function merge_arrays($arr1, $arr2) {
    foreach ($arr2 as $arr2key => $arr2Val) {
        if (array_key_exists($arr2key,$arr1)) {
            if (is_array($arr2[$arr2key])) {
                if (is_array_assoc($arr2[$arr2key])) {
                    $arr1[$arr2key] = merge_arrays($arr1[$arr2key], $arr2[$arr2key]);
                } else {
                    $arr1[$arr2key] = array_merge($arr1[$arr2key], $arr2[$arr2key]);
                }

            } else {
                $arr1[$arr2key] = $arr2[$arr2key];
            }
        } else {
            $arr1[$arr2key] = $arr2[$arr2key];
        }
    }
    return $arr1;
}

function removeItemFromArrayByKey(&$array, $key) {
  unset($array[$key]);
  foreach ($array as &$value) {
    if (is_array($value)) {
      removeItemFromArrayByKey($value, $key);
    }
  }
}

function readDbConfig() {
  $result = array();
  $config = json_decode(file_get_contents(DB_CONFIG_PATH), true);
  if (file_exists('/etc/webim/db.d.json')) {
    $configD = json_decode(file_get_contents('/etc/webim/db.d.json'), true);
    removeItemFromArrayByKey($configD,"database");
    $config = array_replace_recursive($config, $configD);
  }

  if (is_dir(DB_CONFIG_EXT_PATH)) {
      $files = scandir(DB_CONFIG_EXT_PATH);
      foreach ($files as $filename) {
          if (is_file(DB_CONFIG_EXT_PATH . '/' . $filename)) {
            $full_name = DB_CONFIG_EXT_PATH . '/' . $filename;
            $configD = json_decode(file_get_contents($full_name), true);
            if (!is_array($configD)) {
              throw new Exception("Could not parse " . $full_name);
            }
            $config = array_replace_recursive($config, $configD);
          }
      }
  }
  $result['operators'] = $config['dbs']['meta'];

  if (isset($config['dbs']['pro'][getAccountId()])) {
    $result['pro'] = $config['dbs']['pro'][getAccountId()];

    if (isset($config['dbs']['pro2'][getAccountId()])) {
      $result['pro2'] = $config['dbs']['pro2'][getAccountId()];
    }
  } else {
    $result['pro'] = $config['dbs']['pro']['default'];
    $result['pro']['database'] = 'webim_service_pro_' . getAccountId();

    if (isset($config['pro2'])) {
      $result['pro2'] = $config['dbs']['pro2']['default'];
      $result['pro2']['database'] = 'webim_service_pro_' . getAccountId();
    }
  }

  return $result;
}

function getAccountId() {

  static $accountId = false;
  if ($accountId === false) {

    global $MAIN_SETTINGS;
    if (isset($MAIN_SETTINGS['hostedmode']) && $MAIN_SETTINGS['hostedmode']) {
      $accountId = $MAIN_SETTINGS['hosted_accountname'];
      return $accountId;
    }

    if (isset($_SERVER['X_ACCOUNT_NAME'])) {
      $accountId = $_SERVER['X_ACCOUNT_NAME'];
      if (in_array($accountId, array('login', 'profile', ''))) {
        $accountId = null;
      }
    }

    if ($accountId === false && !empty($_SERVER['HTTP_HOST'])) {
      preg_match("/^([a-zA-Z0-9]+?)\./", $_SERVER['HTTP_HOST'], $matches);
      $accountId = isset($matches[1]) ? $matches[1] : null;
    }

    global $argc, $argv;
    if ($accountId === false && !empty($argc) && $argc > 1) {
      $accountId = $argv[1]; // for cli
    }

//    if (empty($accountId)) {
//      $o = Helper::silentGetCurrentOperator();
//      if ($o !== null) {
//        $accountId = Helper::getFirstAvailableAccountName();
//      }
//    }
    if ($accountId === false) {
      $accountId = null;
    }
  }
  if ($accountId !== null && !preg_match('/^[a-zA-Z0-9]+$/', $accountId)) {
      throw new Exception("Account name doesn't match regexp " . $accountId);
  }
  return $accountId;
}

function getThemesFolder() {
  return is_dir($_SERVER['DOCUMENT_ROOT'] . WEBIM_ROOT . '/accounts/' . getAccountId() . '/themes/') ? '/accounts/' . getAccountId() . '/themes/' : '/themes/';
}

function getThemesRoot() {
  return $_SERVER['DOCUMENT_ROOT'] . WEBIM_ROOT . getThemesFolder();
}

function getButtonsLocation() {
  $accountButtons = $_SERVER['DOCUMENT_ROOT'] . WEBIM_ROOT . '/accounts/' . getAccountId() . '/themes/.buttons/';
  if (is_dir($accountButtons)) {
    return $accountButtons;
  }
  //  return $_SERVER['DOCUMENT_ROOT'].WEBIM_ROOT.'/themes/.buttons/';
  return dirname(__FILE__) . '/../themes/.buttons/';
}


/* s */
function isAccountBlocked() {
    $currentAccount = Account::getInstance()->getCurrentAccount();
    return $currentAccount['isblocked'];
}

/* end s */
?>
