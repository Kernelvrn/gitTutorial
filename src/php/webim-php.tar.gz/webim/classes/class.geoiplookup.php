<?php

class GeoIPLookup {
  private static $haveCngeoip = null;
  private static $defaultLocale = "ru";
  private static $defaultEncoding = "UTF-8";
  private static $cnGeo = null;
   
  /*Only Russian and English locales avaliable for cngeoip*/
  private static $indexesForLocales = array(
    "ru" => array(0, 5),
    "en" => array(1, 6)
  );

  private static $functionsForEncodings = array(
    "UTF-8" => "cngeoip_lookup_ip",
    "CP1251" => "cngeoip_lookup_ip_cp1251"
  );

  private function __construct() {
  }

  public static function getGeoDataByIP($ip) {
    if (empty($ip)) {
      return null;
    }
    $ip = Helper::getRealIP($ip);
//    $ip = '84.52.101.196';

    self::initGeoIP();

    if (self::$haveCngeoip) {
      if (!isset(self::$indexesForLocales[Resources::getCurrentLocale()])) {
        $locale = self::$defaultLocale;
      } else {
        $locale = Resources::getCurrentLocale();
      }

      $locale = strtoupper($locale);

      if (!isset(self::$functionsForEncodings[WEBIM_ENCODING])) {
        $encoding = self::$defaultEncoding;
      } else {
        $encoding = WEBIM_ENCODING;
      }


      $json = self::$cnGeo->lookup($ip);
//      $data = json_decode($json, true);

//      var_dump(self::$indexesForLocales[$locale]);

//      var_dump($json['items']);

      if (empty($json) || empty($json['items'])
          || (empty($json['items'][count($json['items']) - 1]['name']) && empty($json['items'][count($json['items']) - 1]['name_official']))
        || (empty($json['items'][0]['name'][$locale]) && empty($json['items'][0]['name_official'][$locale]))) {
        return null;
      }

       $result = array("city" => !empty($json['items'][0]['name'][$locale]) ? $json['items'][0]['name'][$locale] : $json['items'][0]['name_official'][$locale],
        "country" => !empty($json['items'][count($json['items']) - 1]['name'][$locale]) ? $json['items'][count($json['items']) - 1]['name'][$locale] : $json['items'][count($json['items']) - 1]['name_official'][$locale],
        "lat" => !empty($json['items'][0]['lat']) ? str_replace(',', '.', $json['items'][0]['lat']) : '',
        "lng" => !empty($json['items'][0]['lon']) ? str_replace(',', '.', $json['items'][0]['lon']) : ''
      );

      foreach ($result as $key => $value) {
        $result[$key] = smarticonv('utf-8', WEBIM_ENCODING, $value);
      }

      return $result;

      $data = call_user_func(self::$functionsForEncodings[$encoding], $ip);

      if (empty($data[0])) {
        return null;
      }

      if ($encoding != WEBIM_ENCODING) {
        foreach ($data as $key => $value) {
          $data[$key] = smarticonv($encoding, WEBIM_ENCODING, $value);
        }
      }

      $result = array("city" => $data[self::$indexesForLocales[$locale][0]],
        "country" => $data[self::$indexesForLocales[$locale][1]],
        "lat" => str_replace(',', '.', $data[3]),
        "lng" => str_replace(',', '.', $data[4])
      );

      return $result;
    }
     
    return null;
  }

  private static function initGeoIP() {
     
//    {
      if (self::$haveCngeoip === null) {
        $cngeoip_dir = dirname(__FILE__) . "/cngeoip";

//        if (file_exists($cngeoip_dir)) {
          self::$haveCngeoip = true;

          if (!include_once($cngeoip_dir . "/geobaza.php")) {
            self::$haveCngeoip = false;
          }

          self::$cnGeo = new Geobaza(GEODB_DIR . '/geobaza.dat');
        } else {
          self::$haveCngeoip = false;
        }
//      }
//    }
  }
}

?>
