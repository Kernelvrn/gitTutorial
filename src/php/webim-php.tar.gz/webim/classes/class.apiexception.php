<?php
class APIException extends Exception {

}
?>