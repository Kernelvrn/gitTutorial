<?php
require_once(dirname(__FILE__) . '/idna_convert.class.php');


class Helper {
    const URL_PATTERN = '[-\w\d+&@#\/%?=~_|!:,.;\[\]]+';

    public static function getParam($name, $regex = null, $defaultValue = null) {
        if (empty($_REQUEST[$name])) {
            return $defaultValue;
        }
        return Helper::getMandatoryParam($name, $regex);
    }

    public static function getMandatoryAccountParam() {
      return self::getMandatoryParam('accountname', '[\d\w]+');
    }


    public static function getMandatoryParam($name, $regex = null) {
        $value = "";
        if (isset($_REQUEST[$name])) {
            $value = trim($_REQUEST[$name]);
        } else {
            throw new Exception("no " . $name . " parameter");
        }

        if ($regex !== null) {
            if (!preg_match('/^' . $regex . '$/', $value)) {
                @mail(SERVICE_NOTIF_EMAIL, 'param doesnt match', 'param ' . $name . ' doesnt match regex ' . $regex . ' ' . getDebugInfoArrayAsString());
                throw new Exception($value . " doesn't match " . $regex);
            }
        }
        return $value;
    }

    public static function getField($key, array $arr, $default = NULL) {
        return array_key_exists($key, $arr) ? $arr[$key] : $default;
    }

    public static function getCheckboxValue($name) {
        return isset($_REQUEST[$name]) && $_REQUEST[$name] == "on";
    }

    public static function getAuthCRC($userAgent, $md5password) {
        $userAgent = preg_replace('/MSIE\s*[\.\d]+/', 'MSIE', $userAgent);
        $res = md5($userAgent . '|' . $md5password . '|' . AUTH_TOKEN_SALT);
        if (isMyIP()) {
            $res = $userAgent . '|' . $md5password . '|' . AUTH_TOKEN_SALT;
        }
        return $res;
    }

    public static function getCurrentSessionId() {
        $token = isset($_COOKIE[COOKIE_AUTH_TOKEN]) ? $_COOKIE[COOKIE_AUTH_TOKEN] : null;
        if (empty($token)) {
            return null;
        }
        $cookie = base64_decode($token);
        list ($operatorId, $sessionId) = explode('|', $cookie);
        return $sessionId;
    }

    public static function getCookieOperatorSessionFileName(&$operatorId = null, $token = null) {
        if ($token === null) {
            $token = isset($_COOKIE[COOKIE_AUTH_TOKEN]) ? $_COOKIE[COOKIE_AUTH_TOKEN] : null;
        }
        if (empty($token)) {
            return null;
        }
        $cookie = base64_decode($token);
        list ($operatorId, $sessionId) = explode('|', $cookie);

        return self::getSessionFileName($operatorId, $sessionId);
    }


    public static function checkIPinList($ip, $ipList) {
        $currentIP = ip2long($ip);
        $allowedIPs = array();
        $allowedRanges = array();
        $data = explode(',', $ipList);
        foreach ($data as $val) {
            $val = trim($val);
            $r = explode('-', $val);
            if (count($r) == 2) {
                $r[0] = trim($r[0]);
                $r[1] = trim($r[1]);
                $allowedRanges[] = array(ip2long($r[0]), ip2long($r[1]));
            } else {
                $allowedIPs[] = ip2long($val);
            }
        }
        if (in_array($currentIP, $allowedIPs)) {
            return true;
        } else {
            foreach ($allowedRanges as $range) {
                if (($currentIP >= $range[0]) && ($currentIP <= $range[1])) {
                    return true;
                }
            }
        }
        return false;
    }

    public static function getRemoteAccountSettings($account) {
        $localAccountInfo = self::getRemoteAccountInfo($account);
        return $localAccountInfo['settings'];
    }

    public static function getServiceURL($accountName = null, $user = null, $password = null, $isOldSchool = true, $partner = null) {
        $auth = $user !== null ? ($user . ':' . $password . '@') : '';
        if ($isOldSchool === null) {
          $isOldSchool = false;
        }
        global $MAIN_SETTINGS;

        $url = self::getServiceDomain($accountName, $isOldSchool, $partner);

        return ($isOldSchool ? 'http://' : Helper::getServerProtocol()) . $auth . $url;
    }

    public static function getServiceDomain($accountName = null, $isOldSchool = false, $partner = null) {
        if (isHostedMode()) {
            global $MAIN_SETTINGS;
            return $MAIN_SETTINGS['base_domain'];
        }
        if ($accountName === null) {
            $accountName = getAccountId();
        }
        return $accountName . '.' . ($isOldSchool ? 'pro-service.' : '') . self::getRootDomain($accountName, $partner);
    }

    public static function getProServiceDomain() {
        $proServiceSuffix = stristr($_SERVER['HTTP_HOST'], '.pro-service.') ? 'pro-service.' : '';
        return $proServiceSuffix . Helper::getRootDomain();
    }

    public static function getSessionFileName($operatorId, $sessionId) {
        if (!preg_match('/^[\w\d-]+$/', $operatorId . $sessionId)) {
            return null;
        }
        return LOGGED_OPERATORS_DIR . '/' . $operatorId . '-' . $sessionId . '.txt';
    }

    public static function clearOperatorSessions($operatorId) {
        if (!preg_match('/^\d+$/', $operatorId)) {
            throw new Exception("could not delete operator $operatorId");
        }
        $cmd = "rm " . LOGGED_OPERATORS_DIR . "/" . $operatorId . '-*.txt';
        `$cmd`;
    }

    public static function isEmailValid($email) {
        return preg_match("/^[^@]+@[^\.]+(\.[^\.]+)*$/", $email);
    }

    public static function getServerProtocol() {
        return self::isHttp() ? 'http://' : 'https://';
    }

  public static function isDomainHttpsEnabled($domain = null) {
    if ($domain === null) {
      $domain = Helper::getRootDomain();
    }
    global $MAIN_SETTINGS;
    $domains = isset($MAIN_SETTINGS['https_domains']) ? $MAIN_SETTINGS['https_domains'] : array('webim.ru', 'webim.my', 'i-services.ru');
    return in_array($domain, $domains);
  }


  public static function getRootDomain($accountName = null, $partner = null) {
        if (isHostedMode()) {
          global $MAIN_SETTINGS;
          return $MAIN_SETTINGS['base_domain'];
        }

        if ($partner === null) {
            if (getBrandPartner() !== null) {
                $partner = getBrandPartner();
            } else {
                if ($accountName === null) {
                    $accountName = getAccountId();
                }
                $a = Account::getInstance()->getAccountByName($accountName);
                $partner = $a['partner'];
            }
        }
        $result = null;
        if ($partner !== null) {
            $partner2domain = array(
              'webim2' => 'webim2.ru',
              'marvabru' => 'marva-b.ru',
              'v2chat' => 'v2chat.net',
              'v2chatnet' => 'v2chat.net',
              'v2chatcom' => 'v2chat.net',
              'site52ru' => 'site52.ru',
              'myinfsru' => 'myinfs.ru',
              'callrfru' => 'callrf.ru',
              'infotellchatru' => 'infotell-chat.ru',
              'onlineprositeru' => 'online-prosite.ru',
            );
            if (isset($partner2domain[$partner])) {
                $result = $partner2domain[$partner];
            } else {
                $result = !isDevMode() ? 'webim.ru' : 'webimdev.ru';
            }
        }

        if ($result !== null) {
            return $result;
        }
        if (!preg_match('/([^\.]+\.[^\.]+)$/', $_SERVER['HTTP_HOST'], $matches)) {
            throw new Exception("Could not find root domain: " . $_SERVER['HTTP_HOST']);
        }
        return $matches[1];
    }

    public static function getServerRootURL($public = false) {
        $host = $_SERVER['HTTP_HOST'];
        if (isHostedMode()) {
            global $MAIN_SETTINGS;
            $host = $public ? 
                (!empty($MAIN_SETTINGS['public_domain']) ?
                    $MAIN_SETTINGS['public_domain'] : 
                    $MAIN_SETTINGS['base_domain']
                ) : 
                $MAIN_SETTINGS['base_domain'];
        }
        return self::getServerProtocol() . $host;
    }

    public static function getPasswordForCookie($password) {
        return md5($password . COOKIE_SALT);
    }

    public static function getRedir() {
        return $_SERVER['PHP_SELF'] . (empty($_SERVER['QUERY_STRING']) ? '' : "?" . $_SERVER['QUERY_STRING']);
    }

    public static function getCurrentRoles() {
        return Helper::getRolesForAccount(getAccountId());
    }

    public static function checkIfOptionRestricted($option) {
        $res = false;
        $restrictedOptions = Settings::Get('restricted_options');
        if (empty($restrictedOptions)) {
            return false;
        }
        $operatorRoles = self::getCurrentRoles();
        foreach ($restrictedOptions as $role => $options) {
            if (in_array($role, $operatorRoles) && in_array($option, $options)) {
                $res = true;
            }
        }
        return $res;
    }

    public static function checkPageIfCurrentUserCanBeHereOrRedirect($option, $roles) {
        $mustRedirect = false;
        if (!Operator::getInstance()->silentGetCurrentOperator()
            || Helper::checkIfOptionRestricted($option)) {
            $mustRedirect = true;
        } else {
            $operatorRoles = self::getCurrentRoles();
            $roles = is_array($roles) ? $roles : array($roles);

            if (!is_array($operatorRoles) || !array_intersect($roles, $operatorRoles)) {
                $mustRedirect = true;
            }
        }

        if ($mustRedirect) {
            Operator::getInstance()->loginRedirect(true);
            die();
        }
    }


    public static function getRolesForAccount($accountName) {
        if (!isset($_SESSION[SESSION_ROLES]) || !isset($_SESSION[SESSION_ROLES][$accountName])) {
            return null;
        }

        return empty($_SESSION[SESSION_ROLES][$accountName]) ? null : $_SESSION[SESSION_ROLES][$accountName];
    }

    public static function getUrlParams() {
        return empty($_SERVER['QUERY_STRING']) ? '' : '?' . $_SERVER['QUERY_STRING'];
    }

    public static function getFirstAvailableAccountName() {
        if (!isset($_SESSION[SESSION_ROLES])) {
            return null;
        }

        $roles = $_SESSION[SESSION_ROLES];
        if (!empty($roles)) {
            $arr = array_keys($roles);
            return array_shift($arr);
        }
        return null;
    }

    public static function getRealIP($ip) {
        $ips = explode(',', $ip);
        return trim($ips[count($ips) - 1]);
    }

    public static function getRemoteAddress() {
        if (!isset($_SERVER['REMOTE_ADDR'])) {
            return null;
        }
        $ip = $_SERVER['REMOTE_ADDR'];
        return $ip;
    }

    public static function fixVisitedPageURL($url) {
        if (preg_match('/^http/', $url)) {
            return $url;
        }
        $domain = Settings::Get('hosturl');
        if ($domain !== null) {
            if (preg_match('/\/$/', $domain)) {
                $domain = substr($domain, 0, strlen($domain) - 1);
            }

            return $domain . $url;
        }

        return $url;
    }

    public static function combineGetParams($params) {
        $res = '';

        foreach ($params as $p => $v) {
            if ($v !== null) {
                $res .= empty($res) ? '?' : '&';
                if ($v != '') {
                    $res .= urlencode($p) . '=' . urlencode($v);
                } else {
                    $res .= urlencode($p);
                }
            }
        }

        return $res;
    }

    public static function arrIconv($fromEncoding, $toEncoding, $var) {
        if (is_array($var)) {
            $new = array();
            foreach ($var as $k => $v) {
                $new[self::arrIconv($fromEncoding, $toEncoding, $k)] = self::arrIconv($fromEncoding, $toEncoding, $v);
            }
            $var = $new;
        } elseif (is_object($var)) {
            $vars = get_object_vars($var);
            foreach ($vars as $m => $v) {
                $var->$m = self::arrIconv($fromEncoding, $toEncoding, $v);
            }
        } elseif (is_string($var)) {
            $var = iconv($fromEncoding, $toEncoding, $var);
        }
        return $var;
    }

    public static function clearAvatarImages($operatorId) {
        $cmd = 'rm ' . READY_IMAGES_DIR . '/avatar/' . getAccountId() . '-' . $operatorId . '*.*';
        `$cmd`;
        $cmd = 'rm ' . READY_IMAGES_DIR . '/avatar/' . getAccountId() . '_' . $operatorId . '*.*';
        `$cmd`;
        $cmd = 'rm ' . dirname(__FILE__) . '/../images/avatar/' . getAccountId() . '_' . $operatorId . '.*';
        `$cmd`;
        $cmd = 'rm ' . READY_IMAGES_DIR . '/' . getAccountId() . '_' . $operatorId . '*.*';
        `$cmd`;

    }

    public static function clearDepartmentLogoImages($departmentId) {
        $cmd = 'rm ' . READY_IMAGES_DIR . '/' . getAccountId() . '_' . $departmentId . '_department_logo*.*';
        `$cmd`;
    }

    public static function getPrivateKeyForAccount($accountName) {
        $url = Helper::getServiceURL($accountName, SERVICE_USER, SERVICE_PASSWORD) . '/webim/service/get-private-key.php';
        $url = preg_replace('/^https/', 'http', $url); // TODO not a best place
        $privateKeys = @file($url, FILE_IGNORE_NEW_LINES | FILE_SKIP_EMPTY_LINES);
        return $privateKeys[0];
    }

    public static function getAccountVersion($accountName) {
        if (isHostedMode()) {
            return WEBIM_VERSION;
        }
        $verURL1 = Helper::getServiceURL($accountName, SERVICE_USER, SERVICE_PASSWORD, true) . WEBIM_ROOT . '/service/version.txt';
        $verURL2 = Helper::getServiceURL($accountName, SERVICE_USER, SERVICE_PASSWORD, true) . WEBIM_ROOT . '/service/get-version.php';
        foreach (array($verURL1, $verURL2) as $url) {
            $url = preg_replace('/^https:/', 'http:', $url);
            $res = @file_get_contents($url);
            if (!empty($res)) {
                return $res;
            }
        }
    }

    public static function getMajorVersion($version) {
        $arr1 = explode('.', $version);
        return $arr1[0];
    }

    public static function generateRandomPassword($length = 12, $chars = 'abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789') {
        return substr(str_shuffle($chars), 0, $length);
    }
    public static function enumPredefinedAnswers2($locale = null) {
        if ($locale === null) {
            $locale = Resources::getCurrentLocale();
        }
        $accountAnswers = Settings::Get('answers_' . $locale) != NULL ? self::text2Tree(Settings::Get('answers_' . $locale)) : array();
        $operator = Operator::getInstance()->silentGetCurrentOperator();
        $operatorAnswers = !empty($operator['answers']) ? self::text2Tree($operator['answers']) : array();
        $departmentsAnswers = array();

        if (!empty($operator)) {
            $departmentIds = Operator::getInstance()->enumAvailableDepartmentIdsForOperator($operator);
            if (!empty($departmentIds)) {
                $departmentAnswersRows = MapperFactory::getDepartmentLocaleMapper()->getPredefinedAnswersForDepartments($departmentIds, $locale);
                if (!empty($departmentAnswersRows)) {
                    foreach ($departmentAnswersRows as $departmentAnswersRow) {
                        $departmentAnswers = !empty($departmentAnswersRow) ? self::text2Tree($departmentAnswersRow) : array();
                        $departmentsAnswers = array_merge($departmentsAnswers, $departmentAnswers);
                    }
                }
            }
        }
        return array_merge($operatorAnswers, $departmentsAnswers, $accountAnswers);
    }

    public static function enumPredefinedAnswers($locale = null) {
        if ($locale === null) {
            $locale = Resources::getCurrentLocale();
        }

        $a = Settings::Get('answers');
        $accountAnswers = $a && isset($a[$locale]) ? $a[$locale] : array();

        $operator = Operator::getInstance()->silentGetCurrentOperator();
        $operatorAnswers = Operator::getInstance()->getPredefinedAnswersByLocale($operator['operatorid'], $locale);

        $departmentsAnswers = array();

        if (!empty($operator)) {
            $departments = Operator::getInstance()->enumAvailableDepartmentsForOperator($operator['operatorid']);
            if (!empty($departments)) {
                foreach ($departments as $dep) {
                    $depAnwers = Settings::Get('answers', FALSE, $dep['departmentid']) ?  Settings::Get('answers', FALSE, $dep['departmentid']) : array();
                    $depLocaleAnswers = $depAnwers && isset($depAnwers[$locale]) ? $depAnwers[$locale] : array();
                    $departmentsAnswers = array_merge($departmentsAnswers, $depLocaleAnswers);
                }
            }
        }
        $newAnswers = array_merge($operatorAnswers, $departmentsAnswers, $accountAnswers);
        $oldAnswers = array();

        foreach ($newAnswers as $answer) {
            array_push($oldAnswers, array("name" => $answer['text']));
        }

        return $oldAnswers;
    }

    public static function getPredefinedAnswers($locale = null) {
        if ($locale === null) {
            $locale = Resources::getCurrentLocale();
        }

        $res = array('account' => array(), 'operator' => array(), 'departments' => array());

        $res['account'] = Settings::Get('answers') ? Settings::Get('answers') : array();

        $operator = Operator::getInstance()->silentGetCurrentOperator();
        $res['operator'] = Operator::getInstance()->getPredefinedAnswers($operator['operatorid']);

        $departmentsAnswers = array();
        if (!empty($operator)) {
            $departments = Operator::getInstance()->enumAvailableDepartmentsForOperator($operator['operatorid']);
            if (!empty($departments)) {
                foreach($departments as $dep) {
                    $departmentsAnswers[$dep['departmentkey']] = Settings::Get('answers', FALSE, $dep['departmentid']) ?  Settings::Get('answers', FALSE, $dep['departmentid']) : array();
                }
            }
        }
        $res['departments'] = $departmentsAnswers;

        return $res;
    }

    public static function formatPredefinedAnswersToJSON () {
        $locales = Resources::getAvailableLocales();
        $formattedAccountAnswers = array();
        $depConfigs = array();

        $departments = MapperFactory::getDepartmentMapper()->getDepartments();
        foreach ($departments as $dep) {
            $depConfigs[$dep['departmentid']] = $dep['config'] ? json_decode($dep['config'], true) : array();
            if (isset($depConfigs[$dep['departmentid']]['answers'])) {
                $depConfigs[$dep['departmentid']]['answers'] = array();
            }
        }

        foreach ($locales as $locale) {
            $accountAnswers = Settings::Get('answers_' . $locale);
            $accountLocaleAnswers = self::text2Tree($accountAnswers);
            $formattedAccountAnswers[$locale] = self::answersToArray($accountLocaleAnswers);

            $departments = MapperFactory::getDepartmentMapper()->getDepartmentsOrderedByName($locale);
            foreach ($departments as $dep) {
                $depAnswers = $dep['answers'] ? self::answersToArray(self::text2Tree($dep['answers'])) : array();
                $depConfigs[$dep['departmentid']]['answers'][$locale] = $depAnswers;
            }

        }

        foreach ($depConfigs as $depId => $config) {
            $config['answers'] = json_encode($config['answers']);
            MapperFactory::getDepartmentMapper()->save(array('departmentid' => $depId, 'config' => json_encode($config)));
        }

        Settings::Set('answers', $formattedAccountAnswers);

        $operatorIdRows = MapperFactory::getOperatorAccountViewMapper()->makeSearch('accountname=?', getAccountId(), 'operatorid');
        foreach ($operatorIdRows as $operatorIdRow) {
            $r = array();
            $operator = Operator::getInstance()->getOperatorById($operatorIdRow['operatorid']);
            $formattedAnswers = self::answersToArray($operator['answers'] ? self::text2Tree($operator['answers']) : array());

            $r['ru'] = $formattedAnswers;

            $operatorConfig = $operator['config'] ? json_decode($operator['config'], true) : array();
            $operatorConfig['answers'] = $r;
            $operator['config'] = json_encode($operatorConfig);
            Operator::getInstance()->UpdateOperator($operator['operatorid'], array('config' => json_encode($operatorConfig)));
        }

        KeyValueCache::clearKind('operators');
        KeyValueCache::clearKind('getOperatorById');
    }

    public static function answersToArray($answers) {
        $r = array();
        foreach ($answers as $answer) {
            if (!empty($answer['name'])) {
                if (isset($answer['children'])) {
                    foreach ($answer['children'] as $subanswer) {
                        $r[] = self::formatAnswer($subanswer, $answer['name']);
                    }
                } else {
                    $r[] = self::formatAnswer($answer);
                }
            }
        }
        return $r;
    }

    public static function formatAnswer ($answer, $section = '') {
        $answer = explode('|', $answer['name'], 2);
        if (count($answer) == 1) {
            $a = array('name' => '', 'text' => $answer[0], 'section' => $section);
        } else {
            $a = array('name' => $answer[0], 'text' => $answer[1], 'section' => $section);
        }

        return $a;
    }


    public static function getDateFormat($targetFunc = 'date') {
        $formats = array(
            'ru' => array(
                'date' => 'd.m.Y',
                'strftime' => '%d.%m.%Y',
                'js' => 'DD.MM.YYYY'
            ),
            'en' => array(
                'date' => 'm/d/Y',
                'strftime' => '%m/%d/%Y',
                'js' => 'MM/DD/YYYY'
            ),
            'ua' => array(
                'date' => 'd.m.Y',
                'strftime' => '%d.%m.%Y',
                'js' => 'DD.MM.YYYY'
            )
        );
        $lang = Resources::getCurrentLocale();
        if (empty($formats[$lang])) {
            $lang = DEFAULT_LOCALE;
        }
        return $formats[$lang][$targetFunc];
    }

    public static function getDateTimeFormat($targetFunc = 'date') {
        $formats = array(
            'ru' => array(
                'date' => 'd.m.Y H:i',
                'strftime' => '%d.%m.%Y %H:%M'
            ),
            'en' => array(
                'date' => 'm/d/Y H:i',
                'strftime' => '%m/%d/%Y %H:%M'
            ),
            'ua' => array(
                'date' => 'd.m.Y H:i',
                'strftime' => '%d.%m.%Y %H:%M'
            )
        );
        $lang = Resources::getCurrentLocale();
        if (empty($formats[$lang])) {
            $lang = DEFAULT_LOCALE;
        }
        return $formats[$lang][$targetFunc];
    }

    public static function getTimeFormat($targetFunc = 'date') {
        $formats = array(
            'date' => 'H:i',
            'strftime' => '%H:%M'
        );

        return $formats[$targetFunc];
    }

    public static function ensureAuthTokenIsRemovedFromMainServer($token) {
        if (getAccountId() === null) {
            return;
        }
//        return; //debug
        $domain = (Helper::isDomainHttpsEnabled() ? "https" : "http" ) . "://login." . Helper::getRootDomain();

        $url = $domain . '/webim/api/logout.php?token=' . urlencode($token);
        $remoteServerResponse = @file_get_contents($url);
    }

    public static function goToPythonForJson($pythonURL, $cookie = null) {
        $ch = curl_init();
        curl_setopt($ch, CURLOPT_URL, $pythonURL);
        curl_setopt($ch, CURLOPT_FAILONERROR, 1);
        curl_setopt($ch, CURLOPT_FOLLOWLOCATION, 1); // allow redirects
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1); // return into a variable
        curl_setopt($ch, CURLOPT_TIMEOUT, 60); // times out after 4s
        curl_setopt($ch, CURLOPT_VERBOSE, 0);
        if ($cookie !== null) {
            curl_setopt($ch, CURLOPT_COOKIE, 'WEBIM_AUTH_TOKEN=' . urlencode($cookie) . '; path:/');
        } elseif (isset($_COOKIE['WEBIM_AUTH_TOKEN'])) {
            curl_setopt($ch, CURLOPT_COOKIE, 'WEBIM_AUTH_TOKEN=' . urlencode($_COOKIE['WEBIM_AUTH_TOKEN']) . '; path=/');
        }
        $r = curl_exec($ch);
        doMyLog(print_r($ch, true));
        doMyLog("Result: ");
        doMyLog($r);
        curl_close($ch);
        $reply = json_decode($r, true);
        return $reply;
    }

    /**
     * Convert text to 2-levels tree. Example
     * Text:
     * "First
     *   First1
     *   First2
     * Second"
     * to
     * array(
     *   array(
     *     'name' => 'First'
     *     'children' => array(
     *       array('name' => 'First1'),
     *       array('name' => 'First2')
     *     )
     *   ),
     *   array('name' => 'Second')
     * )
     * @param $text
     * @return array
     */
    public static function text2Tree($text) {
        $tree = array();
        $lines = explode(PHP_EOL, trim($text));
        if (!empty($lines)) {
            $curNode = array(
                'name' => trim(array_shift($lines))
            );

            foreach ($lines as $line) {
                if (preg_match('/^\s/', $line)) {
                    $curNode['children'][] = array(
                        'name' => trim($line)
                    );
                } else {
                    $tree[] = $curNode;
                    $curNode = array(
                        'name' => trim($line)
                    );
                }
            }
            $tree[] = $curNode;
        }
        return $tree;
    }

    /**
     * Return column by name from 2-demensional array
     * @param array $arr
     * @param $columnName
     * @return array
     */
    public static function getColumnFromArray(array $arr, $columnName) {
        $column = array();
        foreach ($arr as $row) {
            if (array_key_exists($columnName, $row)) {
                $column[] = $row[$columnName];
            }
        }
        return $column;
    }

    public static function groupArrayByColumn(array $arr, $columnName) {
        $result = array();
        foreach ($arr as $row) {
            if (array_key_exists($columnName, $row)) {
                $result[$row[$columnName]][] = $row;
            }
        }

        return $result;
    }

    /**
     * Remove value from array (work for multidimensional)
     *
     * @param $removeValues
     * @param array $arr
     * @return array
     */
    public static function removeValueFromArray($removeValues, array $arr) {
        if (!is_array($removeValues)) {
            $removeValues = array($removeValues);
        }
        $result = array();
        foreach ($arr as $key => $value) {
            if (is_array($value)) {
                $result[$key] = self::removeValueFromArray($removeValues, $value);
            } elseif (!in_array($value, $removeValues)) {
                $result[$key] = $value;
            }
        }

        return $result;
    }

    /**
     * Fill not exists columns in two-dimensional array by value
     * @param array $arr
     * @param array $columns Checked columns
     * @param null $value
     * @return array
     */
    public static function fillNotSetColumnsInArray(array $arr, array $columns, $value = NULL) {
        foreach ($arr as &$row) {
            foreach ($columns as $columnName) {
                if (!array_key_exists($columnName, $row)) {
                    $row[$columnName] = NULL;
                }
            }
        }

        return $arr;
    }

    /**
     * Create new array from source use one column as keys
     * @param array $arr
     * @param $columnName
     * @return array
     */
    public static function arrayColumnToKeys(array $arr, $columnName) {
        $result = array();
        foreach ($arr as $row) {
            if (array_key_exists($columnName, $row)) {
                $result[$row[$columnName]] = $row;
            }
        }
        return $result;
    }

    /**
     * Alternative array_splice with trying to preserve keys from additional array/
     * @param array $targetArr
     * @param int $offset
     * @param int $length
     * @param $addArr
     * @return array
     */
    public static function arraySpliceWithKeysPreserve(array &$targetArr, $offset = 0, $length = 0, $addArr) {
        $addArr = is_array($addArr) ? $addArr : array($addArr);
        $newTarget = array();
        $result = array();

        $i = 0;
        reset($targetArr);
        while ($i < $offset && list($key, $value) = each($targetArr)) {
            $newTarget[$key] = $value;
            $i++;
        }

        foreach ($addArr as $key => $value) {
            $newTarget[$key] = $value;
        }

        if (!empty($length) && $length > 0) {
            $i = 0;
            while ($i < $length && list($key, $value) = each($targetArr)) {
                $result[$key] = $value;
                $i++;
            }
        }

        while (list($key, $value) = each($targetArr)) {
            $newTarget[$key] = $value;
        }

        $targetArr = $newTarget;

        return $result;
    }

    public static function getServerDomainByNumber($i) {
        return self::getServerSubdomainByNumber($i) . '.webim.ru';
    }

    /**
     * @param $i
     * @param $MAIN_SETTINGS
     * @return string
     */
    public static function getServerSubdomainByNumber($i) {
        global $MAIN_SETTINGS;
        return substr(md5($MAIN_SETTINGS['server_number_salt'] . $i), 0, 6);
    }

    public static function setupBrandPartnerFromAccountPartner() { // TODO very hard code
        $a = Account::getInstance()->getAccountByName(getAccountId());
        if ($a !== null) {
            $partner = $a['partner'];
            if ($partner === 'v2chatcom') {
                $_SERVER['X_BRAND_PARTNER'] = 'v2chat';
            } elseif ($partner === 'sait52ru') {
                $_SERVER['X_BRAND_PARTNER'] = 'sait52ru';
            } elseif ($partner === 'myinfsru') {
                $_SERVER['X_BRAND_PARTNER'] = 'myinfsru';
            } elseif ($partner === 'callrfru') { // beeper
                $_SERVER['X_BRAND_PARTNER'] = 'callrfru';
            } elseif ($partner === 'infotellchatru') { // infotell
                $_SERVER['X_BRAND_PARTNER'] = 'infotellchatru';
            } elseif ($partner === 'online-prosite.ru') {
                $_SERVER['X_BRAND_PARTNER'] = 'onlineprositeru';
            }
        }
    }

    /**
     * Explode string and trim all elements
     * @param $delimiter
     * @param $str
     * @return array
     */
    public static function trimExplode($delimiter, $str) {
        return array_map('trim', explode($delimiter, $str));
    }

    /**
     * Check param as valid timezone id
     * @param $tzid
     * @return bool
     */
    public static function isValidTimezoneId($tzid) {
        $valid = DateTimeZone::listIdentifiers();
        return in_array($tzid, $valid);
    }

    /**
     * Format date with current account timezone.
     * @param string $format
     * @param int $timestamp timestamp
     * @return string
     */
    public static function accountStrftime($timestamp = NULL, $format = NULL) {
        $datetime = self::getAccountDateTime($timestamp);
        $defaultTimeZone = new DateTimeZone(date_default_timezone_get());
        if (!isset($format)) {
            $format = self::getDateTimeFormat('strftime');
        }
        return strftime($format, $datetime->getTimestamp() + $datetime->getOffset() - $defaultTimeZone->getOffset($datetime));
    }

    /**
     * Return rows by value one of columns from 2-demensional array
     * @param array $arr
     * @param $columnName
     * @param $columnValue
     * @return array
     */
    public static function getRowsByColumnValue(array $arr, $columnName, $columnValue) {
        $result = array();
        foreach ($arr as $row) {
            if (isset($row[$columnName]) && $row[$columnName] === $columnValue) {
                $result[] = $row;
            }
        }
        return $result;
    }

    /**
     * Get web page by url via cURL
     * @param $url
     * @return string
     */
    public static function getWebPage($url) {
        $ch = curl_init($url);
        $cookie = tmpfile();
        $options = array(
            CURLOPT_AUTOREFERER => TRUE,
            CURLOPT_FOLLOWLOCATION => TRUE,
            CURLOPT_MAXREDIRS => 10,
            CURLOPT_RETURNTRANSFER => TRUE,
            CURLOPT_TIMEOUT => 30,
            CURLOPT_COOKIEFILE => $cookie,
            CURLOPT_COOKIEJAR => $cookie,
            CURLOPT_USERAGENT => 'Mozilla/5.0 (Windows NT 6.2; WOW64) AppleWebKit/537.31 (KHTML, like Gecko) Chrome/26.0.1410.64 Safari/537.31'
        );
        curl_setopt_array($ch, $options);

        $output = curl_exec($ch);
        $error = curl_error($ch);
        curl_close($ch);
        if (!empty($error)) {
            doMyLog('Error while getting web-page by url:' . $url . PHP_EOL . $error);
        }
        return $output;
    }

    public static function makeSiteScreenshot() {
        $imageName = FilesLocation::getAccountSitePreviewPath() . '/' . getAccountId() . '_site_preview.png';

        if (file_exists($imageName) && time() - filemtime($imageName) < 60*60*24*7 && !isDevMode()) {
            return;
        }

        $phantomjs = '/usr/bin/phantomjs  --ssl-protocol=any --ignore-ssl-errors=yes ' . dirname(__FILE__) . '/../js/phantomjs/rasterize.js';

        $site = Settings::getInstance()->Get('hosturl');
//        $site = idn_to_ascii($site);

        $IDN = new idna_convert(array('idn_version' => 2003));
        $site = $IDN->encode($site);
//        if (isMyIP()) {
//            var_dump($site);
//            die();
//        }

        $site = preg_replace('/[^A-Za-z0-9:\/\.-]/', '', $site);
//        $site = 'http://ya.ru';
        $cmd = "$phantomjs  $site $imageName '1024*1024px'";
        doMyLog("Making preview $cmd");
//        die($cmd);
        $res = shell_exec($cmd);
    }

    /**
     * Get value in associative tree.
     * @param array $path array('a', 'a', 'c')
     * @param $arr      array(a => array(a => array(c => 'value')))
     * @param $default
     * @return          'value'
     */
    public static function getValueFromArrayByPath(array $path, $arr, $default = NULL) {
        $pathPart = array_shift($path);
        if (!empty($path) && is_array($arr) && array_key_exists($pathPart, $arr)) {
            return self::getValueFromArrayByPath($path, $arr[$pathPart]);
        }

        return is_array($arr) && array_key_exists($pathPart, $arr) ? $arr[$pathPart] : $default;
    }

    /**
     * Set value in tree
     * @param $value        'value'
     * @param array $path   array('a', 'a', 'c')
     * @param array $arr    array(a => array(b => '')) -> array(a => array(a => array('c' => 'value'), b => ''))
     */
    public static function setValueToArrayByPath($value, array $path, array &$arr) {
        $pathPart = array_shift($path);
        if (!empty($path)) {
            if (empty($arr[$pathPart]) || !is_array($arr[$pathPart])) {
                $arr[$pathPart] = array();
            }
            self::setValueToArrayByPath($value, $path, $arr[$pathPart]);
        } else {
            $arr[$pathPart] = $value;
        }
    }

    /**
     * Check that path exists in tree
     * @param array $path       array('a', 'a', 'c')
     * @param $arr              array(a => array(b => ''))
     * @return bool             FALSE
     */
    public static function arrayKeyExistsByPath(array $path, $arr) {
        $pathPart = array_shift($path);
        if (!empty($path) && is_array($arr) && array_key_exists($pathPart, $arr)) {
            return self::arrayKeyExistsByPath($path, $arr[$pathPart]);
        }

        return is_array($arr) && array_key_exists($pathPart, $arr);
    }


    /**
     * Sort two demensional array by fields (like order by in sql)
     * @param array $arr
     * @param string|array $keys
     * @param int $order
     * @return bool
     */
    public static function sortTwoDimensionalArray(array &$arr, $keys, $order = SORT_ASC) {
        return usort($arr, function($a, $b) use($keys, $order) {
            if (!is_array($keys)) {
                $keys = array($keys);
            }
            if ($order == SORT_ASC) {
                $first = $a;
                $second = $b;
            } else {
                $first = $b;
                $second = $a;
            }

            foreach ($keys as $key) {
                $subKeys = explode('.', $key);
                $subFirst = $first;
                $subSecond = $second;
                $lastSubKey = array_pop($subKeys);

                foreach($subKeys as $subKey) {
                    if (!isset($subFirst[$subKey])) {
                        return 1;
                    }
                    $subFirst = $subFirst[$subKey];

                    if (!isset($subSecond[$subKey])) {
                        return -1;
                    }
                    $subSecond = $subSecond[$subKey];
                }

                if (!isset($subFirst[$lastSubKey])) {
                    return 1;
                }

                if (!isset($subSecond[$lastSubKey])) {
                    return -1;
                }

                if ($subFirst[$lastSubKey] == $subSecond[$lastSubKey]) {
                    continue;
                }

                return $subFirst[$lastSubKey] > $subSecond[$lastSubKey] ? 1 : -1;
            }
        });
    }

    public static function sortArrayByArray(array $array, array $orderArray, $default = null) {
        $ordered = array();
        foreach($orderArray as $key) {
            $ordered[$key] = array_key_exists($key, $array) ? $array[$key] : $default;
        }
        return $ordered;
    }

    public static function arrayRecursiveDiff($aArray1, $aArray2) {
        $aReturn = array();
        foreach ($aArray1 as $mKey => $mValue) {
            if (array_key_exists($mKey, $aArray2)) {
                if (is_array($mValue)) {
                    $aRecursiveDiff = self::arrayRecursiveDiff($mValue, $aArray2[$mKey]);
                    if (count($aRecursiveDiff)) { $aReturn[$mKey] = $aRecursiveDiff; }
                } else {
                    if ($mValue != $aArray2[$mKey]) {
                        $aReturn[$mKey]['old'] = $mValue;
                        $aReturn[$mKey]['new'] = $aArray2[$mKey];
                    }
                }
            } else {
                $aReturn[$mKey] = $mValue;
            }
        }
        return $aReturn;
    }

    private static $currentAccountTimezone = NULL;
    /**
     * Возвращает DateTime объект с временной зоной в соответствии с настройками аккаунта
     * @param $timestamp int|float|DateTime|null
     * @return DateTime
     * @throws Exception На некорректный тип $timestamp
     */
    public static function getAccountDateTime($timestamp) {
        $datetime = self::makeDateTime($timestamp);
        if (empty(self::$currentAccountTimezone)) {
            $account = Account::getInstance()->getCurrentAccount();
            $timezone = !empty($account['timezone']) ? $account['timezone'] : DEFAULT_TIMEZONE_ID;
            self::$currentAccountTimezone = new DateTimeZone($timezone);
        }
        $datetime->setTimezone(self::$currentAccountTimezone);

        return $datetime;
    }

    /**
     * @param int|float|string|DateTime $timestamp
     * @return DateTime
     */
    public static function makeDateTime($timestamp) {
        if (empty($timestamp)) {
            $timestamp = microtime(true);
        } elseif (is_numeric($timestamp)) {
            $timestamp += 0; //Приводим строку к числу
        }


        if (is_int($timestamp)) {
            $datetime = DateTime::createFromFormat('U', $timestamp);
        } elseif (is_float($timestamp)) {
            $datetime = DateTime::createFromFormat('U.u', sprintf('%.6F', $timestamp));
        } elseif ($timestamp instanceof DateTime) {
            $datetime = clone $timestamp;
        } elseif (is_string($timestamp)) {
            $datetime = new DateTime($timestamp);
        } else {
            throw new InvalidArgumentException('Invalid parameter for DateTime: ' . $timestamp);
        }

        return $datetime;
    }

  /**
   * @return bool
   */
  public static function isHttp() {
    return empty($_SERVER['HTTPS']);
  }

  public static function checkOriginAndReferrer() {
    // TODO fix after WEBIM_ROOT fix
    if (isset($_SERVER['HTTP_ORIGIN'])) {
        return in_array(strpos($_SERVER['HTTP_ORIGIN'], self::getServiceDomain()), array(7, 8));
    } else if (isset($_SERVER['HTTP_REFERER'])) {
        return in_array(strpos($_SERVER['HTTP_REFERER'], self::getServiceDomain() . '/'), array(7, 8));
    } else {
        return FALSE;
    }
  }

  /**
   * @param $accountName
   * @return array|string
   * @throws Exception
   */
  public static function getRemoteAccountInfo($accountName) {
      if (isHostedMode() && getAccountId() !== null) {
          return self::getLocalAccountInfo();
      }
      $url = Helper::getServiceURL($accountName, SERVICE_USER, SERVICE_PASSWORD, null) . WEBIM_ROOT . '/service/get-local-account-info.php?' . WEBIM_VERSION;

      $response = Helper::curlGet($url);
      $localAccountInfo = json_safe_decode($response);

      if ($localAccountInfo === null) {
          throw new Exception("Could not decode remote settings for: " . $url . " response: " . $response);
      }
      return $localAccountInfo;
  }

    public static function getLocalAccountInfo() {
        $localAccountInfo = array();
        $localAccountInfo['site_url'] = Settings::Get('hosturl');

        $localAccountInfo['last_period'] = MapperFactory::getOnlinePeriodMapper()->getLastPeriod();
        $localAccountInfo['last_thread'] = MapperFactory::getThreadMapper()->getLastThread();

        $localAccountInfo['letter'] = getPHPEnvLetter();

        $localAccountInfo['is_blocked'] = isAccountBlocked();

        foreach (array('strong_passwords', 'password_expiration_days', 'operator_allowed_ips', 'stats_display_only') as $param) {
          $localAccountInfo['settings'][$param] = Settings::Get($param);
        }
        return $localAccountInfo;
    }

    public static function isCookieHttps() {
        if (empty($_SERVER['HTTP_USER_AGENT'])) {
            return False;
        }
        $browser = KeyValueCache::getCachedResults($_SERVER['HTTP_USER_AGENT'], 'user-agent-get-browser', function() {
                  return get_browser(null, true);
                }, 3600 * 24 * 7, 'login'); // 3 days

        return !empty($_SERVER['HTTPS']) && $browser['platform'] != 'WinXP';
    }

    private static function strftimeToDateFormat($strftimeFormat) {
        $caracs = array(
            // Day - no strf eq : S
            '%d' => 'd', '%a' => 'D', '%e' => 'j', '%A' => 'l', '%u' => 'N', '%w' => 'w', '%j' => 'z',
            // Week - no date eq : %U, %W
            '%V' => 'W',
            // Month - no strf eq : n, t
            '%B' => 'F', '%m' => 'm', '%b' => 'M',
            // Year - no strf eq : L; no date eq : %C, %g
            '%G' => 'o', '%Y' => 'Y', '%y' => 'y',
            // Time - no strf eq : B, G, u; no date eq : %r, %R, %T, %X
            '%P' => 'a', '%p' => 'A', '%l' => 'g', '%I' => 'h', '%H' => 'H', '%M' => 'i', '%S' => 's',
            // Timezone - no strf eq : e, I, P, Z
            '%z' => 'O', '%Z' => 'T',
            // Full Date / Time - no strf eq : c, r; no date eq : %c, %D, %F, %x
            '%s' => 'U'
        );
        return strtr($strftimeFormat, $caracs);
    }

  public static function clearNginxCache($accountId = null) {
    $accountName = $accountId ?: (getAccountId() ?: 'login');
    $pathToNginxCache = isHostedMode() ? '/var/cache/webim/nginx' : '/var/cache/nginx';

    $cmd = "/usr/bin/find ". $pathToNginxCache ." | xargs grep -l " . $accountName . "|xargs rm&";
    doMyLog("Executing $cmd");
    `$cmd`;
    $cmd = "/usr/bin/find /var/cache/webim/" . $accountName . " -name \"all-settings-*\" -delete&";
    doMyLog("Executing $cmd");
    `$cmd`;
    $cmd = "/usr/bin/find /var/cache/webim/" . $accountName . "* -type f -delete&";
    doMyLog("Executing $cmd");
    `$cmd`;

  }

  public static function clearAllPythonCache() {
      if (getAccountId() === null) {
          return;
      }
      $url = Helper::getServiceURL(getAccountId(), SERVICE_USER, SERVICE_PASSWORD) . '/l/i/reset-cache?type=all';
      @file_get_contents($url);
  }

  public static function clearPythonCache() {
      $url = Helper::getServiceURL(getAccountId(), SERVICE_USER, SERVICE_PASSWORD) . '/l/i/reset-cache?type=account-settings';
      @file_get_contents($url);
  }

  public static function clearOperatorsCache() {
      $url = Helper::getServiceURL(getAccountId(), SERVICE_USER, SERVICE_PASSWORD) . '/l/i/reset-cache?type=operators';
      @file_get_contents($url);
  }

    public static function clearOperatorCache($id) {
      $url = Helper::getServiceURL(getAccountId(), SERVICE_USER, SERVICE_PASSWORD) . '/l/i/reset-cache?type=operator&id=' . $id;
      @file_get_contents($url);
  }

  public static function clearBanRecordsCache() {
      $url = Helper::getServiceURL(getAccountId(), SERVICE_USER, SERVICE_PASSWORD) . '/l/i/reset-cache?type=ban-records';
      @file_get_contents($url);
  }

  public static function clearTariffSettingsCache() {
      $url = Helper::getServiceURL(getAccountId(), SERVICE_USER, SERVICE_PASSWORD) . '/l/i/reset-cache?type=tariff-settings';
      @file_get_contents($url);
  }

    public static function clearDepartmentsCache() {
      $url = Helper::getServiceURL(getAccountId(), SERVICE_USER, SERVICE_PASSWORD) . '/l/i/reset-cache?type=departments';
      @file_get_contents($url);
  }

    public static function clearSessionSectionsCache() {
        $url = Helper::getServiceURL(getAccountId(), SERVICE_USER, SERVICE_PASSWORD) . '/l/i/reset-cache?type=session-sections';
        @file_get_contents($url);
    }

  public static function curlGet($url) {
      $result = @file_get_contents($url);
      for ($i = 0; $i < 2 && empty($result); $i++) {
          $ch = curl_init();
          curl_setopt($ch, CURLOPT_URL, $url); // set url to post to
          curl_setopt($ch, CURLOPT_FAILONERROR, 1);
          curl_setopt($ch, CURLOPT_FOLLOWLOCATION, 1); // allow redirects
          curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1); // return into a variable
          curl_setopt($ch, CURLOPT_TIMEOUT, 60);
          curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, 0);
    //      curl_setopt($ch, CURLOPT_POST, 1); // set POST method
    //      curl_setopt($ch, CURLOPT_POSTFIELDS, $post_content); // add POST fields
          $result = curl_exec($ch); // run the whole process
          curl_close($ch);
      }
      return $result;
  }
}