<?php

define('PAGINATION_SPACING', "&nbsp;&nbsp;&nbsp;");
define('LINKS_ON_PAGE', 5);

function setup_pagination($items, $default_items_per_page, $total) {
    $pagination = array();

    if (!empty($items)) {
        $items_per_page = verify_param("items", "/^\d{1,3}$/", $default_items_per_page);

        $total_pages = ceil($total * 1.0 / $items_per_page);
        $curr_page = verify_param("page", "/^\d{1,6}$/", 1);

        if ($curr_page < 1)
            $curr_page = 1;
        if ($curr_page > $total_pages)
            $curr_page = $total_pages;

        $start_index = ($curr_page - 1) * $items_per_page;
        $end_index = min($start_index + $items_per_page, $total);
        $pagination['pagination_items'] = $items;
        $pagination['pagination'] =
            array("page" => $curr_page, "items" => $items_per_page, "total" => $total_pages,
                "count" => $total, "start" => $start_index, "end" => $end_index);
    }
//    TRACEVAR('pagination', $pagination);
    return $pagination;
}

function generate_pagination_link($page, $title, $hash = '') {
    $white_params = array(
        'date_range'    => "/\d+.\d+.\d+\+\-\+\d+.\d+.\d+/",
        'operators'     => "/\w+/",
        'rate'          => "/\w+/",
        'departments'   => "/\d+|\-/",
        'locale'        => "/\w+/",
        'category'      => "/(\w+)|\-/",
        'thread_types'  => "/\w+/",
        'min_messages'  => "/\d+/",
        'q'             =>  '',
        'actions'       =>  "/\w+/",
        'statsids'      =>  '\d+|\,',
        'visitor_provided_id' => ''
    );

// Divide the URL into parts and then collect it from the parts.

    $original_url = $_SERVER['REQUEST_URI'];
    $href = explode('.php', $original_url)[0] . '.php';
    $result_params = '';

    foreach ($white_params as $key => $val) {
        if (isset($_GET[$key])) {
            $arg_val = $_GET[$key];
            if (gettype($arg_val) == 'array')
                foreach ($arg_val as $arg_val_item) {
                    $result_params .= '&' . $key . '[]=' . verify_param($arg_val_item, $val, $from = $arg_val_item);
                }
            else
                $result_params .= '&' . $key . '=' .  ($val ? verify_param($arg_val, $val, $from = $arg_val) : urlencode($arg_val));
        }
    }

    $href .=  '?page=' . $page . $result_params . (!empty($hash) ? '#' . $hash : '');

    return "<a href=\"$href\" class=\"pagelink\">$title</a>";
}

function generate_pagination($pagination, $hash = '') {
    $result = '';

    if ($pagination['total'] > 1) {
        $result .= '<nav><ul class="pagination">';
        $curr_page = $pagination['page'];

        $minPage = max($curr_page - LINKS_ON_PAGE, 1);
        $maxPage = min($curr_page + LINKS_ON_PAGE, $pagination['total']);

        $result .= '<li ' . ($curr_page <= 1 ? 'class="disabled"' : '') . '>'
            . ($curr_page > 1 ? generate_pagination_link($curr_page - 1, '<span aria-hidden="true">&laquo;</span>')
                : generate_pagination_link(1, '<span aria-hidden="true">&laquo;</span>', $hash))
         . '</li>';

        for ($i = $minPage; $i <= $maxPage; $i++) {
            $title = abs($curr_page - $i) >= LINKS_ON_PAGE && $i != 1 ? '...' : $i;
            if ($i != $curr_page) {
                $result .= '<li>' . generate_pagination_link($i, $title, $hash) . '</li>';
            } else {
                $result .= '<li class="active">' . generate_pagination_link($i, $title, $hash) . '</li>';
            }
        }

        $result .= '<li ' . ($curr_page >= $pagination['total'] ? 'class="disabled"' : '') . '>'
            . ($curr_page < $pagination['total'] ? generate_pagination_link($curr_page + 1, '<span aria-hidden="true">&raquo;</span>')
                : generate_pagination_link($pagination['total'], '<span aria-hidden="true">&raquo;</span>', $hash))
            . '</li>';

        $result .= '</ul></nav>';
    }

    $result .= Resources::Get('tag.pagination.info',
            array($pagination['page'], $pagination['total'], $pagination['start'] + 1, $pagination['end'], $pagination['count']));

    return $result;
}

?>