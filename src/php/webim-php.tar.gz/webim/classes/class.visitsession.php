<?php
require_once('common.php');

define("VISIT_SESSION_TIMEOUT", 300); // seconds

class VisitSession {
  const VISITSESSION_FILENAME_EXT = "visitsession_info";

  private static $instance = NULL;

  /**
   * @return VisitSession
   */
  static function GetInstance() {
    if (self::$instance == NULL) {
      self::$instance = new VisitSession();
    }
    return self::$instance;
  }

  private static $idToVisitSession = array();

  function GetVisitSessionById($id, $ip = null, $userAgent = null, $visitorId = null) {
    return $this->_GetVisitSessionById($id, false, $ip, $userAgent, $visitorId);
  }

  function _GetVisitSessionById($id, $returnCopy = true, $ip = null, $userAgent = null, $visitorid = null) {
    if (array_key_exists($id, self::$idToVisitSession)) {
      $result = self::$idToVisitSession[$id];
    } else {
      $result = $this->GetVisitSessionById_fromPython($id, $ip, $userAgent, $visitorid);
      if ($result === null) {
        $result = $this->GetVisitSessionById_fromFile($id);
        # TODO very hard crc and user info
        if (isset($_REQUEST['webim_visitor'])) {
          $j = json_safe_decode($_REQUEST['webim_visitor']);
          foreach (array('id', 'email', 'phone', 'name') as $f) {
            if (isset($j[$f])) {
              $result['visitorExt'][$f] = $j[$f];
            }
          }
          if (isset($j['display_name'])) {
            $result['visitorname'] = $j['name'];
          }
        }
        doMyLog("Got session from file: " . print_r($result, true));
      }
      self::$idToVisitSession[$id] = $result;
    }
    if ($returnCopy) {
      $result = array_copy($result);
    }
    return $result;
  }

  private function GetVisitSessionById_fromPython($visitsessionid, $ip, $userAgent, $visitorid) {
//    if (strstr($visitsessionid, '.')) {
      doMyLog("Getting session for id: " . $visitsessionid);
      doMyLog(print_r(debug_backtrace(true), true));
//    }
//    print_r(debug_backtrace(true));

    if (!isset($ip, $userAgent)) {
      $dir = ONLINE_FILES_DIR . '/safe-sessions';
      $b = @file_get_contents($dir . '/' . $visitsessionid . '.txt');
      if (!empty($b)) {
        $b = @unserialize($b);
        if (!empty($b) && !empty($b['server']['HTTP_USER_AGENT'])) {
          $userAgent = $b['server']['HTTP_USER_AGENT'];
          $ip = $b['server']['REMOTE_ADDR'];
        }
      }
    }
    //todo cache
    $base = Helper::getServiceURL();
    $url = "/l/i/visit-session?id=" . urlencode($visitsessionid) . (isset($ip)? '&ip='.urlencode($ip) : '') . (isset($userAgent) ? '&user-agent='.urlencode($userAgent) : '');
    $response = requestPyServerUseCache($url, $visitsessionid, 'visitsession', 30*1000, false, true);
//    $response = requestPyServer($url);

    $result = null;

    if (empty($response) && getAccountId() == 'komusru001') {
      doMyLog($response, false);
      doMyLog("Got empty response for: " . $url, false, true);
    }

    if (!empty($response)) {
      doMyLog("Got session from python: " . print_r($response, true));
      //    print $response;
      $vs_orig = json_decode($response, true);

      $vs = @Helper::arrIconv('utf-8', WEBIM_ENCODING, $vs_orig);

      if (empty($vs)) {
        if (empty($response) && getAccountId() == 'komusru001') {
          doMyLog("Got empty response after json parsing for: " . $url, false, true);
        }

        $vs = $vs_orig;
//        @mail('oleg@webim.ru', 'GetVisitSessionById_fromPython error', print_r($response, true) . " " . $base . " " . $url);
      }

      if (empty($vs)) {
        return null;
      }

      if (getAccountId() == 'komusru001' && (empty($vs['visitorExt']) || empty($vs['visitorExt']['id']))) {
        doMyLog("Got empty ['visitorExt']['id'] response after :" . $url, false, true);
        doMyLog($response);
      }


      $result = array(
        'visitsessionid' => $visitsessionid,
        'ip' => $vs['ip'],
        'remotehost' => '',
        'useragent' => $vs['userAgent'],
        'userid' => !empty($vs['visitorExt']) && !empty($vs['visitorExt']['id']) ? $vs['visitorExt']['id'] : null,
        'visitorid' => !empty($vs['visitor']['id']) ? $vs['visitor']['id'] : (!empty($visitorid) ? $visitorid : 0),
        'visitorname' => isset($vs['visitor']['name']) ? $vs['visitor']['name'] : Resources::Get("chat.default.visitorname"),
        'visitorExt' => $vs['visitorExt'],
        'created' => $vs['creationTs'],
        'updated' => $vs['lastAliveTs'],
        'partnerref' => null,
        'locale' => null, /* locale of the thread */
        'invitationid' => $vs['invitationId'],
        'hasthread' => 1,
        'savedToDB' => $vs['savedToDB'],

        'storedIn' => 'python'

         
      );
      doMyLog("Making result: " . print_r($result, true));
    } else {
      doMyLog("Getting session from backup file");

      $dir = ONLINE_FILES_DIR . '/safe-sessions';
      $b = @file_get_contents($dir . '/' . $visitsessionid . '.txt');
      $b = @unserialize($b);
      $r = $b['request'];
      $s = $b['server'];
      $c = $b['cookie'];
      $ses = isset($b['session']) ? $b['session'] : array();

      if (!empty($b)) {
        $result = array(
          'visitsessionid' => $visitsessionid,
          'ip' => $s['REMOTE_ADDR'],
          'remotehost' => '',
          'useragent' => $s['HTTP_USER_AGENT'],
          'userid' => null,
          'visitorid' => isset($c['WEBIM_VISITOR_ID']) ? $c['WEBIM_VISITOR_ID'] : (isset($ses['WEBIM_VISITOR_ID']) ? $ses['WEBIM_VISITOR_ID'] : generateVisitorId()),
          'visitorname' => '����������',
          'visitorExt' => null,
          'created' => null,
          'updated' => null,
          'partnerref' => null,
          'locale' => null, /* locale of the thread */
          'invitationid' => null,
          'hasthread' => 1,
          'savedToDB' => false,
          'storedIn' => 'python'
        );
        doMyLog("Got " . print_r($result, true));


      }
    }
    return $result;
  }

  function GetVisitSessionById_fromFile($visitsessionid) {
    $filename = self::getVisitSessionFilename($visitsessionid);

    if (!file_exists($filename)) {
      return NULL;
    }

    $data = @file_get_contents($filename);
    if ($data === false) {
      return NULL;
    }

    $result = unserialize($data);
    if ($result === false || !isset($result['visitsessionid']) || empty($result['visitsessionid'])) {
      return NULL;
    }

    $result['storedIn'] = 'file';
    return $result;
  }

  static function getVisitSessionFilename($id) {
    return TRACKER_FILES_DIR . DIRECTORY_SEPARATOR .
        substr(md5($id), 0, 1) . DIRECTORY_SEPARATOR .
        md5($id) . "." . self::VISITSESSION_FILENAME_EXT;
  }
}
