<?php
require_once(dirname(__FILE__) . '/functions.php');
require_once(dirname(__FILE__).'/../autoload.php');

class ActionLog {
    static private $instance = null;

    /**
     * @return ActionLogMapper
     */
    static private $actionLogMapper;
    static private $operatorData;

    static function getInstance() {
        if (self::$instance == null) {
            self::$instance = new ActionLog();
            self::$actionLogMapper = MapperFactory::getActionLogMapper();
        }
        return self::$instance;
    }

    private function __construct() {
      self::$operatorData = array(
        'operatorfullname' => isset($_SESSION[SESSION_OPERATOR]['fullname']) ? $_SESSION[SESSION_OPERATOR]['fullname'] : null,
        'operatorid' => isset($_SESSION[SESSION_OPERATOR]['operatorid']) ? $_SESSION[SESSION_OPERATOR]['operatorid'] : null,
        'operatorsessionid' => Helper::getCurrentSessionId(),
        'ip' => Helper::getRemoteAddress(),
        'useragent' => !empty($_SERVER['HTTP_USER_AGENT']) ? $_SERVER['HTTP_USER_AGENT'] : '' # TODO make it null
      );

    }

    private function __clone() {

    }
    private static function __isActionDoneForCurrentSession($action){
        $res = self::$actionLogMapper->makeSearch('actiontype = :action AND operatorsessionid = :sessionid', array('action'=> $action, 'sessionid'=> self::$operatorData['operatorsessionid']));
        return (!empty($res)) ? True : False;
    }


    public static function loginAction(){
        if (!getAccountId() || self::__isActionDoneForCurrentSession('login')) {
            return;
        }

        self::$actionLogMapper->save(array_merge(array(
            'actiontarget'=>'auth',
            'actiontype'=>'login',
            'dtm'=> time()
        ), self::$operatorData));
    }

    public static function storeFailedLoginAction($email, $ip) {
        $op = MapperFactory::getOperatorAccountViewMapper()->getAccountsByEmail($email);
        if (empty($op)) {
            return;
        } else {
            $op = $op[0];
        }
        if (getAccountId()) {
            ActionLog::getInstance()->loginFailed($op);
        } else {
            $url = Helper::getServiceURL($op['accountname'], SERVICE_USER, SERVICE_PASSWORD, null) . WEBIM_ROOT
                . '/service/store-failed-login-action.php?email=' . $email
                . '&ip=' . $ip
                . '&useragent=' . $_SERVER['HTTP_USER_AGENT'];

            $response = @file_get_contents($url);
        }
    }

    public static function loginFailed($operator, $ip = null, $userAgent = null){
        self::$operatorData['operatorfullname'] = $operator['fullname'];
        self::$operatorData['operatorid'] = $operator['operatorid'];
        self::$operatorData['ip'] = empty($ip) ? Helper::getRemoteAddress() : $ip;
        self::$operatorData['useragent'] = empty($userAgent) ? $_SERVER['HTTP_USER_AGENT'] : $userAgent;

        self::$actionLogMapper->save(array_merge(array(
            'actiontarget'=>'auth',
            'actiontype'=>'failed',
            'dtm'=> time()
        ), self::$operatorData));
    }


    public static function logoutAction(){
        if (!getAccountId() || self::__isActionDoneForCurrentSession('logout')) {
            return;
        }
        $data = array_merge(array(
            'actiontarget'=>'auth',
            'actiontype'=>'logout',
            'dtm'=> time()
        ), self::$operatorData);
        self::$actionLogMapper->save($data);
    }

    public static function updateAction($target, $oldValue, $newValue){
        if (array_key_exists('password', $oldValue)) {
            unset ($oldValue['password']);
        }
        if (array_key_exists('password', $newValue)) {
            unset ($newValue['password']);
        }

        $jsonOldValue = is_array($oldValue) ? json_encode_readable($oldValue) : $oldValue;
        $jsonNewValue = is_array($newValue) ? json_encode_readable($newValue) : $newValue;
        $jsonDiffValue = null;
        if ($jsonOldValue == $jsonNewValue) {
            return;
        }

        $arrayDiff = Helper::arrayRecursiveDiff($oldValue, $newValue);
        if (!empty($arrayDiff)) {
            $jsonDiffValue = json_encode_readable($arrayDiff);
        }

        self::$actionLogMapper->save(array_merge(array(
            'actiontarget'=>$target,
            'actiontype'=>'update',
            'newvalue'=>$jsonNewValue,
            'oldvalue'=>$jsonOldValue,
            'diff'=>$jsonDiffValue,
            'dtm'=> time()
        ), self::$operatorData));
    }

    public static function resetAction($target){
        self::$actionLogMapper->save(array_merge(array(
            'actiontarget'=>$target,
            'actiontype'=>'reset',
            'dtm'=> time()
        ), self::$operatorData));
    }

    public static function createAction($target, $value){
        if (array_key_exists('password', $value)) {
            unset ($value['password']);
        }
        $jsonValue = is_array($value) ? json_encode_readable($value) : $value;

        self::$actionLogMapper->save(array_merge(array(
            'actiontarget'=>$target,
            'actiontype'=>'create',
            'newvalue'=>$jsonValue,
            'dtm'=> time()
        ), self::$operatorData));
    }

    public static function deleteAction($target, $value){
        if (array_key_exists('password', $value)) {
            unset ($value['password']);
        }
        $jsonValue = is_array($value) ? json_encode_readable($value) : $value;

        self::$actionLogMapper->save(array_merge(array(
            'actiontarget'=>$target,
            'actiontype'=>'delete',
            'dtm'=> time(),
            'oldvalue'=>$jsonValue,
        ), self::$operatorData));
    }
}
