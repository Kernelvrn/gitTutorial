<?php

/**
 * All methods to access to files and directories in webim.
 */
class FilesLocation {
    const DEFAULT_DIR_MODE = 0755;

    private static $oldPaths = array(
        'operator_avatars' => '/var/www/webim_ru/login/public_html.eta/webim/images/avatar',
        'ainvite_avatars' => '/var/www/webim_ru/login/public_html.eta/webim/images/logo',
        'account_status' => '/var/pro/account-statuses',
        'logo' => '/var/www/webim_ru/login/public_html.eta/webim/images/logo',
        'preview' => '/var/www/webim_ru/login/public_html.eta/webim/images/',
        'ports' => '/etc/nginx/ports',
        'buttons' => '/var/www/webim_ru/login/public_html.eta/webim/themes/.buttons',
    );

    /**
     * Return path to avatars directory for (current) account
     * @param mixed $accountName
     * @param mixed $fileName
     * @param array|NULL $extensionsToTry
     * @return string path
     */
    public static function getAccountOperatorAvatarsPath($accountName = NULL, $fileName = NULL, $extensionsToTry = null) {
        return self::_tryFiles($accountName, $fileName, $extensionsToTry, '/images/avatars', 'operator_avatars');
    }

    private static function _tryFiles($accountName, $fileName, $extensionsToTry = null, $newDirName, $oldDirName) {
        $path = self::ensureAbsolutePathForAccountDirs($newDirName, $accountName);
        if ($extensionsToTry !== null) {
            foreach ($extensionsToTry as $ext) {
                if (file_exists($path . '/' . $fileName . '.' . $ext)) {
                    return $path;
                }
            }
            foreach ($extensionsToTry as $ext) {
                if (file_exists(self::$oldPaths[$oldDirName] . '/' . $fileName . '.' . $ext)) {
                    return self::$oldPaths[$oldDirName];
                }
            }
        } elseif ($fileName !== null) {
            $oldFileName = self::$oldPaths[$oldDirName] . '/' . $fileName;
            if (file_exists($oldFileName)) {
                return self::$oldPaths[$oldDirName];
            }
        }

        return $path;
    }


    /**
     * Return path to ainvite avatars directory for (current) account
     * @param mixed $accountName
     * @param mixed $fileName
     * @param array|NULL $extensionsToTry
     * @return string path
     */
    public static function getAccountAinviteAvatarsPath($accountName = NULL, $fileName = NULL, $extensionsToTry = null) {
        return self::_tryFiles($accountName, $fileName, $extensionsToTry, '/images', 'ainvite_avatars');
    }

    public static function getAccountVisitorAvatarsPath($accountName = NULL, $fileName = NULL, $extensionsToTry = null) {
        return self::_tryFiles($accountName, $fileName, $extensionsToTry, '/images/visitor_avatars', NULL);
    }

    public static function getAccountDepartmentLogosPath($accountName = NULL, $fileName = NULL, $extensionsToTry = null) {
        return self::_tryFiles($accountName, $fileName, $extensionsToTry, '/images/department_logos', NULL);
    }

    /**
     * Return path to status file directory for (current) account
     * @param mixed $accountName
     * @param mixed $fileName
     * @return string path
     */
    public static function getAccountStatusFilePath($accountName = NULL, $fileName = NULL) {
        $path = self::ensureAbsolutePathForAccountDirs('/', $accountName);
        if (!empty($fileName) && !@file_exists($path . '/' . $fileName)) {
            return self::$oldPaths['account_status'];
        }
        return $path;
    }

    /**
     * Return path to site logos directory for (current) account
     * @param mixed $accountName
     * @param mixed $fileName
     * @param array|NULL $extensionsToTry
     * @return string path
     */
    public static function getAccountLogotypesPath($accountName = NULL, $fileName = NULL, $extensionsToTry = null) {
        return self::_tryFiles($accountName, $fileName, $extensionsToTry, '/images', 'logo');
    }

    /**
     * Return path to site preview directory for (current) account
     * @param mixed $accountName
     * @param mixed $fileName
     * @param array|NULL $extensionsToTry
     * @return string path
     */
    public static function getAccountSitePreviewPath($accountName = NULL, $fileName = NULL, $extensionsToTry = null) {
        return self::_tryFiles($accountName, $fileName, $extensionsToTry, '/images/site_preview', 'preview');
    }


    /**
     * Return path to port files directory for (current) account
     * @param mixed $accountName
     * @param mixed $fileName
     * @return string path
     */
    public static function getAccountPortsPath($accountName = NULL, $fileName = NULL) {
        $path = self::ensureAbsolutePathForAccountDirs('/ports', $accountName);
        if (!empty($fileName) && !@file_exists($path . '/' . $fileName)) {
            return self::$oldPaths['ports'];
        }
        return $path;
    }

    /**
     * Return path to locations directory for (current) account
     * @param mixed $accountName
     * @return string path
     */
    public static function getAccountLocationsPath($accountName = NULL) {
        return self::ensureAbsolutePathForAccountDirs('/locations', $accountName);
    }

    /**
     * Return path to location directory for (current) account
     * @param string $location
     * @param mixed $accountName
     * @return string path
     */
    public static function getAccountLocationPath($location, $accountName = NULL) {
        return self::ensureAbsolutePathForAccountDirs('/locations/' . $location, $accountName);
    }


    public static function getAccountDBPath($accountName = NULL) {
        return self::ensureAbsolutePathForAccountDirs('/db', $accountName);
    }

    /**
     * Return path to local button images directory for (current) account
     * @param string $locale
     * @param mixed $accountName
     * @param mixed $backToOldIfProblems
     * @return string path
     */
    public static function getAccountButtonsPath($locale, $accountName = NULL, $backToOldIfProblems = NULL) {
        $path = self::ensureAbsolutePathForAccountDirs('/images/buttons/' . $locale, $accountName);
        $files = @scandir($path);
        if (!empty($backToOldIfProblems) && count($files) <= 2) {
            return self::$oldPaths['buttons'];
        }
        return $path;
    }

    /**
     * Return path to local resources directory for (current) account
     * @param string $locale
     * @param mixed $accountName
     * @return string path
     */
    public static function getAccountResourcesPath($locale, $accountName = NULL) {
        return self::ensureAbsolutePathForAccountDirs('/locales/' . $locale, $accountName);
    }

    /**
     * Return path to local rules (for button.js, etc) directory for (current) account
     * @param null $accountName
     * @return mixed
     */
    public static function getAccountButtonRulesPath($accountName = NULL) {
        return self::ensureAbsolutePathForAccountDirs('/button-rules', $accountName);
    }

    /**
     * Return base path to account local files
     * @static
     * @param $accountName string account name
     * @return string|NULL
     */
    public static function getClientDataDirPath($accountName) {
        return empty($accountName) ? '/var/pro/client-data/cd/login' : '/var/pro/client-data/cd/' . $accountName;
    }

    /**
     * Return path to account temp directory (for temp images, etc.)
     * @param null $accountName
     * @return mixed
     */
    public static function getAccountTempPath($accountName = NULL) {
        return self::ensureAbsolutePathForAccountDirs('/temp', $accountName);
    }

    /**
     * Return path to chat css file for $theme or default
     * @param null $theme
     * @param null $accountName
     * @return string
     */
    public static function getVisitorCSSPath($theme = NULL, $accountName = NULL) {
        $accountName = !empty($accountName) ? $accountName : getAccountId();
        $cssPath = $default = __DIR__ . '/../v/css/frontend.css';
        $accountDefault = __DIR__ . '/../account-specific/' . $accountName . '/themes/default/css/frontend.css';
        if (file_exists($accountDefault)) {
            $cssPath = $accountDefault;
        }
        if (!empty($theme)) {
            $accountThemePath =  __DIR__ . '/../account-specific/' . $accountName . '/themes/' . $theme . '/css/frontend.css';
            if (file_exists($accountThemePath)) {
                $cssPath = $accountThemePath;
            }
        }
        return realpath($cssPath);
    }

    /**
     * Return path to additional css file for account.
     * @param null $accountName
     * @return bool|string
     */
    public static function getVisitorAdditionalCSSPath($accountName = NULL) {
        $accountName = !empty($accountName) ? $accountName : getAccountId();
        $path = __DIR__ . '/../account-specific/' . $accountName . '/v/css/frontend.css';
        return file_exists($path) ? realpath($path) : FALSE;
    }

    /**
     * Return paths to chat templates dirs for $theme or default
     * @param null $theme
     * @param string $mode
     * @param null $accountName
     * @return array
     */
    public static function getVisitorTemplatesPath($theme = NULL, $mode='desktop', $accountName = NULL) {
        $accountName = !empty($accountName) ? $accountName : getAccountId();
        $paths = array();
        $possiblePaths = array(
            WEBIM_SMARTY_TEMPLATE_DIR . '/frontend/',
            __DIR__ . '/../account-specific/' . $accountName . '/themes/default/templates/',
        );
        if ($theme && $theme != 'default') {
            $possiblePaths[] = __DIR__ . '/../account-specific/' . $accountName . '/themes/' . $theme . '/templates/';
        }
        $modes = array('desktop');
        if (in_array($mode, array('mobile', 'separate'))) {
            $modes[] = $mode;
        }
        foreach ($possiblePaths as $possiblePath) {
            foreach ($modes as $mode) {
                if (file_exists($possiblePath . $mode)) {
                    array_unshift($paths, realpath($possiblePath . $mode));
                }
            }
        }
        return $paths;
    }

    public static function getAccountReportsPath($accountName = NULL) {
        return self::ensureAbsolutePathForAccountDirs('/reports', $accountName);
    }

    /**
     * Check that $path exists or create it.
     * @param string $path to target directory
     * @param int $mode for created directory
     * @return mixed
     * @throws Exception
     */
    protected static function ensurePathExists($path, $mode = self::DEFAULT_DIR_MODE) {
        $dirs = explode(DIRECTORY_SEPARATOR, $path);
        $passPath = '';
        foreach ($dirs as $dir) {
            if (!empty($dir)) {
                $passPath .= '/' . $dir;
                if (file_exists($passPath) && !is_dir($passPath)) {
                    throw new Exception('Can\'t create directory "' . $passPath . '" in path "' . $path . '" - already exists and not directory');
                } elseif (!file_exists($passPath)) {
                    doMyLog('Try to create dir:' . $passPath);
                    if (!mkdir($passPath, $mode, true)) {
                        throw new Exception('Can\'t create directory "' . $passPath . '" in path "' . $path . '"');
                    }
                }
            }
        }
        return $path;
    }

    protected static function ensureAbsolutePathForAccountDirs($relPath, $accountName = NULL) {
        $relPath = substr($relPath, 0, 1) != '/' ? '/' . $relPath : $relPath;
        $accountName = empty($accountName) ? getAccountId() : $accountName;
        $absPath = self::getClientDataDirPath($accountName) . $relPath;
        return self::ensurePathExists($absPath);
    }

    public static function getAccountEnabledFilename() {
        return FilesLocation::getAccountStatusFilePath() . '/' . getAccountId() . ACCOUNT_STATUS_FILE_EXT;
    }
}

?>