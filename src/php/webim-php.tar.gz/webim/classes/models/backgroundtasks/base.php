<?php

/**
 * Class Model_BackgroundTask
 * Представляет фоновую задачу - процесс запускаемый в отедльном потоке php,
 * что бы обходить ограничение по времени выполнения, и иметь возможность
 * выполнять длительные задачи по запросу операторов (построение отчётов)
 */
abstract class Model_BackgroundTask_Base extends Model_Base {
    /**
     * Уникальный идентификатор для некоторого типа задач
     * Позволяет определять количество задач одного типа выполняемых на данный момент
     * @var string
     */
    protected $key;

    /**
     * @var \DateTime Время создания задачи
     */
    protected $created;
    /**
     * @var \DateTime|NULL Время запуска задачи
     */
    protected $started;
    /**
     * @var \DateTime|NULL Время завершения задачи. Может не быть, если задача завершилась без возможности записи в базу
     */
    protected $finished;
    /**
     * @var \DateTime|NULL Время последнего обновления задачи
     */
    protected $updated;

    /**
     * @var string Статус задачи на данный момент
     */
    protected $state;
    /**
     * @var array|NULL Хранит все необходимые данные для запуска задачи
     */
    protected $config;
    /**
     * @var array|NULL Результат выполнения задачи. Например, номер и текст ошибки
     */
    protected $result;
    /**
     * @var int ID оператора создавшего задачу
     */
    protected $operatorId;
    /**
     * @var float Прогресс выполнения задачи от 0 до 1
     */
    protected $progress = 0.0;

    /**
     * Возможные состояния задачи
     * @var array
     * @const
     */
    public static $STATES = array(
        'CREATED' => 'created',
        'RUNNING' => 'running',
        'CANCELED' => 'canceled',
        'FAILED' => 'failed',
        'COMPLETED' => 'completed'
    );

    /**
     * @param $taskRow array Строка из таблицы backgroundtask
     * @throws Exception Если $taskRow не содержит обязательных аргументов
     */
    public function __construct(array $taskRow) {
        if (empty($taskRow['key']) || empty($taskRow['operatorid'])) {
            throw new Exception('Can\'t create task without key or operator');
        }

        $default = array(
            'id' => NULL,
            'config' => NULL,
            'created' => (int) (microtime(true) * 1e6),
            'updated' => $this->getCachedUpdated() ? $this->getCachedUpdated() : (int) (microtime(true) * 1e6),
            'started' => NULL,
            'finished' => NULL,
            'progress' => 0.0,
            'state' => '',
            'result' => NULL
        );

        $taskRow = array_merge($default, $taskRow);
        $this->key = $taskRow['key'];
        $this->config = $taskRow['config']
            ? is_string($taskRow['config'])
                ? json_decode($taskRow['config'], true)
                : $taskRow['config']
            : NULL;
        $this->operatorId = $taskRow['operatorid'];
        $this->created = Helper::getAccountDateTime($taskRow['created'] / 1e6);
        $this->updated = Helper::getAccountDateTime($taskRow['updated'] / 1e6);
        $this->started = !empty($taskRow['started']) ? Helper::getAccountDateTime($taskRow['started'] / 1e6) : NULL;
        $this->finished = !empty($taskRow['finished']) ? Helper::getAccountDateTime($taskRow['finished'] / 1e6) : NULL;
        $this->state = !empty($taskRow['state']) ? $taskRow['state'] : self::$STATES['CREATED'];
        $this->result = !empty($taskRow['result'])
            ? is_string($taskRow['result'])
                ? json_decode($taskRow['result'], true)
                : $taskRow['result']
            : NULL;
        $this->progress = (float)$taskRow['progress'];

        parent::__construct($taskRow['id']);
    }

    /**
     * Запускает задачу на выполнение в отдельном потоке
     */
    public function backgroundRun() {
        if ($this->getState() === self::$STATES['CREATED'] && !$this->isReallyRunning()) {
            $this->state = self::$STATES['RUNNING'];
            $this->started = Helper::getAccountDateTime(microtime(true));
            $this->setUpdatedToNow();
            /**
             * Так как фоновый процесс може завершится ещё до конца текущего и записать результат в базу,
             * который мы случайно можем перезаписать, то откладываем его запуск.
             */
            register_shutdown_function('exec', 'nice ' . $this->getSystemRunCmd() . ' > /dev/null 2>&1 &');
            return true;
        }

        return false;
    }

    /**
     * Запускает задачу на выполнение в этом потоке.
     */
    public function run() {
        if (!$this->isReallyRunning()) {
            $this->state = self::$STATES['RUNNING'];
            $this->started = Helper::getAccountDateTime(microtime(true));
            $this->setUpdatedToNow();
            $this->doIt();
            $this->state = self::$STATES['COMPLETED'];
            $this->finished = Helper::getAccountDateTime(microtime(true));
            $this->setProgress(1.0);
            $this->setUpdatedToNow();
        }
    }

    /**
     * Прерывает выполнение запущенной задачи или просто отменяет её, переводя в отменённые.
     * Не влияет на неудавшиесяи завершённые задачи.
     * @throws Exception если при выполнении команды закрытия ситема выдала какой-то ответ,
     * чего в нормальных условиях быть не должно
     * @return bool
     */
    public function cancel() {
        if (!in_array($this->getState(), array(self::$STATES['CANCELED'], self::$STATES['FAILED'], self::$STATES['COMPLETED']))) {
            $cmd = 'pkill -f ' . escapeshellarg(preg_quote($this->getSystemRunCmd()));
            $res = trim(exec($cmd));
            if (strlen($res)) {
                throw new Exception('Get unexpected output "' . $res . '" while try to execute "' . $cmd . '"');
            }
            if ($this->state == self::$STATES['RUNNING']) {
                $this->finished = Helper::getAccountDateTime(microtime(true));
            }
            $this->state = self::$STATES['CANCELED'];
            $this->setUpdatedToNow();
            return true;
        }

        return false;
    }

    /**
     * Прерывает выполнение задачи, если идёт и отмечает задачу как неудавшуюся.
     */
    public function fail() {
        $this->cancel();
        $this->state = self::$STATES['FAILED'];
        $this->setUpdatedToNow();
    }

    /**
     * Проверяет запущена ли задача сейчас (есть ли в списке процессов на сервере)
     * @return bool
     */
    public function isReallyRunning() {
        $cmd = 'pgrep -f ' . escapeshellarg(preg_quote($this->getSystemRunCmd()));
        $res = trim(exec($cmd));
        return $res !== '' && (int)$res !== getmypid();
    }

    /**
     * Возвращает массив для сохранения в базу
     * @return array
     */
    public function toRow() {
        return array(
            'id' => $this->getId(),
            'key' => $this->getKey(),
            'operatorid' => $this->getOperatorId(),
            'config' => $this->getConfig() ? json_encode($this->getConfig()) : NULL,
            'created' => $this->getCreated()->format('Uu'),
            'updated' => $this->getUpdated()->format('Uu'),
            'started' => $this->getStarted() ? $this->getStarted()->format('Uu') : NULL,
            'finished' => $this->getFinished() ? $this->getFinished()->format('Uu') : NULL,
            'state' => $this->getState(),
            'progress' => $this->getProgress(),
            'result' => $this->getResult() ? json_encode($this->getResult()) : NULL
        );
    }

    /**
     * @return float
     */
    public function getProgress() {
        $cachedProgress = KeyValueCache::get('background_task_' . $this->getId() . '_progress');
        if (!empty($cachedProgress)) {
            $this->progress = (float)$cachedProgress;
        }
        return $this->progress;
    }

    /**
     * @param float $progress
     */
    public function setProgress($progress) {
        $this->progress = (float)$progress;
        $this->setUpdatedToNow();
        /* Так как модель сама себя в базу сохранять не должна (на уровне концепции), но task должен обновлять
        информацию о прогрессе и гже-то её хранить для асинхронного доступа, используеу кэш */
        KeyValueCache::put('background_task_' . $this->getId() . '_progress', $progress);
    }


    /**
     * @return array|NULL
     */
    public function getConfig() {
        return $this->config;
    }

    /**
     * @return \DateTime
     */
    public function getCreated() {
        return $this->created;
    }

    /**
     * @return \DateTime|NULL
     */
    public function getFinished() {
        return $this->finished;
    }

    /**
     * @return string
     */
    public function getKey() {
        return $this->key;
    }

    /**
     * @return array|NULL
     */
    public function getResult() {
        return $this->result;
    }

    /**
     * @return \DateTime|NULL
     */
    public function getStarted() {
        return $this->started;
    }

    /**
     * @return string
     */
    public function getState() {
        return $this->state;
    }

    /**
     * @return int
     */
    public function getOperatorId() {
        return $this->operatorId;
    }

    /**
     * @return \DateTime|NULL
     */
    public function getUpdated() {
        $cachedUpdated = $this->getCachedUpdated();
        if (!empty($cachedUpdated) && (int)$cachedUpdated > (int)($this->updated->format('Uu'))) {
            $this->updated = Helper::getAccountDateTime($cachedUpdated / 1e6);
        }

        return $this->updated;
    }

    public function setUpdatedToNow() {
        $this->updated = Helper::getAccountDateTime(microtime(true));
        KeyValueCache::put('background_task_' . $this->getId() . '_updated', $this->updated->format('Uu'));
    }

    /**
     * @return null|int in timestamp microseconds
     */
    protected function getCachedUpdated() {
        return KeyValueCache::get('background_task_' . $this->getId() . '_updated');
    }


    /**
     * Возвращает строку для запуска задачи через exec
     * @return string
     */
    protected function getSystemRunCmd() {
        $makeTaskPath = realpath(__DIR__ . '/../../../service/aux/make-task.php');
        return 'php ' . $makeTaskPath . ' ' . getAccountId() . ' ' . $this->getId();
    }

    /**
     * Непоредсвтенно выполняет задачу
     * @return mixed
     */
    abstract protected function doIt();
}