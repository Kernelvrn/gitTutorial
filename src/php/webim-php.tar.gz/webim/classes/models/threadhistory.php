<?php

class Model_ThreadHistory extends Model_Base {
    /**
     * @var array
     * @const
     */
    public static $STATES = array(
        'QUEUE' => 'queue',
        'CHATTING' => 'chatting',
        'CLOSED' => 'closed',
        'CLOSED_BY_VISITOR' => 'closed_by_visitor',
        'CLOSED_BY_OPERATOR' => 'closed_by_operator',
        'OFFLINE_QUEUE' => 'offline_queue',
        'OFFLINE_PROCESS' => 'offline_process',
        'INVITATION' => 'invitation',
        'DELETED' => 'deleted'
    );

    /**
     * @var null|int
     */
    protected $threadId = NULL;
    /**
     * @var null|int
     */
    protected $number = NULL;
    /**
     * @var null|\DateTime
     */
    protected $created = NULL;
    /**
     * @var null|string
     */
    protected $state = NULL;
    /**
     * @var null|int
     */
    protected $operatorId = NULL;
    /**
     * @var null|Model_Operator
     */
    protected $operator = NULL;
    /**
     * @var null|int
     */
    protected $departmentId = NULL;
    /**
     * @var null|Model_Department
     */
    protected $department = NULL;
    /**
     * @var null|string
     */
    protected $locale = NULL;
    /**
     * @var null|string
     */
    protected $event = NULL;
    /**
     * @var null|int
     */
    protected $officeId = NULL;

    public function __construct($eventRow) {
        if (empty($eventRow['threadid']) || empty($eventRow['number']) || empty($eventRow['state'])) {
            throw new Exception('Can\'t create thread history event without thread, number, state');
        }

        $defaults = array(
            'event' => NULL,
            'threadhistoryid' => NULL,
            'dtm' => NULL,
            'operatorid' => NULL,
            'operator' => NULL,
            'departmentid' => NULL,
            'department' => NULL,
            'locale' => NULL,
            'officeid' => NULL
        );
        $eventRow = array_merge($defaults, $eventRow);

        parent::__construct($eventRow['threadhistoryid']);

        $this->created = Helper::getAccountDateTime($eventRow['dtm']);
        $this->operatorId = $eventRow['operatorid'];
        $this->operator = $eventRow['operator'];
        $this->number = $eventRow['number'];
        $this->state = $eventRow['state'];
        $this->event = $eventRow['event'];
        $this->departmentId = $eventRow['departmentid'];
        $this->department = $eventRow['department'];
        $this->locale = $eventRow['locale'];
        $this->officeId = $eventRow['officeid'];
        $this->threadId = $eventRow['threadid'];
    }

    /**
     * @return \Model_Department|null
     */
    public function getDepartment() {
        if (empty($this->department) && !empty($this->departmentId)) {
            $this->department = Factory_Repository::create('Department')->findById($this->departmentId);
        }

        return $this->department;
    }

    /**
     * @return \Model_Operator|null
     */
    public function getOperator() {
        if (empty($this->operator) && !empty($this->operatorId)) {
            $this->operator = Factory_Repository::create('Operator')->findById($this->operatorId);
        }
        return $this->operator;
    }

    /**
     * @return \DateTime|null
     */
    public function getCreated() {
        return $this->created;
    }

    /**
     * @return int|null
     */
    public function getDepartmentId() {
        return $this->departmentId;
    }

    /**
     * @return null|string
     */
    public function getEvent() {
        return $this->event;
    }

    /**
     * @return null|string
     */
    public function getLocale() {
        return $this->locale;
    }

    /**
     * @return int|null
     */
    public function getNumber() {
        return $this->number;
    }

    /**
     * @return int|null
     */
    public function getOfficeId() {
        return $this->officeId;
    }

    /**
     * @return int|null
     */
    public function getOperatorId() {
        return $this->operatorId;
    }

    /**
     * @return null|string
     */
    public function getState() {
        return $this->state;
    }

    /**
     * @return int|null
     */
    public function getThreadId() {
        return $this->threadId;
    }
}