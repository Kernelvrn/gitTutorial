<?php
class Model_Operator extends Model_Base {
    /**
     * @var null|string
     */
    protected $fullName = NULL;
    /**
     * @var null|string
     */
    protected $email = NULL;
    /**
     * @var null|\DateTime
     */
    protected $created = NULL;
    /**
     * @var null|string
     */
    protected $password = NULL;
    /**
     * @var null|string
     */
    protected $avatar = NULL;
    /**
     * @var null|string
     */
    protected $login = NULL;

    public function __construct(array $operatorRow = array()) {
        $defaults = array(
            'operatorid' => NULL,
            'fullname' => NULL,
            'email' => NULL,
            'created' => NULL,
            'password' => NULL,
            'avatar' => NULL,
            'login' => NULL
        );

        $operatorRow = array_merge($defaults, $operatorRow);

        parent::__construct($operatorRow['operatorid']);

        $this->fullName = $operatorRow['fullname'];
        $this->email = $operatorRow['email'];
        $this->created = Helper::getAccountDateTime($operatorRow['created']);
        $this->password = $operatorRow['password'];
        $this->avatar = $operatorRow['avatar'];
        $this->login = $operatorRow['login'];
    }

    /**
     * @return null|string
     */
    public function getAvatar() {
        return $this->avatar;
    }

    /**
     * @return \DateTime
     */
    public function getCreated() {
        return $this->created;
    }

    /**
     * @return null|string
     */
    public function getEmail() {
        return $this->email;
    }

    /**
     * @return null|string
     */
    public function getLogin() {
        return $this->login;
    }

    /**
     * @return null|string
     */
    public function getPassword() {
        return $this->password;
    }

    /**
     * @return null|string
     */
    public function getFullName() {
        return $this->fullName;
    }
}