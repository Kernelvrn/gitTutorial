<?php

/**
 * Class Model_Category
 * Для данных объектов, так как они не хранятся в базе в отдельной таблице,
 * id определяется согласно их положения в иерархии.
 */
class Model_Category extends Model_Base {
    /**
     * @var string
     */
    protected $title;
    /**
     * @var Model_Category|null
     */
    protected $parent;
    /**
     * @var Model_Category[]
     */
    protected $children = array();

    /**
     * Model_Category constructor.
     * @param string $title
     * @param Model_Category $parent
     */
    public function __construct($title, Model_Category $parent = NULL) {
        $id = $parent ? $parent->getId() . '|' . $title : $title;
        parent::__construct($id);
        $this->title = $title;
        $this->parent = $parent;
    }

    /**
     * @return string
     */
    public function getTitle() {
        return $this->title;
    }

    /**
     * @return Model_Category[]
     */
    public function getChildren() {
        return $this->children;
    }

    /**
     * @param string $title
     * @return bool
     */
    public function hasChildByTitle($title) {
        return array_key_exists($title, $this->children);
    }

    /**
     * @param string $title
     * @return Model_Category|null
     */
    public function getChildByTitle($title) {
        return array_key_exists($title, $this->children) ? $this->children[$title] : NULL;
    }

    /**
     * @param string $title
     */
    public function addChildByTitle($title) {
        if (!array_key_exists($title, $this->children)) {
            $this->children[$title] = new Model_Category($title, $this);
            ksort($this->children);
        }
    }

    /**
     * @return Model_Category|null
     */
    public function getParent() {
        return $this->parent;
    }
}