<?php
class Model_Callback extends Model_Base {
    protected $rawCallback = array();

    protected $created = null;
    protected $modified = null;
    protected $duration = null;
    protected $visitor = array();
    protected $kind = null;
    protected $remote = null;
    protected $operatorPhone = null;
    protected $visitorPhone = null;
    protected $recordFilename = null;
    protected $referrerUrl = null;
    protected $location = array();


    public function __construct($callbackRow) {
        $default = array_fill_keys(array(
            'id', 'visitorname', 'json', 'userid', 'operatorphone', 'visitorphone',
            'remote', 'referrerurl', 'recorduri', 'created', 'duration', 'modified', 'kind'
        ), null);
        $callbackRow = array_merge($default, $callbackRow);
        $this->rawCallback = $callbackRow;

        $this->id = $callbackRow['id'];
        $this->created = Helper::getAccountDateTime($callbackRow['created']);
        $this->modified = Helper::getAccountDateTime($callbackRow['modified']);
        $this->duration = $callbackRow['duration'];
        $this->remote = $callbackRow['remote'];
        $this->setLocationByIp($callbackRow['remote']);
        $this->setVisitor($callbackRow['userid'], $callbackRow['visitorname'], $callbackRow['json']);
        $this->kind = $callbackRow['kind'];
        $this->recordFilename = $callbackRow['recorduri'];
        $this->referrerUrl = $callbackRow['referrerurl'];
        $this->operatorPhone = $callbackRow['operatorphone'];
        $this->visitorPhone = $callbackRow['visitorphone'];
    }

    /**
     * @return \DateTime|null
     */
    public function getCreated() {
        return $this->created;
    }

    /**
     * @return null
     */
    public function getKind() {
        return $this->kind;
    }

    /**
     * @return null
     */
    public function getDuration() {
        return $this->duration;
    }

    /**
     * @return array
     */
    public function getLocation() {
        return $this->location;
    }

    /**
     * @return \DateTime|null
     */
    public function getModified() {
        return $this->modified;
    }

    /**
     * @return null
     */
    public function getOperatorPhone() {
        return $this->operatorPhone;
    }

    /**
     * @return array
     */
    public function getRawCallback() {
        return $this->rawCallback;
    }

    /**
     * @return null
     */
    public function getRecordFilename() {
        return $this->recordFilename;
    }

    /**
     * @return null
     */
    public function getReferrerUrl() {
        return $this->referrerUrl;
    }

    /**
     * @return null
     */
    public function getRemote() {
        return $this->remote;
    }

    /**
     * @return array
     */
    public function getVisitor() {
        return $this->visitor;
    }

    /**
     * @return null
     */
    public function getVisitorPhone() {
        return $this->visitorPhone;
    }

    protected function setVisitor($id, $name, $threadJson) {
        $this->visitor = array_fill_keys(array('id', 'name', 'phone', 'email'), null);
        $this->visitor['id'] = $id;
        $this->visitor['name'] = $name;

        $json = !empty($threadJson) ? json_decode($threadJson, true) : array();
        if (!empty($json)) {
            $fields = $json['visitor']['fields'];
            if (array_key_exists('email', $fields)) {
                $this->visitor['email'] = $fields['email'];
            }

            if (array_key_exists('phone', $fields)) {
                $this->visitor['phone'] = $fields['phone'];
            }
        }
    }

    protected function setLocationByIp($ip) {
        $locationDefault = array_fill_keys(array('city', 'country', 'lat', 'lng'), null);
        $geoData = GeoIPLookup::getGeoDataByIP($ip);
        $this->location = array_merge(
            $locationDefault,
            !empty($geoData) ? $geoData : array()
        );
    }
}