<?php

class Model_VisitorSession extends Model_Base {
    /**
     * @var null|string
     */
    protected $ip = NULL;
    /**
     * @var null|string
     */
    protected $userAgent = NULL;
    /**
     * Именно этот ID используется для связи с другими моделями и генерится ещё до сохранения в БД.
     * @var null|string
     */
    protected $sessionId = NULL;
    /**
     * @var null|string
     */
    protected $visitorId = NULL;
    /**
     * ID посетителя в различных системах клиентов
     * @var null|string
     */
    protected $userId = NULL;
    /**
     * @var null|Model_Visitor
     */
    protected $visitor = NULL;
    /**
     * @var null|\DateTime
     */
    protected $created = NULL;
    /**
     * @var null|\DateTime
     */
    protected $updated = NULL;
    /**
     * @var null|array
     */
    protected $json = NULL;
    /**
     * @var null|string
     */
    protected $country = NULL;
    /**
     * @var null|string
     */
    protected $region = NULL;
    /**
     * @var null|string
     */
    protected $city = NULL;

    public function __construct(array $sessionRow) {
        if (empty($sessionRow['visitsessionid'])) {
            throw new Exception('Can\'t create session without SessionId');
        }

        $defaults = array(
            'id' => NULL,
            'ip' => NULL,
            'useragent' => NULL,
            'visitorid' => NULL,
            'userid' => NULL,
            'created' => time(),
            'updated' => time(),
            'json' => NULL,
            'country' => NULL,
            'region' => NULL,
            'city' => NULL
        );

        $sessionRow = array_merge($defaults, $sessionRow);

        parent::__construct($sessionRow['id']);

        $this->sessionId = $sessionRow['visitsessionid'];
        $this->ip = $sessionRow['ip'];
        $this->userAgent = $sessionRow['useragent'];
        $this->created = Helper::getAccountDateTime($sessionRow['created']);
        $this->updated = Helper::getAccountDateTime($sessionRow['updated']);
        $this->json = isset($sessionRow['json'])
            ? is_string($sessionRow['json']) ? json_decode($sessionRow['json'], true) : $sessionRow['json']
            : NULL;
        $this->country = $sessionRow['country'];
        $this->region = $sessionRow['region'];
        $this->city = $sessionRow['city'];
        $this->visitorId = $sessionRow['visitorid'];
        $this->userId = $sessionRow['userid'];
    }

    /**
     * @return null|string
     */
    public function getCity() {
        return $this->city;
    }

    /**
     * @return null|string
     */
    public function getCountry() {
        return $this->country;
    }

    /**
     * @return \DateTime|null
     */
    public function getCreated() {
        return $this->created;
    }

    /**
     * @return null|string
     */
    public function getIp() {
        return $this->ip;
    }

    /**
     * @return array|null
     */
    public function getJson() {
        return $this->json;
    }

    /**
     * @return null|string
     */
    public function getRegion() {
        return $this->region;
    }

    /**
     * @return null|string
     */
    public function getSessionId() {
        return $this->sessionId;
    }

    /**
     * @return \DateTime|null
     */
    public function getUpdated() {
        return $this->updated;
    }

    /**
     * @return null|string
     */
    public function getUserAgent() {
        return $this->userAgent;
    }

    /**
     * @return \Model_Visitor|null
     */
    public function getVisitor() {
        if (empty($this->visitor) && isset($this->visitorId)) {
            $fields = [];
            if (!empty($this->json) && !empty($this->json['visitor'])) {
                $order = array_reverse(Settings::Get('visitor_fields_priority_order'));
                foreach ($order as $item) {
                    $fields = array_merge($fields, !empty($this->json['visitor'][$item]) ? $this->json['visitor'][$item] : []);
                }
            }
            $this->visitor = new Model_Visitor(array(
                'visitorid' => $this->visitorId,
                'userid' => $this->userId,
                'created' => $this->created->getTimestamp(),
                'fields' => $fields
            ));
        }
        return $this->visitor;
    }

    /**
     * @return null|string
     */
    public function getVisitorId() {
        return $this->visitorId;
    }

    /**
     * @return null|string
     */
    public function getPlatform() {
        return !empty($this->json) && !empty($this->json['platform'])  ? $this->json['platform'] : NULL;
    }

    public function getLandingPageLocation() {
        return !empty($this->json) && !empty($this->json['landingPage']) && !empty($this->json['landingPage']['location'])
            ? $this->json['landingPage']['location']
            : NULL;
    }
}