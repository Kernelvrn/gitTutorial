<?php
class Model_Thread extends Model_Base {
    use Trait_LocalCategoryTree;
    /**
     * @var DateTime|null
     */
    protected $created = NULL;
    /**
     * @var DateTime|null
     */
    protected $modified = NULL;
    /**
     * @var null|int
     */
    protected $duration = NULL;
    /**
     * @var array|null
     */
    protected $location = NULL;
    /**
     * @var null
     */
    protected $operatorOwnerName = NULL;
    /**
     * @var array
     */
    protected $departmentNames = array();
    /**
     * @var array
     */
    protected $departmentKeys = array();
    /**
     * @var array
     */
    protected $category = array();
    /**
     * @var null|string
     */
    protected $kind = NULL;
    /**
     * @var array|null
     */
    protected $office = NULL;
    /**
     * @var null|Model_Message_Base[]
     */
    protected $messages = NULL;
    /**
     * @var null|int
     */
    protected $messagesCount = NULL;
    /**
     * @var null|Model_ThreadHistory[]
     */
    protected $history = NULL;
    /**
     * @var null|Model_Rate[]
     */
    protected $rates = NULL;
    /**
     * @var null|string
     */
    protected $sessionId = NULL;
    /**
     * @var null|Model_VisitorSession
     */
    protected $session = NULL;

    public function __construct(array $threadRow) {
        $default = array_fill_keys(array(
            'threadid', 'operatorfullname',
            'officeid', 'category', 'subcategory', 'size',
            'created', 'duration', 'modified', 'threadkind', 'departmentnames',
            'departmentkeys', 'messages', 'history', 'rates', 'session', 'sessionId'
        ), NULL);
        $threadRow = array_merge($default, $threadRow);

        parent::__construct($threadRow['threadid']);

        $this->operatorOwnerName = $threadRow['operatorfullname'];
        $this->departmentNames = explode(',', $threadRow['departmentnames']);
        $this->departmentKeys = explode(',', $threadRow['departmentkeys']);
        $this->created = Helper::getAccountDateTime($threadRow['created']);
        $this->modified = Helper::getAccountDateTime($threadRow['modified']);
        $this->duration = $threadRow['duration'];
        $this->history = $threadRow['history'];
        $this->rates = $threadRow['rates'];
        $this->sessionId = $threadRow['visitsessionid'];
        $this->session = $threadRow['session'];
        $this->kind = $threadRow['threadkind'];
        $this->office = !empty($threadRow['officeid']) ? array('id' => $threadRow['officeid']) : NULL;
        $this->setCategory($threadRow['category'], $threadRow['subcategory']);
        $this->messagesCount = $threadRow['size'];
        $this->messages = $threadRow['messages'];
    }

    /**
     * @return \DateTime|NULL
     */
    public function getCreated() {
        return $this->created;
    }

    /**
     * @return array
     */
    public function getDepartmentNames() {
        return $this->departmentNames;
    }

    /**
     * @return Model_Message_Base[]
     */
    public function getMessages() {
        if (!isset($this->messages)) {
            /**
             * @var $repository Repository_Message
             */
            $repository = Factory_Repository::create('Message');
            $this->messages = $repository->findByThread($this);
        }
        return $this->messages;
    }

    /**
     * @return Model_Rate[]
     */
    public function getRates() {
        if (!isset($this->rates)) {
            /**
             * @var $repository Repository_Rate
             */
            $repository = Factory_Repository::create('Rate');
            $this->rates = $repository->findByThread($this);
        }
        return $this->rates;
    }

    /**
     * @return Model_ThreadHistory[]
     */
    public function getHistory() {
        if (!isset($this->history)) {
            /**
             * @var $repository Repository_ThreadHistory
             */
            $repository = Factory_Repository::create('ThreadHistory');
            $this->history = $repository->findByThread($this);
        }
        return $this->history;
    }

    /**
     * @return \DateTime|NULL
     */
    public function getModified() {
        return $this->modified;
    }

    /**
     * @return mixed
     */
    public function getOperatorOwnerName() {
        return $this->operatorOwnerName;
    }

    /**
     * @return null|Model_Visitor
     */
    public function getVisitor() {
        return $this->getSession() ? $this->getSession()->getVisitor() : NULL;
    }

    /**
     * @return null|string
     */
    public function getSessionId() {
        return $this->sessionId;
    }

    /**
     * @return \Model_VisitorSession|null
     */
    public function getSession() {
        if (empty($this->session) && !empty($this->sessionId)) {
            /** @var $repository Repository_VisitorSession */
            $repository = Factory_Repository::create('VisitorSession');
            $this->session = $repository->findBySessionId($this->sessionId);
        }
        return $this->session;
    }

    /**
     * @return array
     */
    public function getCategory() {
        return $this->category;
    }

    /**
     * @return NULL
     */
    public function getRemote() {
        return $this->getSession() ? $this->getSession()->getIp() : NULL;
    }

    /**
     * @return array|NULL
     */
    public function getOffice() {
        if (!empty($this->office['id']) && empty($this->office['name'])) {
            $this->office['name'] = Settings::GetOfficeName($this->office['id']);
        }
        return $this->office;
    }

    /**
     * @return array
     */
    public function getLocation() {
        if (!isset($this->location)) {
            $this->location = array_fill_keys(array('city', 'country', 'lat', 'lng'), NULL);
            if ($this->getRemote()) {
                $geoData = GeoIPLookup::getGeoDataByIP($this->getRemote());
                $this->location = array_merge(
                    $this->location,
                    !empty($geoData) ? $geoData : array()
                );
            }
        }

        return $this->location;
    }

    /**
     * @return NULL
     */
    public function getKind() {
        return $this->kind;
    }

    /**
     * @return NULL
     */
    public function getDuration() {
        return $this->duration;
    }

    /**
     * @return array
     */
    public function getDepartmentKeys() {
        return $this->departmentKeys;
    }

    /**
     * @return NULL
     */
    public function getMessagesCount() {
        return $this->messagesCount;
    }

    protected function setCategory($category, $subcategory) {
        if ($category instanceof Model_Category) {
            $this->category = $category;
        } elseif ($category) {
            $this->category = self::getCategoryModel($category, $subcategory);
        }
    }
}