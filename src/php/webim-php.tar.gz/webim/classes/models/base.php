<?php

/**
 * Class Model_Base
 * Базовый предок для моделей из паттерна MVC
 */
abstract class Model_Base {
    /**
     * @var int|string|NULL
     */
    protected $id = NULL;

    public function __construct($id) {
        $this->id = $id;
    }

    public function getId() {
        return $this->id;
    }

    public function setId($id) {
        $this->id = $id;
    }
}