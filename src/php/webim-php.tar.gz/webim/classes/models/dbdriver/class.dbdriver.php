<?php

interface DBDriver {

//  function __construct($link = null);

  function getEscapedString($str);

    function prepareParamForSQL($param);

  function execArrayOfQueries($queries);

  function nextRecord();

  function getRow();

  function getNumRows();

  function getInsertId();

  /**
   * @deprecated queryArrayOfRows should be used instead
   */
  function getArrayOfRows();

  function queryArrayOfRows($query_string, $params = null, $skipDbUse = false);

  public function shouldUseSlave();

  public function getDatabaseName();

  public function multiQuery($sql, $params = null, $skipDbUse = false, $insertQuery = false);

  public function Query($query_string, $params = null, $skipDbUse = false, $insertQuery = false);


}

?>
