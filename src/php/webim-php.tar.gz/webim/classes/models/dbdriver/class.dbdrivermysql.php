<?php
require_once dirname(__FILE__) . '/class.dbdriver.php';
require_once dirname(__FILE__) . '/class.dbnotfoundexception.php';
require_once dirname(__FILE__) . '/class.couldnotconnectexception.php';
require_once dirname(__FILE__) . '/class.movedtoanotherserverexception.php';

class DBDriverMysql implements DBDriver {
  protected $lid = null;
  protected $qid = 0;
  protected $records = array();
  private $dbSettings = null;
  public static $connectionNames = null;

  protected $row = 0;
  protected static $query_count = 0;
  private $key;

  private static $drivers = array();

  public static function getDriver($key) {
    if (isset(self::$drivers[$key])) {
      return self::$drivers[$key];
    }

    self::$drivers[$key] = new DBDriverMysql($key);
    return self::$drivers[$key];
  }


  private function __construct($key, $link = null) {
//    doMyLog("Creating: " . $this->lid . " key " . $this->key, false, true);
//    @doMyLog("Creating: " . $link . " key " . $key, false, empty($key));
    $this->key = $key;
    $this->lid = $link;
  }

  public function getArrayOfRows() {
    return self::_getArrayOfRows($this->qid);
  }

  public function getEscapedString($str) {
    $this->connect();
    if (is_array($str)) {
      $new_str = array();
      foreach ($str as $key => $value) {
        $new_str[$key] = $this->getEscapedString($value);
      }
      return $new_str;
    }

    $new_str = mysql_real_escape_string($str, $this->lid);

    return $new_str;
  }

  protected function connect($skipDbUse = false) {
    if ($this->_getLid() !== null) {
//      if (!isMyIP() && getAccountId() != 'sportmasterru') {
//        $this->_selectDatabase();
//      }
      return;
    }
//    if ($this->lid !== null) {
//      return;
//    }
//    global $DBSETTINGS;

//    if ($this->key == 'pro' && isset($DBSETTINGS['pro2']) && !$skipDbUse) { # to move to new server or work with replication
    $this->_connect($skipDbUse);
//    } else {
//      $this->_connectByKey($skipDbUse);
//    }
//    doMyLog("Saving lid: " . $this->lid);
  }

//  private function __selectDatabase() { // for debug only
//    global $DBSETTINGS;
//    $param = $DBSETTINGS[$this->key];
//    $database = $param['database'];
//
//    if (defined('MYSQL_LOG') && MYSQL_LOG) {
//      doMyLog("Selecting $database for " . $this->lid . " this key " . $this->key);
//    }
//
//    mysql_query("use `" . mysql_real_escape_string($database) . "`", $this->_getLid());
//
//  }

  private static function __connectToExactDatabase($param, $skipDbUse) {
    $use_mysql_ssl = isset($param['ssl']) && $param['ssl'] == "1" ? true : false;
//    var_dump($param);
//    die();
    $host = $param['host'];
    $user = $param['user'];
    $password = $param['password'];
    $port = isset($param['port']) ? $param['port'] : null;
    $connName = isset($param['name']) ? $param['name'] : 'unnamed connection';
    $databaseName = $skipDbUse ? null : $param['database'];
//    $checkMovedTable = isset($param['check_moved_table']);

    $link = null;
    if (empty($retries)) {
      $retries = 5;
    }
    if (empty($databaseName) && $databaseName !== null) {
      immediatelyNotifyAboutProblem("Trying to use empty database");
      throw new Exception("Couldn't use empty database");
    }
    //    $link = @mysql_connect($host, $user, $password); // TODO
    if ($port !== null) {
      $host .= ':' . $port;
    }
    ini_set('mysql.connect_timeout', 2);

    for ($i = 0; $i < $retries; $i++) {
      // 5 retries

      $link = @mysql_connect($host, $user, $password, false, $use_mysql_ssl ? MYSQL_CLIENT_SSL : 0);


//      $this->logFile = 'connection-' . uniqid() . '.log';
      //    @doMyLog("Making connection: " . $link . ' ' . $host . ' ' . $user, false, true, $this->logFile);

      if (!empty($link)) {
        break;
      }
//      if (empty($link)) {
//        if (!defined('SKIP_DB_CONNECTION_FAILURES_NOTIFICATION')) {
//          $myHost = `cat /etc/hostname`;
//          immediatelyNotifyAboutProblem("Couldn't connect to server " . $user . ' @ ' . $host . @mysql_error($link) . " retry: " . $i . " from " . $myHost . " for account " . getAccountId());
//        }
//      } else {
//        break;
//      }
    }

    if (empty($link)) {
      $myHost = `cat /etc/hostname`;
      $errorNum = mysql_errno();
      $message = "Finally couldn't connect to server " . $user . ' @ ' . $host . @mysql_error($link) . " from " . $myHost . " for account " . getAccountId() . " error number: " . $errorNum ;
      if (!defined('SKIP_DB_CONNECTION_FAILURES_NOTIFICATION') && getAccountId() !== 'sportmasterru') {
        immediatelyNotifyAboutProblem($message);
      }
      doMyLog($message);
      throw new CouldNotConnectException($message);
    } elseif ($i > 0) {
      if (!defined('SKIP_DB_CONNECTION_FAILURES_NOTIFICATION')) {
        immediatelyNotifyAboutProblem("Connected after $i retry");
      }
    }

    //if
    if ($databaseName !== null) {
      if (defined('MYSQL_LOG') && MYSQL_LOG) {
        doMyLog("_connectToExactDatabase: Selecting $databaseName for " . $link . " this $user@$host $port ");
      }

//      if (mysql_num_rows(mysql_query("SELECT * FROM information_schema.SCHEMATA WHERE SCHEMA_NAME ='".mysql_real_escape_string($databaseName)."'", $link)) == 0) {
//        doMyLog("Couldn't find database " . $databaseName);
//        throw new DBNotFoundException("Couldn't find database " . $databaseName);
//      }

      if (!@mysql_query("use `" . mysql_real_escape_string($databaseName) . "`", $link)) {
        $errno = @mysql_errno($link);
        $error = @mysql_error($link);
        doMyLog("Couldn't use database " . $databaseName);
        throw new DBNotFoundException("Couldn't use database " . $databaseName . ". MySQL says: (" . $errno . ") " . $error, $errno);
      } //if

//      if ($checkMovedTable && mysql_num_rows(mysql_query("SELECT * FROM information_schema.tables WHERE table_name='moved_to_another_server' AND table_schema='".mysql_real_escape_string($databaseName)."'", $link)) == 1) {
//        doMyLog("Found moved table for " . $databaseName);
//        throw new MovedToAnotherServerException("Found moved table for " . $databaseName);
//      }

    }

    @mysql_query("set character_set_client=" . SITE_DB_CHARSET, $link);
    @mysql_query("set character_set_connection=" . SITE_DB_CHARSET, $link);
    @mysql_query("set collation_connection=" . SITE_DB_COLLATION, $link);
    @mysql_query("set character_set_results=" . SITE_DB_CHARSET, $link);
    @mysql_query("set SQL_BIG_SELECTS=1", $link); #TODO remove it
    self::$connectionNames[$databaseName] = $connName;
    return $link;
//    mysql_query("use `" . mysql_real_escape_string($databaseName) . "`", $link);
  }

  public function queryArrayOfRows($sql, $params = null, $skipDbUse = false) {
    $qid = $this->Query($sql, $params, $skipDbUse);
    return $this->_getArrayOfRows($qid);
  }

  public function multiQuery($sql, $params = null, $skipDbUse = false, $insertQuery = false) {
    $sql = preg_replace('/DELIMITER.*/', '', $sql);
    $sql = preg_replace('/--.*/', '', $sql);
    $arr = null;
    if (strstr($sql, ';;')) {
      $arr = preg_split('/\s*;;\s*/', $sql);
    } else {
      $arr = preg_split('/\s*;\s*/', $sql);
    }
    foreach ($arr as $q) {
      if (!empty($q)) {
        $this->Query($q, $params = null, $skipDbUse = false, $insertQuery = false);
      }
    }
  }

  public function Query($query_string, $params = null, $skipDbUse = false, $insertQuery = false) {
    global $LAST_QUERY;
    $this->connect($skipDbUse);
//    if (!$skipDbUse) {
////      $this->__selectDatabase(); // debug
//    }
    self::$query_count++;
    $query = $this->prepareSQL($query_string, $params, $insertQuery);
    $LAST_QUERY = $query;

    if (stristr($query, 'avg_chatting_time')) {
      $a = 1;
    }

    if (defined('MYSQL_LOG') && MYSQL_LOG) {
      doMyLog("Running for " . $this->_getLid(), true, true);
      doMyLog($query);
    }

    if (defined('MYSQL_LOG_QUERY') && MYSQL_LOG_QUERY) {
      doMyLog($query . ';');
    }

    $time_start = microtime_float();
    $qid = @mysql_query($query, $this->_getLid());
    $this->qid = $qid;

    $time_end = microtime_float();
    $time = $time_end - $time_start;

    $this->row = 0;
    $errno = @mysql_errno($this->_getLid());
    $error = @mysql_error($this->_getLid());

    if (defined('MYSQL_LOG') && MYSQL_LOG) {
      @doMyLog("Query is finished for $time seconds");
    }
    if (!$qid) {

      $ip = isset($_SERVER['REMOTE_ADDR']) ? $_SERVER['REMOTE_ADDR'] : '';

      //      $eol = $MAIN_SETTINGS['devmode'] == 1 ? "<br/>" : PHP_EOL;
      $message = 'Invalid query for ' . getAccountId() . ' remote addr:' . $ip . PHP_EOL . 'MySQL says:' . PHP_EOL . $errno . PHP_EOL . $error . PHP_EOL;
      $message .= PHP_EOL . 'Lid: ' . PHP_EOL . $this->_getLid() . PHP_EOL;
      $message .= PHP_EOL . 'Query:' . PHP_EOL . $query . PHP_EOL;
      $message .= PHP_EOL . 'Query string:' . PHP_EOL . $query_string . PHP_EOL;
      $message .= PHP_EOL . 'Params:' . PHP_EOL . print_r($params, true) . PHP_EOL;
      immediatelyNotifyAboutProblem($message, 'db query error');
      if (isDevMode()|| php_sapi_name() === 'cli' || isMyIP()) {
        die('<pre>' . $message . '</pre>');
      }
      doMyLog($message, false, true);
      throw new Exception($message, $errno);
    } //if

    return $qid;
  } // query()

  protected function prepareSQL($sql, $params, $insertQuery) {
    $sql = $this->convertTablesNames($sql);

//    $sql = preg_replace('/\n/', '', $sql); // can be easily removed
//    $sql = preg_replace('/\s+/', ' ', $sql);

    if ($params === null) {
      return $sql;
    }

    if (!is_array($params)) {
      $params = array($params);
    }

    $positional_params = array();

    $named_params = array('names' => array(), 'values' => array());

    foreach ($params as $k => $v) {
      $paramSQL = $this->prepareParamForSQL($v);
      if (is_int($k)) {
        $positional_params[] = $paramSQL;
      } else {
        $named_params['names'][] = ':' . $k;
        $named_params['values'][] = $paramSQL;
      }
    }

    $result = $sql;

    if (count($positional_params) > 0) {
      $tmp = explode('?', $result);

      if ((count($tmp) - count($positional_params)) != 1) {
        throw new Exception("Wrong parameter count for query $sql");
      }

      $result = '';
      foreach ($tmp as $k => $v) {
        $result .= $v;
        if (isset($positional_params[$k])) {
          $result .= $positional_params[$k];
        }
      }
    }

    if (count($named_params['names']) > 0) {
        foreach ($named_params['names'] as $i => $name) {
            $replace = addcslashes($named_params['values'][$i], '\\$');
            $result = preg_replace('/'.$name.'\b/', $replace, $result);
        }
    }

    if ($insertQuery) {
      $queryToInsert = $result;
      $queryToInsert = str_replace(":query,", '', $queryToInsert);
      $queryToInsert = str_replace("query,", '', $queryToInsert);
      $result = str_replace(':query', $this->prepareParamForSQL($queryToInsert), $result);
    }

    return $result;
  }

  public function prepareParamForSQL($param) {
    switch (gettype($param)) {
      case 'NULL':
        $paramSQL = 'NULL';
        break;
      case 'integer':
        $paramSQL = $param;
        break;
      case 'boolean':
        $paramSQL = $param ? 'TRUE' : 'FALSE';
        break;
      case 'array':
        $subparams = array();
        foreach ($param as $subparam) {
          $subparams[] = $this->prepareParamForSQL($subparam);
        }
        $paramSQL = implode(',', $subparams);
        break;
      case 'object':
        if (get_class($param) == 'DateTime') {
            $dd = $param->format('Y-m-d H:i:s');
            $paramSQL = '"' . $dd . '"';
        } else {
            throw new Exception('Not supported class for SQL param: ' . get_class($param));
        }
        break;
      default:
        $paramSQL = sprintf('"%s"', $this->getEscapedString($param));
    }
    return $paramSQL;
  }

  protected function convertTablesNames($sql) {
      $res = $sql;
      foreach (array(
                   'autoinvite',
                   'ban',
                   'config',
                   'department',
                   'departmentlocale',
                   'hitgoal',
                   'invitation',
                   'lostvisitor',
                   'message',
                   'onlineperiod',
                   'onlineperiods',
                   'operator',
                   'operatoraccount',
                   'operatordepartment',
                   'operatorlastaccess',
                   'operatoronline',
                   'rate',
                   'revision',
                   'stats',
                   'statslog',
                   'thread',
                   'threadhistory',
                   'threadhistoryview',
                   'visitedpage',
                   'visitsession',
               ) as $table) {
          $res = str_replace("{".$table."}", SITE_DB_TABLE_PREFIX . $table, $res); # a little bit hard
      }
      return $res;
  }

  public function execArrayOfQueries($queries) {
    for ($i = 0; $i < sizeof($queries); $i++) {
//      try {
      $this->Query($queries[$i]);
//      } catch (Exception $e) {
//        throw $e;
//      }
    }
  }

  public function nextRecord() {
//    $this->connect();

    if ($this->qid == 0) {
      return (false);
    }
    $this->records = mysql_fetch_array($this->qid, MYSQL_ASSOC);
    $this->row++;
//    $this->errno = mysql_errno();
//    $this->error = mysql_error();

    if (!is_array($this->records)) {
      mysql_free_result($this->qid);
      $this->qid = 0;
    } //if


    return (is_array($this->records));
  } // next_record()

  public function getRow($field = '') {
    if (empty($field))
      return $this->records;
    elseif (is_array($field)) {
      $result = array();
      foreach ($field as $fieldname) {
        $result[$fieldname] = $this->records[$fieldname];
      }
      return $result;
    } else
      return $this->records[$field];
  }

  public function getNumRows() {
    $this->connect();

    if ($this->qid) {
      $r = @mysql_num_rows($this->qid);

      if (defined('MYSQL_LOG') && MYSQL_LOG) {
        doMyLog("Num rows gave " . $r);
      }

      if ($r > 0) {
        return $r;
      }
      return @mysql_affected_rows($this->lid);
    } else {
      return 0;
    }
  } // num_rows()

  public function getInsertId() {
    //                $this->connect();
    return @mysql_insert_id($this->lid);
  } // num_rows()

  protected function close() {
    if (!empty($this->qid) && is_resource($this->qid)) {
      @mysql_free_result($this->qid);
    }
    // don't close any db connection for bitrix
    if (!empty($this->lid)) {
//      @doMyLog("Closing connection: " . $this->lid . " key " . $this->key);
      @mysql_close($this->lid);
//      @unlink('/var/log/pro/' . $this->logFile);
    }
    $this->lid = 0;
  } // close()

  public function __destruct() {
//    @doMyLog("Destructing: " . $this->lid, false, false, $this->logFile);
    $this->close();
  }

  public static function getQueryCount() {
    return self::$query_count;
  }

  private function __insertConnections(&$arr, $connections) {
    $res = array();

    foreach ($arr as $k => $v) {
      if (is_array($v)) {
        $res[$k] = $this->__insertConnections($v, $connections);
      } elseif ($k == 'connection') {
        if (empty($connections[$v])) {
          immediatelyNotifyAboutProblem("Could not find connection name: " . $v);
          throw new Exception("Could not find connection name: " . $v);
        }
        $connections[$v]['name'] = $v;
        $res = array_merge($res, $connections[$v]);
      } else {
        $res[$k] = $v;
      }
    }

    return $res;
  }

  private function __ensureDbSettingsRead() {
    global $MAIN_SETTINGS;
    if ($this->dbSettings !== null) {
      return;
    }
    $result = array();
    $config = json_decode(file_get_contents(DB_CONFIG_PATH), true);

    if (file_exists(DB_CONFIG_EXT_PATH) &&  $handle = opendir(DB_CONFIG_EXT_PATH)) {
      while (false !== ($filename = readdir($handle))) {
        if (is_file(DB_CONFIG_EXT_PATH . '/' . $filename)) {
          $configD = json_decode(file_get_contents(DB_CONFIG_EXT_PATH . '/' . $filename), true);
          $config = array_replace_recursive($config, $configD);
        }
      }
      closedir($handle);
    }
    $acc = getAccountId();
    $dir = $MAIN_SETTINGS['client-data-dir'] . "/$acc/db/db.json.d";
    if ($acc !== null && is_dir($dir) && $handle = opendir($dir)) {
        while (false !== ($filename = readdir($handle))) {
            if (is_file($dir . '/' . $filename)) {
                $configD = json_decode(file_get_contents($dir . '/' . $filename), true);
                $config = array_replace_recursive($config, $configD);
            }
        }
        closedir($handle);
    }

    $result['dbs'] = $config['dbs'];

    $connections = isset($config['connections']) ? $config['connections'] : array();
    $result['dbs'] = $this->__insertConnections($config['dbs'], $connections);

    $result['dbs']['operators'] = $result['dbs']['meta'];


    $this->dbSettings = $result;
  }

  private function __connectByKey($skipDbUse = false) {
    $this->__ensureDbSettingsRead();

    $param = null;

    if ($this->key == 'pro') {
      $param = $this->dbSettings['dbs'][$this->key];
      $param = isset($param[getAccountId()]) ? $param[getAccountId()] : $param['default'];
//      $param = array(
//        'host' => '5.9.141.228',
//        'user'=> 'webim_service',
//        'password'=> 'id28A9Uo2PXWqqkDxQxgX82dfpCxQAAFBn'
//      );
    } else {
      $param = $this->dbSettings['dbs'][$this->key];
    }
    if ($this->shouldUseSlave()) {
      doMyLog("Connecting to slave from the very beginning");
      $param = $param['slave'];
    }

    $param['database'] = $this->getDatabaseName();

//    if ($this->key == 'pro') {
//      $param['database'] = 'webim_service_pro_shoptimeru';
//    }

    $this->lid = self::__connectToExactDatabase($param, $skipDbUse);

  }

  /**
   * @return array of rows
   */
  private static function _getArrayOfRows($qid) {
    $result = array();
    while ($row = mysql_fetch_array($qid, MYSQL_ASSOC)) {
      $result[] = $row;
    }
    return $result;
  }

  /**
   * @param $skipDbUse
   * @throws Exception
   */
  private function _connect($skipDbUse) {
    $xdebugEnabled = function_exists('xdebug_is_enabled') && xdebug_is_enabled();
    if (function_exists('xdebug_disable') && $xdebugEnabled) {
      xdebug_disable();
    }

    try {
      $this->__connectByKey($skipDbUse);
    }
//    catch (DBNotFoundException $e) {
//      if (function_exists('xdebug_enable')) {
//        xdebug_enable();
//      }
//      doMyLog("Going to pro2 because of DBNotFoundException");
//      $this->key = 'pro2';
//      $this->_connectByKey($skipDbUse);
//    }
    catch (CouldNotConnectException $e) {
      if (function_exists('xdebug_enable') && $xdebugEnabled) {
        xdebug_enable();
      }
      if ($this->key == 'pro') {
          $param = $this->dbSettings['dbs'][$this->key]['default'];
      } else {
          $param = $this->dbSettings['dbs'][$this->key];
      }
      if (empty($param['slave'])) {
          throw $e;
      }
      $cacheKey = md5($this->key);
      $firstFailureTime = KeyValueCache::get($cacheKey, 'db-failure-time', null);
      if ($firstFailureTime === null) {
        KeyValueCache::put($cacheKey, time(), 'db-failure-time', 60 * 60);
      } else {
        if (time() - $firstFailureTime > 60) { // more than a minute
          doMyLog("Switching to slave: " . $this->key);
          $useSlaveFilepath = $this->__getUseSlaveFilename();
          $this->lid = self::__connectToExactDatabase($param['slave'], $skipDbUse);
          touch($useSlaveFilepath);
        }
      }
    }
//    catch (MovedToAnotherServerException $e) {
//      if (function_exists('xdebug_enable')) {
//        xdebug_enable();
//      }
//      doMyLog("Going to pro2 because of MovedToAnotherServerException");
//      $this->key = 'pro2';
//      $this->_connectByKey($skipDbUse);
//    }
    catch (Exception $e) {
      throw $e;
    }
  }

  private function _getLid() {
    return $this->lid;
  }

  /**
   * @return mixed
   */
  private function __getUseSlaveFilename() {
    $key = $this->key;
    $accountName = $key != 'pro' ? getAccountId() : 'login';
    $res = FilesLocation::getAccountDBPath($accountName) . '/' . $key . '-slave.txt';
      return $res;
  }

  /**
   * @return bool
   */
  public function shouldUseSlave() {
    return file_exists($this->__getUseSlaveFilename());
  }

  public function getDatabaseName() {
    $this->__ensureDbSettingsRead();

    if ($this->key == 'pro') {
      return 'webim_service_pro_' . getAccountId();
    } else {
      return $this->dbSettings['dbs'][$this->key]['database'];
    }
  }
}


?>
