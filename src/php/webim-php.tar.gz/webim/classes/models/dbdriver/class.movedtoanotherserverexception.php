<?php
/**
 * Created by PhpStorm.
 * User: oleg
 * Date: 10.07.14
 * Time: 14:43
 */

class MovedToAnotherServerException extends Exception {

} 