<?php

class Model_Visitor extends Model_Base {
    /**
     * @var null|\DateTime
     */
    protected $created = NULL;
    /**
     * Разнообразные данные, которые посетитель может указать о себе в соответствующей форме чата.
     * @var null|array
     */
    protected $fields = NULL;
    /**
     * ID пользователя в ситеме клиента
     * @var null|string
     */
    protected $userId = NULL;

    public function __construct(array $visitorRow) {
        if (empty($visitorRow['visitorid'])) {
            throw new Exception('Can\'t create visitor without ID');
        }

        $defaults = array(
            'created' => time(),
            'userid' => NULL,
            'fields' => NULL,
        );

        $visitorRow = array_merge($defaults, $visitorRow);

        parent::__construct($visitorRow['visitorid']);

        $this->created = Helper::getAccountDateTime($visitorRow['created']);
        $this->fields = $visitorRow['fields'];
        $this->userId = $visitorRow['userid'];
    }

    /**
     * @return \DateTime|null
     */
    public function getCreated() {
        return $this->created;
    }

    /**
     * @return array|null
     */
    public function getFields() {
        return $this->fields;
    }

    /**
     * @return null|string
     */
    public function getName() {
        return !empty($this->fields) && array_key_exists('name', $this->fields)
            ? $this->fields['name']
            : NULL;
    }

    /**
     * @return null|string
     */
    public function getDisplayName() {
        return !empty($this->fields) && array_key_exists('display_name', $this->fields)
            ? $this->fields['display_name']
            : NULL;
    }


    /**
     * @return null|string
     */
    public function getPhone() {
        return !empty($this->fields) && array_key_exists('phone', $this->fields)
            ? $this->fields['phone']
            : NULL;
    }

    /**
     * @return null|string
     */
    public function getEmail() {
        return !empty($this->fields) && array_key_exists('email', $this->fields)
            ? $this->fields['email']
            : NULL;
    }

    public function getUserId() {
        return $this->userId;
    }
}