<?php
/**
 * Created by JetBrains PhpStorm.
 * User: Alexander Bezroukov
 * Date: 12/20/12
 * Time: 12:03 PM
 */

require_once(dirname(__FILE__) . '/class.basemapper.php');

class StatsLogMapper extends BaseMapper {

    public function __construct($model_name) {
        parent::__construct($model_name, array('dtm'), TRUE, 'id', 'CREATE TABLE chatstatslog (
          id int(11) unsigned NOT NULL AUTO_INCREMENT,
          query text NOT NULL,
          dtm datetime NOT NULL,
          PRIMARY KEY (id)
        ) ENGINE=InnoDB;');


    }

    public function insertLogItem($sql) {
        $arr = array(
            'query' => $sql,
            'dtm' => time()
        );

        $id = $this->save($arr);
        return $id;
    }


}

?>