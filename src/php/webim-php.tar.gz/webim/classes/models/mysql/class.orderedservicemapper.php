<?php
require_once (dirname(__FILE__) . '/class.basemapper.php');

/**
 * Class for fetching data from 'orderedservice' table.
 */
class OrderedServiceMapper extends BaseMapper {

    public function __construct($model_name) {
        parent::__construct($model_name, array('accountname', 'dtmfrom', 'dtmto', 'price', 'invoiceguid', 'dtmcreated', 'comment'), TRUE, 'id');
    }

    public function getDatabaseKey()
    {
        return 'meta';
    }

    /**
     * @param $from (string: 'yyyy-mm-dd')
     * @param $to (string: 'yyyy-mm-dd')
     * @param int $pricesFrom (invoices with amount larger than ...)
     * @return mixed
     */
    public function getOperatorsCountByPeriod($from, $to, $pricesFrom = 0) {
        return $this->db->queryArrayOfRows('select orderedservice.settings 
from invoice left join orderedservice on invoice.guid = orderedservice.invoiceguid 
where invoice.paydate >= :from and invoice.paydate <= :to and invoice.price >= :pricesFrom
order by invoice.paydate;', array('from' => $from, 'to' => $to, 'pricesFrom' => $pricesFrom));
    }

    /**
     * @param $from (string: 'yyyy-mm-dd')
     * @param $to (string: 'yyyy-mm-dd')
     * @param int $pricesFrom (invoices with amount larger than ...)
     * @return mixed
     */
    public function getCertainPeriodData($from, $to, $pricesFrom = 0) {
        return $this->db->queryArrayOfRows('select invoice.guid, invoice.paydate, 
invoice.pro_payer_accountname, orderedservice.dtmfrom, orderedservice.dtmto, 
orderedservice.tariffkey, invoice.price, orderedservice.monthcnt 
from invoice left join orderedservice on invoice.guid = orderedservice.invoiceguid 
where invoice.paydate >= :from and invoice.paydate <= :to and invoice.price >= :pricesFrom
order by invoice.paydate;', array('from' => $from, 'to' => $to, 'pricesFrom' => $pricesFrom));
    }

    protected function getTableNameForQueries()
    {
        return $this->getTableName();
    }

}
?>