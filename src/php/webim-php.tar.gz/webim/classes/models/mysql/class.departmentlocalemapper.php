<?php
require_once(dirname(__FILE__) . '/class.basemapper.php');

class DepartmentLocaleMapper extends BaseMapper {
    function getDepartmentLocale($departmentid, $locale) {
        $res = $this->makeSearch("departmentid = ? AND locale = ?", array($departmentid, $locale), null, 1);
        return array_shift($res);
    }

    public function getPredefinedAnswersForDepartments($departmentIds, $locale) {
        $rows = $this->makeSearch('locale = ? AND departmentid IN (' . implode(',', $departmentIds) . ')', array($locale), 'answers');
        $answers = NULL;
        if (!empty($rows)) {
            foreach ($rows as $row) {
                $answers[] = $row['answers'];
            }
        }
        return $answers;
    }

    public function getDepartmentLocales($departmentid) {
        return $this->makeSearch('departmentid = ?', array($departmentid));
    }

    public function getDepartmentLocalesByIds(array $ids) {
        $rows = array();
        if (!empty($ids)) {
            $rows = $this->makeSearch('departmentid IN (?)', array($ids));
        }
        return $rows;
    }
}

?>