<?php
//use StatsMapper;

require_once (dirname(__FILE__) . '/class.basemapper.php');
require_once (dirname(__FILE__) . '/../../../autoload.php');


class OperatorOnlineMapper extends BaseMapper {
  public function __construct($model_name) {
    parent::__construct($model_name, array('updated'), false, 'id', null, array(), array('tmp-tables', 'procedures'), array(
      MapperFactory::getOnlinePeriodMapper(),
      MapperFactory::getThreadMapper(),
      MapperFactory::getThreadHistoryMapper()
    ));
  }

  public function getOperatorsOnlineForDate($time) {
    $res = array();

    $sql = <<<END
    SELECT operatorid, sum(`seconds`) as total FROM {operatoronline} WHERE DATE(`date`) = DATE(FROM_UNIXTIME(:date)) GROUP BY operatorid HAVING total > 10*60
END;

    $this->db->Query($sql, array('date' => $time));
    $arr = $this->db->getArrayOfRows();
    foreach ($arr as $a) {
      $res[$a['operatorid']] = 1;
    }

    $sql = <<<END
    SELECT DISTINCT operatorid FROM {onlineperiod} WHERE DATE(dtmfrom) <= DATE(FROM_UNIXTIME(:date)) AND DATE(FROM_UNIXTIME(:date)) <= DATE(dtmto) AND unix_timestamp(dtmto) - unix_timestamp(dtmfrom) > 10*60
END;

    $this->db->Query($sql, array('date' => $time));
    $arr = $this->db->getArrayOfRows();
    foreach ($arr as $a) {
      $res[$a['operatorid']] = 1;
    }

    return $res;
  }
}

?>