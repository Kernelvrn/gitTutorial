<?php
require_once (dirname(__FILE__) . '/class.basemapper.php');

/**
 * Class for working with accounts.
 */
class DnsDomainMapper extends BaseMapper {

  public function __construct($model_name) {
    parent::__construct('dnsdomain', null, true, 'id', "CREATE TABLE dnsdomain (
      id int(11) unsigned NOT NULL AUTO_INCREMENT,
      domain varchar(64) CHARACTER SET ascii NOT NULL DEFAULT '',
      prefix text CHARACTER SET ascii NOT NULL,
      default_ip char(64) NOT NULL DEFAULT '',
      PRIMARY KEY (id),
      KEY idx_domain (domain)
    ) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=latin1;");
  }

  public function getDefaultDomainData() {
    $arr = $this->makeSearch("domain is null");
    return array_shift($arr);
  }

  protected function getTableNameForQueries() {
    return '`' . $this->getTableName() . '`';
  }

  public function getDatabaseKey() {
    return 'operators';
  }

  public function getByDomain($domain) {
    $arr = $this->makeSearch("domain = ?", array($domain));
    return array_shift($arr);

  }

}

?>
