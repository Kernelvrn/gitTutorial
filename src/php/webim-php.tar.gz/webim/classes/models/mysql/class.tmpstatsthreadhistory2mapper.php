<?php
require_once(dirname(__FILE__) . '/class.basemapper.php');

class TmpStatsThreadHistory2Mapper extends BaseMapper {
    protected $statsQueryConfigs = array();
    protected $reportName2GroupFields = array(
        'categories' => array('category', 'subcategory'),
        'departments_online' => array('departmentid'),
        'departments_offline' => array('departmentid'),
        'offices_online' => array('officeid'),
        'offices_offline' => array('officeid'),
        'geo' => array('country', 'region', 'city'),
        'startpages' => array('startpage'),
        'dates_online' => array('d'),
        'dates_offline' => array('d'),
        'hours_online' => array('h'),
        'hours_offline' => array('h'),
        'operators_time' => array('operatorid'),
        'operators' => array('operatorid'),
        'operators_lost_visitor' => array('operatorid'),
        'operators_intercepted_visitor' => array('operatorid')
    );

    public function __construct($model_name) {
        parent::__construct($model_name);

        $this->statsQueryConfigs[] = array(
            'sql' => '
                COUNT(DISTINCT mm.threadhistoryid1) category_cnt,
                mm.category, mm.subcategory
                FROM (
                    SELECT threadid, threadhistoryid1,
                    dtm1 dtm, departmentid1 departmentid, locale1 locale, category, subcategory, officeid1 officeid, offline
                    FROM tmp_stats_threadhistory2
                    WHERE
                        state1 IN ("closed")
                        AND event1 <> "sys.auto_close" AND dtm1 BETWEEN :start AND :end
                ) mm
                WHERE 1 = 1
            ',
            'params' => array(
                array('name' => 'category', 'modes' => 'categories', 'value_src' => 'category_cnt', 'additionalFields' => array('category' => 'category', 'subcategory' => 'subcategory'))
            )
        );

        $this->statsQueryConfigs[] = array(
            'sql' => "
                COUNT(DISTINCT mm.threadhistoryid1) department_cnt,
                mm.departmentid
                FROM (
                    SELECT threadid, threadhistoryid1,
                    dtm1 dtm, departmentid1 departmentid, locale1 locale, category, subcategory, officeid1 officeid, offline
                    FROM tmp_stats_threadhistory2
                    WHERE
                        dtm1 >= :start
                        AND state1 in ('offline_queue', 'queue')
                        and (event1 is null or event1 <> 'sys.unassign')
                        and operatorid1 is null
                ) mm
                WHERE 1 = 1
            ",
            'params' => array(
                array('name' => 'department', 'modes' => array('departments_online', 'departments_offline'), 'value_src' => 'department_cnt', 'additionalFields' => array('departmentid' => 'departmentid_data'))
            )
        );

        $this->statsQueryConfigs[] = array(
            'sql' => "
                COUNT(DISTINCT mm.threadhistoryid1) department_first_cnt,
                mm.departmentid
                FROM (
                    SELECT threadid, threadhistoryid1,
                    dtm1 dtm, departmentid1 departmentid, locale1 locale, category, subcategory, officeid1 officeid, offline
                    FROM tmp_stats_threadhistory2
                    WHERE
                        dtm1 >= :start
                        AND number1 = 1
                        AND state1 in ('offline_queue', 'queue')
                        and (event1 is null or event1 <> 'sys.unassign')
                        and operatorid1 is null
                ) mm
                WHERE 1 = 1
            ",
            'params' => array(
                array('name' => 'department_first', 'modes' => array('departments_online', 'departments_offline'), 'value_src' => 'department_first_cnt', 'additionalFields' => array('departmentid' => 'departmentid_data'))
            )
        );

        $this->statsQueryConfigs[] = array(
            'sql' => '
                COUNT(DISTINCT mm.threadhistoryid1) department_closed,
                mm.departmentid
                FROM (
                    SELECT threadid, threadhistoryid1,
                    dtm1 dtm, departmentid1 departmentid, locale1 locale, category, subcategory, officeid1 officeid, offline
                    FROM tmp_stats_threadhistory2
                    WHERE
                        dtm1 >= :start
                        AND state1 = "closed" AND event1 <> "sys.auto_close"
                ) mm
                WHERE 1 = 1
            ',
            'params' => array(
                array('name' => 'department_closed', 'modes' => array('departments_online', 'departments_offline'), 'additionalFields' => array('departmentid' => 'departmentid_data'))
            )
        );

       $this->statsQueryConfigs[] = array(
            'sql' => '
                SUM(UNIX_TIMESTAMP(dtm2) - UNIX_TIMESTAMP(dtm1)) operator_avg_common_queue_waiting_time_sum,
                COUNT(distinct threadhistoryid1) operator_avg_common_queue_waiting_time_cnt,
                departmentid
                FROM (
                    SELECT th1.threadid, th1.threadhistoryid1 threadhistoryid1, th1.dtm1 dtm1, th1.dtm2 dtm2, th1.dtm1 dtm,
                    th1.departmentid1 departmentid, th1.locale1 locale, th1.category, th1.subcategory, th1.officeid1 officeid, th1.offline
                    FROM tmp_stats_threadhistory2 th1
                    LEFT OUTER JOIN tmp_stats_threadhistory2 th2 ON th1.threadid = th2.threadid AND th2.number1 = th1.number1 + 1
                    WHERE
                        th1.dtm1 >= :start
                        AND th1.state1 = "queue"
                        AND th1.operatorid1 IS NULL
                        AND (th1.state2 = "chatting" or th1.state2 = "queue" and th2.state2 = "chatting")
                ) mm
                WHERE 1 = 1
            ',
            'params' => array(
                array('name' => 'operator_avg_common_queue_waiting_time_sum', 'modes' => array('departments_online', 'departments_offline'), 'additionalFields' => array('departmentid' => 'departmentid_data')),
                array('name' => 'operator_avg_common_queue_waiting_time_cnt', 'modes' => array('departments_online', 'departments_offline'), 'additionalFields' => array('departmentid' => 'departmentid_data'))
            )
        );

        $this->statsQueryConfigs[] = array(
            'sql' => '
                COUNT(DISTINCT mm.threadhistoryid1) geo_cnt,
                mm.country, mm.city, mm.region
                FROM (
                    SELECT threadid, threadhistoryid1,
                    dtm1 dtm, departmentid1 departmentid, locale1 locale, category, subcategory , officeid1 officeid, offline, country, region, city
                    FROM tmp_stats_threadhistory2
                    WHERE
                        state1 IN ("closed")
                        AND event1 <> "sys.auto_close"
                        AND dtm1 >= :start
                ) mm
                WHERE 1 = 1
            ',
            'params' => array(
                array('name' => 'geo', 'modes' => 'geo', 'value_src' => 'geo_cnt', 'additionalFields' => array('country' => 'country', 'region' => 'region', 'city' => 'city'))
            )
        );

        $this->statsQueryConfigs[] = array(
            'sql' => '
                COUNT(DISTINCT mm.threadhistoryid1) startpage_cnt,
                mm.startpage
                FROM (
                    SELECT threadid, threadhistoryid1,
                    dtm1 dtm, departmentid1 departmentid, locale1 locale, category, subcategory , officeid1 officeid, offline, startpage
                    FROM tmp_stats_threadhistory2
                    WHERE
                        state1 IN ("closed")
                        AND event1 <> "sys.auto_close"
                        AND dtm1 >= :start
                ) mm
                WHERE 1 = 1
            ',
            'params' => array(
                array('name' => 'startpage', 'modes' => 'startpages', 'value_src' => 'startpage_cnt', 'additionalFields' => array('startpage' => 'startpage'))
            )
        );

        $this->statsQueryConfigs[] = array(
            'sql' => '
                COUNT(DISTINCT messageid) visitor_messages
                FROM (
                    SELECT messageid, mm.threadid,
                    mm.created as dtm, th2.operatorid1 operatorid, th2.departmentid1 departmentid, th2.locale1 locale, category, subcategory , officeid1 officeid, offline
                    FROM {message} mm
                    INNER JOIN tmp_stats_threadhistory2 th2 ON th2.threadid = mm.threadid
                    WHERE kind = ' . KIND_USER . '
                    AND mm.created BETWEEN :start AND :end
                ) mm
                WHERE 1=1',
            'params' => array(
                array('name' => 'visitor_messages', 'modes' => array('dates_online', 'hours_online'))
            )
        );

        $this->statsQueryConfigs[] = array(
            'sql' => '
                COUNT(DISTINCT messageid) operator_messages,
                SUM(CHAR_LENGTH(message)) operator_avglen_sum,
                COUNT(messageid) operator_avglen_cnt,
                STD(CHAR_LENGTH(message)) operator_stdlen
                FROM (
                    SELECT messageid, mm.threadid, message,
                    mm.created as dtm, mm.operatorid operatorid, th2.departmentid1 departmentid, th2.locale1 locale, category, subcategory, officeid1 officeid, offline
                    FROM {message} mm
                    INNER JOIN tmp_stats_threadhistory2 th2 ON th2.threadid = mm.threadid
                    WHERE kind = '. KIND_AGENT . '
                    AND mm.created BETWEEN :start AND :end
                ) mm
                WHERE 1=1',
            'params' => array(
                array('name' => 'operator_messages', 'modes' => array('dates_online', 'dates_offline', 'hours_online', 'hours_offline', 'operators')),
                array('name' => 'operator_avglen_sum', 'modes' => 'operators'),
                array('name' => 'operator_avglen_cnt', 'modes' => 'operators')
            )
        );

        $this->statsQueryConfigs[] = array(
            'sql' => '
                COUNT(DISTINCT messageid) avg_message_answer_time_cnt,
                SUM(UNIX_TIMESTAMP(dtm2) - UNIX_TIMESTAMP(dtm1)) avg_message_answer_time_sum
                FROM (
                    SELECT mm1.messageid, mm1.threadid,
                    mm1.created as dtm1, MIN(mm2.created) as dtm2,
                    mm1.created as dtm, mm2.operatorid operatorid, th2.departmentid1 departmentid, th2.locale1 locale, category, subcategory, officeid1 officeid, offline
                    FROM {message} mm1
                    INNER JOIN {message} mm2 ON mm1.threadid = mm2.threadid AND mm2.created > mm1.created
                    INNER JOIN tmp_stats_threadhistory2 th2 ON th2.threadid = mm1.threadid
                    WHERE mm2.kind = '. KIND_AGENT . '
                        AND mm1.kind = '. KIND_USER . '
                        AND mm1.created BETWEEN :start AND :end
                        AND mm2.created BETWEEN :start AND :end
                    GROUP BY mm1.messageid
                ) mm
                WHERE 1=1',
            'params' => array(
                array('name' => 'avg_message_answer_time_sum', 'modes' => array('dates_online', 'hours_online')),
                array('name' => 'avg_message_answer_time_cnt', 'modes' => array('dates_online', 'hours_online'))
            )
        );

        $this->statsQueryConfigs[] = array(
            'sql' => '
                COUNT(DISTINCT threadhistoryid1) threads
                FROM (
                    SELECT mm.threadid, mm.threadhistoryid1,
                    mm.dtm1 dtm, mm.operatorid1 operatorid, mm.departmentid1 departmentid, mm.locale1 locale, category, subcategory, officeid1 officeid, offline
                    FROM tmp_stats_threadhistory2 mm
                    WHERE dtm1 >= :start
                        AND number1 = 1
                        AND offline = 0
                ) mm
                WHERE 1=1',
            'params' => array(
                array('name' => 'threads', 'modes' => array('dates_online', 'hours_online'))
            )
        );

        $this->statsQueryConfigs[] = array(
            'sql' => '
                COUNT(DISTINCT threadhistoryid1) new_threads
                FROM (
                    SELECT mm.threadid, threadhistoryid1,
                    mm.dtm1 dtm, mm.operatorid1 operatorid, mm.departmentid1 departmentid, mm.locale1 locale, mm.category, mm.subcategory, mm.officeid1 officeid, mm.offline
                    FROM tmp_stats_threadhistory2 mm
                    INNER JOIN {thread} tt ON tt.threadid = mm.threadid
                    INNER JOIN {visitsession} vs ON vs.visitsessionid = tt.visitsessionid
                    WHERE dtm1 >= :start
                        AND number1 = 1
                        AND NOT EXISTS (
                            SELECT * FROM {visitsession} svs WHERE
                            svs.visitorid = vs.visitorid AND svs.created < vs.created
                        )
                        AND mm.offline = 0
                ) mm
                WHERE 1 = 1',
            'params' => array(
                array('name' => 'new_threads', 'modes' => array('dates_online', 'hours_online'))
            )
        );

        $this->statsQueryConfigs[] = array(
            'sql' => '
                COUNT(DISTINCT threadhistoryid1) quick_answered
                FROM (
                    SELECT mm.threadid, threadhistoryid1,
                    mm.operatorid2 operatorid, mm.dtm2 dtm, mm.departmentid1 departmentid, mm.locale1 locale, category, subcategory, officeid1 officeid, offline
                    FROM tmp_stats_threadhistory2 mm
                    WHERE dtm1 >= :start
                        AND offline = 0
                        AND state1 = "queue" AND state2 = "chatting"
                        AND TIMESTAMPDIFF(SECOND, dtm1, dtm2) <= 20
                        AND threadkind = "chat"
                ) mm
                WHERE 1=1',
            'params' => array(
                array('name' => 'quick_answered', 'modes' => array('dates_online', 'hours_online', 'operators'))
            )
        );

        $this->statsQueryConfigs[] = array(
            'sql' => '
                COUNT(DISTINCT threadhistoryid1) chats
                FROM (
                    SELECT mm.threadid, threadhistoryid1,
                    mm.operatorid1 operatorid, mm.dtm1 dtm, mm.departmentid1 departmentid, mm.locale1 locale, category, subcategory, officeid1 officeid, offline
                    FROM tmp_stats_threadhistory2 mm
                    WHERE dtm1 >= :start
                        AND offline = 0
                        AND state1 in ("closed")
                        AND threadkind = "chat"
                ) mm
                WHERE 1=1',
            'params' => array(
                array('name' => 'chats', 'modes' => array('dates_online', 'hours_online', 'operators'))
            )
        );

        $this->statsQueryConfigs[] = array(
            'sql' => '
                COUNT(DISTINCT threadhistoryid1) answered_in_base
                FROM (
                    SELECT mm.threadid, threadhistoryid1,
                    mm.operatorid1 operatorid, mm.dtm1 dtm, mm.departmentid1 departmentid, mm.locale1 locale, category, subcategory, officeid1 officeid, offline
                    FROM tmp_stats_threadhistory2 mm
                    WHERE dtm1 >= :start
                        AND offline = 0
                        AND state1 IN ("queue")
                        AND state2 IN ("chatting")
                ) mm
                WHERE 1=1',
            'params' => array(
                array('name' => 'answered_in_base', 'modes' => array('dates_online', 'hours_online', 'operators'))
            )
        );

        $this->statsQueryConfigs[] = array(
            'sql' => '
                COUNT(DISTINCT threadhistoryid1) answered_in_10_sec
                FROM (
                    SELECT mm.threadid, threadhistoryid1,
                    mm.operatorid1 operatorid, mm.dtm1 dtm, mm.departmentid1 departmentid, mm.locale1 locale, category, subcategory, officeid1 officeid, offline
                    FROM tmp_stats_threadhistory2 mm
                    WHERE dtm1 >= :start
                        AND offline = 0
                        AND state1 IN ("queue")
                        AND state2 IN ("chatting")
                        AND UNIX_TIMESTAMP(dtm2) - UNIX_TIMESTAMP(dtm1) <= 10 
                ) mm
                WHERE 1=1',
            'params' => array(
                array('name' => 'answered_in_10_sec', 'modes' => array('dates_online', 'hours_online', 'operators'))
            )
        );

        $this->statsQueryConfigs[] = array(
            'sql' => '
                COUNT(DISTINCT threadhistoryid1) answered_in_20_sec
                FROM (
                    SELECT mm.threadid, threadhistoryid1,
                    mm.operatorid1 operatorid, mm.dtm1 dtm, mm.departmentid1 departmentid, mm.locale1 locale, category, subcategory, officeid1 officeid, offline
                    FROM tmp_stats_threadhistory2 mm
                    WHERE dtm1 >= :start
                        AND offline = 0
                        AND state1 IN ("queue")
                        AND state2 IN ("chatting")
                        AND UNIX_TIMESTAMP(dtm2) - UNIX_TIMESTAMP(dtm1) <= 20 
                ) mm
                WHERE 1=1',
            'params' => array(
                array('name' => 'answered_in_20_sec', 'modes' => array('dates_online', 'hours_online', 'operators'))
            )
        );

        $this->statsQueryConfigs[] = array(
            'sql' => '
                COUNT(DISTINCT threadhistoryid1) answered_in_30_sec
                FROM (
                    SELECT mm.threadid, threadhistoryid1,
                    mm.operatorid1 operatorid, mm.dtm1 dtm, mm.departmentid1 departmentid, mm.locale1 locale, category, subcategory, officeid1 officeid, offline
                    FROM tmp_stats_threadhistory2 mm
                    WHERE dtm1 >= :start
                        AND offline = 0
                        AND state1 IN ("queue")
                        AND state2 IN ("chatting")
                        AND UNIX_TIMESTAMP(dtm2) - UNIX_TIMESTAMP(dtm1) <= 30 
                ) mm
                WHERE 1=1',
            'params' => array(
                array('name' => 'answered_in_30_sec', 'modes' => array('dates_online', 'hours_online', 'operators'))
            )
        );

        $this->statsQueryConfigs[] = array(
            'sql' => '
                COUNT(DISTINCT threadhistoryid1) answered_in_40_sec
                FROM (
                    SELECT mm.threadid, threadhistoryid1,
                    mm.operatorid1 operatorid, mm.dtm1 dtm, mm.departmentid1 departmentid, mm.locale1 locale, category, subcategory, officeid1 officeid, offline
                    FROM tmp_stats_threadhistory2 mm
                    WHERE dtm1 >= :start
                        AND offline = 0
                        AND state1 IN ("queue")
                        AND state2 IN ("chatting")
                        AND UNIX_TIMESTAMP(dtm2) - UNIX_TIMESTAMP(dtm1) <= 40 
                ) mm
                WHERE 1=1',
            'params' => array(
                array('name' => 'answered_in_40_sec', 'modes' => array('dates_online', 'hours_online', 'operators'))
            )
        );

        $this->statsQueryConfigs[] = array(
            'sql' => '
                SUM(ABS(UNIX_TIMESTAMP(dtm2) - UNIX_TIMESTAMP(dtm1)))  avg_missed_time_sum,
                COUNT(threadid) avg_missed_time_cnt,
                COUNT(DISTINCT threadid) missed
                FROM (
                    SELECT threadid, dtm1, dtm2,
                    dtm2 dtm, operatorid1 operatorid, departmentid1 departmentid, locale1 locale, category, subcategory, officeid1 officeid, offline
                    FROM tmp_stats_threadhistory2 mm
                    WHERE mm.threadkind = "missed"
                        AND dtm2 < :end
                        AND state1 = "queue"
                        AND state2 = "closed"
                ) mm
                WHERE 1=1',
            'params' => array(
                array('name' => 'missed', 'modes' => array('dates_online', 'hours_online')),
                array('name' => 'avg_missed_time_sum', 'modes' => array('dates_online', 'hours_online')),
                array('name' => 'avg_missed_time_cnt', 'modes' => array('dates_online', 'hours_online'))
            )
        );

        $this->statsQueryConfigs[] = array(
            'sql' => '
                SUM(ABS(UNIX_TIMESTAMP(dtm2) - UNIX_TIMESTAMP(dtm1))) operator_avg_missed_time_sum,
                COUNT(threadid) operator_avg_missed_time_cnt,
                COUNT(DISTINCT threadid) operator_missed
                FROM (
                    SELECT threadid, dtm1, dtm2,
                    dtm2 dtm, operatorid1 operatorid, departmentid1 departmentid, locale1 locale, category, subcategory, officeid1 officeid, offline
                    FROM tmp_stats_threadhistory2 mm
                    WHERE
                        operatorid1 IS NOT NULL
                        AND mm.threadkind = "missed"
                        AND dtm2 < :end
                        AND state1 = "queue"
                        AND state2 = "closed"

                ) mm
                WHERE 1=1',
            'params' => array(
                array('name' => 'operator_missed', 'modes' => array('operators_lost_visitor')),
                array('name' => 'operator_avg_missed_time_sum', 'modes' => array('operators_lost_visitor')),
                array('name' => 'operator_avg_missed_time_cnt', 'modes' => array('operators_lost_visitor'))
            )
        );

        $this->statsQueryConfigs[] = array(
            'sql' => '
                COUNT(DISTINCT threadid) bounce_rate
                FROM (
                    SELECT mm.threadid,
                    mm.operatorid1 operatorid, mm.dtm1 dtm, mm.departmentid1 departmentid, mm.locale1 locale, category, subcategory, officeid1 officeid, offline
                    FROM tmp_stats_threadhistory2 mm
                    WHERE dtm1 >= :start
                        AND offline = 0
                        AND state1 in ("closed")
                        AND threadkind = "bounce"
                ) mm
                WHERE 1 = 1',
            'params' => array(
                array('name' => 'bounce_rate', 'modes' => array('dates_online', 'hours_online'))
            )
        );

        $this->statsQueryConfigs[] = array(
            'sql' => '
                COUNT(DISTINCT threadid) rejected_invitation
                FROM (
                    SELECT mm.threadid,
                    mm.operatorid1 operatorid, mm.dtm1 dtm, mm.departmentid1 departmentid, mm.locale1 locale, category, subcategory, officeid1 officeid, offline
                    FROM tmp_stats_threadhistory2 mm
                    WHERE dtm1 >= :start
                        AND offline = 0
                        AND state1 in ("closed")
                        AND threadkind = "rejected_invitation"
                ) mm
                WHERE 1 = 1',
            'params' => array(
                array('name' => 'rejected_invitation', 'modes' => array('dates_online', 'hours_online', 'operators'))
            )
        );

        $this->statsQueryConfigs[] = array(
            'sql' => '
                COUNT(DISTINCT threadhistoryid1) closed_offlines
                FROM (
                    SELECT mm.threadid, threadhistoryid1,
                    mm.operatorid1 operatorid, mm.dtm1 dtm, mm.departmentid1 departmentid, mm.locale1 locale, category, subcategory, officeid1 officeid, offline
                    FROM tmp_stats_threadhistory2 mm
                    WHERE dtm1 >= :start
                        AND offline = 1
                        AND state1 = "closed" AND not event1 = "sys.auto_close"
                ) mm
                WHERE 1=1',
            'params' => array(
                array('name' => 'closed_offlines', 'modes' => array('dates_offline', 'hours_offline', 'operators'))
            )
        );

        $this->statsQueryConfigs[] = array(
            'sql' => '
                COUNT(DISTINCT threadhistoryid1) closed_onlines
                FROM (
                    SELECT mm.threadid, threadhistoryid1,
                    mm.operatorid1 operatorid, mm.dtm1 dtm, mm.departmentid1 departmentid, mm.locale1 locale, category, subcategory, officeid1 officeid, offline
                    FROM tmp_stats_threadhistory2 mm
                    WHERE dtm1 >= :start
                        AND offline = 0
                        AND state1 = "closed"
                        AND threadkind = "chat"
                ) mm
                WHERE 1=1',
            'params' => array(
                array('name' => 'closed_onlines', 'modes' => array('operators'))
            )
        );

        $this->statsQueryConfigs[] = array(
            'sql' => '
                COUNT(DISTINCT threadhistoryid1) new_offlines_operator
                FROM (
                    SELECT mm.threadid, threadhistoryid1,
                    mm.operatorid1 operatorid, mm.dtm1 dtm, mm.departmentid1 departmentid, mm.locale1 locale, category, subcategory, officeid1 officeid, offline
                    FROM tmp_stats_threadhistory2 mm
                    WHERE dtm1 >= :start
                        AND offline = 1
                        AND event1 = "sys.auto_assign"
                        AND state1 = "offline_queue"
                ) mm
                WHERE 1=1',
            'params' => array(
                array('name' => 'new_offlines_operator', 'modes' => array('dates_offline', 'hours_offline', 'operators'))
            )
        );

        $this->statsQueryConfigs[] = array(
            'sql' => '
                COUNT(DISTINCT threadhistoryid1) new_offlines_queue
                FROM (
                    SELECT mm.threadid, threadhistoryid1,
                    mm.operatorid1 operatorid, mm.dtm1 dtm, mm.departmentid1 departmentid, mm.locale1 locale, category, subcategory, officeid1 officeid, offline
                    FROM tmp_stats_threadhistory2 mm
                    WHERE dtm1 >= :start
                        AND state1 = "offline_queue"
                        and (event1 is null or event1 <> "sys.unassign")
                        AND operatorid1 IS NULL
                ) mm
                WHERE 1=1',
            'params' => array(
                array('name' => 'new_offlines_queue', 'modes' => array('dates_offline', 'hours_offline'))
            )
        );

        $this->statsQueryConfigs[] = array(
            'proc' => 'p_operator_peak',
            'sql' => '
                max(peak) operator_peak
                FROM (
                    SELECT peak, concat(dtm, \' \', hr, \':00\') dtm, :category category, :subcategory subcategory, :officeid officeid, :departmentid departmentid, :locale locale, :offline offline, NULL threadid
                    FROM tmp_stats_operators_peaks_res
                ) mm
                WHERE 1=1',
            'params' => array(
                array('name' => 'operator_peak', 'modes' => array('dates_offline', 'hours_offline', 'dates_online', 'hours_online'))
            )
        );

        $this->statsQueryConfigs[] = array(
            'sql' => '
                SUM(UNIX_TIMESTAMP(dtm2) - UNIX_TIMESTAMP(dtm1)) avg_answer_time_offline_queue_sum,
                COUNT(distinct threadhistoryid1) avg_answer_time_offline_queue_cnt
                FROM (
                    SELECT th1.threadid, threadhistoryid1, dtm1, dtm2,
                    th1.dtm2 dtm, th1.operatorid2 operatorid, th1.departmentid1 departmentid, th1.locale1 locale, th1.category, th1.subcategory, th1.officeid1 officeid, th1.offline
                    FROM tmp_stats_threadhistory2 th1
                    WHERE
                        th1.state1 IN ("offline_queue")
                        AND th1.dtm2 <= :end
                        AND th1.operatorid1 IS NULL
                    ) mm
                WHERE 1=1',
            'params' => array(
                array('name' => 'avg_answer_time_offline_queue_sum', 'modes' => array('dates_offline', 'hours_offline')),
                array('name' => 'avg_answer_time_offline_queue_cnt', 'modes' => array('dates_offline', 'hours_offline')),
            )
        );

        $this->statsQueryConfigs[] = array(
            'sql' => '
                SUM(UNIX_TIMESTAMP(dtm2) - UNIX_TIMESTAMP(dtm1)) avg_answer_time_online_queue_sum,
                COUNT(distinct threadhistoryid1) avg_answer_time_online_queue_cnt
                FROM (
                    SELECT th1.threadid, threadhistoryid1,
                    dtm1, dtm2,
                    th1.dtm2 dtm, th1.operatorid2 operatorid, th1.departmentid1 departmentid, th1.locale1 locale, th1.category, th1.subcategory, th1.officeid1 officeid, th1.offline
                    FROM tmp_stats_threadhistory2 th1
                    WHERE
                        th1.state1 IN ("queue")
                        AND th1.dtm2 <= :end
                        AND th1.operatorid1 IS NULL
                    ) mm
                WHERE 1=1',
            'params' => array(
                array('name' => 'avg_answer_time_online_queue_sum', 'modes' => array('dates_online', 'hours_online')),
                array('name' => 'avg_answer_time_online_queue_cnt', 'modes' => array('dates_online', 'hours_online')),
            )
        );

        $this->statsQueryConfigs[] = array(
            'sql' => '
                sum(tt) visitor_got_answer_time_offline_sum,
                count(distinct threadhistoryid1) visitor_got_answer_time_offline_cnt
                FROM (
                    SELECT mm.threadid, threadhistoryid1, unix_timestamp(m1.created) - unix_timestamp((select m2.created from {message} m2 where m2.threadid=mm.threadid and m2.created < m1.created and m2.kind=' . KIND_USER . ' order by created desc limit 0, 1)) tt,
                    mm.operatorid1 operatorid, m1.created dtm, mm.departmentid1 departmentid, mm.locale1 locale, category, subcategory, officeid1 officeid, offline
                    FROM tmp_stats_threadhistory2 mm
                    INNER JOIN {message} m1 ON m1.threadid=mm.threadid and m1.kind=' . KIND_AGENT . ' AND m1.operatorid IS NOT null
                    WHERE m1.created >= :start AND m1.created < :end
                        AND offline = 1 GROUP BY mm.threadid, m1.messageid
                ) mm
                WHERE 1=1',
            'params' => array(
                array('name' => 'visitor_got_answer_time_offline_sum', 'modes' => array('dates_offline', 'hours_offline', 'operators')),
                array('name' => 'visitor_got_answer_time_offline_cnt', 'modes' => array('dates_offline', 'hours_offline', 'operators'))
            )
        );

        $this->statsQueryConfigs[] = array(
            'proc' => 'p_status_time',
            'sql' => '
                SUM(IF(status IS NULL OR status = "online", period, null)) online_time,
                SUM(IF(status = "dinner", period, null)) dinner_time,
                SUM(IF(status = "coaching_break", period, null)) coaching_break_time,
                SUM(IF(status = "technical_break", period, null)) technical_break_time,
                SUM(IF(status = "meeting_break", period, null)) meeting_break_time,
                SUM(IF(status = "short_break", period, null)) short_break_time,
                SUM(IF(status = "pre_dinner", period, null)) pre_dinner_time,
                SUM(IF(status = "private_break", period, null)) private_time,
                SUM(IF(status = "invisible", period, null)) invisible_time
                FROM (
                    SELECT * , :category category, :subcategory subcategory, :officeid officeid, :departmentid departmentid, :locale locale, NULL threadid, :offline offline
                    FROM tmp_stats_periods_status_res
                ) mm
                WHERE 1=1',
            'params' => array(
                array('name' => 'online_time', 'modes' => 'operators_time'),
                array('name' => 'dinner_time', 'modes' => 'operators_time'),
                array('name' => 'coaching_break_time', 'modes' => 'operators_time'),
                array('name' => 'technical_break_time', 'modes' => 'operators_time'),
                array('name' => 'meeting_break_time', 'modes' => 'operators_time'),
                array('name' => 'short_break_time', 'modes' => 'operators_time'),
                array('name' => 'pre_dinner_time', 'modes' => 'operators_time'),
                array('name' => 'private_time', 'modes' => 'operators_time'),
                array('name' => 'invisible_time', 'modes' => 'operators_time')
            )
        );

        $this->statsQueryConfigs[] = array(
            'proc' => 'p_chats_time2',
            'sql' => '
                SUM(UNIX_TIMESTAMP(dtm2) - UNIX_TIMESTAMP(dtm1)) avg_chatting_time_sum,
                COUNT(distinct threadid) avg_chatting_time_cnt
                FROM (
                    SELECT operatorid, p.dtm1 dtm, p.dtm1, p.dtm2, p.threadid, :departmentid departmentid, :locale locale, :category category, :subcategory subcategory, :officeid officeid, :offline offline
                    FROM tmp_stats_periods_intersected p
                ) mm
                WHERE 1=1',
            'params' => array(
                array('name' => 'avg_chatting_time_cnt', 'modes' => 'operators_time'),
                array('name' => 'avg_chatting_time_sum', 'modes' => 'operators_time')
            )
        );

        $this->statsQueryConfigs[] = array(
            'proc' => 'p_chats_time2',
            'sql' => '
                SUM(period) as chatting_time
                FROM (
                    SELECT period, operatorid, dtm, :departmentid departmentid, :locale locale, :category category, :subcategory subcategory, :officeid officeid, :offline offline, NULL threadid
                    FROM tmp_stats_periods_res p
                    INNER JOIN tmp_stats_periods_intersect i
                        ON p.intersectid = i.id) mm
                    WHERE 1=1',
            'params' => array(
                array('name' => 'chatting_time', 'modes' => 'operators_time')
            )
        );

        $this->statsQueryConfigs[] = array(
            'proc' => 'p_periods_by_chat_count',
            'sql' => '
                SUM(IF(chatcount = 1, period, 0)) one_chat_time,
                SUM(IF(chatcount = 2, period, 0)) two_chats_time,
                SUM(IF(chatcount >= 3, period, 0)) three_and_more_chats_time
                FROM (
                    SELECT TIMESTAMPDIFF(SECOND, dtm1, dtm2) period, chatcount, operatorid, dtm1 dtm, :departmentid departmentid, :locale locale, :category category, :subcategory subcategory, :officeid officeid, :offline offline, NULL threadid
                    FROM tmp_stats_periods_by_chat_count p
                ) mm
                WHERE 1=1',
            'params' => array(
                array('name' => 'one_chat_time', 'modes' => 'operators_time'),
                array('name' => 'two_chats_time', 'modes' => 'operators_time'),
                array('name' => 'three_and_more_chats_time', 'modes' => 'operators_time')
            )
        );

        $this->statsQueryConfigs[] = array(
            'sql' => '
                COUNT(DISTINCT threadid) invited_users1
                FROM (
                    SELECT mm.threadid,
                    mm.dtm1 dtm, mm.operatorid1 operatorid, mm.departmentid1 departmentid, mm.locale1 locale, mm.category, mm.subcategory, officeid1 officeid, :offline offline
                    FROM tmp_stats_threadhistory2 mm
                    WHERE dtm1 >= :start
                        AND number1 = 1
                        AND state1="invitation"
                ) mm
                WHERE 1=1',
            'params' => array(
                array('name' => 'invited_users1', 'modes' => 'operators')
            )
        );

        $this->statsQueryConfigs[] = array(
            'sql' => '
                COUNT(DISTINCT messageid) agentbusy
                FROM (
                    SELECT messageid, mm.threadid, message,
                    mm.created as dtm, th.operatorid1 operatorid, th.departmentid1 departmentid, th.locale1 locale, category, subcategory, th.officeid1 officeid, :offline offline
                    FROM {message} mm
                    INNER JOIN tmp_stats_threadhistory2 th ON th.threadid = mm.threadid
                    WHERE kind = ' . KIND_AGENT_BUSY . '
                    AND mm.created between :start and :end
                ) mm
                WHERE 1=1',
            'params' => array(
                array('name' => 'agentbusy', 'modes' => 'operators')
            )
        );

        $this->statsQueryConfigs[] = array(
            'sql' => '
                SUM(UNIX_TIMESTAMP(dtm2) - UNIX_TIMESTAMP(dtm1)) operator_avg_process_time_offline_sum,
                COUNT(DISTINCT threadhistoryid1) operator_avg_process_time_offline_cnt
                FROM (
                    SELECT th1.threadid, threadhistoryid1, dtm1, dtm2,
                    th1.dtm2 dtm, th1.operatorid2 operatorid, th1.departmentid1 departmentid, th1.locale1 locale, th1.category, th1.subcategory, officeid1 officeid, offline
                    FROM tmp_stats_threadhistory2 th1
                    WHERE
                        th1.state1 IN ("offline_process")
                        AND th1.dtm2 <= :end
                        AND th1.operatorid1 IS NOT NULL
                ) mm
                WHERE 1=1',
            'params' => array(
                array('name' => 'operator_avg_process_time_offline_sum', 'modes' => array('operators')),
                array('name' => 'operator_avg_process_time_offline_cnt', 'modes' => array('operators'))
            )
        );

        $this->statsQueryConfigs[] = array(
            'sql' => '
                SUM(rate + 3) avg_rate_sum,
                sum(if(rate + 3 = 1, 1, null)) rate1_cnt,
                sum(if(rate + 3 = 2, 1, null)) rate2_cnt,
                sum(if(rate + 3 = 3, 1, null)) rate3_cnt,
                sum(if(rate + 3 = 4, 1, null)) rate4_cnt,
                COUNT(rateid) cnt_rate
                FROM (
                    SELECT mm.threadid, rate, r.rateid,
                    r.date dtm, mm.operatorid1 operatorid, mm.departmentid1 departmentid, mm.locale1 locale, category, subcategory, mm.officeid1 officeid, offline
                    FROM tmp_stats_threadhistory2 mm
                    INNER JOIN {rate} r ON r.threadid = mm.threadid and r.operatorid = mm.operatorid1 AND deldate IS NULL
                    WHERE mm.dtm1 >= :start
                    AND r.date >= :start AND r.date < :end
                    GROUP BY mm.threadid, mm.operatorid1, mm.departmentid1, mm.locale1
                ) mm
                WHERE 1=1',
            'params' => array(
                array('name' => 'rate1_cnt', 'modes' => 'operators'),
                array('name' => 'rate2_cnt', 'modes' => 'operators'),
                array('name' => 'rate3_cnt', 'modes' => 'operators'),
                array('name' => 'rate4_cnt', 'modes' => 'operators'),
                array('name' => 'avg_rate_sum', 'modes' => 'operators'),
                array('name' => 'cnt_rate', 'modes' => 'operators')
            )
        );

        $this->statsQueryConfigs[] = array(
            'sql' => '
                COUNT(DISTINCT threadid) transfered_to_another_department
                FROM (
                    SELECT mm.threadid,
                    mm.dtm1 dtm, mm.operatorid1 operatorid, mm.departmentid1 departmentid, mm.locale1 locale, category, subcategory, mm.officeid1 officeid, offline
                    FROM tmp_stats_threadhistory2 mm
                    WHERE IFNULL(mm.departmentid1, 0) <> IFNULL(mm.departmentid2, 0)
                        AND (mm.departmentid1 = :departmentid OR mm.departmentid1 IS NULL AND :departmentid is null)
                        AND threadhistoryid2 is not null
                        AND dtm1 >= :start
                ) mm
                WHERE 1=1',
            'params' => array(
                array('name' => 'transfered_to_another_department', 'modes' => 'operators')
            )
        );

        $this->statsQueryConfigs[] = array(
            'sql' => '
                COUNT(DISTINCT threadid) transfered_from_another_department
                FROM (
                    SELECT mm.threadid,
                    mm.dtm1 dtm, mm.operatorid1 operatorid, mm.departmentid2 departmentid, mm.locale1 locale, category, subcategory, mm.officeid1 officeid, offline
                    FROM tmp_stats_threadhistory2 mm
                    WHERE IFNULL(mm.departmentid1, 0) <> IFNULL(mm.departmentid2, 0)
                        AND (mm.departmentid2 = :departmentid OR mm.departmentid2 IS NULL AND :departmentid is null)
                        AND threadhistoryid2 is not null
                        AND dtm1 >= :start
                ) mm
                where 1=1',
            'params' => array(
                array('name' => 'transfered_from_another_department', 'modes' => 'operators')
            )
        );

        $this->statsQueryConfigs[] = array(
            'sql' => '
                SUM(UNIX_TIMESTAMP(dtm2) - UNIX_TIMESTAMP(dtm1)) avg_intercepted_time_sum,
                COUNT(DISTINCT threadid) intercepted,
                COUNT(threadid) avg_intercepted_time_cnt
                FROM (
                    SELECT mm.threadid, dtm1, dtm2,
                    dtm1 dtm, cop.operatorid operatorid, departmentid1 departmentid, mm.locale1 locale, category, subcategory, mm.officeid1 officeid, offline
                    FROM tmp_stats_threadhistory2 mm
                    LEFT OUTER JOIN {onlineperiod} cop
                        ON (mm.dtm1 between cop.dtmfrom AND cop.dtmto)
                        AND cop.dtmfrom > DATE_SUB(:start, interval 2 day)
                        AND cop.dtmfrom < DATE_ADD(:end, interval 2 day)
                        AND IFNULL(cop.departmentid, 0) = IFNULL(departmentid1, 0)
                    WHERE state1 = "queue" AND state2 = "chatting" AND operatorid2 <> cop.operatorid
                        AND dtm1 >= :start
                ) mm
                where 1=1',
            'params' => array(
                array('name' => 'avg_intercepted_time_sum', 'modes' => 'operators_intercepted_visitor'),
                array('name' => 'avg_intercepted_time_cnt', 'modes' => 'operators_intercepted_visitor'),
                array('name' => 'intercepted', 'modes' => 'operators_intercepted_visitor')
            )
        );

        $this->statsQueryConfigs[] = array(
            'sql' => "
                COUNT(DISTINCT threadhistoryid1) office_cnt,
                mm.officeid
                FROM (
                    SELECT threadid, threadhistoryid1,
                    dtm1 dtm, departmentid1 departmentid, locale1 locale, category, subcategory, officeid1 officeid, offline
                    FROM tmp_stats_threadhistory2
                    WHERE
                        dtm1 BETWEEN :start AND :end
                        AND state1 = 'offline_queue'
                        and (event1 is null or event1 <> 'sys.unassign')
                        AND operatorid1 IS null
                ) mm
                WHERE 1 = 1
            ",
            'params' => array(
                array('name' => 'office_cnt', 'modes' => array('offices_online', 'offices_offline'), 'additionalFields' => array('officeid' => 'officeid_data'))
            )
        );

        $this->statsQueryConfigs[] = array(
            'sql' => '
                COUNT(DISTINCT threadhistoryid1) office_closed,
                mm.officeid
                FROM (
                    SELECT threadid, threadhistoryid1,
                    dtm1 dtm, departmentid1 departmentid, locale1 locale, category, subcategory, officeid1 officeid, offline
                    FROM tmp_stats_threadhistory2
                    WHERE
                        dtm1 BETWEEN :start AND :end
                        AND state1 = "closed" AND event1 <> "sys.auto_close"
                ) mm
                WHERE 1 = 1
            ',
            'params' => array(
                array('name' => 'office_closed', 'modes' => array('offices_online', 'offices_offline'), 'additionalFields' => array('officeid' => 'officeid_data'))
            )
        );

        $this->statsQueryConfigs[] = array(
            'sql' => '
                SUM(UNIX_TIMESTAMP(dtm2) - UNIX_TIMESTAMP(dtm1)) operator_avg_queue_waiting_time_offline_sum,
                COUNT(distinct threadhistoryid1) operator_avg_queue_waiting_time_offline_cnt
                FROM (
                    SELECT th1.threadid, threadhistoryid1, dtm1, dtm2,
                    th1.dtm2 dtm, th1.operatorid2 operatorid, th1.departmentid1 departmentid, th1.locale1 locale, th1.category, th1.subcategory, officeid1 officeid, offline
                    FROM tmp_stats_threadhistory2 th1
                    WHERE
                        th1.state1 IN ("offline_queue")
                        AND th1.dtm2 <= :end
                        AND th1.operatorid1 IS NOT NULL
                ) mm
                WHERE 1=1',
            'params' => array(
                array('name' => 'operator_avg_queue_waiting_time_offline_sum', 'modes' => array('operators', 'dates_offline', 'hours_offline')),
                array('name' => 'operator_avg_queue_waiting_time_offline_cnt', 'modes' => array('operators', 'dates_offline', 'hours_offline')),
            )
        );

        $this->statsQueryConfigs[] = array(
            'sql' => '
                SUM(UNIX_TIMESTAMP(dtm2) - UNIX_TIMESTAMP(dtm1)) operator_avg_queue_waiting_time_online_sum,
                COUNT(distinct threadhistoryid1) operator_avg_queue_waiting_time_online_cnt
                FROM (
                    SELECT th1.threadid, threadhistoryid1, dtm1, dtm2,
                    th1.dtm2 dtm, th1.operatorid2 operatorid, th1.departmentid1 departmentid, th1.locale1 locale, th1.category, th1.subcategory, officeid1 officeid, offline
                    FROM tmp_stats_threadhistory2 th1
                    WHERE
                        th1.state1 IN ("queue")
                        AND th1.state2 IN ("chatting")
                        AND th1.operatorid2 IS NOT NULL
                        AND th1.dtm2 <= :end
                ) mm
                WHERE 1=1',
            'params' => array(
                array('name' => 'operator_avg_queue_waiting_time_online_sum', 'modes' => array('operators', 'dates_online', 'hours_online')),
                array('name' => 'operator_avg_queue_waiting_time_online_cnt', 'modes' => array('operators', 'dates_online', 'hours_online')),
            )
        );
    }

    public function getStats($reportName, array $filters, array $accountParams = array(), array $extFields = array(), $isDaily = FALSE) {
        $this->setupStatsThreadsToFilter($filters, $accountParams);

        $stats = array();
        $reportConfigs = $this->filterAccountIncludedQueryConfigs(
            $this->getQueryConfigsByMode($reportName), $accountParams
        );

        $additionalGroupBy = array();
        $keyFields = $this->reportName2GroupFields[$reportName];
        if ($isDaily) {
            $additionalGroupBy[] = 'd';
            $keyFields[] = 'd';
        }
        foreach ($reportConfigs as $config) {
            $pAccountParams = $accountParams;
            if (!empty($config['proc'])) {
                unset($pAccountParams['timezone']);
            }
            $query = $this->makeStatsQuery($config['sql'], $reportName, $filters, $additionalGroupBy, $pAccountParams);

            $this->ensureProcIsInvoked($config, array(
                'start' => $filters['date_range']['start'],
                'end' => $filters['date_range']['end'],
                'departmentid' => $filters['department'],
                'locale' => $filters['locale']
            ));
            $addStats = $this->queryArrayOfRows($query['sql'], $query['params']);

            if (empty($stats) && !$this->isEmptyStats($addStats)) {
                $stats = $addStats;
            } elseif (!$this->isEmptyStats($addStats)) {
                $this->mergeByFields($addStats, $stats, $keyFields);
            }
        }

        return $this->statsPostProcess($reportName, $stats, $extFields, $isDaily);
    }

    public function statsPostProcess($reportName, array $stats, array $extFields = array(), $isDaily = FALSE) {
        if ($isDaily || strpos($reportName, 'operators') === 0) {
            return $this->mergeByFields($extFields, $stats, $this->reportName2GroupFields[$reportName], TRUE);
        } else {
            return $this->mergeByFields($stats, $extFields, $this->reportName2GroupFields[$reportName]);
        }
    }

    public function makeStatsQuery($baseSQL, $mode, array $filters, array $additionGroupBy = array(), array $accountParams = array()) {
        $params = array(
            'start' => clone $filters['date_range']['start'],
            'end' => clone $filters['date_range']['end'],
            'auto_assign' => !empty($accountParams['auto_assign']) ? 1 : 0
        );
        $params['start']->setTime(0,0,0);
        $params['end']->setTime(23,59,59);

        $dateField = 'dtm';
        if (!empty($accountParams['timezone'])) {
            $timeOffset = Account::getInstance()->calcTimeOffset($params['start']);
            if (!empty($timeOffset)) {
                $dateField = 'DATE_ADD(dtm, INTERVAL :time_offset SECOND)';
                $params['time_offset'] = $timeOffset;

                if ($timeOffset > 0) {
                    $params['start']->add(new DateInterval('PT' . $timeOffset . 'S'));
                    $params['end']->add(new DateInterval('PT' . $timeOffset . 'S'));
                } else {
                    $params['start']->sub(new DateInterval('PT' . -$timeOffset . 'S'));
                    $params['end']->sub(new DateInterval('PT' . -$timeOffset . 'S'));
                }
            }
        }

        $queryParts = array(
            'addFields' => array(
                'GROUP_CONCAT(DISTINCT mm.threadid) threadids',
                'DATE(' . $dateField . ') d',
                'HOUR(' . $dateField . ') h',
                'offline offline'
            ),
            'andWhere' => array(),
            'groupBy' => array(),
        );

        if (in_array($mode, array('operators', 'operators_time', 'operators_lost_visitor', 'operators_intercepted_visitor'))) {
            $queryParts['addFields'][] = 'operatorid';
            $queryParts['andWhere'][] = 'operatorid IS NOT NULL';
        }

        foreach (array(
                     'department' => 'departmentid1',
                     'office' => 'officeid1',
                     'locale' => 'locale',
                     'category' => 'category',
                     'subcategory' => 'subcategory') as $filterKey => $fieldName) {
            $value = array_key_exists($filterKey, $filters) ? $filters[$filterKey] : NULL;
            $params[$fieldName] = $value;
            $params[$filterKey . 'id'] = $value;
        }

        $params['offline'] = NULL;
        if (strpos($mode, '_offline')) {
            $queryParts['andWhere'][] = 'mm.offline = 1';
            $params['offline'] = 1;
        } elseif (strpos($mode, '_online')) {
            $queryParts['andWhere'][] = 'mm.offline = 0';
            $params['offline'] = 0;
        }

        $queryParts['groupBy'] = array_merge(
            $queryParts['groupBy'],
            $this->reportName2GroupFields[$mode]
        );

        if (!empty($additionGroupBy)) {
            $queryParts['groupBy'] = array_merge($additionGroupBy, $queryParts['groupBy']);
        }

        $sql = 'SELECT '
            . (!empty($queryParts['addFields']) ? implode(', ', $queryParts['addFields']) . ', ' : '')
            . $baseSQL
            . (!empty($queryParts['andWhere']) ? ' AND ' . implode(' AND ', $queryParts['andWhere']) : '')
            . (!empty($queryParts['groupBy']) ? ' GROUP BY ' . implode(', ', $queryParts['groupBy']) : '');

        return array(
            'sql' => $sql,
            'params' => $params
        );
    }

    public function setupStatsThreadsToFilter(array $filters, array $accountParams = array()) {
//        var_dump($filters);
//        die();
        static $setupThreadsToFilterLastFill;
        $params = array(
            'start' => clone $filters['date_range']['start'],
            'end' => clone $filters['date_range']['end']
        );
        $params['start']->setTime(0,0,0);
        $params['end']->setTime(23,59,59);

        $timeOffset = 0;
        if (!empty($accountParams['timezone'])) {
            $timeOffset = Account::getInstance()->calcTimeOffset($params['start']);
        }
        if (!empty($timeOffset)) {
            if ($timeOffset > 0) {
                $params['start']->add(new DateInterval('PT' . $timeOffset . 'S'));
                $params['end']->add(new DateInterval('PT' . $timeOffset . 'S'));
            } else {
                $params['start']->sub(new DateInterval('PT' . -$timeOffset . 'S'));
                $params['end']->sub(new DateInterval('PT' . -$timeOffset . 'S'));
            }
        }


        $key = serialize($filters);

        if ($setupThreadsToFilterLastFill == $key) {
            return;
        }

        $this->Query('TRUNCATE tmp_stats_threadhistory2');

        $threadWhere = defined('STATS_DEBUG_THREAD_IDS') ? ' AND h1.threadid IN (' . STATS_DEBUG_THREAD_IDS . ')  ' : '';
        $sqls = array('
        INSERT INTO tmp_stats_threadhistory2 (threadid, threadhistoryid1, number1, dtm1_trim, state1, operatorid1, departmentid1, event1, locale1, threadhistoryid2, number2, dtm2_trim, state2, operatorid2, departmentid2, event2, locale2, dtm1, dtm2, category, subcategory, offline, country, region, city, officeid1, officeid2, startpage, threadkind)
                    SELECT
                        h1.threadid,
                        h1.threadhistoryid       threadhistoryid1,
                        h1.number                number1,
                        GREATEST(IFNULL(h1.dtm, :start), :start) dtm1_trim,
                        h1.state                 state1,
                        h1.operatorid            operatorid1,
                        h1.departmentid          departmentid1,
                        h1.event                 event1,
                        h1.locale                locale1,
                        h2.threadhistoryid       threadhistoryid2,
                        h2.number                number2,
                        LEAST(IFNULL(h2.dtm, NOW()), :end)      dtm2_trim,
                        h2.state                 state2,
                        h2.operatorid            operatorid2,
                        h2.departmentid          departmentid2,
                        h2.event                 event2,
                        h2.locale                locale2,
                        h1.dtm                   dtm1,
                        h2.dtm                   dtm2,
                        category,
                        subcategory,
                        offline,
                        country,
                        region,
                        city,
                        h1.officeid             officeid1,
                        h2.officeid             officeid2,
                        t.startpage,
                        t.threadkind
                    FROM chatthreadhistory h1
                    INNER JOIN chatthreadhistory h2 ON h1.threadid = h2.threadid AND h2.number = h1.number + 1
                    STRAIGHT_JOIN chatthread t ON t.threadid = h1.threadid
                    LEFT JOIN chatvisitsession s ON t.visitsessionid = s.visitsessionid
                    WHERE t.threadkind <> "skip" AND t.threadkind IS NOT NULL AND
                        1 = 1 ' . $threadWhere . ' AND 
                        (h1.dtm <= :end AND :start <= h2.dtm)
        ', 'SELECT
                        h1.threadid,
                        h1.threadhistoryid       threadhistoryid1,
                        h1.number                number1,
                        GREATEST(IFNULL(h1.dtm, :start), :start) dtm1_trim,
                        h1.state                 state1,
                        h1.operatorid            operatorid1,
                        h1.departmentid          departmentid1,
                        h1.event                 event1,
                        h1.locale                locale1,
                        h2.threadhistoryid       threadhistoryid2,
                        h2.number                number2,
                        LEAST(IFNULL(h2.dtm, NOW()), :end)      dtm2_trim,
                        h2.state                 state2,
                        h2.operatorid            operatorid2,
                        h2.departmentid          departmentid2,
                        h2.event                 event2,
                        h2.locale                locale2,
                        h1.dtm                   dtm1,
                        h2.dtm                   dtm2,
                        category,
                        subcategory,
                        offline,
                        country,
                        region,
                        city,
                        h1.officeid             officeid1,
                        h2.officeid             officeid2,
                        t.startpage,
                        t.threadkind
                    FROM chatthreadhistory h1
                    LEFT OUTER JOIN chatthreadhistory h2 ON h1.threadid = h2.threadid AND h2.number = h1.number + 1
                    INNER JOIN chatthread t ON t.threadid = h1.threadid
                    LEFT JOIN chatvisitsession s ON t.visitsessionid = s.visitsessionid
                    WHERE t.threadkind <> "skip" AND t.threadkind IS NOT NULL AND
                        1 = 1 ' . $threadWhere . ' AND 
                        (h2.dtm IS NULL AND h1.dtm BETWEEN :start AND :end)');


        $andFilter = '';
        foreach (array(
                            'department' => 'departmentid',
                            'office' => 'officeid') as $filterKey => $fieldName) {
            if (empty($filters[$filterKey])) {
                continue;
            }
            $value = $filters[$filterKey];
            $params[$fieldName] = $value;
            $andFilter .= ' AND (h1.' . $fieldName . ' = :' . $fieldName . ' OR EXISTS (
                           SELECT * FROM chatthreadhistory h3
                           WHERE h3.threadid = h1.threadid
                               AND h3.' . $fieldName . ' = :' . $fieldName . '
                       ))';
        }

        foreach (array(
                     'locale' => 'locale',
                     'category' => 'category',
                     'subcategory' => 'subcategory') as $filterKey => $fieldName) {
            if (empty($filters[$filterKey])) {
                continue;
            }
            $value = $filters[$filterKey];
            $params[$fieldName] = $value;
            $andFilter .= ' AND t.' . $fieldName . ' = :' . $fieldName;
        }

        foreach ($sqls as &$partSql) {
            $partSql .= $andFilter;
        }

        $sql = implode(PHP_EOL . ' UNION ' . PHP_EOL, $sqls);

        global $LAST_QUERY;
        $this->Query($sql,
            $params, FALSE, TRUE);
        $setupThreadsToFilterLastFill = $key;

        $logId = MapperFactory::getStatsLogMapper()->insertLogItem($LAST_QUERY);
        MapperFactory::getStatsMapper()->setLogId($logId);
    }


    public function ensureProcIsInvoked(array $queryConfig, array $params = array()) {
        static $ensureProcIsInvokedLastInvoke;
        $key = serialize(array('query' => $queryConfig, 'params' => $params));
        if ($key == $ensureProcIsInvokedLastInvoke) {
            return;
        }

        $params['time_offset'] = Account::getInstance()->calcTimeOffset($params['start']);

        if (!empty($queryConfig['proc'])) {
//            if ($queryConfig['proc'] == 'p_status_time') {
//                $a = 1;
//            }
            in_array($queryConfig['proc'], array('p_chats_time2', 'p_operator_peak', 'p_status_time', 'p_periods_by_chat_count'))
                ? $this->db->Query('call ' . $queryConfig['proc'] . ' (:start, :end, :departmentid, :locale, :time_offset)', $params)
                : $this->db->Query('call ' . $queryConfig['proc'] . ' (:start, :end, :departmentid, :locale)', $params);
        }

        $ensureProcIsInvokedLastInvoke = $key;

    }

    public function getAccountIncludedQueryConfigs(array $accountParams = array()) {
        return $this->filterAccountIncludedQueryConfigs($this->statsQueryConfigs, $accountParams);
    }

    private function getQueryConfigsByMode($mode) {
        $configs = array();
        foreach ($this->statsQueryConfigs as $config) {
            if (!empty($config['params'])) {
                $modesArr = Helper::getColumnFromArray($config['params'], 'modes');
                $allModes = array();
                foreach ($modesArr as $modes) {
                    $allModes = array_merge($allModes, (array)$modes);
                }
                if (in_array($mode, $allModes)) {
                    $configs[] = $config;
                }
            }
        }

        return $configs;
    }

    private function filterAccountIncludedQueryConfigs(array $configs, array $accountParams = array()) {
        $filteredConfigs = array();
        foreach ($configs as $config) {
            foreach (Helper::getColumnFromArray($config['params'], 'name') as $paramName) {
                if ($this->isParamIncluded($paramName, $accountParams)) {
                    $filteredConfigs[] = $config;
                    break;
                }
            }
        }

        return $filteredConfigs;
    }

    private function mergeByFields(array $source, array &$target, array $fields, $skipNotMerged = FALSE) {
        foreach ($source as $srcRow) {
            foreach ($fields as $field) {
                if (!array_key_exists($field, $srcRow)) {
                    continue 2;
                }
            }

            $merged = FALSE;
            foreach ($target as $key => $trgRow) {
                foreach ($fields as $field) {
                    if (!array_key_exists($field, $trgRow) || $srcRow[$field] != $trgRow[$field]) {
                        continue 2;
                    }
                }

                $target[$key] = array_merge($trgRow, $srcRow);
                $merged = TRUE;
            }

            if (!$merged && !$skipNotMerged) {
                $target[] = $srcRow;
            }
        }

        return $target;
    }

    private function isParamIncluded($paramName, array $accountParams = array()) {
        $includedFields = !empty($accountParams['stats_fields_include']) ? $accountParams['stats_fields_include'] : array();
        $excludedFields = !empty($accountParams['stats_fields_exclude']) ? $accountParams['stats_fields_exclude'] : array();

        $fName = preg_replace('/(_sum|_avg|_std|_cnt)$/', '', $paramName);

//        if ($paramName == 'operator_peak') {
//            $aaa = 1;
//            return isMyIP() || php_sapi_name() === 'cli';
//            return false;
//        }

        if ($paramName == 'startpage') {
            return false;
        }

        $result = true;
        if (!empty($excludedFields)) {
            $result = !in_array($paramName, $excludedFields)  && !in_array($fName, $excludedFields);
        }

        if (!empty($includedFields) && !$result) {
            $result = in_array($paramName, $includedFields) || in_array($fName, $includedFields);
        }

        return $result;
    }

//    public static function calcTimeOffset($timezone, DateTime $date) {
//        $baseTimezone = new DateTimeZone(date_default_timezone_get());
//        $accountTimezone = new DateTimeZone($timezone);
//        $timeOffset = $accountTimezone->getOffset($date) - $baseTimezone->getOffset($date);
//
//        return $timeOffset;
//    }

    private function isEmptyStats($stats) {
        foreach ($stats as $row) {
            foreach ($row as $field) {
                if (!empty($field)) {
                    return FALSE;
                }
            }
        }
        return TRUE;
    }
}
