<?php
require_once (__DIR__ . '/class.basemapper.php');

class OperatorLastAccessMapper extends BaseMapper {
    public function save($data) {
        $result = parent::save($data);
        return $result;
    }

    public function delete($id) {
        $data = parent::getById($id);
        $result = parent::delete($id);
        return $result;
    }

    public function __construct($model_name) {
        parent::__construct($model_name, array("lastvisited"), false, "operatorid");
    }

    public function enumByOperatorsId(array $operatorIds) {
        $result = array();
        if (!empty($operatorIds)) {
            $result = $this->makeSearch('operatorid IN (:operatorids)', array('operatorids' => $operatorIds));
        }

        return $result;
    }
}