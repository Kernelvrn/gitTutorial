<?php
require_once(dirname(__FILE__) . '/class.basemapper.php');

class ConfigMapper extends BaseMapper {

    public function __construct($model_name) {
        parent::__construct($model_name, array(), false, "configkey");
    }

    public function enumPairs() {
        $r = $this->getAll();
        $result = array();
        foreach ($r as $v) {
            $result[$v['configkey']] = $v['configvalue'];
        }

        return $result;
    }


}

?>