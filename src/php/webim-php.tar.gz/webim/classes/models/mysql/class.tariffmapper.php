<?php
require_once dirname(__FILE__) . '/class.basemapper.php';

class TariffMapper extends BaseMapper {
  public function __construct($model_name) {
    parent::__construct($model_name);
  }

  public function getDatabaseKey() {
    return 'operators';
  }

  public function getDiscounts() {
    $sql = "select value from globalsettings where name='tariff_discount_by_month'";
    $arr = $this->db->queryArrayOfRows($sql);
    return array_shift($arr);
  }

  public function getAccountTariffs($accountName, $tariffKey) {
    $sql = "SELECT * FROM accounttariffview WHERE account_accountname = :accountname and (tariffkey = :tariffkey or tariffkey is null)";
    return $this->db->queryArrayOfRows($sql, array('accountname' => $accountName, 'tariffkey' => $tariffKey));
  }


    public function getPartnerTariffs($partnerName) {
      $sql = "SELECT t1.tariffkey, t1.descriptor FROM tariff AS t1
                INNER JOIN tariff AS t2 ON t1.tariffkey = t2.tariffkey
                WHERE isnull(t1.accountname) AND isnull(t1.accountname) AND isnull(t1.partner) AND t2.partner = :partnername";
      $this->db->Query($sql, array('partnername' => $partnerName));
      $arr = $this->db->getArrayOfRows();
      return $arr;
    }

    public function getAccountWithTariff($accountName) {
      $sql = "SELECT * FROM account a
                INNER JOIN tariffwithaccountandpartnerlevelview t ON a.tariff = t.tariffkey and a.accountname = t.accountname
                WHERE a.accountname = :accountname";
      $arr = $this->db->queryArrayOfRows($sql, array('accountname' => $accountName));

      return array_shift($arr);
    }

}

?>