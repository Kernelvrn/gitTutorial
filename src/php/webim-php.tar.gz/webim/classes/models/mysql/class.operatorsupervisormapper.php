<?php
require_once (dirname(__FILE__) . '/class.basemapper.php');

/**
 * Class for working with operatorsupervisor.
 */
class OperatorSupervisorMapper extends BaseMapper {
  public function __construct($modelName) {
    parent::__construct($modelName, array(), true, 'id');
  }

  protected function getTableNameForQueries() {
    return '`' . $this->getTableName() . '`';
  }

  /**
   * Return array of operator ids was assigned to supervisor.
   *
   * @param $supervisorId Operator-supervisor id
   * @return mixed  Array of ids or null
   */
  public function getAssignedOperatorIds($supervisorId) {
    $result = NULL;
    if (!empty($supervisorId)) {
      $rows = $this->makeSearch('supervisor_id = ?', $supervisorId, 'operator_id');
      if (!empty($rows)) {
        foreach ($rows as $row) {
          $result[] = $row['operator_id'];
        }
      }
    }
    return $result;
  }

  /**
   * Delete records about operators assigned to supervisor.
   *
   * @param $supervisorId Operator-supervisor id
   */
  public function deleteAssignedOperators($supervisorId) {
    $query = 'DELETE FROM ' . $this->getTableNameForQueries() . ' WHERE supervisor_id = "' . $this->db->getEscapedString($supervisorId) . '"';
    $this->db->Query($query);
    return true;
  }
}

?>
