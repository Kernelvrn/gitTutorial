<?php
require_once (dirname(__FILE__) . '/class.basemapper.php');

class RateMapper extends BaseMapper {
    
  public function __construct($model_name) {
 	parent::__construct($model_name, array('date','deldate'));
  }
   
  public function getByThreadidWithOperator($threadid) {
    $query = '
      SELECT r.*, ' . $this->getDateColumnsSql('r') . '
      FROM {rate} as r
      WHERE r.threadid = ? AND r.deldate IS NULL
      ORDER BY r.date';
    $this->db->Query($query, $threadid);
    $rates = $this->db->getArrayOfRows();
    $operators = MapperFactory::getOperatorAccountViewMapper()->listOperatorsByAccount(getAccountId());
    $operatorsAssoc = array();
    foreach ($operators as $operator) {
      $operatorsAssoc[$operator['operatorid']] = $operator;
    }
    foreach($rates as &$rate) {
      $rate['operator'] = !empty($operatorsAssoc[$rate['operatorid']]) ? $operatorsAssoc[$rate['operatorid']]['fullname'] : NULL;
    }
    return  $rates;
  }

    public function getRatesByThreadIds(array $threadIds) {
        $query = '
            SELECT r.*, ' . $this->getDateColumnsSql('r') . '
            FROM {rate} as r
            WHERE r.threadid IN ( :threads ) AND r.deldate IS NULL
            ORDER BY r.date';
        $rates = $this->db->queryArrayOfRows($query, array('threads' => $threadIds));
        $operators = MapperFactory::getOperatorAccountViewMapper()->listOperatorsByAccount(getAccountId());
        $operatorsAssoc = array();
        foreach ($operators as $operator) {
            $operatorsAssoc[$operator['operatorid']] = $operator;
        }
        foreach($rates as &$rate) {
            $rate['operator'] = !empty($operatorsAssoc[$rate['operatorid']]) ? $operatorsAssoc[$rate['operatorid']]['fullname'] : NULL;
        }
        return $rates;
    }

    public function getByThreadId($threadid) {
        $total = 0;
        return $this->makeSearch("threadid = ?", $threadid, null, null, null, $total, array("date", "ASC"));
    }
    
  public function getByThreadidAndOperatorid($threadid, $operatorid) { 
    $r = $this->makeSearch(
    		"threadid = ? AND operatorid = ?",  
            array($threadid, $operatorid)
    );
  	return array_shift($r);
  }

  public function removeRate($rateid) {
    $sql = 'UPDATE {rate} SET deldate=NOW() WHERE rateid=:rateid';
    $this->db->Query($sql, array("rateid" => $rateid));
  }
}

?>
