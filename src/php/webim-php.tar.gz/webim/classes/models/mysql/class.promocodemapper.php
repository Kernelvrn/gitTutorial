<?php
require_once (dirname(__FILE__) . '/class.basemapper.php');
/**
 * Class for working with promocodess.
 */
class PromocodeMapper extends BaseMapper {

    public function __construct($model_name) {
        parent::__construct('promocode', array(), true, 'id', NULL, array(
            array('name' => 'tariff', 'sql' => 'alter table promocode add column tariff varchar(128) CHARACTER SET "utf8" NULL DEFAULT "test"')
        ));
    }

    protected function getTableNameForQueries() {
        return '`' . $this->getTableName() . '`';
    }

    public function getDatabaseKey() {
        return 'operators';
    }

    /**
     * Add unique code into DB
     * @param string $ownerAccountName Partner accountname for added promocode
     * @param int $usageLimit How many times code maybe used
     * @param DateTime $validUntil Before which date code should be used
     * @param int $freePeriod Duration of free test period
     * @return bool
     */
    public function makeAndAddPromocode($ownerAccountName = NULL, $usageLimit = 1, DateTime $validUntil = NULL, $freePeriod = NULL, $tariff = 'test') {
        $data = array(
            'partner_accountname' => !empty($ownerAccountName) ? $ownerAccountName : getAccountId(),
            'promocode' => $this->makeUniqueCode(),
            'usage_limit' => $usageLimit,
            'free_period' => $freePeriod,
            'tariff' => $tariff
        );

        if (!empty($validUntil)) {
            $data['valid_until'] = $validUntil->format('Y-m-d');
        }
        $data['id'] = $this->save($data);
        return $data;
    }

    /**
     * Check that code is exists and can be used for account registering.
     * @param $code
     * @return bool
     */
    public function isCodeAcceptable($code) {
        $promocode = $this->getByCode($code);
        if (!empty($promocode)) {
            return $promocode['usage_limit'] > $this->getCountUsingCode($code)
                && (empty($promocode['valid_until']) || $promocode['valid_until'] > strftime('%Y-%m-%d'));
        }
        return FALSE;
    }

    public function getByCode($code) {
        $promocodes = $this->makeSearch('promocode = :code', array('code' => $code));
        return !empty($promocodes) ? $promocodes[0] : NULL;
    }

    protected function makeUniqueCode() {
        do {
            $code = $this->generateRandomCode();
        } while ($this->codeExists($code));
        return $code;
    }

    protected function codeExists($code) {
        $promocode = $this->getByCode($code);
        return !empty($promocode);
    }

    protected function generateRandomCode($length = 8) {
        $code = '';
        $chars = 'abdefhiknrstyzABDEFGHKNQRSTYZ23456789';
        $countChars = strlen($chars);
        for ($i = 0; $i < $length; $i++) {
            $rand = rand(1,$countChars);
            $code .= substr ($chars, $rand, 1);
        }
        return $code;
    }

    protected function getCountUsingCode($code) {
        return count(MapperFactory::getAccountMapper()->enumAccountsByPromocode($code));
    }
}
?>