<?php
require_once (dirname(__FILE__) . '/class.basemapper.php');

/**
 * Class for working with accounts.
 */
class InvoiceMapper extends BaseMapper {

  public function __construct($model_name) {
    parent::__construct($model_name, array('when', 'paydate'), true, 'id');
  }

  protected function getTableNameForQueries() {
    return '`' . $this->getTableName() . '`';
  }

  public function getDatabaseKey() {
    return 'operators';
  }

  public function enumInvoicesByAccountName($accountName) {
    return $this->makeSearch("pro_payer_accountname = ? and (payment_method <> 'robokassa' or paydate is not null)", $accountName);
  }

  public function enumAllInvoicesByAccountName($accountName) {
    return $this->makeSearch("pro_payer_accountname = ?", $accountName);
  }

  public function getByGuid($guid) {
    $r = $this->makeSearch("guid=?", array($guid));
    return array_shift($r);
  }

  public function getById($id, $select = null) {
     $r = $this->makeSearch("id=?",array($id));
     return array_shift($r);
  }


}

?>
