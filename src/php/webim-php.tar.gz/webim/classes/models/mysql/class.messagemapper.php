<?php
require_once(dirname(__FILE__) . '/class.basemapper.php');

class MessageMapper extends BaseMapper {
    public function __construct($model_name) {
        parent::__construct($model_name, array("created"), TRUE, 'messageid', null,
        array(
            array('name' => 'json', 'sql' => 'ALTER TABLE {message} ADD COLUMN json text;')
        ));
    }

    public function getListMessages($threadId, $sinceId, $forVisitor = false) {
        $where = 'threadid = :threadid and messageid > :sinceid';
        $query_params = array('threadid' => $threadId, 'sinceid' => $sinceId);
        if ($forVisitor) {
            $where .= ' AND kind <> :kind';
            $query_params['kind'] = KIND_FOR_AGENT;
        }

        $total = 0;
        return $this->makeSearch($where,
            $query_params,
            'messageid, kind, unix_timestamp(created) as created, sendername, message, operatorid, json',
            null,
            null,
            $total,
            array('created', 'ASC')
        );
    }

    public function getMessagesByThread(array $threadsId) {
        $where = 'threadid IN (:threads)';
        $queryParams = array(
            'threads' => $threadsId
        );

        return $this->makeSearch($where, $queryParams, 'messageid, kind, unix_timestamp(created) as created, sendername, message, operatorid, threadid, json');
    }

    public function getMessagesByThreadIds(array $threadIds) {
        $sql = 'SELECT *, unix_timestamp(created) as created FROM {message} WHERE threadid IN (:threadIds) ORDER BY created ASC';
        return $this->db->queryArrayOfRows($sql, array('threadIds' => $threadIds));
    }

    public function getVisitorAndOperatorMessages($threadid) {
        return $this->makeSearch('threadid = :threadid and kind in (1,2)' , array('threadid'=>$threadid));
    }

    public function getLastMessageOperatorIdByThread($threadId, $sinceId) {
        $where = 'threadid = :threadid and messageid > :sinceid';
        $query_params = array('threadid' => $threadId, 'sinceid' => $sinceId);
        $total = 0;
        $messages =  $this->makeSearch($where, $query_params, 'operatorid', null, null, $total, array('created', 'ASC'));
        foreach ($messages as $message) {
            if ($message['operatorid']){
                $threadOperatorId = $message['operatorid'];
                break;
            }
        }
        return $threadOperatorId;
    }

    public function removeHistory($threadid) {
        try {
            $this->db->query('DELETE FROM {' . $this->getTableName() . '} WHERE threadid=:threadid', $threadid);
        } catch (Exception $e) {
        }
    }

    public function getLastMessagesTime($threadid) {
        try {
            $this->db->Query("SELECT kind, max( unix_timestamp( created )) as lasttime
            FROM {" . $this->getTableName() . "}
            WHERE threadid=:threadid
            GROUP BY kind", array("threadid" => $threadid));

            $result = array();
            while ($this->db->nextRecord()) {
                $row = $this->db->getRow();
                $result[$row['kind']] = $row['lasttime'];
            }
            return $result;
        } catch (Exception $e) {
        }
    }


    public function getByRangeQuery($startDate, $endDate, $lastSyncedId = null) {
        return new Wrapper_SelectQuery(
            $this->db,
            array(
                'fields' => '*',
                'tables' => $this->getTableNameForQueries(),
                'where' => array(
                    'created BETWEEN :startDate AND :endDate',
                    $lastSyncedId ? 'messageid > :id' : '1=1'
                )
            ),
            array(
                'startDate' => $startDate->format('Y-m-d H:i:s'),
                'endDate' => $endDate->format('Y-m-d H:i:s'),
                'id' => $lastSyncedId
            ),
            array(
                'rowsPerRequest' => 5000
            )
        );
    }
}
