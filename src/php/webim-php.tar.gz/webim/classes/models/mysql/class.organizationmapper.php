<?php
require_once (dirname(__FILE__) . '/class.basemapper.php');

/**
 * Class for working with accounts.
 */
class OrganizationMapper extends BaseMapper {

  public function __construct($model_name) {
    parent::__construct($model_name, array(), true, 'organizationid');
  }

  protected function getTableNameForQueries() {
    return '`' . $this->getTableName() . '`';
  }

  public function getDatabaseKey() {
    return 'operators';
  }

  public function getByAccountName($accountName) {
    $res = $this->makeSearch('accountname = ?', $accountName);
    return array_shift($res);
  }
}

?>
