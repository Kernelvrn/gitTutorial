<?php
require_once (dirname(__FILE__) . '/class.basemapper.php');

/**
 * Class for working with authtokens.
 */
class AuthtokenMapper extends BaseMapper {

  public function __construct($model_name) {
    parent::__construct($model_name, array('created', 'modified'), true, 'id');
  }

  protected function getTableNameForQueries() {
    return '`' . $this->getTableName() . '`';
  }

  public function getDatabaseKey() {
    return 'operators';
  }

  public function addToken($operatorId, $authToken, $userAgent, $persistent = 'false', $created_time = null) {
    $hash = array(
      "operatorid" => $operatorId,
      "authtoken" => $authToken,
      "useragent" => $userAgent,
      "modified" => time(),
      "persistent" => $persistent
    );

    if ($created_time !== null) {
      $hash['created'] = $created_time;
    }
    return $this->save($hash);
  }

  public function getTokenInfo($operatorId, $authToken) {
      $arr = $this->makeSearch('operatorid = :operator AND authtoken = :authtoken',
          array('operator' => $operatorId, 'authtoken' => $authToken));
      $token = array_shift($arr);
    if ($token) {
      $hash = array(
        "id" => $token["id"],
        "modified" => time()
      );
      $this->save($hash);
    }
    return $token;
  }

}

?>
