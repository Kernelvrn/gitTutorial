<?php
require_once (dirname(__FILE__) . '/class.basemapper.php');

/**
 * Class for working with accountsentstats.
 */
class AccountSentStatsMapper extends BaseMapper {
  public function __construct($modelName) {
    parent::__construct($modelName, array('dtm'), true, 'id');
  }

  protected function getTableNameForQueries() {
    return '`' . $this->getTableName() . '`';
  }

  public function getDatabaseKey() {
      return 'operators';
  }

  public function enumAllSentStatsByAccountName($accountName) {
      return $this->makeSearch("accountname = ?", $accountName);
  }

  public function getLastSentTimeForAccount($account) {
      $result = null;
      $data = $this->makeSearch("accountname = ? ORDER BY dtm DESC LIMIT 1", $account);
      if (!empty($data)) {
          $result = $data[0]['dtm'];
      }
      return $result;
  }
}

?>
