<?php
require_once (dirname(__FILE__) . '/class.basemapper.php');

/**
 * Class for working with accounts.
 */
class OperatorAccountViewMapper extends BaseMapper {

  public function __construct($model_name) {
    parent::__construct($model_name, array(), true, 'operatoraccountid', null, array(), array(), array(MapperFactory::getLoginAttemptMapper(), MapperFactory::getAccountKeyValueMapper()));
  }

  public function getAccountsByEmail($email) {
    $total = null;
    return $this->makeSearch("email = :email", array('email' => $email), null, null, null, $total, array('operatoraccountid', 'asc'));
  }

  public function getAccountNameByEmail($email) {
    $accountName = null;
    $accounts = $this->getAccountsByEmail($email);
    if (!empty($accounts)) {
      $accountName = $accounts[0]['accountname'];
    }
    return $accountName;
  }

  public function getAccountsByOperatorId($operatorId) {
    $mapper = &$this;
    return KeyValueCache::getCachedResults($operatorId, 'operators', function() use($operatorId, &$mapper) {
      $total = null;
      return $mapper->makeSearch("operatorid = ?", $operatorId, null, null, null, $total, array('operatoraccountid', 'asc'));
    });
  }

  public function listAccountToFillSip() {
    return $this->makeSearch("sip is null");
  }


  public function getCreatorByAccount($accountName) {
    $res = $this->makeSearch("accountname=:accountname and roles like '%admin%'", array('accountname' => $accountName));
    return empty($res) ? null : $res[0];
  }

  public function getDatabaseKey() {
    return 'operators';
  }

  protected function getTableNameForQueries() {
    return "`" . $this->getTableName() . "`";
  }

  public function getByOperatorIdAndAccount($operatorId, $accountName) {
    $res = $this->makeSearch('operatorid = :operatorid AND accountname = :accountname', array('operatorid' => $operatorId, 'accountname' => $accountName));
    return array_shift($res);
  }

  public function getByOperatorId($operatorId) {
    $res = $this->makeSearch('operatorid = :operatorid', array('operatorid' => $operatorId));
    return array_shift($res);
  }

  public function getByLoginAccountNameAndPassword($login, $accountName, $password) {
    $array = $this->makeSearch('login=:login and accountname=:accountname and password=:password', array('login' => $login, 'accountname' => $accountName, 'password' => $password));
    return array_shift($array);
  }

  public function getAccountAdmin($accountName) {
    return self::__getAccountOperatorByRole($accountName, 'admin');
  }

  public function getAccountOperator($accountName) {
    return self::__getAccountOperatorByRole($accountName, 'operator');
  }

  private function __getAccountOperatorByRole($accountName, $role) {
    $res = $this->makeSearch("accountname=:accountname and roles like '%".$role."%' ", array('accountname' => $accountName));
    return array_shift($res);
  }

  public function getByLoginAndAccountName($login, $accountName) {
    $res = $this->makeSearch('login=:login and accountname=:accountname', array('login' => $login, 'accountname' => $accountName));
    return array_shift($res);
  }

  public function getByEmailAndAccountName($email, $accountName) {
    $res = $this->makeSearch('email=:email and accountname=:accountname', array('email' => $email, 'accountname' => $accountName));
    return array_shift($res);
  }

  public function getMaxOrder($accountName) {
    $row = $this->makeSearch('accountname = ?', array($accountName), "MAX(operatororder) as max_order");
    return $row[0]['max_order'];
  }

  public function listOperatorsByAccount($accountName) {
    return $this->makeSearch('accountname = ?', array($accountName));
  }

  public function getAccountRolesByOperatorId($accountName, $operatorId) {
    $res = $this->makeSearch("operatorid = ? and accountname = ?", array($operatorId, $accountName));
    $r = array_shift($res);
    return explode(',', $r['roles']);
  }

  public function enumOperatorsByAccountAndOffice($accountName, $officeId) {
      return $this->makeSearch('accountname = ? AND officeid = ?', array($accountName, $officeId));
  }

  public function enumOperatorsByAccountAndIds($accountName, array $operatorIds) {
      return !empty($operatorIds)
          ? $this->makeSearch('operatorid IN (:operatorids) AND accountname = :accountname', array('operatorids' => $operatorIds, 'accountname' => $accountName))
          : array();
  }


}

?>
