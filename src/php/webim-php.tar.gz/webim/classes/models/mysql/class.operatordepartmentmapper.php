<?php
require_once (dirname(__FILE__) . '/class.basemapper.php');

class OperatorDepartmentMapper extends BaseMapper {
  public function __construct($model_name) {
    parent::__construct($model_name);
  }
  
  function deleteByOperatorId($operatorid, $include_deleted=false) {
    if ($include_deleted) {
        $this->db->Query('DELETE FROM {operatordepartment} WHERE operatorid = ?', array($operatorid));
    } else {
        $this->db->Query(
            'DELETE od
            FROM {operatordepartment} od
            JOIN {department} d ON od.departmentid=d.departmentid
            WHERE od.operatorid = ? AND d.deleted != 1', array($operatorid));
    }
  }

  function enumDepartmentsWithOperator($operatorid, $locale) {

    $sql = "SELECT *, 
      EXISTS(SELECT * 
        FROM {operatordepartment} od 
        WHERE od.operatorid=:operatorid  
        AND od.departmentid=d.departmentid) AS isindepartment 
      FROM {department} d 
      INNER JOIN {departmentlocale} dl 
      ON d.departmentid=dl.departmentid 
      WHERE locale=:locale";

    $this->db->Query($sql, array('locale' => $locale, 'operatorid' => $operatorid));
    
    return $this->db->getArrayOfRows(); 
  }

  public function enumAvailableDepartmentsForOperators(array $operatorIds, $locale) {
     $sql = '
        SELECT * FROM {department} d
        INNER JOIN {departmentlocale} dl ON d.departmentid=dl.departmentid
        INNER JOIN {operatordepartment} od ON od.departmentid = d.departmentid
        WHERE dl.locale = :locale
          AND od.operatorid IN (:operatorids)';
     return $this->queryArrayOfRows($sql, array('locale' => $locale, 'operatorids' => $operatorIds));
  }
  
  /**
   * Checks, whether operator is in private department
   * Returns department key if operator in private department, false if not
   */
  public function isOperatorInPrivateDepartment($operatorid) {
  	$query = "
  		SELECT 
  			d.departmentkey
  		FROM  
  			{operatordepartment} as od
  		INNER JOIN
  			{department} as d
  		ON
  			od.departmentid = d.departmentid
  		WHERE
  			od.operatorid = ?
  		AND 
  			d.isprivate = 1
  		";
  	try {
  		$this->db->Query($query, array($operatorid));
  		$result = $this->db->getArrayOfRows();
  		return count($result)>0 ? $result[0]['departmentkey'] : false; 
  	} catch (Exception $e) {
  		return false;
  	}
  }
  
  public function isOperatorInDepartment($operatorid, $departmentid) {
    $totalRows = 0;
    $this->makeSearch("operatorid=:operatorid AND departmentid=:departmentid ", array('operatorid' => $operatorid, 'departmentid' => $departmentid), null, 1, null, $totalRows);

    return $totalRows > 0;
  }

  public function getOperatorDepartments($operatorid) {
    return $this->makeSearch("operatorid=:operatorid", array('operatorid' => $operatorid));
  }

  public function enumOperatorsInDepts($depts) {
    $ops = (!empty($depts)) ? $this->makeSearch("departmentid IN (:departmentids)", array('departmentids'=>$depts), 'operatorid') : array();
    return $ops;
  }


  public function getSupervisedDeptsAndOperators($operatorid) {
    $operators = array();
    $departments = array();
    $depts = array();
    $depts = $this->enumOperatorSupervisedDepts($operatorid);
    foreach ($depts as $dept) {
      $departments[] = $dept['departmentid'];
    }
    $ops = $this->enumOperatorsInDepts($departments);
    foreach ($ops as $op) {
      $operators[] = $op['operatorid'];
    }
    return array('depts'=>$departments, 'operators'=>$operators);
  }

  public function enumOperatorSupervisedDepts($operatorid) {
      $result = array();
      if (empty($operatorid)) {
        return $result;
      }
      $result = $this->makeSearch("operatorid=:operatorid AND supervisor = 1", array('operatorid' => $operatorid), 'departmentid');
      return $result;
  }

  public function getOperatorSupervisedDeptsIds($operatorid) {
    if (empty($operatorid)) {
      return false;
    }
    $result = array();
    $depts = $this->makeSearch("operatorid=:operatorid AND supervisor = 1", array('operatorid' => $operatorid), 'departmentid');
    foreach ($depts as $dept) {
      $result[] = $dept['departmentid'];
    }
    return $result;
  }

    public function getDepartmentSupervisorsIds ($departmentid) {
        $sql = "SELECT operatorid FROM {".$this->getTableName()."}
              WHERE departmentid=:departmentid
              AND supervisor=1;";
        try {
            $this->db->Query($sql, array('departmentid'=>$departmentid));
            return $this->db->getArrayOfRows();
        } catch (Exception $e) {
            return array();
        }
    }

  public function checkIfOperatorIsSupervisorInAnotherDepartment($operatorid, $excludedDepartmentId) {
    $sql = "SELECT * FROM {" . $this->getTableName() . "}
            WHERE operatorid=:operatorid
            AND departmentid!=:departmentid
            AND supervisor=1;";

    return $this->db->queryArrayOfRows($sql, array('operatorid' => $operatorid, 'departmentid' => $excludedDepartmentId));
  }

  public function getAllSupervisorIds() {
      $result = array();
      $operators = $this->makeSearch("supervisor = 1", null, 'operatorid');
      foreach ($operators as $operator) {
          $result[] = $operator['operatorid'];
      }
      return $result;
   }


  public function enumDepartmentKeysByOperator($operatorid) {
  	$query = "
  		SELECT 
  			d.departmentkey, d.departmentid 
  		FROM  
  			{operatordepartment} as od
  		INNER JOIN
  			{department} as d
  		ON
  			od.departmentid = d.departmentid
  		WHERE
  			od.operatorid = ?
  		";
  	try {
  		$this->db->Query($query, array($operatorid));
  		return $this->db->getArrayOfRows(); 
  	} catch (Exception $e) {
  		return false;
  	}
  }

    public function enumDepartmentsByOperator($operatorid) {
        $query = '
  		SELECT
  			*
  		FROM
  			{operatordepartment} as od
  		INNER JOIN
  			{department} as d
  		ON
  			od.departmentid = d.departmentid
  		WHERE
  			od.operatorid = ?
  		';
        $this->db->Query($query, array($operatorid));
        return $this->db->getArrayOfRows();
    }

    public function enumDepartmentsListByOperatorIds(array $operatorIds) {
        $result = array();
        if (!empty($operatorIds)) {
            $sql = '
                SELECT operatorid, GROUP_CONCAT(DISTINCT departmentid SEPARATOR ",") department_id_list FROM {operatordepartment}
                WHERE operatorid IN (:operatorids)
                GROUP BY operatorid;
            ';
            $this->db->Query($sql, array('operatorids' => $operatorIds));
            $result = $this->db->getArrayOfRows();
        }

        return $result;
    }
}
?>