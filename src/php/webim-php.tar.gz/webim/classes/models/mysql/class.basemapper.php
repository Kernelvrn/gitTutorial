<?php

abstract class BaseMapper {
  /**
   * @var DBDriver
   */
  protected $db;
  protected $model_name;
  private $id_column;
  private $createSql = null;
  private $columnsToCreate = array();
  private $entitiesToCreate = array();
  private $indexesToCreate = array();

  private $table;
  private $date_columns_names = array();
  private $autoincrement = true;

  public function __construct($model_name, $date_columns_names = array(), $autoincrement = true, $id_column = null, $createSql = null, array $columnsToCreate = array(), array $entitiesToCreate = array(), array $dependsOnMappers = array(), array $indexesToCreate = array(), array $columnsToModify = array()) {
    $this->model_name = $model_name;
    $this->table = strtolower($this->model_name);
    $this->createSql = $createSql;
    $this->columnsToCreate = $columnsToCreate;
    $this->columnsToModify = $columnsToModify;
    $this->entitiesToCreate = $entitiesToCreate;
    $this->indexesToCreate = $indexesToCreate;

    assert("is_array(\$columnsToCreate)");

    if ($id_column !== null) {
      $this->id_column = $id_column;
    } else {
      $this->id_column = $this->table . "id";
    }

    $this->date_columns_names = $date_columns_names;
    $this->autoincrement = $autoincrement;

    $class = "DBDriver" . ucfirst(SITE_DB_TYPE);
    $include_file = dirname(__FILE__) . "/../dbdriver/class." . strtolower($class) . ".php";

    if (!include_once($include_file)) {
      throw new Exception("Couldn't load dbdriver " . $class . " file $include_file");
    }

    $this->db = $class::getDriver($this->getDatabaseKey());
    $this->ensureTableCorrect();
  }

  protected function getDateColumnsNames() {
    return $this->date_columns_names;
  }

  protected function getDateColumnsSql($table_alias = null) {
    $result = "";
    foreach ($this->date_columns_names as $k => $c) {
      if ($k != 0) {
        $result .= ", ";
      }
      if (!$table_alias) {
        $result .= "unix_timestamp(`$c`) as `$c`";
      } else {
        $result .= "unix_timestamp(`$table_alias`.`$c`) as `$c`";
      }
    }

    return $result;
  }

  /**
   * Get object by id
   *
   * @param int $id
   * @param string $select
   * @return array or false on failure
   */
  public function getById($id, $select = null) {
    $r = $this->makeSearch("{$this->id_column}=?", $id, $select, 1);
    return array_shift($r);
  }


  protected function getTableNameForQueries() {
    return "`{" . $this->getTableName() . "}`";
  }

  public function getAll($limit = null, $offset = null, $total = null, $orderby = null) {
    return $this->makeSearch(null, null, null, $limit, $offset, $total, $orderby ?: $this->id_column);
  }


  /**
   * если надо получить количество строк всего с данным условием, например для пейджинга параметр тотал надо передавать по ссылке
   * например
   * $total = 0;
   * $this->makeSearch(null, null, null, null, &$total);
   * данный вызов выберет все строки из табилицы
   * и в переменную $total сохранит их количество
   **/
  public function makeSearch($where = null, $params = null, $select = null, $limit = null, $offset = null, &$total = null, $orderby = null) {
    $query = $this->formatSelect($select);

    $query_add = "";
    if ($where != null) {
      $query_add .= " WHERE " . $where;
    }

    $query .= $query_add;

    if (is_array($orderby) && count($orderby)) {
      $query .= " ORDER BY " . $orderby[0] . " " . $orderby[1];
    }

    if ($limit !== null) {
      $query .= " LIMIT " . $limit;
      if ($offset !== null) {
        $query .= " OFFSET " . $offset;
      }
    }

    $result = $this->queryArrayOfRows($query, $params);

    if ($total !== null) {
      $query = "SELECT COUNT(`{$this->id_column}`) as `total` FROM " . $this->getTableNameForQueries() . $query_add;

      $this->db->Query($query, $params);
      $total = 0;
      $this->db->nextRecord();
      $row = $this->db->getRow();
      $total = $row['total'];
    }

    return $result;
  }

  public function save($data) {
    if ($this->autoincrement) {
      if (isset($data[$this->id_column]) && !empty($data[$this->id_column])) {
        return $this->update($data);
      }
      return $this->add($data);
    } else {
      if (isset($data[$this->id_column]) && !empty($data[$this->id_column])) {
        $r = $this->update($data);
        if ($r > 0) {
          return true;
        }
      }
      return $this->add($data);
    }
  }

  protected function add($data) {
    $fields = "";
    $values = "";
    $update = "";
    $params = array();

    $first = true;
    foreach ($data as $k => $d) {
      if (!$first) {
        $fields .= ", ";
        $values .= ", ";
      }

      $fields .= "`" . $k . "`";


      $values .= ':' . $k;

      if (!$this->autoincrement) {
        if (!$first) {
          $update .= ", ";
        }
        $update .= "`$k`= :" . $k;
      }

      $first = false;
      $d = $this->getValueForParam($k, $d);
      $params[$k] = $d;
    }

    $query = "INSERT INTO " . $this->getTableNameForQueries() . " (" . $fields . ") VALUES (" . $values . ")";
    if (!$this->autoincrement) {
      $query .= " ON DUPLICATE KEY UPDATE $update";
    }

    $this->db->Query($query, $params);

    return $this->db->getInsertId();
  }

  private function getValue($field, $value) { // TODO new one
    if ($value === TRUE) {
      $value = '1';
    } else if ($value === FALSE) {
      $value = '0';
    } else if ($value === null) {
      $value = "NULL";
    } elseif (in_array($field, $this->date_columns_names)) {
      $value = "'" . date(DB_DATETIME_FORMAT, $value) . "'";
    } else {
      $value = "'" . $this->db->getEscapedString($value) . "'";
    }
    return $value;
  }

  private function getValueForParam($field, $value) { // TODO new one
    if ($value === TRUE) {
      $value = 1;
    } elseif ($value === FALSE) {
      $value = 0;
    } elseif (in_array($field, $this->date_columns_names) && $value !== null) {
        $date = new DateTime();
        $date->setTimestamp($value);
        $value = $date;
    }
    return $value;
  }


  protected function update($data) {
    $update = '';
    $first = true;
    $params = array();

    foreach ($data as $k => $d) {
      if ($k == $this->id_column) {
        continue;
      }

      if (!$first) {
        $update .= ", ";
      }

//      $d = $this->getValue($k, $d);
      $d = $this->getValueForParam($k, $d);

      $update .= "`" . $k . "` = :" . $k;
      $params[$k] = $d;
      $first = false;
    }

    $query = "UPDATE " . $this->getTableNameForQueries() . " SET " . $update . " WHERE `{$this->id_column}` = '" . $this->db->getEscapedString($data[$this->id_column]) . "'";

    $this->db->Query($query, $params);

    return $this->db->getNumRows();
  }

  public function delete($id) {
    $query = "DELETE FROM " . $this->getTableNameForQueries() . " WHERE `{$this->id_column}` = '" . $this->db->getEscapedString($id) . "'";

    $this->db->Query($query);

    return true;
  }

  public function startTransaction() {
    $this->db->Query("START TRANSACTION;");
  }

  public function commit() {
    $this->db->Query("COMMIT;");
  }

  public function rollback() {
    $this->db->Query("ROLLBACK;");
  }

  public function getIdColumn() {
    return $this->id_column;
  }

  protected function getTableName() {
    return $this->table;
  }

  public function getDatabaseKey() {
    return 'pro';
  }

  protected function queryArrayOfRows($query, $params = null) {
    return $this->db->queryArrayOfRows($query, $params);
  }

  protected function queryMax($sql, $default = null, $params = array()) {
    $rows = $this->queryArrayOfRows($sql, $params);
    $existingMaxId = null;
    if (!empty($rows) && !empty($rows[0]['maxres'])) {
      return $rows[0]['maxres'];
    }
    return $default;
  }

  protected function Query($sql, $params = null, $skipDbUse = false, $insertQuery = false) {
    return $this->db->Query($sql, $params, $skipDbUse, $insertQuery);
  }

  protected function getEscapedString($strtolower) {
    return $this->db->getEscapedString($strtolower);
  }

  private function ensureDatabaseConnected() {
    if ($this->db !== null) {
      return;
    }

  }

  public function ensureTableCorrect() {
    if ($this->createSql !== null) {
      $this->_ensureTableExists();
    }

    foreach ($this->columnsToCreate as $col) {
      $name = $col['name'];
      $key = $this->table . '-' . $name;
      if (KeyValueCache::get($key, 'created-columns') !== null && !isDevMode()) {
        continue;
      }
      $sql = $col['sql'];

      $tableName = $this->getTableNameForQueries();
      $tableName = str_replace('`', '', $tableName);

      $dbName = $this->db->getDatabaseName();

      $this->db->Query("SELECT *
        FROM information_schema.COLUMNS
        WHERE
          TABLE_SCHEMA = '" . $dbName . "'
        AND TABLE_NAME = '" . $tableName . "'
        AND COLUMN_NAME = '" . $name . "'");

      if ($this->db->getNumRows() != 1) {
        if (!isBigAccount() || isDevMode()) {
          $this->db->Query($sql);
        } else {
          immediatelyNotifyAboutProblem("Trying to create column for big account: " . getAccountId() . " " . $sql);
        }
      }

    KeyValueCache::put($key, true, 'created-columns', -1);

    }

    foreach ($this->columnsToModify as $col) {
      $name = $col['name'];
      $key = $this->table . '-' . $name;
      $modifiedValue = $col['modifiedValue'];
      $cachedValue = KeyValueCache::get($key, 'modified-columns');
      if ($cachedValue !== null && $cachedValue == $modifiedValue && !isDevMode()) {
        continue;
      }

      $sql = $col['sql'];

      if (!isBigAccount() || isDevMode()) {
        $this->db->Query($sql);
      } else {
        immediatelyNotifyAboutProblem("Trying to modify column for big account: " . getAccountId() . " " . $sql);
      }

    KeyValueCache::put($key, $modifiedValue, 'modified-columns', -1);

    }

    $this->_ensureIndexesCreated();

    if (in_array('tmp-tables', $this->entitiesToCreate)) {
      $this->_ensureTmpTablesCreated();
    }
    if (in_array('procedures', $this->entitiesToCreate)) {
      $this->_ensureProcsCreated();
    }
  }

  private function _ensureTableExists() {
    if (KeyValueCache::get($this->table, 'created-tables') !== null) {
      return;
    }
    $tableName = $this->_getTableNameForCreate();
    $this->db->Query("SHOW TABLES LIKE '" . $tableName . "'");
    if ($this->db->getNumRows() != 1) {
      $this->db->Query($this->createSql);
    }
    KeyValueCache::put($this->table, true, 'created-tables', -1);
  }

  /**
   * @param $select
   * @return string
   */
  protected function formatSelect($select = null) {
    $query = "SELECT ";

    if ($select === null) {
      $query .= "*";
      if (count($this->date_columns_names) > 0) {
        $query .= ", " . $this->getDateColumnsSql();
      }
    } else {
      $query .= $select;
    }

    $query .= " FROM " . $this->getTableNameForQueries();
    return $query;
  }

  private function _ensureProcsCreated() {
    $this->_ensureRecreatableEntityCorrect('PROCEDURE', 'install-mysql-procedures.sql');

  }

  private function _ensureTmpTablesCreated() {
    $this->_ensureRecreatableEntityCorrect('TABLE', 'install-mysql-tmp-tables.sql');
  }

  /**
   * @param $entity
   */
  private function _ensureRecreatableEntityCorrect($entity, $fileName) {
    $key = 'tmp-' . $entity . '-created-' . WEBIM_VERSION;
    if (KeyValueCache::get($key, 'created-tmp') !== null) {
      return;
    }

    $content = file_get_contents(dirname(__FILE__) . '/../../../install/sql/'. $fileName);
    $matches = array();
    if (preg_match_all('/CREATE.+' . $entity . '.+?([\w_]+).+/', $content, $matches, PREG_SET_ORDER)) {
        foreach ($matches as $m) {
            $a = 1;
            $this->db->Query("DROP " . $entity . " IF EXISTS " . $this->db->getEscapedString($m[1]));
        }
    }
    $this->db->multiQuery($content);
    KeyValueCache::put($key, time(), 'created-tmp', isDevMode() ? 60 : -1);
  }

  private function _ensureIndexesCreated() {
//    foreach ($this->indexesToCreate as $index) {KeyValueCache::cachableExecute('indexes-created-'. WEBIM_VERSION,
//        function ($bd, $tableName, $index) use ($this->bd, $this->_getTableNameForCreate(), $index) {

    foreach ($this->indexesToCreate as $index) {
      $key = $index['name'] . WEBIM_VERSION;
      if (KeyValueCache::get($key, 'created-indexes') !== null) {
        continue;
      }

      $tableName = $this->_getTableNameForCreate();

      $this->db->Query("SELECT * FROM INFORMATION_SCHEMA.STATISTICS
                    WHERE table_schema=DATABASE() AND TABLE_NAME='" . $tableName . "' AND index_name='" . $index['name'] . "'");
      global $LAST_QUERY;
      if ($this->db->getNumRows() == 0) {
        $this->db->Query($index['sql']);
      }
      KeyValueCache::put($key, time(), 'created-indexes', isDevMode() ? 60 : -1);
    }

//          SELECT * FROM INFORMATION_SCHEMA.STATISTICS
//          WHERE table_schema=DATABASE() AND TABLE_NAME='chatthreadhistory' AND index_name='idx_threadhistory_dtm';
//
//        });
//    }

  }

  /**
   * @return mixed|string
   */
  private function _getTableNameForCreate() {
    $tableName = $this->getTableNameForQueries();
    $tableName = str_replace('`', '', $tableName);
    return $tableName;
  }
}

?>