<?php
require_once (dirname(__FILE__) . '/class.basemapper.php');


class InsalesAccountMapper extends BaseMapper {
    public function __construct($model_name) {
        parent::__construct($model_name, array('dtm_button_code_installed'), true, 'id');
    }

    protected function getTableNameForQueries() {
        return '`' . $this->getTableName() . '`';
    }

    public function getDatabaseKey() {
        return 'operators';
    }

    public function addInsalesAccount($insalesId, $shop, $password, $accountName = null) {
        $insalesData = array('insalesid' => $insalesId,'shop' => $shop, 'password' => $password,
            'accountname' => $accountName);
        $this->save($insalesData);
    }

    public function getByInsalesId($insalesId) {
        $res = $this->makeSearch('insalesid=:insalesid', array('insalesid' => $insalesId));
        return array_shift($res);
    }

}

