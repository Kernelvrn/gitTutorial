<?php
require_once (dirname(__FILE__) . '/class.basemapper.php');

class TimeMapper extends BaseMapper {

  public function __construct($model_name) {
    parent::__construct($model_name, array("created", "till"));
  }
  	
  public function getCurrentTime() {
    $this->db->Query("SELECT unix_timestamp(CURRENT_TIMESTAMP) AS current");
    $this->db->nextRecord();
    $result = $this->db->getRow();
    return $result['current'];
  }
}
?>