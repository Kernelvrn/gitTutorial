<?php
require_once dirname(__FILE__) . '/class.basemapper.php';


class OperatorMapper extends BaseMapper {
  public function __construct($model_name) {
    parent::__construct($model_name, array("recoverytime", "deleted", "passwordmodified"));
  }

  public function getDatabaseKey() {
    return 'operators';
  }

  public function save($data) {
    if (!empty($data['password'])) {
      $data['passwordmodified'] = time();
    }
    $result = parent::save($data);
    return $result;
  }

  public function delete($id) {
//    $result = parent::delete($id);
    $o = $this->getById($id);
    $o['deleted'] = time();
    $result = $this->save($o);

    return $result;
  }




  /* end pb */

  public function getByEmail($email) {
    $r = $this->makeSearch("email = ? and deleted is null", $email, null, 1);
    return array_shift($r);
  }

  public function enumByEmail($email) {
    return $this->makeSearch("email = ? and deleted is null", $email, null, 1);
  }


//  public function getByLoginAndPassword($login, $password) {
//    return array_shift($r = $this->makeSearch("login = ? AND password = MD5(?)", array($login, $password), null, 1));
//  }


  public function createOperator($email, $fullname, $password, $isAccountCreator = FALSE) {
    global $MAIN_SETTINGS;

    $salt = $MAIN_SETTINGS['password_salt'];
    $operatorData = array('email' => $email, 'password' => md5($salt . $password),
      'fullname' => $fullname, 'created' => null, 'subscribed' => $isAccountCreator ? 1 : 0);
    $id = $this->save($operatorData);
    return $this->getById($id);
  }

  /**
   * Return operators participated in thread
   * @param $threadId
   * @return array
   */
  public function enumOperatorsWithStatesByThreadId($threadId) {
    $operatorsWithStates = array();
    $stateAndOperatorIds = MapperFactory::getThreadHistoryMapper()->enumStateAndOperatorIdsByThreadId($threadId);
    $idToStates = array();
    foreach ($stateAndOperatorIds as $stateAndId) {
      $idToStates[$stateAndId['operatorid']][] = $stateAndId['state'];
    }
    $operatorIds = array_keys($idToStates);
    if (!empty($operatorIds)) {
      $operators = $this->makeSearch('operatorid IN (:operatorids)', array('operatorids' => $operatorIds));
      if (!empty($operators)) {
        foreach($operators as $operator) {
          $operatorsWithStates[] = array_merge($operator, array('states' => $idToStates[$operator['operatorid']]));
        }
      }
    }

    return $operatorsWithStates;
  }

  /**
   * Return available operators when was thread
   * @param $threadId
   * @return array
   */
  public function enumOperatorsWereAvailableByThreadId($threadId) {
    $operators = array();
    $operatorIds = MapperFactory::getOnlinePeriodMapper()->enumOperatorIdsWereAvailableByThreadId($threadId);
    if (!empty($operatorIds)) {
      return $this->makeSearch('operatorid IN (:operatorids)', array('operatorids' => $operatorIds));
    }
      return $operators;
  }

    /**
     * Return array of operators by their ids
     * @param array $operatorIds
     * @return array
     */
    public function enumOperatorsWithDeletedByIds(array $operatorIds) {
      $operators = array();
      if (!empty($operatorIds)) {
          $operators = $this->makeSearch('operatorid IN (:operatorids)', array('operatorids' => $operatorIds));
      }

      return $operators;
    }

    public function enumOperatorsByIds(array $operatorIds) {
        $operators = array();
        if (!empty($operatorIds)) {
            $operators = $this->makeSearch('operatorid IN (:operatorids) AND deleted IS NULL', array('operatorids' => $operatorIds));
        }

        return $operators;
    }

}
?>