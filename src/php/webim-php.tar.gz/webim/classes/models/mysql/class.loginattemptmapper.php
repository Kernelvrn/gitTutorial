<?php

class LoginAttemptMapper extends BaseMapper {
    public function __construct($modelName) {
        parent::__construct($modelName, array(), true, 'id',
            "CREATE TABLE loginattempt (
              id INT(11) AUTO_INCREMENT NOT NULL,
              email VARCHAR(255) NOT NULL,
              ip VARCHAR(20) NOT NULL,
              ts bigint(20) NOT NULL,
              accountname VARCHAR(64) DEFAULT NULL,
              failed  tinyint(1) NOT NULL DEFAULT '1',
              PRIMARY KEY (id)
            ) ENGINE=InnoDB DEFAULT CHARSET=utf8"
        );
    }

    public function getDatabaseKey() {
        return 'operators';
    }

    protected function getTableNameForQueries() {
        return '`' . $this->getTableName() . '`';
    }

    public function insertLoginAttempt($email, $ip, $ts, $accountname, $failed) {
        $data = array(
            'email' => $email,
            'ip' => $ip,
            'ts' => $ts,
            'accountname' => $accountname,
            'failed' => $failed
        );
        $this->save($data);
    }

    public function getLoginAttemptsByIp($ip, $failed, $ts=0) {
        $totalRows = 0;
        $this->makeSearch('ip=:ip AND failed=:failed AND ts >:ts', array('ip' => $ip, 'failed' => $failed, 'ts' =>$ts), null, null, null, $totalRows);
        return $totalRows;
    }

    public function getLoginAttemptsByEmail($email, $failed, $ts=0) {
        $totalRows = 0;
        $this->makeSearch('email=:email AND failed=:failed AND ts >:ts', array('email' => $email, 'failed' => $failed, 'ts' =>$ts), null, null, null, $totalRows);
        return $totalRows;
    }

}