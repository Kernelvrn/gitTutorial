<?php
require_once(dirname(__FILE__) . '/class.basemapper.php');
require_once(dirname(__FILE__) . '/../../../autoload.php');

class CallbackMapper extends BaseMapper {
    public function search(array $params = array()) {
        return $this->queryCallbacks($params);
    }

    public function count(array $params = array()) {
        $count = 0;
        $rows = $this->queryCallbacks($params, $isCount = true);
        if ($rows) {
            $count = $rows[0]['c'];
        }

        return $count;
    }

    protected function queryCallbacks(array $filters = array(), $isCount = false) {
        $this->checkAndSetKind(new DateTime());
        $defaultParams = array(
            'pageNum' => 1,
            'dateRange' => array(
                'start' => null,
                'end' => null
            ),
            'types' => null,
            'timezone' => '',
            'itemsPerPage' => DEFAULT_ITEMS_PER_PAGE,
        );
        $params = array_merge($defaultParams, $filters);

        $queryParams = array();
        $queryParts = array(
            'fields' => array(
                'cb.id',
                'unix_timestamp(cb.created) as created',
                'unix_timestamp(cb.modified) as modified',
                'cb.visitorphone',
                'cb.operatorphone',
                'cb.referrerurl',
                'cb.billsec duration',
                'cb.recorduri',
                'cb.kind',
                'v.ip as remote',
                'v.remotehost',
                'v.visitorname',
                'v.json',
                'v.userid'
            ),
            'from' => array(),
            'joins' => array(),
            'where' => array()
        );

        $queryParts['joins'][] = 'LEFT JOIN {visitsession} as v ON v.visitsessionid = cb.visitsessionid';

        $queryParts['from'][] = 'callback as cb';

        $timeOffset = 0;
        if (!empty($params['timezone'])) {
            $baseTimezone = new DateTimeZone(date_default_timezone_get());
            $accountTimezone = new DateTimeZone($params['timezone']);
            if (!empty($params['dateRange']['end'])) {
                $dateObj = clone $params['dateRange']['end'];
            } else {
                $dateObj = new DateTime();
            }
            $timeOffset = $accountTimezone->getOffset($dateObj) - $baseTimezone->getOffset($dateObj);
        }

        if (!empty($params['dateRange']['start'])) {
            $queryParams['start_timestamp'] = $params['dateRange']['start']->getTimestamp() - $timeOffset;
            $queryParts['where'][] = 'cb.created  >= FROM_UNIXTIME(:start_timestamp)';
        }

        if (!empty($params['dateRange']['end'])) {
            $queryParams['end_timestamp'] = $params['dateRange']['end']->getTimestamp() + 24 * 3600 - $timeOffset;
            $queryParts['where'][] = 'cb.created  <= FROM_UNIXTIME(:end_timestamp)';
        }

        $kindWhereParts = array();
        $simpleKinds = array();
        if (!empty($params['types'])) {
            foreach (array_unique($params['types']) as $type) {
                switch (strtolower($type)) {
                    case 'current':
                        $kindWhereParts[] = '(cb.kind IS NULL)';
                        break;
                    case 'success':
                    case 'operator_missed':
                    case 'visitor_missed':
                    case 'visitor_incorrect_number':
                        $simpleKinds[] = $type;
                        break;
                }
            }
        }

        if (!empty($simpleKinds)) {
            $queryParams['kinds'] = $simpleKinds;
            $kindWhereParts[] = '(cb.kind IN (:kinds))';
        }

        if (!empty($kindWhereParts)) {
            $queryParts['where'][] = '(' . implode(' OR ', $kindWhereParts) . ')';
        }

        $queryParams['items_per_page'] = DEFAULT_ITEMS_PER_PAGE;
        $queryParams['offset'] = DEFAULT_ITEMS_PER_PAGE * ($params['pageNum'] - 1);

        if ($isCount) {
            $sql = 'SELECT COUNT(DISTINCT cb.id) c'
                . ' FROM ' . implode(', ', $queryParts['from'])
                . ' ' . implode(' ', $queryParts['joins'])
                . ' WHERE ' . implode(' AND ', $queryParts['where']);
        } else {
            $sql = 'SELECT ' . implode(', ', $queryParts['fields'])
                . ' FROM ' . implode(', ', $queryParts['from'])
                . ' ' . implode(' ', $queryParts['joins'])
                . ' WHERE ' . implode(' AND ', $queryParts['where'])
                . ' ORDER BY cb.created DESC' . ($params['pageNum'] > 0 ? ' LIMIT :offset, :items_per_page' : '');
        }

        return $this->db->queryArrayOfRows($sql, $queryParams);

    }

    protected function checkAndSetKind(DateTime $endDate) {
        $selectSql = '
              SELECT cb.id
              FROM callback cb
              WHERE (cb.kind = "undefined" || cb.kind IS NULL)
                  AND DATE(created) <= :endDate';

        $typesAddWhere = array(
            'success' => '
                EXISTS (
                    SELECT *
                    FROM  callbackhistory cbh
                    WHERE cbh.callbackuid = cb.uid
                          AND cbh.event="callback.visitor_answered" FOR UPDATE
                )
            ',
            'visitor_missed' => '
                EXISTS (
                    SELECT *
                    FROM  callbackhistory cbh
                    WHERE cbh.callbackuid = cb.uid
                    AND cbh.event IN("callback.visitor_busy", "callback.visitor_not_answered") FOR UPDATE
                )
            ',
            'operator_missed' => '
                TIMESTAMPDIFF(SECOND, created, NOW()) > 120
                AND (
                    EXISTS (
                        SELECT *
                        FROM  callbackhistory cbh
                        WHERE cbh.callbackuid = cb.uid
                        AND cbh.event = "callback.operator_cancelled" FOR UPDATE
                    ) OR NOT EXISTS (
                        SELECT *
                        FROM  callbackhistory cbh
                        WHERE cbh.callbackuid = cb.uid
                        AND cbh.event = "callback.operator_answered" FOR UPDATE
                    )
                )
            ',
            'visitor_incorrect_number' => '
                EXISTS (
                    SELECT *
                    FROM  callbackhistory cbh
                    WHERE cbh.callbackuid = cb.uid
                    AND cbh.event = "callback.number_not_recognised" FOR UPDATE
                )
            '
        );

        $params['endDate'] = $endDate->format('Y-m-d');

        $this->db->Query('DROP TEMPORARY TABLE IF EXISTS tmp_callback_update');
        $this->db->Query('CREATE TEMPORARY TABLE tmp_callback_update (
            callbackid int(11) NOT NULL AUTO_INCREMENT,
            kind varchar(32) CHARACTER SET ascii DEFAULT NULL,
            PRIMARY KEY (callbackid))');

        foreach ($typesAddWhere as $kind => $addWhere) {
            $sql = 'INSERT IGNORE INTO tmp_callback_update(callbackid, kind)
                  SELECT distinct id, :kind FROM (' . $selectSql . ' AND ' . $addWhere . ') t';
            $params['kind'] = $kind;
            $this->db->Query($sql, $params);
        }

        $this->db->Query('UPDATE callback cb INNER JOIN tmp_callback_update cbu ON cbu.callbackid = cb.id set cb.kind=cbu.kind', $params);
    }

    public function getStats(array $filters) {
        $andWhere = '';
        if (!empty($filters['date_range'])) {
            $andWhere .= ' AND created >= STR_TO_DATE("' . $filters['date_range']['start']->format('Y-m-d H:i:s') . '", "%Y-%m-%d %H:%i:%s") AND created <= STR_TO_DATE("' . $filters['date_range']['end']->format('Y-m-d H:i:s') . '", "%Y-%m-%d %H:%i:%s")';
        }
        $sql = 'SELECT COUNT(*) call_cnt, SUM(IF(kind = "success", 1, 0)) talk_cnt, SUM(IF(kind = "success", billsec, 0)) talk_length_sum, SUM(IF(kind = "success", 1, 0)) talk_length_cnt  FROM callback WHERE 1 = 1' . $andWhere;
        return $this->queryArrayOfRows($sql);
    }
}