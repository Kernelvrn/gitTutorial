<?php
/**
 * Created by JetBrains PhpStorm.
 * User: Alexander Bezroukov
 * Date: 12/20/12
 * Time: 12:03 PM
 */

require_once(dirname(__FILE__) . '/class.basemapper.php');
define('NOT_NULL', 'this_is_imposible_value_for_string_in_SQL,_not_good_way_but_simple234');

class StatsMapper extends BaseMapper {
    private $mode2Configs = array();
    private $_logId = null;

    public function __construct($model_name) {
        parent::__construct($model_name, array('dtm'), TRUE, 'statid', NULL,
            array(
                array('name' => 'country', 'sql' => 'alter table {stats} add column country varchar(128) CHARACTER SET "utf8" NULL DEFAULT NULL'),
                array('name' => 'region', 'sql' => 'alter table {stats} add column region tinytext CHARACTER SET "utf8" NULL'),
                array('name' => 'city', 'sql' => 'alter table {stats} add column city tinytext CHARACTER SET "utf8" NULL'),
                array('name' => 'startpage', 'sql' => 'alter table {stats} add column startpage tinytext CHARACTER SET "utf8" NULL'),
                array('name' => 'departmentid_data', 'sql' => 'alter table {stats} add column departmentid_data int(11) DEFAULT NULL'),
                array('name' => 'query', 'sql' => 'alter table {stats} add column query text  CHARACTER SET "utf8"  DEFAULT NULL'),
                array('name' => 'threadids', 'sql' => 'alter table {stats} add column threadids text  CHARACTER SET "utf8"  DEFAULT NULL'),
                array('name' => 'officeid_data', 'sql' => 'alter table {stats} add column officeid_data INT(11)  DEFAULT NULL'),
                array('name' => 'offline', 'sql' => 'alter table {stats} add column offline INT(1)  DEFAULT NULL'),
                array('name' => 'logid', 'sql' => 'alter table {stats} add column logid INT(11)  DEFAULT NULL')
            ), array(), array(
                MapperFactory::getOperatorOnlineMapper()
            )
        );

        $this->mode2Configs['departments_online'] = array(
            'addFields' => array('departmentid_data as departmentid'),
            'addFilters' => array(
                'hr' => NULL,
                'operatorid' => NULL,
                'offline' => FALSE
            ),
            'addGroupFields' => array('departmentid_data'),
            'keyFields' => array('departmentid')
        );

        $this->mode2Configs['departments_offline'] = $this->mode2Configs['departments_online'];
        $this->mode2Configs['departments_offline']['addFilters']['offline'] = TRUE;

        $this->mode2Configs['categories'] = array(
            'addFields' => array('category', 'subcategory'),
            'addFilters' => array(
                'hr' => NULL,
                'operatorid' => NULL,
                'offline' => NULL
            ),
            'addGroupFields' => array('category', 'subcategory'),
            'keyFields' => array('category', 'subcategory')
        );

        $this->mode2Configs['startpages'] = array(
            'addFields' => array('startpage'),
            'addFilters' => array(
                'hr' => NULL,
                'operatorid' => NULL,
                'offline' => NULL
            ),
            'addGroupFields' => array('startpage'),
            'keyFields' => array('startpage')
        );

        $this->mode2Configs['geo'] = array(
            'addFields' => array('country', 'region', 'city'),
            'addFilters' => array(
                'hr' => NULL,
                'operatorid' => NULL,
                'offline' => NULL
            ),
            'addGroupFields' => array('country', 'region', 'city'),
            'keyFields' => array('country', 'region', 'city')
        );

        $this->mode2Configs['dates_online'] = array(
            'addFields' => array('DATE(dtm) d'),
            'addFilters' => array(
                'hr' => NULL,
                'operatorid' => NULL,
                'offline' => FALSE
            ),
            'addGroupFields' => array('d'),
            'keyFields' => array('d')
        );

        $this->mode2Configs['dates_offline'] = $this->mode2Configs['dates_online'];
        $this->mode2Configs['dates_offline']['addFilters']['offline'] = TRUE;

        $this->mode2Configs['hours_online'] = array(
            'addFields' => array('hr h'),
            'addFilters' => array(
                'hr' => range(0, 23),
                'operatorid' => NULL,
                'offline' => FALSE
            ),
            'addGroupFields' => array('h'),
            'keyFields' => array('h')
        );

        $this->mode2Configs['hours_offline'] = $this->mode2Configs['hours_online'];
        $this->mode2Configs['hours_offline']['addFilters']['offline'] = TRUE;

        $this->mode2Configs['operators_time'] = array(
            'addFields' => array('operatorid'),
            'addFilters' => array(
                'hr' => NULL,
                'operatorid' => NOT_NULL,
                'offline' => NULL
            ),
            'addGroupFields' => array('operatorid'),
            'keyFields' => array('operatorid')
        );

        $this->mode2Configs['operators'] = array(
            'addFields' => array('operatorid'),
            'addFilters' => array(
                'hr' => NULL,
                'operatorid' => NOT_NULL,
                'offline' => NULL
            ),
            'addGroupFields' => array('operatorid'),
            'keyFields' => array('operatorid')
        );

        $this->mode2Configs['operators_daily']
            = $this->mode2Configs['operators_lost_visitor']
            = $this->mode2Configs['operators_intercepted_visitor']
            = $this->mode2Configs['operators'];


        $this->mode2Configs['offices_online'] = array(
            'addFields' => array('officeid_data as officeid'),
            'addFilters' => array(
                'hr' => NULL,
                'operatorid' => NULL,
                'offline' => FALSE
            ),
            'addGroupFields' => array('officeid_data'),
            'keyFields' => array('officeid')
        );

        $this->mode2Configs['offices_offline'] = $this->mode2Configs['offices_online'];
        $this->mode2Configs['offices_offline']['addFilters']['offline'] = TRUE;
    }

    public function getStats($mode, array $filters, array $accountParams = array(), array $extFields = array(), $isDaily = FALSE) {
        $this->Query('SET SESSION TRANSACTION ISOLATION LEVEL READ UNCOMMITTED');
        $query = $this->makeStatsQuery($mode, $filters, $accountParams, $isDaily ? 'daily' : NULL);
        $rawStats = $query->fetchAll();
        $keyFields = $this->mode2Configs[$mode]['keyFields'];
        if ($isDaily) {
            $keyFields[] = 'd';
        }
        $stats = $this->groupStatsByKeyFields($rawStats, $keyFields);

        return MapperFactory::getTmpStatsThreadHistory2Mapper()->statsPostProcess($mode, $stats, $extFields, $isDaily);
    }

    /**
     * Clear stats table for recalculation.
     */
    public function clearStats() {
        $sql = 'DELETE FROM {stats}';
        $this->Query($sql);
    }


    public function loadStatsCacheForFilters(array $filters, array $accountSpecificParams = array()) {
        $this->cleanIncomplete();
        $this->loadStatsCache($filters, $accountSpecificParams);
    }

    /**
     * Load missed (check by endDate) stats from work tables to stats table for all categories, departments.
     *
     * @param DateTime $endDate
     * @param array $accountSpecificParams account param
     */
    public function loadAllStatsCache(DateTime $endDate, $accountSpecificParams = array()) {
        //$clickHouseStatsMaker = new Statistic_Maker();
        //$clickHouseStatsMaker->syncAll($endDate);

        $this->cleanIncomplete();

        $departments = MapperFactory::getDepartmentMapper()->getAll();
        $departmentIds = array(NULL); // NULL means 'any'

        if (!defined('STATS_DEBUG_PARAM')) { // a little bit hard
          foreach ($departments as $department) {
            $departmentIds[] = $department['departmentid'];
          }
        }

        $locales = array();
        if (Settings::Get('multilang') && !in_array(getAccountId(), array('russianpostru', 'komusru001'))) {
            $locales = Resources::GetAvailableLocales();
        }
        array_unshift($locales, NULL);

        $categories = array(
            array('name' => NULL)
        );
        if (!Settings::Get('skip_categories_in_all_stats')) {
            $accCategories = Settings::GetCategories();
            if (!empty($accCategories)) {
                $categories = array_merge($categories, $accCategories);
            }
        }

        $officeIds = array(NULL);
        $offices = Settings::Get('offices');
        if (!empty($offices) && !Settings::Get('skip_offices_in_all_stats')) {
            foreach ($offices as $office) {
                $officeIds[] = $office['id'];
            }
        }

        foreach ($departmentIds as $departmentId) {
            $filters = array(
                'date_range' => array(
                    'end' => $endDate
                ),
                'department' => $departmentId
            );

            foreach ($locales as $locale) {
                $filters['locale'] = $locale;
                foreach ($officeIds as $officeId) {
                    $filters['office'] = $officeId;
                    foreach ($categories as $category) {
                        $filters['category'] = $category['name'];
                        $this->loadStatsCache($filters, $accountSpecificParams);
                        if (!empty($category['children'])) {
                            foreach ($category['children'] as $subcategory) {
                                $filters['subcategory'] = $subcategory;
                                $this->loadStatsCache($filters, $accountSpecificParams);
#                                sleep(60);
                            }
                        }
                    }
                }
            }
        }
    }

    public function getStatsRowsById($id) {
        $ids = is_array($id) ? $id : array($id);

        return $this->makeSearch('id in (:ids)', array('ids' => $ids));
    }

    protected static $vectorTypeToMode = array(
        'DateOnline' => 'dates_online',
        'DateOffline' => 'dates_offline',
        'HourOnline' => 'hours_online',
        'HourOffline' => 'hours_offline',
        'Category' => 'categories',
        'StartPage' => 'startpages',
        'DepartmentOnline' => 'departments_online',
        'DepartmentOffline' => 'departments_offline',
        'OfficeOnline' => 'offices_online',
        'OfficeOffline' => 'offices_offline',
        'OperatorTime' => 'operators_time',
    );

    public function getStatsVectorsQuery($vectorType, array $filters, array $accountParams = array()) {
        return $this->makeStatsQuery(self::$vectorTypeToMode[ucfirst($vectorType)], $filters, $accountParams);
    }

    public function getTotalStatsQuery($vectorType, array $filters, array $accountParams = array()) {
        return $this->makeStatsQuery(self::$vectorTypeToMode[ucfirst($vectorType)], $filters, $accountParams, 'total');
    }

    protected function makeStatsQuery($mode, $filters, $accountParams, $type = NULL) {
        $queryParts = array(
            'fields' => array(
                'GROUP_CONCAT(DISTINCT threadids) threadids',
                'GROUP_CONCAT(DISTINCT id) statsids',
                'IF(param_name <> "operator_peak", SUM(param_value), MAX(param_value)) as param_value', //TODO: Evil hardcode for operator_peak. Should be refactored if more than one param.
                'param_name'
            ),
            'tables' => array($this->getTableNameForQueries()),
            'where' => array(
                'dtm BETWEEN DATE(:start) AND DATE(:end)',
                'param_name IN (:param_names)'
            ),
            'group' => array('param_name')
        );

        if (!empty($this->mode2Configs[$mode]['addFields'])) {
            $queryParts['fields'] = array_merge($queryParts['fields'], $this->mode2Configs[$mode]['addFields']);
        }

        $params = array(
            'start' => clone $filters['date_range']['start'],
            'end' => clone $filters['date_range']['end']
        );
        $params['start']->setTime(0,0,0);
        $params['end']->setTime(23,59,59);

        $params['param_names'] = $this->getParamNamesForStatsQueryByMode($mode, $accountParams);

        if (!empty($this->mode2Configs[$mode]['addFilters'])) {
            $filters = array_merge($filters, $this->mode2Configs[$mode]['addFilters']);
        }

        foreach (array(
                     'locale' => 'locale',
                     'department' => 'departmentid',
                     'office' => 'officeid',
                     'category' => 'category_filter',
                     'subcategory' => 'subcategory_filter',
                     'hr' => 'hr',
                     'operatorid' => 'operatorid',
                     'offline' => 'offline') as $filterKey => $fieldName) {
            $params[$fieldName] = array_key_exists($filterKey, $filters) ? $filters[$filterKey] : NULL;
            if ($params[$fieldName] === NULL) {
                $queryParts['where'][] = $fieldName . ' IS NULL';
            } elseif ($params[$fieldName] === NOT_NULL) {
                $queryParts['where'][] = $fieldName . ' IS NOT NULL';
            } elseif (is_array($params[$fieldName])) {
                $queryParts['where'][] = $fieldName . ' IN (:' . $fieldName . ')';
            } else {
                $queryParts['where'][] = $fieldName . ' = :' . $fieldName;
            }
        }

        if ($type !== 'total') {
            if (!empty($this->mode2Configs[$mode]['addGroupFields'])) {
                $queryParts['group'] = array_merge($this->mode2Configs[$mode]['addGroupFields'], $queryParts['group']);
            }
            $queryParts['order'] = $queryParts['group'];

            if ($type === 'daily') {
                $queryParts['fields'][] = 'dtm d';
                array_unshift($queryParts['group'], 'dtm');
            }
        }

        return new Wrapper_SelectQuery($this->db, $queryParts, $params, array(
            'rowsPerRequest' => 2000
        ));
    }

    protected function groupStatsByKeyFields(array $stats, array $keys) {
        $groupedStats = array();

        foreach ($stats as $row) {
            $rowKey = '';
            foreach ($keys as $key) {
                $rowKey .= !empty($row[$key]) ? $row[$key] : 'NULL';
            }

            $groupedStats[$rowKey][$this->convertParamName($row['param_name'])] = array(
                'value' => $row['param_value'],
                'statsids' => $row['statsids'],
                'threadids' => $row['threadids']
            );

            foreach ($keys as $key) {
                $groupedStats[$rowKey][$key] = $row[$key];
            }
        }

        return $groupedStats;
    }

    private function convertParamName($paramName) {
        $converts = array(
            'category' => 'category_cnt',
            'department' => 'department_cnt',
            'geo' => 'geo_cnt',
            'startpage' => 'startpage_cnt'
        );

        return !empty($converts[$paramName]) ? $converts[$paramName] : $paramName;
    }

    private function getParamNamesForStatsQueryByMode($mode, $accountParams) {
        $params = array();
        $configs = MapperFactory::getTmpStatsThreadHistory2Mapper()->getAccountIncludedQueryConfigs($accountParams);
        foreach ($configs as $config) {
            foreach ($config['params'] as $configParam) {
                $modes = is_array($configParam['modes']) ? $configParam['modes'] : array($configParam['modes']);
                if (in_array($mode, $modes)) {
                    $params[] = $configParam['name'];
                }
            }
        }
        return $params;
    }

    private function loadStatsCache(array $filters, array $accountSpecificParams = array()) {
        if ($this->db->shouldUseSlave()) {
          doMyLog('Could not make stats on slave');
          return;
        }

        $endDate = clone $filters['date_range']['end'];
        $endDate->setTime(23,59,59);

        $maxStartDate = $this->getMaxStartDate($filters);
        if (empty($maxStartDate)) {
            self::__verbose("Exiting because of empty maxStartDate");
            return;
        }
        $maxStartDate->setTime(0, 0, 0);
        if ($maxStartDate > $endDate) {
            return;
        }

        $yesterdayDate = new DateTime('yesterday');

        $dateStep = new DateInterval('P10D');
        $workFilters = $filters;
        $workFilters['date_range']['start'] = clone $maxStartDate;

        $filterParams = array();
        foreach (array(
                     'locale' => 'locale',
                     'department' => 'departmentid',
                     'category' => 'category_filter',
                     'subcategory' => 'subcategory_filter',
                     'office' => 'officeid'
                 ) as $filterKey => $fieldName) {
            //Prefix 'f_' because we don't want overwrite params from select sub query
            $filterParams['f_' . $fieldName] = array_key_exists($filterKey, $workFilters) ? $workFilters[$filterKey] : NULL;
        }

        $statsSelectsAndInserts = array( //Последовательности полей в selects и inserts должны соответсвовать
            'departments_online' => array(
                'offline' => 'offline'
            ),
            'departments_offline' => array(
                'offline' => 'offline'
            ),
            'offices_online' => array(
                'offline' => 'offline'
            ),
            'offices_offline' => array(
                'offline' => 'offline'
            ),
            'startpages' => array(),
            'categories' => array(),
            'dates_online' => array(
                'offline' => 'offline'
            ),
            'dates_offline' => array(
                'offline' => 'offline'
            ),
            'hours_online' => array(
                'h' => 'hr',
                'offline' => 'offline'
            ),
            'hours_offline' => array(
                'h' => 'hr',
                'offline' => 'offline'
            ),
            'operators' => array(
                'operatorid' => 'operatorid'
            ),
            'operators_time' => array(
                'operatorid' => 'operatorid'
            ),
            'operators_lost_visitor' => array(
                'operatorid' => 'operatorid'
            ),
            'operators_intercepted_visitor' => array(
                'operatorid' => 'operatorid'
            ),
        );

        do {
            $workFilters['date_range']['end'] = clone $workFilters['date_range']['start'];
            $workFilters['date_range']['end']->add($dateStep)->setTime(23,59,59);
            if ($workFilters['date_range']['end'] > $endDate) {
                $workFilters['date_range']['end'] = clone $endDate;
            }

            MapperFactory::getTmpStatsThreadHistory2Mapper()->setupStatsThreadsToFilter($workFilters);
            $queryConfigs = MapperFactory::getTmpStatsThreadHistory2Mapper()->getAccountIncludedQueryConfigs($accountSpecificParams);
            foreach ($queryConfigs as $queryConfig) {
                foreach ($queryConfig['params'] as $queryConfigParam) {
                    if (defined('STATS_DEBUG_PARAM') && !stristr($queryConfigParam['name'], STATS_DEBUG_PARAM)) {
                        continue;
                    }
                    $modes = $this->filterIncludedModes($queryConfigParam['modes'], $accountSpecificParams);
                    foreach ($modes as $mode) {
                        $insertFilterFieldNames = !empty($statsSelectsAndInserts[$mode]) ? $statsSelectsAndInserts[$mode] : array();
                        $selectFilterFieldNames = !empty($statsSelectsAndInserts[$mode]) ? array_keys($statsSelectsAndInserts[$mode]) : array();
//var_dump($queryConfig);
//                        die();
                        $pAccountParams = $accountSpecificParams;
                        if (!empty($queryConfig['proc'])) {
//                            var_dump($pAccountParams);
                            unset($pAccountParams['timezone']);
//                            die();
                        }

                        $baseSelectQuery = MapperFactory::getTmpStatsThreadHistory2Mapper()->makeStatsQuery($queryConfig['sql'], $mode, $workFilters, array('d'), $pAccountParams);
                        $params = array_merge($baseSelectQuery['params'], $filterParams);
                        $paramSrcName = !empty($queryConfigParam['value_src']) ? $queryConfigParam['value_src'] : $queryConfigParam['name'];
                        $params['paramName'] = $queryConfigParam['name'];
                        if (!empty($queryConfigParam['additionalFields'])) {
                            $selectFilterFieldNames = array_merge($selectFilterFieldNames, array_keys($queryConfigParam['additionalFields']));
                            $insertFilterFieldNames = array_merge($insertFilterFieldNames, $queryConfigParam['additionalFields']);
                        }

                        $selectSQL = 'SELECT :query, :logid, 0, d, :paramName,' . $paramSrcName . ', :f_departmentid, :f_locale, :f_category_filter, :f_subcategory_filter, :f_officeid, threadids'
                            . (!empty($selectFilterFieldNames) ? ', ' . implode(', ', $selectFilterFieldNames) : '')
                            . ' FROM (' . PHP_EOL
                            . $baseSelectQuery['sql'] . PHP_EOL
                            . ') s WHERE ' . $paramSrcName . ' IS NOT NULL ';

                        MapperFactory::getTmpStatsThreadHistory2Mapper()->ensureProcIsInvoked($queryConfig, array(
                            'start' => $workFilters['date_range']['start'],
                            'end' => $workFilters['date_range']['end'],
                            'departmentid' => array_key_exists('department', $workFilters) ? $workFilters['department'] : null,
                            'locale' => array_key_exists('locale', $workFilters) ? $workFilters['locale'] : null,
                        ));
                        $params['logid'] = $this->_logId;
                        $this->makeInsertStatsFromSelectQuery($selectSQL, $insertFilterFieldNames , $params);
                    }
                }

            }

            $this->db->Query('SET SESSION TRANSACTION ISOLATION LEVEL READ UNCOMMITTED');

            $sql = 'INSERT INTO {stats}(is_complete, dtm, param_name, param_value, departmentid, locale, category_filter, subcategory_filter, officeid) VALUES(0, :dtm, "checkpoint", 0, :f_departmentid, :f_locale, :f_category_filter, :f_subcategory_filter, :f_officeid)';
            $this->Query($sql,
                array_merge(
                    $filterParams,
                    array('dtm' => ($workFilters['date_range']['end'] < $yesterdayDate) ? $workFilters['date_range']['end']->format('Y-m-d') : $yesterdayDate->format('Y-m-d'))
                )
            );

            $sql = 'UPDATE {stats} SET is_complete = 1 WHERE dtm < DATE(NOW()) and is_complete = 0';
            $this->Query($sql);
            $workFilters['date_range']['start']->add($dateStep)->add(new DateInterval('P1D'));
        } while ($workFilters['date_range']['end'] < $endDate);
    }

    private function filterIncludedModes($modesName, array $accountParams = array()) {
        $includedReports = !empty($accountParams['stats_reports_include']) ? $accountParams['stats_reports_include'] : array();
        $excludedReports = !empty($accountParams['stats_reports_exclude']) ? $accountParams['stats_reports_exclude'] : array();

        $filteredModes = is_array($modesName) ? $modesName : array($modesName);
        if (!empty($includedReports)) {
            $filteredModes = array_intersect($filteredModes, $includedReports);
        }
        if (!empty($excludedReports)) {
            $filteredModes = array_diff($modesName, $excludedReports);
        }

        return $filteredModes;
    }

    private function getMaxStartDate(array $filters) {
        $params = array();
        $andLocaleDepartmentForStats = '';
        foreach (array(
                     'department' => 'departmentid',
                     'locale' => 'locale',
                     'category' => 'category_filter',
                     'subcategory' => 'subcategory_filter',
                     'office' => 'officeid'
                 ) as $filterKey => $fieldName) {
            $value = array_key_exists($filterKey, $filters) ? $filters[$filterKey] : NULL;
            $params[$fieldName] = $value;
            if ($value !== NULL) {
                $params[$fieldName] = $value;
                $andLocaleDepartmentForStats .= ' AND ' . $fieldName . ' = :' . $fieldName;
            } else {
                $andLocaleDepartmentForStats .= ' AND ' . $fieldName . ' IS NULL';
            }
        }
        $andLocaleDepartmentForThreadHistory = '';
        foreach (array(
                     'department' => 'th.departmentid',
                     'locale' => 'th.locale',
                     'category' => 't.category',
                     'subcategory' => 't.subcategory',
                     'office' => 't.officeid'
                 ) as $filterKey => $fieldName) {
            $value = array_key_exists($filterKey, $filters) ? $filters[$filterKey] : NULL;
            $params[$fieldName] = $value;
            if ($value !== NULL) {
                $params[$fieldName] = $value;
                $andLocaleDepartmentForThreadHistory .= ' AND ' . $fieldName . ' = :' . $fieldName;
            }
        }

        $result = NULL;
        $sql = 'SELECT MAX(DATE(dtm)) max_date_from_stats FROM {stats} WHERE dtm >= DATE(date_sub(now(), interval :day_sub day)) AND is_complete=1 AND param_name <> "category"' . $andLocaleDepartmentForStats;
        $params['day_sub'] = 5;
        $rows = $this->queryArrayOfRows($sql, $params);
        if (!empty($rows) && !empty($rows[0]['max_date_from_stats'])) {
            $result = new DateTime($rows[0]['max_date_from_stats']);
            $result->add(new DateInterval('P1D'));
        }

        $default = new DateTime(MAX_AGE_FOR_STATS_CALC);
        if (empty($result)) {
            $params['default_date'] = $default->format('Y-m-d');
            $sql = 'SELECT MAX(DATE(dtm)) max_date_from_stats FROM {stats} WHERE is_complete=1 AND param_name <> "category" AND dtm >= :default_date' . $andLocaleDepartmentForStats;
            $rows = $this->queryArrayOfRows($sql, $params);
            if (!empty($rows) && !empty($rows[0]['max_date_from_stats'])) {
                $result = new DateTime($rows[0]['max_date_from_stats']);
                $result->add(new DateInterval('P1D'));
            }

            if (empty($result)) {
                $sql = 'SELECT MIN(DATE(dtm)) min_date_from_history FROM {threadhistory} th JOIN {thread} t ON t.threadid = th.threadid WHERE dtm > 0' . $andLocaleDepartmentForThreadHistory;
                $rows = $this->queryArrayOfRows($sql, $params);

                if (!empty($rows)) {
                    if (!empty($rows[0]['min_date_from_history'])) {
                        $result = new DateTime($rows[0]['min_date_from_history']);
                    }
                }
            }
        }
        $result = max($default, $result);
        return $result;
    }

    private function cleanIncomplete() {
        self::__verbose("Cleaning incomplete");
        $sql = 'DELETE FROM {stats} WHERE is_complete = 0';
        $this->Query($sql);
        self::__verbose("Ready");
    }

    private function makeInsertStatsFromSelectQuery($selectQuery, $insertFieldNames, array $params) {
        $this->Query('SET SESSION TRANSACTION ISOLATION LEVEL READ UNCOMMITTED');
        $insertFieldNames = implode(', ', $insertFieldNames);

        $sql = 'INSERT INTO {stats}(query, logid, is_complete, dtm, param_name, param_value, departmentid, locale, category_filter, subcategory_filter, officeid, threadids'
            . (!empty($insertFieldNames) ? ', ' . $insertFieldNames : '') . ') ' . PHP_EOL
            . $selectQuery;
//        . '  WHERE '.$params['paramName'].' IS NOT NULL';

        $this->Query('SET SESSION group_concat_max_len = 1000000');
        $this->Query($sql, $params, FALSE, TRUE);
        global $LAST_QUERY;
      }

    private function __verbose($string) {
        if (defined('VERBOSE_STATS')) {
            $val = $string;
            if (!is_string($string) && !is_numeric($string)) {
                $val = print_r($string, true);
            }
            echo $val . PHP_EOL;
        }
    }

    public function enumThreadsByStatsIds($ids, $exclIds) {
        global $LAST_QUERY;
        $this->Query('SET SESSION group_concat_max_len = 1000000');
        if (empty($exclIds)) {
            $exclIds = array(-1);
        }
        $rows = $this->queryArrayOfRows('select group_concat(threadids) threadids from {stats} where id in (?)', array($ids));
        if (empty($rows)) {
            return null;
        }
        $threads1 = Helper::trimExplode(',', $rows[0]['threadids']);

        $rows = $this->queryArrayOfRows('select group_concat(threadids) threadids from {stats} where id in (?)', array($exclIds));
        if (empty($rows)) {
            return null;
        }

        $threads2 = Helper::trimExplode(',', $rows[0]['threadids']);

        $rows = $this->queryArrayOfRows('select group_concat(threadid) threadids from {thread} where threadid in (?) and threadid not in (?)', array($threads1, $threads2));
        if (empty($rows)) {
            return null;
        }
//        $threads1 = $rows[0]['threadids'];

//        if (isMyIP()) {
//            die($LAST_QUERY);
//        }

        return Helper::trimExplode(',', $rows[0]['threadids']);
    }

    public function enumNotUniqStats() {
        $keyFields = array(
            'dtm',
            'param_name',
            'hr',
            'operatorid',
            'category',
            'subcategory',
            'category_filter',
            'subcategory_filter',
            'departmentid',
            'departmentid_data',
            'locale',
            'officeid',
            'officeid_data',
            'offline',
        );
        $fields = implode(',', $keyFields);

        $sql = "select * from (select count(*) cnt, $fields from chatstats where
dtm > date_sub(now(), interval 1 month) and
param_name not in ('startpage', 'geo', 'checkpoint') group by " . $fields .') a where cnt > 1 order by cnt desc limit 1';
        $arr = $this->queryArrayOfRows($sql);
        if (empty($arr)) {
            return null;
        }

        $row = $arr[0];
        $where = ' 1 = 1 ';
//        var_dump($row);
//        die();
        foreach ($keyFields as $f) {
            $where .= ' and ' . $f;
            $where .= $row[$f] == null ? ' is null' : " = '" . $this->getEscapedString($row[$f]) . "'";
        }
        $sql = 'select * from chatstats where ' . $where;
//        die($sql);
        $res = $this->queryArrayOfRows($sql);
        return $res;

    }

    public function setLogId($logId) {
        $this->_logId= $logId;
    }
}

?>