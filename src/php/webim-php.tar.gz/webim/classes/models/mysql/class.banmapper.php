<?php
require_once (dirname(__FILE__) . '/class.basemapper.php');

class BanMapper extends BaseMapper {
  public function __construct($model_name) {
    parent::__construct($model_name, array("created", "till"), TRUE, 'banid', null,
        array(
            array('name' => 'json', 'sql' => 'ALTER TABLE {ban} ADD COLUMN json text;')
        ));
  }

  public function getBanByAddress($address) {
    if (strlen(trim($address)) == 0) {
      return null;
    }
    $res = $this->makeSearch("address like '%".$this->db->getEscapedString($address)."%' AND unix_timestamp(till) > unix_timestamp(CURRENT_TIMESTAMP)",
      null,
      null,
      1);
    return array_shift($res);
  }

  public function isBanned($address) {
    $ban = $this->getBanByAddress($address);
    if (!empty($ban)) {
      return true;
    }

    $all = $this->getAll();
    foreach ($all as $b) {
      if (!strstr($b['address'], '*')) {
        continue;
      }
      $re = str_replace('*', '\d{1,3}', $b['address']);
      $re = str_replace('.', '\.', $re);
      if (preg_match('/^'.$re.'$/', $address)) {
        return true;
      }
    }
    return false;
  }

  public function getAll($limit = null, $offset = null, $total = null, $orderby = null) {
    $res = $this->makeSearch("unix_timestamp(till) > unix_timestamp(CURRENT_TIMESTAMP)", null, null, null, null, $total, 'till');
    return $res;
  }
}

?>