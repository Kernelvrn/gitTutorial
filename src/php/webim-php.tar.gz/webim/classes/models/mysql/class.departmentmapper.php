<?php
require_once(dirname(__FILE__) . '/class.basemapper.php');

class DepartmentMapper extends BaseMapper {


    public function enumDepartments($locale, $only_visible = false, $include_deleted=false) { // TODO check for oracle inner vs outer joins
        return $this->getOrderedDepartments($locale, $only_visible, false, $include_deleted);
    }

    public function enumDeletedDepartments($locale, $only_visible = false) {
        $result = array();
        $allDeps = $this->getOrderedDepartments($locale, $only_visible, false, true);
        foreach ($allDeps as $dep) {
            if ($dep['deleted'] == '1') {
                array_push($result, $dep);
            }
        }
        return $result;
    }

    public function enumDepartmentsByIds($locale, $deptsIds, $only_visible = false) {
        return $this->getOrderedDepartmentsByIds($locale, $deptsIds, $only_visible);
    }

    public function getDepartmentsOrderedByName($locale, $only_visible = false) {
        return $this->getOrderedDepartments($locale, $only_visible, true);
    }

    private function getOrderedDepartments($locale, $only_visible = false, $orderByName = false, $include_deleted = false) {
        $sql = "SELECT dl.*, d.* FROM {" . $this->getTableName() . "} d
        LEFT OUTER JOIN {departmentlocale} dl
        ON d.departmentid=dl.departmentid 
        AND locale=:locale ";
        $sql .= "WHERE ";
        $sql .= $only_visible ? "ishidden = '0' AND " : "TRUE AND ";
        $sql .= !$include_deleted ? "deleted != '1' " : "TRUE ";
        $sql .= $orderByName ? "ORDER BY departmentname ASC" : "ORDER BY departmentorder ASC";
        return $this->queryArrayOfRows($sql, array('locale' => $locale));
    }

    public function getOrderedDepartmentsByIds($locale, $departmentIds, $only_visible = false) {
        $rows = $this->getOrderedDepartments($locale, $only_visible);
        $answers = array();
        if (!empty($rows)) {
            foreach ($rows as $row) {
                if (in_array($row['departmentid'], $departmentIds)) {
                    $answers[] = $row;
                }
            }
        }
        return $answers;
    }

    public function getDepartmentKeysAndAnswersByIds($locale, $departmentIds) {
        $rows = $this->getOrderedDepartments($locale);
        $answers = array();

        if (!empty($rows)) {
            foreach ($rows as $row) {
                if (in_array($row['departmentid'], $departmentIds)) {
                    $answers[$row['departmentkey']] = $row['answers'];
                }
            }
        }
        return $answers;
    }

    public function getByGeoInfo($geostr) {
        $total = 0;
        $r = $this->makeSearch("departmentgeo LIKE ?", "%$geostr%", null, 1, null, $total, array('departmentorder', 'asc'));
        return array_shift($r);
    }

    public function getByDepartmentKey($key) {
        $r = $this->makeSearch("departmentkey = ?", $key, null, 1);
        return array_shift($r);
    }

    public function deleteDepartment($departmentid) {
        $supervisorIdsRows = MapperFactory::getOperatorDepartmentMapper()->getDepartmentSupervisorsIds($departmentid);
        $accountName = getAccountId();
        foreach ($supervisorIdsRows as $row) {
            $check = MapperFactory::getOperatorDepartmentMapper()->checkIfOperatorIsSupervisorInAnotherDepartment($row['operatorid'], $departmentid);
            if (empty($check)) {
                MapperFactory::getOperatorAccountMapper()->setOperatorRolesForAccount($row['operatorid'], 'operator', $accountName);
            }
        }

        $this->Query('DELETE FROM {operatordepartment} WHERE departmentid = ?', $departmentid);
        $this->Query('DELETE FROM {departmentlocale} WHERE departmentid = ?', $departmentid);
        $this->Query('DELETE FROM {department} WHERE departmentid = ?', $departmentid);
    }

    public function departmentsExist() {
        $sql = "SELECT * FROM {" . $this->getTableName() . "} LIMIT 1";
        return count($this->queryArrayOfRows($sql)) > 0;
    }

    public function getDepartments() {
        $sql = "SELECT * FROM {" . $this->getTableName() . "}";
        return $this->queryArrayOfRows($sql);
    }

    public function getDepartmentByIds(array $ids) {
        $rows = array();
        if (!empty($ids)) {
            $rows = $this->makeSearch('departmentid IN (?)', array($ids));
        }

        return $rows;
    }


    public function getMaxOrder() {
        $row = $this->makeSearch(null, null, "MAX(departmentorder) as max_order");
        return $row[0]['max_order'];
    }

}

?>