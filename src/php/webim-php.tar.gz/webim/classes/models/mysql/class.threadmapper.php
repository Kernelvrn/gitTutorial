<?php
require_once (dirname(__FILE__) . '/class.basemapper.php');
require_once (dirname(__FILE__) . '/../../../autoload.php');

class ThreadMapper extends BaseMapper {
  public function __construct($model_name) {
    parent::__construct($model_name, array(
      "created", "modified", "lastpingvisitor", "lastpingagent"
    ), TRUE, NULL, NULL, array(
        array('name' => 'startpage', 'sql' => 'alter table {thread} add column startpage text')
    ));
  }

  public function getByIdDefault($id, $select = null) {
    return parent::getById($id, $select);
  }

  public function getById($id, $select = null) {
    $result = parent::getById($id, "
    				*,
                    unix_timestamp(created) as tscreated,
                    unix_timestamp(lastpingvisitor) as lpvisitor,
                    unix_timestamp(lastpingagent) as lpoperator,
                    unix_timestamp(CURRENT_TIMESTAMP) as current"
    );

    /* pb */
      if($result) {
	      //Inject rate if needed
	      $crm = MapperFactory::getRateMapper();
	      $rate = $crm->getByThreadidAndOperatorid($result['threadid'], $result['operatorid']);
	      if($rate) {
	      	$result['ratedoperatorid'] = $rate['operatorid'];
	      	$result['rate'] = $rate['rate'];
	      } else {
	      	$result['ratedoperatorid'] = null;
	      	$result['rate'] = null;
	      }
      }
    /* end pb */

    return $result;
  }

  public function getOpenThreadsForVisitor($visitorid) {
    $sql = "SELECT
                    *,
                    unix_timestamp(t.created) as tscreated,
                    unix_timestamp(lastpingvisitor) as lpvisitor,
                    unix_timestamp(lastpingagent) as lpoperator,
                    unix_timestamp(CURRENT_TIMESTAMP) as current
                FROM
                    {thread} as t
                INNER JOIN
                    {visitsession} as v
                ON
                    t.visitsessionid = v.visitsessionid
                WHERE
                    visitorid = ? AND state <> ?
                ORDER BY threadid DESC";

    $this->db->Query($sql, array($visitorid, STATE_CLOSED));
    return $this->db->getArrayOfRows();
  }

  public function countOpenThreadsForReferal($referal) {
    $referal = trim($referal);

    if (empty($referal)) {
      return 0;
    }
    $sql = "SELECT
              *,
              unix_timestamp(t.created) as tscreated,
              unix_timestamp(lastpingvisitor) as lpvisitor,
              unix_timestamp(lastpingagent) as lpoperator,
              unix_timestamp(CURRENT_TIMESTAMP) as current
          FROM
              {thread} as t
          INNER JOIN
              {message} as m
          ON
              t.threadid = m.threadid
          WHERE
              m.message like '%" . mysql_real_escape_string($referal). "%'
               AND m.kind = :kind
               AND t.state <> :state";

    $this->db->Query($sql, array('kind' => KIND_FOR_AGENT, 'state' => STATE_CLOSED));
    $arr = $this->db->getArrayOfRows();
    return count($arr);

  }

  public function countOpenThreadsForIP($ip) {
    return count($this->getOpenThreadsForIP($ip));
  }

  public function getOpenThreadsForIP($ip) {
    $sql = "SELECT
                    *,
                    unix_timestamp(t.created) as tscreated,
                    unix_timestamp(lastpingvisitor) as lpvisitor,
                    unix_timestamp(lastpingagent) as lpoperator,
                    unix_timestamp(CURRENT_TIMESTAMP) as current
                FROM
                    {thread} as t
                INNER JOIN
                    {visitsession} as v
                ON
                    t.visitsessionid = v.visitsessionid
                WHERE
                    v.ip = ? AND state <> ?
                ORDER BY threadid DESC";

    $this->db->Query($sql, array($ip, STATE_CLOSED));
    return $this->db->getArrayOfRows();
  }


  /** TODO: Это вроде как пережиток прошлого его нужно будет удалить **/
  public function getActiveThreadForVisitor($visitorid) {
    $res = $this->getOpenThreadsForVisitor($visitorid);
    return array_shift($res);
  }

  public function incrementVisitorMessageCount($threadid) {
    $sql = "UPDATE {thread}
    		 SET visitormessagecount = visitormessagecount + 1
    		 WHERE threadid=?";
    $this->db->Query($sql, $threadid);
    return true;
  }

  public function getNonEmptyThreadsCountByVisitorId($visitorid, $userid = null, $threadIdToSkip = null) {
    if ($visitorid == 0) {
      $visitorid = null;
    }
//    if (!defined('MYSQL_LOG')) {
//      define('MYSQL_LOG', true);
//    }
    $t = isset($threadIdToSkip) ? ' and t.threadid <> :threadid' : '';
     $sql = " SELECT
     				COUNT(t.threadid) as total
              FROM {thread} as t
              INNER JOIN {visitsession} as v
              ON t.visitsessionid=v.visitsessionid
              WHERE (v.visitorid=:visitorid and :userid is null) or (v.userid=:userid)  AND t.visitormessagecount > 0 " . $t;
     $this->db->Query($sql, array('visitorid' => $visitorid, 'userid' => $userid, 'threadid' => $threadIdToSkip));
//    define('MYSQL_LOG', false);
     $this->db->nextRecord();
     $row = $this->db->getRow();
     return $row['total'];
  }

  public function getByVisitSessionId($visitsessionid) {
    $sql = " SELECT
    			  unix_timestamp(t.created) as created,
                  unix_timestamp(t.modified) as modified,
                  unix_timestamp(t.modified) - unix_timestamp(t.created) as diff,
                  t.threadid,
                  v.ip as remote,
                  t.operatorfullname,
                  v.visitorname as visitorname
             FROM {thread} as t
             LEFT JOIN {visitsession} as v
             ON (t.visitsessionid = v.visitsessionid)
             WHERE t.visitsessionid = ?
             ORDER BY t.created DESC
    ";
      $this->db->Query($sql, $visitsessionid);
      return $this->db->getArrayOfRows();
  }

  public function getByTimeVisitorAndMessage($time, $visitorName, $firstMessage) {
    $sql = 'SELECT
             DISTINCT t.*
             FROM {thread} as t
             LEFT JOIN {visitsession} as v
              ON t.visitsessionid = v.visitsessionid
             LEFT JOIN {message} as m
              ON t.threadid = m.threadid
             WHERE ABS(timestampdiff(SECOND, :created, t.created)) < 120
              AND IF(:visitor_name, v.visitorname = :visitor_name, 1)
              AND TRIM(REPLACE(REPLACE(REPLACE(m.message, "\r", ""), "\n", ""), " ", "")) = TRIM(REPLACE(REPLACE(REPLACE(:first_message, "\r", ""), "\n", ""), " ", ""))
             ORDER BY ABS(timestampdiff(SECOND, :created, t.created)) ASC LIMIT 1';

    $this->db->Query($sql, array(
      'created' => $time,
      'visitor_name' => $visitorName,
      'first_message' => $firstMessage
    ));
    return $this->db->getArrayOfRows();
  }

  public function countActiveThreads() {
    $result = $this->makeSearch("(state <> ?)", array(STATE_CLOSED), "COUNT(*) as total");
    $result = array_shift($result);

    return $result['total'];
  }

    public function searchThreads(array $params = array()) {
        return $this->queryThreads($params);
    }

    public function countThreads(array $params = array()) {
        return $this->queryThreads($params)->count();
    }

    protected function queryThreads(array $params = array()) {
        $defaultParams = array(
            'q' => null,
            'currentOperatorId' => null,
            'showEmpty' => true,
            'pageNum' => 1,
            'checkDepartmentsAccess' => true,
            'dateRange' => array(
                'start' => null,
                'end' => null
            ),
            'atDateTime' => null,
            'operatorIds' => null,
            'departmentIds' => null,
            'locale' => null,
            'rate' => null,
            'threadKinds' => null,
            'category' => null,
            'subcategory' => null,
            'office' => null,
            'withoutOffice' => false,
            'includeWithoutDepartment' => false,
            'hideThreadsWithOthers' => false,
            'withoutCategory' => false,
            'minMessages' => 0,
            'visitorId' => null,
            'timezone' => '',
            'notEmptyVisitorData' => false,
            'selectDeptKeys' => false,
            'canSeeOffline' => false,
            'itemsPerPage' => DEFAULT_ITEMS_PER_PAGE,
            'statsIds' => array()
        );
        $params = array_merge($defaultParams, $params);

        $queryParams = array();
        $queryParts = array(
            'fields' => array(
                'unix_timestamp(t.created) as created',
                'unix_timestamp(t.modified) as modified',
                '(SELECT SUM(unix_timestamp(dtm2) - unix_timestamp(dtm1)) FROM {threadhistoryview} thv WHERE thv.threadid = t.threadid AND thv.state1 IN ("chatting", "chatting_with_robot", "queue", "offline_process")) as duration',
                't.threadid',
                't.operatorfullname',
                '(SELECT COUNT(mv.messageid) FROM {message} as mv WHERE mv.threadid = t.threadid AND mv.kind = 1) as size',
                't.category',
                't.subcategory',
                '(SELECT GROUP_CONCAT(DISTINCT dptl.departmentname)
                    FROM chatthreadhistory ths
                    INNER JOIN chatdepartmentlocale dptl ON dptl.departmentid = ths.departmentid
                    INNER JOIN chatdepartment dpt ON dpt.departmentid = ths.departmentid
                    WHERE dptl.locale = "ru"
                        AND ths.threadid=t.threadid
                    GROUP BY ths.threadid
                ) as departmentnames',
                't.officeid',
                'v.ip as remote',
                'v.remotehost',
                'v.visitorname',
                'v.json',
                'v.userid',
                't.threadkind',
                't.visitsessionid'
            ),
            'tables' => array(),
            'joins' => array(),
            'where' => array()
        );

        if ($params['selectDeptKeys']) {
            $queryParts['fields'][] = '
                (SELECT GROUP_CONCAT(DISTINCT dpt.departmentkey)
                    FROM chatthreadhistory ths
                    INNER JOIN chatdepartment dpt ON dpt.departmentid = ths.departmentid
                    WHERE ths.threadid=t.threadid
                    GROUP BY ths.threadid) AS departmentkeys';
        }

        if ($params['rate']) {
            switch ($params['rate']) {
                case '1_point':
                    $queryParts['joins'][] = 'INNER JOIN chatrate r ON r.threadid=t.threadid AND r.rate = -2 AND r.deldate IS NULL';
                    break;
                case '2_point':
                    $queryParts['joins'][] = 'INNER JOIN chatrate r ON r.threadid=t.threadid AND r.rate = -1 AND r.deldate IS NULL';
                    break;
                case '3_point':
                    $queryParts['joins'][] = 'INNER JOIN chatrate r ON r.threadid=t.threadid AND r.rate = 0 AND r.deldate IS NULL';
                    break;
                case '4_point':
                    $queryParts['joins'][] = 'INNER JOIN chatrate r ON r.threadid=t.threadid AND r.rate = 1 AND r.deldate IS NULL';
                    break;
                case '5_point':
                    $queryParts['joins'][] = 'INNER JOIN chatrate r ON r.threadid=t.threadid AND r.rate = 2 AND r.deldate IS NULL';
                    break;
                case 'exist':
                    $queryParts['joins'][] = 'INNER JOIN chatrate r ON r.threadid=t.threadid AND r.deldate IS NULL';
                    break;
                case 'not_exist':
                    $queryParts['where'][] = 'NOT EXISTS (SELECT * FROM chatrate r WHERE r.threadid=t.threadid AND r.deldate IS NULL)';
                    break;
            }
        }

        $queryParts['joins'][] = 'LEFT JOIN {visitsession} as v ON v.visitsessionid = t.visitsessionid';

        $queryParts['tables'][] = '{thread} as t';

        if (!empty($params['q'])) {
            $queryParams['query'] = '%' . $params['q'] . '%';
            $queryParts['where'][] = '(
             t.threadid IN (
                 SELECT threadid
                 FROM {message} as m
                 WHERE
                     m.sendername LIKE :query
                     OR m.message LIKE :query
             )
             OR v.visitorid LIKE :query
             OR v.userid LIKE :query
             OR v.ip LIKE :query
             OR v.remotehost LIKE :query
             OR t.operatorfullname LIKE :query
             OR t.threadid LIKE :query
             OR v.visitorname LIKE :query
         )';
        }

        if (!empty($params['statsIds'])) {
            $statsRow = MapperFactory::getStatsMapper()->getStatsRowsById($params['statsIds']);
            $threadIdsArr = Helper::getColumnFromArray($statsRow, 'threadids');
            $threadIds = Helper::trimExplode(',', implode(',', $threadIdsArr));
            if (!empty($threadIds)) {
                $queryParts['where'][] = 't.threadid IN (:threadids)';
                $queryParams['threadids'] = $threadIds;
            }
        }

        if ($params['notEmptyVisitorData']) {
            $queryParts['where'][] = '(v.json LIKE BINARY "%email%" OR v.json LIKE BINARY "%phone%")';
        }

        if ($params['checkDepartmentsAccess']) {
            $queryParts['where'][] = '((exists (select * from {threadhistory} th where th.threadid=t.threadid and th.departmentid is null)) OR EXISTS(SELECT * FROM {operatordepartment} od, {threadhistory} th WHERE od.operatorid=:currentoperatorid AND od.departmentid=th.departmentid and th.threadid=t.threadid))';
            $queryParams['currentoperatorid'] = $params['currentOperatorId'];
        }

        if (!$params['showEmpty']) {
            $queryParts['where'][] = 't.visitormessagecount > 0';
        }

        if (!empty($params['minMessages'])) {
            $queryParts['where'][] = '(SELECT count(*) FROM {message} WHERE kind IN (1, 2) AND threadid = t.threadid) >= :minMessages';
            $queryParams['minMessages'] = $params['minMessages'];
        }

        if (!empty($params['visitorId'])) {
            $queryParts['where'][] = 'v.visitorid = :visitorId';
            $queryParams['visitorId'] = $params['visitorId'];
        }

        $timeOffset = 0;
        if (!empty($params['timezone'])) {
            $baseTimezone = new DateTimeZone(date_default_timezone_get());
            $accountTimezone = new DateTimeZone($params['timezone']);
            if (!empty($params['dateRange']['end'])) {
                $dateObj = clone $params['dateRange']['end'];
            } else {
                $dateObj = new DateTime();
            }
            $timeOffset = $accountTimezone->getOffset($dateObj) - $baseTimezone->getOffset($dateObj);
        }

        if (!empty($params['dateRange']['start'])) {
            $queryParams['start_timestamp'] = $params['dateRange']['start']->getTimestamp() - $timeOffset;
            $queryParts['where'][] = 't.created  >= FROM_UNIXTIME(:start_timestamp)';
        }

        if (!empty($params['dateRange']['end'])) {
            $queryParams['end_timestamp'] = $params['dateRange']['end']->getTimestamp() - $timeOffset;
            $queryParts['where'][] = 't.created  <= FROM_UNIXTIME(:end_timestamp)';
        }

        if (!empty($params['atDateTime'])) {
            $queryParams['atDateTime_timestamp'] = $params['atDateTime']->getTimestamp() - $timeOffset;
            $queryParts['where'][] = 't.created  <= FROM_UNIXTIME(:atDateTime_timestamp) AND t.modified  >= FROM_UNIXTIME(:atDateTime_timestamp)';
        }

        if (!empty($params['departmentIds'])) {
            if (!is_array($params['departmentIds'])) {
                $params['departmentIds'] = array($params['departmentIds']);
            }
            $queryParams['departmentids'] = $params['departmentIds'];
            if (!$params['includeWithoutDepartment']) {
                $queryParts['where'][] = 'exists (select * from {threadhistory} th where t.threadid=th.threadid and th.departmentid IN (:departmentids))';
            } else {
                $queryParts['where'][] = 'exists (select * from {threadhistory} th where t.threadid=th.threadid and (th.departmentid IN (:departmentids) or th.departmentid IS NULL))';
            }
        } elseif ($params['includeWithoutDepartment']) {
            $queryParts['where'][] = 'not exists (select * from {threadhistory} th where t.threadid=th.threadid and th.departmentid IS NOT NULL)';
        }

        if (!empty($params['locale'])) {
            $queryParams['locale'] = $params['locale'];
            $queryParts['where'][] = 'EXISTS (SELECT * from {threadhistory} as ths WHERE ths.threadid = t.threadid AND ths.locale = :locale)';
        }

        if (!empty($params['category']) && !$params['withoutCategory']) {
            $queryParams['category'] = $params['category'];
            $queryParts['where'][] = 't.category = :category';
        } elseif (!empty($params['category']) && $params['withoutCategory']) {
            $queryParams['category'] = $params['category'];
            $queryParts['where'][] = '(t.category = :category OR t.category IS NULL)';
        } elseif ($params['withoutCategory']) {
            $queryParts['where'][] = 't.category IS NULL';
        }

        if (!empty($params['subcategory'])) {
            $queryParams['subcategory'] = $params['subcategory'];
            $queryParts['where'][] = 't.subcategory = :subcategory';
        }

        if (!empty($params['office']) && !$params['withoutOffice']) {
            $queryParams['office'] = $params['office'];
            $queryParts['where'][] = 't.officeid = :office';
        }  elseif (empty($queryParams['office']) && $params['withoutOffice']) {
            $queryParts['where'][] = 't.officeid IS NULL';
        }

        if (!empty($params['hideThreadsWithOthers']) && !empty($params['currentOperatorId'])) {
            $assignedOperatorIds = MapperFactory::getOperatorSupervisorMapper()->getAssignedOperatorIds($params['currentOperatorId']);
            $assignedOperatorIds = !empty($assignedOperatorIds) ? $assignedOperatorIds : array();
            $data = MapperFactory::getOperatorDepartmentMapper()->getSupervisedDeptsAndOperators($params['currentOperatorId']);
            $assignedOperatorIds = array_merge($assignedOperatorIds, $data['operators']);
            $queryParams['currentoperatorid'] = $params['currentOperatorId'];
            $queryParams['assignedoperators'] = !empty($assignedOperatorIds) ? $assignedOperatorIds : null;
            $queryParts['where'][] = 'exists (SELECT * FROM {threadhistory} th WHERE th.threadid=t.threadid AND (th.operatorid = :currentoperatorid OR th.operatorid IN (:assignedoperators)))';
        }

        $kindWhereParts = array();
        $simpleKinds = array();
        $showWithoutOperators = FALSE;
        if (!empty($params['operatorIds'])) {
            if (!is_array($params['operatorIds'])) {
                $params['operatorIds'] = array($params['operatorIds']);
            }
            $queryParams['operatorids'] = $params['operatorIds'];
        }
        if (!empty($params['threadKinds'])) {
            foreach (array_unique($params['threadKinds']) as $kind) {
                switch (strtolower($kind)) {
                    case 'in_process':
                        $kindWhereParts[] = '(t.state NOT IN ("closed", "deleted"))';
                        break;
                    case 'missed':
                        $showWithoutOperators = TRUE;
                        if (!empty($params['operatorIds'])) {
                            $kindWhereParts[] = '(t.threadkind = "missed" AND exists (SELECT * FROM {threadhistory} th LEFT OUTER JOIN {onlineperiod} cop ON th.dtm between cop.dtmfrom and cop.dtmto WHERE th.threadid=t.threadid AND cop.operatorid IN (:operatorids)))';
                        } else {
                            $simpleKinds[] = $kind;
                        }
                        break;
                    case 'offline':
                        $kindWhereParts[] = '(t.offline = 1)';
                        break;
                    default:
                        $simpleKinds[] = $kind;
                }
            }
        }

        if (!empty($simpleKinds)) {
            $queryParams['thread_kinds'] = $simpleKinds;
            $kindWhereParts[] = '(t.threadkind IN (:thread_kinds) AND t.state IN ("closed", "deleted"))';
        }

        if (!empty($kindWhereParts)) {
            $queryParts['where'][] = '(' . implode(' OR ', $kindWhereParts) . ')';
        }

        if (!empty($params['operatorIds'])) {
            if ($showWithoutOperators) {
                $queryParts['where'][] = '(t.operatorid IN (:operatorids) OR (t.operatorid IS NULL AND t.threadkind = "missed"))';
            } else {
                $queryParts['where'][] = 't.operatorid IN (:operatorids)';
            }
        }

        if ($params['canSeeOffline'] === false) {
            $queryParts['where'][] = 't.offline = 0';
        }

        if ($params['pageNum'] > 0) {
            $queryParts['limit'] = array(
                'start' => DEFAULT_ITEMS_PER_PAGE * ($params['pageNum'] - 1),
                'length' => DEFAULT_ITEMS_PER_PAGE
            );
        }

        $queryParts['group'] = 'threadid';
        $queryParts['order'] = 't.created DESC';

        return new Wrapper_SelectQuery($this->db, $queryParts, $queryParams, array(
            'rowsPerRequest' => 1500,
            'countLimit' => 100000
        ));
    }


  public function enumNotEmptyByDate($start, $end, $departmentId = NULL, $timezone = '') {
    if (is_numeric($start)) {
      $start = new DateTime('@'.$start);
    }
    if (is_numeric($end)) {
      $end = new DateTime('@'.$end);
    }

    $timeOffset = 0;
    if (!empty($timezone)) {
      $baseTimezone = new DateTimeZone(date_default_timezone_get());
      $accountTimezone = new DateTimeZone($timezone);
      if ($accountTimezone->getOffset($start) > $baseTimezone->getOffset($start)) {
          $start->sub(new DateInterval('P1D'));
      }
      if ($accountTimezone->getOffset($end) < $baseTimezone->getOffset($end)) {
          $end->add(new DateInterval('P1D'));
      }
      $timeOffset = $accountTimezone->getOffset($end) - $baseTimezone->getOffset($end);
    }

    $params = array('start' => $start->format('Y-m-d'), 'end' => $end->format('Y-m-d'));

    $dateField = 'created';
    if (!empty($timeOffset)) {
      $dateField = 'DATE_ADD(created, INTERVAL :time_offset SECOND)';
      $params['time_offset'] = $timeOffset;
    }
    $sql = 'date(' . $dateField . ') between date(:start) and date(:end) and visitormessagecount > 0';
    if (!empty($departmentId)) {
        $sql .= ' AND exists (select * from chatthreadhistory th where chatthread.threadid=th.threadid and th.departmentid =:departmentid)';
        $params['departmentid'] = $departmentId;
    }
    return $this->makeSearch($sql, $params);
  }
  public function getNextRevision() {
    $sql = "UPDATE {revision} SET id = LAST_INSERT_ID(id+1)";
    try {
      $this->db->Query($sql);
      return $this->db->getInsertId();
    } catch (Exception $e) {
      return null;
    }
  }

  public function getNextToken() {
    return rand(99999, 99999999);
  }

  public function getPendingThreads($since, $includeClosed, $operatorid, $shouldcheckdepartments, $locales, $additionalCondition = '') {
    $departmentsSql = $shouldcheckdepartments ? " AND (t.departmentid IS NULL OR t.departmentid IN
            (SELECT departmentid FROM {operatordepartment} WHERE operatorid=:operatorid))" : '';

    if (!empty($locales)) {
      $escapted = array();

      foreach ($locales as $l) {
        $escaped[] = $this->db->getEscapedString($l);
      }

      $localeSql = " AND (t.locale IN ('" . join("','", $escaped) . "')) ";
    } else {
      $localeSql = '';
    }

    $sql = "SELECT *, unix_timestamp(created) as created FROM {".$this->getTableName()."} t WHERE 1=1 "
            .$departmentsSql
            .$localeSql
            ." AND revision > :since AND (:condition OR state <> :closed) AND state <> 'loading'  "
            .$additionalCondition;

      $this->db->Query($sql, array('operatorid'=>$operatorid,
        'since'=>$since,
        'closed'=>STATE_CLOSED,
        'condition'=>$includeClosed ? TRUE : FALSE));
      return $this->db->getArrayOfRows();
  }

  public function enumOpenWithTimeout($timeout) {
    return $this->makeSearch(
    	"state <> ?
    	AND unix_timestamp(CURRENT_TIMESTAMP) - unix_timestamp(modified) > ?",
        array(STATE_CLOSED, $timeout)
    );
  }

  public function removeHistory($threadid) {
    try {
        $this->db->query('DELETE FROM {'.$this->getTableName().'} WHERE threadid=:threadid', $threadid);
    } catch(Exception $e) {}
  }

  public function operatorHasActiveThreads($operatorid) {
    $result = $this->makeSearch(
    	"operatorid = ? AND state <> ?",
        array($operatorid, STATE_CLOSED),
        "COUNT(threadid) as cnt",
        1
    );

    $result = array_shift($result);

    return $result['cnt'] > 0;
  }

  public function getLatestOperatorIdForVisitor($visitorId) {
    $sql = "select * from {thread} ct inner join {visitsession} cvs on ct.visitsessionid=cvs.visitsessionid where visitorid=? order by threadid desc;";
    $this->db->Query($sql, $visitorId);
    $result = $this->db->getArrayOfRows();

    return array_shift($result);
  }
/*s*/
  public function getNumberOfChatsByDate($time) {
    $sql = <<<END
    SELECT count(*) as cnt FROM {thread} m WHERE DATE(created) = DATE(FROM_UNIXTIME(:time)) AND operatorid IS NOT NULL
             AND visitormessagecount > 0
END;

      $this->db->Query($sql, array('time' => $time, 'kindvisitor' => KIND_USER));
      $res = $this->db->getArrayOfRows();
      $res = array_shift($res);
      return $res['cnt'];
  }

  public function getOperatorsChattedForDate($time) {
    $sql = <<<END
    SELECT DISTINCT th.operatorid FROM {thread} t INNER JOIN {threadhistory} th ON th.threadid = t.threadid WHERE visitormessagecount > 0 AND DATE(created) = DATE(FROM_UNIXTIME(?)) AND th.operatorid IS NOT NULL AND th.operatorid <> 0
END;
//    $sql = <<<END
//    SELECT DISTINCT operatorid FROM {thread} I WHERE visitormessagecount > 0 AND DATE(created) = DATE(FROM_UNIXTIME(?)) AND operatorid IS NOT NULL
//END;

    $this->db->Query($sql, $time);
    $arr = $this->db->getArrayOfRows();
    $res = array();
    foreach ($arr as $a) {
      $res[$a['operatorid']] = 1;
    }
    return $res;
  }
/*end s*/

  public function getLastThread() {
    $total = 0;
    $result = $this->makeSearch($where = null, $params = null, $select = null, $limit = 1, $offset = 0, $total, $orderby = array('threadid', 'DESC'));
    if (!empty($result)) {
      return array_shift($result);
    }
    return NULL;
  }

    /**
     * Set correct threadkind for threads
     * @param DateTime $end
     * @param int account configuration param
     */
    public function checkAndSetType(DateTime $end, $secondsBeforeVisitorMissed = 0) {
        doMyLog('checkAndSetType');
        $params['endDate'] = $end->format('Y-m-d 23:59:59');
        $params['startDate'] = (new DateTime(MAX_AGE_FOR_STATS_CALC))->format('Y-m-d');

        $selectSql = '
              SELECT t.threadid threadid
              FROM {thread} t
              WHERE (threadkind = "undefined" || threadkind IS NULL)
                AND (t.state IN ("closed", "deleted") OR t.offline = 1)
                AND created BETWEEN :startDate AND :endDate';
        $threadTypesAddWhere = array(
            'missed' => '
                  t.offline = 0
                  AND EXISTS (
                    SELECT *
                    FROM {threadhistoryview} th
                      WHERE th.state1 = "queue" AND th.state2 = "closed"
                        AND TIMESTAMPDIFF(SECOND, th.dtm1, th.dtm2) >= :seconds_before_visitor_missed
                        AND t.threadid = th.threadid FOR UPDATE
                  )
              ',
            'chat' => '
                  t.offline = 0
                  AND
                      EXISTS (
                        SELECT *
                        FROM {threadhistory} th
                        WHERE (th.state IN ("chatting", "chatting_with_robot") OR th.state = "closed_by_operator")
                          AND t.threadid = th.threadid FOR UPDATE
                      )
              ',
            'bounce' => '
                  t.offline = 0
                  AND EXISTS (
                    SELECT *
                    FROM {threadhistoryview} th
                    WHERE ((
                      th.state1 = "queue" AND th.state2 = "closed"
                      AND TIMESTAMPDIFF(SECOND, th.dtm1, th.dtm2) < :seconds_before_visitor_missed
                    )) AND t.threadid = th.threadid FOR UPDATE
                  )
              ',
            'rejected_invitation' => '
                  t.visitormessagecount = 0 AND t.offline = 0
                  AND EXISTS (
                    SELECT *
                    FROM {threadhistory} th
                    WHERE th.state = "invitation" AND th.number = 1
                      AND t.threadid = th.threadid FOR UPDATE
                  )
              ',
            'offline' => '
                  t.offline = 1
              ',
            'could not define' => '
                  1 = 1
              '
        );

        if (getAccountId() == 'russianpostru') {
            $threadTypesAddWhere = array('skip' => 't.offline = 1
                      AND (SELECT event FROM chatthreadhistory h WHERE h.threadid = t.threadid ORDER BY h.number DESC LIMIT 1) = "sys.auto_close"
            ') + $threadTypesAddWhere;
        }

        $params['seconds_before_visitor_missed'] = $secondsBeforeVisitorMissed;

        $this->db->Query('DROP TEMPORARY TABLE IF EXISTS tmp_thread_update');
        $this->db->Query('CREATE TEMPORARY TABLE tmp_thread_update (
            threadid int(11) NOT NULL AUTO_INCREMENT,
            threadkind varchar(32) CHARACTER SET ascii DEFAULT NULL,
            PRIMARY KEY (threadid))');

//    $this->db->Query("DELETE FROM tmp_thread_update");

        foreach ($threadTypesAddWhere as $threadkind => $addWhere) {
            $sql = 'INSERT IGNORE INTO tmp_thread_update(threadid, threadkind)
                  SELECT distinct threadid, :threadkind FROM (' . $selectSql . ' AND ' . $addWhere . ') t';
            $params['threadkind'] = $threadkind;
            $this->db->Query($sql, $params);
        }


        $this->db->Query("update {thread} t  INNER JOIN tmp_thread_update tu ON tu.threadid = t.threadid set t.threadkind=tu.threadkind", $params);
    }

    public function setThreadOperatorAndOffice(DateTime $end) {
        $params['endDtm'] = $end->format('Y-m-d 23:59:59');
        $params['startDate'] = (new DateTime(MAX_AGE_FOR_STATS_CALC))->format('Y-m-d');
        $updateOperatorIdSql = '
        UPDATE {thread} t
        SET t.operatorid = IF(t.manuallyassignedoperatorid IS NOT NULL, t.manuallyassignedoperatorid,
         IFNULL((
          SELECT operatorid FROM {message} m
          WHERE m.threadid = t.threadid AND m.messageid = (
            SELECT MAX(messageid) FROM {message} ms
            WHERE kind = ' . KIND_AGENT . ' AND ms.threadid = m.threadid
          )
        ), IFNULL((
          SELECT operatorid FROM {threadhistory} th
          WHERE th.threadid = t.threadid AND th.threadhistoryid = (
            SELECT MAX(threadhistoryid) FROM {threadhistory} ths
            WHERE ths.operatorid IS NOT NULL AND ths.threadid = th.threadid
          )
        ), 0)))
        WHERE t.operatorid IS NULL AND t.created BETWEEN :startDate AND :endDtm
        AND t.state in ("closed", "deleted")';
        $this->db->Query($updateOperatorIdSql, $params);

        $threads = $this->makeSearch('operatorid IS NOT NULL AND operatorid <> 0 AND operatorfullname IS NULL AND created <= :endDtm AND state in ("closed", "deleted")', $params);
        $operatorIds = Helper::getColumnFromArray($threads, 'operatorid');
        if (!empty($operatorIds)) {
            $operators = MapperFactory::getOperatorMapper()->enumOperatorsWithDeletedByIds($operatorIds);
            if (!empty($operators)) {
                $setOperatorNameSql = 'SET operatorfullname = CASE operatorid';
                foreach ($operators as $operator) {
                    $setOperatorNameSql .= ' WHEN :operatorid' . $operator['operatorid'] . ' THEN :operatorname' . $operator['operatorid'];
                    $params['operatorid' . $operator['operatorid']] = $operator['operatorid'];
                    $params['operatorname' . $operator['operatorid']] = !empty($operator['fullname']) ? $operator['fullname'] : '';
                }
                $setOperatorNameSql .= ' ELSE "" END';
            } else {
                $setOperatorNameSql = 'SET operatorfullname = ""';
            }


            $operatorOfficeSql = '';
            if (Tariff::getInstance()->hasTariffOption('offices') && !empty($operators) && !Settings::areOfficesByGeo()) {
                $operatorOfficeSql = ', officeid = CASE operatorid';
                foreach ($operators as $operator) {
                    $operatorOfficeSql .= ' WHEN :operatorid' . $operator['operatorid'] . ' THEN :operatoroffice' . $operator['operatorid'];
                    $params['operatoroffice' . $operator['operatorid']] = !empty($operator['officeid']) ? $operator['officeid'] : NULL;
                }
                $operatorOfficeSql .= ' ELSE NULL END';
            }
            $updateOperatorNameSql = '
            UPDATE {thread} t
            ' . $setOperatorNameSql . '
            ' . $operatorOfficeSql . '
            WHERE t.operatorid IS NOT NULL AND t.operatorid <> 0 AND t.operatorfullname IS NULL
              AND t.created <= :endDtm AND t.state in ("closed", "deleted")';
            $this->db->Query($updateOperatorNameSql, $params);
            global $LAST_QUERY;
        }

        $offices = Settings::Get('offices');
        if (!empty($offices)) {
            $allGeosIn = array();
            foreach ($offices as $o) {
                if (empty($o['geo'])) {
                    continue;
                }
                if ($o['geo'] != '*') {
                    $geos = explode("\n", $o['geo']);
                    $in = array();

                    foreach ($geos as $g) {
                        $g = trim($g);
                        $in[] = $this->db->prepareParamForSQL($g);
                        $allGeosIn[] = $this->db->prepareParamForSQL($g);
                    }
                    global $LAST_QUERY;
                    $this->db->Query("update {thread} t  set officeid=?
                      WHERE officeid is null and exists (select * from {visitsession} s where t.visitsessionid = s.visitsessionid and (city in (" . join(',', $in) . ") or  region in (" . join(',', $in) . "))) limit 10000", array($o['id']));
                    global $LAST_QUERY;
//                    die($LAST_QUERY);
                } else {
                    $this->db->Query("update {thread} t  set officeid=?
                      WHERE officeid is null and not exists (select * from {visitsession} s where t.visitsessionid = s.visitsessionid and (city in (" . join(',', $allGeosIn) . ") or  region in (" . join(',', $allGeosIn) . "))) limit 10000", array($o['id']));
                    global $LAST_QUERY;
//                    die($LAST_QUERY);
                }

                $this->db->Query("update {threadhistory} h  set officeid=(select officeid from {thread} t WHERE t.threadid = h.threadid) WHERE h.officeid is null limit 1000000");

            }
        }
    }

    public function getUnclosedThreadStats(array $filters, $statsType = 'date', $timezone = NULL, $forOffline = FALSE) {
        $timeOffset = 0;
        $baseTimezone = $accountTimezone = new DateTimeZone(date_default_timezone_get());
        $startDate = $filters['date_range']['start'];
        $endDate = $filters['date_range']['end'];
        if (!empty($timezone)) {
            $accountTimezone = new DateTimeZone($timezone);
            if ($accountTimezone->getOffset($filters['date_range']['end']) < $baseTimezone->getOffset($filters['date_range']['end'])) {
                $endDate = clone $filters['date_range']['end'];
                $endDate->add(new DateInterval('P1D'));
            }
            if ($accountTimezone->getOffset($filters['date_range']['start']) > $baseTimezone->getOffset($filters['date_range']['start'])) {
                $startDate = clone $filters['date_range']['start'];
                $startDate->sub(new DateInterval('P1D'));
            }
            $timeOffset = $accountTimezone->getOffset($startDate) - $baseTimezone->getOffset($startDate);
        }
        $paramsSQL = array(
            'start' => $startDate,
            'end' => $endDate
        );
        $dateField = 't.created';
        if (!empty($timeOffset)) {
            $dateField = 'DATE_ADD(t.created, INTERVAL :time_offset SECOND)';
            $paramsSQL['time_offset'] = $timeOffset;
        }
        $fieldsArr = array('COUNT(DISTINCT t.threadid) unclosed');
        $where = 'WHERE DATE(' . $dateField . ') >= DATE(:start) AND DATE(' . $dateField . ') <= DATE(:end) AND t.state not in ("closed", "deleted")';
        $groupByArr = array();
        switch ($statsType) {
            case 'date':
                $fieldsArr[] = 'DATE(' . $dateField . ') d';
                $groupByArr[] = 'DATE(' . $dateField . ')';
		        break;
            case 'operatorDaily':
                $fieldsArr[] = 'DATE(' . $dateField . ') d';
                $fieldsArr[] = 't.operatorid';
                $groupByArr[] = 'DATE(' . $dateField . ')';
                $groupByArr[] = 't.operatorid';
                break;
            case 'hour':
                $fieldsArr[] = 'HOUR(' . $dateField . ') h';
                $groupByArr[] = 'HOUR(' . $dateField . ')';
                break;
            case 'operatorSummary':
                $fieldsArr[] = 't.operatorid';
                $groupByArr[] = 't.operatorid';
                break;
        }
        $paramsSQL['departmentid'] = !empty($filters['department']) ? $filters['department'] : NULL;
        if (isset($filters['department'])) {
            $where .= ' AND exists (SELECT * FROM {threadhistory} th WHERE t.threadid = th.threadid AND th.departmentid = :departmentid)';
        }
        if (isset($filters['office'])) {
            $where .= ' AND exists (SELECT * FROM {threadhistory} th WHERE t.threadid = th.threadid AND th.officeid = :officeid)';
        }
        foreach (array(
                     'locale' => 'locale',
                     'category' => 'category',
                     'subcategory' => 'subcategory') as $filterKey => $fieldName) {
            $value = array_key_exists($filterKey, $filters) ? $filters[$filterKey] : NULL;
            $paramsSQL[$fieldName] = $value;
            if ($value !== NULL) {
                $where .= ' AND t.' . $fieldName . ' = :' . $fieldName;
            }
        }
        $paramsSQL['offline'] = $forOffline ? 1 : 0;
        $where .= ' AND t.offline = :offline';

        $sql = 'SELECT ' . implode(',', $fieldsArr) . ' FROM {thread} t ' . $where . ' GROUP BY ' . implode(',', $groupByArr);
        $this->Query('SET SESSION TRANSACTION ISOLATION LEVEL READ UNCOMMITTED');
        return $this->queryArrayOfRows($sql, $paramsSQL);
    }

    public function getVisitorPreviousThreadIds($threadid, $visitorid, $departmentids, $isAdmin = false, $limit = true,
                                                $operatorid = NULL) {
        $params = [
            'threadid' => $threadid,
            'visitorid' => $visitorid,
            'departmentids' => $departmentids,
            'operatorid' => $operatorid
        ];

        $sql = 'SELECT t.threadid, t.created  FROM {thread} as t
                INNER JOIN {visitsession} as v
                ON t.visitsessionid=v.visitsessionid
                WHERE v.visitorid=:visitorid';

        $sql .= $threadid ? ' AND t.threadid < :threadid' : '';
        $sql .= ' AND EXISTS (SELECT * FROM {threadhistory} th WHERE t.threadid=th.threadid';
        if (!($isAdmin || Settings::Get('show_chats_from_other_departments_in_history'))) {
            $sql .= !empty($departmentids) ? ' AND (th.departmentid IN (:departmentids) OR th.departmentid IS NULL)' : ' AND  th.departmentid IS NULL';
            if (isset($operatorid)) {
                $sql .= ' AND t.operatorid=:operatorid';
            }
        }
        $sql .= ') ORDER BY t.threadid DESC';
        if ($limit) {
            $sql .= ' LIMIT 2';
        };

        $res = $this->db->queryArrayOfRows($sql, $params);
        if (!empty($res)) {
            return $res;
        } else {
            return false;
        }
    }

    public function getVisitorNextThreadIds($threadid, $visitorid, $departmentids, $isAdmin = false, $limit = true, $operatorid = NULL) {
        $params = array('threadid' => $threadid, 'visitorid' => $visitorid, 'departmentids' => $departmentids, 'operatorid' => $operatorid);

        $sql = 'SELECT t.threadid, t.created  FROM {thread} as t
                INNER JOIN {visitsession} as v
                ON t.visitsessionid=v.visitsessionid
                WHERE v.visitorid=:visitorid
                AND t.threadid > :threadid
                AND EXISTS (SELECT * FROM {threadhistory} th WHERE t.threadid=th.threadid';

        if (!($isAdmin || Settings::Get('show_chats_from_other_departments_in_history'))) {
            $sql .= !empty($departmentids) ? ' AND (th.departmentid IN (:departmentids) OR th.departmentid IS NULL)' : ' AND  th.departmentid IS NULL';
            if (isset($operatorid)) {
                $sql .= ' AND t.operatorid=:operatorid';
            }
        }
        $sql .= ') ORDER BY t.threadid ASC';

        if ($limit) {
            $sql .= ' LIMIT 2';
        };

        $this->db->Query($sql, $params);
        $res = $this->db->getArrayOfRows();
        if (!empty($res)) {
            return $res;
        } else {
            return false;
        }
    }

    public function getVisitorIdByThreadId($threadid) {
        $params = array('threadid' => $threadid);
        $sql = 'SELECT vs.visitorid FROM {visitsession} vs WHERE vs.visitsessionid = (SELECT visitsessionid FROM {thread} WHERE threadid=:threadid)';
        $this->db->Query($sql, $params);
        $res = $this->db->getArrayOfRows();
        if (!empty($res)) {
            return $res[0]['visitorid'];
        } else {
            return false;
        }

//      $params = array('threadid' => $threadid);
//      $sql = "SELECT visitsessionid FROM {thread} WHERE threadid=:threadid";
//      $arr = $this->queryArrayOfRows($sql, $params);
//      $sessionid = $arr[0]['visitsessionid'];
//
//      $params['sessionid'] = $sessionid;
//      $sql = 'SELECT vs.visitorid FROM {visitsession} vs WHERE vs.visitsessionid = :sessionid';
//
//      $arr = $this->queryArrayOfRows($sql, $params);
//      return $arr[0]['visitorid'];

    }

    public function enumClosedChatsWithCategoryMustHaveBeenSet() {
        $sql = "SELECT * FROM {thread} t WHERE threadkind <> 'undefined' and category is null and exists (select * from {message} m where m.threadid=t.threadid and message like 'Диалогу присвоена категория%') and created > date_sub(now(), interval 1 month) order by t.threadid desc limit 5 ";
        $rows = $this->db->queryArrayOfRows($sql);
        return $rows;
    }
}

?>