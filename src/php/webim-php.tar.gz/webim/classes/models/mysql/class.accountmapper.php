<?php
require_once (dirname(__FILE__) . '/class.basemapper.php');

/**
 * Class for working with accounts.
 */
class AccountMapper extends BaseMapper {

  public function __construct($model_name) {
    parent::__construct('account', array('dtmcreated', 'closedate', 'timeonline', 'dtmwriteoff', 'profreedate', 'last_db_backup_dtm'), true, 'accountid', false,
      array(
        array('name' => 'last_db_backup_dtm', 'sql' => 'alter table account add column last_db_backup_dtm datetime null'),
        array('name' => 'dtmblocked', 'sql' => 'alter table account add column dtmblocked timestamp NULL DEFAULT NULL'),
        )
      );
  }

  protected function getTableNameForQueries() {
    return '`' . $this->getTableName() . '`';
  }

  public function getDatabaseKey() {
    return 'operators';
  }

  public function addAccount($data) {
    $rowId = $this->add($data);

//    $this->Query("UPDATE account SET profreedate=date_add(
//            CURRENT_TIMESTAMP, interval " . PRO_FREE_PERIOD . " day) WHERE accountname='" .
//        mysql_real_escape_string($data['accountname']) . "'");

    //mysql_query("CREATE DATABASE webim_service_pro_".mysql_real_escape_string($name));

    if (!$rowId) {
      return null;
    } else {
      return $this->getById($rowId);
    }
  }

  /**
   * Checks if the $value exists in the specific $field of the table.
   *
   * @param string $field name of the field.
   * @param string $value value you want to check on unique.
   * @return boolean true if the $value exists in the $field, or false.
   */
  public function isValueExists($field, $value) {
    $totalRows = 0;
    //print $field." ".$value." ".$table_name."<br>";
    $this->makeSearch("$field=:val",
      array('val' => $value), "$field", null, null, $totalRows);
    //print "isExists=".$totalRows."<br><br>";
    return $totalRows;
  }

  public function countAccountsForSite($accountName) {
    $totalRows = 0;
    //print $field." ".$value." ".$table_name."<br>";
    $this->makeSearch("accountname like '" . mysql_real_escape_string($accountName) . "%'",
      null, null, null, null, $totalRows);
    //print "isExists=".$totalRows."<br><br>";
    return $totalRows;
  }

  /**
   * Checks if account with such $name and $password exists.
   *
   * @param string $name account's name.
   * @param string $password account's password.
   * @return boolean false if account isn't exists or true.
   */
  public function ifAccountExists($name) {
    $totalRows = 0;


    $this->makeSearch('accountname = :name',
      array('name' => $name), null, null, null, $totalRows);

    //	        if ($password == md5(SALT."11111")) {
    //		          $this->makeSearch('accountname=:name', array('name'=>$name),null,null,null,&$totalRows);
    //          } elseif ($password == md5(SALT.'111111')) {
    //            $this->makeSearch("accountname=:name and partner='alltrade'", array('name'=>$name),null,null,null,&$totalRows);
    //          }

    // '0' equals to false.
    return $totalRows;
  }

  public function getByName($name) {
      $arr = $this->makeSearch('accountname = :name', array('name' => $name));
      return array_shift($arr);
  }

  /**
   *
   * @param <type> $name
   * @return <type>
   */
  public function isAccountActive($name) {
    $totalRows = 0;

    $this->makeSearch('accountname=:name AND registertoken is null',
      array('name' => $name), null, null, null, $totalRows);

    // '0' equals to false.
    return $totalRows;
  }

  /**
   * Checks tokens and if they are similar than activation of the account will occur.
   *
   * @param string $token to for check.
   * @return string account login name or false if such token is
   * not exists in the account's table.
   */
  public function isActivated($accountName) {
    $result = $this->makeSearch('accountname=:accountname and registertoken is null',
      array('accountname' => $accountName));
    return count($result) > 0;
  }

  public function validateToken($accountName, $token) {
    $result = $this->makeSearch('accountname=:accountname and registertoken = :token',
      array('accountname' => $accountName, 'token' => $token));

    if (count($result) != 1) {
      return false;
    }

    return true;
  }

  public function cleanToken($accountName, $token) {
    $result = $this->makeSearch('accountname=:accountname and registertoken = :token',
      array('accountname' => $accountName, 'token' => $token));

    if (count($result) != 1) {
      return false;
    }

    $row = $result[0];
    $accountid = $row['accountid'];

    $this->update(array('registertoken' => null, 'accountid' => $accountid));
    return true;
  }


  public function getAccountByField($value, $field_name) {
    $result = $this->makeSearch("$field_name=:value", array('value' => $value));
    if (is_array($result) && isset($result[0]) && is_array($result[0])) {
      return $result[0];
    }
  }


  public function getServiceProFreePeriod($accountname) {
    $result = $this->makeSearch('accountname=:accountname', array('accountname' => $accountname),
      'datediff(profreedate,now()) as freetime');

    if (isset($result[0]['freetime'])) {
      return $result[0]['freetime'];
    }
  }

  public function getPartnerClientsList($partner_accountname) {
    return $this->makeSearch("partner=:name AND accountname!=:name AND registertoken is null",
      array('name' => $partner_accountname), 'accountname,' .
            'unix_timestamp(dtmcreated) as dtmcreated,' .
            'datediff(profreedate,now()) as freetime,ratetype, money_amount');
  }

  public function makeServiceProPeriodInfinity($accountid) {
    $this->update(array('accountid' => $accountid,
      'profreedate' => null, 'ratetype' => RATE_SCHEME_FREE,
      'dtmwriteoff' => null, 'isblocked' => 0));

  }

  public function enumForPartner($accountName) {
    return $this->makeSearch('partner = ?', $accountName);
  }

  public function enumNotBlockedAccounts() {
    return $this->makeSearch("isblocked = 0 and registertoken is null");
//    return $this->makeSearch("isblocked = 0 and accountname in ('laptopdesk', 'xyncru', 'webim', 'yaru')");
  }

  public function enumNotBlockedAccountsForBackupCheck() {
    return $this->makeSearch("isblocked = 0 and registertoken is null and dtmcreated < date_sub(now(), interval 1 day)");
//    return $this->makeSearch("isblocked = 0 and accountname in ('laptopdesk', 'xyncru', 'webim', 'yaru')");
  }

  public function enumAccounts() {
    return $this->makeSearch("registertoken is null and server_ip is not null and accountname not like '%\\_%'", null, 'accountname, server_ip, server_name_src');
//    return $this->makeSearch("isblocked = 0 and accountname in ('laptopdesk', 'xyncru', 'webim', 'yaru')");
  }

  public function enumAccountsByIP($ip) {
    return $this->makeSearch("server_ip = ?", $ip);
  }

  public function enumAccountWithNullCMS($limit = 5) {
    return $this->makeSearch("cms_used IS NULL", NULL, NULL, $limit);
  }

  public function enumAccountWithNullChat($limit = 5) {
    return $this->makeSearch("chat_used IS NULL", NULL, NULL, $limit);
  }

  public function enumAccountWithNullSip() {
    return $this->makeSearch('sip is null');
  }

  public function listAccountsToUpdateVersionInfo($limit = 10) {
    $total = NULL;
    return $this->makeSearch("registertoken IS NULL", NULL, NULL, $limit, NULL, $total, array('version_checked_dtm IS NOT NULL ASC, version_checked_dtm ASC', ''));
  }

  public function enumAccountsByPromocode($code) {
    return $this->makeSearch('promocode = ?', $code);
  }

    public function enumNotBlockedPayedAccounts() {
        return $this->queryArrayOfRows('SELECT DISTINCT(accountname) accountname FROM account a INNER JOIN invoice i ON i.`pro_payer_accountname` = a.accountname AND isblocked = 0 AND registertoken IS NULL AND paydate IS NOT NULL order by accountname');
    //    return $this->makeSearch("isblocked = 0 and accountname in ('laptopdesk', 'xyncru', 'webim', 'yaru')");
      }


}

?>
