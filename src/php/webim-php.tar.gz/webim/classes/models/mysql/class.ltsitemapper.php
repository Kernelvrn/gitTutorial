<?php
require_once (dirname(__FILE__) . '/class.basemapper.php');

/**
 * Class for working with accounts.
 */
class LtSiteMapper extends BaseMapper {

  public function __construct($model_name) {
    parent::__construct('ltsite', array('dtmprocessed'), true, 'id', false);
  }

  protected function getTableNameForQueries() {
    return '`' . $this->getTableName() . '`';
  }

  public function getDatabaseKey() {
    return 'operators';
  }

  public function fill() {
    $data = array();
    $this->save($data);
  }

  public function processed($siteId, $comment, $promocode) {
    $data = array();
    $data['siteid'] = $siteId;
    $data['comment'] = $comment;
    $data['promocode'] = $promocode;
    $data['dtmprocessed'] = time();
    $this->save($data);
  }

  public function getNextToProcess() {
    $total = 0;
    $rows = $this->makeSearch("dtmprocessed is null",
      null, null, 1, 0, $total, array("id", "desc"));
    return $total > 0 ? array_shift($rows) : null;
  }

  public function getBySiteId($siteId) {
    $rows = $this->makeSearch("siteid = ?", array($siteId));
    return array_shift($rows);
  }

}

?>
