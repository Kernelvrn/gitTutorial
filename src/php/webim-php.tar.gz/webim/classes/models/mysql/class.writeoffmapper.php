<?php
require_once (dirname(__FILE__) . '/class.basemapper.php');

/**
 * Class for working with accounts.
 */
class WriteoffMapper extends BaseMapper {

  public function __construct($model_name) {
    parent::__construct('webim_pro_writeoff', array('billing_date'), true, 'writeoffid', false);
  }

  protected function getTableNameForQueries() {
    return '`' . $this->getTableName() . '`';
  }

  public function getDatabaseKey() {
    return 'operators';
  }

  public function getExpensesDetails($accountName, $from, $to) {
    $res = $this->makeSearch("accountname=? and unix_timestamp(billing_date) between ? and ?", array($accountName, $from, $to), null, null, null, $total, 'billing_date');
    return $res;
  }
}

?>
