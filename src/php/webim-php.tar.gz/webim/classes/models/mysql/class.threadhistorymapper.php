<?php
require_once(dirname(__FILE__) . '/class.basemapper.php');

class ThreadHistoryMapper extends BaseMapper {

    public function __construct($model_name) {
        parent::__construct($model_name, array('dtm'), true, null, null, array(), array(), array(),
            array(
                array('name' => 'idx_threadhistory_dtm',
                    'sql' => 'CREATE INDEX idx_threadhistory_dtm ON chatthreadhistory(dtm)'
                )));
    }

    /**
     * Get array of operator ids by thread id.
     * @param $threadId
     * @return array
     */
    public function enumStateAndOperatorIdsByThreadId($threadId) {
        $sql = 'SELECT DISTINCT operatorid, state FROM {threadhistory} WHERE threadid = :threadid';
        $this->db->Query($sql, array('threadid' => $threadId));
        $result = $this->db->getArrayOfRows();

        return $result;
    }

    public function getRussianpostThreadScheme($threadid) {
        $data = $this->makeSearch('threadid = ?', $threadid);
        $steps = array();
        $initScheme = array(
            'request' => null,
            'operator_accept' => null,
            'close' => null
        );
        $scheme = $initScheme;
        foreach ($data as $step) {
            $stepTime = $step['dtm'];

            switch ($step['state']) {
                case 'offline_queue':
                    if (empty($step['event']) || $step['event'] == 'visitor.message') {
                        $scheme['request'] = $stepTime;
                    }
                    break;
                case 'offline_process':
                    if ($step['event'] == 'operator.accept') {
                        $scheme['operator_accept'] = $stepTime;
                    }
                    break;
                case 'closed':
                    /*if ($step['event'] == 'operator.close') {
                        $scheme['operator_close'] = $stepTime;
                    } else {
                        $scheme['auto_close'] = $stepTime;
                    }*/
                    $scheme['close'] = $stepTime;
                    $steps[] = $scheme;
                    $scheme = $initScheme;
                    break;
            }
        }
        return $steps;
    }

    public function getThreadHistoryByThreadIds(array $ids) {
        $rows = array();
        if (!empty($ids)) {
            $sql = 'SELECT * FROM {threadhistory} WHERE threadid IN (:threadids) ORDER BY dtm ASC';
            $rows = $this->queryArrayOfRows($sql, array('threadids' => $ids));
        }
        return $rows;
    }

    public function getByRangeQuery(DateTime $startDate, DateTime $endDate, $moreThanId = NULL) {
        return new Wrapper_SelectQuery(
            $this->db,
            array(
                'fields' => '*',
                'tables' => $this->getTableNameForQueries(),
                'where' => array(
                    'dtm BETWEEN :startDate AND :endDate',
                    $moreThanId ? 'threadhistoryid > :id' : '1 = 1'
                )
            ),
            array(
                'startDate' => $startDate->format('Y-m-d H:i:s'),
                'endDate' => $endDate->format('Y-m-d H:i:s'),
                'id' => $moreThanId
            ),
            array(
                'rowsPerRequest' => 5000
            )
        );
    }

    /**
     * Возвращает ассоциативный массив вида [id события] => [количество идущих парарлелльно чата для этого оператора этого события]
     * @param int[] $threadIds - список id обращений события которых учитываются
     * @return array
     */
    public function getParallelChatCountByThreadIds(array $threadIds) {
        $result = array();
        if (!empty($threadIds)) {
            $sql = '
                SELECT th.threadhistoryid AS threadhistoryid, count(thv.threadhistoryid2) AS parallel_chat_count
                FROM {threadhistory} th
                JOIN {threadhistoryview} thv
                  ON th.threadid <> thv.threadid AND th.operatorid = thv.operatorid2 AND th.dtm BETWEEN thv.dtm1 AND thv.dtm2
                WHERE th.threadid IN (:threadids) AND thv.threadid IN (:threadids)
                GROUP BY th.threadhistoryid;
            ';

            $rows = $this->queryArrayOfRows($sql, array(
                'threadids' => $threadIds
            ));

            foreach ($rows as $row) {
                $result[$row['threadhistoryid']] = $row['parallel_chat_count'];
            }
        }

        return $result;
    }
}
