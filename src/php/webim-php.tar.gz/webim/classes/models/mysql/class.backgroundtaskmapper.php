<?php
require_once (dirname(__FILE__) . '/class.basemapper.php');

class BackgroundTaskMapper extends BaseMapper {
    public function __construct($model_name) {
        parent::__construct($model_name, array(), $autoincrement = true, $idColumn = 'id', $createSql = '
          CREATE TABLE `backgroundtask` (
            `id` INT NOT NULL AUTO_INCREMENT,
            `operatorid` INT(11) NOT NULL,
            `key` VARCHAR(45) NOT NULL,
            `state` VARCHAR(45) NOT NULL,
            `created` BIGINT NOT NULL,
            `started` BIGINT NULL DEFAULT NULL,
            `finished` BIGINT NULL DEFAULT NULL,
            `deleted` BIGINT NULL DEFAULT NULL,
            `updated` BIGINT NULL DEFAULT NULL,
            `progress` FLOAT NULL DEFAULT 0,
            `config` TEXT NULL DEFAULT NULL,
            `result` TEXT NULL DEFAULT NULL,
            PRIMARY KEY (`id`),
            INDEX `idx_key_state` (`key` ASC, `state` ASC),
            INDEX `idx_state` (`state` ASC)
          ) ENGINE=InnoDB DEFAULT CHARSET=utf8;
        ', array(
            array(
                'name' => 'updated',
                'sql' => 'ALTER TABLE `backgroundtask` ADD COLUMN `updated` BIGINT NULL DEFAULT NULL'
            )
        ));
    }

    public function getById($id) {
        $rows = $this->makeSearch('id=?' . $this->andNotDeleted(), $id, NULL, 1);
        return array_shift($rows);
    }

    public function getByKey($key) {
        return $this->makeSearch('`key` = :key' . $this->andNotDeleted(), array(
            'key' => $key
        ));
    }

    public function getLastByKey($key) {
        $query = 'SELECT * FROM `backgroundtask` WHERE `key` = :key ' . $this->andNotDeleted()
            . ' ORDER BY created DESC LIMIT 1';
        $rows = $this->queryArrayOfRows($query, array(
            'key' => $key
        ));

        return !empty($rows) ? $rows[0] : NULL;
    }

    public function getAll() {
        return $this->makeSearch('1=1' . $this->andNotDeleted());
    }

    public function delete($id) {
        $query = 'UPDATE `backgroundtask` SET deleted = :deleted WHERE id = :id' . $this->andNotDeleted();
        $params = array(
            'id' => $id,
            'deleted' => (int)(microtime(true) * 1e6)
        );
        $this->db->Query($query, $params);
        return (bool)$this->db->getNumRows();
    }

    protected function getTableNameForQueries() {
        return $this->getTableName();
    }

    private function andNotDeleted() {
        return ' AND deleted IS NULL';
    }

}