<?php
require_once (dirname(__FILE__) . '/class.basemapper.php');

class AutoInviteMapper extends BaseMapper {
    
  public function __construct($model_name) {
 		parent::__construct($model_name, array());
  }
  
}
?>