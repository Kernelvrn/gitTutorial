<?php

class AccountKeyValueMapper extends BaseMapper {
    public function __construct($modelName) {
        parent::__construct($modelName, array(), true, 'id',
            "CREATE TABLE accountkeyvalue (
              id INT(11) AUTO_INCREMENT NOT NULL,
              accountname VARCHAR(64) NOT NULL,
              `key` VARCHAR(45) NOT NULL,
              value text,
              PRIMARY KEY (id)
            ) ENGINE=InnoDB DEFAULT CHARSET=utf8",
            array(), array(), array(),
            array(
                array('name' => 'idx_accountkeyvalue_accountname_key',
                    'sql' => 'CREATE INDEX idx_accountkeyvalue_accountname_key ON accountkeyvalue(accountname, `key`)'
                ))
        );
    }

    public function getDatabaseKey() {
        return 'operators';
    }

    protected function getTableNameForQueries() {
        return '`' . $this->getTableName() . '`';
    }

    private function addAccountKeyValue($accountname, $key, $value) {
        $data = array(
            'key' => $key,
            'accountname' => $accountname,
            'value' => $value
        );
        $this->add($data);
    }

    private function updateAccountKeyValue($accountname, $key, $value) {
        $params = array(
            'key' => $key,
            'accountname' => $accountname,
            'value' => $value
        );
        $query = "UPDATE " . $this->getTableNameForQueries() . " SET `value`=:value WHERE `accountname` =:accountname and `key`=:key";
        $this->db->Query($query, $params);
        return $this->db->getNumRows();
    }

    public function getAccountKeyValue($name, $key) {
        $result = $this->makeSearch('accountname=:name AND `key`=:key', array('name' => $name, 'key' => $key));
        if (!empty($result)) {
            return $result[0]['value'];
        }
    }

    public function setAccountKeyValue($accountName, $key, $newValue) {
        $updateResult = $this->updateAccountKeyValue($accountName, $key, $newValue);
        if (empty($updateResult)) {
            $this->addAccountKeyValue($accountName, $key, $newValue);
        }
    }
}