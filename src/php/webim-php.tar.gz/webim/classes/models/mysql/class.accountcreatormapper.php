<?php
require_once (dirname(__FILE__) . '/class.basemapper.php');

/**
 * Class for working with accounts.
 */
class AccountCreatorMapper extends BaseMapper {

  public function __construct($model_name) {
    parent::__construct('foo');
  }

  public function createAccountDatabase($accountName) {
    doMyLog("Creating db $accountName");

    $res = $this->db->queryArrayOfRows('SELECT DATABASE() db', null, $skipDbUse = true);
    $dbName = $res[0]['db'];
    doMyLog('Previous db: ' . $dbName);

    $query = "CREATE DATABASE webim_service_pro_" . mysql_real_escape_string($accountName);
    $res = $this->Query($query, null, $skipDbUse = true);

    if (!$res) {
      $error = 'Could not create database ' . $accountName . ' query was: ' . $query . ' error was ' . mysql_error() . ' this was: ' . print_r($this, true);
      MailNotifications::serviceProCreationFailureMail($accountName, '', $error, '');
      immediatelyNotifyAboutProblem($error);
      return false;
    }

    if (!empty($dbName)) {
        $this->Query('use ' . $dbName);
    }

    return true;
  }

}

?>
