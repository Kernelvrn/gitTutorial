<?php
require_once ("class.basemapper.php");

class OnlinePeriodMapper extends BaseMapper {

    public function __construct($model_name) {
        parent::__construct($model_name, array('dtmfrom', 'dtmto'), TRUE, 'id', NULL, array(
            array('name' => 'status', 'sql' => 'alter table {onlineperiod} add column status  varchar(20) CHARACTER SET ascii DEFAULT "online"')
        ));
    }

    public function getLastPeriod() {
        $total = 0;
        $result = $this->makeSearch($where = null, $params = null, $select = null, $limit = 1, $offset = 0, $total, $orderby = array('id','DESC'));
        if (!empty($result)) {
            return array_shift($result);
        }
        return NULL;
    }

    /**
     * Get array of operator ids which were available when was thread.
     * @param $threadId
     * @return array
     */
    public function enumOperatorIdsWereAvailableByThreadId($threadId) {
        $sql = '
            SELECT DISTINCT cop.operatorid
            FROM {onlineperiod} cop
            JOIN {threadhistory} cth
                ON (cth.dtm BETWEEN cop.dtmfrom AND cop.dtmto)
                AND IFNULL(cth.departmentid, 0) = IFNULL(cop.departmentid, 0)
                AND IFNULL(cth.locale, 0) = IFNULL(cop.locale, 0)
            WHERE cth.threadid = :threadid AND cth.state = "queue"';
        $this->db->Query($sql, array('threadid' => $threadId));
        $result = $this->db->getArrayOfRows();
        return $result;
    }

    public function getLatestOnlineDate() {
        $sql = 'SELECT unix_timestamp(max(dtmto)) dtmto FROM {onlineperiod}';
        $rows = $this->queryArrayOfRows($sql);
        if (empty($rows)) {
            return null;
        }
        return $rows[0]['dtmto'];
    }

    /**
     * Возвращает периоды попадающие в диапазон + обрезает их даты начала конца под этот диапазон.
     * @param DateTime $startDate
     * @param DateTime $endDate
     * @param int $moreThanId Дополнительный фильтр по id, если указан, будут искаться строки с большим.
     * @return Wrapper_SelectQuery
     */
    public function getCutsByRangeQuery(DateTime $startDate, DateTime $endDate, $moreThanId = NULL) {
        return new Wrapper_SelectQuery(
            $this->db,
            array(
                'fields' => array(
                    'GREATEST(dtmfrom, :startDate) AS dtmfrom',
                    'LEAST(dtmto, :endDate) AS dtmto',
                    'status, operatorid, departmentid, locale, id'
                ),
                'tables' => $this->getTableNameForQueries(),
                'where' => array(
                    'dtmfrom <= :endDate AND dtmto >= :startDate',
                    $moreThanId ? 'id > :id' : '1 = 1'
                )
            ),
            array(
                'startDate' => $startDate->format('Y-m-d H:i:s'),
                'endDate' => $endDate->format('Y-m-d H:i:s'),
                'id' => $moreThanId
            ),
            array(
                'rowsPerRequest' => 5000
            )
        );
    }
}
