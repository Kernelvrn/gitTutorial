<?php
require_once ("class.basemapper.php");
require_once (dirname(__FILE__)."/../../class.operator.php");

class OnlinePeriodsMapper extends BaseMapper {

    public function __construct($model_name) {
        parent::__construct($model_name, array("date"));
    }

    public function setOnlineStatus($operator) {
        try {
            $this->checkNotClosedOnlineStatus($operator['operatorid']);
//            $updated = $this->tryToConcatePeriods($operator['operatorid']);
//            if (empty($updated)) {
            $query = "INSERT INTO {".$this->getTableName()."}
                (operatorid,date) VALUES(:operatorid,curdate())";
            $this->db->Query($query, array("operatorid" => $operator['operatorid']));
//            }
        } catch (Exception $e) {}
    }

    public function setOfflineStatus($operator) {
        try {
            $query = "UPDATE {".$this->getTableName()."} SET timeoffline=current_timestamp() ".
                    " WHERE operatorid=:operatorid AND timeoffline is null";
            $this->db->Query($query, array("operatorid" => $operator['operatorid']));
        } catch (Exception $e) {}
    }

    /**
     *Sometimes, because of browser page refreshing (or other causes) we have two operator's online
     * periods which have same timeoffline and timeonline periods.
     * We should concate this periods.
     *
     * @param int $operatorid id of operator
     * @return int number of rows are updated.
     */
    private function tryToConcatePeriods($operatorid) {
        try {
            $query = "UPDATE {".$this->getTableName()."} SET timeoffline=null
             WHERE timestampdiff(SECOND,timeoffline,current_timestamp())=0
             AND operatorid=:operatorid";
            $this->db->Query($query, array("operatorid"=>$operatorid));
            return $this->db->getNumRows();
        } catch (Exception $e) {}
    }

    private function checkNotClosedOnlineStatus($operatorid) {
        try {
            $result = $this->makeSearch("operatorid = ? and timeoffline is null",
                    $operatorid, "date");

            $query ="";
            if (!empty($result)) {
                Operator::getInstance()->loadOnlineStatsIntoDB();
                foreach ($result as $row) {
                    $query = "UPDATE {".$this->getTableName()."} SET timeoffline =
                    (SELECT max(updated) FROM {operatoronline}
                     WHERE operatorid=:operator_id AND date=:update_date)
                     WHERE date=:update_date AND timeoffline is null AND operatorid=:operator_id";

                    $this->db->Query($query, array("operator_id" => $operatorid,
                            "update_date" => $row['date']));
                }

            }
        } catch (Exception $e) {}
    }

    public function getVisitorWaitingTimeForOnlineOperator($operatorid, $threadId) {
        $seconds_count = 0;
        $visitorOnlineTime = $this->getVisitorOnlineTime($threadId);
        if (!empty($visitorOnlineTime)) {
            $result = $this->makeSearch("operatorid=:operatorid AND timeonline<=:visitor_online_time AND
                    (timeoffline>=:visitor_online_time OR timeoffline is null)",
                    array("operatorid"=>$operatorid, "visitor_online_time"=>$visitorOnlineTime['created']),
                    "min(timeonline) as timeonline");

            if(empty($result[0]['timeonline'])) {
                $result = $this->makeSearch("operatorid=:operatorid
                        AND timeonline>:visitor_online_time
                        AND timeonline<=:visitor_modified_time
                        AND (timeoffline<:visitor_modified_time OR timeoffline is null)",
                        array("operatorid"=>$operatorid, "visitor_online_time"=>$visitorOnlineTime['created'],
                        "visitor_modified_time"=>$visitorOnlineTime['modified']),
                        "min(timeonline) as timeonline");

                if (!empty($result[0]['timeonline'])) {
                    $query = "SELECT (timestampdiff(SECOND, :visitor_online_time, now()) -
                        timestampdiff(SECOND, :visitor_online_time, :operator_online_point)) as seconds_count";
                    try {
                        $this->db->Query($query, array("visitor_online_time"=>$visitorOnlineTime['created'],
                            "operator_online_point" => $result[0]['timeonline']));
                        $result = $this->db->getArrayOfRows();

                        return $this->getSecondsFromResult($result);
                    } catch (Exception $e) {}
                }

            } else {
                $query = "SELECT timestampdiff(SECOND, :visitor_online_time, now()) as seconds_count";
                try {
                    $this->db->Query($query, array("visitor_online_time"=>$visitorOnlineTime['created']));
                    $result = $this->db->getArrayOfRows();
                    return $this->getSecondsFromResult($result);
                } catch (Exception $e) {}
            }
        }
    }
    

    private function getSecondsFromResult($result) {
        if (!empty ($result)) {
            return $result[0]['seconds_count'];
        } else {
            return 0;
        }
    }

    private function getVisitorOnlineTime($threadId) {
        $sql = "SELECT created,modified
          FROM {thread}
          WHERE threadid = :threadid LIMIT 1";

        try {
            $this->db->Query($sql, array("threadid" => $threadId));
            $result = $this->db->getArrayOfRows();

            if (!empty ($result)) {
                return $result[0];
            }
        } catch (Exception $e) {}
    }


    public function getVisitorWaitingTimeTest($operatorid, $now, $visitorOnlineTime) {
        $seconds_count = 0;

        if (!empty($visitorOnlineTime)) {
            $result = $this->makeSearch("operatorid=:operatorid AND timeonline<=:visitor_online_time AND
                    (timeoffline>=:visitor_online_time OR timeoffline is null)",
                    array("operatorid"=>$operatorid, "visitor_online_time"=>$visitorOnlineTime['created']),
                    "min(timeonline) as timeonline");

            if(empty($result[0]['timeonline'])) {
                $result = $this->makeSearch("operatorid=:operatorid
                        AND timeonline>:visitor_online_time
                        AND timeonline<=:visitor_modified_time
                        AND (timeoffline<:visitor_modified_time OR timeoffline is null)",
                        array("operatorid"=>$operatorid, "visitor_online_time"=>$visitorOnlineTime['created'],
                        "visitor_modified_time"=>$visitorOnlineTime['modified']),
                        "min(timeonline) as timeonline");

                print_r($result);
                print "VISITOR POINT OUTSIDE PERIOD";

                if (!empty($result[0]['timeonline'])) {
                    $query = "SELECT (timestampdiff(SECOND, :visitor_online_time, :now) -
                        timestampdiff(SECOND, :visitor_online_time, :operator_online_point)) as seconds_count";
                    try {
                        $this->db->Query($query, array("visitor_online_time"=>$visitorOnlineTime['created'],
                            "operator_online_point" => $result[0]['timeonline'],
                                "now"=>$now));
                        $result = $this->db->getArrayOfRows();

                        return $this->getSecondsFromResult($result);
                    } catch (Exception $e) {}
                }

            } else {
                $query = "SELECT timestampdiff(SECOND, :visitor_online_time, :now) as seconds_count";
                print_r($result);
                print "VISITOR POINT INSIDE PERIOD";
                try {
                    $this->db->Query($query, array("visitor_online_time"=>$visitorOnlineTime['created'],"now"=>$now));
                    $result = $this->db->getArrayOfRows();
                    return $this->getSecondsFromResult($result);
                } catch (Exception $e) {}
            }
        }
    }


    //------USING INTETVALS FOR CALCULATING WAITING TIME-------
    //
    //
//    public function getVisitorWaitingTimeForOnlineOperator($operatorid, $threadId) {
//        $seconds_count = 0;
//        $visitorOnlineTime = $this->getVisitorOnlineTime($threadId);
//        if (!empty($visitorOnlineTime)) {
//            //if the operator is online right now
//            $result = $this->makeSearch("operatorid=:operatorid AND timeoffline is null AND timeonline<:visitor_online_time",
//                    array("operatorid"=>$operatorid, "visitor_online_time"=>$visitorOnlineTime['created']),
//                    "timestampdiff(SECOND ,:visitor_online_time,current_timestamp()) as seconds_count");
//            $seconds_count+=$this->getSecondsFromResult($result);
//
//            //if the operator is online, but he became online after visitor got 'online' status
//            $result = $this->makeSearch("operatorid=:operatorid AND timeoffline is null
//                    AND timeonline>:visitor_online_time
//                    AND timeonline<=:visitor_modified_time",
//                    array("operatorid"=>$operatorid, "visitor_online_time"=>$visitorOnlineTime['created'],
//                        "visitor_modified_time"=>$visitorOnlineTime['modified']),
//                    "timestampdiff(SECOND ,timeonline,current_timestamp()) as seconds_count");
//            $seconds_count+=$this->getSecondsFromResult($result);
//        }
//        return $seconds_count;
//    }
//
//    public function getVisitorWaitingTimeForClosedPeriods($operatorid, $threadId) {
//        $visitorOnlineTime = $this->getVisitorOnlineTime($threadId);
//        $seconds_count = 0;
//
//        if (!empty($visitorOnlineTime)) {
//            $result = $this->makeSearch("operatorid=:operatorid AND timeonline<:visitor_online_time AND timeoffline>:visitor_online_time",
//                    array("operatorid"=>$operatorid, "visitor_online_time"=>$visitorOnlineTime['created']),
//                    "timestampdiff(SECOND ,:visitor_online_time,timeoffline) as seconds_count");
//
//            $seconds_count += $this->getSecondsFromResult($result);
//
//            $result = $this->makeSearch("operatorid=:operatorid AND timeonline>:visitor_online_time AND timeoffline<:visitor_modified_time",
//                    array("operatorid"=>$operatorid, "visitor_online_time"=>$visitorOnlineTime['created'],
//                    "visitor_modified_time"=>$visitorOnlineTime['modified']),
//                    "sum(timestampdiff(SECOND ,timeonline,timeoffline)) as seconds_count");
//
//            $seconds_count += $this->getSecondsFromResult($result);
//
//            return $seconds_count;
//        }
//    }
}
?>
