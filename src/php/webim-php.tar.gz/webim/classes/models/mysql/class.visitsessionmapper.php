<?php
require_once(dirname(__FILE__) . '/class.basemapper.php');

class VisitSessionMapper extends BaseMapper {
    public function __construct($model_name) {
        // TRICK: the real PK field in db is "id" but it is not used in code, "visitsessionid" used instead as id_column
        // and it's marked as non autoincrement to be stored when inserting new record
        parent::__construct($model_name, array('created', 'updated'), false, null, null,
            array(
                array('name' => 'country', 'sql' => 'alter table {visitsession} add column country varchar(128) CHARACTER SET "utf8" NULL DEFAULT NULL'),
                array('name' => 'region', 'sql' => 'alter table {visitsession} add column region tinytext CHARACTER SET "utf8" NULL'),
                array('name' => 'city', 'sql' => 'alter table {visitsession} add column city tinytext CHARACTER SET "utf8" NULL')));
    }

    public function getSessionsWithVisitorsData() {
        return new Wrapper_SelectQuery($this->db, array(
            'fields' => array('*', $this->getDateColumnsSql()),
            'tables' => '{visitsession}',
            'where' => 'json LIKE BINARY "%email%" OR json LIKE BINARY "%phone%"',
            'group' => 'visitorid',
            'order' => 'id DESC'
        ));
    }

    public function getByThreadIds(array $ids) {
        $rows = array();
        if (!empty($ids)) {
            $sql = 'SELECT vs.*, t.threadid FROM {visitsession} vs
                JOIN {thread} t ON t.visitsessionid = vs.visitsessionid
                WHERE t.threadid IN (:threadids)';

            $rows = $this->queryArrayOfRows($sql, array('threadids' => $ids));
        }
        return $rows;
    }

    public function getBySessionId($id) {
        $row = NULL;
        if (!empty($id)) {
            $rows = $this->makeSearch('visitsessionid = :id', array('id' => $id));
            $row = !empty($rows) ? array_shift($rows) : NULL;
        }

        return $row;
    }

    public function getByRangeQuery($startDate, $endDate, $lastSyncedId = null) {
        return new Wrapper_SelectQuery(
            $this->db,
            array(
                'fields' => '*',
                'tables' => $this->getTableNameForQueries(),
                'where' => array(
                    'created BETWEEN :startDate AND :endDate',
                    $lastSyncedId ? 'messageid > :id' : '1=1'
                )
            ),
            array(
                'startDate' => $startDate->format('Y-m-d H:i:s'),
                'endDate' => $endDate->format('Y-m-d H:i:s'),
                'id' => $lastSyncedId
            ),
            array(
                'rowsPerRequest' => 5000
            )
        );
    }
}
