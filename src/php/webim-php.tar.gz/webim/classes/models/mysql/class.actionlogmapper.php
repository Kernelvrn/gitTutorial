<?php
require_once (dirname(__FILE__) . '/class.basemapper.php');

/**
 * Class for working with operatoractionlog.
 */
class ActionLogMapper extends BaseMapper {
  public function __construct($modelName) {
    parent::__construct($modelName, array('dtm'), true, 'id',
      "CREATE TABLE actionlog (
      id INT( 11 ) AUTO_INCREMENT NOT NULL,
      dtm DATETIME NOT NULL,
      actiontarget VARCHAR( 255 ) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL,
      actiontype ENUM( 'create', 'update', 'delete', 'login', 'logout', 'failed' , 'reset') CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL,
      operatorid INT( 11 ) unsigned NOT NULL,
      operatorfullname VARCHAR( 255 ) CHARACTER SET utf8 COLLATE utf8_general_ci NULL,
      newvalue TEXT CHARACTER SET utf8 COLLATE utf8_general_ci NULL,
      oldvalue TEXT CHARACTER SET utf8 COLLATE utf8_general_ci NULL,
      ip VARCHAR( 15 ) CHARACTER SET utf8 COLLATE utf8_general_ci NULL,
      useragent VARCHAR( 255 ) CHARACTER SET utf8 COLLATE utf8_general_ci NULL,
      diff TEXT CHARACTER SET utf8 COLLATE utf8_general_ci NULL,
      operatorsessionid VARCHAR( 255 ) CHARACTER SET utf8 COLLATE utf8_general_ci NULL,
      PRIMARY KEY ( id )
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8",
    array(
        array('name' => 'diff', 'sql' => 'alter table actionlog add column diff text CHARACTER SET utf8 COLLATE utf8_general_ci NULL'),
        array('name' => 'operatorsessionid', 'sql' => 'alter table actionlog add column operatorsessionid VARCHAR( 255 ) CHARACTER SET utf8 COLLATE utf8_general_ci NULL'),
        array('name' => 'operatorfullname', 'sql' => 'alter table actionlog add column operatorfullname VARCHAR( 255 ) CHARACTER SET utf8 COLLATE utf8_general_ci NULL')
    ), array(), array(), array(), array(
        array('name' => 'actiontype', 'sql' => 'alter table actionlog modify column actiontype ENUM( \'create\', \'update\', \'delete\', \'login\', \'logout\', \'failed\', \'reset\') CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL',
            'modifiedValue' => 'ENUM( \'create\', \'update\', \'delete\', \'login\', \'logout\', \'failed\', \'reset\') CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL')
    )
    );
  }

  protected function getTableNameForQueries() {
    return '`' . $this->getTableName() . '`';
  }


}

?>
