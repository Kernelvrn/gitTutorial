<?php
require_once dirname(__FILE__) . '/class.basemapper.php';

class OperatorAccountMapper extends BaseMapper {
  public function __construct($model_name) {
    parent::__construct($model_name);
  }

  public function getDatabaseKey() {
    return 'operators';
  }

  public function save($data) {
    $result = parent::save($data);

    return $result;
  }

  public function setOperatorRolesForAccount($operatorId, $roles, $accountName) {
    $data = array();

    $res = MapperFactory::getOperatorAccountViewMapper()->getByOperatorIdAndAccount($operatorId, $accountName);
    if ($res !== null) {
      $data['operatoraccountid'] = $res['operatoraccountid'];
    }

    $data['operatorid'] = $operatorId;
    $data['accountname'] = $accountName;
    $data['roles'] = is_array($roles) ? join(',', $roles) : $roles;

    $result = $this->save($data);
    return $result;
  }

  public function delete($id) {
    $data = parent::getById($id);
    $result = parent::delete($id);

    return $result;
  }
}

?>