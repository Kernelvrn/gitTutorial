<?php
class Model_Rate extends Model_Base {
    /**
     * @var null|int
     */
    protected $operatorId = NULL;
    /**
     * @var null|Model_Operator
     */
    protected $operator = NULL;
    /**
     * @var null|int
     */
    protected $threadId = NULL;
    /**
     * @var null|int
     */
    protected $value = NULL;
    /**
     * @var null|\DateTime
     */
    protected $created = NULL;

    function __construct(array $rateRow) {
        if (empty($rateRow['threadid']) || empty($rateRow['operatorid']) && empty($rateRow['operator']) || !isset($rateRow['rate']) ) {
            throw new Exception('Can\'t create rate without thread, operator or value');
        }

        $defaults = array(
            'rateid' => NULL,
            'date' => NULL,
            'operator' => NULL,
            'operatorid' => NULL
        );
        $rateRow = array_merge($defaults, $rateRow);

        parent::__construct($rateRow['rateid']);

        $this->created = Helper::getAccountDateTime($rateRow['date']);
        $this->operatorId = $rateRow['operatorid'];
        $this->operator = $rateRow['operator'];
        $this->value = $rateRow['rate'];
        $this->threadId = $rateRow['threadid'];
    }

    /**
     * @return \DateTime|null
     */
    public function getCreated() {
        return $this->created;
    }

    /**
     * Возвращает оператора, для которого поставлен рейтинг. Если такового оператора не существует
     * (так как он был удалён, например), создаёт просто пустую модель.
     * @return Model_Operator
     */
    public function getOperator() {
        if (!isset($this->operator)) {
            /**
             * @var $repository Repository_Operator
             */
            $repository = Factory_Repository::create('Operator');
            $this->operator = $repository->findById($this->operatorId) || new Model_Operator();
        }
        return $this->operator;
    }

    /**
     * @return int|null
     */
    public function getThreadId() {
        return $this->threadId;
    }

    /**
     * @return int|null
     */
    public function getValue() {
        return $this->value;
    }
}