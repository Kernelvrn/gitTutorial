<?php

class MapperFactory {
    protected static $mappers = array();

    protected function __construct() { }
    /**
     * @return AuthtokenMapper
     */
    static public function getAuthtokenMapper() {
        return self::getMapper('Authtoken');
    }

    /**
     * @return PromocodeMapper
     */
    static public function getPromocodeMapper() {
        return self::getMapper('Promocode');
    }

    /**
     * @return OrderedServiceMapper
     */
    static public function getOrderedServiceMapper() {
        return self::getMapper('OrderedService');
    }

    /**
     * @return OperatorDepartmentMapper
     */
    static public function getOperatorDepartmentMapper() {
        return self::getMapper('OperatorDepartment');
    }

    /**
     * @return OperatorLastAccessMapper
     */
    static public function getOperatorLastAccessMapper() {
        return self::getMapper('OperatorLastAccess');
    }

    /**
     * @return AccountMapper
     */
    static public function getAccountMapper() {
        return self::getMapper('Account');
    }

    /**
     * @return BanMapper
     */
    static public function getBanMapper() {
        return self::getMapper('Ban');
    }

    /**
     * @return ThreadMapper
     */
    static public function getThreadMapper() {
        return self::getMapper('Thread');
    }

    /**
     * @return AutoInviteMapper
     */
    static public function getAutoInviteMapper() {
        return self::getMapper('AutoInvite');
    }

    /**
     * @return MessageMapper
     */
    static public function getMessageMapper() {
        return self::getMapper('Message');
    }

    /**
     * @return InvitationMapper
     */
    static public function getInvitationMapper() {
        return self::getMapper('Invitation');
    }

    /**
     * @return DepartmentLocaleMapper
     */
    static public function getDepartmentLocaleMapper() {
        return self::getMapper('DepartmentLocale');
    }

    /**
     * @return DepartmentMapper
     */
    static public function getDepartmentMapper() {
        return self::getMapper('Department');
    }

    /**
     * @return RateMapper
     */
    static public function getRateMapper() {
        return self::getMapper('Rate');
    }

    /**
     * @return VisitSessionMapper
     */
    static public function getVisitSessionMapper() {
        return self::getMapper('VisitSession');
    }

    /**
     * @return OperatorAccountViewMapper
     */
    static public function getOperatorAccountViewMapper() {
        return self::getMapper('OperatorAccountView');
    }

    /**
     * @return OperatorSupervisorMapper
     */
    static public function getOperatorSupervisorMapper() {
        return self::getMapper('OperatorSupervisor');
    }

    /**
     * @return LoginAttemptMapper
     */
    static public function getLoginAttemptMapper() {
        return self::getMapper('LoginAttempt');
    }

    /**
     * @return AccountKeyValueMapper
     */
    static public function getAccountKeyValueMapper() {
        return self::getMapper('AccountKeyValue');
    }

    /**
     * @return ActionLogMapper
     */
    static public function getActionLogMapper() {
        return self::getMapper('ActionLog');
    }

    /**
     * @return AccountSentStatsMapper
     */
    static public function getAccountSentStatsMapper() {
        return self::getMapper('AccountSentStats');
    }

    /**
     * @return StatsLogMapper
     */
    static public function getStatsLogMapper() {
        return self::getMapper('StatsLog');
    }

    /**
     * @return OperatorMapper
     */
    static public function getOperatorMapper() {
        return self::getMapper('Operator');
    }

    /**
     * @return OperatorAccountMapper
     */
    static public function getOperatorAccountMapper() {
        return self::getMapper('OperatorAccount');
    }

    /**
     * @return BuhCardMapper
     */
    static public function getBuhCardMapper() {
        return self::getMapper('BuhCard');
    }

    /**
     * @return InvoiceMapper
     */
    static public function getInvoiceMapper() {
        return self::getMapper('Invoice');
    }

    /**
     * @return ProRateMapper
     */
    static public function getProRateMapper() {
        return self::getMapper('ProRate');
    }

    /**
     * @return TariffMapper
     */
    static public function getTariffMapper() {
        return self::getMapper('Tariff');
    }

    /**
     * @return HitGoalMapper
     */
    static public function getHitGoalMapper() {
        return self::getMapper('HitGoal');
    }

    /**
     * @return OrganizationMapper
     */
    static public function getOrganizationMapper() {
        return self::getMapper('Organization');
    }

    /**
     * @return OperatorOnlineMapper
     */
    static public function getOperatorOnlineMapper() {
        return self::getMapper('OperatorOnline');
    }

    /**
     * @return OnlinePeriodsMapper
     */
    static public function getOnlinePeriodsMapper() {
        return self::getMapper('OnlinePeriods');
    }

    /**
     * @return ConfigMapper
     */
    static public function getConfigMapper() {
        return self::getMapper('Config');
    }

    /**
     * @return LostVisitorMapper
     */
    static public function getLostVisitorMapper() {
        return self::getMapper('LostVisitor');
    }

    /**
     * @return VisitedPageMapper
     */
    static public function getVisitedPageMapper() {
        return self::getMapper('VisitedPage');
    }

    /**
     * @return WriteoffMapper
     */
    static public function getWriteoffMapper() {
        return self::getMapper('Writeoff');
    }

    /**
     * @return OnlinePeriodMapper
     */
    static public function getOnlinePeriodMapper() {
        return self::getMapper('OnlinePeriod');
    }

    /**
     * @return StatsMapper
     */
    static public function getStatsMapper() {
        return self::getMapper('Stats');
    }

    /**
     * @return ThreadHistoryMapper
     */
    static public function getThreadHistoryMapper() {
        return self::getMapper('ThreadHistory');
    }

    /**
     * @return TmpStatsThreadHistory2Mapper
     */
    static public function getTmpStatsThreadHistory2Mapper() {
        return self::getMapper('TmpStatsThreadHistory2');
    }

    static protected function getMapper($model_class) {
        if (!isset(self::$mappers[$model_class])) {
            $mapper_class = $model_class . 'Mapper';
            $include_file = dirname(__FILE__) . '/../' . strtolower(SITE_DB_TYPE) . '/class.' . strtolower($mapper_class) . '.php';
            if (!include_once($include_file)) {
                throw new Exception("Cound't load mapper class $mapper_class file $include_file");
            }

            if (!class_exists($mapper_class)) {
                doMyLog("Class $mapper_class not found", true, true);
            }
            $mapper = new $mapper_class($model_class);

            self::$mappers[$model_class] = $mapper;
        }
        return self::$mappers[$model_class];
    }

    /**
     * @return LtSiteMapper
     */
    public static function getLtSiteMapper() {
        return self::getMapper('LtSite');
    }

    /**
     * @return InsalesAccountMapper
     */
    static public function getInsalesAccountMapper() {
        return self::getMapper('InsalesAccount');
    }

    /**
     * @return AccountCreatorMapper
     */
    public static function getAccountCreatorMapper() {
        return self::getMapper('AccountCreator');
    }

    /**
     * @return DnsDomainMapper
     */
    public static function getDnsDomainMapper() {
        return self::getMapper('DnsDomain');
    }

    /**
     * @return CallbackMapper
     */
    public static function getCallbackMapper() {
        return self::getMapper('Callback');
    }

    /**
     * @return CBHStatsMapper
     */
    public static function getCBHStatsMapper() {
        return self::getMapper("CBHStats");
    }

    /**
     * @return BackgroundTaskMapper
     */
    public static function getBackgroundTaskMapper() {
        return self::getMapper('BackgroundTask');
    }
}
