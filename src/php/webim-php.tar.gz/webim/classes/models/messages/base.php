<?php

class Model_Message_Base extends Model_Base {
    /**
     * @var null|int Идентификатор чата, к которому относится сообщение
     */
    protected $threadId = NULL;
    /**
     * @var null|int Тип сообщения.
     */
    protected $kind = NULL;
    /**
     * @var null|int
     */
    protected $operatorId = NULL;
    /**
     * @var string
     */
    protected $text = '';
    /**
     * @var \DateTime
     */
    protected $created = NULL;
    /**
     * @var null|string
     */
    protected $senderName = NULL;
    /**
     * @var null|array
     */
    protected $json = NULL;

    /**
     * @var array
     * @const
     */
    public static $KINDS = array(
        'VISITOR' => 1,
        'OPERATOR' => 2,
        'FOR_OPERATOR' => 3,
        'INFO' => 4,
        'OPERATOR_BUSY' => 9,
        'CONT_REQ' => 10,
        'CONTACTS' => 11,
        'FILE_OPERATOR' => 13,
        'FILE_VISITOR' => 14,
        'FORM_RESPONSE' => 15
    );

    public function __construct(array $messageRow) {
        if (empty($messageRow['threadid']) ) {
            throw new Exception('Can\'t create message without thread');
        }

        $defaults = array(
            'messageid' => NULL,
            'operatorid' => NULL,
            'message' => '',
            'created' => NULL,
            'sendername' => NULL,
            'json' => NULL
        );

        $messageRow = array_merge($defaults, $messageRow);

        parent::__construct($messageRow['messageid']);

        $this->threadId = $messageRow['threadid'];
        $this->kind = (int)$messageRow['kind'];
        $this->operatorId = $messageRow['operatorid'];
        $this->text = $messageRow['message'];
        $this->created = Helper::getAccountDateTime($messageRow['created']);
        $this->senderName = $messageRow['sendername'];
        $this->json = $messageRow['json'] ? json_decode($messageRow['json']) : NULL;
    }

    /**
     * @return \DateTime
     */
    public function getCreated() {
        return $this->created;
    }

    /**
     * @return array|null
     */
    public function getJson() {
        return $this->json;
    }

    /**
     * @return int|null
     */
    public function getKind() {
        return $this->kind;
    }

    /**
     * @return int|null
     */
    public function getOperatorId() {
        return $this->operatorId;
    }

    /**
     * @return null|string
     */
    public function getSenderName() {
        return $this->senderName;
    }

    /**
     * @return string
     */
    public function getText() {
        return $this->text;
    }

    /**
     * @return int|null
     */
    public function getThreadId() {
        return $this->threadId;
    }

    /**
     * Переопределяется в потомках для возвращения основного содержимого сообщения в зависимости от типа.
     * Например, для пересылаемого файла это будет массив данных о файле.
     * @return mixed
     */
    public function getContent() {
        return $this->getText();
    }
}