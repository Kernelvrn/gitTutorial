<?php

class Model_Message_FileVisitor extends Model_Message_Base {
    public function getContent() {
        return json_decode(iconv(WEBIM_ENCODING, 'utf-8', $this->getText()), true);
    }
}