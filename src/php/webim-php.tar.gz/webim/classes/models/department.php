<?php

class Model_Department extends Model_Base {
    /**
     * Уникальный ключ отдела в рамках аккаунта
     * @var null|string
     */
    protected $key;
    /**
     * Используется для сортировки отделов при выводе в чате
     * @var null|int
     */
    protected $order;
    /**
     * Используется для выбора отдела на основе геоинформации об обращении
     * @var null|string
     */
    protected $geo;
    /**
     * @var bool
     */
    protected $private = false;
    /**
     * @var bool
     */
    protected $deleted = false;

    /**
     * @var bool
     */
    protected $hidden = false;
    /**
     * @var null|array
     */
    protected $config;
    /**
     * @var null|array
     */
    protected $names;
    /**
     * @var null|array
     */
    protected $answers;


    public function __construct(array $departmentRow) {
        $defaults = array(
            'departmentid' => NULL,
            'departmentorder' => 0,
            'departmentgeo' => NULL,
            'departmentkey' => NULL,
            'isprivate' => false,
            'ishidden' => false,
            'names' => NULL,
            'config' => array(),
            'deleted' => false
        );

        $departmentRow = array_merge($defaults, $departmentRow);
        parent::__construct($departmentRow['departmentid']);
        $this->key = $departmentRow['departmentkey'];
        $this->order = (int)$departmentRow['departmentorder'];
        $this->geo = $departmentRow['departmentgeo'];
        $this->private = (bool)$departmentRow['isprivate'];
        $this->hidden = (bool)$departmentRow['ishidden'];
        $this->config = $departmentRow['config']
            ? is_array($departmentRow['config'])
                ? $departmentRow['config']
                : json_decode($departmentRow['config'], true)
            : array();
        $this->names = $departmentRow['names'];
        $this->deleted = (bool)$departmentRow['deleted'];
    }

    /**
     * @return boolean
     */
    public function isDeleted() {
        return $this->deleted;
    }

    /**
     * @param boolean $deleted
     */
    public function setDeleted($deleted) {
        $this->deleted = $deleted;
    }

    /**
     * @return bool|null
     */
    public function getRouting() {
        return array_key_exists('routing', $this->config) ? $this->config['routing'] : FALSE;
    }

    /**
     * @param bool|null $routing
     */
    public function setRouting($routing) {
        $this->config['routing'] = $routing;
    }

    /**
     * @return array|null
     */
    public function getAnswers() {
        return array_key_exists('answers', $this->config) ? json_decode($this->config['answers'], true) : null;
    }

    /**
     * @return array|null
     */
    public function getLogo() {
        return array_key_exists('logo', $this->config) ? $this->config['logo'] : null;
    }

    /**
     * @param string|null $logo
     */
    public function setLogo($logo) {
        $this->config['logo'] = $logo;
    }

    /**
     * @return array|null
     */
    public function getCallbackHunterNumber() {
        return array_key_exists('callback_hunter_number', $this->config) ? $this->config['callback_hunter_number'] : null;
    }

    /**
     * @return array|null
     */
    public function getPublicCallbackHunterNumber() {
        return array_key_exists('public_callback_hunter_number', $this->config) ? $this->config['public_callback_hunter_number'] : null;
    }

    /**
     * @return array|null
     */
    public function getConfig() {
        if (empty($this->config)) {
            $this->config = array(
                'answers' => json_encode(array())
            );
        }
        return $this->config;
    }

    /**
     * @return null|string
     */
    public function getGeo() {
        return $this->geo;
    }

    /**
     * @return boolean
     */
    public function isHidden() {
        return $this->hidden;
    }

    /**
     * @return null|string
     */
    public function getKey() {
        return $this->key;
    }

    /**
     * @return array|null
     */
    public function getNames() {
        return $this->names;
    }

    /**
     * @param $locale
     * @return string|null
     */
    public function getNameByLocale($locale) {
        return $this->names && array_key_exists($locale, $this->names)
            ? $this->names[$locale]
            : NULL;
    }

    /**
     * @return int|null
     */
    public function getOrder() {
        return $this->order;
    }

    /**
     * @return boolean
     */
    public function isPrivate() {
        return $this->private;
    }

    /**
     * @param int|null $order
     */
    public function setOrder($order) {
        $this->order = $order;
    }

    /**
     * @param array|null $answers
     */
    public function setAnswers($answers) {
        $this->config['answers'] = json_encode(is_array($answers) ? $answers :  array());
    }

    /**
     * @param string|null $callbackHunterNumber
     */
    public function setCallbackHunterNumber($callbackHunterNumber) {
        $this->config['callback_hunter_number'] = $callbackHunterNumber;
    }

    /**
     * @param string|null $publicCallbackHunterNumber
     */
    public function setPublicCallbackHunterNumber($publicCallbackHunterNumber) {
        $this->config['public_callback_hunter_number'] = $publicCallbackHunterNumber;
    }

    /**
     * @param null|string $key
     */
    public function setKey($key) {
        $this->key = $key;
    }

    /**
     * @param null|string $geo
     */
    public function setGeo($geo) {
        $this->geo = $geo;
    }

    /**
     * @param boolean $hidden
     */
    public function setHidden($hidden) {
        $this->hidden = $hidden;
    }

    /**
     * @param array|null $config
     */
    public function setConfig($config) {
        $this->config = $config;
    }

    /**
     * @param string|null $name
     * @param string|null $locale
     */
    public function setNameByLocale($name, $locale) {
        $this->names[$locale] = $name;
    }

    /**
     * @return string|null
     */
    public function getAgentHelloText() {
        return array_key_exists('agent_hello_text', $this->config)
            ? (array_key_exists(Resources::getCurrentLocale(), $this->config['agent_hello_text'])
                ? $this->config['agent_hello_text'][Resources::getCurrentLocale()]
                : null)
            : null;
    }

    /**
     * @param string|null $agentHelloText
     */
    public function setAgentHelloText($agentHelloText) {
        if (empty($agentHelloText)) {
            unset($this->config['agent_hello_text'][Resources::getCurrentLocale()]);
            if (empty($this->config['agent_hello_text'])) {
                unset($this->config['agent_hello_text']);
            }
        } else {
            $this->config['agent_hello_text'][Resources::getCurrentLocale()] = $agentHelloText;
        }
    }

    /**
     * @return int|null
     */
    public function getAgentCantPickTimeout() {
        return array_key_exists('agent_cant_pick_timeout', $this->config) ? $this->config['agent_cant_pick_timeout'] : null;
    }

    /**
     * @param int|null $agentCantPickTimeout
     */
    public function setAgentCantPickTimeout($agentCantPickTimeout) {
        if (empty($agentCantPickTimeout)) {
            unset($this->config['agent_cant_pick_timeout']);
        } else {
            $this->config['agent_cant_pick_timeout'] = intval($agentCantPickTimeout);
        }
    }

    /**
     * @return int|null
     */
    public function getAgentBusyTimeout() {
        return array_key_exists('agent_busy_timeout', $this->config) ? $this->config['agent_busy_timeout'] : null;
    }

    /**
     * @param int|null $agentBusyTimeout
     */
    public function setAgentBusyTimeout($agentBusyTimeout) {
        if (empty($agentBusyTimeout)) {
            unset($this->config['agent_busy_timeout']);
        } else {
            $this->config['agent_busy_timeout'] = intval($agentBusyTimeout);
        }
    }

    /**
     * @return string|null
     */
    public function getAgentBusyText() {
        return array_key_exists('agent_busy_text', $this->config)
            ? (array_key_exists(Resources::getCurrentLocale(), $this->config['agent_busy_text'])
                ? $this->config['agent_busy_text'][Resources::getCurrentLocale()]
                : null)
            : null;
    }

    /**
     * @param string|null $agentBusyText
     */
    public function setAgentBusyText($agentBusyText) {
        if (empty($agentBusyText)) {
            unset($this->config['agent_busy_text'][Resources::getCurrentLocale()]);
            if (empty($this->config['agent_busy_text'])) {
                unset($this->config['agent_busy_text']);
            }
        } else {
            $this->config['agent_busy_text'][Resources::getCurrentLocale()] = $agentBusyText;
        }
    }

    /**
     * @return int|null
     */
    public function getTimeoutForChatAutoCloseIfChatIsInactive() {
        return array_key_exists('timeout_for_chat_auto_close_if_chat_is_inactive', $this->config) ? $this->config['timeout_for_chat_auto_close_if_chat_is_inactive'] : null;
    }

    /**
     * @param int|null $timeoutForChatAutoCloseIfChatIsInactive
     */
    public function setTimeoutForChatAutoCloseIfChatIsInactive($timeoutForChatAutoCloseIfChatIsInactive) {
        if (empty($timeoutForChatAutoCloseIfChatIsInactive)) {
            unset($this->config['timeout_for_chat_auto_close_if_chat_is_inactive']);
        } else {
            $this->config['timeout_for_chat_auto_close_if_chat_is_inactive'] = intval($timeoutForChatAutoCloseIfChatIsInactive);
        }
    }

    /**
     * @return int|null
     */
    public function getTimeoutForChatAutoCloseIfClosedByOperator() {
        return array_key_exists('timeout_for_chat_auto_close_if_closed_by_operator', $this->config) ? $this->config['timeout_for_chat_auto_close_if_closed_by_operator'] : null;
    }

    /**
     * @param int|null $timeoutForChatAutoCloseIfClosedByOperator
     */
    public function setTimeoutForChatAutoCloseIfClosedByOperator($timeoutForChatAutoCloseIfClosedByOperator) {
        if (empty($timeoutForChatAutoCloseIfClosedByOperator)) {
            unset($this->config['timeout_for_chat_auto_close_if_closed_by_operator']);
        } else {
            $this->config['timeout_for_chat_auto_close_if_closed_by_operator'] = intval($timeoutForChatAutoCloseIfClosedByOperator);
        }
    }

    /**
     * Возвращает отдел
     * @return array
     */
    public function toDBRow() {
        return array(
            'departmentid' => $this->getId(),
            'departmentkey' => $this->getKey(),
            'departmentorder' => $this->getOrder(),
            'departmentgeo' => $this->getGeo(),
            'isprivate' => $this->isPrivate(),
            'ishidden' => $this->isHidden(),
            'config' => json_encode($this->getConfig()),
            'deleted' => $this->isDeleted()
        );
    }

    /**
     * Возвращает отдел
     * @return array
     */
    public function toRow() {
        return array(
            'departmentid' => $this->getId(),
            'departmentname' => $this->getNameByLocale(Resources::getCurrentLocale()),
            'departmentkey' => $this->getKey(),
            'departmentorder' => $this->getOrder(),
            'departmentgeo' => $this->getGeo(),
            'ishidden' => $this->isHidden(),
            'logo' => $this->getLogo(),
            'deleted' => $this->isDeleted(),
            'public_callback_hunter_number' => $this->getPublicCallbackHunterNumber(),
            'callback_hunter_number' => $this->getCallbackHunterNumber(),
            'agent_hello_text' => $this->getAgentHelloText(),
            'agent_cant_pick_timeout' => $this->getAgentCantPickTimeout(),
            'agent_busy_timeout' => $this->getAgentBusyTimeout(),
            'agent_busy_text' => $this->getAgentBusyText(),
            'timeout_for_chat_auto_close_if_chat_is_inactive' => $this->getTimeoutForChatAutoCloseIfChatIsInactive(),
            'timeout_for_chat_auto_close_if_closed_by_operator' => $this->getTimeoutForChatAutoCloseIfClosedByOperator()
        );
    }
}