<?php

class Model_Office extends Model_Base {
    /**
     * @var string
     */
    protected $name;

    public function __construct(array $officeRow) {
        if (empty($officeRow['name']) ) {
            throw new InvalidArgumentException('Can\'t create office without name');
        }

        parent::__construct(array_key_exists('id', $officeRow) ? $officeRow['id'] : NULL);
        $this->name = (string) $officeRow['name'];
    }

    /**
     * @return string
     */
    public function getName() {
        return $this->name;
    }
}