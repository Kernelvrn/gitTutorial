<?php
/**
 * Created by JetBrains PhpStorm.
 * User: andrew
 * Date: 9/20/13
 * Time: 8:08 PM
 * To change this template use File | Settings | File Templates.
 */
class InsalesHelper {

    public static function installInsalesButton($insalesId, $accountName) {
        global $MAIN_SETTINGS;
        $insales = MapperFactory::getInsalesAccountMapper()->getByInsalesId($insalesId);
        $insales['accountname'] = $accountName;
        MapperFactory::getInsalesAccountMapper()->save($insales);

//        $url = 'http://' . urlencode($insalesId) . ':' . urlencode($insales['password']) . '@' . $insales['shop'] . '/admin/js_tags.xml';
        $url = 'http://' . urlencode($MAIN_SETTINGS['insales_app_id']) . ':' . urlencode($insales['password']) . '@' . $insales['shop'] . '/admin/js_tags.xml';
        $jsTag = '<js-tag><type type="string">JsTag::FileTag</type><content>' . Helper::getServiceURL($accountName, null, null, false) . WEBIM_ROOT . '/api/insales/insales-button.js.php</content></js-tag>';// TODO make sure http is used

        $ch = curl_init();
        curl_setopt($ch, CURLOPT_URL, $url);
        curl_setopt($ch, CURLOPT_HTTPHEADER, array('Content-Type: text/xml'));
        curl_setopt($ch, CURLOPT_HEADER, 0);
        curl_setopt($ch, CURLOPT_TIMEOUT, 5);
        curl_setopt($ch, CURLOPT_CONNECTTIMEOUT, 2);
        curl_setopt($ch, CURLOPT_POST, 1);
        curl_setopt($ch, CURLOPT_POSTFIELDS, $jsTag);
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
        $result = curl_exec($ch);
        doMyLog("Making curl for insales: ");
        doMyLog($url);
        doMyLog($jsTag);
        doMyLog($result);
        $info = curl_getinfo($ch);
        if ($result !== false && $info['http_code'] == 200) {
            curl_close($ch);
        }
        $insales['dtm_button_code_installed'] = time();
        MapperFactory::getInsalesAccountMapper()->save($insales);
    }
}