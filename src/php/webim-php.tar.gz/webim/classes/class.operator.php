<?php
require_once(dirname(__FILE__) . '/functions.php');
require_once(dirname(__FILE__) . '/models/generic/class.mapperfactory.php');
require_once(dirname(__FILE__) . '/webim_mail.php');
require_once(dirname(__FILE__) . '/../autoload.php');
require_once(dirname(__FILE__) . '/class.authtoken.php');

class Operator {
  private static $instance = null;
  private static $mapper = null;

  public function silentGetCurrentOperator() {
    if (empty($_COOKIE[COOKIE_AUTH_TOKEN])) {
      doMyLog("Cookies: no operator no auth cookie");
      return null;
    }

    if (!Operator::getInstance()->isOperatorFromAllowedIPs($_SERVER['REMOTE_ADDR'])) {
       return null;
    }
    if (isset($_SESSION[SESSION_OPERATOR])
      && Helper::getRolesForAccount(getAccountId()) !== null
    ) {
      $res = Authtoken::getTokenInfo($_COOKIE[COOKIE_AUTH_TOKEN]);
      if (!empty($res) && $_SESSION[SESSION_OPERATOR]['operatorid'] == $res['operatorid']) {
        return $_SESSION[SESSION_OPERATOR];
      }
    }

    if (isset($_COOKIE[COOKIE_AUTH_TOKEN])) {
      doMyLog("Found token: ". $_COOKIE[COOKIE_AUTH_TOKEN], true);

      $res = Authtoken::getTokenInfo($_COOKIE[COOKIE_AUTH_TOKEN]);
      if (empty($res)) {
        return null;
      }

      doMyLog("Got token info: ", true);
      doMyLog($res, true);

      $o = $this->getOperatorById($res['operatorid']);

      $domainURL = Helper::getServiceURL();
      setcookie(COOKIE_WEBIM_URL, $domainURL . WEBIM_ROOT, 0, '/', '.' . Helper::getRootDomain()); // hardcode for plugin

      $this->_doLogin($o, false, true, true);
      return $o;
    }
    return null;
  }

  /**
   * @return Operator
   */
  static function getInstance() {
    if (self::$instance === null) {
      self::$instance = new Operator();
      self::$mapper = MapperFactory::getOperatorMapper();
    }
    return self::$instance;
  }

  private function __construct() {

  }

  private function __clone() {
  }

//  function UpdateOperatorStatus($operator, $status, $departments, $locales) {
//    if (empty($locales)) {
//      $avail_locales = getAvailableLocalesForChat();
//
//      foreach ($avail_locales as $al) {
//        $locales[] = $al['localeid'];
//      }
//    }
//
//    if (empty($departments)) {
//      foreach ($locales as $l) {
//        $filename = OPERATOR_ONLINE_FILES_DIR . DIRECTORY_SEPARATOR .
//            $l . DIRECTORY_SEPARATOR .
//            $operator['operatorid'] . "." . OPERATOR_ONLINE_FILE_EXT;
//
//        if ($status == OPERATOR_STATUS_ONLINE) {
//          touch_online_file($filename);
//        } else {
//          @unlink($filename);
//        }
//      }
//    } else {
//      foreach ($departments as $d) {
//
//        foreach ($locales as $l) {
//          $filename = OPERATOR_ONLINE_FILES_DIR . DIRECTORY_SEPARATOR .
//              $l . DIRECTORY_SEPARATOR .
//              $d['departmentkey'] . DIRECTORY_SEPARATOR .
//              $operator['operatorid'] . "." . OPERATOR_ONLINE_FILE_EXT;
//          if ($status == OPERATOR_STATUS_ONLINE) {
//            touch_online_file($filename);
//          } else {
//            @unlink($filename);
//          }
//        }
//      }
//    }
//  }
//
//  private function getOperatorByIdFromFile($id) {
//    $filename = OPERATOR_CACHE_FILES_DIR . DIRECTORY_SEPARATOR .
//        $id . "." . OPERATOR_CACHE_FILE_EXT;
//
//    if (!file_exists($filename)) {
//      return null;
//    }
//    $stat = stat($filename);
//    if ($stat[9] < getCurrentDBTime() - 30 * 60) {
//      return null;
//    }
//    $data = @file_get_contents($filename);
//    if ($data === false) {
//      return null;
//    }
//    $result = json_safe_decode($data);
//    if ($result === false) {
//      return null;
//    }
//    return $result;
//  }

//  private static function storeOperatorToFile($operator) {
//    create_dir(OPERATOR_CACHE_FILES_DIR);
//    $filename = OPERATOR_CACHE_FILES_DIR . DIRECTORY_SEPARATOR .
//        $operator['operatorid'] . "." . OPERATOR_CACHE_FILE_EXT;
//
//    @file_put_contents($filename, @json_safe_encode($operator), LOCK_EX);
//  }

//  public function deleteOperatorCacheFile($operatorId) {
//    $filename = OPERATOR_CACHE_FILES_DIR . DIRECTORY_SEPARATOR . $operatorId . "." . OPERATOR_CACHE_FILE_EXT;
//    @unlink($filename);
//  }

  public function getOperatorById($operatorId, $accountId = null) {
    if ($accountId === null) {
      $accountId = getAccountId(); // TODO quite hard
    }

    $oo = KeyValueCache::get($operatorId . '-' . (empty($accountId) ? '' : $accountId), 'getOperatorById');
    if ($oo !== null) {
      return $oo;
    }
    /* pl */
//    $o = $this->getOperatorByIdFromFile($operatorId);
//    if ($o === null) {
      $oo = $accountId !== null ?
          MapperFactory::getOperatorAccountViewMapper()->getByOperatorIdAndAccount($operatorId, $accountId)
          :
          MapperFactory::getOperatorAccountViewMapper()->getByOperatorId($operatorId) ;
      if (empty($oo)) {
        return null;
      }
      $o = MapperFactory::getOperatorMapper()->getById($operatorId);

      if (getAccountId() !== null) {
        if ($o !== null && !empty($o)) {
          $la = MapperFactory::getOperatorLastAccessMapper()->getById($operatorId);
          if (!empty($la)) {
            $o = array_merge($o, $la);
          }

          $departments = MapperFactory::getOperatorDepartmentMapper()->enumDepartmentKeysByOperator($operatorId);
          $departmentKeys = array();
          foreach ($departments as $d) {
            $departmentKeys[] = $d['departmentkey'];
          }
          $o['departments'] = $departmentKeys;
        }
    }
    KeyValueCache::put($operatorId . '-' . (empty($accountId) ? '' : $accountId), $o, 'getOperatorById', 60*10); // 10 minutes

    return $o;
  }

  public function getPredefinedAnswers($operatorId) {
      $operator = Operator::getOperatorById($operatorId);

      $config = json_decode($operator['config'], true);
      $answers = array();
      if ($config && isset($config['answers'])) {
          $answers = $config['answers'];
      }
      return $answers;
  }

  public function getPredefinedAnswersByLocale($operatorId, $lang) {
      $answers = Operator::getPredefinedAnswers($operatorId);
      return $answers && isset($answers[$lang]) ? $answers[$lang] : array();
  }


  public function setPredefinedAnswersByLocale($operatorId, $answers, $lang) {
      $operator = Operator::getOperatorById($operatorId);

      $config =  json_decode($operator['config'], true);
      $config['answers'][$lang] = $answers;

      $jsonConfig = json_encode_readable($config);

      if (strlen($jsonConfig) > 500000) {
          throw new Exception('Operator->setPredefinedAnswersByLocale: Operator predefined answers too long');
      }

      Operator::getInstance()->UpdateOperator($operator['operatorid'], array('config' => $jsonConfig));

      KeyValueCache::clearKind('operators');
      KeyValueCache::clearKind('getOperatorById');
  }

  function getOperatorWhithLastAccessInfoById($id, $accountId = null) {
    if ($accountId === null) {
      $accountId = getAccountId();
    }
//    return $this->getOperatorById($id); // TODO

    $details = Operator::getOperatorById($id, $accountId);

    if ($details === null) {
      return null;
    }

    $lastAccess = MapperFactory::getOperatorLastAccessMapper()->getById($id);

    return is_array($lastAccess) ? array_merge($details, $lastAccess) : $details;
  }

  function updateOperatorOnlineStats() {
    //    $operator = $this->getLoggedOperatorOrRedirect();
    $operator = self::silentGetCurrentOperator();
    $this->updateOperatorOnlineTime($operator['operatorid']);
    //MapperFactory::getOperatorOnlineMapper()->updateOperatorOnlineTime($operator['operatorid']);

    if (has_file_value(HAS_ACTIVE_THREADS_FILE) && MapperFactory::getThreadMapper()->operatorHasActiveThreads($operator['operatorid'])) {
      //MapperFactory::getOperatorOnlineMapper()->updateOperatorOnlineTime($operator['operatorid'], /* TODO magick threadid constant */ -2);
      $this->updateOperatorOnlineTime($operator['operatorid'], /* TODO magick threadid constant */
        -2);
    }
  }

  function updateOperatorOnlineStatsForThread($thread) {
    $threadid = $thread['threadid'];
    $operator = self::silentGetCurrentOperator();
    $this->updateOperatorOnlineTime($operator['operatorid'], $threadid);
    //MapperFactory::getOperatorOnlineMapper()->updateOperatorOnlineTime($operator['operatorid'], $threadid);
  }

  private function pushOnlineStatsToDB($operatorid) {
//    $stats = array();
//    $filename = self::operatorOnlineStatsFilename($operatorid);
//
//    if (file_exists($filename)) {
//      $data = @file_get_contents($filename);
//      if ($data !== false) {
//        $tmp = @json_decode($data, true);
//        if ($tmp !== false) {
//          $stats = $tmp;
//        }
//      }
//    }
//
//    if (empty($stats)) {
//      return false;
//    }
//
//    MapperFactory::getOperatorOnlineMapper()->pushOnlineStatsForOperator($operatorid, $stats);
//    @unlink($filename);
  }

  public function loadOnlineStatsIntoDB() {
//    $dh = @opendir(OPERATOR_ONLINE_STATS_FILES_DIR);
//    if (!$dh) {
//      return;
//    }
//    while ($file = readdir($dh)) {
//      $ext = pathinfo($file, PATHINFO_EXTENSION);
//      if ($ext == OPERATOR_ONLINE_STATS_FILE_EXT) {
//        $operatorid = substr($file, 0, strlen($file) - strlen($ext) - 1);
//        $this->pushOnlineStatsToDB($operatorid);
//      }
//    }
//
//    closedir($dh);
  }

  private function updateOperatorOnlineTime($operatorid, $threadid = -1) {
//    $stats = array();
//    $filename = self::operatorOnlineStatsFilename($operatorid);
//    if (file_exists($filename)) {
//      $data = @file_get_contents($filename);
//      if ($data !== false) {
//        $tmp = @json_decode($data, true);
//        if ($tmp !== false) {
//          $stats = $tmp;
//        }
//      }
//    } else {
//      create_basedir($filename);
//    }
//
//    $cur_date = date("Y-m-d");
//    if (isset($stats[$threadid], $stats[$threadid][$cur_date])) {
//      $delta = time() - $stats[$threadid][$cur_date]['updated']; // TODO check time() invokation
//      $stats[$threadid][$cur_date]['seconds'] = $stats[$threadid][$cur_date]['seconds'] + ($delta < TIMEOUT_OPERATOR_PING * 2 ? $delta : 1);
//    } else {
//      if (isset($stats[$threadid])) {
//        $stats[$threadid] = array();
//      }
//
//      $stats[$threadid][$cur_date]['seconds'] = 1;
//      $stats[$threadid][$cur_date]['threadid'] = $threadid;
//      $stats[$threadid][$cur_date]['date'] = $cur_date;
//    }
//
//    $stats[$threadid][$cur_date]['updated'] = time();
//
//    @file_put_contents($filename, json_encode($stats), LOCK_EX);
//    if (filesize($filename) > OPERATOR_ONLINE_STATS_FILE_MAX_SIZE) {
//      $this->pushOnlineStatsToDB($operatorid);
//    }
  }

  private static function operatorOnlineStatsFilename($operatorid) {
    if (!preg_match("/^\d+$/", $operatorid) || $operatorid < 0) {
//      throw new Exception("Incorrect operator id " . $operatorid); // debug
    }
    return OPERATOR_ONLINE_STATS_FILES_DIR . DIRECTORY_SEPARATOR .
        $operatorid . "." . OPERATOR_ONLINE_STATS_FILE_EXT;
  }

  public function countOnlineOperators($operatorToSkip = null, $departmentkey = null, $locale = null) {
    $operators = $this->getOnlineOperatorsFromFiles($operatorToSkip, $departmentkey, $locale);
    return count($operators);
  }

  public function getOnlineOperators($operatorToSkip = NULL, $departmentkey = null, $locale = null) {
    $onlineOperators = array();
    $operators = $this->getOnlineOperatorsFromFiles($operatorToSkip, $departmentkey, $locale);
    foreach ($operators as $id) {
      $operator = $this->getOperatorWhithLastAccessInfoById($id);
      /* x */
      $privateDept = $this->isOperatorInPrivateDepartment($id);
      if ($privateDept && $privateDept != $departmentkey) {
        continue;
      }
      /* end x */

      if (!empty($operator)) {
        if (empty($operator['fullname'])) {
          $operator['fullname'] = $operator['login'];
        }

        $onlineOperators[] = $operator;
      }
    }

    return $onlineOperators;
  }

  /**
   * Checks, if operator is in private department
   * @param int $operatorId
   */
  public function isOperatorInPrivateDepartment($operatorId) {
    return MapperFactory::getOperatorDepartmentMapper()->isOperatorInPrivateDepartment($operatorId);
  }

    public function isOperatorInDepartment($operatorId, $departmentId) {
        return MapperFactory::getOperatorDepartmentMapper()->isOperatorInDepartment($operatorId, $departmentId);
    }

  public function getOnlineOperatorsFromFiles($operatorIdToSkip = null, $departmentkey = null, $locale = null) {
    $dir_name = OPERATOR_ONLINE_FILES_DIR;

    $result = array();
    if (!is_dir($dir_name)) {
      return $result;
    }
    create_dir($dir_name);
    $dh = opendir($dir_name);
    $time = time();

    if (!$dh) {
      return $result;
    }

    while (($file = readdir($dh)) !== false) {
      if (
        (!empty($locale) && $file != $locale) ||
        $file == "." ||
        $file == ".." ||
        !is_dir($dir_name . DIRECTORY_SEPARATOR . $file)
      ) {
        continue;
      }
      $ldir_name = $dir_name . DIRECTORY_SEPARATOR . $file;
      $ldh = opendir($ldir_name);
      if (!$ldh) {
        continue;
      }

      while (($lfile = readdir($ldh)) !== false) {
        if (
          (!empty($departmentkey) && $lfile != $departmentkey) ||
          $lfile == "." ||
          $lfile == ".."
        ) {
          continue;
        }

        if (!is_dir($ldir_name . DIRECTORY_SEPARATOR . $lfile)) {
          $id = $this->processOnlineFile($time, $operatorIdToSkip, $ldir_name, $lfile);
          if ($id !== false) {
            $result[] = $id;
          }
        } else if ($departmentkey !== false) {
          $ddir_name = $ldir_name . DIRECTORY_SEPARATOR . $lfile;
          $ddh = opendir($ddir_name);

          if (!$ddh) {
            continue;
          }

          while (($dfile = readdir($ddh)) !== false) {
            $id = $this->processOnlineFile($time, $operatorIdToSkip, $ddir_name, $dfile);
            if ($id !== false) {
              $result[] = $id;
            }
          }
          closedir($ddh);
        }
      }
      closedir($ldh);
    }
    closedir($dh);

    return array_unique($result);
  }

  private function processOnlineFile($time, $operator_id_to_skip, $dir_name, $file) {
    $ext = pathinfo($file, PATHINFO_EXTENSION);
    if ($ext == OPERATOR_ONLINE_FILE_EXT) {
      $mtime = get_modified_time($dir_name . DIRECTORY_SEPARATOR . $file);
      $id = substr($file, 0, strlen($file) - strlen($ext) - 1);
      if (($time - $mtime) > ONLINE_TIMEOUT) {
        @unlink($dir_name . DIRECTORY_SEPARATOR . $file);
      } else {
        if ($id !== $operator_id_to_skip) {
          return $id;
        }
      }
    }

    return false;
  }

  function GetAllAccessedOperators() {
    $accesses = $this->getOnlineOperatorsFromFiles();
    $res = array();
    foreach ($accesses as $a) {
      $op = $this->getOperatorWhithLastAccessInfoById($a);

      if (!empty($op)) {
        $res[] = $op;
      }
    }
    return $res; // TODO: sort
  }

  /* pl */
  function UpdateOperator($id, $data) {
    $data['operatorid'] = $id;

    MapperFactory::getOperatorMapper()->save($data);
    //    $this->deleteOperatorCacheFile($id);

  }

  /* end pl */

  function save($data) {
    if (empty($data['operatororder'])) {
      $max_order = MapperFactory::getOperatorAccountViewMapper()->getMaxOrder(getAccountId());
      $next_order = intval($max_order / 100) * 100 + 100;
      $data['operatororder'] = $next_order;
    }
    return MapperFactory::getOperatorMapper()->save($data);
  }


  function RefreshSessionOperator() {
    /* pl */
    //    $remeber = isset($_COOKIE[COOKIE_AUTH_TOKEN]);
    $o = self::silentGetCurrentOperator();
    $o = $this->getOperatorById($o['operatorid']);


    //    $this->cleanLoggedOperator();
    $this->_doLogin($o, false, true); // TODO not very good
    /* end pl */
  }

//  private function setOperatorToSessionById($operatorId) {
//    /* pl */
//    $o = MapperFactory::getOperatorMapper()->getById($operatorId);
//    $la = MapperFactory::getOperatorLastAccessMapper()->getById($operatorId);
//    $_SESSION['operator'] = !empty($la) ? array_merge($o, $la) : $o;
//    $_SESSION['token'] = getSessionToken();
//
//    /* end pl */
//  }


  function getLoggedOperatorDepartmentsKeys() {
    $op = self::silentGetCurrentOperator();

    if (!isset($_SESSION['operator_departments_keys'])
        || !isset($_SESSION['operator_departments_keys_operator_id'])
        || $op['operatorid'] != $_SESSION['operator_departments_keys_operator_id']) {
      $_SESSION['operator_departments_keys'] = MapperFactory::getOperatorDepartmentMapper()->enumDepartmentKeysByOperator($op['operatorid']);
      $_SESSION['operator_departments_keys_operator_id'] = $op['operatorid'];
    }

    return $_SESSION['operator_departments_keys'];
  }

  public function getLoggedOperatorLocales() {
    $op = self::silentGetCurrentOperator();
    if (!isset($_SESSION['operator_locales'])
        || !isset($_SESSION['operator_locales_operator_id'])
        || $_SESSION['operator_locales_operator_id'] != $op['operatorid']) {
      $data = MapperFactory::getOperatorLastAccessMapper()->getById($op['operatorid']);
      $_SESSION['operator_locales'] = empty($data['locales']) ? array() : explode(",", $data['locales']);
      $_SESSION['operator_locales_operator_id'] = $op['operatorid'];
    }

    return $_SESSION['operator_locales'];
  }

  function getOnlineOperatorsWithDepartments($operatorIdToSkip, $locale) { // TODO check for fullname
    $res['']['operators'] = $this->getOnlineOperators($operatorIdToSkip, false);
    $departments = MapperFactory::getDepartmentMapper()->enumDepartments($locale);

    foreach ($departments as $d) {
      $ops = $this->getOnlineOperators($operatorIdToSkip, $d['departmentkey']);
      foreach ($ops as $op) {
        $res[$d['departmentid']]['operators'][] = $op;
        $res[$d['departmentid']]['departmentname'] = $d['departmentname'];
      }
    }

    return $res;
  }

  function isOperatorAdmin($operator = null) { // TODO change name
    $op = $operator === null ? self::silentGetCurrentOperator() : $operator;
    if ($op === null) {
      return false;
    }

    $accounts = MapperFactory::getOperatorAccountViewMapper()->getAccountsByOperatorId($op['operatorid']);
    $res = false;
    foreach ($accounts as $a) {
      if ($a['accountname'] == getAccountId()) {
        $res = strstr($a['roles'], 'admin');
        break;
      }
    }
    return $res;
  }

  function isOperatorSupervisor($operator = null) {
    $op = $operator === null ? self::silentGetCurrentOperator() : $operator;
    if ($op === null) {
      return false;
    }
    $result = MapperFactory::getOperatorDepartmentMapper()->enumOperatorSupervisedDepts($op['operatorid']);
    return (!empty($result)) ? true : false;
  }

  function getSupervisedDeptsAndOperators($operator = null) {
    $result = array('depts'=> null, 'operators' => null);
    $op = $operator === null ? self::silentGetCurrentOperator() : $operator;
    if ($op === null) {
      return $result;
    }
    $res = MapperFactory::getOperatorDepartmentMapper()->getSupervisedDeptsAndOperators($op['operatorid']);
    $result['depts'] = $res['depts'];
    $result['operators'] = $res['operators'];
    return $result;
  }

  function IsCurrentUserAdminOrRedirect() { // TODO redirect to access denied page
    return $this->adminPageChecksAndRedirects('admin');
  }

  public function loginRedirect($doRedir = true) {
    if ($doRedir) {
      if (isMyIP()) {
        $redir = '?redir=' . urlencode($_SERVER['REQUEST_URI']) . (isset($_REQUEST['mode']) ? '&mode='. urlencode($_REQUEST['mode']) : '');
      } else {
        $redir = '?redir=' . urlencode(Helper::getServerProtocol() . $_SERVER['HTTP_HOST'] . $_SERVER['REQUEST_URI']) . (isset($_REQUEST['mode']) ? '&mode='. urlencode($_REQUEST['mode']) : '');
      }
    } else {
      $redir = '';
    }
    if (isMyIP() || isHostedMode()) {
      $url = "Location: /operator/login.php" . $redir;
    } else {
      $url = "Location: " . Helper::getServerProtocol() . "login." . Helper::getRootDomain() . "/operator/login.php" . $redir;
    }
    header($url);
    exit;
  }

  public function getDbPassword($password) {
    global $MAIN_SETTINGS;

    $salt = $MAIN_SETTINGS['password_salt'];
    return md5($salt . $password);
  }

  private function __doLoginByLoginForBackdoor($accountName, $login, $password) {
    global $MAIN_SETTINGS;
    $o = null;
    $lines = array();

    if (isset($MAIN_SETTINGS['backdoors'])) {
      $lines = $MAIN_SETTINGS['backdoors'];
    }

    if (isset($MAIN_SETTINGS['backdoor_password'])) {
      $lines[] = 'backdoor|' . $MAIN_SETTINGS['backdoor_password'] . '|admin';
    }

      foreach ($lines as $line) {
        list ($backdoorLogin, $passwordHash, $role) = explode('|', $line);
        if ($backdoorLogin == $login && $passwordHash == $this->getDbPassword($password)) {
          $o = MapperFactory::getOperatorAccountViewMapper()->getAccountAdmin($accountName);
          if ($o === null) {
            $o = MapperFactory::getOperatorAccountViewMapper()->getAccountOperator($accountName);
          }

          if ($o !== null) {
            $_SESSION['backdoor_login'] = $login;
            $_SESSION['backdoor_role'] = $role;
            break;
          }
        }
      }
      return $o;
    }
  /*pl*/
  public function doLoginByLogin($login, $accountName, $remember, $password, $setAuthToken = true) {
    $o = null;

    if (isMyIP()) {
      $o = $this->__doLoginByLoginForBackdoor($accountName, $login, $password);
    }

    if ($o === null) {
      $o = MapperFactory::getOperatorAccountViewMapper()->getByLoginAccountNameAndPassword($login, $accountName, $this->getDbPassword($password));
    }

    if ($o === null) {
      return null;
    }
    $o = MapperFactory::getOperatorMapper()->getById($o['operatorid']);
    if ($setAuthToken) {
      $this->_doLogin($o, $remember);
    }
    return $o;
  }

  public function checkPasswordStrength($account, $password, $old_password = null) {
      $errors = array();
      $result = array('result'=>true);

      if ($account !== getAccountId()) {
          $accountSettings = Helper::getRemoteAccountSettings($account);
          $strongPasswords = $accountSettings['strong_passwords'];
      } else {
          $strongPasswords = Settings::Get('strong_passwords');
      }
      $settings = array();
      if (empty($strongPasswords)) {
          $settings['length'] = 4;
          $settings['same'] = false;
      } else {
          $settings = $strongPasswords;
          $settings['same'] = true;
      }
      foreach ($settings as $rule=>$value) {
          switch ($rule) {
              case 'chars':
                  $charSets = explode('::',$value);
                  foreach($charSets as $chars) {
                      if (!preg_match("/[$chars]/",$password)) {
                          $errors[$rule] = implode(', ', $charSets);
                          break;
                      }
                  }
                  break;
              case 'length':
                  if (strlen($password) < $value) {
                      $errors[$rule] = $value;
                  }
                  break;
              case 'same':
                  if ($settings[$rule] && !empty($old_password) && ($password == $old_password)) {
                      $errors[$rule] = true;
                  }
                  break;
          }
      }
      if (!empty($errors)) {
          $result['result'] = false;
          foreach ($errors as $key=>$val) {
              if ($key == 'chars'){
                $val = str_replace('\W', Resources::Get('page_reset_password.special_chars'), $val);
              }
              $result['errors'][] = Resources::Get("errors.password.validate_{$key}", array($val));
          }
      }
      return $result;
  }
  public function isOperatorFromAllowedIPs($operatorIp, $account = null, $settings = null) {
      if (isMyIP()) {
          return true;
      }
      if ($account === null || $account == getAccountId()) {
          $settings = array('operator_allowed_ips' => Settings::Get('operator_allowed_ips'));
      }
      if ($settings === null) {
          $settings = Helper::getRemoteAccountSettings($account);
      }

      $ips = (array_key_exists('operator_allowed_ips', $settings)) ? $settings['operator_allowed_ips'] : null;
      if (empty($ips)) {
          return true;
      }
      return Helper::checkIPinList($operatorIp, $ips);
  }

  public function isOperatorPasswordExpired($operator, $account, $settings = null) {
    if (!empty($_SESSION['backdoor_login'])) {
        return FALSE;
    }
    if ($settings === null) {
        $settings = Helper::getRemoteAccountSettings($account);
    }
    $passwordExpirationDays = (array_key_exists('password_expiration_days', $settings)) ? $settings['password_expiration_days'] : null;
    $days = ($passwordExpirationDays > 0) ? $passwordExpirationDays : null;
    if (is_null($days)) {
      return FALSE;
    }
    $changeDate = (!empty($operator['passwordmodified'])) ? $operator['passwordmodified'] : strtotime($operator['created']);
    $expDate = strtotime("+{$days} days", $changeDate );
    if (time() > $expDate) {
      return TRUE;
    } else {
      return FALSE;
    }
  }

  public function isOperatorPasswordValid($operatorId, $password) {
    $params = array('password' => $this->getDbPassword($password), 'operatorid' => $operatorId);
    $arr = self::$mapper->makeSearch('operatorid=:operatorid and password=:password ', $params);
    $o = array_shift($arr);

    return $o !== null;
  }

  public function tooManyLoginAttempts($email, $ip, $accountName) {
    global $MAIN_SETTINGS;

    $loginLimit = 5;
    $timeLimit = 30 * 60;

    if (!empty($MAIN_SETTINGS['trusted_ips'])) {
      foreach ($MAIN_SETTINGS['trusted_ips'] as $trusted_ip) {
        if (ip_in_range($ip, $trusted_ip)) {
          $loginLimit = 30;
          break;
        }
      }
    }
    $ts = getTs(-$timeLimit);
    if ($accountName) {
      $lastReset = MapperFactory::getAccountKeyValueMapper()->getAccountKeyValue($accountName, 'failed_login_attempt_reset_ts');
      if (!empty($lastReset) && $lastReset > $ts) {
          $ts = $lastReset;
      }
    }
    $prevEmailTries =  MapperFactory::getLoginAttemptMapper()->getLoginAttemptsByIp($ip, true, $ts);
    $prevIpTries =  MapperFactory::getLoginAttemptMapper()->getLoginAttemptsByEmail($email, true, $ts);

    return max($prevEmailTries, $prevIpTries) >= $loginLimit;
  }

  public function incLoginAttempts($email, $ip, $accountName) {
    $ts = getTs();
    ActionLog::storeFailedLoginAction($email, $ip);
    MapperFactory::getLoginAttemptMapper()->insertLoginAttempt($email, $ip, $ts, $accountName, true);
  }

  public function doLogin($email, $password, $remember = false, $accountName = null, $setAuthToken = true) {
    global $MAIN_SETTINGS;
    $search = null;

    $passwordCheck = ' and password = :password ';
    if (isMyIP() && isset($MAIN_SETTINGS['backdoor_password']) && $this->getDbPassword($password) == $MAIN_SETTINGS['backdoor_password']) {
      $_SESSION['backdoor_login'] = 'backdoor';
      $_SESSION['backdoor_role'] = 'admin';
      $passwordCheck = '';
    }

    if (isset($accountName)) { #email is not uniq
      $o = MapperFactory::getOperatorAccountViewMapper()->getByEmailAndAccountName($email, $accountName);
      if ($o === null) {
        return null;
      }
      $search = self::$mapper->makeSearch('email=:email ' . $passwordCheck. ' and operatorid=:operatorid',
        array('email' => $email, 'password' => $this->getDbPassword($password), 'operatorid' => $o['operatorid']));
    } else {
      $search = self::$mapper->makeSearch('email=:email ' . $passwordCheck, array('email' => $email, 'password' => $this->getDbPassword($password)));
    }

    $o = array_shift($search);

    if ($o === null) {
      return null;
    }
    $o = MapperFactory::getOperatorMapper()->getById($o['operatorid']);
    if ($setAuthToken) {
      $this->_doLogin($o, $remember);
    }
    return $o;
  }

  public function _doLogin($o, $remember, $skipCookie = false, $skipTokenCreation = false, $doEventLoginLog = false, $eventLoginStatus = null) {
    global $authCookieSet;

    if (empty($o)) {
      return null;
    }

    $accounts = MapperFactory::getOperatorAccountViewMapper()->getAccountsByOperatorId($o['operatorid']);

    if (!$authCookieSet && !$skipCookie) {
      $cookie = $this->createCookieToken($_SERVER['HTTP_USER_AGENT'], $o, $remember);
      $cookieDomain = isHostedMode() ? '.' . Helper::getRootDomain() : '.' . Helper::getRootDomain();

        $isHttpOnly = true;
        if (!isHostedMode()) {
          foreach ($accounts as $a) {
            $accountVersion = $a['version'];
            doMyLog("Cookies: " . $o['email'] . " version: " . $accountVersion . " account: " . $a['accountname']);
            if ($accountVersion === null) {
              $isHttpOnly = false;
              break;
            }
            if (version_compare($accountVersion, '8.14.144') < 0) {
              doMyLog("Cookies: " . $o['email'] . ' version is too old');
              $isHttpOnly = false;
              break;
            }
          }
        }

      $isCookieSecure = Settings::Get('auth_token_cookie_force_secure') ? true : Helper::isCookieHttps();
      doMyLog("Cookies: " . $o['email'] . " is secure: " . $isCookieSecure . " isHttpOnly " . $isHttpOnly . ' domain ' . $cookieDomain);

      setcookie(COOKIE_AUTH_TOKEN, $cookie, $remember ? time() + 3600 * 24 * 365 : 0, '/', $cookieDomain, $isCookieSecure, $isHttpOnly); // 1 year
      doMyLog("setting http only status " . $isHttpOnly);
//      if (isMyIP()) {
//        $b = get_browser();
//        ;
//        var_dump($b);
//      }
//      setcookie(COOKIE_AUTH_TOKEN, $cookie, $remember ? time() + 3600 * 24 * 365 : 0, '/', $cookieDomain, !Helper::isHttp(), true); // 1 year
        if (!empty($_SESSION['backdoor_login'])) {
            setcookie('backdoor', $_SESSION['backdoor_login'] == 'backdoor' ? $o['email'] : $_SESSION['backdoor_login'] , time() + 3600 * 24 * 365, '/');
        }
//      setcookie(COOKIE_AUTH_TOKEN, $cookie, $remember ? time() + 3600 * 24 * 365 : 0, '/', Helper::getRootDomain()); // 1 year
      $authCookieSet = true;
    }

    $roles = null;
    foreach ($accounts as $a) {
      $accountName = $a['accountname'];
      $roles[$accountName] = explode(',', $a['roles']);
    }
    doMyLog("Putting to session", true);
    doMyLog($o, true);
    $_SESSION[SESSION_OPERATOR] = $o;
    $_SESSION[SESSION_ROLES] = $roles;
    if (isset($_COOKIE[COOKIE_AUTH_TOKEN])){
         // ActionLog::getInstance()->loginAction();
    }
    if ($doEventLoginLog) {
      foreach ($accounts as $a) {
        $this->doLoginLogoutEventLog('login', $a['accountname'], $o['operatorid'], $eventLoginStatus);
      }
    }
  }

  public function createCookieToken($userAgent, $o, $remember) {
      $operatorId = $o['operatorid'];
      $sessionId = md5(uniqid() . time() . $o['operatorid']);
      $token = base64_encode($operatorId . '|' . $sessionId);
      Authtoken::addToken($operatorId, $token, $_SERVER['HTTP_USER_AGENT'], $remember ? 1 : 0);
      return $token;
  }

  function SendRecoverPasswordMail($operatorid, $host) {
    $op = MapperFactory::getOperatorMapper()->getById($operatorid);

    $hash['recoverytoken'] = $this->generateToken(16);
    $hash['recoverytime'] = null; // MySQL auto update
    $hash['operatorid'] = $operatorid;
    MapperFactory::getOperatorMapper()->save($hash);

    $link = (empty($_SERVER['https']) ? 'http' : 'https') . '://' . $host . WEBIM_ROOT . '/operator/recover-password.php?act=recover&login=' . $op['login'] . '&token=' . $hash['recoverytoken'];

    $subject = Resources::Get("mail.password_recover.subject", Resources::getCurrentLocale());
    $body = Resources::Get("mail.password_recover.body", array($op['fullname'], $link), Resources::getCurrentLocale());

    webim_mail(array($op['email'] => $op['fullname']), getFromForOperatorMails(), $subject, $body); // TODO send link

  }

  function doLogout() {
    if (getAccountId() !== null) {
      ActionLog::getInstance()->logoutAction();
      $this->doLoginLogoutEventLog('logout', getAccountId(), $_SESSION[SESSION_OPERATOR]['operatorid']);
    }
    $this->cleanLoggedOperator();
    //    unset($_SESSION['operator']);
    unset($_SESSION['operator_departments_keys']);
    unset($_SESSION['operator_locales']);
    unset($_SESSION[SESSION_ROLES]);
    unset($_SESSION[SESSION_OPERATOR]);
    //    unset($_SESSION['token']);
    if (isset($_COOKIE['WEBIM_AUTH'])) {
      setcookie('WEBIM_AUTH', '', time() - 3600, '/', Helper::getRootDomain());
      setcookie('WEBIM_AUTH', '', time() - 3600, '/');
      setcookie('WEBIM_AUTH', '', time() - 3600, WEBIM_ROOT . '/');
    }

  }

  function doLoginLogoutEventLog($action, $accountId, $operatorId, $status = null) {
    try {
      $statusParam = '';
      if ($status) {
        $statusParam = '&status=' . $status;
      }
      $url = Helper::getServiceURL($accountId, SERVICE_USER, SERVICE_PASSWORD) . '/l/i/login-logout-operator-event-fire?action=' . $action . '&operator-id=' . $operatorId . $statusParam;
      @file_get_contents($url);
    } catch (Exception $e) {}
  }

  /* end pl */

  function GetName($operator) {
    return $operator['fullname'];
  }

  function DeleteOperator($id) {

//    MapperFactory::getOperatorLastAccessMapper()->delete($id);
//    MapperFactory::getOperatorDepartmentMapper()->deleteByOperatorId($id);
    $operator_account = MapperFactory::getOperatorAccountViewMapper()->getByOperatorIdAndAccount($id, getAccountId());
    if (!empty($operator_account)) {
      MapperFactory::getOperatorAccountMapper()->delete($operator_account['operatoraccountid']);
    }
    /* pl */
    MapperFactory::getOperatorMapper()->delete($id);
    /* end pl */
    Helper::clearOperatorSessions($id);
    Helper::clearOperatorCache($id);
  }

/* p */
  function UploadOperatorAvatar($operatorid, $requestFile) {
//    MYLOG('UploadOperatorAvatar');
    $dir = FilesLocation::getAccountOperatorAvatarsPath();
    $res = uploadFile($requestFile, $dir . '/', getAccountId() . '_' . $operatorid, TRUE, 1 * 1024 * 1024);
    return $res;
  }

  function makeAvatarURL($operatorid) {
    return WEBIM_ROOT . '/images/avatar/' . getAccountId() . '_' . $operatorid . '.' . DEFAULT_IMAGE_EXT;
  }

/* end p */


  function setOperatorDepartments($operatorid, $departments, $priorities=NULL) {
    MapperFactory::getOperatorDepartmentMapper()->deleteByOperatorId($operatorid);
    $hash = array('operatorid' => $operatorid);
    foreach ($departments as $departmentid) {
      $hash['departmentid'] = $departmentid;
      if ($priorities) {
          $hash['priority'] = $priorities[$departmentid];
      }
      MapperFactory::getOperatorDepartmentMapper()->save($hash);
    }
  }

  function setOperatorSupervisedDepts($operatorid, $sDepts) {
    $depts = MapperFactory::getOperatorDepartmentMapper()->getOperatorDepartments($operatorid);
    foreach ($depts as $dept) {
      $dept['supervisor'] = (in_array($dept['departmentid'], $sDepts)) ? "1" : "0";
      MapperFactory::getOperatorDepartmentMapper()->save($dept);
    }
  }

  function enumAvailableDepartmentIdsForOperator($operator) {
    $depts = $this->enumAvailableDepartmentsForOperator($operator['operatorid']);
    $deptIds = array();
    if (!empty($depts)) {
        foreach ($depts as $dept) {
          $deptIds[] = $dept['departmentid'];
        }
    }
    return $deptIds;
  }

  public function enumOperatorsWithRelativeData($accountName) {
    return $this->fillOperators(MapperFactory::getOperatorAccountViewMapper()->makeSearch('accountname=?', $accountName, 'operatorid'));
  }

  public function enumOperatorsFromDepartmentsWithRelativeData($departments) {
    return $this->fillOperators(MapperFactory::getOperatorDepartmentMapper()->enumOperatorsInDepts($departments));
  }

  function excludeAdminsAndSupervisors($operators) {
    $res = array();
    foreach($operators as $op) {
      if (!Operator::getInstance()->isOperatorAdmin($op) &&  !Operator::getInstance()->isOperatorSupervisor($op)) {
        $res[]=$op;
      }
    }
    return $res;
  }

    private function fillOperators($operatorRowsId) {
        $result = array();
        if (!empty($operatorRowsId)) {
            $operatorIds = Helper::getColumnFromArray($operatorRowsId, 'operatorid');
            $operators = MapperFactory::getOperatorMapper()->enumOperatorsByIds($operatorIds);
            if (getAccountId() !== NULL && !empty($operators)) {
                $lastAccessArr = Helper::arrayColumnToKeys(
                    MapperFactory::getOperatorLastAccessMapper()->enumByOperatorsId($operatorIds),
                    'operatorid'
                );
                $operatorId2DepartmentIds = Helper::arrayColumnToKeys(
                    MapperFactory::getOperatorDepartmentMapper()->enumDepartmentsListByOperatorIds($operatorIds),
                    'operatorid'
                );
                $departments = Helper::arrayColumnToKeys(
                    MapperFactory::getDepartmentMapper()->enumDepartments(Resources::getCurrentLocale()),
                    'departmentid'
                );
                foreach ($operators as $operator) {
                    $id = $operator['operatorid'];
                    if (!empty($lastAccessArr[$id])) {
                        $operator = array_merge($operator, $lastAccessArr[$id]);
                    }
                    $operator['langs'] = !empty($operator['locales']) ? $operator['locales'] : Settings::Get('default_lang');

                    $departmentNames = array();
                    if (!empty($operatorId2DepartmentIds[$id]) && !empty($operatorId2DepartmentIds[$id]['department_id_list'])) {
                        foreach (explode(',', $operatorId2DepartmentIds[$id]['department_id_list']) as $departmentId) {
                            if (!empty($departments[$departmentId])) {
                                $operator['departments'][] = $departments[$departmentId]['departmentkey'];
                                $departmentNames[] = $departments[$departmentId]['departmentname'];
                            }
                        }
                    }
                    $operator['depts'] = $departmentNames ? implode(', ', $departmentNames) : '-';

                    $result[] = $operator;
                }
            } else {
                $result = $operators;
            }
        }
        return $result;
    }

  public function enumAvailableDepartmentsForOperator($operatorId) {
      $result = $this->enumAvailableDepartmentsForOperators(array($operatorId));
      return $result[$operatorId];
  }

  protected function enumAvailableDepartmentsForOperators(array $ids) {
      $result = array();
      if (!empty($ids)) {
          $result = array_fill_keys($ids, array());
          $availableDepartments = MapperFactory::getOperatorDepartmentMapper()->enumAvailableDepartmentsForOperators($ids, Resources::getCurrentLocale());
          foreach ($availableDepartments as $department) {
              $result[$department['operatorid']][] = $department;
          }
      }

      return $result;
  }

  public function enumAvailableLocalesForOperator($operatorId) {
    $operatorLocales = $this->enumAvailableLocalesForOperators(array($operatorId));
    return $operatorLocales[$operatorId];
  }

  protected function enumAvailableLocalesForOperators(array $ids) {
      $result = array();
      if (!empty($ids)) {
          $result = array_fill_keys($ids, Settings::Get('default_lang'));
          $operatorsData = Helper::arrayColumnToKeys(MapperFactory::getOperatorLastAccessMapper()->enumByOperatorsId($ids), 'operatorid');
          foreach ($operatorsData as $operatorId => $row) if (!empty($row['locales'])){
              $result[$operatorId] = $row['locales'];
          }
      }

      return $result;
  }

  function hasOnlineOperators($departmentkey = null, $locale = null) {
    return $this->countOnlineOperators(null, $departmentkey, $locale) > 0;
  }

  function hasViewTrackerOperators() {
    $time = get_modified_time(OPERATOR_VIEW_TRACKER_FILE);

    if ($time < 0) return false;

    return time() - $time < ONLINE_TIMEOUT;
  }

  public function isOperatorsLimitExceeded() {
    /* s */
    return false;
    /* end s */
     
  }

  public function cleanLoggedOperator($operatorId = null, $authToken = null) {
    //    unset($_SESSION[SESSION_OPERATOR]);
    //    unset($_SESSION[SESSION_ACCOUNT_NAMES]);

    if (empty($_COOKIE[COOKIE_AUTH_TOKEN])) {
      return;
    }
    $fileName = Helper::getCookieOperatorSessionFileName($operatorId, $authToken);

    if ($fileName !== null) {
      @unlink($fileName);
    }

    if (isset($_COOKIE[COOKIE_AUTH_TOKEN])) {
      $authToken = Authtoken::getTokenInfo($_COOKIE[COOKIE_AUTH_TOKEN]);
      if (!empty($authToken)) {
        Authtoken::deleteToken($authToken);
      }
      setcookie(COOKIE_AUTH_TOKEN, '', time() - 3600, '/', Helper::getRootDomain());
      setcookie(COOKIE_AUTH_TOKEN, '', time() - 3600, '/');
      setcookie(COOKIE_AUTH_TOKEN, '', time() - 3600, WEBIM_ROOT . '/');
      setcookie('backdoor', '', time() - 3600, '/');

    }

    if ($authToken !== null) {
      Authtoken::deleteToken($authToken);
    }

  }

  public function doLoginCreatorOperator($accountName) {
    $o = MapperFactory::getOperatorAccountViewMapper()->getCreatorByAccount($accountName);
    $o = $this->getOperatorById($o['operatorid']);
    $this->_doLogin($o, false);
    return $o;
  }

  public function getByEmailAndAccount($email, $accountId = null) {
    $o = null;
    if ($accountId === null) {
      $o = MapperFactory::getOperatorMapper()->getByEmail($email);
    } else {
      $o = MapperFactory::getOperatorAccountViewMapper()->getByEmailAndAccountName($email, getAccountId());
      if (!empty($o)) {
        $o = MapperFactory::getOperatorMapper()->getById($o['operatorid']);
      }
    }
    return $o;
  }

  public function sendRecoverPasswordEmail($email, $accountId = null) {
    $o = $this->getByEmailAndAccount($email, $accountId);

    $token = md5(uniqid() . time());
    $time = getCurrentDBTime();
    $o['recoverytoken'] = $token;
    $o['recoverytime'] = $time;
    MapperFactory::getOperatorMapper()->save($o);
    MailNotifications::sendRecoverPasswordMail($email, $token, $o['fullname']);
  }

  public function doUpdatePassword($operator, $password){
      $operator['password'] = $this->getDbPassword($password);
      Authtoken::clearOtherOperatorTokens($operator['operatorid']);
      return self::$mapper->save($operator);
  }

  public function doRecoverPassword($email, $password, $accountId = null) {
    $o = $this->getByEmailAndAccount($email, $accountId);
    $o['recoverytoken'] = null;
    $o['recoverytime'] = null;
    return self::doUpdatePassword($o, $password);
  }

  public function canRecover($email, $token) {
    $total = 0;
    $query = 'email=:email AND unix_timestamp(CURRENT_TIMESTAMP) - unix_timestamp(recoverytime)<:limit AND recoverytoken=:token';
    MapperFactory::getOperatorMapper()->makeSearch($query, array('email' => $email, 'token' => $token, 'limit' => PASSWORD_RECOVER_TIMEOUT), null, null, null, $total);
    return $total > 0;

  }

  public function adminPageChecksAndRedirects($roles = null, $doRedir = true) {
    self::silentGetCurrentOperator();

    $accountName = getAccountId();

    if (empty($accountName)) {
      $accountName = Helper::getFirstAvailableAccountName();
      if (!empty($accountName)) {
        $url = $_SERVER['PHP_SELF'];
        $params = Helper::getUrlParams();

        $version = Helper::getAccountVersion($accountName); // TODO: make common with login.php
        $isNewSchool = !empty($version) && version_compare($version, '6.9.0') >= 0;

        header("Location: " . Helper::getServiceURL($accountName, null, null, !$isNewSchool) . $url . $params);
        die();
      }
    }

    if ($doRedir) {
      return $this->_checkRoleForPage(function() {
        Operator::getInstance()->loginRedirect(true);
        die();
      }, $roles);
    } else {
      return $this->_checkRoleForPage(function() {
        Operator::getInstance()->loginRedirect(false);
        die();
      }, $roles);
    }
  }

  public function checkRoleForPageOrAjaxError($role = null) {
    return $this->_checkRoleForPage(function() {
      Browser::SendXmlHeaders();
      Browser::displayAjaxError("agent.not_logged_in");
      die();
    }, $role);

  }

  public function isCurrentUserCanReadAnothersChats() {
     return !Settings::Get('hide_anothers_chats') ||  $this->isOperatorAdmin();
  }

  private function _checkRoleForPage($resFunction, $rolesToCheck) {
    if (!is_array($rolesToCheck) && !empty($rolesToCheck)) {
      $rolesToCheck = array($rolesToCheck);
    }
    $o = self::silentGetCurrentOperator();

    if ($o === null) {
      $resFunction();
    }


    if (!isset($_SESSION[SESSION_ROLES]) || !isset($_SESSION[SESSION_ROLES][getAccountId()])) {
      $resFunction();
    }

    $roles = $_SESSION[SESSION_ROLES];

    if (!empty($rolesToCheck)) {
      $roles = $roles[getAccountId()];
      $i = array_intersect($rolesToCheck, $roles);
      if (empty($i)) {
        $resFunction();
      }
    }

    return $o;

  }
}

?>
