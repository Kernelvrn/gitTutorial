<?php
require_once(dirname(__FILE__) . '/functions.php');
require_once(dirname(__FILE__) . '/../autoload.php');
require_once(dirname(__FILE__) . '/../../vendor/autoload.php');


use UAParser\Parser;

//define('SMARTY3_DIR', '/usr/share/php/smarty3');
//require_once(SMARTY3_DIR . '/Smarty.class.php');

class SmartyWrapper extends \Smarty {
    public function __construct() {
        parent::__construct();

        $this->setTemplateDir(WEBIM_SMARTY_TEMPLATE_DIR);
        $this->setCompileDir(WEBIM_SMARTY_COMPILE_DIR);
        $this->addPluginsDir(WEBIM_SMARTY_PLUGINS_DIR);

        $this->assignCommonParams();
        if (!defined('VISITOR_SIDE') || !VISITOR_SIDE) {
            $this->assignBackendParams();
        }
        if ($currentAccountName = getAccountId()) {
            $this->assignAccountParams($currentAccountName);
            if ($currentOperator = Operator::getInstance()->silentGetCurrentOperator()) {
                $this->assignOperatorParams($currentOperator['operatorid']);
            }
        }
    }

    protected function assignCommonParams() {
        global $MAIN_SETTINGS;
        $this->assign('availableLocales', Resources::GetAvailableLocales());
        $this->assign('backendLocales', Resources::getBackendAvailableLocales());
        $this->assign('bodyClass', '');
        $this->assign('brandPartner', getBrandPartner(), false);
        $this->assign('charset', BROWSER_CHARSET);
        $this->assign('currentLocale', Resources::getCurrentLocale());
        $this->assign('dateFormat', Helper::getDateFormat());
        $this->assign('dateTimeFormat', Helper::getDateTimeFormat());
        if (!empty($_SERVER['HTTP_HOST'])) {
            $this->assign('domain', $_SERVER['HTTP_HOST']);
        }
        $this->assign('webimEncoding', strtolower(WEBIM_ENCODING), false);
        $this->assign('productAndVersion', Settings::GetProductAndVersion());
        $this->assign('protocol', Helper::getServerProtocol());
        $this->assign('rootDomain', Helper::getRootDomain());
        $this->assign('version', WEBIM_VERSION);
        $this->assign('hosted_mode', isHostedMode());


        $serverInfo = '';
        if (isMyIP()) {
            $serverInfo = ' ' . trim(file_get_contents('/etc/hostname')) . ':' . getPythonPort() . '/' . getPHPEnvLetter() . ' - ' . @file_get_contents(dirname(__FILE__) . '/../service/branch.txt');
        }
        $this->assign('versionDate', WEBIM_VERSION_DATE . $serverInfo);
        $this->assign('webimRoot', '');
        $this->assign('webimSipDomain', WEBIM_SIP_DOMAIN);
        $this->assign('webimSipProxy', WEBIM_SIP_PROXY);
        $this->assign('hostedMode', isHostedMode() ? 1 : 0);
    }

    protected function assignBackendParams() {
        if (!empty($_SERVER['HTTP_USER_AGENT'])) {
            $parser = Parser::create();
            $result = $parser->parse($_SERVER['HTTP_USER_AGENT']);
            $platform = array('browser' => $result->ua->family, 'majorver' => $result->ua->major); # compatibility
            $this->assign('browserEnv', $platform);
        }
        $this->assign('isChrome', !empty($_SERVER['HTTP_USER_AGENT']) && stristr($_SERVER['HTTP_USER_AGENT'], 'Chrome') ? TRUE : FALSE);        $this->assign('isIos', !empty($_SERVER['HTTP_USER_AGENT']) && (stristr($_SERVER['HTTP_USER_AGENT'], 'iphone') || stristr($_SERVER['HTTP_USER_AGENT'], 'ipad')) ? TRUE : FALSE);
        $this->assign('isTray', Browser::isTray());
        $this->assign('isWindows', !empty($_SERVER['HTTP_USER_AGENT']) && (stristr($_SERVER['HTTP_USER_AGENT'], 'Windows')) ? TRUE : FALSE);
        $this->assign('isUbuntu', !empty($_SERVER['HTTP_USER_AGENT']) && (stristr($_SERVER['HTTP_USER_AGENT'], 'Ubuntu')) ? TRUE : FALSE);
    }

    protected function assignAccountParams($accountName) {
        global $MAIN_SETTINGS;
        if ($accountName == getAccountId()) {
          $currentAccount = Account::getInstance()->getCurrentAccount();
        } else {
          $currentAccount = Account::getInstance()->getAccountByName($accountName);
        }
        $this->assign('currentAccount', $currentAccount);
        $this->assign('tariff', Tariff::getInstance());
        $this->assign('settings', Settings::getInstance());
        $this->assign('serviceUrl', Helper::getServiceURL($accountName, NULL, NULL, FALSE));
        $this->assign('serviceDomain', Helper::getServiceDomain(), FALSE);
        $this->assign('offices', Settings::Get('offices'));
        $this->assign('useYandexSpellcheck', Settings::Get('use_yandex_spellcheck') ? 1 : 0);
        $this->assign('haveCustomVisitorsJS', file_exists(__DIR__ . '/../account-specific/' . $currentAccount['accountname'] . '/js/visitors.js'));

        $statuses = Account::getInstance()->getAvailableOperatorStatuses();
        $this->assign('available_operator_statuses', $statuses);

        $shownSettingKeys = array(
            'auto_assign',
            'multilang',
            'chat_intercept',
            'spell_check_force',
            'default_lang',
            'visitor_dep_answers',
            'visitors_subsections',
            'section_table_view',
            'operator_chat',
            'crm_url_template',
            'stop_typing_timeout',
            'operator_iframe_allowed_parent_origin',
            'enable_capitalization_correction',
            'default_operator_department_priority',
            'dashboard_realtime_update_interval',
            'dashboard_prev_periods_update_interval',
            'spelling_pass_button_autofocus_and_pass_all',
            'operator_websockets',
            'message_editing',
            'previous_chats_label_time_interval',
            'tcs_custom_operator_interface_events',
            'chatting_timer',
            'operator_status_timer');
        $accountSettingsFilteredForBackend = array();
        foreach ($shownSettingKeys as $settingKey) {
            $accountSettingsFilteredForBackend[$settingKey] = Settings::Get($settingKey);
        }
        $this->assign('accountSettingsFilteredForBackend', $accountSettingsFilteredForBackend);

        $publicMainSettingKeys = array('bitrix24_app_client_id', 'bitrix24_app_redirect_uri');
        $publicMainSettings = array();
        foreach ($publicMainSettingKeys as $settingKey) {
            $publicMainSettings[$settingKey] = array_key_exists($settingKey, $MAIN_SETTINGS)
                ? $MAIN_SETTINGS[$settingKey]
                : NULL;
        }
        $this->assign('publicMainSettings', $publicMainSettings);

        $this->assign('poweredByLink', $this->getPoweredByLink());

    }

   protected function getPoweredByLink() {
        $rootDomain = Helper::getRootDomain();

        if ($rootDomain == 'callrf.ru') {
            return 'http://www.beeper.ua'; # TODO: very hard code
        }

        return 'http://' . $rootDomain . '/?pp=' . urlencode(getAccountId()) . '&utm_source=webim-client-embedded-chat&utm_medium=webim&utm_campaign=' . urlencode(getAccountId());
    }



    protected function assignOperatorParams($operatorId) {
        $currentOperator = Operator::getInstance()->getOperatorById($operatorId);
        if (!empty($currentOperator)) {
            $currentOperator['is_admin'] = Operator::getInstance()->isOperatorAdmin();
            if (getAccountId() !== null) {
              $currentOperator['is_supervisor'] = Operator::getInstance()->isOperatorSupervisor();
            }
            $this->assign('currentOperator', $currentOperator);
            $this->assign('sipEnabled', !empty($currentOperator['sip']) && Settings::Get('calls'));
            $this->assign('csrfToken', Csrf::getHash());
            $operatorAccounts = MapperFactory::getOperatorAccountViewMapper()->getAccountsByOperatorId($operatorId);
            foreach ($operatorAccounts as &$account) {
                $account['service_url'] = Helper::getServiceURL($account['accountname'], NULL, NULL, FALSE, !empty($account['partner']) ? $account['partner'] : '');
            }
            $this->assign('currentOperatorAccounts', $operatorAccounts);
            $this->assign('topMenu', $this->prepareBackendMenu());
        }
    }

    protected function prepareBackendMenu() {
        $menu = array();
        $operatorRoles = Helper::getCurrentRoles();

        $partner = getBrandPartner();

        $restrictedDep = false; //TODO remove teztour hardcode after BUGZTASKS-1987
        $restricted = array(
            'depId' => 4,
            'options' => array('operators' => array('supervisor', 'admin'), 'blocked' => array('admin'), 'dashboard' => array('admin'))
        );
        $operator = Operator::getInstance()->silentGetCurrentOperator();
        if (getAccountId() == 'teztourcom') {
            if (Operator::getInstance()->isOperatorInDepartment($operator['operatorid'], $restricted['depId'])) {
                $restrictedDep = true;
            }

        }
        foreach (AdminURL::$ADMIN_MENU as $menuItem) {
            if (isset($menuItem['enable_setting']) && !Settings::Get($menuItem['enable_setting'])) {
                continue;
            }

            if (!isset($menuItem['section'])) {
                continue;
            }
            $section = $menuItem['section'];

            if (isset($menuItem['tariff_option'])) {
                $hasOption = FALSE;
                $tariffOptions = is_array($menuItem['tariff_option']) ? $menuItem['tariff_option'] : array($menuItem['tariff_option']);
                foreach ($tariffOptions as $tariffOption) {
                    if (Tariff::getInstance()->hasTariffOption($tariffOption) && !Helper::checkIfOptionRestricted($tariffOption)) {
                        $hasOption = TRUE;
                        break;
                    }
                }
                if (!$hasOption) {
                    continue;
                }

                if ($restrictedDep) {
                    if (array_key_exists($menuItem['link_name'], $restricted['options']) && !array_intersect($operatorRoles, $restricted['options'][$menuItem['link_name']])) {
                        continue;
                    }
                }
            }

            $menuRoles = is_array($menuItem['roles']) ? $menuItem['roles'] : array($menuItem['roles']);
            if (!array_intersect($menuRoles, $operatorRoles)) {
                continue;
            }

            $menuItem['link'] = AdminURL::getInstance()->getURL($menuItem['link_name']);
            if (!isset($menu[$section])) {
                $menu[$section] = array();
            }
            $menu[$section][] = $menuItem;
        }
        return $menu;
    }
}

?>