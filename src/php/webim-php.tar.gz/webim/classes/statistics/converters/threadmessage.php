<?php

class Statistic_Converter_ThreadMessage extends Statistic_Converter_Base {
    /**
     * @var MessageMapper;
     */
    protected $chatMessageMapper;

    /**
     * @var Mapper_ThreadMessage;
     */
    protected $threadMessageMapper;

    /**
     * @var ThreadHistoryMapper
     */
    protected $threadHistoryMapper;

    public function __construct() {
        $this->chatMessageMapper = MapperFactory::getMessageMapper();
        $this->threadMessageMapper = Factory_Mapper::create('threadMessage');

        $this->threadHistoryMapper = MapperFactory::getThreadHistoryMapper();
    }

    public function sync(DateTime $endDate) {
        $endDate = clone min($endDate, self::getMaxEndDate());
        $endDate->setTime(23, 59, 59);
        $startDate = self::getMinStartDate();
        $startDate->setTime(0, 0);

        $lastSyncedId = $this->threadMessageMapper->getLastSyncedId();
        $rowsQueryChatMessage = $this->chatMessageMapper->getByRangeQuery($startDate, $endDate, $lastSyncedId);

        while ($rows = $rowsQueryChatMessage->fetchNext()) {
            $threadIds = Helper::getColumnFromArray($rows, 'threadid');

            $events = Helper::groupArrayByColumn($this->threadHistoryMapper->getThreadHistoryByThreadIds($threadIds), 'threadid');
            $convertedRows = array();

            foreach ($rows as $row) {
                $date = Helper::makeDateTime($row['created']);
                $event = self::findClosestEvent($events[$row['threadid']], $row['created']);

                $convertedRows[] = array(
                    'date' => $date->format('Y-m-d'),
                    'messageId'=>(int)$row['messageid'],
                    'threadId' => (int)$row['threadid'],
                    'kind' => (int)$row['kind'],
                    'created' => $row['created'],
                    'operatorId' => (int)$row['operatorid'],
                    'messageLength' => strlen($row['message']),
                    'departmentId' => $event ? (int)$event['departmentid'] : 0,
                    'locale' => $event ? ($event['locale'] ?: '') : '',
                    'officeId' => $event ? (int)$event['officeid'] : 0
                );
            }
            $this->threadMessageMapper->saveRows($convertedRows);
        }

    }

    protected function findClosestEvent(array $events, $date) {
        $ts = strtotime($date);
        $prevEvent = NULL;
        foreach ($events as $event) {
            if (strtotime($event['dtm']) > $ts) {
                break;
            }

            $prevEvent = $event;
        }

        return $prevEvent;
    }
}