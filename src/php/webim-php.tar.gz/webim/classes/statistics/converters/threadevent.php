<?php

class Statistic_Converter_ThreadEvent extends Statistic_Converter_Base {
    /**
     * @var ThreadHistoryMapper
     */
    protected $threadHistoryMapper;
    /**
     * @var Mapper_ThreadEvent
     */
    protected $threadEventMapper;

    public function __construct() {
        $this->threadEventMapper = Factory_Mapper::create('threadEvent');
        $this->threadHistoryMapper = MapperFactory::getThreadHistoryMapper();
    }

    public function sync(DateTime $endDate) {
        $endDate = clone min($endDate, self::getMaxEndDate());
        $endDate->setTime(23,59,59);
        $startDate = self::getMinStartDate();
        $startDate->setTime(0,0);

        $lastSyncedId = $this->threadEventMapper->getLastSyncedId();

        $rowsQuery = $this->threadHistoryMapper->getByRangeQuery($startDate, $endDate, $lastSyncedId);

        while ($rows = $rowsQuery->fetchNext()) {
            $convertedRows = array();
            foreach ($rows as $row) {
                $date = Helper::makeDateTime($row['dtm']);
                $convertedRows[] = array(
                    'date' => $date->format('Y-m-d'),
                    'eventThreadId' => (int)$row['threadid'],
                    'eventNumber' => (int)$row['number'],
                    'eventDtm' => $row['dtm'],
                    'event' => $row['event'] ?: '',
                    'threadState' => $row['state'] ?: '',
                    'operatorId' => (int)$row['operatorid'],
                    'departmentId' => (int)$row['departmentid'],
                    'officeId' => (int)$row['officeid'],
                    'locale' => $row['locale'] ?: '',
                    'threadHistoryId' => (int)$row['threadhistoryid']
                );
            }

            $this->threadEventMapper->saveRows($convertedRows);
        }
    }
}