<?php

/**
 * Class Statistic_Maker_Base
 * Классы данной иерархии на основе сырых данных из транзакционной БД
 * создают соответствующие вектора статистики. В последствии эти вектора можно вывести
 * или сохранить в аналитической БД и извлекать уже через репозиторий.
 */
abstract class Statistic_Converter_Base {
    /**
     * Конвертирует данные из одной (или нескольких) таблиц транзакционной базы данных
     * в целевую таблицу аналитической СУБД
     * @param DateTime $endDate
     */
    abstract public function sync(DateTime $endDate);

    private static $minStartDate;
    final protected static function getMinStartDate() {
        return clone (self::$minStartDate ?: self::$minStartDate = new DateTime('first day of previous month'));
    }

    private static $maxEndDate;
    final protected static function getMaxEndDate() {
        return clone (self::$maxEndDate ?: self::$maxEndDate = new DateTime('yesterday'));
    }
}