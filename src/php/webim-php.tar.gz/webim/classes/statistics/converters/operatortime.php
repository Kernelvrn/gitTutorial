<?php

class Statistic_Converter_OperatorTime extends Statistic_Converter_Base {
    /**
     * @var OnlinePeriodMapper
     */
    protected $onlinePeriodMapper;
    /**
     * @var Mapper_OperatorTime
     */
    protected $operatorTimeMapper;

    public function __construct() {
        $this->onlinePeriodMapper = MapperFactory::getOnlinePeriodMapper();
        $this->operatorTimeMapper = Factory_Mapper::create('operatorTime');
    }

    public function sync(DateTime $endDate) {
        $step = new DateInterval('P1D');
        $startDate = self::getMinStartDate();
        $endDate = clone $endDate;
        $endDate->setTime(0,0,0);

        $lastSyncedRow = $this->getLastSyncedRow();
        if ($lastSyncedRow) {
            $lastSyncedDate = Helper::makeDateTime($lastSyncedRow['lastDate']);
            $lastSyncedId = $lastSyncedRow['onlinePeriodId'];

            if (!empty($lastSyncedDate)) {
                if ($lastSyncedDate > $startDate) {
                    $this->syncDate($lastSyncedDate, $lastSyncedId);
                    $startDate = $lastSyncedDate->add($step);
                }
            }
        }

        $endDate = min($endDate, self::getMaxEndDate());

        $currentDate = clone $startDate;

        while ($currentDate <= $endDate) {
            $this->syncDate($currentDate);
            $currentDate->add($step);
        }
    }

    protected function syncDate(DateTime $date, $startFromId = NULL) {
        $start = clone $date;
        $start->setTime(0,0);
        $end = clone $date;
        $end->setTime(23,59,59);
        $rowsQuery = $this->onlinePeriodMapper->getCutsByRangeQuery($start, $end, $startFromId);
        while ($rows = $rowsQuery->fetchNext()) {
            $convertedRows = array();
            foreach ($rows as $row) {
                $convertedRows[] = array(
                    'date' => $date->format('Y-m-d'),
                    'dtmFrom' => $row['dtmfrom'],
                    'dtmTo' => $row['dtmto'],
                    'status' => $row['status'] ?: '',
                    'operatorId' => (int)$row['operatorid'],
                    'departmentId' => (int)$row['departmentid'] ?: 0,
                    'locale' => $row['locale'] ?: '',
                    'onlinePeriodId' => (int)$row['id']
                );
            }
            $this->operatorTimeMapper->saveRows($convertedRows);
        }
    }

    protected function getLastSyncedRow() {
        return $this->operatorTimeMapper->getLastDateWithMaxOnlinePeriodId();
    }
}