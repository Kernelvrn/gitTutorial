<?php
/**
 * Class Statistic_Metric_OnlineTime
 * Время, которое оператор(ы) был в том или ином стутсе.
 * Возвращается с разбивкой на периоды: ($dtmFrom, $dtmTo, $onlinePeriod)
 */
abstract class Statistic_Metric_StatusTime extends Statistic_Metric_Base {
    /**
     * @var Mapper_OperatorTime
     */
    protected $operatorTimeMapper;

    public function __construct() {
        $this->operatorTimeMapper = Factory_Mapper::create('operatorTime');
    }

    /**
     * @param Statistic_Filters $filters
     * @return array
     */
    public function calc(Statistic_Filters $filters) {
        $rows = $this->operatorTimeMapper->getStatsRowsForStatus($filters, $this->getStatusTitle());
        $metric = array();
        foreach ($rows as $row) {
            $metric[$row['periodStart']] = $row['value'];
        }

        return $metric;
    }

    public function calcSumStatusTime(Statistic_Filters $filters) {
        $rows = $this->operatorTimeMapper->getStatsRowsForStatusBySumStatusTime($filters, $this->getStatusTitle());
        $metric = array();
        foreach ($rows as $row) {
            $metric[$row['operatorId']] = $row['statusTime'];
        }

        return $metric;
    }

    abstract protected function getStatusTitle();
}