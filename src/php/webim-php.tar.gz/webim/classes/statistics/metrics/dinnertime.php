<?php

class Statistic_Metric_DinnerTime extends Statistic_Metric_StatusTime  {
    protected function getStatusTitle() {
        return 'dinner';
    }
}