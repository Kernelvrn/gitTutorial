<?php

class Statistic_Metric_PrivateTime extends Statistic_Metric_StatusTime  {
    protected function getStatusTitle() {
        return 'private_break';
    }
}