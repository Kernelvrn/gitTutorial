<?php
/**
 * Class Statistic_Metric_MessageLength
 * Средняя длинна сообщений
 * Возвращается с разбивкой на периоды: ($dtmFrom, $dtmTo, $onlinePeriod)
 */
class Statistic_Metric_MessageLength extends Statistic_Metric_Base {
    /**
     * @var Mapper_ThreadMessage
     */
    protected $threadMessageMapper;


    public function __construct() {
        $this->threadMessageMapper = Factory_Mapper::create('threadMessage');
    }

    /**
     * @param Statistic_Filters $filters
     * @return array
     */
    public function calc(Statistic_Filters $filters) {
        $rows = $this->threadMessageMapper->getStatsRows($filters);
        $metric = array();
        foreach ($rows as $row) {
            $metric[$row['periodStart']] = $row['value'];
        }

        return $metric;
    }
}

