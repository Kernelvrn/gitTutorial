<?php

/**
 * Class StatsMetric_Base
 * Базовый класс для метрик статистики.
 * Позволяет получать значение метрик из аналитической БД
 */
abstract class Statistic_Metric_Base {
    /**
     * Возвращает значения метрики для фильтров
     * @param Statistic_Filters $filters
     * @return array
     */
    abstract public function calc(Statistic_Filters $filters);
}