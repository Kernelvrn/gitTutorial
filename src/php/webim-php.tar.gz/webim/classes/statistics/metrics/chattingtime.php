<?php
/**
 * Class Statistic_Metric_ChattingTime
 * Время, которое оператор(ы) был чатов
 * Возвращается с разбивкой на периоды: ($dtmFrom, $dtmTo, $onlinePeriod)
 */
class Statistic_Metric_ChattingTime extends Statistic_Metric_Base {
    /**
     * @var Mapper_ThreadEvent
     */
    protected $threadEventMapper;

    public function __construct() {
        $this->threadEventMapper = Factory_Mapper::create('threadEvent');
    }

    /**
     * @param Statistic_Filters $filters
     * @return array
     */
    public function calc(Statistic_Filters $filters) {
        $rows = $this->threadEventMapper->getPeriodsRowsWithChats($filters);
        $metric = array();
        $currentPeriodStart = NULL;
        $currentMaxDtm = NULL;
        foreach ($rows as $periodRow) {
            if ($currentPeriodStart !== $periodRow['periodStart']) {
                $currentPeriodStart = $periodRow['periodStart'];
                $currentMaxDtm = strtotime($currentPeriodStart);
                $metric[$currentPeriodStart] = 0;
            }

            if ($periodRow['segmentTo'] > $currentMaxDtm) {
                $metric[$currentPeriodStart] += ($periodRow['segmentTo'] - $currentMaxDtm - max(0, $periodRow['segmentFrom'] - $currentMaxDtm));
                $currentMaxDtm = $periodRow['segmentTo'];
            }
        }

        return $metric;
    }
}