<?php

class Statistic_Metric_PreDinnerTime extends Statistic_Metric_StatusTime  {
    protected function getStatusTitle() {
        return 'pre_dinner';
    }
}