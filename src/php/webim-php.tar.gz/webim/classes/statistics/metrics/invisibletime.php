<?php

class Statistic_Metric_InvisibleTime extends Statistic_Metric_StatusTime  {
    protected function getStatusTitle() {
        return 'invisible';
    }
}