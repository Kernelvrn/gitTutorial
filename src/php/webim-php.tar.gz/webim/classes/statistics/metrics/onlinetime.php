<?php

class Statistic_Metric_OnlineTime extends Statistic_Metric_StatusTime  {
    protected function getStatusTitle() {
        return 'online';
    }
}