<?php

/**
 * Class StatsVector_Base
 * Набор статистических метрик (вектор), соответсвующих некоторому срезу
 */
class Statistic_Vector {
    use Trait_LocalCategoryTree;
    /**
     * Значение измерений, для которых были агрегированы значения метрик вектора
     * @var Statistic_Dimensions
     */
    protected $dimensions;
    /**
     * Ассоциативный массив значений метрик, ключи - названия метрик
     * @var Statistic_Value_Base[]
     */
    protected $values;


    public function __construct(Statistic_Dimensions $dimensions, array $statsValues) {
        $this->dimensions = $dimensions;
        foreach ($statsValues as $metricName => $value) {
            $this->values[$metricName] = $value;
        }
    }

    /**
     * @return Statistic_Dimensions
     */
    public function getDimensions() {
        return $this->dimensions;
    }

    public function get($metricName) {
        return array_key_exists($metricName, $this->values) ? $this->values[$metricName] : NULL;
    }
}