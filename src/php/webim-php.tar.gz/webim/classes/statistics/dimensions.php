<?php

/**
 * Class Statistic_VectorDimensions
 * Хранит измерения для которы был выбран вектор данных
 */
class Statistic_Dimensions {
    use Trait_LocalCategoryTree;

    protected $period = array(
        'dtm' => NULL,
        'length' => NULL
    );
    /**
     * @var Model_Department[]|null
     */
    protected $departments;
    /**
     * @var Model_Operator[]|null
     */
    protected $operators;
    /**
     * @var Model_Category[]|null
     */
    protected $categories;
    /**
     * @var Model_Office[]|null
     */
    protected $offices;
    /**
     * @var string|null
     */
    protected $startPage;
    /**
     * @var string[]|null
     */
    protected $locales;

    public function __construct(array $dimensions) {
        foreach ($dimensions as $dimensionName => $dimensionValue) {
            switch (strtolower($dimensionName)) {
                case 'period':
                    if ($dimensionValue['dtm'] !== NULL) {
                        $this->period['dtm'] = Helper::getAccountDateTime($dimensionValue['dtm']);
                    }
                    if ($dimensionValue['length'] !== NULL) {
                        $this->period['length'] = $dimensionValue['length'] instanceof DateInterval
                            ? $dimensionValue['length']
                            : new DateInterval('PT' . $dimensionValue['length'] . 'S');
                    }
                    break;
                case 'operators':
                    $this->operators = self::prepareDimensionArray($dimensionValue, 'operator', 'Model_Operator');
                    break;
                case 'departments':
                    $this->departments = self::prepareDimensionArray($dimensionValue, 'department', 'Model_Department');
                    break;
                case 'categories':
                    if ($dimensionValue) {
                        $this->categories = array();
                        $dimensionValue = is_array($dimensionValue) && !array_key_exists('category', $dimensionValue)
                            ? $dimensionValue
                            : array($dimensionValue);
                        foreach ($dimensionValue as $category) {
                            if ($category instanceof Model_Category) {
                                $this->categories[] = $category;
                            } elseif ($category['category'] !== NULL) {
                                $this->categories[] = self::getCategoryModel(
                                    $category['category'],
                                    $category['subcategory']
                                );
                            }
                        }
                    }
                    break;
                case 'offices':
                    $this->offices = self::prepareDimensionArray($dimensionValue, 'office', 'Model_Office');
                    break;
                case 'locales':
                    if ($dimensionValue) {
                        $this->locales = is_array($dimensionValue)
                            ? $dimensionValue
                            : array($dimensionValue);
                    }
                    break;
                default:
                    throw new InvalidArgumentException('Unknown dimension type');
            }
        }
    }

    /**
     * @return DateTime|null
     */
    public function getPeriodStart() {
        return $this->period['dtm'];
    }

    /**
     * @return DateInterval|null
     */
    public function getPeriodLength() {
        return $this->period['length'];
    }

    /**
     * @return array
     */
    public function getPeriod() {
        return $this->period;
    }

    /**
     * @return Model_Department[]|null
     */
    public function getDepartments() {
        return $this->departments;
    }

    /**
     * @return Model_Operator[]|null
     */
    public function getOperators() {
        return $this->operators;
    }

    /**
     * @return Model_Category[]|null
     */
    public function getCategories() {
        return $this->categories;
    }

    /**
     * @return Model_Office[]|null
     */
    public function getOffices() {
        return $this->offices;
    }

    /**
     * @return string|null
     */
    public function getStartPage() {
        return $this->startPage;
    }

    /**
     * @return null|string[]
     */
    public function getLocales() {
        return $this->locales;
    }

    protected static function prepareDimensionArray($dimensionValue, $repositoryType, $dimensionClassName) {
        $dimensionArray = array();
        if ($dimensionValue) {
            $dimensionValue = is_array($dimensionValue)
                ? $dimensionValue
                : array($dimensionValue);
            $repository = Factory_Repository::create($repositoryType);
            foreach ($dimensionValue as $value) {
                if ($value instanceof $dimensionClassName) {
                    $dimensionArray[] = $value;
                } elseif ($dimensionValue) {
                    $dimensionArray[] = $repository->findById($value);
                }
            }
        }

        return $dimensionArray ?: NULL;
    }
}