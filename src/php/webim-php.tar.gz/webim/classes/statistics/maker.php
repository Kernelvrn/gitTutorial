<?php

/**
 * Class Statistic_Maker
 * Собирает данные транзакционной БД (mysql) и сохраняет их в аналитической (ClickHouse)
 */
class Statistic_Maker {
    protected static $converterNames = array(
        'operatorTime',
        'threadEvent',
        'threadMessage'
    );

    /**
     * Собирает значения метрик для всех вариантов измерений из транзакционной базы и сохраняет
     * в аналитической. Таким образом формируются OLAP-кубы для всех векторов.
     * @param DateTime $endDate конечная дата для обрабатываемых событий.
     * по последнему сохранённому вектору для соответствующего среза в кубе.
     */
    public function syncAll(DateTime $endDate) {
        foreach (self::$converterNames as $converterName) {
            Factory_StatsConverter::create($converterName)->sync($endDate);
        }
    }
}