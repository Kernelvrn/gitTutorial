<?php

class Statistic_Value_Avg extends Statistic_Value_Base {
    protected $sum = 0;
    protected $cnt = 0;

    /**
     * @param int|number $sum
     * @param int|number $cnt
     * @param array $statsIds
     */
    public function __construct($sum = 0, $cnt = 0, $statsIds = NULL) {
        parent::__construct($statsIds);
        $this->sum = $sum;
        $this->cnt = !empty($cnt) ? abs($cnt) : 0;
    }

    public function getValue() {
        return !empty($this->cnt) ? $this->sum / $this->cnt : 0;
    }

    /**
     * @return number
     */
    public function getSum() {
        return $this->sum;
    }

    /**
     * @return number
     */
    public function getCnt() {
        return $this->cnt;
    }


}