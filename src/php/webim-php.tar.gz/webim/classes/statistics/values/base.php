<?php

/**
 * Class Model_StatsValue
 * Содержит агрегированное значение статистической метрики
 */
abstract class Statistic_Value_Base {
    /**
     * Массив id-строк участвовавших в агрегации
     * @var array
     */
    protected $statsIds;

    /**
     * @param string|array|null $statsIds
     */
    public function __construct($statsIds = NULL) {
        $this->statsIds = array();
        if (is_string($statsIds)) {
            $this->statsIds = explode(',', $statsIds);
        } elseif (is_array($statsIds)) {
            $this->statsIds = $statsIds;
        }
    }

    /**
     * @return array
     */
    public function getStatsIds() {
        return $this->statsIds;
    }

    /**
     * @return mixed|null
     */
    abstract public function getValue();
}