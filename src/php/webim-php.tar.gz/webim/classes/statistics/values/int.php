<?php

class Statistic_Value_Int extends Statistic_Value_Base {
    /**
     * @var int
     */
    protected $value = 0;

    public function __construct($value = 0, $statsIds = NULL) {
        parent::__construct($statsIds);
        $this->value = (int)$value;
    }

    /**
     * @return int
     */
    public function getValue() {
        return $this->value;
    }
}