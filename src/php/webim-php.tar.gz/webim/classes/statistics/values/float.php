<?php

class Statistic_Value_Float extends Statistic_Value_Base {
    /**
     * @var float
     */
    protected $value = 0.0;

    public function __construct($value = 0, $statsIds = NULL) {
        parent::__construct($statsIds);
        $this->value = (float)$value;
    }

    /**
     * @return float
     */
    public function getValue() {
        return $this->value;
    }
}