<?php

/**
 * Class Statistic_Filters
 * Используется для удобной передачи и обработки фильтров при выборке статистики.
 */
class Statistic_Filters {
    /**
     * @var DateTime|null
     */
    protected $startDate;
    /**
     * @var DateTime|null
     */
    protected $endDate;
    /**
     * @var Model_Operator[]|null
     */
    protected $operators;
    /**
     * @var Model_Department[]|null
     */
    protected $departments;
    /**
     * @var string[]|null
     */
    protected $locales;
    /**
     * @var Model_Office[]|null
     */
    protected $offices;
    /**
     * @var Model_Category[]|null
     */
    protected $categories;

    /**
     * Statistic_Filters constructor.
     * @param array $filters [
     *  'dateRange' => ['start', 'end'],
     *  'operators' => [Model_Operator],
     *  'departments' => [Model_Department],
     *  'offices' => [Model_Office],
     *  'locales' => [locale],
     *  'categories' => [Model_Category]
     * ]
     */
    public function __construct(array $filters) {
        if (array_key_exists('dateRange', $filters)) {
            $this->startDate = !empty($filters['dateRange']['start']) ? $filters['dateRange']['start'] : NULL;
            $this->endDate = !empty($filters['dateRange']['end']) ? $filters['dateRange']['end'] : NULL;
        }

        foreach (array('operators', 'departments', 'offices', 'locales', 'categories') as $filterKey) {
            if (array_key_exists($filterKey, $filters)) {
                $this->$filterKey = is_array($filters[$filterKey])
                    ? $filters[$filterKey]
                    : array($filters[$filterKey]);
            }
        }
    }

    /**
     * @return DateTime|null
     */
    public function getStartDate() {
        return $this->startDate;
    }

    /**
     * @return DateTime|null
     */
    public function getEndDate() {
        return $this->endDate;
    }

    /**
     * @return Model_Operator[]|null
     */
    public function getOperators() {
        return $this->operators;
    }

    /**
     * @return Model_Department[]|null
     */
    public function getDepartments() {
        return $this->departments;
    }

    /**
     * @return null|string[]
     */
    public function getLocales() {
        return $this->locales;
    }

    /**
     * @return Model_Office[]|null
     */
    public function getOffices() {
        return $this->offices;
    }

    /**
     * @return Model_Category[]|null
     */
    public function getCategories() {
        return $this->categories;
    }
}