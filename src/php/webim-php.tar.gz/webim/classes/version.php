<?php
define('WEBIM_VERSION', '9.1.51');
define('WEBIM_VERSION_DATE', '2018-12-14');

?>