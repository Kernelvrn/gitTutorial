<?php

class Factory_SubView extends Factory_Base {
    /**
     * Создаёт view для объекта. Ищет вначале непосредственно для него, потом для его родительских классов
     * @param $baseType string html, json, etc.
     * @param $className string
     * @param $viewData array
     * @return View_Base
     * @throws Exception Если view для переданного имени класса не существует.
     */
    public static function create($baseType, $className, $viewData = NULL) {
        $currentClass = $className;
        do {
            $cleanCurrentClass = str_replace('AccountSpecific_' . ucfirst(getAccountId()) . '_', '', $currentClass); //Что бы находить корректные вьюхи для кастомных классов
            $sybViewClass = 'View_SubView_' . ucfirst(strtolower($baseType)) . '_' . $cleanCurrentClass;
            $accountSpecificClass = 'AccountSpecific_' . ucfirst(getAccountId()) . '_' . $sybViewClass;
            if (class_exists($accountSpecificClass)) {
                return new $accountSpecificClass($viewData);
            } elseif (class_exists($sybViewClass)) {
                return new $sybViewClass($viewData);
            }
        } while ($currentClass = get_parent_class($currentClass));

        throw new Exception('SubView for class "' . $className . '" not exists!');
    }
}