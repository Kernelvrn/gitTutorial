<?php

class Factory_Mapper extends Factory_Base {
    protected static $mappers = array();
    protected static $mapperToDbKey = array(
        'ThreadEvent' => 'stats',
        'OperatorTime' => 'stats',
        'ThreadMessage' => 'stats',
        'VisitSession' => 'stats'
    );

    protected static $defaultDbKey = 'pro';

    /**
     * @param string $type
     * @return Mapper_Base
     */
    public static function create($type) {
        $type = ucfirst($type);
        if (!array_key_exists($type, self::$mappers)) {
            $dbKey = array_key_exists($type, self::$mapperToDbKey)
                ? self::$mapperToDbKey[$type]
                : self::$defaultDbKey;
            $db = Factory_Db::create($dbKey);
            $mapperClass = 'Mapper_' . $type;
            self::$mappers[$type] = new $mapperClass($db);
        }

        return self::$mappers[$type];
    }
}