<?php

class Factory_StatsDimensions extends Factory_Base {
    public static function create(array $data) {
        return new Statistic_Dimensions($data);
    }

    public static function createByStatsRow($row) {
        $periodLength = NULL;
        if ($row['d'] !== NULL) {
            $periodLength = $row['h'] === NULL ? 24 * 60 * 60 : 60 * 60;
        }
        $data = array(
            'period' => array(
                'dtm' => $row['d'],
                'length' => $periodLength
            ),
            'operator' => $row['operatorid'],
            'department' => $row['departmentid'],
            'category' => array(
                'category' => $row['category_filter'],
                'subcategory' => $row['subcategory_filter']
            ),
            'office' => $row['officeid'],
            'locale' => $row['locale']
        );

        return static::create($data);
    }
}