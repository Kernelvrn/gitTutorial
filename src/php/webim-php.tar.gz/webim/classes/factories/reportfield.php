<?php

class Factory_ReportField extends Factory_Base {
    /**
     * @param string $type
     * @param null|array $fieldData
     * @return Report_Field_Base
     */
    public static function create($type, array $fieldData = NULL) {
        $fieldClass = 'Report_Field_' . ucfirst($type);
        $value = is_array($fieldData) && array_key_exists('value', $fieldData) ? $fieldData['value'] : NULL;
        $params = is_array($fieldData) && array_key_exists('params', $fieldData) ? $fieldData['params'] : NULL;
        return new $fieldClass($value, $params);
    }
}