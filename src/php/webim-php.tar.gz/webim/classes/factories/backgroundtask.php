<?php

class Factory_BackgroundTask extends Factory_Base {
    /**
     * @param $type string
     * @param $taskData array
     * @return Model_BackgroundTask_Base
     */
    public static function create($type, $taskData = NULL) {
        $taskClassName = 'Model_BackgroundTask_' . $type;
        $accountCustomTaskClass = 'AccountSpecific_' . ucfirst(getAccountId()) . '_' . $taskClassName;

        return class_exists($accountCustomTaskClass)
            ? new $accountCustomTaskClass($taskData)
            : new $taskClassName($taskData);
    }
}