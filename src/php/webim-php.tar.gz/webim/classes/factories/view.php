<?php

class Factory_View extends Factory_Base {
    /**
     * @param $type string
     * @param $viewData array
     * @return View_Base
     */
    public static  function create($type, $viewData = NULL) {
        $viewClass = 'View_' . ucfirst(strtolower($type));

        return new $viewClass($viewData);
    }
}