<?php

/**
 * Class Factory_Base
 * Базовый предок фабрик объектов
 */
abstract class Factory_Base {
    /**
     * Создаёт объект нужного класса на основе $type
     * @param $type string
     * @param $data
     * @return mixed
     * @throws Exception
     */
    public static function create($type, $data = NULL) {
        throw new RuntimeException('Not implement yet');
    }
}