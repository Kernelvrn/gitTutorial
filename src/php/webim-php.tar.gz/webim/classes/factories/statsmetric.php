<?php

class Factory_StatsMetric extends Factory_Base {
    /**
     * @var Statistic_Metric_Base[]
     */
    protected static $metrics = array();

    /**
     * @param string $metricName
     * @return Statistic_Metric_Base
     */
    public static function create($metricName) {
        if (!array_key_exists($metricName, self::$metrics)) {
            $className = 'Statistic_Metric_' . ucfirst($metricName);
            self::$metrics[$metricName] = new $className();
        }

        return self::$metrics[$metricName];
    }
}