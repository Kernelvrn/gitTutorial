<?php

class Factory_Db extends Factory_Base {
    protected static $dbs = array();
    protected static $defaultDbSystem = 'MySql';
    /**
     * @param string $type
     * @return Db_Base
     */
    public static function create($type) {
        $type = strtolower($type);
        if (!array_key_exists($type, self::$dbs)) {
            $xdebugEnabled = function_exists('xdebug_is_enabled') && xdebug_is_enabled();
            if ($xdebugEnabled && function_exists('xdebug_disable')) {
                xdebug_disable();
            }

            $dbConfig = self::usingSlave($type)
                ? self::getDbConfigByType($type, true)
                : self::getDbConfigByType($type);
            $dbSystem = array_key_exists('type', $dbConfig)
                ? $dbConfig['type']
                : self::$defaultDbSystem;
            $dbClass = 'Db_' . ucfirst($dbSystem);
            $db = new $dbClass(
                $dbConfig['database'],
                $dbConfig['user'],
                $dbConfig['password'],
                $dbConfig['host']
            );

            try {
                $db->connect();
            } catch (CouldNotConnectException $exception) {
                if ($xdebugEnabled && function_exists('xdebug_enable')) {
                    xdebug_enable();
                }
                if (!self::usingSlave($type)) {
                    $cacheKey = md5($type);
                    $firstFailureTime = KeyValueCache::get($cacheKey, 'db-failure-time', null);
                    if ($firstFailureTime === null) {
                        KeyValueCache::put($cacheKey, time(), 'db-failure-time', 60 * 60);
                    } else {
                        if (time() - $firstFailureTime > 60) { // more than a minute
                            doMyLog('Switch to slave for ' . $type);
                            $useSlaveFilePath = self::getUseSlaveFilename($type);
                            $dbConfig = self::getDbConfigByType($type, true);
                            $dbSystem = array_key_exists('type', $dbConfig)
                                ? $dbConfig['type']
                                : self::$defaultDbSystem;
                            $dbClass = 'Db_' . ucfirst($dbSystem);
                            $db = new $dbClass(
                                $dbConfig['database'],
                                $dbConfig['user'],
                                $dbConfig['password'],
                                $dbConfig['host']
                            );
                            $db->connect();
                            touch($useSlaveFilePath);
                        }
                    }
                }
            }

            self::$dbs[$type] = $db;
        }

        return self::$dbs[$type];
    }

    protected static function getDbConfigByType($type, $isSlave = false) {
        $dbsConfigs = self::getDbsConfigs();
        if (!array_key_exists($type, $dbsConfigs)) {
            $errorMessage = 'Not found database config for "' . $type . '"';
            immediatelyNotifyAboutProblem($errorMessage);
            throw new DBNotFoundException($errorMessage);
        }

        if (in_array($type, array('pro', 'stats'))) {
            $dbsConfig = array_key_exists(getAccountId(), $dbsConfigs[$type])
                ? $dbsConfigs[$type][getAccountId()]
                : $dbsConfigs[$type]['default'];

            $dbsConfig['database'] = $type === 'pro'
                ? 'webim_service_pro_' . getAccountId()
                : 'webim_statistics_' . getAccountId();
        } else {
            $dbsConfig = $dbsConfigs[$type];
        }

        if ($isSlave) {
            if (empty($dbsConfig['slave'])) {
                $errorMessage = 'Not found slave config for "' . $type . '"';
                immediatelyNotifyAboutProblem($errorMessage);
                throw new DBNotFoundException($errorMessage);
            }

            $dbsConfig = array_merge($dbsConfig, $dbsConfig['slave']);
        }

        if (array_key_exists('slave', $dbsConfig)) {
            unset($dbsConfig['slave']);
        }

        if (!empty($dbsConfig['connection'])) {
            $connections = self::getConnectionConfigs();
            if (!array_key_exists($dbsConfig['connection'], $connections)) {
                $errorMessage = 'Not found connection config for "' . $dbsConfig['connection'] . '"';
                immediatelyNotifyAboutProblem($errorMessage);
                throw new DBNotFoundException($errorMessage);
            }
            $dbsConfig = array_merge($dbsConfig, $connections[$dbsConfig['connection']]);
        }

        return $dbsConfig;
    }

    protected static function getDbsConfigs() {
        return self::getConfig()['dbs'];
    }

    protected static function getConnectionConfigs() {
        return self::getConfig()['connections'];
    }

    protected static $config;
    protected static function getConfig() {
        if (!self::$config) {
            global $MAIN_SETTINGS;
            $config = json_decode(file_get_contents(DB_CONFIG_PATH), true);

            if (is_dir(DB_CONFIG_EXT_PATH) && $handle = opendir(DB_CONFIG_EXT_PATH)) {
                while (false !== ($filename = readdir($handle))) {
                    if (is_file(DB_CONFIG_EXT_PATH . DIRECTORY_SEPARATOR . $filename)) {
                        $configD = json_decode(file_get_contents(DB_CONFIG_EXT_PATH . DIRECTORY_SEPARATOR . $filename), true);
                        $config = array_replace_recursive($config, $configD);
                    }
                }
                closedir($handle);
            }
            if ($accountName = getAccountId()) {
                $accountDir = $MAIN_SETTINGS['client-data-dir'] . DIRECTORY_SEPARATOR . $accountName . '/db/db.json.d';
                if (is_dir($accountDir) && $handle = opendir($accountDir)) {
                    while (false !== ($filename = readdir($handle))) {
                        if (is_file($accountDir . DIRECTORY_SEPARATOR . $filename)) {
                            $configD = json_decode(file_get_contents($accountDir . DIRECTORY_SEPARATOR . $filename), true);
                            $config = array_replace_recursive($config, $configD);
                        }
                    }
                    closedir($handle);
                }
            }

            $dbs = array_key_exists('dbs', $config)
                ? $config['dbs']
                : $config;

            if (array_key_exists('meta', $dbs)) {
                $dbs['operators'] = $dbs['meta'];
            }

            $connections = array_key_exists('connections', $config)
                ? $config['connections']
                : array();

            self::$config = array(
                'dbs' => $dbs,
                'connections' => $connections
            );
        }

        return self::$config;
    }

    protected static function usingSlave($type) {
        return file_exists(self::getUseSlaveFilename($type));
    }

    protected static function getUseSlaveFilename($type) {
        $accountName = !in_array($type, array('pro', 'stats'))
            ? getAccountId()
            : 'login';
        return FilesLocation::getAccountDBPath($accountName) . '/' . $type . '-slave.txt';
    }
}