<?php

class Factory_Report extends Factory_Base {
    /**
     * @param $type string
     * @param $reportData \Iterator_Base|array
     * @param $reportParams array
     * @param $preCalcTotalData array
     * @return Report_Base
     */
    public static  function create($type, $reportData = NULL, array $reportParams = array(), $preCalcTotalData = NULL) {
        $reportClass = 'Report_' . ucfirst($type);
        $accountCustomReportClass = 'AccountSpecific_' . ucfirst(getAccountId()) . '_' . $reportClass;

        return class_exists($accountCustomReportClass)
            ? new $accountCustomReportClass($reportData, $preCalcTotalData, $reportParams)
            : new $reportClass($reportData, $preCalcTotalData, $reportParams);
    }
}