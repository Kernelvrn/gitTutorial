<?php

class Factory_Repository extends Factory_Base {
    /**
     * @var Repository_Base[]
     */
    protected static $repositories = array();

    protected static $typeToDefaultDecorators = array(
        'Operator' => array('Cache'),
        'Department' => array('Cache')
    );

    /**
     * @param string $type CamelCase
     * @param string[] $decoratorNames in CamelCase
     * @return Repository_Base
     */
    public static function create($type, array $decoratorNames = array()) {
        $type = ucfirst($type);
        if (empty($decoratorNames) && !empty(self::$typeToDefaultDecorators[$type])) {
            $decoratorNames = self::$typeToDefaultDecorators[$type];
        }
        $key = $type . '_' . implode('_', $decoratorNames);
        if (empty(self::$repositories[$key])) {
            $repositoryClass = 'Repository_' . $type;
            $repository = new $repositoryClass();
            foreach ($decoratorNames as $decoratorName) {
                $decoratorClass = 'Repository_Decorator_' . $decoratorName;
                $repository = new $decoratorClass($repository);
                if ($decoratorName === 'Cache') {
                    $repository->getAll(); //Прогреваем кэш
                }
            }
            self::$repositories[$key] = $repository;
        }

        return self::$repositories[$key];
    }
}