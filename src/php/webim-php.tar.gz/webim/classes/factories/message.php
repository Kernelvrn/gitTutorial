<?php

class Factory_Message extends Factory_Base {
    /**
     * @var array
     * @const
     */
    protected static $KINDSTONAME = array(
        1 => 'Visitor',
        2 => 'Operator',
        3 => 'ForOperator',
        4 => 'Info',
        9 => 'OperatorBusy',
        10 => 'ContReq',
        11 => 'Contacts',
        13 => 'FileOperator',
        14 => 'FileVisitor',
        15 => 'FormResponse'
    );

    /**
     * @param string $type int
     * @param array $messageRow
     * @return Model_Message_Base
     */
    public static function create($type, array $messageRow) {
        $model = NULL;
        if (!empty(self::$KINDSTONAME[$type])) {
            $messageClass = 'Model_Message_' . self::$KINDSTONAME[$type];
        }

        return !empty($messageClass) && class_exists($messageClass) ? new $messageClass($messageRow) : new Model_Message_Base($messageRow);
    }
}