<?php

class Factory_StatsConverter extends Factory_Base {
    protected static $converters = array();

    /**
     * @param string $converterName
     * @return Statistic_Converter_Base
     */
    public static function create($converterName) {
        if (empty(self::$converters[ucfirst($converterName)])) {
            $className = 'Statistic_Converter_' . ucfirst($converterName);
            self::$converters[$converterName] = new $className();
        }

        return self::$converters[$converterName];
    }
}