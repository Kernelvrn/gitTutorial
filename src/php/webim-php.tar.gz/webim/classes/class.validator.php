<?php
/**
 * Created by JetBrains PhpStorm.
 * User: versus
 * Date: 08.12.13
 * Time: 23:25
 *
 * General class for validation various data.
 */

class Validator {
    /**
     * Check $value via rules and return list of not passed rules
     * @param $value
     * @param array $rules like ('not_empty', 'integer', 'in_range' => array('min' => 0, 'max' => 10), ...)
     * @return array|boolean
     */
    static public function check($value, array $rules) {
        $notPassedRulesMessage = array();
        foreach ($rules as $key => $ruleOrParams) {
            if (is_string($key)) {
                $rule = $key;
                $params = $ruleOrParams;
            } else {
                $rule = $ruleOrParams;
                $params = array();
            }
            $testMethod = self::ruleNameToMethod($rule);
            if (!self::$testMethod($value, $params)) {
                $notPassedRulesMessage[$rule] = self::getErrorMessageForRule($rule);
            }
        }
        return $notPassedRulesMessage;
    }

    static private function processCSV($value, $callback) {
        if (is_string($value)) {
            $values = Helper::trimExplode(',', $value);
        } elseif (is_array($value)) {
            $values = $value;
        } else {
            return empty($value);
        }

        foreach ($values as $val) {
            if (!call_user_func([get_called_class(), $callback], $val)) {
                return FALSE;
            }
        }
        return TRUE;
    }

    /**
     * Empty strings, arrays, NULL - FALSE
     * 0 and others - TRUE
     */
    static public function isNotEmpty($value) {
        return is_numeric($value) || !empty($value);
    }

    static public function isNumeric($value) {
        return empty($value) || is_numeric($value);
    }

    static public function isNotNegative($value) {
        return empty($value) || (self::isNumeric($value) && $value >= 0);
    }

    static public function isPositive($value) {
        return !self::isNotEmpty($value) || (self::isNumeric($value) && $value > 0);
    }

    static public function isInteger($value) {
        return empty($value) || ctype_digit(ltrim(strval($value), '-'));
    }

    static public function isEmail($value) {
        $emailRegPattern = '/^([0-9a-z][\-0-9a-z_]*\.)*([0-9a-z][\-0-9a-z_]*)@(([0-9a-z][\-0-9a-z]*\.)+[a-z]{2,6}|([0-9а-я][\-0-9а-я]*\.)+рф)$/ui';
        return empty($value) || (is_string($value) && preg_match($emailRegPattern, $value)) ? TRUE : FALSE;
    }

    static public function isRussianPhoneNumber($value) {
        $phoneRegPattern = '/^((\+?7|8) ?)?((\([0-58-9]\d{2}\))|([0-58-9]\d{2}))?( )?(\d{3}[\- ]?\d{2}[\- ]?\d{2})$/ui';
        return empty($value) || (is_string($value) && preg_match($phoneRegPattern, $value)) ? TRUE : FALSE;
    }

    static public function isEmails($value) {
        return self::processCSV($value, 'isEmail');
    }

    static public function isUrl($value) {
        $urlRegPattern = '@^((ht|f)tp[s]?)://([a-zа-я0-9\-_]+)+([\.][a-zа-я0-9\-_]+)+([a-zа-я0-9\-\.,\@\?^=%&;:\_/~\+#]*[a-zа-я0-9\-\@\?^=%&;/~\+#])?$@ui';
        return empty($value) || (is_string($value) && preg_match($urlRegPattern, $value)) ? TRUE : FALSE;
    }

    static public function isUrls($value) {
        return self::processCSV($value, 'isUrl');
    }

    static public function isPath($value) {
        $pathRegPattern = '@^/?([a-zа-я0-9\-_]+/)*([a-zа-я0-9\-_]+(\.[a-zа-я0-9\-_]+)?)?$@ui';
        return empty($value) || (is_string($value) && preg_match($pathRegPattern, $value)) ? TRUE : FALSE;
    }

    static public function isPathOrUrl($value) {
        return empty($value) || self::isPath($value) || self::isUrl($value);
    }

    static public function isUrlWithWildcard($value) {
        $urlRegPattern = '@^(((ht|f)tp[s]?)://)?([a-zа-я0-9\-_]+)+([\.][a-zа-я0-9\-_]+)+([a-zа-я0-9\-\.,\@\?*^=%&;:\_/~\+#]*[a-zа-я0-9\-\@\?^=%*&;/~\+#])?$@ui';
        return empty($value) || (is_string($value) && preg_match($urlRegPattern, $value)) ? TRUE : FALSE;
    }

    static public function isPathWithWildcard($value) {
        $pathRegPattern = '@^/?([a-zа-я0-9*\-_]+/)*([a-zа-я0-9*\-_]+(\.[a-zа-я0-9*\-_]+)?)?$@ui';
        return empty($value) || (is_string($value) && preg_match($pathRegPattern, $value)) ? TRUE : FALSE;
    }

    static public function isPathOrUrlWithWildcard($value) {
        return empty($value) || self::isPathWithWildcard($value) || self::isUrlWithWildcard($value);
    }

    static public function isMustBeAccepted($value) {
        return $value == TRUE;
    }

    static public function isTimezoneId($value) {
        return empty($value) || (is_string($value) && in_array($value, DateTimeZone::listIdentifiers()));
    }

    /**
     * Check that value has not spaces
     * @param $value
     * @return bool
     */
    static public function isOneWord($value) {
        return empty($value) || (is_string($value) && !preg_match('/\s/', $value));
    }

    static public function isAllFieldsNotEmptyOrNothing($array) {
        if (array_filter($array)) {
            if (in_array(FALSE, $array)) {
                return FALSE;
            } else {
                return TRUE;
            }
        } else {
            return TRUE;
        }
    }

    static public function isNotExistOperatorEmail($value) {
//        return TRUE; // debug cancel email exists validation
        return empty($value) || in_array($value, array('oleg@webim.ru', 'emikhalev@webim.ru', 'ak@chat2deal.com', 'oleg@chat2deal.com', 'negorov@chat2deal.com', 'ateleshova@chat2deal.com'))
            || !MapperFactory::getOperatorMapper()->getByEmail($value);
    }

    static public function isDate($value) {
        return empty($value) || date_create($value) ? TRUE : FALSE;
    }

    static public function isDatetime($value) {
        return self::isDate($value);
    }

    static public function isDateRange($value) {
        $dateRangeRegPattern = '@^(\d{1,4}[-./]\d{1,2}[-./]\d{1,4})\s*[-\s]\s*(\d{1,4}[-./]\d{1,2}[-./]\d{1,4})$@i';
        $matches = array();
        if (is_string($value) && preg_match($dateRangeRegPattern, trim($value), $matches)) {
            return self::isDate($matches[1]) && self::isDate($matches[2]);
        }

        return empty($value) || FALSE;
    }

    static public function isBackendLocale($value) {
        return empty($value) || in_array($value, Resources::getBackendAvailableLocales());
    }

    static public function isChatLocale($value) {
        return empty($value) || in_array($value, Resources::GetAvailableLocales());
    }

    static public function isLatinsDigitsAndDots($value) {
        return empty($value) || (is_string($value) && preg_match('/^[a-zA-Z_\.\d]*$/', $value));
    }

    static public function isLatinsAndDigits($value) {
        return empty($value) || (is_string($value) && preg_match('/^[a-zA-Z_\d]*$/', $value));
    }

    static public function isNotLongerThan($value, $params) {
        return mb_strlen($value,'UTF-8') <= $params['length'];
    }

    static public function isLongerThan($value, $length) {
        return empty($value) || mb_strlen($value,'UTF-8') > $length;
    }

    static public function isIp($value) {
        $ipRegPattern = '@^(?:(?:25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?)\.){3}(?:25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?)$@i';
        return empty($value) || (is_string($value) && preg_match($ipRegPattern, $value)) ? TRUE : FALSE;
    }

    static public function isDomain($value) {
        $domainRegPattern = '@^(http[s]?://)?([a-zа-я0-9]{1}[a-zа-я0-9-]{0,61}[a-zа-я0-9]{1}\.)+[a-zа-я]{2,12}$@ui';
        return empty($value) || (is_string($value) && preg_match($domainRegPattern, $value)) ? TRUE : FALSE;
    }

    static public function isDomains($value) {
        return self::processCSV($value, 'isDomain');
    }

    static public function isIpOrDomain($value) {
        return empty($value) || self::isIp($value) || self::isDomain($value);
    }

    static public function isInList($value, array $list = array()) {
        return empty($value) ||
            !is_array($value) && in_array($value, $list)
            || is_array($value) && count(array_diff($value, $list)) == 0;
    }

    static public function isNotInList($value, array $list = array()) {
        return empty($value) ||
        !is_array($value) && !in_array($value, $list)
        || is_array($value) && count(array_diff($value, $list)) != 0;
    }

    static public function isCssColor($value) {
        $colorNames = array('aliceblue', 'antiquewhite', 'aqua', 'aquamarine', 'azure', 'beige', 'bisque', 'black', 'blanchedalmond', 'blue', 'blueviolet', 'brown', 'burlywood', 'cadetblue', 'chartreuse', 'chocolate', 'coral', 'cornflowerblue', 'cornsilk', 'crimson', 'cyan', 'darkblue', 'darkcyan', 'darkgoldenrod', 'darkgray', 'darkgreen', 'darkkhaki', 'darkmagenta', 'darkolivegreen', 'darkorange', 'darkorchid', 'darkred', 'darksalmon', 'darkseagreen', 'darkslateblue', 'darkslategray', 'darkturquoise', 'darkviolet', 'deeppink', 'deepskyblue', 'dimgray', 'dodgerblue', 'firebrick', 'floralwhite', 'forestgreen', 'fuchsia', 'gainsboro', 'ghostwhite', 'gold', 'goldenrod', 'gray', 'green', 'greenyellow', 'honeydew', 'hotpink', 'indianred', 'indigo', 'ivory', 'khaki', 'lavender', 'lavenderblush', 'lawngreen', 'lemonchiffon', 'lightblue', 'lightcoral', 'lightcyan', 'lightgoldenrodyellow', 'lightgreen', 'lightgrey', 'lightpink', 'lightsalmon', 'lightseagreen', 'lightskyblue', 'lightslategray', 'lightsteelblue', 'lightyellow', 'lime', 'limegreen', 'linen', 'magenta', 'maroon', 'mediumaquamarine', 'mediumblue', 'mediumorchid', 'mediumpurple', 'mediumseagreen', 'mediumslateblue', 'mediumspringgreen', 'mediumturquoise', 'mediumvioletred', 'midnightblue', 'mintcream', 'mistyrose', 'moccasin', 'navajowhite', 'navy', 'oldlace', 'olive', 'olivedrab', 'orange', 'orangered', 'orchid', 'palegoldenrod', 'palegreen', 'paleturquoise', 'palevioletred', 'papayawhip', 'peachpuff', 'peru', 'pink', 'plum', 'powderblue', 'purple', 'red', 'rosybrown', 'royalblue', 'saddlebrown', 'salmon', 'sandybrown', 'seagreen', 'seashell', 'sienna', 'silver', 'skyblue', 'slateblue', 'slategray', 'snow', 'springgreen', 'steelblue', 'tan', 'teal', 'thistle', 'tomato', 'turquoise', 'violet', 'wheat', 'white', 'whitesmoke', 'yellow', 'yellowgreen');
        $cssColorRegPattern = '@^(#[0-9a-f]{3}|#[0-9a-f]{6}|rgb\((\s*[0-9]{1,3}\s*,){2}\s*[0-9]{1,3}\s*\)|rgba\((\s*[0-9]{1,3}\s*,){3}\s*[0-9.]{1,4}\s*\))$@i';
        return empty($value) || in_array(strtolower($value), $colorNames) || (is_string($value) && preg_match($cssColorRegPattern, $value)) ? TRUE : FALSE;
    }

    static public function isFile($value) {
        if (empty($value)) {
            return TRUE;
        }
        if (!is_array($value)) {
            return FALSE;
        }
        foreach (array('name', 'type', 'size', 'tmp_name', 'error') as $key) {
            if (!array_key_exists($key, $value)) {
                return FALSE;
            }
        }

        return $value['error'] === UPLOAD_ERR_OK && $value['size'] <= MAX_UPLOADED_FILE_SIZE && is_uploaded_file($value['tmp_name']);
    }

    static public function isImageFile($value) {
        if (empty($value)) {
            return TRUE;
        }
        if (self::isFile($value)) {
            $fileInfo = new finfo(FILEINFO_MIME_TYPE);
            if (FALSE !== array_search(
                    $fileInfo->file($value['tmp_name']),
                    array(
                        'jpg' => 'image/jpeg',
                        'png' => 'image/png',
                        'gif' => 'image/gif'
                    ),
                    true
                )) {
                return TRUE;
            }
        }

        return FALSE;
    }

    static public function isInRange($value, $params) {
        return empty($value) || self::isNumeric($value) && $value >= $params['min'] && $value <= $params['max'];
    }

    static public function isPercent($value) {
        $percentRegPattern = '@^1?[0-9]{1,2}%$@ui';
        return empty($value) || (is_string($value) && preg_match($percentRegPattern, $value)) ? TRUE : FALSE;
    }

    static public function isNotDangerSymbols($value) {
        $dangerSymbolsPattern = "(\<|\>|\[|\]|\&|\'|\"|\/)";
        return (is_string($value) && preg_match($dangerSymbolsPattern, $value)) ? FALSE : TRUE;
    }

    static public function isChatLocales($value) {
        return self::processCSV($value, 'isChatLocale');
    }

    static private function ruleNameToMethod($rule) {
        $methodName = 'is' . str_replace(' ', '', ucwords(str_replace('_', ' ', $rule)));
        if (!method_exists(get_called_class(), $methodName)) {
            throw new Exception('Validator error: try to use not existed rule: ' . $rule);
        }

        return $methodName;
    }

    static private function getErrorMessageForRule($rule) {
        $rule2ErrorKey = array(
            'not_empty' => 'errors.field_required',
            'numeric' => 'errors.not_numeric',
            'integer' => 'errors.not_integer',
            'in_list' => 'errors.not_in_list',
            'not_in_list' => 'errors.in_list',
            'all_fields_not_empty_or_nothing' => 'errors.all_fields_not_empty_or_nothing',
            'not_negative' => 'errors.not_positive_or_zero',
            'positive' => 'errors.not_positive',
            'email' => 'errors.email',
            'emails' => 'errors.email',
            'domain' => 'errors.domain',
            'domains' => 'errors.domain',
            'url' => 'errors.url_not_valid',
            'russian_phone_number' => 'errors.russian_phone_not_valid',
            'urls' => 'errors.url_not_valid',
            'timezone_id' => 'errors.timezone_id_not_valid',
            'must_be_accepted' => 'errors.must_be_accepted',
            'one_word' => 'errors.must_has_not_spaces',
            'not_exist_operator_email' => 'errors.email_in_use',
            'date' => 'errors.not_date',
            'date_range' => 'errors.not_correct_date_range',
            'latins_and_digits' => 'errors.latins_and_digits_only',
            'latins_digits_and_dots' => 'errors.latins_digits_and_dots_only',
            'not_longer_than' => 'errors.not_longer_than',
            'longer_than' => 'errors.longer_than',
            'ip_or_domain' => 'errors.ip_or_domain',
            'datetime' => 'errors.not_datetime',
            'path' => 'errors.not_path',
            'path_or_url' => 'errors.not_path_or_url',
            'url_with_wildcard' => 'errors.not_url_with_wildcard',
            'path_with_wildcard' => 'errors.not_path_with_wildcard',
            'path_or_url_with_wildcard' => 'errors.not_path_or_url_with_wildcard',
            'file' => 'errors.not_file',
            'image_file' => 'errors.not_image_file',
            'in_range' => 'errors.not_in_range',
            'percent' => 'errors.not_percent',
            'not_danger_symbols' => 'errors.danger_symbols'
        );


        if (!empty($rule2ErrorKey[$rule])) {
            $message = Resources::Get($rule2ErrorKey[$rule]);
        } else {
            $message = Resources::Get('errors.unknown');
        }

        return $message;
    }
}

?>