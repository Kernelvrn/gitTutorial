<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Pinger</title>
    <script type="text/javascript" src="js/jquery/jquery.js"></script>
    <!--<script type="text/javascript" src="https://code.jquery.com/jquery-3.2.1.js"></script>-->
    <script type="text/javascript" src="js/o/pinger.js"></script>
</head>
<body>
<div id="header"></div>
<br/>
<div id="request_log"></div>

</body>
</html>