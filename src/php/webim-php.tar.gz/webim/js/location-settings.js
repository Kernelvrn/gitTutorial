/**
 * Created by agorodishenin on 31.01.15.
 */

locationSettings = {

    init: function() {
        webimJQuery('#location_json_editor').elastic();
        webimJQuery('#location_json_editor').focus(this.onFocusEditor);
        webimJQuery('#save_location').click(this.saveLocation);
    },

    onFocusEditor: function(){
        webimJQuery(this).removeClass('wrong_json');
    },

    saveLocation: function(){
        try {
            var json = webimJQuery.secureEvalJSON(webimJQuery('#location_json_editor').val());
            webimJQuery('#location_settings_form').submit();
        } catch (err) {
            webimJQuery('#location_json_editor').addClass('wrong_json');
            webimJQuery('#err').html('Wrong json: ' + err);
        }
    }

};
setTimeout( locationSettings.init.bind(locationSettings), 0 );