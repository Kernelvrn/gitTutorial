define([
    'app/base/model',
    'app/libs/error'
],function(BaseModel, Error) {
    var Button = BaseModel.extend({
        defaults: {
            onlineButton: null,
            offlineButton: null,
            params: {
                kind: 'corner',
                slider: {
                    position: 'left',
                    top: '30%',
                    width: 0,
                    alwaysVisibleWidth: 30
                },
                corner: {
                    position: 'right-bottom'
                }
            },
            type: 'client',
            lang: 'ru'
        },

        idAttribute: 'id',

        validation: {
            'onlineButton': {
                required: true,
                fileOrUrl: true
            },
            'offlineButton': {
                required: false,
                fileOrUrl: true
            },
            'params.kind': {
                required: true,
                oneOf: ['slider', 'simple', 'corner', 'html']
            },
            'params.slider.position': {
                oneOf: ['left', 'right']
            },
            'params.slider.width': {
                pattern: 'number'
            },
            'params.slider.top': {
                pattern: 'percent'
            },
            'params.slider.alwaysVisibleWidth': {
                pattern: 'number'
            },
            'params.corner.position': {
                oneOf: ['right-bottom', 'left-bottom', 'right-top', 'left-top']
            }
        },

        initialize: function() {
            this.on('change:onlineButton', function() {
                var val = this.get('onlineButton');
                if (!val) {
                    this.set('params.slider.width', 0);
                } else {
                    var img = new Image();
                    img.onload = jQuery.proxy(function() {
                        this.set('params.slider.width', img.naturalWidth);
                    }, this);
                    if (_.isString(val)) {
                        img.src = val;

                    } else {
                        var reader = new FileReader();
                        reader.readAsDataURL(val);
                        reader.onload = function(event) {
                            img.src = event.target.result;
                        };
                    }
                }
            }, this);

            this.labels = {
                'onlineButton': i18l.getResource('chat_button.label.online_button'),
                'offlineButton': i18l.getResource('chat_button.label.offline_button'),
                'params.kind': i18l.getResource('chat_button.label.kind'),
                'params.slider.position': i18l.getResource('chat_button.label.slider_position'),
                'params.slider.width': i18l.getResource('chat_button.label.width'),
                'params.slider.top': i18l.getResource('chat_button.label.slider_top'),
                'params.slider.alwaysVisibleWidth': i18l.getResource('chat_button.label.slider_visible'),
                'params.corner.position': i18l.getResource('chat_button.label.corner_position')
            }
        }
    });

    return Button;
});

