define([
    'app/base/model'
],function(BaseModel) {
    var Location = BaseModel.extend({
        defaults: {
            code: '',
            params: {}
        },

        idAttribute: 'title',

        validation: {
            'title': {
                required: true
            },
            'params.button.offlineEnabled': {
                required: false,
                oneOf: ['Y', 'N', 'y', 'n']
            }
        },

        oldStyleToNew: {
            'params.invitation.bg': 'params.styles.invitation-body.background',
            'params.invitation.fontColor': 'params.styles.invitation-body.color',
            'params.invitation.fontSize': 'params.styles.invitation-body.font-size',
            'params.chat.headerColor': 'params.styles.header.background',
            'params.chat.headerGradientColor': 'params.styles.header.gradient',
            'params.chat.bgColor': 'params.styles.body.background',
            'params.chat.buttonColor': 'params.styles.button.background',
            'params.chat.buttonGradientColor': 'params.styles.button.gradient'
        },

        initialize: function() {
            if (!this.isNew() && !this.get('params.button.offlineEnabled')) {
                this.set('params.button.offlineEnabled', 'Y');
            }
            if (!this.isNew()) {
                _.each(this.get('params.chat.visitorFields.def'), function(val, key) {
                    if (typeof val == 'string') {
                        this.set('params.chat.visitorFields.def.' + key,{ 'presence': val });
                    }
                }.bind(this));

                _.each(this.oldStyleToNew, function(newPath, oldPath) {
                    if (this.get(oldPath) && !this.get(newPath)) {
                        this.set(newPath, this.get(oldPath));
                        this.set(oldPath, '');
                    }
                }.bind(this));
            }
        },

        isNew: function() {
            return  _.isEmpty(this.get('params'));
        }
    });

    return Location;
});
