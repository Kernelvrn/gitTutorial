define([
    'app/base/model'
],function(BaseModel) {
    var Account = BaseModel.extend({
        defaults: {
            config: null
        },

        idAttribute: 'name',

        getSetting: function(key) {
            return this.get('config.' + key);
        }
    });

    return Account;
});