define([
    'app/base/model'
],function(BaseModel) {
    var Notification = BaseModel.extend({
        defaults: {
            level: 'default',
            dismissible: true,
            image: null,
            text: '',
            title: '',
            position: 'top-right',
            timeoutBeforeClose: 0
        },

        initialize: function() {
            if (this.get('timeoutBeforeClose') > 0) {
                setTimeout(jQuery.proxy(function() {
                    this.destroy();
                }, this), this.get('timeoutBeforeClose'));
            }
        }
    });

    return Notification;
});