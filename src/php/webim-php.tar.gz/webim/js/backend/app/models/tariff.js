define([
    'app/base/model'
],function(BaseModel) {
    var Tariff = BaseModel.extend({
        hasOption: function(optionName) {
            return this.get(optionName) ? true : false;
        }
    });

    return Tariff;
});
