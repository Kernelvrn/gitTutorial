define([
    'app/base/model'
],function(BaseModel) {
    var Operator = BaseModel.extend({
        defaults: {
            avatar: '',
            name: '',
            visible_name: ''
        },

        idAttribute: 'id'
    });

    return Operator;
});
