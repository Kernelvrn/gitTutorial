define([
    'tpl!app/sub-app/location-manager/templates/location-general'
], function (template) {
    var View = Mn.ItemView.extend({
        tagName: 'div',
        className: 'content block block-default',
        template: template,

        behaviors: {
            Base: {},
            Loading: {},
            Stickit: {},
            Validation: {}
        },

        ui: {
            saveButton: '[data-action="save"]'
        },

        bindings: {
            '[name="lang"]': 'params.chat.lang',
            '[name="department_key"]': 'params.chat.departmentKey'
        },

        events: {
            'click @ui.saveButton': 'saveLocation'
        },

        initialize: function(options) {
            this.templateHelpers = {
                controlConfigs: options['controlConfigs']
            };
        },

        saveLocation: function() {
            this.model.save();
        }
    });

    return View;
});
