define([
    'tpl!app/sub-app/button-loader/templates/button-add-panel',
    'app/libs/url-manager',
    'app/libs/file-handler'
], function (template, urlManager) {
    var View = Mn.ItemView.extend({
        tagName: 'div',
        className: 'wrapper-center-block-1',
        template: template,

        behaviors: {
            Base: {},
            Stickit: {},
            Validation: {},
            Closable: {},
            Loading: {}
        },

        buttonFileFilters: null,

        ui: {
            loaderPanel: '[data-type="button-loader-panel"]',
            save: '[data-action="save"]',
            chooseOnlineButton: '[data-action="choose-online-button"]',
            dropZoneOnlineButton: '[data-type="drop-zone-online-button"]',
            onlinePreview: '[data-type="online-preview"]',
            onlineError: '[data-type="online-alert"]',
            chooseOfflineButton: '[data-action="choose-offline-button"]',
            dropZoneOfflineButton: '[data-type="drop-zone-offline-button"]',
            offlinePreview: '[data-type="offline-preview"]',
            offlineError: '[data-type="offline-alert"]',
            buttonPreview: '[data-type="preview"]',
            sliderCustomizeBlock: '[data-type="slider-settings"]',
            cornerCustomizeBlock: '[data-type="corner-settings"]',
            sliderWidthInput: '[name="slider_always_visible_width"]'
        },

        bindings: {
            '[data-type="button-online"]': {
                'observe': 'onlineButton',
                'afterUpdate': function($el, val) {
                    if (val) {
                        this.ui.onlinePreview.show();
                    } else {
                        this.ui.onlinePreview.hide();
                    }
                }
            },
            '[data-type="preview"]': {
                'observe': 'onlineButton',
                'visible': true
            },
            '[data-type="button-offline"]': {
                'observe': 'offlineButton',
                'afterUpdate': function($el, val) {
                    if (val) {
                        this.ui.offlinePreview.show();
                    } else {
                        this.ui.offlinePreview.hide();
                    }
                }
            },
            '[name="type"]': 'params.kind',
            '[name="corner_position"]': 'params.corner.position',
            '[name="slider_position"]': 'params.slider.position',
            '[name="slider_always_visible_width"]': 'params.slider.alwaysVisibleWidth',
            '[name="slider_top"]': {
                'observe': 'params.slider.top',
                'onSet': function(val) {
                    return val + '%';
                }
            }
        },

        events: {
            'click @ui.save': 'saveButton'
        },

        modelEvents: {
            'change:params.kind': 'showSettingsByButtonKind',
            'change': 'refreshPreview',
            'sync': 'onSync'
        },

        initialize: function(options) {
            this.buttonFileFilters = {
                title: i18l.getResource('page.load_button.images'),
                extensions: 'jpg,gif,png,jpeg',
                max_file_size: 10 * 1024 * 1024
            };

            this.appRadio = options['appRadio'];
            this.templateHelpers = {
                controlConfigs: options['controlConfigs'],
                fileExtensions: this.buttonFileFilters['extensions'].replace(/(\w+?)\,/gi, '.$1,')
            };
            this.onlineButtonFileHandler = null;
            this.offlineButtonFileHandler = null;
        },

        onRender: function() {
            this.ui.buttonPreview.on('load', jQuery.proxy(this, 'onUpdatePreviewButton'));
            this.showSettingsByButtonKind();
            this.refreshPreview();
        },

        onDomRefresh: function() {
            var FileHandler = require('app/libs/file-handler');

            this.onlineButtonFileHandler = new FileHandler({
                'buttonElement': this.ui.chooseOnlineButton,
                'multiSelection': false,
                'dropZoneElement': this.ui.dropZoneOnlineButton,
                'filters': this.buttonFileFilters
            });
            this.onlineButtonFileHandler.on('file:add', jQuery.proxy(function(file){
                this.model.set('onlineButton', file);
                this.ui.onlineError.empty().hide();
            }, this));
            this.onlineButtonFileHandler.on('error', jQuery.proxy(function(error){
                this.ui.onlineError.html(i18l.getResource(error.getMessageCode())).show();
            }, this));


            this.offlineButtonFileHandler = new FileHandler({
                'buttonElement': this.ui.chooseOfflineButton,
                'multiSelection': false,
                'dropZoneElement': this.ui.dropZoneOfflineButton,
                'filters': this.buttonFileFilters
            });
            this.offlineButtonFileHandler.on('file:add', jQuery.proxy(function(file){
                this.model.set('offlineButton', file);
                this.ui.offlineError.empty().hide();
            }, this));
            this.offlineButtonFileHandler.on('error', jQuery.proxy(function(error){
                this.ui.offlineError.html(i18l.getResource(error.getMessageCode())).show();
            }, this));
        },

        showSettingsByButtonKind: function() {
            var kind = this.model.get('params.kind');
            this.ui.sliderCustomizeBlock.hide();
            this.ui.cornerCustomizeBlock.hide();
            switch (kind) {
                case 'slider':
                    this.ui.sliderCustomizeBlock.show();
                    break;
                case 'corner':
                    this.ui.cornerCustomizeBlock.show();
                    break;
            }
        },

        refreshPreview: function() {
            switch (this.model.get('params.kind')) {
                case 'simple':
                    this.ui.buttonPreview.css({
                        'position': 'static'
                    });
                    break;
                case 'slider':
                    var slider = this.model.get('params.slider');
                    this.ui.buttonPreview
                        .css({
                            'position': 'absolute',
                            'top': this.model.get('params.slider.top'),
                            'right': '',
                            'left': ''
                        }).css(this.model.get('params.slider.position'), this.model.get('params.slider.alwaysVisibleWidth') - this.ui.buttonPreview.width());
                    break;
                case 'corner':
                    var corner = this.model.get('params.corner');
                    this.ui.buttonPreview.css({
                        'position': 'absolute',
                        'top': '',
                        'right': '',
                        'left': '',
                        'bottom': ''
                    });
                    switch(corner['position']) {
                        case 'right-top':
                            this.ui.buttonPreview.css({
                                'top': 0,
                                'right': 0
                            });
                            break;
                        case 'right-bottom':
                            this.ui.buttonPreview.css({
                                'right': 0,
                                'bottom': 0
                            });
                            break;
                        case 'left-top':
                            this.ui.buttonPreview.css({
                                'top': 0,
                                'left': 0
                            });
                            break;
                        case 'left-bottom':
                            this.ui.buttonPreview.css({
                                'left': 0,
                                'bottom': 0
                            });
                            break;
                    }
                    break;
            }
        },

        saveButton: function() {
            this.model.urlRoot = urlManager.getUrl('button');
            this.model.save();
        },

        onSync: function() {
            this.destroy();
        },

        onUpdatePreviewButton: function() {
            this.ui.sliderWidthInput.attr('max', this.ui.buttonPreview.width());
        },

        onBeforeDestroy: function() {
            this.appRadio.trigger('create-panel:close');
            this.onlineButtonFileHandler && this.onlineButtonFileHandler.destroy();
            this.offlineButtonFileHandler && this.offlineButtonFileHandler.destroy();
        }
    });

    return View;
});