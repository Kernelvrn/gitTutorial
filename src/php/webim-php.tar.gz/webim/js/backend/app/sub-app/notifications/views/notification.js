define([
    'tpl!app/sub-app/notifications/templates/notification'
], function (template) {
    var View = Mn.ItemView.extend({
        tagName: 'div',
        className: function() {
            var className = 'notification alert';
            className += ' alert-' + this.model.get('level');
            if (this.model.get('dismissible')) {
                className += ' alert-dismissible';
            }
            return className;
        },

        template: template,
        attributes: {
            role: 'alert'
        },

        ui: {
            close: '[data-action="close"]'
        },

        events: {
            'click @ui.close': 'close'
        },

        close: function() {
            this.model.destroy();
        }
    });

    return View;
});