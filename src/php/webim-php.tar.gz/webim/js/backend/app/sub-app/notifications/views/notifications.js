define([
    'app/sub-app/notifications/views/notification'
], function (NotificationView) {
    var View = Mn.CollectionView.extend({
        childView: NotificationView,

        filter: function(notification) {
            return this.position == notification.get('position');
        },

        initialize: function(options) {
            this.position = options['position'];
        }
    });

    return View;
});