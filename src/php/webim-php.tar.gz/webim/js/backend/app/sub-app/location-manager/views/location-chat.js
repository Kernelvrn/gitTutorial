define([
    'tpl!app/sub-app/location-manager/templates/location-chat'
], function (template) {
    var View = Mn.ItemView.extend({
        tagName: 'div',
        className: 'chat-customization-settings',
        template: template,

        behaviors: {
            Base: {},
            Stickit: {},
            Validation: {}
        },

        ui: {
            availableDepartments: '[name="available_departments"]'
        },

        bindings: {
            '[name="chat_header_color"]': 'params.styles.header.background',
            '[name="chat_header_color2"]': 'params.styles.header.gradient',
            '[name="chat_bg_color"]': 'params.styles.body.background',
            '[name="chat_button_color"]': 'params.styles.button.background',
            '[name="chat_button_color2"]': 'params.styles.button.gradient',
            '[name="choose_department"]': 'params.chat.chooseDepartment',
            '[name="departments_sort"]': 'params.chat.departmentsSort',
            '[name="chat_enter_first_message"]': 'params.chat.chatEnterFirstMessage',
            '[name="show_first"]': 'params.chat.showFirst',
            '[name="callback_hunter_in_offline"]': 'params.chat.callbackHunterAvailableInOffline',
            '[name="show_select_mode_menu"]': 'params.chat.showSelectModeMenu',
            '[name="chat_hints_enabled"]': 'params.chat.hintsEnabled',
            '[name="available_departments"]': 'params.chat.availableDepartmentKeys'
        },

        modelEvents: {
            'change:params.chat.chooseDepartment': 'onChooseDepartmentChange'
        },

        onAttach: function () {
            this.onChooseDepartmentChange();
        },

        onChooseDepartmentChange: function () {
            var availableDepartmentForm = $(this.ui.availableDepartments).parent();
            if (this.model.get('params.chat.chooseDepartment') === 'Y') {
                availableDepartmentForm.slideDown();
            } else {
                availableDepartmentForm.slideUp();
            }
        },

        initialize: function(options) {
            this.templateHelpers = {
                controlConfigs: options['controlConfigs']
            };
        }
    });

    return View;
});