define([
    'tpl!app/sub-app/location-manager/templates/location-preview'
], function (template) {
    var View = Mn.ItemView.extend({
        tagName: 'div',
        className: 'chat-customization-preview',
        template: template,

        previewController: null,

        behaviors: {
            Base: {},
            Stickit: {}
        },

        ui: {
            'previewBlock': '[data-type="preview"]',
            'offlineState': '[name="offline"]',
            'invitationState': '[name="invitation"]',
            'chatState': '[name="chat-state"]'
        },

        modelEvents: {
            'change:params': 'onLocationChange'
        },

        bindings: {
            '[data-type="preview-button"]': {
                'observe': ['params.button.name', 'params.chat.lang' ],
                'update': 'updateButtonPreview'
            },
            '[data-type="preview-chat"]': {
                'observe': 'params.chat',
                'update': 'updateChatPreview'
            },
            '[data-type="preview-invitation"]': {
                'observe': 'params.invitation',
                'update': 'updateInvitationPreview'
            }
        },

        events: {
            'change @ui.offlineState': 'changedOfflineState',
            'change @ui.invitationState': 'changedInvitationState',
            'change @ui.chatState': 'changedChatState'
        },

        initialize: function(options) {
            this.mergeOptions(options, ['buttons', 'operator']);
        },

        onRender: function() {
            this.$el.loadingState('set');
            this.loadWebimPreviewController()
                .done(function(previewController) {
                    this.previewController = previewController;
                    this.onPreviewLoad();
                }.webimBind(this))
                .fail(this.onError.webimBind(this))
                .always(this.$el.loadingState.webimBind(this.$el, 'remove'));
        },

        loadWebimPreviewController: function() {
            var loadWebimDeferred = new jQuery.Deferred();
            if (!window.webim || !window.webim.previewController) {
                window.webimOnLoad = function() {
                    if (window.webim.previewController) {
                        loadWebimDeferred.resolve(window.webim.previewController);
                    } else {
                        loadWebimDeferred.reject('can-not-load-webim');
                    }
                };
                var systemLoadJsWrapper = jQuery(this.model.get('code')).add(
                    '<script type="text/javascript">' +
                        'webim.mode = \'preview\'; ' +
                        'webim.rootSelector = \'[data-type="preview"]\';' +
                        'webim.debug = true;' +
                    '</script>');
                systemLoadJsWrapper.appendTo('body');
            } else {
                loadWebimDeferred.resolve(window.webim.previewController);
            }

            return loadWebimDeferred.promise();
        },

        onPreviewLoad: function() {
            this.changedChatState();
            this.changedInvitationState();
            this.changedOfflineState();
        },

        onError: function(error) {
            var errorRes;
            switch(error) {
                case 'can-not-load-webim':
                    errorRes = 'location.preview.error.cant_load_webim.text';
                    break;
                default:
                    errorRes = 'location.preview.error.unknown.text'
            }
            console.log(i18l.getResource(errorRes));
        },

        changedChatState: function() {
            if (this.previewController) {
                var state = this.ui.chatState.val();
                if (state == 'hide') {
                    this.previewController.chatHide();
                } else {
                    this.previewController.chatShow({
                        fullname: this.operator.get('visible_name'),
                        avatar: this.operator.get('avatar')
                    });
                    this.previewController.chatSetSection(state);
                }
            }
        },

        changedInvitationState: function() {
            if (this.previewController) {
                if (this.ui.invitationState.prop('checked')) {
                    this.previewController.invitationShow();
                } else {
                    this.previewController.invitationHide();
                }

            }
        },

        changedOfflineState: function() {
            if (this.previewController) {
                if (this.ui.offlineState.prop('checked')) {
                    this.previewController.switchToOffline();
                } else {
                    this.previewController.switchToOnline();
                }

            }
        },

        onLocationChange: function() {
            if (this.model.get('params.button.name') === 'html') {
                var button = this.buttons.get('empty.gif' + '_' + this.model.get('params.chat.lang')).clone();
                button.set('params.kind', 'html');
            } else {
                var button = this.buttons.get((this.model.get('params.button.name') || 'corner.gif') + '_' + this.model.get('params.chat.lang'));
            }
            this.previewController && this.previewController.locationUpdate(jQuery.extend(true,
                {}, this.model.get('params'), { button: button.get('params') }
            ));
        }
    });

    return View;
});
