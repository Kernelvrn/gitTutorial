define([
    'app/sub-app/button-loader/views/button-add-panel',
    'app/models/chat-button',
    'app/models/notification'
], function(AddButtonView, ChatButtonModel) {
    var Controller = Marionette.Object.extend({
        initialize: function(options) {
            this.mergeOptions(options, ['region', 'buttons', 'controlConfigs', 'globalRadio', 'appRadio']);
        },

        show: function(lang) {
            var newButton = new ChatButtonModel({
                lang: lang
            });
            this.addButtonView = new AddButtonView({
                appRadio: this.appRadio,
                controlConfigs: this.controlConfigs,
                model: newButton
            });
            this.region.show(this.addButtonView);
            this.listenToOnce(newButton, 'sync', function() {
                this.buttons.add(newButton);
                var Notification = require('app/models/notification');
                this.globalRadio.trigger('show:notification', new Notification({
                    level: 'success',
                    title: i18l.getResource('button.notification.saved.title'),
                    text: i18l.getResource('button.notification.saved.text'),
                    timeoutBeforeClose: 5000
                }));
                this.globalRadio.trigger('button:created', newButton);
            });
        },

        onBeforeDestroy: function() {
            this.addButtonView.destroy();
        }

    });

    return Controller;
});
