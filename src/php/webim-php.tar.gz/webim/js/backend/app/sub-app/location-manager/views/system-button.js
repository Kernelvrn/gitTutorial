define([
    'tpl!app/sub-app/location-manager/templates/system-button'
], function (template) {
    var View = Mn.ItemView.extend({
        tagName: 'tr',
        template: template,

        behaviors: {
            Base: {},
            Stickit: {}
        },

        bindings: {
            '[data-type="online-button"]': 'onlineButton',
            '[data-type="offline-button"]': 'offlineButton'
        },

        onRender: function() {
            this.$el.click(function() {
                this.trigger('select:button');
            }.bind(this));
        },

        setSelected: function() {
            this.$el.addClass('selected');
        },

        setUnselected: function() {
            this.$el.removeClass('selected');
        }
    });

    return View;
});