define([
    'app/sub-app/notifications/views/notifications'
], function () {
    var NotificationsModule = Mn.Module.extend({
        startWithParent: false,

        initialize: function() {
            this.regionManager = new Marionette.RegionManager();
            this.notifications = null;
        },

        onStart: function(options) {
            this.globalRadio = options['globalRadio'];
            jQuery.each(['top-left', 'top-right', 'bottom-right', 'bottom-left'], jQuery.proxy(function(index, notificationsPosition) {
                jQuery('body').append(
                    jQuery('<div />')
                        .attr('data-region', 'notifications-'  + notificationsPosition)
                        .addClass('notifications notifications-' + notificationsPosition)
                );
                this.regionManager.addRegion(notificationsPosition, '[data-region="notifications-' + notificationsPosition + '"]');
            }, this));

            jQuery.when(
                    this.globalRadio.request('get:collection-promise', 'notifications')
            ).done(jQuery.proxy(function(notifications) {
                this.notifications = notifications;
                var regions = this.regionManager.getRegions();
                var View = require('app/sub-app/notifications/views/notifications');
                jQuery.each(regions, jQuery.proxy(function(position, region) {
                    var view = new View({
                        position: position,
                        collection: this.notifications
                    });
                    region.show(view);
                }, this));
                this.listenTo(this.globalRadio, 'show:notification', function(notification) {
                    this.showNotification(notification)
                }, this);
                this.globalRadio.trigger('ready:notifications');
            }, this));
        },

        showNotification: function(notification) {
            this.notifications.add(notification);
        }
    });

    return NotificationsModule;
});