define([
    'tpl!app/sub-app/location-manager/templates/system-buttons',
    'app/sub-app/location-manager/views/system-button'
], function (template, SystemButtonView) {
    var View = Mn.CompositeView.extend({
        template: template,
        childView: SystemButtonView,
        childViewContainer: '[data-collection-container="system-buttons"]',

        behaviors: {
            Base: {}
        },

        childEvents: {
            'select:button': 'changeSelectedButton'
        },

        modelEvents: {
            'change:params.button': 'onButtonChange'
        },

        onRender: function() {
            this.onButtonChange();
        },

        changeSelectedButton: function(childView) {
            this.model.set('params.button.name', childView.model.get('title'));
        },

        onButtonChange: function() {
            this.children.call('setUnselected');
            var button = this.collection.get(this.model.get('params.button.name') + '_' + this.model.get('params.chat.lang'));
            if (button) {
                var child = this.children.findByModel(button);
            }
            child && child.setSelected();
        }
    });

    return View;
});