define([
    'tpl!app/sub-app/location-manager/templates/resources'
], function (template) {
    var View = Mn.ItemView.extend({
        tagName: 'div',
        className: 'chat-customization-settings',
        template: template,

        behaviors: {
            Base: {},
            Stickit: {},
            Validation: {}
        },

        bindings: {},

        initialize: function(options) {
            var resourceFieldsConfig = {};
            var pattern = /^resource_([a-z0-9\-_]+)_label$/;
            _.each(options['controlConfigs'], function(config, key) {
                if (pattern.test(key)) {
                    var found = key.match(pattern);
                    var resourceKey = found[1];
                    resourceFieldsConfig[resourceKey] = config;
                    this.bindings['[name="' + resourceKey + '"]'] = 'params.resources.' + resourceKey;
                }
            }, this);
            this.templateHelpers = {
                resourceFieldsConfig: resourceFieldsConfig
            };
        }
    });

    return View;
});
