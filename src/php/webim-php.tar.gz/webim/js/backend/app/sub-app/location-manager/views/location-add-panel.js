define([
    'tpl!app/sub-app/location-manager/templates/location-add-panel',
    'app/libs/url-manager'
], function (template, urlManager) {
    var View = Mn.ItemView.extend({
        tagName: 'div',
        className: 'wrapper-center-block-1',
        template: template,

        behaviors: {
            Base: {},
            Stickit: {},
            Validation: {},
            Closable: {},
            Loading: {}
        },

        ui: {
            save: '[data-action="save"]',
            locationForm: 'form[name="location"]'
        },

        bindings: {
            '[name="title"]': 'title'
        },

        events: {
            'click @ui.save': 'saveLocation',
            'submit @ui.locationForm': 'saveLocation'
        },

        modelEvents: {
            'sync': 'onSync'
        },

        initialize: function(options) {
            this.appRadio = options['appRadio'];
            this.templateHelpers = {
                controlConfigs: options['controlConfigs']
            };
        },

        onShow: function() {
            this.ui.locationForm.find('input:first').focus();
        },

        saveLocation: function(event) {
            event.preventDefault();
            this.model.urlRoot = urlManager.getUrl('location');
            this.model.save();
        },

        onSync: function() {
            this.destroy();
        },

        onBeforeDestroy: function() {
            this.appRadio.trigger('create-panel:close');
        }
    });

    return View;
});