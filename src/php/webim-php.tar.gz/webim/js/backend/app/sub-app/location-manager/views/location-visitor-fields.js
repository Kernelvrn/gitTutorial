define([
    'tpl!app/sub-app/location-manager/templates/visitor-fields'
], function (template) {
    var View = Mn.ItemView.extend({
        tagName: 'div',
        className: 'chat-customization-settings',
        template: template,

        behaviors: {
            Base: {},
            Stickit: {},
            Validation: {}
        },

        bindings: {},

        initialize: function(options) {
            var visitorFieldsConfig = {};
            var pattern = /^visitor_field_([a-z0-9]+)_label$/;
            _.each(options['controlConfigs'], function(config, key) {
                if (pattern.test(key)) {
                    var found = key.match(pattern);
                    var fieldName = found[1];
                    visitorFieldsConfig[fieldName] = {
                        'label': config,
                        'presence': {
                            'setting_type': 'select',
                            'options': {
                                '': { 'label_key': 'location.visitor_field.presence_labels.default'},
                                'mandatory': { 'label_key': 'location.visitor_field.presence_labels.mandatory'},
                                'optional': {'label_key': 'location.visitor_field.presence_labels.optional'},
                                'none': {'label_key': 'location.visitor_field.presence_labels.none'}
                            }
                        }
                    };
                    this.bindings['[name="' + fieldName + '"]'] = 'params.chat.visitorFieldLabels.' + fieldName;
                    this.bindings['[name="' + fieldName + '_presence"]'] = 'params.chat.visitorFields.def.' + fieldName + '.presence';
                }
            }, this);
            this.templateHelpers = {
                visitorFieldsConfig: visitorFieldsConfig
            };
        }
    });

    return View;
});