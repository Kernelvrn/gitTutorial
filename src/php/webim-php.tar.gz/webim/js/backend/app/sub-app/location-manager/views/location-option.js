define([], function () {
    var View = Mn.ItemView.extend({
        tagName: 'option',
        attributes: function() {
            return {
                value: this.model.id
            }
        },
        template: _.template('<%- title %>')
    });

    return View;
});
