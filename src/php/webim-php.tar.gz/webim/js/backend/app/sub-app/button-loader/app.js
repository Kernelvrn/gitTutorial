define([
    'app/sub-app/button-loader/controller',
    'app/libs/url-manager'
], function (Controller, urlManager) {
    var ButtonLoader = Mn.Module.extend({
        startWithParent: false,

        initialize: function() {
            this.appRadio = Backbone.Radio.channel('app-button-loader');
            this.router = null;
            this.controller = null;
        },

        onStart: function(options) {
            this.globalRadio = options['globalRadio'];

            jQuery.when(
                this.globalRadio.request('get:collection-promise', 'buttons'),
                this.globalRadio.request('get:json-promise', { url: urlManager.getUrl('button', 'field_configs') })
            ).done(jQuery.proxy(function(buttons, controlConfigs) {
                this.controller = new Controller({
                    'region': options['region'],
                    'globalRadio': this.globalRadio,
                    'appRadio': this.appRadio,
                    'controlConfigs': controlConfigs,
                    'buttons': buttons
                });
                this.router = new Mn.AppRouter({
                    controller: this.controller,
                    appRoutes: {
                        'button/create/:lang/': 'show'
                    }
                });

                this.listenTo(this.globalRadio, 'show:button:create', function(lang) {
                    Backbone.history.navigate('button/create/' + lang + '/', {trigger: true});
                });

                this.listenTo(this.appRadio, 'create-panel:close', function() {
                    Backbone.history.history.back();
                });

                this.globalRadio.trigger('ready:button-loader');
            }, this));
        },

        onStop: function() {
            this.controller.destroy();
        }

    });

    return ButtonLoader;
});
