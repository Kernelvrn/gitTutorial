define([
    'tpl!app/sub-app/location-manager/templates/location-invite',
], function (template) {
    var View = Mn.ItemView.extend({
        tagName: 'div',
        className: 'chat-customization-settings',
        template: template,

        behaviors: {
            Base: {},
            Stickit: {},
            Validation: {}
        },

        ui: {
            preview: '[data-type="preview"][data-preview-type="invite"]'
        },

        bindings: {
            '[name="invitation_theme"]': 'params.invitation.theme',
            '[name="invitation_position"]': 'params.invitation.position',
            '[name="invitation_bg_color"]': 'params.styles.invitation-body.background',
            '[name="invitation_font_color"]': 'params.styles.invitation-body.color'

        },

        initialize: function(options) {
            this.templateHelpers = {
                controlConfigs: options['controlConfigs']
            };
        }
    });

    return View;
});