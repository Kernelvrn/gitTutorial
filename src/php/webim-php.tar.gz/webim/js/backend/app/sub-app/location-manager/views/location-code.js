define([
    'tpl!app/sub-app/location-manager/templates/location-code'
], function (template) {
    var View = Mn.ItemView.extend({
        tagName: 'form',
        template: template,

        behaviors: {
            Base: {},
            Stickit: {}
        },

        bindings: {
            'textarea[name="location-code"]': 'code'
        }
    });

    return View;
});