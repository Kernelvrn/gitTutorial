define([
    'app/sub-app/location-manager/views/system-button',
    'tpl!app/sub-app/location-manager/templates/loaded-button'
], function (BaseView, template) {
    var View = BaseView.extend({
        tagName: 'tr',
        template: template,

        ui: {
            deleteButton: '[data-action="delete"]'
        },

        events: {
            'click @ui.deleteButton': 'deleteButton'
        },

        deleteButton: function() {
            this.model.destroy();
        }
    });

    return View;
});