define([
    'tpl!app/sub-app/location-manager/templates/html-button'
], function (template) {
    var View = Mn.ItemView.extend({
        tagName: 'div',
        className: 'html-button-customization-settings',
        template: template,

        behaviors: {
            Base: {},
            Stickit: {},
            Validation: {}
        },
        ui: {
            button: '[data-type="html-button-view"]',
            settings: '[data-type="settings"]',
            onlineButtonWrapper: '[data-type="online-button"]',
            offlineButtonWrapper: '[data-type="offline-button"]',
        },

        modelEvents: {
            'change:params.button': 'onButtonChange'
        },

        bindings: {
            '[name="html_button_color"]': 'params.button.html.background-color',
            '[name="html_button_border_color"]': 'params.button.html.border-color',
            '[name="html_button_dragged"]': 'params.button.html.dragged',
            '[name="html_button_position_horizontal"]': 'params.button.html.position.horizontal',
            '[name="html_button_position_vertical"]': 'params.button.html.position.vertical',
            // '[data-type="online-button"]': 'onlineButton',
            // '[data-type="offline-button"]': 'offlineButton'
        },

        initialize: function (options) {
            this.templateHelpers = {
                controlConfigs: options['controlConfigs']
            };
        },

        onButtonChange: function () {
            if (this.model.get('params.button.name') === 'html') {
                this.setSelected();
            } else {
                this.setUnselected();
            }
        },

        onRender: function () {
            this.ui.button.click(function () {
                this.model.set('params.button.name', 'html');
                this.model.set('params.button.kind', 'html');
                this.onButtonChange();
            }.bind(this));

            this.onButtonChange();
        },

        setSelected: function () {
            this.ui.settings.show();
            this.ui.button.addClass('selected');
        },

        setUnselected: function () {
            this.ui.settings.hide();
            this.ui.button.removeClass('selected');
        }
    });

    return View;
});