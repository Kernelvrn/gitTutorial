define([
    'app/base/collection',
    'app/models/notification'
], function(BaseCollection, Notification) {
    var Notifications = BaseCollection.extend({
        model: Notification
    });

    return Notifications;
});
