define([
    'app/base/collection',
    'app/models/location',
    'app/libs/url-manager'
], function(BaseCollection, Location, urlManager) {
    var Locations = BaseCollection.extend({
        model: Location,
        url: urlManager.getUrl('location')
    });

    return Locations;
});
