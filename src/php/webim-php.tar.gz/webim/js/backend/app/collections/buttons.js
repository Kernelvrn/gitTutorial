define([
    'app/base/collection',
    'app/models/chat-button',
    'app/libs/url-manager'
], function(BaseCollection, Button, urlManager) {
    var Buttons = BaseCollection.extend({
        model: Button,
        url: urlManager.getUrl('button')
    });

    return Buttons;
});
