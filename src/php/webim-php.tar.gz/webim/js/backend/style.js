/**
 * UI init
 */
var RecaptchaOptions = {
    theme: 'white'
};
jQuery(function() {
    moment.lang(wm.currentLocale);
    jQuery.fn.throbber.defaults.imagePath = wm.rootUrl + '/images/throbber-big.gif';

    jQuery('.js-tooltip').filter('[title=""]').removeClass('tooltip-text');
    jQuery('.js-tooltip').filter('[title!=""]').tooltip();

    var $scrollingTop;
    var $currentHeight;

    jQuery('.js-affix').each(function() {
        jQuery(this).affix({
            offset: {
                top: jQuery(this).attr('data-offset-top')
            }
        });
    });

    jQuery('nav.js-affix').on('affixed.bs.affix', function () {
        $currentHeight = jQuery(".js-affix").height();
        $scrollingTop = 18 + $currentHeight;
        jQuery('.statistics-report table').floatThead({
            scrollingTop: $scrollingTop,
            useAbsolutePositioning: false
        });
        }
    );

    jQuery('.js-scrollspy').each(function() {
        var $this = jQuery(this);
        var spySource = 'body';
        if ($this.attr('data-spy-source')) {
            spySource = $this.attr('data-spy-source');
        }
        jQuery(spySource).scrollspy({target: '#' + $this.attr('id')});
    });

    // jQuery('.statistics-report table').floatThead({
    //     scrollingTop: $scrollingTop,
    //     useAbsolutePositioning: false
    // });

    jQuery('.statistics-report .nav-tabs a').on('shown.bs.tab', function (e) {
        jQuery('.statistics-report table').floatThead('reflow');//Twice, because first time its not correct restore table width
        setTimeout(function() {
            jQuery('.statistics-report table').floatThead('reflow');
        }, 0);
    });
    jQuery('[data-toggle="tab-without-jump"]').click(function(e) {
        e.preventDefault();
        jQuery(this).tab('show');
    });

    var ranges = {};
    ranges[resources['date_range_label']['today']] = [moment(), moment()];
    ranges[resources['date_range_label']['yesterday']] = [moment().subtract('days', 1), moment().subtract('days', 1)];
    ranges[resources['date_range_label']['last_7_days']] = [moment().subtract('days', 6), moment()];
    ranges[resources['date_range_label']['last_30_days']] = [moment().subtract('days', 29), moment()];
    ranges[resources['date_range_label']['this_month']] = [moment().startOf('month'), moment().endOf('month')];
    ranges[resources['date_range_label']['last_month']] = [moment().subtract('month', 1).startOf('month'), moment().subtract('month', 1).endOf('month')];
    jQuery('[data-type="date_range"]').each(function() {
        var $this = jQuery(this);
        $this.daterangepicker({
            format: $this.attr('data-format'),
            startDate: $this.attr('data-startdate'),
            endDate: $this.attr('data-enddate'),
            minDate: $this.attr('data-mindate'),
            maxDate: $this.attr('data-maxdate'),
            applyClass: 'btn-sm btn-success',
            cancelClass: 'btn-sm btn-default',
            ranges: ranges,
            locale: {
                fromLabel: resources['date_range_label']['from'],
                toLabel: resources['date_range_label']['to'],
                applyLabel: resources['date_range_label']['apply'],
                cancelLabel: resources['date_range_label']['cancel'],
                customRangeLabel: resources['date_range_label']['custom_range'],
                monthNames: [
                    resources['months']['short']['january'],
                    resources['months']['short']['february'],
                    resources['months']['short']['march'],
                    resources['months']['short']['april'],
                    resources['months']['short']['may'],
                    resources['months']['short']['june'],
                    resources['months']['short']['july'],
                    resources['months']['short']['august'],
                    resources['months']['short']['september'],
                    resources['months']['short']['october'],
                    resources['months']['short']['november'],
                    resources['months']['short']['december']
                ],
                firstDay: 1
            }
        });
    });

    jQuery('.page select, .external-page select').selectpicker();

    jQuery('[data-type="datetime"]').each(function() {
        var params = {
            language: wm.currentLocale
        }
        if (jQuery(this).attr('data-min-date')) {
            params['minDate'] = jQuery(this).attr('data-min-date');
        }
        if (jQuery(this).attr('data-default')) {
            params['defaultDate'] = jQuery(this).attr('data-default');
        }
        jQuery(this).datetimepicker(params);
    });
    jQuery('.content form').first().not('[data-supress-autofocus]')
        .find('input').first().not('[data-type="date_range"]').focus();

    jQuery('[data-type="color"]').colorpicker({'format': 'rgba', 'align': 'left'});

    jQuery.smartbanner({
        title: 'Webim - онлайн-консультант',
        author: 'Webim.ru',
        price: '',
        appStoreLanguage: 'RU',
        inAppStore: 'В App Store',
        inGooglePlay: 'В Google Play',
        icon: wm.fullBaseUrl + '/images/webim-app.jpg',
        iconGloss: 'false',
        button: 'Установить',
        scale: 'auto',
        speedIn: '300',
        speedOut: '400',
        daysHidden: 0,
        daysReminder: 0,
        force: null,
        layer: true
    });

    if (document.location.hash) {
        jQuery('.nav-tabs a[href="'+ document.location.hash +'"], .nav-pills a[href="'+ document.location.hash +'"]').tab('show') ;
    }

    jQuery('.nav-tabs a, .nav-pills a').not('[data-toggle="tab-without-jump"]').on('shown.bs.tab', function (e) {
        document.location.hash = e.target.hash;
    });

    jQuery('.page select').change(function() {
        var jSelect = jQuery(this);
        var desc = jSelect.find(':selected').attr('data-description');
        if (desc) {
            var jDesc = jQuery('<p class="select-description js-select-description" />')
                .html(desc).hide();
            jSelect.parents('.form-group').append(jDesc);
            jDesc.slideDown();
        } else {
            jSelect.parents('.form-group').find('.js-select-description').remove();
        }
    });
    jQuery('.page select').trigger('change');
});