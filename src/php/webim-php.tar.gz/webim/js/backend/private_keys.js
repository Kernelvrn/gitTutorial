privateKeys = {
    url: '/l/o/settings/private-keys',
    existingKey: null,
    newKey: null,

    init: function() {
        if (!webimJQuery('#private-keys-table').size()) {
            return false;
        }

        this.existingKey = webimJQuery('tr.existing-key').remove();
        this.newKey = webimJQuery('tr.new-key').remove();

        webimJQuery('#generate-key').click(this.generateKey.bind(this));

        this.getKeys();
    },

    getKeys: function() {
        webimJQuery('#private-keys-table').throbber('show');
        wm.ajax.request(
            this.url,
            {},
            function(responseData) {
                this.fillTableWithKeys(responseData);
            }.bind(this),
            function () {
                webimJQuery('#private-keys-table').throbber('hide');
                alert(resources['private_keys_get_error']);
            }.bind(this),
            null, null,
            {type: 'GET'});

    },

    fillTableWithKeys: function(keysJson) {
        var keys = keysJson.keys;
        webimJQuery('#private-keys-table tbody').html('');

        webimJQuery.each(keys, function (_, key) {
            var keyRowWrp = this.existingKey.clone();
            webimJQuery('.key-value', keyRowWrp).text(key);
            webimJQuery('#private-keys-table').append(keyRowWrp);
            keyRowWrp.show();
        }.bind(this));

        var newKeyWrp = this.newKey.clone();
        webimJQuery('#private-keys-table').append(newKeyWrp);
        webimJQuery('#private-keys-table').throbber('hide');
    },

    generateKey: function(e) {
        webimJQuery('#private-keys-table').throbber('show');
        wm.ajax.request(
            this.url,
            {csrfToken: webimJQuery('.csrfToken').first().val()},
            function(responseData) {
                this.fillTableWithKeys(responseData);
            }.bind(this),
            function () {
                webimJQuery('#private-keys-table').throbber('hide');
                alert(resources['private_keys_generate_error']);
            }.bind(this),
            null, null,
            {type: 'POST'});
    }
};

webimJQuery(document).ready(function() {
    privateKeys.init();
});
