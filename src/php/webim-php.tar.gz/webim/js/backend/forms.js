/**
 * Forms logic: load data, store data, validate data
 * TODO: must be rewrite via backbone or another framework
 */
jQuery(function() {
    var uploadFiles = null;
    var uploadFileName = null;
    function setElementValue(jControl, value) {
        if (jControl.size()) {
            switch (jControl.get(0).tagName.toLowerCase()) {
                case 'input':
                    switch (jControl.attr('type')) {
                        case 'text':
                        case 'email':
                        case 'tel':
                        case 'url':
                        case 'password':
                        case 'number':
                            if (value !== '') {
                                jControl.val(value);
                                if (jControl.data('mask')) {
                                    jControl.blur();
                                }
                            }
                            break;
                        case 'checkbox':
                            jControl.attr('checked', value ? 'checked' : null);
                            jControl.closest('.form-group').find('.form-sub-group input').prop('disabled', value ? false : true);
                            break;
                        case 'file':
                            if (value) {
                                var jImageBlock = jControl.siblings('.js-form-image');
                                if (jImageBlock.size() > 0) {
                                    jImageBlock.removeClass('hidden');
                                    jImageBlock.find('img').attr({
                                        'src': value + '?' + Math.floor(Math.random() * 10000),
                                        'id': 'name'
                                    });

                                }
                            }
                    }
                    break;
                case 'select':
                    jControl.selectpicker('val', value);
                    jControl.selectpicker('refresh');
                    break;
                case 'textarea':
                    jControl.val(value);
            }
        }
    }

    function loadFormsData(jBlock, srcUrl) {
        jBlock.removeClass('loading');
        jBlock.throbber('show');
        jQuery.getJSON(srcUrl, function(data) {
            var responseData = data['responseData'];
            jBlock.find('.js-ajax-submit').prop('disabled', true);
            jQuery.each(responseData, function(name, value){
                switch (typeof value) {
                    case 'object':
                        if (value != null && !jQuery.isArray(value)) {
                            jQuery.each(value, function(subname, subvalue) {
                                jControl = jBlock.find('[name="' + subname + '"]');
                                setElementValue(jControl, subvalue);
                            });
                        } else if (jQuery.isArray(value)) {
                            if (jBlock.find('select[name="' + name + '[]"]').size()) {
                                setElementValue(jBlock.find('select[name="' + name + '[]"]'), value);
                            } else {
                                jQuery.each(value, function(index, subvalue) {
                                    jControl = jBlock.find('[name="' + name + '[]"][value="'+ subvalue + '"]');
                                    setElementValue(jControl, true);
                                });
                            }

                            jControl = jBlock.find('[name="' + name + '"]');
                            setElementValue(jControl, value);

                        }
                        break;
                    default:
                        var jControl = jBlock.find('[name="' + name + '"]');
                        setElementValue(jControl, value);
                }
            });
            jBlock.find('.js-form-groups').each(function() {
                var jGroup = jQuery(this);
                var hasValue = false;
                jGroup.find('input').each(function() {
                    hasValue = jQuery(this).val() !== '';
                    return !hasValue;
                });

                if (!hasValue) {
                    jGroup.children('.form-sub-group').hide();
                }

                jGroup.children('label').click(function() {
                    var jLabel = jQuery(this);
                    var jGroup = jLabel.siblings('.form-sub-group');
                    if (jGroup.is(':visible')) {
                        jGroup.slideUp();
                    } else {
                        jGroup.slideDown();
                    }
                });
            });

            // hack for departments with prioritization table in operator.edit
            if (jBlock.find('#departments-table').length) {
                jQuery.each(responseData.departments, function(num, id) {
                    var departmentPriority = responseData['department_to_priority'][num] ? responseData['department_to_priority'][num] : wm.accountConfig['default_operator_department_priority'] ;
                    var departmentRow = jBlock.find('.department-row#' + id);

                    departmentRow.show();
                    departmentRow.find('.department-priority #department-priority-input').val(departmentPriority);
                    jBlock.find('select#new-department-id [department-id="'+ id +'"]').prop('disabled', true);
                });

                jBlock.find('select#new-department-id').selectpicker('render');
                sortOperatorDepartmentTable();
            }

            jBlock.throbber('hide');
            jBlock.find('.js-ajax-submit').prop('disabled', false);
        });
    }

    function ajaxUploadFiles(jForm) {
        if (uploadFileName) {
            var data = new FormData();
            jQuery.each(uploadFiles, function(key, value) {
                data.append(uploadFileName, value);
            });
            data.append('security_token', wm.securityToken);
            var target = jForm.attr('data-target');
            var dataName = jForm.attr('name');
            var params = {
                url: target,
                type: 'POST',
                data: {},
                cache: false,
                dataType: 'json',
                processData: false, // Don't process the files
                contentType: false, // Set content type to false as jQuery will tell the server its a query string request
                success: function(data) {
                    var responseData = data['responseData'];
                    jQuery.each(responseData['stored'],function(name, value) {
                        jForm.find('[name="' + name + '"]').val('')
                            .parents('.form-group').removeClass('has-error').addClass('has-success')
                                .find('.alert').remove().end()
                            .end()
                            .siblings('.js-form-image').removeClass('hidden')
                                .find('img').attr('src', value + '?' + Math.floor(Math.random() * 10000));
                    });
                    jQuery.each(responseData['errors'],function(name,errorMsgs) {
                        jForm.find('[name="' + name + '"]')
                            .parents('.form-group, .checkbox').removeClass('has-success').addClass('has-error')
                            .find('.alert').remove();
                        var jInput = jForm.find('[name="' + name + '"]');
                        jQuery.each(errorMsgs, function(rule, msg) {
                            jInput.before('<div class="alert alert-danger">' + msg + '</div>');
                        });
                    });
                }
            };
            params['data'] = data;
            jQuery.ajax(params);
        }
    }

    function ajaxFormSubmit(jForm) {
        jForm.find('*')
            .removeClass('has-error').removeClass('has-success')
            .find('.alert').remove();
        ajaxUploadFiles(jForm);
        var target = jForm.attr('data-target');
        var params = {
            'security_token': wm.securityToken
        };
        jForm.throbber('show');
        jForm.find('.btn').attr('disabled', 'disabled');
        jForm.find('input, textarea, select').not('[disabled], input[type="file"]').each(function() {
            var jEl = jQuery(this);
            var value = null;
            if (jEl.attr('type') == 'checkbox') {
                value = jEl.is(':checked') ? jEl.val() : false;
            } else if(jEl.attr('type') != 'file') {
                value = jEl.val();
            }
            if (jEl.parents('.js-form-groups').size()) {
                var groupName = jEl.parents('.js-form-groups').first().attr('id').substr('group_'.length);
                if (typeof params[groupName] == 'undefined') {
                    params[groupName] = {};
                }
                params[groupName][jEl.attr('name')] = value;
            } else if (jEl.attr('name').substr(jEl.attr('name').length - 2) == '[]') {
                var name = jEl.attr('name').substr(0, jEl.attr('name').length - 2);
                //jQuery not send empty arrays|objects
                if (typeof params[name] == 'undefined') {
                    params[name] = '';
                }
                if (!params[name] && value) {
                    params[name] = [];
                }
                if (value && jQuery.isArray(value)) {
                    params[name] = value;
                } else if (value) {
                    params[name].push(value);
                }
            } else {
                params[jEl.attr('name')] = value;
            }
        });

        jQuery.ajax({
            type: 'POST',
            url: target,
            data: params,
            success: function(data) {
                var responseData = data['responseData'];
                jQuery.each(responseData['stored'], function(name, value) {
                    jForm.find('[name="' + name + '"], [for="' + name + '"]').not('[type="file"]').parents('.form-group, .checkbox').add(jForm.find('#group_' + name))
                        .addClass('has-success');
                });
                jQuery.each(responseData['errors'], function(name,errorMsgs) {
                    var namePart = name.split('.');
                    var groupName = '';
                    if (namePart.length > 1) {
                        name = namePart[1];
                        groupName = namePart[0];
                    }
                    var jGroup = jForm.find('#group_' + name);
                    if (groupName) {
                        jGroup = jForm.find('#group_' + groupName);
                    }
                    jForm.find('[name="' + name + '"], [for="' + name + '"]').parents('.form-group, .checkbox').add(jGroup)
                        .addClass('has-error');
                    var jLabel = jForm.find('[name="' + name + '"]').siblings('label').add(jForm.find('#group_' + name + ' > label'));
                    if (!jLabel.length) {
                        jLabel = jForm.find('label[for="' + name + '"]').siblings('label').last();
                    }
                    jQuery.each(errorMsgs, function(rule, msg) {
                        jLabel.after('<div class="alert alert-danger">' + msg + '</div>')
                    });
                });
                jForm.throbber('hide');
                jForm.find('.btn').attr('disabled', null);
            }
        });
    }

    function ajaxDepartmentsFormSubmit(jForm) {
        jForm.find('.department-alert').hide();

        jForm.throbber('show');

        var target = jForm.attr('data-target');
        var params = {
            'security_token': wm.securityToken,
            'departments': []
        };

        jForm.find('.department-row:visible').each(function() {
            var jRow = jQuery(this);
            params.departments.push({
                'id': jRow.prop('id'),
                'priority': jRow.find('.department-priority #department-priority-input').val()
            })
        });


        jQuery.ajax({
            type: 'POST',
            url: target,
            data: params,
            dataType: 'json',
            success: function(data) {
                var responseData = data['responseData'];
                jForm.throbber('hide');
                jForm.find('.btn').attr('disabled', null);

                sortOperatorDepartmentTable();

                if (responseData['result'] == 'ok') {
                    jForm.find('.department-alert.alert-success').show();
                } else {
                    jForm.find('.department-alert.alert-error').show();
                }

            }
        });

    }

    function sortOperatorDepartmentTable() {
        jQuery('#departments-table').tablesorter({
                sortList: [[1, 0]],
                textExtraction: function(node) {
                    return jQuery(node).find('#department-priority-input').val();
                }
            }
        )
    }

    function deleteOperatorDepartmentButtonClickHandler(button) {
        button.click(function(event) {
            var row = jQuery(this).parent().parent();

            row.hide();
            jQuery('select#new-department-id [department-id="'+ row.prop('id') +'"]').prop('disabled', false);

            jQuery('select#new-department-id').selectpicker('render');
            event.preventDefault();
        });
    }

    jQuery('.js-load-data[data-source]').each(function(){
        loadFormsData(jQuery(this), jQuery(this).attr('data-source'));
    });

    jQuery('.js-ajax-submit').click(function(event){
        event.preventDefault();
        ajaxFormSubmit(jQuery(this).parents('form'));
    });

    jQuery('.js-ajax-departments-submit').click(function(event){
        event.preventDefault();
        ajaxDepartmentsFormSubmit(jQuery(this).parents('form'));
    });

    jQuery('[data-action="remove-image"]').click(function(event){
        event.preventDefault();
        var $this = jQuery(this);
        var target = '?action=removeImageJSON&image_type=' + $this.attr('data-image-type') + '&security_token=' + wm.securityToken;
        if ($this.parents('form').attr('data-operator')) {
            target += '&operatorid=' + $this.parents('form').attr('data-operator');
        }
        if ($this.parents('form').attr('data-department')) {
            target += '&departmentid=' + $this.parents('form').attr('data-department');
        }
        jQuery.getJSON(target, function() {
            $this.parents('.form-image').addClass('hidden');
        });
    });

    jQuery('input[type="file"]').change(function(event) {
        uploadFiles = event.currentTarget.files;
        uploadFileName = jQuery(event.currentTarget).attr('name');
    });

    if (typeof jstz != 'undefined') {
        var timezone = jstz.determine();
        jQuery('input.js-auto-timezone').val(timezone.name());
    }

    jQuery('[data-action="create-operator"]').click(function() {
        window.location.pathname = wm.rootUrl + '/operator/operator.php';
    });

    jQuery('[data-action="reset-incorrect-login-cache"]').click(function(e) {
        var el = jQuery(e.currentTarget);
        e.target.disabled = true;
        el.find('.js-reset-button-text').hide();
        el.find('.operator-rotate-icon').show();
        jQuery.ajax({
            method: "GET",
            url: "reset_incorrect_login_cache.php"
        }).done(function(msg) {
            e.target.disabled = false;
            el.find('.js-reset-button-text').show();
            el.find('.operator-rotate-icon').hide();
            if (msg.result) {
                alert(resources.operator.reset_incorrect_login_cache_success);
            } else {
                alert(resources['operator'][msg.error]);
            }
        }).fail(function (msg) {
            e.target.disabled = false;
            el.find('.js-reset-button-text').show();
            el.find('.operator-rotate-icon').hide();
            alert(resources.operator.reset_incorrect_login_cache_failed);
        });
    });

    jQuery('[data-action="switch-off-all-operators"]').click(function(event) {
        onlineSupport.sendAction('disconnect_all_operators', {}, {availableOffline: true, connection: longPollConnection});
        alert(resources['disconnect_all_operators_timeout']);
        event.preventDefault();
    });

    jQuery('[data-action="hide-offline-operators"]').click(function(event) {
        jQuery('tr.status-offline').hide();
        jQuery(this).hide();
        jQuery('[data-action="show-offline-operators"]').show();
        event.preventDefault();
    });

    jQuery('[data-action="show-offline-operators"]').click(function(event) {
        jQuery('tr.status-offline').show();
        jQuery(this).hide();
        jQuery('[data-action="hide-offline-operators"]').show();
        event.preventDefault();
    });

    jQuery('[data-action="switch-off-operator"]').click(function(event) {
        onlineSupport.sendAction('disconnect_operator', {operator_id: jQuery(this).attr('data-operator-id')},
            {availableOffline: true, connection: longPollConnection});
        alert(resources['disconnect_operators_timeout']);
        event.preventDefault();
    });

    jQuery('[data-action="edit-operator"]').click(function() {
        window.location.href = window.location.protocol + '//' + window.location.host + wm.rootUrl + '/operator/operator.php?operatorid=' + jQuery(this).attr('data-operator-id');
    });

    jQuery('[data-action="remove-operator"]').click(function(event) {
        if (confirm(resources['page_agents']['confirm']['delete'])) {
            window.location.search = '?action=deleteOperator&operatorid=' + jQuery(this).attr('data-operator-id') + '&security_token=' + wm.securityToken;
        }
    });

    jQuery('[data-action="delete-operator-department"]').each(function(i, button) {
            deleteOperatorDepartmentButtonClickHandler(jQuery(button));
        }
    );

    jQuery('[data-action="add-operator-department"]').click(function(event) {
        event.preventDefault();

        var addRow = jQuery(this).parent().parent();
        addRow.find('*').removeClass('has-error');

        var id = addRow.find('#new-department-id').val();
        var priority = addRow.find('#new-department-priority').val();

        if (!priority || priority <= 0) {
            addRow.find('#new-department-priority').parent().addClass('has-error');
            return;
        }

        var newRow = jQuery('#departments-table #' + id).remove();
        newRow.find('#department-priority-input').val(priority);

        jQuery('select#new-department-id [department-id="'+ newRow.prop('id') +'"]').prop('disabled', true);
        jQuery('select#new-department-id').selectpicker('render');

        jQuery('#departments-table .create-department-row').after(newRow);

        deleteOperatorDepartmentButtonClickHandler(newRow.find('[data-action="delete-operator-department"]'));

        newRow.show();

    });

    jQuery('#account-select').change(function() {
        location.href = jQuery('#account-select').val();
    });

    jQuery('[data-action="create-department"]').click(function() {
        window.location.pathname = wm.rootUrl + '/operator/department.php';
    });

    jQuery('[data-action="edit-department"]').click(function() {
        window.location.href = window.location.protocol + '//' + window.location.host + wm.rootUrl + '/operator/department.php?id=' + jQuery(this).attr('data-department-id');
    });

    jQuery('[data-action="remove-department"]').click(function(event) {
        if (confirm(resources['page_depaprtments']['confirm']['delete'])) {
            window.location.search = '?action=fullDeleteDepartment&departmentid=' + jQuery(this).attr('data-department-id') + '&security_token=' + wm.securityToken;
        }
    });

    jQuery('[data-action="delete-department"]').click(function(event) {
        if (confirm(resources['page_depaprtments']['confirm']['deactivate'])) {
            window.location.search = '?action=deleteDepartment&departmentid=' + jQuery(this).attr('data-department-id') + '&security_token=' + wm.securityToken;
        }
    });

    jQuery('[data-action="restore-department"]').click(function(event) {
        if (confirm(resources['page_depaprtments']['confirm']['activate'])) {
            window.location.search = '?action=restoreDepartment&departmentid=' + jQuery(this).attr('data-department-id') + '&security_token=' + wm.securityToken;
        }
    });

    jQuery('[data-action="add-blocked-visitor"]').click(function() {
        window.location.pathname = wm.rootUrl + '/operator/ban.php';
    });

    jQuery('[data-action="remove-blocked-visitor"]').click(function(event) {
        if (confirm(resources['page_ban']['confirm']['delete'])) {
            window.location.search = '?action=deleteBlockedVisitor&id=' + jQuery(this).attr('data-blocked-visitor-id') + '&security_token=' + wm.securityToken;
        }
    });

    jQuery('[data-action="edit-blocked-visitor"]').click(function() {
        window.location.href = window.location.protocol + '//' + window.location.host + wm.rootUrl + '/operator/ban.php?id=' + jQuery(this).attr('data-blocked-visitor-id');
    });

    jQuery('[data-action="create-auto-invite"]').click(function() {
        window.location.pathname = wm.rootUrl + '/operator/auto_invite.php';
    });

    jQuery('[data-action="edit-auto-invite"]').click(function() {
        window.location.href = window.location.protocol + '//' + window.location.host + wm.rootUrl + '/operator/auto_invite.php?id=' + jQuery(this).attr('data-auto-invite-id');
    });

    jQuery('[data-action="remove-auto-invite"]').click(function(event) {
        if (confirm(resources['page_auto_invites']['confirm']['delete'])) {
            window.location.search = '?action=deleteAutoInvite&id=' + jQuery(this).attr('data-auto-invite-id') + '&security_token=' + wm.securityToken;
        }
    });

    jQuery('form').submit(function(event){
        var secured = jQuery(this).attr('data-secured');
        if (wm.securityToken &&  (typeof secured == 'undefined' || secured === false)) {
            jQuery(this).append('<input type="hidden" name="security_token" value="' + wm.securityToken + '" />');
        }
    });

    jQuery('[data-action="unisender-contacts-export"]').click(function() {
        var btn = jQuery(this);
        btn.prop('disabled', true).throbber();
        jQuery.getJSON('/l/o/export-contacts-to-unisender')
            .done(function() {
                alert(resources.alert.unisender_export_success);
            }).error(function() {
                alert(resources.alert.server_error);
            }).always(function() {
                btn.prop('disabled', false).throbber('hide');
            })
    });

    jQuery('[name="bitrix24_portal"]').on('keyup change', function(event) {
        jQuery(this).val()
            ? jQuery('[data-action="bitrix24-auth"]').prop('disabled', false)
            : jQuery('[data-action="bitrix24-auth"]').prop('disabled', true);
    });

    jQuery('[data-action="bitrix24-auth"]').click(function(event) {
        event.preventDefault();

        window.location.href = webimTools.formatUrl({
            baseUrl: 'https://' + jQuery('[name="bitrix24_portal"]').val() + '/oauth/authorize/',
            params: {
                'response_type': 'code',
                'client_id': wm['mainSettings']['bitrix24_app_client_id'],
                'redirect_uri': wm['mainSettings']['bitrix24_app_redirect_uri']
            }
        });
    });

    jQuery('[data-table-process="reduce_empty-columns"]').each(function() {
        var table = jQuery(this);
        table.find('th').each(function(columnIndex) {
            var remove = 0;

            var tds = jQuery(this).parents('table').find('tbody tr td:nth-child(' + (columnIndex + 1) + ')');
            tds.each(function() {
                if (!jQuery(this).html().trim()) {
                    remove++;
                }
            });

            if (remove == (table.find('tbody tr').length)) {
                jQuery(this).hide();
                tds.hide();
            }
        });
    });

    jQuery('.form-group input[type="checkbox"]').change(function() {
        jQuery(this).closest('.form-group').find('.form-sub-group input').prop('disabled', jQuery(this).prop('checked') ? false : true);
    });

    var checkBackgroundTask = function(task, conf) {
        switch (task['state']) {
            case 'completed':
                conf['reportButton']
                    .prop('disabled', false);
                var result = task['result'];
                conf['reportLink']
                    .attr('href', '/operator/reportdownload.php?filename=' + encodeURIComponent(result['reportFilename']))
                    .removeClass('disabled')
                    .throbber('hide')
                    .attr('title', 'Для скачивания готов отчёт по фильтрам: ' + JSON.stringify(_.omit(task['config']['filters'], function(value, key) {
                        return _.isEmpty(value) || _.contains(['currentOperatorId', 'accountTimezone'], key);
                    })));
                conf['reportProgressBar'].width(0);
                break;
            case 'running':
                conf['reportButton']
                    .prop('disabled', true);
                conf['reportLink']
                    .throbber('show')
                    .addClass('disabled')
                    .attr('title', 'Готовится отчёт по фильтрам: ' + JSON.stringify(_.omit(task['config']['filters'], function(value, key) {
                        return _.isEmpty(value) || _.contains(['currentOperatorId', 'accountTimezone'], key);
                    })));
                conf['reportProgressBar']
                    .width(Math.floor(task['progress'] * 100) + '%');
                setTimeout(function() {
                    refreshBackgroundTask(conf);
                }, 5000);
                break;
            default:
                conf['reportButton']
                    .prop('disabled', false);
                conf['reportLink']
                    .addClass('disabled')
                    .attr('title', '')
                    .throbber('hide');
                conf['reportProgressBar'].width(0);
        }
    };

    var refreshBackgroundTask = function(conf) {
        jQuery.ajax('/operator/backgroundtask.php', {
            data: {
                key: conf['type']
            },
            method: 'GET'
        }).done(function(resp) {
            if (resp['responseData'] && resp['responseData']['id']) {
                checkBackgroundTask(resp['responseData'], conf);
            }
        });
    };

    var reportsElements = [{
        type: 'ThreadReport',
        action: 'createThreadsTask',
        reportButton: jQuery('[data-action="prepare-thread-report"]'),
        reportLink: jQuery('[data-type="last-prepared-report"]'),
        reportProgressBar: jQuery('[data-type="prepare-report-progress"]')
    }, {
        type: 'OperatorTimeReport',
        action: 'createOperatorTimeTask',
        reportButton: jQuery('[data-action="prepare-operator-time-report"]'),
        reportLink: jQuery('[data-type="operator-time-last-prepared-report"]'),
        reportProgressBar: jQuery('[data-type="prepare-operator-time-report-progress"]')
    }, {
        type: 'OperatorStatusTimeReport',
        action: 'createOperatorStatusTimeTask',
        reportButton: jQuery('[data-action="prepare-operator-status-time-report"]'),
        reportLink: jQuery('[data-type="operator-status-time-last-prepared-report"]'),
        reportProgressBar: jQuery('[data-type="prepare-operator-status-time-report-progress"]')
    }];

    if (reportsElements[0]['reportButton'].length) {
        refreshBackgroundTask(reportsElements[0]);
    }

    reportsElements[0]['reportButton'].click(function(event) {
        event.preventDefault();
        event.stopPropagation();
        var elem = jQuery(this);
        elem.prop('disabled', true);
        jQuery.ajax('/operator/history.php?' + jQuery('form[name="filters"]').serialize(), {
            data: {
                action: reportsElements[0]['action']
            },
            method: 'GET'
        }).done(function(resp) {
            checkBackgroundTask(resp['responseData'], reportsElements[0]);
        });
    });

    if (reportsElements[1]['reportButton'].length) {
        refreshBackgroundTask(reportsElements[1]);
    }

    reportsElements[1]['reportButton'].click(function(event) {
        event.preventDefault();
        event.stopPropagation();
        var elem = jQuery(this);
        elem.prop('disabled', true);
        jQuery.ajax('/operator/history.php?' + jQuery('form[name="filters"]').serialize(), {
            data: {
                action: reportsElements[1]['action']
            },
            method: 'GET'
        }).done(function(resp) {
            checkBackgroundTask(resp['responseData'], reportsElements[1]);
        });
    });

    if (reportsElements[2]['reportButton'].length) {
        refreshBackgroundTask(reportsElements[2]);
    }

    reportsElements[2]['reportButton'].click(function(event) {
        event.preventDefault();
        event.stopPropagation();
        var elem = jQuery(this);
        elem.prop('disabled', true);
        jQuery.ajax('/operator/history.php?' + jQuery('form[name="filters"]').serialize(), {
            data: {
                action: reportsElements[2]['action']
            },
            method: 'GET'
        }).done(function(resp) {
            checkBackgroundTask(resp['responseData'], reportsElements[2]);
        });
    });
});