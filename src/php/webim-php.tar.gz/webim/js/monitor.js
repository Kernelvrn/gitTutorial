wm = {};

monitor = {
    host: '',
    accountStatRowTemplate: null,

    init: function() {
        this.envList = null;
        this.tornadoList = [];

        this.totalValues = {};

        var pieces = window.location.hash.substring(1).split(':');
        if (pieces.length == 3) {
            setTimeout(function () {
                this.envList = [{host: pieces[0], env: pieces[1]}];
                this.onPortsRequest(0, [pieces[2]]);
                this.requestMonitor(0);
            }.bind(this), 0);
        } else {
            if (pieces.length >= 1 && pieces[0] != '') {
                monitor.envFilter = {
                    host: pieces[0],
                    env: pieces.length == 2 ? pieces[1] : null
                };
            }
            wm.ajax.request(
                "/webim/service/monitor/get-all-env-list.php", {},
                this.onEnvListRequest.bind(this),
                this.onRequestError.bind(this),
                null, null,
                {type: 'GET'});
        }

        this.popupTemplate = webimJQuery('.popup').remove();
        this.tornadoInfoRowTemplate = webimJQuery('#tornados_info tbody tr').remove();
        this.accountStatRowTemplate = webimJQuery('#accounts_stat tbody tr').remove();
        this.collectedToStoreObjectsStatsRowTemplate = webimJQuery('.failed_to_store_objects_stats table tbody tr').remove();
        this.collectedToStoreObjectsStatsDivTemplate = webimJQuery('.failed_to_store_objects_stats').remove();
        this.collectedToStoreObjectsDivTemplate = webimJQuery('.failed_to_store_objects').remove();
        this.reloadTornadosDivTemplate = webimJQuery('.reload').remove();
        this.queueMonitorDataDivTemplate = webimJQuery('.queue_monitor_data').remove();
        this.timersStatsLastMinRowTemplate = webimJQuery('.timer_stats_data table.last_min_timers tbody tr').remove();
        this.timersStatsFailedRowTemplate = webimJQuery('.timer_stats_data table.failed_timers tbody tr').remove();
        this.timersStatsLastMinDivTemplate = webimJQuery('.timer_stats_data').remove();

        webimJQuery('body').prepend(webimJQuery('<div/>').text('' + new Date()));
        this.initTotalRow();
    },

    initTotalRow: function () {
        var totalRowWpr = this.tornadoInfoRowTemplate.clone();
        totalRowWpr.addClass("total");

        webimJQuery('.host', totalRowWpr).text("TOTAL");
        webimJQuery('a.timers_popup', totalRowWpr).removeAttr('href');
        webimJQuery('a.reload', totalRowWpr).click(function(e) {
            e.preventDefault();
            var content = this.reloadTornadosDivTemplate.clone();
            this.showPopup(content);
            this.reloadTornado(0, content);
        }.bind(this));

        webimJQuery('#tornados_info tbody').append(totalRowWpr);
    },

    onEnvListRequest: function(responseData) {
        if (monitor.envFilter) {
            var newResponseData = [];
            for (var i in responseData) {
                var rowData = responseData[i];
                if (monitor.envFilter.host == rowData.host && (monitor.envFilter.env == null || monitor.envFilter.env == rowData.env)) {
                    newResponseData.push(rowData);
                }
            }
            responseData = newResponseData;
        }
        this.envList = responseData;

        this.requestPorts(0);
    },

    requestPorts: function(idx) {
        var env = this.envList[idx];
        wm.ajax.request(
            "/webim/service/monitor/get-tornado-ports.php", {'env': env['env'], 'host': env['host']},
            function(responseData) {
                if (responseData) {
                    this.onPortsRequest(idx, responseData);
                } else {
                    this.postError('host ' + env['host'] + ' ports request empty response');
                }
                this.onPortsRequestProcessed(idx);
            }.bind(this),
            function() {
                this.postError('host ' + env['host'] + ' ports request failed');
                this.onPortsRequestProcessed(idx);
            }.bind(this),
            null, null,
            {type: 'GET'});
    },

    onPortsRequestProcessed: function(idx) {
        if (idx + 1 < this.envList.length) {
            this.requestPorts(idx + 1);
        } else {
            this.requestMonitor(0);
        }
    },

    onPortsRequest: function(idx, responseData) {
        var env = this.envList[idx];
        var tornados = [];
        for (var i in responseData) {
            var port = responseData[i];
            var tornado = {host: env.host, env: env.env, ip: env.ip, port: port};
            tornados.push(tornado);
            this.tornadoList.push(tornado);
        }

        tableUtils.fillTableWithData(webimJQuery('#tornados_info tbody'), this.tornadoInfoRowTemplate, tornados, {}, function(row, rowData) {
            webimJQuery(row).addClass(rowData.host + '_' + rowData.port);
            webimJQuery(row).addClass(rowData.host + '_' + rowData.env);
            webimJQuery(row).addClass(rowData.env);
            webimJQuery('a.host', row).attr('href', '#' + rowData.host);
            webimJQuery('a.env', row).attr('href', '#' + rowData.host + ':' + rowData.env);
            webimJQuery('a.port', row).attr('href', '#' + rowData.host + ':' + rowData.env + ':' + rowData.port);
            webimJQuery('a.scroll_to', row).attr('href', '#' + rowData.host + '_' + rowData.port);
            webimJQuery('a.reload', row).click(function(e) {
                e.preventDefault();
                this.reload(rowData);
            }.bind(this));
            webimJQuery('a.timers_popup', row).click(function(e) {
                e.preventDefault();
                this.getTimersStatistics(rowData);
            }.bind(this));
        }.bind(this));
    },


    requestMonitor: function(idx) {
        var tornado = this.tornadoList[idx];
        wm.ajax.request(
            "/webim/service/monitor/tornado-monitor-proxy.php",
            {'port': tornado.port, 'host': tornado.host},
            function(responseData) {
                if (responseData) {
                    this.onMonitorRequest(idx, responseData);
                } else {
                    this.postError('Monitor request for ' + tornado.host + ':' + tornado.port + ' failed');
                    this.requestMonitorForNextIdx(idx);
                }
            }.bind(this),
            function(responseData) {
                this.postError('Monitor request for ' + tornado.host + ':' + tornado.port + ' failed');
                this.requestMonitorForNextIdx(idx);
            }.bind(this),
            null, null,
            {type: 'GET'});
    },

    requestMonitorForNextIdx: function(idx) {
        if (idx + 1 < this.tornadoList.length) {
            this.requestMonitor(idx + 1);
        }
    },

    onMonitorRequest: function(idx, responseData) {
        var tornado = this.tornadoList[idx];
        var rowWrp = webimJQuery('#tornados_info .' + tornado.host + '_' + tornado.port);
        webimJQuery('.version', rowWrp).text(responseData.mainInfo.version);
        webimJQuery('.ubuntu_version', rowWrp).text(responseData.mainInfo.ubuntuVersion);
        webimJQuery('.branch', rowWrp).text(responseData.mainInfo.branch);
        webimJQuery('.startTime', rowWrp).text(responseData.mainInfo.startTime);
        webimJQuery('.startTs', rowWrp).text(responseData.mainInfo.startTs);
        if ('avgNTries' in responseData.mainInfo) {
            webimJQuery('.avgNTries', rowWrp).text(responseData.mainInfo.avgNTries);
            webimJQuery('.n', rowWrp).text(responseData.mainInfo.n);
            this.addTotalValue('n', responseData.mainInfo.n);
        }

        webimJQuery('a.turn_storager_on',rowWrp).click(function(e) {
            this.addTotalValue('turn_storager_on', -1);
            this.updateTolalRowValues();
            this.changeBackgroundStoragerStatus(tornado, 'true');
            e.preventDefault();
        }.bind(this));
        webimJQuery('a.turn_storager_off',rowWrp).click(function(e) {
            this.addTotalValue('turn_storager_on', 1);
            this.updateTolalRowValues();
            this.changeBackgroundStoragerStatus(tornado, 'false');
            e.preventDefault();
        }.bind(this));

        webimJQuery('a.turn_storager_' + (responseData.mainInfo.storingEnabled ? 'off' : 'on'), rowWrp).css('display', 'inline');
        if (!responseData.mainInfo.storingEnabled) {
            this.addTotalValue('turn_storager_on', 1);
        }

        wm.ajax.request(
            "/webim/service/monitor/tornado-monitor-proxy.php",
            {'port': tornado.port, 'host': tornado.host, 'subject': 'accounts-stat'},
            function(responseData) {
                if (responseData) {
                    this.onAccountStatsRequest(idx, responseData);
                } else {
                    this.postError('Account stats request for ' + tornado.host + ':' + tornado.port + ' failed');
                    this.requestMonitorForNextIdx(idx);
                }
            }.bind(this),
            function(responseData) {
                this.postError('Account stats request for ' + tornado.host + ':' + tornado.port + ' failed');
                this.requestMonitorForNextIdx(idx);
            }.bind(this),
            null, null,
            {type: 'GET'});
    },

    initCollectedToStoreObjectsLinks: function (row, tornado, accountName, num) {
        var postfix = num ? '_' + num : '';
        webimJQuery('.failed_to_store_objects_cnt' + postfix, row).click(this.createCollectedToStoreObjectsStatsLinkHandler(tornado, accountName, 'failed_to_store', num));
        webimJQuery('.collected_to_store_objects_cnt' + postfix, row).click(this.createCollectedToStoreObjectsStatsLinkHandler(tornado, accountName, 'collected_to_store', num));
        webimJQuery('.being_stored_now_objects_cnt' + postfix, row).click(this.createCollectedToStoreObjectsStatsLinkHandler(tornado, accountName, 'being_stored_now', num));
    },

    onAccountStatsRequest: function(idx, responseData) {
        this.requestMonitorForNextIdx(idx);

        var tornado = this.tornadoList[idx];
        tableUtils.fillTableWithData(webimJQuery('#accounts_stat tbody'), this.accountStatRowTemplate, responseData, {}, function (row, rowData) {
            webimJQuery('.host_link', row).text(tornado.host);
            webimJQuery('.env_link', row).text(tornado.env);
            webimJQuery('.port_link', row).text(tornado.port);
            webimJQuery('.host_link', row).attr('href', '#' + tornado.host);
            webimJQuery('.env_link', row).attr('href', '#' + tornado.host + ':' + tornado.env);
            webimJQuery('.port_link', row).attr('href', '#' + tornado.host + ':' + tornado.env + ':' + tornado.port);
            webimJQuery(row).addClass(tornado.host + '_' + tornado.env);
            webimJQuery(row).addClass(tornado.env);

            var accountName = rowData['name'];
            if (accountName != 'TOTAL') {
                if (accountName in bigAccounts) {
                    webimJQuery(row).addClass('big_account');
                }
                this.initCollectedToStoreObjectsLinks(row, tornado, accountName, 0);
                this.initCollectedToStoreObjectsLinks(row, tornado, accountName, 1);
                webimJQuery('.in_queue_cnt', row).click(this.getQueueMontitorDataClickHandler(tornado, accountName));
                var baseUrl = 'domain' in rowData ?
                    'http://' + rowData['domain'] :
                    'http://' + accountName + '.webim' + location.hostname.substring(location.hostname.lastIndexOf('.'));
                webimJQuery('.adm_link', row).attr('href', baseUrl);
                webimJQuery('.sp_link', row).attr('href', baseUrl + '/sample-page.php');
                webimJQuery('.site_link', row).attr('href', 'redirect-to-site.php?account-name=' + accountName);
                webimJQuery('.account_config_link', row).attr('href', baseUrl + '/service/account-config');
                webimJQuery('.tariff_editor_link', row).attr('href', baseUrl + '/l/a/tariff-editor');
                webimJQuery('.db_settings_link', row).attr('href', baseUrl + '/l/a/monitor/db-settings');
                webimJQuery('.location_settings_link', row).attr('href', baseUrl + '/service/location-settings');
                webimJQuery('.flush_link', row).attr('href', baseUrl + '/service/flush.php');
                webimJQuery('.php_info_link', row).attr('href', baseUrl + '/service/info.php');
                webimJQuery('.account_info_link', row).attr('href', '/webim/service/account-info.php?accountname=' + accountName);

                if ('not_belongs_to_tornado_instance' in rowData) {
                    var tdWrp = webimJQuery('.not_belongs_to_tornado_instance', row).parent();
                    var notBelongs = rowData['not_belongs_to_tornado_instance'];
                    if (notBelongs) {
                        tdWrp.css('background-color', 'orangered');
                    }
                    var ignoreNotBelongs = rowData['ignore_not_belongs_to_tornado_instance'];
                    if (ignoreNotBelongs) {
                        tdWrp.append(webimJQuery('<span> ignored <span/>'));
                    }
                    if (notBelongs || ignoreNotBelongs) {
                        tdWrp.append(webimJQuery('<a href="#"/>').text(ignoreNotBelongs ? 'not ignore' : 'ignore').click(function(e) {
                            this.setIgnoreNotBelongs(tornado, accountName, !ignoreNotBelongs);
                            e.preventDefault();
                        }.bind(this)));
                    }
                }
            } else {
                webimJQuery('a', row).removeAttr('href');
                webimJQuery(row).addClass('total');
                webimJQuery('.host_port', row).append(webimJQuery('<a/>').attr('name', tornado.host + '_' + tornado.port));
            }
        }.bind(this), {hideZeroValues: true});

        var totalRow = responseData[0];
        for (var fieldName in totalRow) {
            var value = totalRow[fieldName];
            var tdWrp = webimJQuery('.' + tornado.host + '_' + tornado.port + ' .' + fieldName);
            tdWrp.text(value != null && value != 0 ? value : '');
            this.addTotalValue(fieldName, value);
            if (fieldName == 'failed_to_store_objects_cnt' || fieldName == 'collected_to_store_objects_cnt') {
                tdWrp.append("<a href='#' class='store_now'> Store</a>");
                webimJQuery('.' + tornado.host + '_' + tornado.port + ' .' + fieldName + ' a.store_now').click(function(fieldName) { return function(e) {
                    this.storeNow(tornado, (fieldName == 'failed_to_store_objects_cnt' ? 'true' : 'false'));
                    e.preventDefault();
                }.bind(this)}.bind(this) (fieldName));
                if (fieldName == 'failed_to_store_objects_cnt' && value) {
                    tdWrp.css('background-color', 'orangered');
                }
            }
            if (fieldName == 'not_belongs_to_tornado_instance' && value) {
                tdWrp.css('background-color', 'orangered');
            }
        }
        var account_cnt = responseData.length - 1;
        webimJQuery('.' + tornado.host + '_' + tornado.port + ' .accounts_cnt').text(account_cnt);
        this.addTotalValue('accounts_cnt', account_cnt);
        this.updateTolalRowValues();
        this.fixColumns();
    },

    fixColumns: function() {
//      alert(1);
        var thsWrp = webimJQuery('#accounts_stat thead th');
        var tdsWrp = webimJQuery('#accounts_stat tbody tr:first-child td');
        for (var i = 0; i < thsWrp.length; i++) {
          var thWrp = webimJQuery(thsWrp.get(i));
          var tdWrp = webimJQuery(tdsWrp.get(i));
//          alert(i + ' ' + thWrp.width() + ' ' + tdWrp.width());
          if (thWrp.width() > tdWrp.width()) {
            tdWrp.width(thWrp.width());
          } else {
            thWrp.width(tdWrp.width());
          }
        }
    },

    addTotalValue: function (name, value) {
        this.totalValues[name] = (name in this.totalValues ? this.totalValues[name] : 0) + value
    },

    updateTolalRowValues: function () {
        for (var fieldName in this.totalValues) {
            var value = this.totalValues[fieldName];
            var totalWrp = webimJQuery('#tornados_info .total .' + fieldName);
            totalWrp.text(value != null && value != 0 ? value : '');
            if (fieldName == 'turn_storager_on' && value != 0) {
                webimJQuery('#tornados_info .total .' + fieldName).css('display', 'inline');
                webimJQuery('#tornados_info .total .' + fieldName).removeAttr('href');
            }
        }
    },

    createCollectedToStoreObjectsStatsLinkHandler: function(tornado, accountName, collectorName, num) {
        return function() {
            var content = this.collectedToStoreObjectsStatsDivTemplate.clone();
            webimJQuery('.account_name', content).text(accountName);
            this.request = wm.ajax.request(
                "/webim/service/monitor/tornado-monitor-proxy.php",
                {'port': tornado.port, 'host': tornado.host, 'subject': 'failed-to-store-objects',  // todo rename
                    'params': webimJQuery.toJSON({mode: 'stat', account_name: accountName, collector_name: collectorName, failed: collectorName == 'failed_to_store' ? '1' : '0', num: num})},
                function(responseData) {
                    tableUtils.fillTableWithData(webimJQuery('table tbody', content), this.collectedToStoreObjectsStatsRowTemplate, responseData, {}, function(row, rowData) {
                        webimJQuery('.cnt', row).click(this.createCollectedToStoreObjectsLinkHandler(tornado, accountName, rowData['class'], collectorName, num));
                    }.bind(this));
                }.bind(this),
                this.onRequestError.bind(this),
                null, null,
                {type: 'GET'});
            this.showPopup(content);
            return false;
        }.bind(this);
    },

    createCollectedToStoreObjectsLinkHandler: function(tornado, accountName, className, collectorName, num) {
        return function() {
            var content = this.collectedToStoreObjectsDivTemplate.clone();
            webimJQuery('.account_name', content).text(accountName);
            webimJQuery('.class_name', content).text(className);
            this.request = wm.ajax.request(
                "/webim/service/monitor/tornado-monitor-proxy.php",
                {'port': tornado.port, 'host': tornado.host, 'subject': 'failed-to-store-objects', // todo rename
                    'params': webimJQuery.toJSON({mode: 'objects', account_name: accountName, class_name: className, collector_name: collectorName, failed: collectorName == 'failed_to_store' ? '1' : '0', num:num})},
                function(responseData) {
                    for (var i in responseData) {
                        var tr = webimJQuery(document.createElement('tr'));
                        webimJQuery('table tbody', content).append(tr);
                        for (var j in responseData[i]) {
                            var td = webimJQuery(document.createElement('td'));
                            tr.append(td);
                            td.text(responseData[i][j]);
                        }
                    }
                }.bind(this),
                this.onRequestError.bind(this),
                null, null,
                {type: 'GET'});
            this.showPopup(content);
            return false;
        }.bind(this);
    },

    reloadTornadoForNextId: function(id, content) {
        if (id + 1 < this.tornadoList.length) {
            this.reloadTornado(id + 1, content);
        }
    },

    reloadTornado: function(id, content) {
        var tornado = this.tornadoList[id];
        this.__add_reload_output(content, 'Reloading ' + tornado.host + ':' + tornado.env + ':' + tornado.port);
        wm.ajax.request(
            "/webim/service/monitor/tornado-monitor-proxy.php",
            {'port': tornado.port, 'host': tornado.host, 'subject': 'reload'},
            function (responseData) {
                if (responseData.result == 'ok') {
                    this.__add_reload_output(content, 'ok');
                } else {
                    this.__add_reload_output(content, 'ERROR ######## ');
                }
                this.reloadTornadoForNextId(id, content);

            }.bind(this),
            function (responseData) {
                this.__add_reload_output(content, 'ERROR ######## ');
                this.reloadTornadoForNextId(id, content);
            }.bind(this),
            null, null,
            {type:'GET'});
    },

    __add_reload_output: function(content, text) {
        webimJQuery('table tbody', content).append(webimJQuery('<tr><td>' + text + '</td></tr>'));
    },

    getQueueMontitorDataClickHandler: function(tornado, accountName) {
        return function() {
            var content = this.queueMonitorDataDivTemplate.clone();
            webimJQuery('.account_name', content).text(accountName);
            this.request = wm.ajax.request(
                "/webim/service/monitor/tornado-monitor-proxy.php",
                {'port': tornado.port, 'host': tornado.host, 'subject': 'queue-data',
                    'params': webimJQuery.toJSON({type: 'monitor', account_name: accountName})},
                function(responseData) {
                    for (var i in responseData) {
                        var queue = responseData[i];
                        var tr = webimJQuery(document.createElement('tr'));
                        webimJQuery('table tbody', content).append(tr);
                        var tdId = webimJQuery(document.createElement('td'));
                        tr.append(tdId);
                        tdId.text((queue['queue_id'][0] ? queue['queue_id'][0] : 'NO_LANG')  +
                            ' - ' + (queue['queue_id'][1] ? queue['queue_id'][1] : 'NO_DEP') +
                            ' - ' + (queue['queue_id'][2] ? 'OFFLINE' : 'ONLINE'));
                        var tdInQueue = webimJQuery(document.createElement('td'));
                        tr.append(tdInQueue);
                        tdInQueue.text(queue['in_queue']);
                        var tdStatus = webimJQuery(document.createElement('td'));
                        tr.append(tdStatus);
                        tdStatus.text(queue['status']);


                    }
                }.bind(this),
                this.onRequestError.bind(this),
                null, null,
                {type: 'GET'});
            this.showPopup(content);
            return false;

        }.bind(this);
    },

    showPopup: function(content) {
        var popup = this.popupTemplate.clone();
        webimJQuery('.close_button', popup).click(function(e) {
            webimJQuery(e.target.parentNode).remove();
            e.preventDefault();
        });
        popup.append(content);
        webimJQuery('body').append(popup);
    },

    onRequestError: function() {
        //alert('some error');
    },

    reload: function(tornado) {
      if (confirm(tornado.host + ':' + tornado.port + ' reload\nThis action clears caches etc\nContinue?')) {
        wm.ajax.request(
            "/webim/service/monitor/tornado-monitor-proxy.php",
            {'port':tornado.port, 'host':tornado.host, 'subject':'reload'},
            function (responseData) {
              if (responseData.result == 'ok') {
                alert('Done');
              }
            }.bind(this),
            function (responseData) {
            }.bind(this),
            null, null,
            {type:'GET'});
      }
    },

    getTimersStatistics: function(tornado) {
        var content = this.timersStatsLastMinDivTemplate.clone();
        wm.ajax.request(
            "/webim/service/monitor/tornado-monitor-proxy.php",
            {'port':tornado.port, 'host':tornado.host, 'subject':'timer-stats'},
            function (responseData) {
                var lastMinRows = [];
                for (var i in responseData['last_min']) {
                    var lastMinRow = responseData['last_min'][i];
                    lastMinRow['name'] = i;
                    lastMinRow['max'] =  Math.max.apply(null, lastMinRow['execution_times']);

                    var sum = lastMinRow['execution_times'].reduce(function(a, b) { return a + b; });
                    lastMinRow['avg'] = sum / lastMinRow['count'];
                    lastMinRow['sum'] = sum;
                    lastMinRows.push(lastMinRow);
                }
                lastMinRows.sort(function(rowData1, rowData2){
                    if (rowData1['sum'] < rowData2['sum']) {
                        return 1;
                    }
                    if (rowData1['sum'] > rowData2['sum']) {
                        return -1;
                    }
                    return 0;
                });
                for (var i in lastMinRows) {
                    var lastMinRow = lastMinRows[i];
                    var row = tableUtils.createFilledTableRow( this.timersStatsLastMinRowTemplate, lastMinRow);
                    webimJQuery('table.last_min_timers tbody', content).append(row);
                }
                for (var i in responseData['failed']) {
                    responseData['failed'][i]['ts'] =webimTools.formatDate(responseData['failed'][i]['ts']) + ' ' + webimTools.formatTime(responseData['failed'][i]['ts']);
                    var row = tableUtils.createFilledTableRow( this.timersStatsFailedRowTemplate, responseData['failed'][i]);
                    webimJQuery('table.failed_timers tbody', content).append(row);
                }
            }.bind(this),
            function (responseData) {
            }.bind(this),
            null, null,
            {type:'GET'});
        this.showPopup(content);
    },

    changeBackgroundStoragerStatus: function(tornado, value) {
        if (confirm(tornado.host + ' - change storager status.\nContinue?')) {
            wm.ajax.request(
                "/webim/service/monitor/tornado-monitor-proxy.php",
                {'port':tornado.port, 'host':tornado.host, 'subject':'change-storager-status',
                    'params': webimJQuery.toJSON({value: value})},
                function (responseData) {
                    if (responseData.result == 'ok') {
                        webimJQuery('tr.' + tornado.host + '_' + tornado.port +' a.turn_storager_on').css('display', responseData.enabled ? 'none' : 'inline');
                        webimJQuery('tr.' + tornado.host + '_' + tornado.port +' a.turn_storager_off').css('display', responseData.enabled ? 'inline' : 'none');
                        alert('Done');
                    } else {
                        alert(responseData.message);
                    }
                }.bind(this),
                null, null, null,
                {type:'GET'});
        }
    },

    storeNow: function(tornado, failed) {
        if (confirm(tornado.host + ' - storing objects.\nContinue?')) {
            this.requestTornadoProxy(tornado, 'store-now', {failed: failed});
        }
    },

    setIgnoreNotBelongs: function(tornado, accountName, value) {
        this.requestTornadoProxy(tornado, 'set-ignore-not-belongs', {'account-name': accountName, 'value': '' + value});
    },

    requestTornadoProxy: function(tornado, subject, params) {
            wm.ajax.request(
                "/webim/service/monitor/tornado-monitor-proxy.php",
                {'port':tornado.port, 'host':tornado.host, 'subject':subject,
                    'params': webimJQuery.toJSON(params)},
                function (responseData) {
                    if (responseData.result == 'ok') {
                        alert('Done');
                    } else {
                        alert(responseData.message);
                    }
                }.bind(this),
                null,null, null,
                {type:'GET'});
    },

    postError: function(msg) {
        webimJQuery('#errors').append(webimJQuery('<div/>').text(msg));
    }
};


webimJQuery(document).ready(function() {
    monitor.init();
});
