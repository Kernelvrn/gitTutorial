idle = {
    idle: false,
    currentTs: new Date().getTime(),
    lastActionTs: new Date().getTime(),
//    overlay: null,
    timeout: 10000,
    lastMousePosition: {
        x: 0,
        y: 0
    },
    handlers: [],

    init: function(timeout) {
        this.timeout = timeout;

        webimJQuery(window).mousemove(_.throttle(this.mouseMoveHandler.bind(this), 200));

        webimJQuery(window).keypress(function() {
            this.lastActionTs = this.currentTs;
            this.setIdle(false);
        }.bind(this));

        webimJQuery(window).focus(this.onFocus.bind(this));

        webimJQuery(window).blur(this.onBlur.bind(this));

        setInterval(function() {
            this.currentTs += 1000;
            this.check();
        }.bind(this), 1000);

//        this.overlay = webimJQuery(document.createElement('div'));
//        this.overlay.css({
//            position: 'fixed',
//            top: 0,
//            bottom: 0,
//            left: 0,
//            right: 0,
//            'z-index': 1000000,
//            background: '#000000',
//            opacity: 0.5});
//        this.overlay.hide();
//        webimJQuery('body').append(this.overlay);
    },

    mouseMoveHandler: function (e) {
        if (this.lastMousePosition.x == e.pageX && this.lastMousePosition.y == e.pageY) {
            return
        }
        this.lastMousePosition.x = e.pageX;
        this.lastMousePosition.y = e.pageY;

        this.lastActionTs = this.currentTs;
        this.setIdle(false);
    },

    onFocus: function() {
        this.lastActionTs = this.currentTs;
        this.setIdle(false);
        webimJQuery(window).mousemove(_.throttle(this.mouseMoveHandler.bind(this), 200));
    },

    onBlur: function() {
        this.setIdle(true);
        webimJQuery(window).unbind('mousemove');
    },

    check: function() {
        if (!this.idle && this.currentTs > this.lastActionTs + this.timeout) {
            this.setIdle(true);
        }
    },

    setIdle: function(value) {
        if (this.idle == value) {
            return;
        }
        this.idle = value;
        if (value) {
//            this.overlay.stop().fadeIn(4000);
        } else {
//            this.overlay.stop().hide();
            this.onUnIdle();
        }
    },

    addHandler: function(h) {
        this.handlers.push(h);
    },

    onUnIdle: function() {
        for (var i = 0; i < this.handlers.length; i++) {
            var h = this.handlers[i];
            h();
        }
    }
};

