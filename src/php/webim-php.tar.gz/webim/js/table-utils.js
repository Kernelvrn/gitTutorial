tableUtils = {

    dateConverter: function(value) {
        return value ? new Date(value * 1000).format('dd.mm.yyyy') : null;
    },

    fillTableWithData: function(table, rowTemplate, data, fieldValueConverters, callbackForRow, settings) {
        for (var i in data) {
            var row = this.createFilledTableRow(rowTemplate, data[i], fieldValueConverters, callbackForRow, settings);
            table.append(row);
        }
    },

    createFilledTableRow: function(rowTemplate, rowData, fieldValueConverters, callbackForRow, settings) {
        if (!settings) {
            settings = {}
        }
        var row = rowTemplate.clone();
        for (var fieldName in rowData) {
            var value = rowData[fieldName];
            if (fieldValueConverters && fieldName in fieldValueConverters) {
                var converter = fieldValueConverters[fieldName];
                value = converter(value);
            }
            if (settings.hideZeroValues && value == 0) {
                value = null;
            }
            webimJQuery('.' + fieldName, row).text(value != null ? value : '');
        }
        if (callbackForRow) {
            callbackForRow(row, rowData);
        }
        return row;
    }
};
