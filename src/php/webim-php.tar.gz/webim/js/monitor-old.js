
wm = {};

monitor = {
    host: '',
    accountStatRowTemplate: null,

    init: function() {
        wm.ajax.request(
            "/l/a/monitor", {},
            this.onMonitorRequest.bind(this),
            this.onRequestError.bind(this),
            null, null,
            {type: 'GET'});
        wm.ajax.request(
            "/l/a/monitor/accounts-stat", {},
            this.onAccountStatsRequest.bind(this),
            this.onRequestError.bind(this),
            null, null,
            {type: 'GET'});

        this.popupTemplate = webimJQuery('.popup').remove();
        this.accountStatRowTemplate = webimJQuery('#accounts_stat tbody tr').remove();
        this.failedToStoreObjectsStatsRowTemplate = webimJQuery('.failed_to_store_objects_stats table tbody tr').remove();
        this.failedToStoreObjectsStatsDivTemplate = webimJQuery('.failed_to_store_objects_stats').remove();
        this.failedToStoreObjectsDivTemplate = webimJQuery('.failed_to_store_objects').remove();
    },

    onMonitorRequest: function(responseData) {
        this.host = responseData.host;
        webimJQuery('#service_info_frame').attr('src', 'http://' + responseData.host + '/webim/service/info.php');
        for (var fieldName in responseData.mainInfo) {
            webimJQuery('#main_info .' + fieldName).text(responseData.mainInfo[fieldName]);
        }
    },

    onAccountStatsRequest: function(responseData) {
        tableUtils.fillTableWithData(webimJQuery('#accounts_stat tbody'), this.accountStatRowTemplate, responseData, {}, function(row, rowData) {
            var accountName = rowData['name'];
            if (accountName != 'TOTAL') {
                webimJQuery('.failed_to_store_objects_cnt', row).click(this.createFailedToStoreObjectsStatsLinkHandler(accountName));
                var baseUrl = 'http://' + accountName + this.host.substring(this.host.indexOf('.')) + '/webim';
                webimJQuery('.adm_link', row).attr('href', baseUrl);
                webimJQuery('.sp_link', row).attr('href', 'sample-page.php?account=' + accountName);
                webimJQuery('.site_link', row).attr('href', baseUrl + '/service/monitor/redirect-to-site.php');
            } else {
                webimJQuery('a', row).removeAttr('href');
            }
        }.bind(this));
    },

    createFailedToStoreObjectsStatsLinkHandler: function(accountName) {
        return function() {
            var content = this.failedToStoreObjectsStatsDivTemplate.clone();
            webimJQuery('.account_name', content).text(accountName);
            this.request = wm.ajax.request(
                "/l/a/monitor/failed-to-store-objects", {mode: 'stat', account_name: accountName},
                function(responseData) {
                    tableUtils.fillTableWithData(webimJQuery('table tbody', content), this.failedToStoreObjectsStatsRowTemplate, responseData, {}, function(row, rowData) {
                        webimJQuery('.cnt', row).click(this.createFailedToStoreObjectsLinkHandler(accountName, rowData['class']));
                    }.bind(this));
                }.bind(this),
                this.onRequestError.bind(this),
                null, null,
                {type: 'GET'});
            this.showPopup(content);
            return false;
        }.bind(this);
    },

    createFailedToStoreObjectsLinkHandler: function(accountName, className) {
        return function() {
            var content = this.failedToStoreObjectsDivTemplate.clone();
            webimJQuery('.account_name', content).text(accountName);
            webimJQuery('.class_name', content).text(className);
            this.request = wm.ajax.request(
                "/l/a/monitor/failed-to-store-objects", {mode: 'objects', account_name: accountName, class_name: className},
                function(responseData) {
                    for (var i in responseData) {
                        var tr = webimJQuery(document.createElement('tr'));
                        webimJQuery('table tbody', content).append(tr);
                        for (var j in responseData[i]) {
                            var td = webimJQuery(document.createElement('td'));
                            tr.append(td);
                            td.text(responseData[i][j]);
                        }
                    }
                }.bind(this),
                this.onRequestError.bind(this),
                null, null,
                {type: 'GET'});
            this.showPopup(content);
            return false;
        }.bind(this);
    },

    showPopup: function(content) {
        var popup = this.popupTemplate.clone();
        webimJQuery('.close_button', popup).click(function(e) {
            webimJQuery(e.target.parentNode).remove();
            e.preventDefault();
        });
        popup.append(content);
        webimJQuery('body').append(popup);
    },

    onRequestError: function() {
        alert('some error');
    }
};


webimJQuery(document).ready(function() {
    monitor.init();
});
