operatorsList = {

    init: function() {
        this.reset();
        this.update();
    },

    update: function() {
        wm.ajax.request("/l/o/get-operator-statuses", {},
            function(operatorIdToStatus) {
                if (operatorIdToStatus) {
                    for (var operatorId in operatorIdToStatus) if (operatorIdToStatus.hasOwnProperty(operatorId)) {
                        this.updateStatusForOperator(operatorId, operatorIdToStatus[operatorId]);
                    }
                }
            }.bind(this),
            function() {
                setTimeout(this.init.bind(this), onlineSupport.afterErrorTimeout);
            }.bind(this),
            null,null,
            {type: 'GET'});

    },

    reset: function() {
        webimJQuery('.operator-item').each(function(i, e) {
            webimJQuery('.operator-status span',e).removeClass().addClass('loading');
            webimJQuery('.operator-name-and-text-status .operator-text-status',e).text();
        })
    },

    updateStatusForOperator: function(operatorId, status) {
        var wrp = webimJQuery('.operator-' + operatorId);
        wrp.removeClass('status-offline').removeClass('status-online').addClass('status-' + (status == 'offline' ? 'offline': 'online'));
        webimJQuery('.operator-status span', wrp).removeClass().addClass(status != 'offline' && status != 'online' ? 'other' : status).attr('title', resources.operator_status[status]);
        webimJQuery('.operator-name-and-text-status .operator-text-status',wrp).text(resources.operator_status[status]);
        webimJQuery('button[data-action="switch-off-operator"]', wrp).attr('disabled', status == 'offline');
    }

};

webimJQuery(document).ready(function() {
    if (webimJQuery('table.operators-list').length > 0) {
        operatorsList.init();
    }
});

