hostedOrderedService = {

    keyToTariff: null,
    rowTemplate: null,

    fieldValueConverters: {
        dtmfrom: tableUtils.dateConverter,
        dtmto: tableUtils.dateConverter
    },

    callbackForRow: function(row, data) {
        row.addClass('status_'+ data['status']);
        webimJQuery('.status', row).text(orderedServiceStatus[data['status']]);
        webimJQuery('.tariff', row).text(this.keyToTariff[data.tariffkey].descriptor.name);
        webimJQuery('.operators_cnt', row).text(this.getOperatorsCnt(data));
    },

    init: function() {
        this.loadTariffs();
        this.rowTemplate = webimJQuery('#ordered_services tbody tr').remove();

        webimJQuery('#activate-license-button').click(function(){
            webimJQuery.ajax({
                url: "/l/o/ordered-service.php",
                type: 'POST',
                dataType: 'json',
                data: {
                    action: 'apply_license_key',
                    'key': webimJQuery('#license-key-input').val()
                },
                success: function (responseData) {
                    var result = responseData['result'];
                    if (result === 'error') {
                        webimJQuery('#license-key-input').css({'border-color': '#b71c1c', 'color': '#b71c1c'});
                        this.showErrorMessage(responseData['msg']);
                    } else if (result === 'ok') {
                        webimJQuery('#license-key-input').css({'border-color': '#3c763d', 'color': '#3c763d'});
                        this.hideErrorMessage();
                        this.reloadList();
                    }
                }.bind(this),
                error: this.onRequestError
            });
        }.bind(this));
    },

    showErrorMessage: function(msg) {
        webimJQuery('#license-key-err-msg').text(msg);
        if (!webimJQuery('#license-key-err-msg').is(':visible')){
            webimJQuery('#license-key-err-msg').fadeIn();
        }
    },

    hideErrorMessage: function() {
        if (webimJQuery('#license-key-err-msg').is(':visible')){
            webimJQuery('#license-key-err-msg').fadeOut();
        }
    },

    loadTariffs: function() {
        wm.ajax.request(
            "/l/o/ordered-service.php",
            {action: 'get_tariffs'},
            function(responseData) {
                this.keyToTariff = responseData.keyToTariff;
                this.discounts = responseData.discounts;
                this.reloadList();
            }.bind(this),
            this.onRequestError.bind(this),
            null, null,
            {type: 'GET'});
    },

    reloadList: function() {
        wm.ajax.request(
            "/l/o/ordered-service.php",
            {action: 'list'},
            this.onListRequest.bind(this),
            this.onRequestError.bind(this),
            null, null,
            {type: 'GET'});
    },

    onListRequest: function(responseData) {
        var tbodyWrapper = webimJQuery('#ordered_services tbody');
        tbodyWrapper.html('');
        tableUtils.fillTableWithData(
            tbodyWrapper,
            this.rowTemplate,
            responseData['orderedServices'],
            this.fieldValueConverters,
            this.callbackForRow.bind(this)
        );
    },

    getOperatorsCnt: function(os) {
        var settings = webimJQuery.evalJSON(os.settings);
        var tariff = this.keyToTariff[os.tariffkey];
        return 'online_operators_limit' in settings ? settings['online_operators_limit'] : tariff.settings.online_operators_limit;
    },

    onRequestError: function() {
        alert(resources.alert.server_error);
    }
};


webimJQuery(document).ready(function() {
    hostedOrderedService.init();
});

