alerts = {

    alertWrp: null,

    init: function() {
        this.alertWrp = webimJQuery('.webim-js-alert-container');
    },

    show: function (settings) {
        this.reset();

        if (settings) {
            for (var settingKey in settings) if (settings.hasOwnProperty(settingKey)) {
                switch (settingKey) {
                    case 'message':
                        webimJQuery('.webim-js-alert-message', this.alertWrp).text(settings[settingKey]);
                        break;
                    case 'header':
                        webimJQuery('.webim-js-alert-header', this.alertWrp).text(settings[settingKey]);
                        webimJQuery('.webim-js-alert-header', this.alertWrp).show();
                        break;
                    case 'buttons':
                        for (var i in settings[settingKey]) if (settings[settingKey].hasOwnProperty(i)) {
                            var buttonSettings = settings[settingKey][i];
                            var buttonSelector = webimJQuery('.webim-js-alert-' + buttonSettings['type'], this.alertWrp);

                            if (buttonSettings['text']) {
                                buttonSelector.text(buttonSettings['text']);
                            }

                            var createOnClickHandler = function (handler) {
                                return function () {
                                    if (typeof handler == 'function') {
                                        handler();
                                    }
                                    this.alertWrp.fadeOut(400);
                                    return false;
                                }.bind(this);
                            }.bind(this);

                            buttonSelector.click(createOnClickHandler(buttonSettings['handler']));
                            buttonSelector.show();
                        }
                        break;
                }
            }
            this.alertWrp.fadeIn();
        }
    },

    reset: function() {
        webimJQuery('.webim-js-alert-message', this.alertWrp).text('');
        webimJQuery('.webim-js-alert-header', this.alertWrp).text('');
        webimJQuery('.webim-js-alert-header', this.alertWrp).hide();
        webimJQuery('.alert-buttons .button', this.alertWrp).each(function(i, e) {
            webimJQuery(e).unbind('click');
        });
    },

    isShown: function() {
      return this.alertWrp.css('display') == 'block';
    },

    hide: function () {
        webimJQuery('.webim-js-alert-container').fadeOut(400);
    },

    showSimpleAlert: function (message) {
        var settings = {
            message: message,
            buttons: [
                {type: 'ok'}
            ]
        };
        this.show(settings);
    },

    showSimpleConfirm: function (message, onOkHandler, onCancelHandler) {
        var settings = {
            message: message,
            buttons: [
                {type: 'ok', handler: onOkHandler},
                {type: 'cancel', handler: onCancelHandler}
            ]
        };
        this.show(settings);
    }
};

webimJQuery(document).ready(function() {
    try {
        alerts.init();
    } catch(e) {
        webimTools.handleException(e);
    }
});