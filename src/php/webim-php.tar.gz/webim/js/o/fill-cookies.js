//var p = webimTools.getUrlParam('pp');
//p = p ? p : webimTools.getUrlParam('p');
//p = p ? p : 'webim';
//webimJQuery.cookie('WEBIM_P', p, { expires: 365, path: '/', domain: 'webim.ru' });

if (document.referrer.length > 0 && !webimJQuery.cookie('WEBIM_REFERAL')) {
  webimJQuery.cookie('WEBIM_REFERAL', document.referrer, { expires: 365, path: '/', domain: 'webim.ru' });
}
if (!webimJQuery.cookie('WEBIM_LANDING')) {
  webimJQuery.cookie('WEBIM_LANDING', document.location.href, { expires: 365, path: '/', domain: 'webim.ru' });
}                                  

