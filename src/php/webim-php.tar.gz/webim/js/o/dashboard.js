dashboard = {
    url: '/l/o/current-stats.php',
    dashboardWrp: null,
    updateInterval: null,

    init: function() {
        this.dashboardWrp = jQuery('[data-type="dashboard"]');
        if (!this.dashboardWrp.size()) {
            return false;
        }

        this.realtime = {
            realtime: true,
            data: null,
            updateInterval: wm.accountConfig['dashboard_realtime_update_interval'] * 1000
        };
        this.prevIntervals = {
            realtime: false,
            data: null,
            updateInterval: wm.accountConfig['dashboard_prev_periods_update_interval'] * 1000
        };

        this.update(this.realtime);
        this.update(this.prevIntervals);
    },

    update: function(statsPart) {
        if (!this.dashboardWrp.size()) {
            return false;
        }
        jQuery('.dashboard-throbber').show();
        jQuery.getJSON(
            this.url + '?realtime=' + statsPart.realtime,
            jQuery.proxy(function(data, status) {
                var doNextUpdate = true;

                if (data.error) {
                    switch (data.error) {
                        case 'unauthorized':
                            onlineSupport.redirectToLoginPage();
                            return;

                        case 'no-tariff-option':
                            data = jQuery('.dashboard-upsale-container').length ? data['dummy'] : {} ;
                            doNextUpdate = false;
                    }
                }

                if (status == 'success') {
                    statsPart.data = data;
                    if ('update_interval' in data) {
                        statsPart.updateInterval = data['update_interval'] * 1000;
                    }
                    this.mergeAndUpdateView();
                }

                if (doNextUpdate) {
                    this.setNextUpdateTimeout(statsPart);
                }
            }, this)
        ).error(function() {
            dashboard.setNextUpdateTimeout(statsPart);
        });
    },

    setNextUpdateTimeout: function (statsPart) {
        setTimeout(jQuery.proxy(function(){this.update(statsPart)}, this), statsPart.updateInterval);
    },

    mergeAndUpdateView: function() {
        if (!this.realtime.data || !this.prevIntervals.data) {
            return;
        }
        var data = {};
        webimJQuery.extend(true, data, this.prevIntervals.data, this.realtime.data);
        this.updateView(data)
    },

    updateView: function(data) {
        for (var block in data) {
            for (var field in data[block]) {
                var value = data[block][field];
                if(field == 'avg_answer_time') {
                    value = webimTools.formatTimeInterval(value);
                }
                this.dashboardWrp.find('[data-type="' + block + '-' + field +'"]').text(value);
            }
        }
        var chatsByDepartmentTableBodyWrp = this.dashboardWrp.find('[data-type="chats-by-department"] tbody');
        chatsByDepartmentTableBodyWrp.empty();
        for (var i in data['chatsByDepartment']) {
            var rowData = data['chatsByDepartment'][i];
            var rowWrp = jQuery('<tr>')
                .append(jQuery('<td class="row-label">').text(rowData.department.name))
                .append(jQuery('<td class="colgroup-first-col">').text(rowData.online.in_process))
                .append(jQuery('<td>').text(rowData.online.waiting).css('color', rowData.online.waiting >= 100 ? 'red' : '#333'))
                .append(jQuery('<td class="colgroup-last-col">').text(webimTools.formatTimeInterval(rowData.online.max_waiting_time)))
                .append(jQuery('<td class="colgroup-first-col">').text(rowData.offline.waiting).css('color', rowData.offline.waiting >= 100 ? 'red' : '#333'))
                .append(jQuery('<td class="colgroup-last-col">').text(webimTools.formatTimeInterval(rowData.offline.max_waiting_time)));
            chatsByDepartmentTableBodyWrp.append(rowWrp);
        }

        var chatsByOperatorTableBodyWrp = this.dashboardWrp.find('[data-type="chats-by-operator"] tbody');
        chatsByOperatorTableBodyWrp.empty();

        for (var departmentKey in data['chatsByOperator']) if (data['chatsByOperator'].hasOwnProperty(departmentKey)) {
            var departmentName = data['chatsByOperator'][departmentKey]['departmentName'];

            var depRowWrp = jQuery('<tr data-type="department-' + departmentKey + '">')
                .append(jQuery('<td colspan="4" class="text-center">').text(departmentName));
            chatsByOperatorTableBodyWrp.append(depRowWrp);

            var operators = data['chatsByOperator'][departmentKey]['operators'];

            for (var operatorId in operators) if (operators.hasOwnProperty(operatorId)) {
                var operator = operators[operatorId];
                var rowWrp = jQuery('<tr>')
                    .append(jQuery('<td class="row-label dashboard-operator">').text(operator.fullname + ' (' + resources.operator_status[operator.status] + (operator.ts_diff_in_current_status ? ' ' + webimTools.formatTimeInterval(operator.ts_diff_in_current_status): '') +')')
                        .addClass('dashboard-operator-status-' + (operator.status ? operator.status : '')))
                    .append(jQuery('<td>').text(operator.threads_now))
                    .append(jQuery('<td>').text(operator.threads_hour))
                    .append(jQuery('<td>').text(operator.avg_answer_time ? webimTools.formatTimeInterval(operator.avg_answer_time) : ''));
                    jQuery(chatsByOperatorTableBodyWrp).append(rowWrp);
            }
        }
        this.dashboardWrp.find('[data-type="chats-by-operator"]').parent().css('display', jQuery('tr', chatsByOperatorTableBodyWrp).length == 0 ? 'none' : 'block');

        var operatorStatsTableBodyWrp = this.dashboardWrp.find('[data-type="extended-operators"] tbody');
        operatorStatsTableBodyWrp.empty();
        if ('operator_extended' in data) {
            for (var i in data['operator_extended']) {
                var rowData = data['operator_extended'][i];
                var rowWrp = jQuery('<tr>')
                    .append(jQuery('<td class="row-label dashboard-operator-name">')
                        .text(rowData.fullname + ' (' + resources.operator_status[rowData.status] + ')')
                        .addClass('dashboard-operator-status-' + (rowData.status ? rowData.status : 'offline')))
                    .append(jQuery('<td>').text(rowData.thread_count))
                    .append(jQuery('<td>').text(rowData.message_count))
                    .append(jQuery('<td>').text(rowData.time_in_system ? webimTools.formatTimeInterval(rowData.time_in_system) : ''))
                    .append(jQuery('<td>').text(rowData.ready_time ? webimTools.formatTimeInterval(rowData.ready_time) : ''))
                    .append(jQuery('<td>').text(rowData.not_ready_time ? webimTools.formatTimeInterval(rowData.not_ready_time) : ''))
                    .append(jQuery('<td>').text(rowData.last_state_time ? webimTools.formatTimeInterval(rowData.last_state_time) : ''))
                    .append(jQuery('<td>').text(rowData.last_login_ts ? webimTools.formatTime(rowData.last_login_ts) : ''))
                    .append(jQuery('<td>').text(rowData.last_logout_ts ? webimTools.formatTime(rowData.last_logout_ts) : ''))
                operatorStatsTableBodyWrp.append(rowWrp);
            }
        }

        var departmentStatsTableBodyWrp = this.dashboardWrp.find('[data-type="extended-departments"] tbody');
        departmentStatsTableBodyWrp.empty();
        if ('department_extended' in data) {
            var departments = data['department_extended']['departments'];
            for (var i in departments) {
                var rowData = departments[i];
                var rowWrp = jQuery('<tr>')
                    .append(jQuery('<td class="row-label">').text(rowData.department_name))
                    .append(jQuery('<td>').text(rowData.thread_count))
                    .append(jQuery('<td>').text(rowData.chat_count))
                    .append(jQuery('<td>').text(rowData.missed_count))
                    .append(jQuery('<td>').text(rowData.bounce_5s_count))
                    .append(jQuery('<td>').text(rowData.not_bounce_5s_count))
                    .append(jQuery('<td>').text(rowData.avg_common_queue_waiting_time ? webimTools.formatTimeInterval(rowData.avg_common_queue_waiting_time) : ''));

                departmentStatsTableBodyWrp.append(rowWrp);
            }

            rowData = data['department_extended']['total'];
            rowWrp = jQuery('<tr>')
                .append(jQuery('<td class="row-label">').text(rowData.department_name))
                .append(jQuery('<td>').text(rowData.thread_count))
                .append(jQuery('<td>').text(rowData.chat_count))
                .append(jQuery('<td>').text(rowData.missed_count))
                .append(jQuery('<td>').text(rowData.bounce_5s_count))
                .append(jQuery('<td>').text(rowData.not_bounce_5s_count))
                .append(jQuery('<td>').text(rowData.avg_common_queue_waiting_time ? webimTools.formatTimeInterval(rowData.avg_common_queue_waiting_time) : ''));

            departmentStatsTableBodyWrp.append(rowWrp);
        }

        jQuery('.dashboard-throbber').hide();
        var currentDate = new Date();
        jQuery('.dashboard-status-text').text(" " + resources.dashboard.last_update + ' ' + webimTools.pad(currentDate.getHours()) + ":" + webimTools.pad(currentDate.getMinutes()) + ":" + webimTools.pad(currentDate.getSeconds()));
    }
};

jQuery(function() {
   dashboard.init();
});
