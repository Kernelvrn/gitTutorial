moneyTransfer = {
    partnerDiscount: null,
    accountMoneyAmount: null,

    init: function() {
        this.partnerDiscount = parseFloat(webimJQuery('#partner_discount').text());
        this.accountMoneyAmount = parseFloat(webimJQuery('#account_money_amount').text());
        webimJQuery('input.balance-transfer[type="text"]').keypress(function(event) {
            var key = event.charCode;
            if (key > 31 && (key < 48 || key > 57)) {
                return false;
            }
            setTimeout(function() {
                var clientId = parseInt(webimJQuery(this).parents('form').attr('name').substr('balance_transfer_'.length));
                var transferMoneyAmount = parseInt(webimJQuery(this).val() ?  webimJQuery(this).val() : '0');
                webimJQuery('#balance_helper_' + clientId + ' .transfer_money_amount').html((transferMoneyAmount * moneyTransfer.partnerDiscount).toFixed(2)).parent().show();
            }.bind(this), 100);
            return true;
        });

        webimJQuery('input.balance-transfer[type="button"]').click(function(event) {
            var value = webimJQuery(this).parents('form').find('input.balance-transfer[type="text"]').val();
            var transferMoneyAmount = parseInt( value ?  value : '0');
            if (transferMoneyAmount * moneyTransfer.partnerDiscount <= moneyTransfer.accountMoneyAmount) {
                webimJQuery(this).parents('form').submit();
            } else {
                alert(resources.alert.need_more_gold);
            }
        });
    }
}

webimJQuery(document).ready(function() {
    moneyTransfer.init();
});