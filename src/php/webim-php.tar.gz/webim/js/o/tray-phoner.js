/**
 * Tray sip-api wrapper. Update info-box, show confirm on incoming, etc.
 */
trayPhoner = {

    init: function() {
        this.refreshStatus();
        this.initUI();
    },

    getStatus: function() {
        return this.processStatus();
    },

    isEnable: function() {
        return typeof window.webimTray.loginToSipServer !== 'undefined';
    },

    processStatus: function(statusFromSip) {
        var status = {
            status: null
        }
        if (!this.isEnable()) {
            status.status = 'not-support';
        } else {
            if(!statusFromSip) {
                var statusJSON = window.webimTray.getSipStatus();
                status = webimJQuery.parseJSON(statusJSON);
            } else {
                status = statusFromSip;
            }
            switch (status.status.toLowerCase()) {
                case '':
                    status.status = 'offline';
                    break;
                case 'free':
                    status.status = 'idle';
                    break;
            }
        }
        return status;
    },

    refreshStatus: function(statusFromSip) {
        var phonerBoxWrp = webimJQuery('.webim-js-phoner');
        if (!statusFromSip) {
            var status = this.getStatus();
        } else {
            var status = this.processStatus(statusFromSip);
        }
        phonerBoxWrp
            .children().hide()
                .filter('.webim-js-' + status.status).show();
        switch (status.status) {
            case 'ringing':
                phonerBoxWrp.find('.webim-js-' + status.status + ' .webim-js-description').html(webimTools.escapeHtml(webimTools.parseResource(resources.phoner.incoming.message, {name: status.caller.name})));
                break;
            case 'talking':
                phonerBoxWrp.find('.webim-js-' + status.status + ' .webim-js-description').html(webimTools.escapeHtml(webimTools.parseResource(resources.phoner.talking.message, {name: status.caller.name})));
                break;
        }
    },

    login: function() {
        var status = this.getStatus();
        if (status.status == 'offline') {
            window.webimTray.loginToSipServer(phonerLoginObject.outboundProxy, phonerLoginObject.port, phonerLoginObject.authenticationName, phonerLoginObject.password);
        }
        setTimeout(this.refreshStatus.bind(this), 500);
    },

    logout: function() {
        var status = this.getStatus();
        if (status.status != 'offline' && status.status != 'not-support') {
            window.webimTray.logoutFromSipServer();
        }
    },

    initUI: function() {
        var phonerBoxWrp = webimJQuery('.webim-js-phoner');
        phonerBoxWrp.find('.webim-js-answer').click(function() {
            window.webimTray.acceptIncomingCall();
            if (typeof visitorListUI != 'undefined') {
                var status = this.getStatus();
                visitorListUI.selectSessionById(this.caller.callerId);
            }
            return false;
        }.bind(this));
        phonerBoxWrp.find('.webim-js-hangup').click(function() {
            window.webimTray.declineIncomingCall();
            return false;
        });
    }
};

/**
 * Handlers using by tray on SIP events.
 */
var invokeFromTray = {
    onIncomingCall: function(status) {
        trayPhoner.refreshStatus(status);
        if (window.location.href.toLocaleLowerCase().indexOf('/tracker.php') == -1) {
            if (confirm(webimTools.parseResource(resources.phoner.incoming.message, {name: status.caller.name}))) {
                window.webimTray.acceptIncomingCall();
            } else {
                window.webimTray.declineIncomingCall();
            }
        }
    },
    onAcceptCall: function(status) {
        window.location.href = '/webim/operator/tracker.php#' + status.caller.callerId;
        trayPhoner.refreshStatus(status);
    },
    onHangupCall: function(status) {
        trayPhoner.refreshStatus(status);
    },
    onSipConnected: function(status) {
        trayPhoner.refreshStatus(status);
    },
    onSipDisconnected: function(status) {
        trayPhoner.refreshStatus(status);
    }
}
