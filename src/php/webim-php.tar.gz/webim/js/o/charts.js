webimCharts = {
    charts: [],
    colors: [
        '#0065a9', '#63a634', '#f02f2f',
        '#FF6600', '#FF9E01',
        '#FCD202', '#F8FF01', '#B0DE09',
        '#04D215', '#0D8ECF', '#0D52D1',
        '#2A0CD0', '#8A0CCF', '#CD0D74',
        '#754DEB', '#DDDDDD', '#999999',
        '#333333', '#000000', '#57032A',
        '#CA9726', '#990000', '#4B0C25'
    ],
    lang: wm.currentLocale == 'ru' ? 'ru' : 'en',
    chartBaseConfigs: {
        'pie': {
            'type': 'pie',
            'titleField': 'label',
            'valueField': 'data',
            'radius': '35%',
            'startDuration': 0,
            'groupedTitle': resources['charts']['chart']['other'],
            'legend': {
                'useGraphSettings': true,
                'valueWidth': 40,
                'markerBorderThickness': 5
            }
        },
        'serial': {
            'type': 'serial',
            'theme': 'none',
            'legend': {
                'useGraphSettings': true,
                'valueWidth': 40,
                'markerBorderThickness': 5
            },
            'valueAxes': [
                {
                    'gridColor': '#FFFFFF',
                    'gridAlpha': 0.2,
                    'dashLength': 0
                }
            ],
            'gridAboveGraphs': true,
            'startDuration': 0,
            'graphs': [
                {
                    'balloonText': '[[title]]: <b>[[value]]</b>',
                    'lineAlpha': 1,
                    'lineThickness': 3
                }
            ],
            'chartCursor': {
                'categoryBalloonEnabled': false,
                'cursorAlpha': 0,
                'zoomable': true
            },
            'categoryAxis': {
                'gridPosition': 'start',
                'gridAlpha': 0,
                'tickPosition': 'start',
                'tickLength': 20
            }
        }
    },
    chartSpecificConfigs: {
        'categories': {
            'type': 'pie',
            'report2dataConverter': function (report) {
                var data = report['data'];
                var result = [];
                var total = 0;

                for (var k in data) {
                    if (parseFloat(data[k]['requestCount']['value']) != 0) {
                        var label = data[k]['category']['value'] ? data[k]['category']['value'] : resources['charts']['categories']['no_category'];
                        if (data[k]['subcategory']['value']) {
                            label += ' [' + data[k]['subcategory']['value'] + ']';
                        }
                        result.push({
                            data: parseFloat(data[k]['requestCount']['value']),
                            label: label
                        });
                        total += parseFloat(data[k]['requestCount']['value']);
                    }
                }

                result.sort(webimCharts.sortPieData);
                var percent = 0;
                if (result.length > 10) {
                    var last = result[10]['data'];
                    percent = last / total * 100;
                }

                return result.length ? {data: result, percent: percent} : null;
            }
        },
        'geo': {
            'type': 'pie',
            'country': 'Россия',
            'report2dataConverter': function (report) {
                var data = report['data'];
                var result = [];
                var total = 0;


                for (var k in data) {
                    if (data[k]['country']['value'] == this.country && data[k]['region']['value']) {
                        result.push({
                            label: data[k]['region']['value'],
                            data: data[k]['requestCount']['value']
                        });
                        total += data[k]['requestCount']['value'];
                    }
                }

                result.sort(this.sortPieData);

                var percent = 0;
                if (result.length > 10) {
                    var last = result[10]['data'];
                    percent = last / total * 100;
                }


                return result.length ? {data: result, percent: percent} : null;
            }
        },
        'departments_online': {
            'type': 'pie',
            'report2dataConverter': function (report) {
                var data = report['data'];
                var result = [];
                var total = 0;

                for (var k in data) {
                    if (parseFloat(data[k]['requestCount']['value']) != 0) {
                        result.push({
                            data: parseFloat(data[k]['requestCount']['value']),
                            label: data[k]['department']['value']['name'] ? data[k]['department']['value']['name'] : resources['charts']['departments'].no_department
                        });
                        total += parseFloat(data[k]['requestCount']['value']);
                    }

                }

                result.sort(this.sortPieData);

                var percent = 0;
                if (result.length > 10) {
                    var last = result[10]['data'];
                    percent = last / total * 100;
                }

                return result.length ? {data: result, percent: percent} : null;
            }
        },
        'offices_online': {
            'type': 'pie',
            'report2dataConverter': function (report) {
                var data = report['data'];
                var result = [];
                var total = 0;

                for (var k in data) {
                    if (parseFloat(data[k]['closedCount']['value']) != 0) {
                        result.push({
                            data: parseFloat(data[k]['closedCount']['value']),
                            label: data[k]['office']['value']['name'] ? data[k]['office']['value']['name'] : resources['charts']['offices']['no_office']
                        });
                        total += parseFloat(data[k]['closedCount']['value']);
                    }

                }

                result.sort(this.sortPieData);

                var percent = 0;
                if (result.length > 10) {
                    var last = result[10]['data'];
                    percent = last / total * 100;
                }

                return result.length ? {data: result, percent: percent} : null;
            }
        },
        'dates_online': {
            'type': 'serial',
            'fields': [
                {'title': resources['charts']['chart']['requests'], 'valueField': 'requestCount'},
                {'title': resources['charts']['chart']['new_requests'], 'valueField': 'newRequestCount'},
                {'title': resources['charts']['chart']['chats'], 'valueField': 'chatCount'},
                {'title': resources['charts']['chart']['missed'], 'valueField': 'missedCount'}
            ],
            config: {
                'categoryField': 'date'
            },
            'report2dataConverter': function (report) {
                return webimCharts.datesReportToDataConverter(report, this.fields);
            }
        },
        'dates_offline': {
            'type': 'serial',
            'fields': [
                {'title': resources['charts']['chart']['new_offlines_queue'], 'valueField': 'newOfflineQueueCount'},
                {'title': resources['charts']['chart']['new_offlines_operator'], 'valueField': 'newOfflineOperatorCount'},
                {'title': resources['charts']['chart']['closed_offline'], 'valueField': 'closedOfflineCount'}
            ],
            config: {
                'categoryField': 'date'
            },
            'report2dataConverter': function (report) {
                return webimCharts.datesReportToDataConverter(report, this.fields);
            }
        },
        'hours_online': {
            'type': 'serial',
            'fields': [
                {'title': resources['charts']['chart']['requests'], 'valueField': 'requestCount'},
                {'title': resources['charts']['chart']['new_requests'], 'valueField': 'newRequestCount'},
                {'title': resources['charts']['chart']['chats'], 'valueField': 'chatCount'},
                {'title': resources['charts']['chart']['missed'], 'valueField': 'missedCount'}
            ],
            config: {
                'categoryField': 'hour'
            },
            'report2dataConverter': function (report) {
                return webimCharts.hoursReportToDataConverter(report, this.fields);
            }
        },
        'hours_offline': {
            'type': 'serial',
            'fields': [
                {'title': resources['charts']['chart']['new_offlines_queue'], 'valueField': 'newOfflineQueueCount'},
                {'title': resources['charts']['chart']['new_offlines_operator'], 'valueField': 'newOfflineOperatorCount'},
                {'title': resources['charts']['chart']['closed_offline'], 'valueField': 'closedOfflineCount'}
            ],
            config: {
                'categoryField': 'hour'
            },
            'report2dataConverter': function (report) {
                return webimCharts.hoursReportToDataConverter(report, this.fields);
            }
        }
    },

    init: function () {
        this.chartSpecificConfigs['departments_offline'] = this.chartSpecificConfigs['departments_online'];
        this.chartSpecificConfigs['offices_offline'] = this.chartSpecificConfigs['offices_online'];

        if (typeof WebimReports != 'undefined') {
            for (var reportName in WebimReports) if (WebimReports.hasOwnProperty(reportName)) {
                if (typeof this.chartSpecificConfigs[reportName] != 'undefined') {
                    if (reportName != 'geo') {
                        var data = this.chartSpecificConfigs[reportName].report2dataConverter(WebimReports[reportName]);
                    } else {
                        var dataRussia = this.chartSpecificConfigs[reportName].report2dataConverter(WebimReports[reportName]);

                        this.chartSpecificConfigs[reportName].country = 'Украина';
                        var dataUkraine = this.chartSpecificConfigs[reportName].report2dataConverter(WebimReports[reportName]);
                    }
                    if (data || (reportName == 'geo' && (dataRussia || dataUkraine))) {
                        var chartConfig = jQuery.extend(true,
                            {},
                            this.chartBaseConfigs[this.chartSpecificConfigs[reportName].type],
                            this.chartSpecificConfigs[reportName].config,
                            {
                                'colors': this.colors,
                                'lang': this.lang

                            }
                        );

                        if (reportName != 'geo') {
                            this.addChart(chartConfig, data, reportName);
                        } else {
                            if (dataRussia) {
                                this.addChart(chartConfig, dataRussia, 'geo-russia');
                            }
                            if (dataUkraine) {
                                this.addChart(chartConfig, dataUkraine, 'geo-ukraine');
                            }
                        }
                    } else {
                        jQuery('.js-chart-' + reportName)
                            .addClass('chart-empty')
                            .text(resources['charts']['no_data']);
                    }
                }
            }
            jQuery('.nav-tabs a[data-action="show-charts"], .nav-tabs a[href="#stats-geo-ukraine"]').one('shown.bs.tab',jQuery.proxy(function() {
                for (var i = 0; i < this.charts.length; i++) {
                    this.charts[i].invalidateSize()
                }
            }, this));
        }
    },

    addChart: function(chartConfig, data, reportName) {
        switch (chartConfig['type']) {
            case 'pie':
                var legendId = 'chart_legend_' + reportName;
                jQuery('.js-chart-' + reportName).parent().append(
                    '<div class="chart-report legend" id="' + legendId + '"></div>'
                );
                jQuery.extend(true, chartConfig, {
                    'groupPercent': data['percent'] + 0.01,
                    'dataProvider': data['data'],
                    'legend': {
                        'divId': legendId
                    }
                });
                break;
            case 'serial':
                var graphTemplate = chartConfig.graphs.pop();
                for (var i = 0; i < this.chartSpecificConfigs[reportName].fields.length; i++) {
                    var field = this.chartSpecificConfigs[reportName].fields[i];
                    var graph = jQuery.extend({}, graphTemplate, field);
                    chartConfig.graphs.push(graph);
                }

                jQuery.extend(true, chartConfig, {
                    'dataProvider': data
                });
                break;
        }
        jQuery('.js-chart-' + reportName).addClass(chartConfig['type']+'-chart');
        var chart = AmCharts.makeChart('chart_' + reportName, chartConfig);
        this.charts.push(chart);
    },

    sortPieData: function (a, b) {
        if (a['data'] < b['data'])
            return 1;
        if (a['data'] > b['data'])
            return -1;
        return 0;
    },

    getHoursLabel: function (hour) {
        return (hour < 10 ? '0' : '') + hour + '-' + (hour >= 9 ? '' : '0') + (hour + 1)
    },

    getAllDays: function (data) {
        var dates = [];
        var res = [];

        for (var i = 0; i < data.length; i++) {
            var date = data[i]['date']['value']['date'].replace(/-/g, '/');
            dates.push(date);
        }

        var first = new Date(dates[dates.length - 1]).getTime();
        var last = new Date(dates[0]).getTime();

        var timeDiff = Math.abs(last - first);
        var diffDays = Math.ceil(timeDiff / (1000 * 60 * 60 * 24));

        for (var i = 0; i <= diffDays; i++) {
            var d = new Date(first + (1000 * 60 * 60 * 24) * i);
            res.push(AmCharts.formatDate(d, 'YYYY-MM-DD'));
        }

        return res;
    },

    datesReportToDataConverter: function (report, fields) {
        var data = report['data'];
        var result = [];

        if (data.length == 0) {
            return result;
        }

        var days = this.getAllDays(data);

        var dayToData = {};
        for (var i=0; i < data.length; i++) {
            var d = new Date(data[i]['date']['value']['date'].replace(/-/g, '/'));
            dayToData[AmCharts.formatDate(d, 'YYYY-MM-DD')] = data[i];
        }

        for (var k = 0; k < days.length; k++) {
            var day = days[k];
            var row = {
                'date': AmCharts.formatDate(new Date(day), 'DD.MM')
            };
            if (dayToData[day]) {
                for (var i = 0; i < fields.length; i++) {
                    var field = fields[i]['valueField'];
                    row[field] = parseInt(dayToData[day][field]['value']);
                }
            } else {
                for (var i = 0; i < fields.length; i++) {
                    var field = fields[i]['valueField'];
                    row[field] = 0;
                }
            }
            result.push(row);
        }
        return result.length ? result : null;
    },

    hoursReportToDataConverter: function (report, fields) {
        var data = report['data'];
        var result = [];

        if (data.length == 0) {
            return result;
        }

        var rowTemplate = {};
        for (var i = 0; i < fields.length; i++) {
            rowTemplate[fields[i]['valueField']] = 0;
        }

        for (var i = 0; i < 24; i++) {
            var row = jQuery.extend({
                hour: this.getHoursLabel(i)
            }, rowTemplate);
            result.push(row);
        }

        for (var k in data) {
            var hour = parseInt(data[k]['hour']['value']);
            for (var i = 0; i < fields.length; i++) {
                var field = fields[i]['valueField'];
                result[hour][field] = parseInt(data[k][field]['value']);
            }
        }

        return result.length ? result : null;
    }
};


jQuery().ready(function () {
    webimCharts.init();
});
