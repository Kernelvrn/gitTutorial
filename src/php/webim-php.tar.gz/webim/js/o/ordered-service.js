orderedService = {

    keyToTariff: null,
    discounts: null,
    replacedOs: null,
//    subscription: {activeProfile: null, replacing: false},
    lastPayedOs: null,

    pendingOs: null,

    operatorsCntOptionTemplate: null,
    rowTemplate: null,

    fieldValueConverters: {
        dtmfrom: tableUtils.dateConverter,
        dtmto: tableUtils.dateConverter
    },

    callbackForRow: function(row, data) {
        if ((data['status'] === 'payed' || data['status'] === 'payment_guaranteed') && data['license_key']) {
            webimJQuery('.os_row_link', row).show();
        }
        this.preparePaymentLink(row, data);
        row.addClass('status_'+ data['status']);
        row.addClass('id_'+ data['id']);
        webimJQuery('.tariff', row).text(resources.tariffs[data.tariffkey]);
        webimJQuery('.operators_cnt', row).text(this.getOperatorsCnt(data));
        webimJQuery('.status', row).text(orderedServiceStatus[data['status']]);
        if (data.dtmto > new Date().getTime() / 1000
            && data['status'] === 'payed'
            && !data['replacingid']
//            && data['paymentmethod'] != 'paypal'
            ) {
                webimJQuery('.change_button', row).show();
        }
        if (data['status'] === 'pending') {
            webimJQuery('.cancel_pending_button', row).show();
        }

        if (data['status'] == 'payment_guaranteed'
            && data.dtmfrom > new Date().getTime() / 1000) {
            webimJQuery('.cancel_pending_button', row).show();
        }

        webimJQuery('.cancel_pending_button', row).click(function() {
              orderedService.cancelOrder(data['id']);
        });
        webimJQuery('.change_button', row).click(function() {
            orderedService.replacedOs = data;
//            orderedService.subscription.replacing = false;
            orderedService.showForm();
        }.bind(this));
        webimJQuery('.os_row_link', row).click(function() {
            webimJQuery('textarea', '.modal-body').text(data['license_key']);
        });

    },

    init: function() {
        this.operatorsCntOptionTemplate = webimJQuery('#operators_cnt_select option').remove();

        webimJQuery('.tariff_option').click(function(e) {
            var tariffKey = webimJQuery(e.target).attr('value');
            if (tariffKey !== this.getSelectedTariffKey()) {
                this.selectTariff(tariffKey);
                this.onOrderOptionsChanged();
            }
        }.bind(this));

        webimJQuery('.payment-method').change(this.changeFormState.bind(this));
//        webimJQuery('#tariff_select').change(this.onOrderOptionsChanged.bind(this));
        webimJQuery('#month_cnt_select').change(this.onOrderOptionsChanged.bind(this));
        webimJQuery('#operators_cnt_select').change(this.onOrderOptionsChanged.bind(this));

        webimJQuery('#order_button').click(this.order.bind(this));
        webimJQuery('#order_free_tariff_button').click(this.setFreeTariff.bind(this));
        webimJQuery('#cancel_change_button').click(this.cancelChange.bind(this));
        webimJQuery('#accept_change_button').click(this.order.bind(this));
        webimJQuery('#cancel_button').click(this.cancelNewOrder.bind(this));
//        webimJQuery('#change_subscription_button').click(this.changeSubscription.bind(this));

        var modal = webimJQuery('#license-key');
        modal.on('shown.bs.modal', function() {
            webimJQuery('.modal-body textarea', modal).select();
        });
        webimJQuery('.copy', modal).click(function() {
            webimJQuery('.modal-body textarea', modal).select();
            document.execCommand('copy');
            webimJQuery('.alert-success', modal).stop(true, false).slideDown(500).delay(3000).slideUp(500);
        });

        this.rowTemplate = webimJQuery('#ordered_services tbody tr').remove();
        this.loadTariffs();
        this.loadCurrentTariff();
    },

    changeForm: function(pendingOs) {
        webimJQuery('#pending_order').hide();
        webimJQuery('#order_form').hide();
//        webimJQuery('#active_subscription').hide();
        if (pendingOs) {
            webimJQuery('#pending_order').show();
            this.changePendingState(pendingOs);
        } else {
//            if (this.subscription.activeProfile && !this.replacedOs) {
//                webimJQuery('#active_subscription').show();
//                this.showActiveSubscriptionForm();
//            } else {
                webimJQuery('#order_form').show();
//            }
        }
        this.changeFormState();
    },


    changeFormState: function() {
        webimJQuery('#order_form')
//            .removeClass('subscription_order')
            .removeClass('new_order')
//            .removeClass('replacing_subscription')
            .removeClass('replacing_order');
        webimJQuery('.payment-method[value=robokassa]').attr('disabled', false);
        webimJQuery('.payment-method[value=paypal]').attr('disabled', false);
        if (this.replacedOs) {
//            if (this.subscription.replacing) {
//                webimJQuery('#order_form').addClass('replacing_subscription');
//                webimJQuery('.payment-method[value=robokassa]').attr('disabled', true);
//                webimJQuery('.payment-method[value=invoice]').attr('disabled', true);
//            } else {
                webimJQuery('#order_form').addClass('replacing_order');
//            }
        } else {
//            var val = webimJQuery('.payment-method:checked').val();
//            if (val == 'paypal') {
//                webimJQuery('#order_form').addClass('subscription_order');
//            } else {
                webimJQuery('#order_form').addClass('new_order');
//            }
        }
    },

    changePendingState: function(pendingOs) {
        webimJQuery('#pending_order')
            .removeClass('new_order')
//            .removeClass('subscription_order')
//            .removeClass('replacing_subscription')
            .removeClass('replacing_order');
        if (this.replacedOs) {
//            if (this.subscription.replacing) {
//                webimJQuery('#pending_order').addClass('replacing_subscription');
//            } else {
                webimJQuery('#pending_order').addClass('replacing_order');
//            }
        } else {
//            if(pendingOs['paymentmethod'] == 'paypal') {
//                webimJQuery('#pending_order').addClass('subscription_order');
//            } else {
                webimJQuery('#pending_order').addClass('new_order');
//            }

        }
    },

    loadCurrentTariff: function() {
        wm.ajax.request(
            "/l/o/ordered-service.php",
            {action: 'get_current_tariff'},
            function(responseData) {
                this.setCurrentTariff(responseData['tariff']);
                if(!responseData['blocked']) {
                    webimJQuery('.tariff_option:has(a[value="free"])').hide();
                }
            }.bind(this),
            this.onRequestError.bind(this),
            null, null,
            {type: 'GET'});
    },

    loadTariffs: function() {
        wm.ajax.request(
            "/l/o/ordered-service.php",
            {action: 'get_tariffs'},
            function(responseData) {
                this.keyToTariff = responseData.keyToTariff;
                this.discounts = responseData.discounts;
                this.initTariffOptions();
                this.fillMonthCntSelect();
                this.fillDescriptions();
                this.reloadList();
            }.bind(this),
            this.onRequestError.bind(this),
            null, null,
            {type: 'GET'});
    },

    initTariffOptions: function() {
        for (var key in this.keyToTariff) {
            var tariff = this.keyToTariff[key];
            var wrp = webimJQuery('.tariff_option[value="' + key + '"]');
            if ('disabled' in tariff.descriptor && tariff.descriptor.disabled) {
                wrp.hide();
            }
        }
    },

    fillDescriptions: function() {
        for (var key in this.keyToTariff) {
            var tariff = this.keyToTariff[key];
            webimJQuery(".tariff_" + key + " .base_price").text(Math.round(tariff.descriptor.base_price * 100) / 100);
            webimJQuery(".tariff_" + key + " .per_operator_price").text(Math.round(tariff.descriptor.per_operator_price * 100) / 100);
        }
    },

    reloadList: function() {
        this.pendingOs = null;
        wm.ajax.request(
            "/l/o/ordered-service.php",
            {action: 'list'},
            this.onListRequest.bind(this),
            this.onRequestError.bind(this),
            null, null,
            {type: 'GET'});
    },

    onListRequest: function(responseData) {
        var tbodyWrapper = webimJQuery('#ordered_services tbody');
        tbodyWrapper.html('');
        tableUtils.fillTableWithData(tbodyWrapper, this.rowTemplate, responseData['orderedServices'], this.fieldValueConverters, this.callbackForRow.bind(this));
        webimJQuery('.os_row_link').click(function() {
            webimJQuery('#license-key').modal('show');
        });
        webimJQuery('#ordered_services_list').css('display', responseData['orderedServices'].length ? 'block' : 'none');
//        this.subscription.activeProfile = responseData['activeProfile'];
//        this.subscription.replacing = false;
        var lastPayedOs = null;
        for (var i in responseData['orderedServices']) {
            var os = responseData['orderedServices'][i];
            if ((os['status'] == 'pending' || os['status'] == 'payment_guaranteed') && (!this.replacedOs && !os.replacedid  || this.replacedOs && os.replacedid == this.replacedOs.id)) {
                this.showPending(os);
                return;
            } else if (os.status == 'payed' && !lastPayedOs) {
                lastPayedOs = os;
            }
        }
        this.lastPayedOs = lastPayedOs;
        this.showForm(lastPayedOs);
    },

    showPending: function(pendingOs) {
        this.pendingOs = pendingOs;
        this.changeForm(pendingOs);

        webimJQuery('#pending_order').removeClass('new_order').removeClass('replacing_order');
        webimJQuery('#pending_order').addClass(this.replacedOs ? 'replacing_order': 'new_order');
        webimJQuery('#pending_order #cancel_button').css('display', pendingOs.status == 'payment_guaranteed' ? 'none': 'inline');

//        webimJQuery('#pending_order .description').text(pendingOs.description);
        webimJQuery('#pending_order .tariff').text(resources.tariffs[pendingOs.tariffkey]);
        webimJQuery('#pending_order .month_cnt').text(pendingOs.monthcnt + " " + monthLabel[pendingOs.monthcnt]);
        webimJQuery('#pending_order .operators_cnt').text(this.getOperatorsCnt(pendingOs));
        webimJQuery('#pending_order .date_from').text(new Date(pendingOs.dtmfrom * 1000).format('dd.mm.yyyy'));
        webimJQuery('#pending_order .date_to').text(new Date(pendingOs.dtmto * 1000).format('dd.mm.yyyy'));
        if (this.replacedOs) {
            webimJQuery('#pending_order .price_to_pay').text(pendingOs.price);
        } else {
            webimJQuery('#pending_order .price_per_month').text((pendingOs.price / pendingOs.monthcnt).toFixed());
            webimJQuery('#pending_order .total_price').text(pendingOs.price);
        }
        webimJQuery('#pending_order .payment_method span').hide();
        webimJQuery('#pending_order .payment_method .' + pendingOs.paymentmethod).show();

        webimJQuery('#pending_order .payment_link_outer a').hide();
        this.preparePaymentLink(webimJQuery('#pending_order'), pendingOs);
    },

    getOperatorsCnt: function(os) {
        var settings = JSON.parse(os.settings);
        var tariff = this.keyToTariff[os.tariffkey];
        return 'online_operators_limit' in settings ? settings['online_operators_limit'] : tariff.settings.online_operators_limit;
    },

    preparePaymentLink: function(parentElement, os) {
        var invoiceGuid = os['invoiceguid'];
        if (invoiceGuid && invoiceGuid.length) {
            if (os['paymentmethod'] == 'invoice') {
                webimJQuery('a.invoice_link', parentElement).attr('href', '//ii.webim.ru/buy/schet.php?id=' + invoiceGuid).show();
            } else if (os['paymentmethod'] == 'robokassa' && (os['status'] == 'pending' || os['status'] == 'payment_guaranteed')) {
                webimJQuery('a.robo_form_link', parentElement).attr('href', '/webim/operator/payments.php?show-robo-form=1&guid=' + invoiceGuid).show();
            } else if (os['paymentmethod'] == 'invoicebox' && (os['status'] == 'pending' || os['status'] == 'payment_guaranteed')) {
                    webimJQuery('a.invoicebox_form_link', parentElement).attr('href', '/webim/operator/payments.php?show-invoicebox-form=1&guid=' + invoiceGuid).show();
            } else if (os['paymentmethod'] == 'paypal' && (os['status'] == 'pending' || os['status'] == 'payment_guaranteed')) {
//                webimJQuery('a.paypal_form_link', parentElement).attr('href', 'javascript:void(0);').show();
//                webimJQuery('a.paypal_form_link', parentElement).click(function() {
//                    orderedService.paypalPayment(invoiceGuid, this.replacedOs && !this.subscription.replacing ? 0 : 1);
//                }.bind(this));
                webimJQuery('a.paypal_form_link', parentElement).attr('href', '/webim/operator/payments.php?show-paypal-form=1&guid=' + invoiceGuid).show();
            } else if (os['paymentmethod'] == 'coinkassa' && (os['status'] == 'pending' || os['status'] == 'payment_guaranteed')) {
                webimJQuery('a.coinkassa_form_link', parentElement).attr('href', '/webim/operator/payments.php?show-coinkassa-form=1&guid=' + invoiceGuid).show();
            }

        }
    },

//    paypalPayment: function(guid, subscribe) {
//        wm.ajax.request('/l/o/paypal', {action: 'express_checkout', guid: guid, subscribe: subscribe}, function(responseData) {
//            if (responseData['result'] == 'success') {
//                window.location.href = responseData['url'];
//            } else {
//                this.onRequestError.bind(this)
//            }
//        }.bind(this),
//        this.onRequestError.bind(this),
//        null,
//        {type: 'GET'})
//
//    },

//    replacingSubscription: function(guid, profileId) {
//        wm.ajax.request('/l/o/paypal', {action: 'replace_profile', guid: guid, profileid: profileId, subscribe: 1}, function(responseData) {
//            if (responseData['result'] == 'success') {
//                window.location.href = responseData['url'];
//            } else {
//                this.onRequestError.bind(this)
//            }
//        }.bind(this),
//            this.onRequestError.bind(this),
//            null,
//            null,
//            {type: 'GET'})
//
//    },

    showForm: function(lastPayedOs) {
        this.changeForm();

        if (lastPayedOs) {
            this.selectTariff(lastPayedOs.tariffkey);

            var settings = JSON.parse(lastPayedOs.settings);
            var operatorsCnt = 'online_operators_limit' in settings ? settings['online_operators_limit'] : webimJQuery('#operators_cnt_select option:first').val();
            webimJQuery('#operators_cnt_select').val(operatorsCnt);

            if (lastPayedOs.monthcnt in monthLabel) {
                webimJQuery('#month_cnt_select').val(lastPayedOs.monthcnt);
            }
            webimJQuery("input.payment-method[value=" + lastPayedOs.paymentmethod + "]").attr('checked', 'checked');

            // когда последний период оплачен пэйпалом и мы, например, отменяем изменение заказа,
            // то после отмены показывается форма нового заказа,
            // хотя должна показываться форма новой подписки, т.к. выбран пэйпал.
            // Поэтому приходится делать проверку и еще раз делать ченджформ.

            //            if (lastPayedOs.paymentmethod == 'paypal') {
            //                this.changeForm();
            //            }
        } else {
            this.fillOperatorsCntSelect();
            if (this.replacedOs) {
                webimJQuery('#operators_cnt_select').val(this.getOperatorsCnt(this.replacedOs));
                if (this.replacedOs['monthcnt'] in monthLabel) {
                    webimJQuery('#month_cnt_select').val(this.replacedOs['monthcnt']);
                }
                this.selectTariff(this.replacedOs['tariffkey']);
            } else {
                this.selectTariff('bus');
            }
        }

        this.onOrderOptionsChanged();
    },

    setCurrentTariff: function(key) {
        webimJQuery('.current_tariff').find('strong').text(resources.tariffs[key]);
        if (key === 'free') {
            webimJQuery('#order_free_tariff_button').attr('disabled', true).text(resources.ordered_service_is_active)
                .off('click');
        }
    },

    selectTariff: function(key) {
        webimJQuery('.tariff_option').removeClass('active');
        webimJQuery('.tariff_option:has([value=' + key + '])').addClass('active');
        webimJQuery('.tariff_description').hide();
        webimJQuery('.tariff_description.tariff_' + key).show();
        this.fillOperatorsCntSelect();
        if (key === 'free') {
            webimJQuery('#form_inner').hide();
            webimJQuery('#free_tariff_description').show();
        } else {
            webimJQuery('#form_inner').show();
            webimJQuery('#free_tariff_description').hide();
        }
    },

    fillMonthCntSelect: function() {
        var selectWrp = webimJQuery('#month_cnt_select');
        for (var i in monthLabel) {
            var discount = this.discounts[i];
            var optionWrp = this.operatorsCntOptionTemplate.clone();
            // var discountStr = discount ? ' ( -' + discount + '% )' : '';
            optionWrp.text(i + " " + monthLabel[i]).attr('value', i);
            selectWrp.append(optionWrp);
        }
        selectWrp.val(defaultMonth.value);
        selectWrp.selectpicker && selectWrp.selectpicker('refresh');
    },

    fillOperatorsCntSelect: _.once(function() {
        var selectWrp = webimJQuery('#operators_cnt_select');
        var val = selectWrp.val();
        var tariff = this.keyToTariff[this.getSelectedTariffKey()];
        selectWrp.html('');
        for (var i = tariff.settings.online_operators_limit; i <= 1000; i++) {
            var optionWrp = this.operatorsCntOptionTemplate.clone();
            optionWrp.text(i).attr('value', i);
            selectWrp.append(optionWrp);
        }
        selectWrp.val(val || tariff.settings.online_operators_limit);
        selectWrp.selectpicker && selectWrp.selectpicker('refresh');
    }),

    onOrderOptionsChanged: function() {
        var options = this.getOrderOptions();
        if (options['tariffKey'] !== 'free') {
            wm.ajax.request(
                "/l/o/ordered-service.php",
                {action: 'calculate', 'options': JSON.stringify(options)},
                function(responseData) {
                    webimJQuery('#order_form .date_from').text(new Date(responseData.from * 1000).format('dd.mm.yyyy'));
                    webimJQuery('#order_form .date_to').text(new Date(responseData.to * 1000).format('dd.mm.yyyy'));
                    webimJQuery('#order_form .price_per_month').text(responseData.pricePerMonth);
                    webimJQuery('#order_form .total_price').text(responseData.totalPrice);
                    webimJQuery('#order_form .price_to_pay').text(responseData.priceToPay);
                    webimJQuery('#order_form #accept_change_button').css('display', responseData.priceToPay > 0 && this.replacedOs ? 'inline-block' : 'none');

                    var invoiceRadioWrp = webimJQuery('#order_form .payment-method[value=invoice]');
                    if (responseData.priceToPay >= 2000 && !organizationEmpty && !this.replacedOs) { // this.replacedOs && this.subscription.replacing
                        invoiceRadioWrp.removeAttr('disabled');
                    } else {
                        invoiceRadioWrp.attr('disabled', true);
                        if (invoiceRadioWrp.attr('checked')) {
                            webimJQuery('#order_form .payment-method[value!=invoice]').first().attr('checked', 'checked');
                        }
                    }
                }.bind(this),
                this.onRequestError.bind(this),
                null, null,
                {type: 'POST'});
        }
    },

    order: function() {
        var options = JSON.stringify(this.getOrderOptions());
        wm.ajax.request(
            "/l/o/ordered-service.php",
            {action: 'order', 'options': options},
            function(responseData) {
                webimJQuery('#ordered_services_list').show();
//                if (responseData['paymentmethod'] == 'paypal') {
//                    if (this.subscription.replacing) {
//                        this.replacingSubscription(responseData['invoiceguid'], this.subscription.activeProfile.profileid);
//                    } else if (this.replacedOs) {
//                        this.paypalPayment(responseData['invoiceguid'], 0);
//                    } else {
//                        this.paypalPayment(responseData['invoiceguid'], 1)
//                    }
//                } else {
                    this.reloadList();
//                }
            }.bind(this),
            this.onRequestError.bind(this),
            null, null,
            {type: 'POST'});
    },

    setFreeTariff: function() {
        wm.ajax.request(
            "/l/o/ordered-service.php",
            {action: 'set-free-tariff'},
            function(response) {
                if(response['error'] === 'could_not_enable_free_tariff') {
                    this.onRequestError(resources.alert['set_free_tariff_error'])
                } else if(response['result'] === 'ok') {
                    this.setCurrentTariff('free');
                }
            }.bind(this),
            this.onRequestError.bind(this),
            null, null,
            {type: 'POST'});
    },

    cancelChange: function() {
        this.replacedOs = null;
//        this.subscription.replacing = false;
        this.pendingOs ? this.showPending(this.pendingOs) : this.showForm();
    },

    cancelNewOrder: function() {
        this.cancelOrder(this.pendingOs.id);
    },

    cancelOrder: function(id) {
        this.replacedOs = null;
        wm.ajax.request(
            "/l/o/ordered-service.php",
            {action: 'cancel', 'id': id},
            function(responseData) {
                this.reloadList();
            }.bind(this),
            this.onRequestError.bind(this),
            null, null,
            {type: 'POST', dataType: 'text'});
    },

    getSelectedTariffKey: function() {
        return webimJQuery('.tariff_option.active a').attr('value') || 'bus';
    },

//    changeSubscription: function() {
//        this.replacedOs = this.lastPayedOs;
//        this.subscription.replacing = true;
//        this.showForm();
//    },

    getReplacedId: function() {
        if (this.replacedOs) {
            return this.replacedOs.id;
        } else {
            return null;
        }
    },

    getOrderOptions: function() {
        return {
            tariffKey: this.getSelectedTariffKey(),
            replacedId: this.getReplacedId(),
            monthCnt: parseInt(webimJQuery('#month_cnt_select').val() || 1),
            operatorsCnt: parseInt(webimJQuery('#operators_cnt_select').val() || 1),
            paymentMethod: webimJQuery(".payment-method:checked").val()
        };
    },

    onRequestError: function(message) {
        alert(message || resources.alert.server_error);
    }
};


webimJQuery(document).ready(function() {
    orderedService.init();
});

