function doNextRequest() {
    // var url = Math.random() > 0.5 ? 'http://hamster.webim.ru/sample-page.php?redirected=1' : 'http://hamster.webim.ru/_sample-page.php?redirected=1';
    // var url = Math.random() > 0.5 ? 'sample-page.php?a=a' : '_sample-page.php?redirected=1';
    // var url = Math.random() > 0.5 ? 'http://russianpostru.webim.ru/l/v/get-online-status?a=a' : 'http://hamster.webim.ru/_sample-page.php?redirected=1';
    var url = '/l/o/pingservice';
    var start_ts = new Date().getTime();
    url += '?ts=' + start_ts;
    url += '&pinger-id=' + pingerId;
    var logRecordText = '' + new Date();
    // logRecordText += ' ' + url;
    logRecordText += ' ' + start_ts;
    logRecordText += ' ...';
    var logRecordDivWrp = $('<div/>').text(logRecordText);
    $('#request_log').append(logRecordDivWrp);

    var jqxhr = $.get(url)
    .always(function(jqXHR) {
        setTimeout(doNextRequest, 5000);
        var duration = new Date().getTime() - start_ts;

        logRecordText += ' ' + jqxhr.status + ' ' + jqxhr.statusText + ' ' + duration + 'ms';
        logRecordDivWrp.text(logRecordText);
    })
    .done(function(response) {
        var resp = response.length > 101 ? response.substr(0, 100) : response;
        logRecordText += ' success ' + resp;
        logRecordDivWrp.text(logRecordText);
    })
    .fail(function(jqXHR, textStatus) {
        logRecordText += ' error';
        logRecordDivWrp.text(logRecordText);
    });

}

function guid() {
    function _p8(s) {
        var p = (Math.random().toString(16)+"000000000").substr(2,8);
        return s ? p.substr(0,4) + p.substr(4,4) : p ;
    }
    return _p8() + _p8(true) + _p8(true) + _p8();
}

$(window).ready(function() {
    pingerId = guid();
    $('#header').text('Pinger id: ' + pingerId);
    doNextRequest();
});
