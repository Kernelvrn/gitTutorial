<?php
/**
 * Created by JetBrains PhpStorm.
 * User: Alexander Bezroukov
 * Date: 12/7/12
 * Time: 11:22 PM
 * Generate js resource file (l18n data, еtс.)
 */

define('AVOID_SESSION_START', 1);
define('VISITOR_SIDE', TRUE);

require_once(dirname(__FILE__) . '/../../classes/functions.php');
require_once(dirname(__FILE__) . '/../../classes/version.php');
require_once(dirname(__FILE__) . '/../../autoload.php');

header('Content-Type: application/x-javascript; charset=' . strtolower(WEBIM_ENCODING));


/**
 * Array with labels of lang resources which will be load to file.
 * [js_object_name_in_webim.resource] => [first_part_of_key_in_resource_file]
 * You can use dots in js name if want to create subobjects: lang.ru => {lang { ru: '...' }}
 */

$resourceRules =  array(
  'days' => 'days',
  'months' => 'months',
  'week' => 'week',
  'second' => 'second',
  'enter' => 'enter',
  'errors' => 'errors',
  'check' => 'check',
  'phoner.incoming' => 'phoner.incoming',
  'phoner.talking' => 'phoner.talking',
  'service' => 'service',
  'alert' => 'alert',
  'system' => 'system',
  'operator' => 'operator',
  'charts' => 'charts',
  'tariffs' => 'ordered_service.tariff_option',
  'operator_chat' => 'operator_chat',
  'operator_status' => 'operator_status',
  'cobrowsing.notification' => 'cobrowsing.notification',
  'disconnect_all_operators_timeout' => 'disconnect_all_operators_timeout',
  'disconnect_operators_timeout' => 'disconnect_operators_timeout',
  'page_agents.confirm' => 'page_agents.confirm',
  'page_depaprtments.confirm' => 'page_depaprtments.confirm',
  'date_range_label' => 'filters.by_date.labels',
  'page_ban.confirm' => 'page_ban.confirm',
   'dashboard' => 'dashboard',
  'page_auto_invites.confirm' => 'page_auto_invites.confirm',
  'chat.window.predefined.add_answer_action' => 'chat.window.predefined.add_answer_action',
  'chat.error_message' => 'chat.error_message',
  'image_open_text' => 'chat.window.image_open_text',
  'delete_answer_confirm' => 'table.answers.action.delete.confirm',
  'answer_get_error' => 'table.answers.error.get',
  'answer_save_error' => 'table.answers.error.save',
  'private_keys_get_error' => 'table.private_keys.error.get',
  'private_keys_generate_error' => 'table.private_keys.error.generate',
  'chat.overlay.identification' => 'chat.overlay.identification',
  'spelling_dict_get_error' => 'table.spelling_dict.error.get',
  'spelling_dict_save_error' => 'table.spelling_dict.error.save',
  'online_periods_request_error' => 'online_periods.request_error',
  'chat.custom_action_request.buttons' => 'chat.custom_action_request.buttons',
  'ordered_service_is_active' => 'ordered_service.is_active',
  'delete_channel_confirm' => 'settings.channels.delete_channel_confirm',
  'visitor_fields' => 'visitor_field'
);

$resourcesArray = array();
$resourcesArray['default_visitor_names'] = Resources::GetDefaultVisitorNames();
foreach ($resourceRules as $jsName => $resourceKey) {
  $resourcesByKey = Resources::Get($resourceKey, array(), Resources::getOperatorCurrentLocale(), $byPrefix = TRUE);
  if (!empty($resourcesByKey) && is_array($resourcesByKey)) {
    Resources::addValueToArrayByPath(Resources::resourcesToTree($resourcesByKey), $resourcesArray, $jsName);
  } elseif (!empty($resourcesByKey)) {
      $resourcesArray[$jsName] = $resourcesByKey;
  }
}
print 'var resources = ' . array2JSObject($resourcesArray);


/**
 * Convert multidemensional array into jsObject with subobject.
 * @param array $arr
 * @param int $tab init tabulation (in spaces) for first level object
 * @return string
 */
function array2JSObject(array $arr, $tab = 0) {
  $jsObjectStr = '';
  $itemNumber = 1;
  foreach ($arr as $key => $val) {
    $jsObjectStr .= str_repeat(' ', $tab + 4) . $key . ': '
      . (is_array($val) ? array2JSObject($val, $tab + 4) : '\'' . addcslashes($val, '\'') . '\'')
      . ($itemNumber < count($arr) ? ',' : '')
      . PHP_EOL;
    $itemNumber++;
  }
  return '{' . PHP_EOL . $jsObjectStr . str_repeat(' ', $tab) . '}';
}


?>