waitingVisitorsPageMarker = true;

visitorsDeltaProcessor = {
    reset: function() {
        visitorListData.reset();
    },

    processDelta: function(delta) {
      if (onlineSupport.status == 'offline') {
          return
      }
      switch (delta.objectType) {
          case 'VISIT_SESSION':
              switch (delta.event) {
                  case "add":
                      visitorListData.addSession(delta.data);
                      break;
                  case "del":
                      visitorListData.deleteSession(delta.id);
                      break;
              }
              break;
          case 'VISITED_PAGE_2':
              var session = visitorListData.getSession(delta.id[0]);
              switch (delta.event) {
                  case "add":
                      session.addPage(delta.data);
                      break;
                  case "del":
                      session.delPage(delta.id[1]);
                      break;
                  case "upd":
                      // not supported
                      break;
              }
              break;
          case 'VISIT_SESSION_STATE':
              if (delta.event == 'upd') {
                  visitorListData.getSession(delta.id).setState(delta.data);
              }
              break;
          case 'VISIT_SESSION_ALIVE':
              if (delta.event == 'upd') {
                  var session = visitorListData.getSession(delta.id);
                  session.setAlive(delta.data);
              }
              break;
          case 'VISIT_SESSION_ON_SITE':
              if (delta.event == 'upd') {
                  visitorListData.getSession(delta.id).setOnSite(delta.data);
              }
              break;
          case 'VISIT_SESSION_SECTION_AND_ORDER':
              if (delta.event == 'upd') {
                  visitorListData.getSession(delta.id).setSectionKeyAndOrder(delta.data.sectionKey, delta.data.order);
              }
              break;
          case 'VISIT_SESSION_ACTUAL_TIME':
              if (delta.event == 'upd') {
                  visitorListData.getSession(delta.id).setSessionActualTime(delta.data);
              }
              break;
          case 'PREV_CHATS_COUNT':
              if (delta.event == 'upd') {
                  visitorListData.getSession(delta.id).setPrevChatsCount(delta.data);
              }
              break;
          case 'VISITOR':
              if (delta.event == 'upd') {
                  visitorListData.getSession(delta.id).setVisitor(delta.data);
              }
              break;
          case 'CHAT':
              switch (delta.event) {
                  case "add":
                      visitorListData.getSession(delta.id).setChat(delta.data);
                      break;
                  case "del":
                      visitorListData.getSession(delta.id).setChat(null);
                      break;
                  case "upd":
              //        not defined
              }
              break;
          case 'CHAT_MESSAGE_2':
              var session = visitorListData.getSession(delta.id[0]);
              switch (delta.event) {
                  case "add":
                      session.addMessage(delta.data);
                      break;
                  case "upd":
                      session.onEditMessageDelta(delta.data);
                      break;
                  case "del":
                      session.onDeleteMessageDelta(delta.id[1]);
                      break;
              }
              break;
          case 'CHAT_STATE':
              if (delta.event == 'upd') {
                  visitorListData.getSession(delta.id).setChatState(delta.data);
              }
              break;
          case 'CHAT_CATEGORY':
              if (delta.event == 'upd') {
                  visitorListData.getSession(delta.id).setChatCategory(delta.data);
              }
              break;
          case 'CHAT_OPERATOR':
              if (delta.event == 'upd') {
                  visitorListData.getSession(delta.id).setChatOperator(delta.data);
              }
              break;
          case 'CHAT_UNREAD_BY_OPERATOR_SINCE_TS':
              if (delta.event == 'upd') {
                  visitorListData.getSession(delta.id).setChatUnreadByOperatorSinceTs(delta.data);
              }
              break;
          case 'CHAT_NEED_TO_BE_CLOSED':
              if (delta.event == 'upd') {
                session = visitorListData.getSession(delta.id);
                if (session.chat.operator.id == wm.operatorId) {
                    visitorListData.setSessionIdToClose(delta.id, delta.data);
                }
              }
              break;
          case 'MESSAGE_READ':
              if (delta.event == 'upd') {
                  //todo support
              }
              break;
          case 'CHAT_VISITOR_TYPING':
              if (delta.event == 'upd') {
                  visitorListData.getSession(delta.id).setVisitorTyping(delta.data);
              }
              break;
          case 'CHAT_ID':
              if (delta.event == 'upd') {
                  visitorListData.getSession(delta.id).setChatId(delta.data);
              }
              break;
          case 'VISITOR_MESSAGE_DRAFT':
              if (delta.event == 'upd') {
                  visitorListData.getSession(delta.id).setVisitorMessageDraft(delta.data);
              }
              break;
          case 'INVITATION':
              if (delta.event == 'upd') {
                  visitorListData.getSession(delta.id).setInvitation(delta.data);
              }
              break;
          case 'DEPARTMENT':
              if (delta.event == 'upd') {
                  visitorListData.getSession(delta.id).setDepartment(delta.data);
              }
              break;
          case 'VISIT_SESSION_NUMBER':
              if (delta.event == 'upd') {
                  visitorListData.getSession(delta.id).setVisitorNumber(delta.data);
              }
              break;
          case 'USER_AGENT':
              if (delta.event == 'upd') {
                  visitorListData.getSession(delta.id).setBrowserInfo(delta.data);
              }
              break;
          case 'COBROWSING_SESSION':
              if (delta.event == 'upd') {
                  visitorListData.getSession(delta.id).setCobrowsingSession(delta.data);
              }
              break;
          case 'COBROWSING_STATE':
              if (delta.event == 'upd') {
                  visitorListData.getSession(delta.id).updateCobrowsingState(delta.data);
              }
              break;
          case 'OPERATOR_CHAT_MESSAGE':
              if (delta.event == 'add') {
                  operatorsChat.addMessage(delta.data, true);
              }
              break;
          case 'OPERATOR_STATUS':
              if (delta.event == 'upd') {
                  operatorsChat.updateOperatorStatus(delta.id, delta.data);
              }
              break;
          case 'OPERATOR_HINTS':
              if (delta.event == 'upd') {
                  visitorListData.getSession(delta.id).setOperatorHints(delta.data);
              }
              break;
          case 'CHAT_LAST_OPERATOR_ASSIGNED_TS':
              if (delta.event == 'upd') {
                  visitorListData.getSession(delta.id).setLastOperatorAssignedTs(delta.data);
              }
              break;
          case 'CHAT_STATE_MODIFIED_TS':
              if (delta.event == 'upd') {
                  visitorListData.getSession(delta.id).setStateModifiedTs(delta.data);
              }
              break;
      }
    },

    doFullUpdate: function(fullUpdate) {
        visitorListData.reset();
        visitorListData.hasVisitorData = true;
        visitorListData.keyToDepartment = fullUpdate.keyToDepartment;
        visitorListData.idToOperator = fullUpdate.idToOperator;

        for (var i in fullUpdate.visitSessionSections) if (fullUpdate.visitSessionSections.hasOwnProperty(i)) {
            var section = fullUpdate.visitSessionSections[i];
            visitorListData.keyToSessionSestions[section.key] = section;
        }
        visitorListUI.initSessionSections(fullUpdate.visitSessionSections);

        //sorting in reverse order to obtain max efficiency in __addSessionToContainer
        fullUpdate.visitSessions.sort(function(s1, s2) {
            return s2.order - s1.order;
        });
        for (var i in fullUpdate.visitSessions) {
            visitorListData.addSession(fullUpdate.visitSessions[i]);
        }
        if (!fullUpdate.visitSessions.length) {
            visitorListUI.setNoUsersPanelShown(true);
        }

        operatorsChat.reset();
        if ('operatorChat' in fullUpdate && fullUpdate['operatorChat']) {
            for (var operatorId in visitorListData.idToOperator) {
                operatorsChat.addOperator(operatorId);
            }
            operatorsChat.initOperatorChat(fullUpdate['operatorChat']);
        }
        var sessionId = window.location.hash.substring(1);
        visitorListUI.selectSessionById(sessionId);
    }
};

var visitorListData = {

    idToVisitSession: {},
    keyToDepartment: null,
    idToOperator: null,
    hasVisitorData: false,
    sessionWithAliveCobrowsingId: null,
    cobrowsingWindow: null,
    sessionIdsToCloseSet: {},
    keyToSessionSestions: {},
    resendUnconfirmedMessagesTimerId: null,

    reset: function() {
        localSessionStorager.store();

        this.idToVisitSession = new Object();
        this.hasVisitorData = false;
        this.sessionWithAliveCobrowsingId = null;

        if (this.resendUnconfirmedMessagesTimerId) {
            clearInterval(this.resendUnconfirmedMessagesTimerId);
            this.resendUnconfirmedMessagesTimerId = null;
        }
        this.resendUnconfirmedMessagesTimerId = setInterval(this.resendUnconfirmedMessages.bind(this), 3000);


        visitorListUI.clear();
        visitorListUI.setOperatorInOfflineModePanelShown(onlineSupport.status == 'offline');
        this.keyToSessionSestions = {};
    },

    addSession: function(session) {
        this.deleteSession(session.id);
        session.local = {
            messageDraft: null,
            previousChats: [],
            prevChatLoadError: false,
            hasAnotherPrevChatToLoad: session.visitor.hasPreviousChats,
            hasPreviousChats: session.visitor.hasPreviousChats,
            previousChatRequest: null,
            punctuationErrors: null,
            unconfirmedMessages: []
        };
        this.idToVisitSession[session.id] = session;
        session.__proto__ = this.sessionPrototype;
        session.addedToUI = false;

        this.addSessionPages(session);

        if (session.chat) {
            this.fillMessageIds(session.chat);
            session.postNewMessageAddedEventForChatIfNeed();
            if (session.chat.needToBeClosed) {
                if (session.chat.operator && session.chat.operator.id == wm.operatorId) {
                    visitorListData.setSessionIdToClose(session.id, true);
                }
            }
        }

        if (session.isActiveCobrowsingSessionForCurrentOperator()) {
            session.setCobrowsingSession(session.cobrowsingSession);
        }

        localSessionStorager.restore(session);

        if (session.isVisible()) {
            visitorListUI.addVisitSession(session);
            session.addedToUI = true;
            session.updateCurrentPage();
            if (!visitorListUI.selectedSession) {
                visitorListUI.setChooseVisitorPanelShown(true);
            }

            visitorListUI.setNoUsersPanelShown(false);

            var sessionIdFromHash = window.location.hash.substring(1);
            if (session.id == sessionIdFromHash) {
                visitorListUI.selectSessionById(session.id);
            }
        }
    },

    setSessionIdToClose: function(id, value) {
        if ((id in this.sessionIdsToCloseSet) != value) {
            if (value) {
                this.sessionIdsToCloseSet[id] = null;
            } else {
                delete this.sessionIdsToCloseSet[id];
            }
            visitorListUI.onSessionIdsToCloseSetChanged();
        }
    },

    addSessionPages: function(session) {
        for (var i in session.pages) {
            var page = session.pages[i];
            page.session = session;
        }
    },

    getSession: function(id) {
        debugData.lastGetSessionId = id;
        if (id in this.idToVisitSession) {
            return this.idToVisitSession[id];
        } else {
            return null;
        }
    },

    deleteSession: function(id) {
        var session = visitorListData.getSession(id);
        if (session) {
            session.del();
            visitorListUI.removeEmptySubsections();
        }
    },

    getOperatorsSortedByName: function () {
        var result = [];
        for (var id in this.idToOperator) {
            result.push({id: this.idToOperator[id].id, fullname: this.idToOperator[id].fullname})
        }
        return webimTools.sortArrayOfObjectsByKey(result, 'fullname');
    },

    resendUnconfirmedMessages: function() {
        if (onlineSupport.connectionEstablished) {
            for (var sessionId in this.idToVisitSession) if (this.idToVisitSession.hasOwnProperty(sessionId)) {
                var session = this.idToVisitSession[sessionId];
                session.resendUnconfirmedMessages();
            }
         }
    },

    sessionPrototype: {

        del: function() {
            delete visitorListData.idToVisitSession[this.id];

            if (this.isActiveCobrowsingSessionForCurrentOperator()) {
                visitorListData.sessionWithAliveCobrowsingId = null;
            }

            if (this.addedToUI) {
                visitorListUI.removeVisitSession(this.id);
            }
        },

        isVisible: function() {
            return this.sectionKey in visitorListData.keyToSessionSestions && !visitorListData.keyToSessionSestions[this.sectionKey].hidden
        },

        setState: function(state) {
            this.invitationState = state;
            if (this.addedToUI) {
                visitorListUI.updateSessionState(this.id, state);
            }
        },

        setAlive: function(alive) {
            this.alive = alive;
            if (this.addedToUI) {
                visitorListUI.updateSessionAlive(this.id, alive);
            }
        },

        setOnSite: function(onSite) {
            this.onSite = onSite;
            if (this.addedToUI) {
                visitorListUI.updateSessionOnSite(this.id, onSite);
            }
        },

        setSectionKeyAndOrder: function(sectionKey, order) {
            this.sectionKey = sectionKey;
            this.order = order;

            if (this.isVisible()) {
                if (this.addedToUI) {
                    visitorListUI.updateSessionSectionAndOrder(this);
                } else {
                    visitorListUI.addVisitSession(this);
                    this.addedToUI = true;
                    this.updateCurrentPage();

                    if (!visitorListUI.selectedSession) {
                        visitorListUI.setChooseVisitorPanelShown(true);
                    }
                    visitorListUI.setNoUsersPanelShown(false);
                }
            } else {
                if (this.addedToUI) {
                    visitorListUI.removeVisitSession(this.id);
                    this.addedToUI = false;
                }
            }
        },

        setSessionActualTime: function(actualTime) {
            this.actualTime = actualTime;
            if (this.addedToUI) {
                visitorListUI.updateSessionActualTime(this);
            }
        },

        setLastOperatorAssignedTs: function(lastOperatorAssignedTs) {
            this.chat.lastOperatorAssignedTs = lastOperatorAssignedTs;
        },

        setStateModifiedTs: function(stateModifiedTs) {
            this.chat.stateModifiedTs = stateModifiedTs;
        },

        addPage: function(page) {
            page.session = this;
            this.pages.push(page);

            this.updateCurrentPage();
            if (this.addedToUI) {
                visitorListUI.addPage(page);
            }
        },

        delPage: function(pageId) {
            for (var i in this.pages) {
                if (this.pages[i].id == pageId) {
                    this.pages.splice(i, 1);
                    break;
                }
            }

            this.updateCurrentPage();
            if (this.addedToUI) {
                visitorListUI.delPage(this.id, pageId);
            }
        },

        updateCurrentPage: function() {
            if (!this.addedToUI) {
                return;
            }
            var pages = this.pages;
            if (pages.length > 0) {
                for (var i = pages.length - 1; i--; i >= 0) {
                    if (pages[i].highPriority) {
                        visitorListUI.setCurrentPage(this.id, pages[i]);
                        return;
                    }
                }
                visitorListUI.setCurrentPage(this.id, pages[pages.length - 1]);
            } else {
                visitorListUI.setCurrentPage(this.id, null);
            }
        },

        setChat: function(chat) {
            if (this.chat && chat && this.chat.clientSideId != chat.clientSideId) {
                this.local.previousChats.unshift(this.chat);
            }

            this.chat = chat;
            if (chat) {
                visitorListData.fillMessageIds(chat);
                this.postNewMessageAddedEventForChatIfNeed(this.chat);
            } else {
                visitorListData.setSessionIdToClose(this.id, false);
            }
            if (this.addedToUI) {
                visitorListUI.setChat(this.id, chat);
            }
        },

        postNewMessageAddedEventForChatIfNeed: function() {
            if (this.chat && this.chat.operator && this.chat.operator.id == wm.operatorId) {
                for (var i = this.chat.messages.length - 1; i >= 0; i--) {
                    var message = this.chat.messages[i];
                    if (this.postNewMessageAddedEvent(message)) {
                        return;
                    }
                }
            }
        },

        postNewMessageAddedEvent: function(message) {
            var params = {
                'webimVisitorId': this.visitor.id,
                'providedVisitorId': this.visitor.fields && this.visitor.fields.id ? this.visitor.fields.id : null,
                'chatId': this.chat.id,
                'sessionId': this.id,
                'kind': message.kind,
                'messageText': message.text,
                'siebelId': this.getvisitorCustomField('siebelId')
            };

            if (message.kind == 'visitor' || message.kind == 'operator') {
                postMessageToParent({
                    event: 'newMessageAdded',
                    params: params
                });
            }
            return (message.kind == 'visitor'); // sending messages in postNewMessageAddedEventForChatIfNeed until we send last visitor message.
        },

        setChatState: function(state) {
            this.chat.state = state;

            if (state == 'closed_by_visitor' && this.chat.operator && this.chat.operator.id == wm.operatorId) {
                var providedVisitorId = this.visitor.fields && this.visitor.fields.id ? this.visitor.fields.id : null;
                postMessageToParent({
                    event: 'chatClosedByVisitor',
                    params:{
                        'webimVisitorId': this.visitor.id,
                        'providedVisitorId': providedVisitorId,
                        'chatId': this.chat.id,
                        'siebelId': this.getvisitorCustomField('siebelId')
                    }
                });

            }

            if (this.addedToUI) {
                visitorListUI.updateChatState(this.id);
            }
        },

        setChatCategory: function(category) {
            this.chat.category = category.category;
            this.chat.subcategory = category.subcategory;
        },

        setChatOperator: function(operator) {
            this.chat.operator = operator;
            this.postNewMessageAddedEventForChatIfNeed(this.chat);

            if (this.chat.neet_to_be_closed) {
                visitorListData.setSessionIdToClose(delta.id, this.chat.operator.id == wm.operatorId);
            }

            if (this.addedToUI) {
                visitorListUI.setChatOperator(this.id, operator);
            }
        },

        setChatUnreadByOperatorSinceTs: function(chatUnreadByOperatorSinceTs) {
            this.chat.unreadByOperatorSinceTs = chatUnreadByOperatorSinceTs;
            if (this.addedToUI) {
                visitorListUI.showUnreadMessageButton(this);
                visitorListUI.sendChatReadByOperator(this);
            }
        },

        setVisitorTyping: function(visitorTyping) {
            this.chat.visitorTyping = visitorTyping;
            if (this.addedToUI) {
                visitorListUI.setVisitorTyping(this.id, visitorTyping);
            }
        },

        setChatId: function(chatId) {
            this.chat.id = chatId;
            if (this.addedToUI) {
                visitorListUI.setChatId(this);
            }
        },

        setVisitorMessageDraft: function(visitorMessageDraft) {
          this.chat.visitorMessageDraft = visitorMessageDraft;
          if (this.addedToUI) {
              visitorListUI.setVisitorMessageDraft(this.id, visitorMessageDraft);
          }
        },

        addUnconfirmedMessage: function(clientSideId, pendingChange, confirmedState) {
            var found = false;
            for (var i in this.local.unconfirmedMessages) if (this.local.unconfirmedMessages.hasOwnProperty(i)) {
                if (this.local.unconfirmedMessages[i].clientSideId == clientSideId) {
                    this.local.unconfirmedMessages[i].pendingChange = pendingChange;
                    found = this.local.unconfirmedMessages[i];
                    break;
                }
            }

            if (!found) {
                this.local.unconfirmedMessages.push({
                    clientSideId: clientSideId,
                    confirmedState: confirmedState,
                    pendingRequest: true,
                    pendingChange: pendingChange
                });
            }
            if (!found || !found.pendingRequest) {
                if (pendingChange.deleted) {
                    this.deleteMessageAction(pendingChange.text, clientSideId, pendingChange);
                } else {
                    this.sendMessageAction(pendingChange.text, clientSideId, pendingChange);
                }
            }
            return true;
        },

        setPendingRequestForUnconfirmedMessage: function(clientSideId, pendingRequest) {
            for (var i in this.local.unconfirmedMessages) if (this.local.unconfirmedMessages.hasOwnProperty(i)) {
                if (this.local.unconfirmedMessages[i].clientSideId == clientSideId) {
                    this.local.unconfirmedMessages[i].pendingRequest = pendingRequest;
                    break;
                }
    }
        },

        confirmMessageOnResultOk: function(clientSideId, pendingChange) {
            for (var i in this.local.unconfirmedMessages) if (this.local.unconfirmedMessages.hasOwnProperty(i)) {
                var unconfirmedMessage = this.local.unconfirmedMessages[i];
                if (unconfirmedMessage.clientSideId == clientSideId) {
                    if (unconfirmedMessage.pendingChange.text == pendingChange.text && unconfirmedMessage.pendingChange.deleted == pendingChange.deleted) {

                        unconfirmedMessage.pendingRequest = false;
                        unconfirmedMessage.confirmedState = pendingChange;
                        unconfirmedMessage.pendingChange = null;

                        visitorListUI.confirmMessage(clientSideId);

                        this.local.unconfirmedMessages[i] = null;
                        delete this.local.unconfirmedMessages[i];
                    } else {
                        unconfirmedMessage.confirmedState = pendingChange;
                        unconfirmedMessage.pendingRequest = true;

                        if (unconfirmedMessage.pendingChange.deleted) {
                            this.deleteMessageAction( unconfirmedMessage.pendingChange.text, clientSideId,  unconfirmedMessage.pendingChange);
                        } else {
                            this.sendMessageAction( unconfirmedMessage.pendingChange.text, clientSideId,  unconfirmedMessage.pendingChange);
                        }
                    }
                    break;
                }
            }
        },

        deleteUnconfirmedMessage: function(clientSideId) {
             for (var i in this.local.unconfirmedMessages) if (this.local.unconfirmedMessages.hasOwnProperty(i)) {
                if (this.local.unconfirmedMessages[i].clientSideId == clientSideId) {
                    var confirmedState = this.local.unconfirmedMessages[i].confirmedState;

                    this.local.unconfirmedMessages[i] = null;
                    delete this.local.unconfirmedMessages[i];

                    visitorListUI.rollbackMessageToConfirmedState(clientSideId, this.id, confirmedState);
                }
            }
        },

        resendUnconfirmedMessages: function () {
            if (onlineSupport.connectionEstablished) {
                for (var i in this.local.unconfirmedMessages) if (this.local.unconfirmedMessages.hasOwnProperty(i)) {
                    var msg = this.local.unconfirmedMessages[i];
                    if (!msg.pendingRequest && msg.pendingChange) {
                        if (msg.pendingChange.deleted) {
                            this.deleteMessageAction( msg.pendingChange.text, msg.clientSideId,  msg.pendingChange);
                        } else {
                            this.sendMessageAction( msg.pendingChange.text, msg.clientSideId,  msg.pendingChange);
                        }
                    }
                }
            }
        },

        addMessage: function(message) {
            var chat = this.chat;
            if (chat) {
                if (message.id in chat.messageIds) {
                    return;
                } else {
                    chat.messageIds[message.id] = null;
                }
                chat.messages.push(message);

                if (chat.operator && chat.operator.id == wm.operatorId) {
                    this.postNewMessageAddedEvent(message);
                }

            }
            if (this.addedToUI) {
                visitorListUI.addMessage(message);
            }
        },

        onEditMessageDelta: function(message) {
            var chat = this.chat;
            if (chat) {
                for (var i in chat.messages) {
                    if (chat.messages[i].id == message.id) {
                        chat.messages[i] = message;
                    }
                }
            }
            visitorListUI.editMessage(message, this.id);
        },

        onDeleteMessageDelta: function(msgId) {
            var chat = this.chat;
            if (chat) {
                if (msgId in chat.messageIds) {
                    delete chat.messageIds[msgId];
                    for (var i in chat.messages) {
                        if (chat.messages[i].id == msgId) {
                            var clientSideId = chat.messages[i].clientSideId;
                            var text = chat.messages[i].text;
                            delete chat.messages[i];
                        }
                    }
                }
                visitorListUI.deleteMessage(this.id, clientSideId)
            }
        },

        setPrevChatsCount: function(count) {
            this.prevChatsCount = count;
            if (this.addedToUI) {
                visitorListUI.updatePrevChatsCount(this)
            }
        },

        setVisitor: function(visitor) {
            var auth = visitor.id != this.visitor.id;

            if (auth) {
                if (this.chat && this.chat.operator && this.chat.operator.id == wm.operatorId) {
                    postMessageToParent(
                    {'event': 'visitorAuthorized',
                    'params': {
                        'old': {
                            'webimVisitorId': this.visitor.id,
                            'providedVisitorId':  this.visitor.fields && this.visitor.fields.id ? this.visitor.fields.id : null,
                            'siebelId': this.getvisitorCustomField('siebelId')

                        },
                        'new': {
                            'webimVisitorId': visitor.id,
                            'providedVisitorId': visitor.fields && visitor.fields.id ? visitor.fields.id : null,
                            'siebelId': visitor.customFields && visitor.customFields.siebelId ? visitor.customFields.siebelId : null

                        }
                    }});
                }
                this.local.previousChats = [];
                this.local.hasAnotherPrevChatToLoad = visitor.hasPreviousChats;
            }

            this.visitor = visitor;
            this.local.hasPreviousChats = visitor.hasPreviousChats;
            if (this.addedToUI) {
                visitorListUI.updateVisitor(this.id, visitor, auth);
            }

            if (auth && visitor.hasPreviousChats) {
                this.loadPrevChat();
            }
        },

        setInvitation: function(invitation) {
            this.invitation = invitation;
        },

        setDepartment: function(departmentData) {
            this.departmentKey = departmentData.departmentKey;
            this.lang = departmentData.lang;
            this.shownDepartmentName = departmentData.shownDepartmentName;
            if (this.addedToUI) {
                visitorListUI.updateSessionDepartment(this);
                if (wm.accountConfig.visitors_subsections) {
                    visitorListUI.updateSessionSectionAndOrder(this);
                }
            }
        },

        setVisitorNumber: function(number) {
            this.visitorNumber = number;
            if (this.addedToUI) {
                visitorListUI.updateVisitorNumber(this);
            }
        },

        setBrowserInfo: function(browser) {
            this.browser = browser;
            if (this.addedToUI) {
                visitorListUI.updateVisitorBrowserInfo(this);
            }
        },

        setCobrowsingSession: function(cobrowsingSession) {
            this.cobrowsingSession = cobrowsingSession;
            if (this.cobrowsingSession.operatorId == wm.operatorId && this.cobrowsingSession.state != 'disconnected') {
                visitorListData.sessionWithAliveCobrowsingId = this.id;
                if (this.cobrowsingSession.state == 'connected') {
                    visitorListUI.updateCobrowsingWindow(cobrowsingSession);
                }
            }
            if (this == visitorListUI.selectedSession) {
                visitorListUI.updateCobrowsingPanel();
            }
        },

        isActiveCobrowsingSessionForCurrentOperator: function() {
            return this.cobrowsingSession && this.cobrowsingSession.state == 'connected' && this.cobrowsingSession.operatorId == wm.operatorId;
        },

        updateCobrowsingState: function(data) {
          this.cobrowsingSession.state = data.state;
          this.cobrowsingSession.lastStateReason = data.reason;

          if (this.cobrowsingSession.operatorId == wm.operatorId) {
              if (data.state == 'disconnected') {
                  visitorListData.sessionWithAliveCobrowsingId = null;
                  if (visitorListData.cobrowsingWindow && visitorListData.cobrowsingWindow.window) {
                      visitorListData.cobrowsingWindow.window.close();
                  }
                  visitorListData.cobrowsingWindow = null;
                  visitorListUI.cobrowsingNotifications.show(data.reason, this);
              }
          }
          visitorListUI.updateCobrowsingPanel();
        },

        getVisitorFields: function() {
            var fields = {};
            if (this.visitor){
                if(this.visitor.fields) {
                    fields = this.visitor.fields;
                }
                if (this.visitor.channelUserName) {
                    fields['user_name'] = this.visitor.channelUserName;
                }
            }

            return fields;
        },

        getvisitorCustomField: function(key) {
            if (this.visitor && this.visitor.customFields && this.visitor.customFields[key]) {
                return this.visitor.customFields[key];
            }

            return null;
        },

        getMessage: function(clientSideId) {
            for (var i in this.chat.messages) {
                var m = this.chat.messages[i];
                if (m.clientSideId == clientSideId) {
                    return m;
                }
            }
            return null;
        },

        setOperatorHints: function(data) {
            this.chat.operatorHints = [];
            for (var i=0; i < data.length; i++) if (data.hasOwnProperty(i)) {
                this.chat.operatorHints.push(data[i]);
            }
            visitorListUI.updateOperatorHints(this.id);
        },

        loadPrevChat: function(first, chatId) {
            if (this.local.previousChatRequest) {
                return;
            }
            var length = this.local.previousChats.length;
            var params = {
                visitorid: this.visitor.id,
                threadid:  chatId || (length > 0 ? this.local.previousChats[length-1].id : 0)
            };

            this.local.previousChatRequest = wm.ajax.request('/webim/operator/get-another-chat.php', params, function(responseData) {
                if (responseData) {
                    if (this.chat && (this.chat.id && this.chat.id === responseData['id'] ||
                            !this.chat.id && this.chat.clientSideId && this.chat.clientSideId === responseData['clientSideId'])) {

                        if (!responseData['another_one']) {
                            this.local.hasAnotherPrevChatToLoad = false;
                            responseData = null;
                        } else {
                            this.local.previousChatRequest = null;
                            this.local.prevChatLoadError = false;
                            this.loadPrevChat(false, this.chat.id);
                            return;
                        }
                    } else {
                        this.local.previousChats.push(responseData);
                        this.local.hasAnotherPrevChatToLoad = responseData['another_one'];
                    }
                } else {
                    this.local.hasAnotherPrevChatToLoad = false;
                }

                this.local.previousChatRequest = null;
                this.local.prevChatLoadError = false;

                if (this == visitorListUI.selectedSession) {
                    visitorListUI.updateChatPanelAfterLoadingPrevChat(responseData);
                    if (first) {
                        visitorListUI.scrollDown(false);
                    }
                }
            }.bind(this),
                function() {
                    this.local.previousChatRequest = null;
                    this.local.prevChatLoadError = true;
                    visitorListUI.updateChatPanelAfterErrorOnLoadingPrevChat();
                }.bind(this),
                null,null,
                {type: 'GET', timeout: 10000});
        },

        sendMessage: function(messageText, clientSideId) {
            var pendingChange = {text: messageText, deleted: false};

            this.addUnconfirmedMessage(clientSideId, pendingChange, null);
        },

        sendMessageAction: function(messageText, clientSideId, pendingChange) {
            onlineSupport.sendAction('message', {session_id: this.id, message: messageText, 'client-side-id': clientSideId},
                {
                    availableOffline: true,
                    ignoreOnErrorTimeout: true
                },
                {
                    onOkCallback: function(responseData) {
                                      this.confirmMessageOnResultOk(clientSideId, pendingChange);
                                  }.bind(this),

                    onErrorCallback: function(responseData) {
                                        try {
                                            this.setPendingRequestForUnconfirmedMessage(clientSideId, false);
                                            var response = webimJQuery.evalJSON(responseData);
                                             if ('error' in response) {
                                                    if (response.error == 'operator_cant_start_chat_with_visitor_from_another_department' ||
                                                        response.error == 'visitor_starting_chat_from_his_side' ||
                                                        response.error == 'another_operator_in_chat' ||
                                                        response.error == 'message_empty' ||
                                                        response.error == 'message_not_owned') {
                                                        alerts.showSimpleAlert(resources.alert[response.error]);
                                                        this.deleteUnconfirmedMessage(clientSideId);
                                                    }
                                             }
                                        } catch (e) {}


                                     }.bind(this),

                    checkResponse:   function(responseData) {
                                            try {
                                                var response = webimJQuery.evalJSON(responseData);
                                                if ('result' in response && response.result == 'ok') {
                                                    return true;
                                                }
                                                if ('error' in response) {
                                                    return false;
                                                }
                                            } catch (e) {}
                                            return false;
                                        }.bind(this)
                });
        },

        deleteMessage: function(messageText, clientSideId) {
            var pendingChange = {text: messageText, deleted: true};
            this.addUnconfirmedMessage(clientSideId, pendingChange, {text: messageText, deleted: false});
        },

        deleteMessageAction: function(messageText, clientSideId, pendingChange) {
            onlineSupport.sendAction('delete_message', {session_id: this.id, 'client-side-id': clientSideId},
                {
                    availableOffline: true,
                    ignoreOnErrorTimeout: true
                },
                {
                    onOkCallback: function(responseData) {
                                      this.confirmMessageOnResultOk(clientSideId, pendingChange);
                                    }.bind(this),

                    onErrorCallback: function(responseData) {
                                        this.setPendingRequestForUnconfirmedMessage(clientSideId, false);
                                        try {
                                            var response = webimJQuery.evalJSON(responseData);
                                             if ('error' in response) {
                                                 if (response['error'] == 'no-connection') {
                                                    // pass
                                                 } else if (response['error'] == 'message_not_owned') {
                                                      alerts.showSimpleAlert(resources.alert['delete_error'] + ' ' + resources.alert[response.error]);
                                                      this.deleteUnconfirmedMessage(clientSideId);

                                                 } else {
                                                     this.deleteUnconfirmedMessage(clientSideId);
                                                 }
                                             }
                                        } catch (e) {}
                                     }.bind(this),

                    checkResponse:   function(responseData) {
                                            var response = webimJQuery.evalJSON(responseData);
                                            if ('result' in response && response.result == 'ok') {
                                                return true;
                                            }
                                            if ('error' in response) {
                                                return false;
                                            }
                                            return false;
                                        }.bind(this)
                }
            );

        },

        editMessage: function(newMessageText, clientSideId) {
            var pendingChange = {text: newMessageText, deleted: false};
            var msg = this.getMessage(clientSideId);
            this.addUnconfirmedMessage(clientSideId, pendingChange, {text: msg ? msg.text : null, deleted: false});

        }
    },

    fillMessageIds: function(chat) {
        chat.messageIds = {}; // messageId -> null - set
        for (var i in chat.messages) {
            var m = chat.messages[i];
            chat.messageIds[m.id] = null;
        }
    }
};

visitorListUI = {

    visitSessionSectionTemplate: null,
    visitSessionElementTemplate: null,
    authorMessageTemplate: null,
    systemMessageTemplate: null,
    actionRequestMessageTemplates: {},
    previousChatTemplate: null,
    visitedPageElementTemplate: null,
    operatorToAssignTemplate: null,
    redirectVisitorListItem: null,
    emailChatOperatorListItem: null,
    operatorTypingManager: null,
    useSpellChecker: (["ru","en"].indexOf(wm.accountConfig.default_lang) != -1),
    punctuationChecking: {
        currentRequestSessionId: null,
        needRecheck: false,
        errorsHighlighted: false
    },
    selectedSession: null,
    onCategorySetCallback: null,
    scrollDownAnimationRunning: false,
    onOperatorAssignCallback: null,
    blockingCloseSessionId: null,

    //todo use webimJQuery.Callbacks
    handlers: {
        onSessionSelected: []
    },
    messageEditing: {
        active: false,
        msgId: null
    },

    init: function() {
        this.visitSessionElementTemplate = webimJQuery('[data-block="visit-session"]').remove();
        this.operatorHint = webimJQuery('.hints_container .hint').remove();
        this.visitSessionSubsectionTemplate = webimJQuery(".visit_session_subsection").remove();
        this.visitSessionSectionTemplate = webimJQuery('[data-block="visit-session-section"]').remove();

        this.operatorToAssignTemplate = webimJQuery("#manual_operator_assign_popup ul.operators_list li.operator").remove();

        this.previousChatTemplate = webimJQuery('.previous_chats .previous_chat').remove();

        setInterval(this.updateTime.bind(this), 1000);

        this.authorMessageTemplate = webimJQuery(".author_message").remove().show();
        this.systemMessageTemplate = webimJQuery(".system_message").remove().show();
        webimJQuery('.action_request_message').each(function(idx, element) {
            this.actionRequestMessageTemplates[webimJQuery(element).attr('message-subkind')] = webimJQuery(element).remove().css('display', 'block');
        }.bind(this));

        if (webimTools.storage.get('WEBIM_SPELL_CHECK_AUTO', true) || wm.accountConfig.spell_check_force) {
            webimJQuery('#check_spelling_auto_checkbox').attr('checked', true);
        } else {
            webimJQuery('#check_spelling_auto_checkbox').removeAttr('checked');
        }

        webimJQuery('#check_spelling_auto_checkbox').attr('disabled',wm.accountConfig.spell_check_force);
        if (!this.useSpellChecker) {
            webimJQuery(".spell_check_params").hide();
        }
        webimJQuery('.chat_panel .button.invite_visitor').click(this.inviteVisitor.bind(this));
        webimTools.addEnterKeyHandler('.chat_panel .invitation_textarea', this.inviteVisitor.bind(this));

        webimJQuery('.chat_panel .set_category').click(webimTools.createEventHandler(this.showCategoryPopup, this));
        webimJQuery('.category-selector-container #set_category_popup a').click(webimTools.createEventHandler(function(e) {
            webimJQuery('.category-selector-container').hide();
            this.setChatCategory(e);
        }, this));

        webimJQuery('.chat_panel .chat_message_textarea').click(function(e) {
          if (!visitorListUI.selectedSession.chat) {
            webimJQuery('.chat_panel .chat_message_textarea').val('');
          }
        }.bind(this));

        webimJQuery('#redirect_visitor_popup_frame .redirect_visitor_to_common_queue a').click(function () {
            onlineSupport.sendAction('redirect_visitor',
                {
                    'session_id': this.selectedSession.id,
                    'redirect_type': 'queue',
                    'redirect_id': null
                },
                {
                    availableOffline: true
                },
                {
                    onErrorCallback: function(responseData) {
                                            var response = webimJQuery.evalJSON(responseData);
                                            if (response && response['result'] && response['result'] == 'offline') {
                                                alert(resources.alert.redirect_target_offline);
                                            }
                                        }.bind(this),
                    checkResponse: onlineSupport.resultIsOkResponseDataChecker
                });
            this.hidePopups();
            return false;
        }.bind(this));

        this.redirectVisitorListItem = webimJQuery('#redirect_visitor_popup_frame .redirect-visitor-item').remove();
        this.emailChatOperatorListItem = webimJQuery('#email_chat_to_operator_frame .email-chat-operator-list-item').remove();
	    webimJQuery('.chat_panel .button.ban_visitor').click(this.banVisitor.bind(this));
        webimJQuery('.chat_panel .button.redirect_visitor').click(this.showRedirectVisitorPopup.bind(this));
        webimJQuery('.chat_panel .button.email_chat_to_operator').click(this.showSendChatToOperatorEmailPopup.bind(this));
        webimJQuery('#popup_glass_pane').click(webimTools.createEventHandler(this.hidePopups, this));
        webimJQuery('.chat_panel .button.request_contacts').click(this.requestContacts.bind(this));
        webimJQuery('.chat_panel .close_chat_button a').click(this.closeChat.bind(this));
        webimJQuery('.chat_panel .button.send_chat_message').click(this.onSendMessage.bindAsEventListener(this));
        webimJQuery('#check_spelling_auto_checkbox').change(this.onCheckSpellingAutoCheckboxChanged.bind(this));
        webimJQuery('#check_spelling_link').click(this.onCheckSpellingLinkClick.bind(this));
        webimJQuery('.chat_panel .button.accept_offline_chat').click(function(){this.accept()}.bind(this));
        webimJQuery('.chat_panel .button.zendesk_ticket').click(this.showZendeskPopup.bind(this));
        webimJQuery('.cobrowsing_panel .start_cobrowsing').click(this.startCobrowsing.bind(this));
        webimJQuery('.cobrowsing_panel .show_current_cobrowsing').click(this.onShowCurrentCobrowsingButton.bind(this));
        webimJQuery('.cobrowsing_panel .start_new_cobrowsing').click(this.startCobrowsing.bind(this));
        webimJQuery('.cobrowsing_panel .close_cobrowsing_button').click(this.stopCobrowsing.bind(this));
        webimJQuery('.show_chat_and_info_tab').click(function() {this.selectTab('chat_and_info')}.bind(this));
        webimJQuery('.show_cobrowsing_tab').click(function() {this.selectTab('cobrowsing')}.bind(this));
        webimJQuery('.chat_panel .button.form_request').click(this.showFormRequestPopup.bind(this));
        webimJQuery('.zendesk_ticket_popup .create_ticket').click(this.createZendeskTicket.bind(this));
        webimJQuery('.chat_panel .button.send_offline_chat_message').click(this.onSendMessage.bindAsEventListener(this));
        webimJQuery('.chat_panel .button.scroll_down').click(function(event){event.preventDefault(); this.scrollDown(false)}.bind(this));
        webimJQuery('.chat_panel .button.cancel_editing_message').click(this.cancelEditing.bind(this));
        webimJQuery('.chat_panel .button.edit_chat_message').click(this.onEditMessage.bind(this));
        webimJQuery('.chat_panel .chat_load_error .reload_prev_chat').click(this.reloadPrevChat.bind(this));
        webimJQuery('.chat_panel .button.operator_note').click(this.showOperatorNotePopup.bind(this));
        webimJQuery('.chat_panel .button.identification_kk').click(this.requestIdentificationKK.bind(this));
        webimJQuery('.chat_panel .button.identification_knpk').click(this.requestIdentificationKNPK.bind(this));
        webimJQuery('#operator_note_popup .button.send_operator_note').click(this.sendOperatorNoteMessage.bind(this));
        webimJQuery('#visitor_contact_info_div .update_visitor_fields').click(this.visitorFieldsUpdater.show.bind(this));
        webimJQuery('#visitor_contact_info_div .insert_visitor_fields').click(this.visitorFieldsUpdater.show.bind(this));
        webimJQuery('.visitor-fields-updater .button.button-cancel').click(this.visitorFieldsUpdater.cancel.bind(this));
        webimJQuery('.visitor-fields-updater .button.button-ok').click(this.visitorFieldsUpdater.update.bind(this));
        webimJQuery('[data-type="add_hyperlink"]').click(this.showAddHyperlinkPopup.bind(this));
        webimJQuery('[data-type="add_hyperlink_confirm"]').click(this.addHyperlink.bind(this));
        webimJQuery('.category-selector-container .hide-category-selector').click(this.hideCategoryPopup.bind(this));
        webimJQuery('.dialog_outer').scroll(this.onScrollHandler.bind(this));
	    webimJQuery('#visitors_list .assign_overlimit_chat').click(this.assignOverlimitChat.bind(this));

        webimJQuery(window).resize(function() {
            this.updateEmptySpaceDivHeight();
            this.updateDialogOuterBottom();
        }.bind(this));

        this.visitedPageElementTemplate = webimJQuery(".visit_info_panel .visited_page").remove();

        this.operatorTypingManager = webimTools.createTypingManager(
            function() {
                if (this.selectedSession && this.selectedSession.chat && this.selectedSession.chat.operator && this.selectedSession.chat.operator.id == wm.operatorId) {
                    onlineSupport.sendAction('operator_typing', {session_id: this.selectedSession.id, typing: true}, {availableOffline: true});
                }
            }.bind(this),
            function() {
                if (this.selectedSession && this.selectedSession.chat && this.selectedSession.chat.operator && this.selectedSession.chat.operator.id == wm.operatorId) {
                    onlineSupport.sendAction('operator_typing', {session_id: this.selectedSession.id, typing: false}, {availableOffline: true});
                }
            }.bind(this),
            wm.accountConfig.stop_typing_timeout);

        webimJQuery('.chat_panel .chat_message_textarea').blur(function(event) {
            webimJQuery('#start_typing_tip').css('display', 'block');
            this.operatorTypingManager.setNotTyping();
        }.bind(this));

        webimJQuery('.chat_panel .chat_message_textarea').bind('keypress', this.onKeyPress.bind(this));
        webimJQuery('.chat_panel .chat_message_textarea').bind('input',  this.onMessageChange.bind(this));

        webimJQuery(document).keyup(this.onKeyUp.bind(this));

        var handler = function() {
            //this timeout is need to invoke sendChatReadByOperator after alarm.focus is set to true
            //by another focus handler
            setTimeout(function () {
                this.sendChatReadByOperator(this.selectedSession);
            }.bind(this), 1);
        }.bind(this);
        webimJQuery(window).focus(handler);
        idle.addHandler(handler);
        this.fileUpload.init();

        if (window.webimTray) {
            var fixSessionPanelHeight = function () {
                var sessionPanelWrp = webimJQuery("#right_panel .session_panel");
                var rightPanelWrp = webimJQuery("#right_panel");
                var diff = sessionPanelWrp.width() > rightPanelWrp.width() ? 20 : 0;
                sessionPanelWrp.css('height', rightPanelWrp.height() - diff);
            };
            fixSessionPanelHeight();
            webimJQuery(window).resize(fixSessionPanelHeight);
        }

        webimJQuery('.webim-js-visitor-filter input[name="visitor_number"]').keyup(function(event) {
            this.findSessionByVisitorNumber(webimJQuery(event.currentTarget).val(), webimJQuery(event.currentTarget));
        }.bind(this));

        webimJQuery('#operators_search_field').keyup(function(event) {
            this.filterOperatorList(event.target.value);
        }.bind(this));

        this.prompter.init(this.selectedSession ? this.selectedSession.departmentKey : '');
        this.initFormRequestPopup();
    },

    updateOperatorHints: function(sessionId) {
        if (this.isSelected(sessionId)) {
            webimJQuery('.hints_container').empty();
            if (this.selectedSession.chat && this.selectedSession.chat.operatorHints && this.selectedSession.chat.operatorHints.length) {
                for (var i=0; i < this.selectedSession.chat.operatorHints.length; i++) {
                    var new_hint = this.operatorHint.clone();
                    webimJQuery(new_hint).text(this.selectedSession.chat.operatorHints[i].text);
                    webimJQuery('.hints_container').append(new_hint);
                }
                webimJQuery('.operator_hints').show();
            } else {
                webimJQuery('.operator_hints').hide();
            }
        }
    },

    updateVisitorPreviousChatLabel: function(sessionId) {
        var previousChatsInterval = wm.accountConfig.previous_chats_label_time_interval;
        if (previousChatsInterval) {
            var previousChatTag = visitorListData.idToVisitSession[sessionId].visitor.previousChatTag;
            if (previousChatTag && (new Date().getTime()/1000 - previousChatTag) < previousChatsInterval) {
                webimJQuery('.visit_session.' + sessionId + ' .previous_chat_label').show();
            } else {
                webimJQuery('.visit_session.' + sessionId + ' .previous_chat_label').hide();
            }
        }
    },

    filterOperatorList: function(selector) {
        var operators_list = webimJQuery('#redirect_visitor_operators_list');
        var departments_list = webimJQuery('#redirect_visitor_departments_list');

        var regexp = new RegExp(selector, 'i');

        var filterFunction = function() {
            var name = webimJQuery(this).find('a').html();

            if (name.search(regexp) > -1) {
                this.style.display = 'block';
            } else {
                this.style.display = 'none';
            }
        };
        operators_list.children().each(filterFunction);

        departments_list.children().each(filterFunction)
    },

    onMessageChange: function() {
        // this.checkPunctuation();
    },

    getCursorPosition: function () {
        var el = webimJQuery('.chat_panel .chat_message_textarea').get(0);
        var pos = 0;
        if('selectionStart' in el) {
            pos = el.selectionStart;
        } else if('selection' in document) {
            el.focus();
            var Sel = document.selection.createRange();
            var SelLength = document.selection.createRange().text.length;
            Sel.moveStart('character', -el.value.length);
            pos = Sel.text.length - SelLength;
        }

        return pos;
    },

    setCursorPosition: function (caretPos) {
        var elem = webimJQuery('.chat_panel .chat_message_textarea').get(0);

        if (elem != null) {
            if(elem.createTextRange) {
                var range = elem.createTextRange();
                range.move('character', caretPos);
                range.select();
            }
            else {
                if(elem.selectionStart) {
                    elem.focus();
                    elem.setSelectionRange(caretPos, caretPos);
                }
                else
                    elem.focus();
            }
        }
    },

    isSeparatorKeyPressed: function(key) {
        return webimJQuery.inArray(key, [13, 32, 33, 46, 63]) > -1; //  space, dot, ! or ?
    },

    upperCaseCharacter: function (charPos) {
       var text = webimJQuery('.chat_panel .chat_message_textarea').val();
        var pos = this.getCursorPosition();
        webimJQuery('.chat_panel .chat_message_textarea').val(text.slice(0, charPos) + text.charAt(charPos).toUpperCase() + text.slice(charPos+1));
        this.setCursorPosition(pos);
    },

    checkCapitalization: function() {
           var text = webimJQuery('.chat_panel .chat_message_textarea').val();
           var charToChange = 0;
           for (var i = this.getCursorPosition() - 1; i >= 0; i--) {
                var chCode = text.charCodeAt(i);
                if (i == 0) {
                    this.upperCaseCharacter(charToChange);
                    break;
                }

                if (chCode == 32) {
                    if (!charToChange) {
                       charToChange = i + 1;
                    }
                    if (text.charCodeAt(i-1) == 32) {
                        continue;
                    }
                    if (webimJQuery.inArray(text.charCodeAt(i-1), [13, 10, 33, 46, 63]) > -1) {
                        this.upperCaseCharacter(charToChange);
                    }
                    break;
                } else if (chCode == 13 || chCode == 10) {
                    this.upperCaseCharacter(i+1);
                    break;
                }
           }
    },

    onKeyPress: function(event) {
        if (event.which == '13' && !event.shiftKey) {
            if (!(this.selectedSession.chat && this.selectedSession.chat.offline)) {
                event.preventDefault();
                if (this.messageEditing.active) {
                    this.onEditMessage(event);
                } else {
                    this.onSendMessage(event);
                }
                return;
            }

        }

        if (wm.accountConfig.enable_capitalization_correction && this.isSeparatorKeyPressed(event.which)) {
            this.checkCapitalization();
        }

        setTimeout(function() {
              this.checkIfItNeedsAccept();
              this.operatorTypingManager.onKeyDown();
        }.bind(this), 0);
    },

    onKeyUp: function(e) {
        if (e.which == '27' && this.messageEditing.active) {
            e.preventDefault();
            this.updateEditingModeStatus(false);
            webimJQuery('.chat_panel .chat_message_textarea').val('');
        } else if (e.which == '38' && !this.messageEditing.active) {
            e.preventDefault();
            var lastMsgElement = webimJQuery('.author_message.kind_operator:last[op-id="'+ wm.operatorId + '"]', '.current_chat');
            if (lastMsgElement && !webimJQuery('.chat_message_textarea').val() && this.isMessageCanBeEdit()) {
                this.startEditMode(null, lastMsgElement);
            }
//            this.updateEditingModeStatus(false);
//            webimJQuery('.chat_panel .chat_message_textarea').val('');
        }
    },

    isMessageCanBeEdit: function() {
        return this.selectedSession.chat &&
               this.selectedSession.chat.operator &&
               this.selectedSession.chat.operator.id == wm.operatorId &&
               !this.selectedSession.visitor.channelType;
    },

    setOnLoadThrobberPanel: function(show) {
        this.setNoUsersPanelShown(false);
        webimJQuery('.on_load_throbber').css('display', show ? 'block' : 'none');
    },

    updateOnLoadThrobberPanel: function() {
        this.setOnLoadThrobberPanel(!visitorListData.hasVisitorData && !onlineSupport.connectionEstablished && onlineSupport.status != 'offline');
    },

    initSessionSections: function(sections) {
        webimJQuery('[data-widget="visitors-list"] [data-block="visit-session-section"]').remove();
        for (var i in sections) if (sections.hasOwnProperty(i)) {
            var section = sections[i];
            var wrp = this.visitSessionSectionTemplate.clone();

            wrp
                .addClass(section.key)
                .addClass('color_' + section.color.replace('#', ''))
                .find('[data-block="session-items-container"]').hide();
            wrp
                .find('[class="panel-heading"]')
                .attr('data-toggle','collapse')
                .attr('data-target','#collapse_id_'+section.key);
            wrp
                .find('[data-block="session-items-container"]')
                .addClass('collapse in')
                .attr('id','collapse_id_'+section.key);
            switch (section.key) {
                case 'offline_queue':
                    webimJQuery('[data-type="section-tooltip"]', wrp)
                        .show()
                        .attr('title', resources.system.section.tooltip.offline);
                    break;
                case 'not_in_chat':
                    webimJQuery('[data-type="section-tooltip"]', wrp)
                        .show()
                        .attr('title', resources.system.section.tooltip.not_in_chat);
                    break;
                default:
                    webimJQuery('[data-type="section-tooltip"]', wrp).hide();
            }

            webimJQuery('[data-type="section-label"]', wrp).text(section.name);
            section.hidden ? wrp.hide() : wrp.show();
            webimJQuery('[data-widget="visitors-list"]').append(wrp);
        }

    },

    initFormRequestPopup: function() {
      webimJQuery('.form_request_button').each(function(idx, element) {
          webimJQuery(element).click(function() {
              var formId = webimJQuery(element).attr('id');
              onlineSupport.sendAction('request_form', {session_id: this.selectedSession.id, form_id: formId});
              this.hidePopups();
          }.bind(this))
      }.bind(this));
    },

    addVisitSession: function(session) {
        var sessionItemElement = this.visitSessionElementTemplate.clone();
        sessionItemElement.css('display', session.alive ? 'block' : 'none');

        sessionItemElement.addClass(session.id);
        sessionItemElement.attr('order', session.order);
        if (session.chat && session.chat.offline) {
            webimJQuery('.visitor_not_on_site', sessionItemElement).remove();
            webimJQuery('.current_page', sessionItemElement).remove();
//            sessionItemElement.addClass('offline_chat');
        }
        webimJQuery('.visitor_name', sessionItemElement).text(session.visitor.fields.name);
        if (session.visitorNumber !== null) {
            webimJQuery('.visitor_number', sessionItemElement).text('[' + session.visitorNumber + ']');
        }
        this.setVisitorPicture(webimJQuery('.visitor_icon', sessionItemElement), session.visitor, 30);

//        var invitationStateStr = wmGetRes(session.invitationState);
//        invitationStateStr = invitationStateStr.length > 0 ? " &mdash; " + invitationStateStr : "";
//        webimJQuery('.state', sessionItemElement).html(invitationStateStr);

//        var bi = this.getBrowserInfo(session);
//        webimJQuery('.browser_icon', sessionItemElement).attr('src', bi.browserIconSrc).attr('alt', bi.browser).attr('title', bi.browser ? bi.browser : session.userAgent);
//        webimJQuery('.platform_icon', sessionItemElement).attr('src', bi.platformIconSrc).attr('alt', bi.platform).attr('title', bi.platform ? bi.platform : session.userAgent);

        this.setSessionDepartment(sessionItemElement, session);
        this.setCurrentOperatorName(sessionItemElement, session.chat ? session.chat.operator : null);

        webimJQuery('.current_page a', sessionItemElement).attr('href', '');
        webimJQuery('.current_page span', sessionItemElement).text('');
        this.updateChattingWithOperatorTimer(sessionItemElement, session);
        this.updateSessionActualTime_(sessionItemElement, session);
        webimJQuery('.offline_chat_marker', sessionItemElement).css('display', session.chat && session.chat.offline ? 'inline' : 'none');

        var geo = session.ipInfo.geo;
        if (geo != null) {
            webimJQuery('.location', sessionItemElement).text((geo.city ? geo.city + ', ' : '') + geo.country_name);
//            webimJQuery('.location_link', sessionItemElement).attr('href', geo.latitude && geo.longitude ? 'http://maps.google.com/maps?q=' + geo.latitude + ', ' + geo.longitude : '');
        } else {
            webimJQuery('.location', sessionItemElement).text('');
        }

        this.setLastMessage(sessionItemElement, this.getLastMessage(session.chat));
        this.updateSessionItemInvitationInfo(sessionItemElement, session);

        var landingInfo = session.landingInfo;
        if (landingInfo.search) {
            webimJQuery('.search_text a', sessionItemElement).attr('href', landingInfo.landingPage.referer);
            webimJQuery('.search_text span', sessionItemElement).text(landingInfo.search.search_text);
            webimJQuery('.search_text img', sessionItemElement).attr('src', '/webim/images/icons/' + landingInfo.search.engine + '.ico');
        } else {
            webimJQuery('.search_text', sessionItemElement).css('display', 'none');
        }

        sessionItemElement.click(function() {
            this.selectSession(session, true);

            if (window.Notification && window.Notification.permission == 'default') {
                window.Notification.requestPermission(function(result){});
            }
        }.bind(this));

        webimJQuery('a', sessionItemElement).click(function(e) {
            e.stopPropagation();
        });
        this.updateSessionItemSection_(session, sessionItemElement);

        if (this.isHighPriorityVisitor(session.id)) {
            webimJQuery('.visit_session.' + session.id).addClass('high_priority');
        }

        this.updatePrevChatsCount(session);
        this.updateVisitorPreviousChatLabel(session.id);

    },

    addSessionToSubsection: function(session, sessionItemElement) {
        var subsectionClass = 'subsection_' + session.departmentKey;
        var subsectionClassQueryString = subsectionClass.replace(/\./g, '\\\.');
        var section = webimJQuery('.' + session.sectionKey + '[data-block="visit-session-section"]');
        var subsection = webimJQuery('.visit_session_subsection.' + subsectionClassQueryString, section);
        if (subsection.length) {
            this.__addSessionToContainer(session, sessionItemElement, webimJQuery('.subsection_session_items_container', subsection));
        } else {
            var wrp = this.visitSessionSubsectionTemplate.clone();
            wrp.addClass(subsectionClass);
            webimJQuery('.subsection_label .subsection_name', wrp).text(visitorListData.keyToDepartment[session.departmentKey].localeToName['ru']);
            if (session.sectionKey != 'in_chat' && session.sectionKey != 'queue'){
                webimJQuery('.subsection_label .glyphicon', wrp).addClass('glyphicon-menu-down');
                webimJQuery('.subsection_session_items_container', wrp).hide();
                webimJQuery('.subsection_label', wrp).click(function (e) {
                    var container = webimJQuery('.subsection_session_items_container', webimJQuery(e.currentTarget).parent());
                    var glyph = webimJQuery(e.currentTarget).find('.glyphicon');

                    container.slideToggle(300);
                    glyph.toggleClass('glyphicon-menu-right glyphicon-menu-down');
                });
            } else {
                webimJQuery('.subsection_label .glyphicon', wrp).hide().parent().addClass('non-clickable');
            }

            this.__addSessionToContainer(session, sessionItemElement, webimJQuery('.subsection_session_items_container', wrp));
            if (session.departmentKey) {
                webimJQuery('[data-block="session-items-container"]', section)
                    .show()
                    .append(wrp);
            } else {
                webimJQuery('.subsection_label .subsection_name', wrp).text(resources.system.section.default_subsection);
                webimJQuery('[data-block="session-items-container"]', section)
                    .show()
                    .prepend(wrp);
            }
        }

        if (this.selectedSession == session) {
            webimJQuery('.visit_session.' + session.id).parents('.subsection_session_items_container').show();
        }
    },

    updateSessionSectionAndOrder: function(session) {
        var sessionItemElement = webimJQuery('.visit_session.' + session.id);
        sessionItemElement.attr('order', session.order);
        this.updateSessionItemSection_(session, sessionItemElement);

        if (!sessionItemElement.is(':visible') && this.selectedSession == session) {
            this.selectSession(null);
        }
    },

    updateSessionItemSection_: function(session, sessionItemElement) {
        var sectionClass = session.sectionKey;
        if (wm.accountConfig.visitors_subsections) {
            this.addSessionToSubsection(session, sessionItemElement);
            this.removeEmptySubsections();
        } else {
            this.__addSessionToContainer(session, sessionItemElement, webimJQuery('[data-widget="visitors-list"] .' + sectionClass + ' [data-block="session-items-container"]'));
        }
        this.updateSessionCounts();

    },

    __addSessionToContainer: function(session, sessionWrp, containerWrp) {
        var sessionsWrp = webimJQuery('.visit_session', containerWrp);
        var added = false;
        sessionsWrp.each(function(idx, element) {
            var wrp = webimJQuery(element);
            if (session.order < wrp.attr('order')) {
                wrp.before(sessionWrp);
                added = true;
                return false;
            }
        });
        if (!added) {
            containerWrp.append(sessionWrp);
        }
        containerWrp.show();

    },


    updateSessionCounts: function() {
        if (!visitorListUI.selectedSession) {
            visitorListUI.setChooseVisitorPanelShown(true);
        }

        if (wm.accountConfig.visitors_subsections) {
            webimJQuery('[data-widget="visitors-list"] [data-block="visit-session-section"]').each(function(idx, element) {
                var count = 0;
                webimJQuery('.subsection_session_items_container', element).each(function(idx, e) {
                    webimJQuery('.subsection_sessions_count', webimJQuery(e).parent()).text(webimJQuery('.visit_session', e).length);
                    count = count + webimJQuery('.visit_session', e).length;
                });
                webimJQuery('[data-type="session-count"]', element).text(count);
            });
        } else {
            webimJQuery('[data-widget="visitors-list"] [data-block="session-items-container"]').each(function(idx, element) {
                webimJQuery('[data-type="session-count"]', webimJQuery(element).parent()).text(webimJQuery(element).children().filter(':visible').length);
            });
        }
    },

    removeEmptySubsections: function() {
        webimJQuery('.visit_session_subsection').each(function(idx, element) {
           if (webimJQuery('.subsection_session_items_container .visit_session', element).length == 0) {
               webimJQuery(element).remove();
           }
        });
    },

    updateSessionState: function(sessionId, state) {
        var session = visitorListData.idToVisitSession[sessionId];
        this.updateSessionItemInvitationInfo(webimJQuery('.visit_session.' + sessionId), session);
        if (this.isSelected(sessionId)) {
            this.updateMainPanel();
        }
    },

    updateSessionAlive: function(sessionId, alive) {
        webimJQuery('.visit_session.' + sessionId).css('display', alive ? 'block' : 'none');
        this.updateSessionCounts();
    },

    updateSessionOnSite: function(sessionId, onSite) {
        if (this.isSelected(sessionId)) {
            this.updateOnSiteTotalTime(onSite);
        }
    },

    updateSessionItemInvitationInfo: function(sessionItemElement, session) {
        var label = '';
        var message = '';
        var title = '';
        switch (session.invitationState) {
            case 'showing':
                label = resources.operator.label.showing;
                message = session.invitation.message;
                break;
            case 'showing-auto':
                label = resources.operator.label.showing_auto;
                message = session.invitation.message;
                break;
            case 'idle-after-chat':
                cur_chats = session.prevChatsCount['current_chats_count'] ? session.prevChatsCount['current_chats_count'] : 0;
                cur_invites = session.prevChatsCount['current_invitations_count'] ? session.prevChatsCount['current_invitations_count'] : 0;
                label = (cur_chats == 0 && cur_invites == 0) ? resources.operator.label.idle_after_chat : resources.operator.label.cur_chats + cur_chats + resources.operator.label.cur_invites + cur_invites;
                title = resources.operator.label.chats_n_invites_by_session;
                break;
            case 'first-question':
                label = resources.operator.label.first_question;
                break;
            case 'department-selection':
                label = resources.operator.label.department_selection;
                break;
            case 'offline-message':
                label = resources.operator.label.offline_message;
                break;
        }
        webimJQuery('.session_state_label', sessionItemElement).text(label);
        webimJQuery('.session_state_label', sessionItemElement).attr('title', title);
        webimJQuery('.invitation_message', sessionItemElement).text(webimTools.cutString(message, 30)).attr('title', message);
    },

    selectSessionById: function(sessionId) {
        if (sessionId in visitorListData.idToVisitSession) {
            this.selectSession(visitorListData.idToVisitSession[sessionId]);
        }
    },

    selectSession: function(session, avoidScroll) {

        if (this.selectedSession == session) {
            return;
        }

        var previousSelectedSessionChatId = null;

        if (this.selectedSession) {
            var draftText = webimJQuery('.session_panel .chat_message_textarea').val();
            if (draftText) {
                this.selectedSession.local.messageDraft = {
                    text: draftText,
                    messageClientSideId: this.messageEditing.active ? this.messageEditing.msgId : null
                };
            } else {
                this.selectedSession.local.messageDraft = null;
            }
        }
        this.cancelEditing();

        this.hidePopups();

        this.selectedSession = session;

        if (this.selectedSession) {
            this.prompter.initAnswers(this.selectedSession.departmentKey);
        }
        webimJQuery('.session_panel textarea').val('');

        if (this.selectedSession) {
            this.selectTab('chat_and_info');
            webimJQuery('.dialog .throbber').css('display', 'none');
            webimJQuery('.dialog .chat_load_error').css('display', 'none');
            if (this.selectedSession.local.previousChats.length == 0 && this.selectedSession.local.hasAnotherPrevChatToLoad) {
                if (!this.selectedSession.local.prevChatLoadError) {
                    webimJQuery('.dialog .throbber').css('display', 'block');
                    this.selectedSession.loadPrevChat(true);
                } else {
                    webimJQuery('.dialog .chat_load_error').css('display', 'block');
                }
            }
            webimJQuery('.dialog .previous_chats_line').css('display',this.selectedSession.local.previousChats.length ? 'block' : 'none');
            if (this.selectedSession.chat) {
                this.setUnreadMessageButtonText(this.selectedSession);
            }

            postMessageToParent({
                    event: 'visitorSelected',
                    params: {
                            webimVisitorId: this.selectedSession.visitor.id,
                            providedVisitorId: this.selectedSession.visitor.fields && this.selectedSession.visitor.fields.id ? this.selectedSession.visitor.fields.id : null,
                            chatId: this.selectedSession.chat ? this.selectedSession.chat.id : null,
                            sessionId: this.selectedSession.id,
                            taskId: this.selectedSession.getvisitorCustomField('taskId'),
                            siebelId: this.selectedSession.getvisitorCustomField('siebelId')

                    }
            });
            if (wm.accountConfig.tcs_custom_operator_interface_events) {
                onlineSupport.sendAction('select_session', {session_id: this.selectedSession.id, previous_session_chat_id: previousSelectedSessionChatId});
            }
        }

        webimJQuery('.visit_session').removeClass('selected');
        if (session) {
          webimJQuery('.visit_session.' + session.id).addClass('selected');
            if (wm.accountConfig.visitors_subsections) {
                webimJQuery('.visit_session.' + session.id).parents('.subsection_session_items_container').show();
            }
        }
        this.showVisitorListPanel();
        this.updateMainPanel();

        this.scrollDown(false);

        if (!avoidScroll) {
            this.scrollToSelectedSession();
        }

        if (session) {
            window.location.hash = session.id;
            this.sendChatReadByOperator(session);
        }

        for (var i in this.handlers.onSessionSelected) {
            this.handlers.onSessionSelected[i](session);
        }
    },

    showPreviousChatInDialogDiv: function() {
        if (this.selectedSession.local.previousChats.length == 0) {
            return;
        }

        webimJQuery('.dialog').scrollTo(webimJQuery('.empty_space_div'));
        var currentScroll = webimJQuery('.dialog').scrollTop();
        webimJQuery('.dialog').scrollTop(currentScroll - webimJQuery('.empty_space_div').height());
    },

    scrollToSelectedSession: function() {
        var selected = webimJQuery('.visit_session.selected');
        if (selected.size()) {
            webimJQuery('#visitors_list').scrollTo(selected);
        }
    },

    isSelected: function(sessionId) {
      return this.selectedSession && this.selectedSession.id == sessionId;
    },

    updateMainPanel: function() {
        this.setChooseVisitorPanelShown(false);
        this.setOnLoadThrobberPanel(false);
        this.setNoUsersPanelShown(false);
        this.setOperatorInOfflineModePanelShown(false);
        webimJQuery('.session_panel').hide();
        webimJQuery('.operator_chat_and_info_panel').hide();
        webimJQuery('.cobrowsing_panel').hide();
        webimJQuery('.chat_and_info_panel').hide();

        if (onlineSupport.status == 'offline') {
            this.setOperatorInOfflineModePanelShown(true);
            return;
        }

        if (!visitorListData.hasVisitorData && !onlineSupport.connectionEstablished) {
            this.setOnLoadThrobberPanel(true);
            return;
        }

        if (this.isOperatorsChatPanelSelected()) {
            webimJQuery('.operator_chat_and_info_panel').show();
            operatorsChat.scrollDown(false);
            operatorsChat.unreadMessagesCounter = 0;
            operatorsChat.updateNewMessageCounter();
            if (operatorsChat.lastNotification) {
                operatorsChat.lastNotification.close();
            }
            return;
        }

        if (this.isVisitorListPanelSelected()) {
            if (_.isEmpty(visitorListData.idToVisitSession)) {
                this.setNoUsersPanelShown(true);
            } else {
                var session = this.selectedSession;
                if (session == null) {
                    this.setChooseVisitorPanelShown(true);
                } else {
                    webimJQuery('.session_panel').show();

                    if (this.isChatTabSelected()) {
                        webimJQuery('.chat_and_info_panel').show();
                        this.updateChatAndInfoPanel();
                        return;
                    }

                    if (this.isCobrowsingTabSelected()) {
                        webimJQuery('.cobrowsing_panel').show();
                        this.updateCobrowsingPanel();
                    }
                }
            }
        }
    },

    updateChatAndInfoPanel: function() {
        var session = this.selectedSession;
        this.setChooseVisitorPanelShown(false);
        var sessionPanelClass;
        if (session.chat) {
            var assignedToAnotherOperator = this.selectedSession.chat.operator && this.selectedSession.chat.operator.id != wm.operatorId;
            var state = session.chat.state;
            if (assignedToAnotherOperator) {
                sessionPanelClass =
                    state == 'offline_process' || state == 'offline_queue' ?
                        'state_offline_process_by_other' : 'state_chatting_with_other';
            } else {
                sessionPanelClass =
                    state == 'queue' ? 'state_queue' :
                    state == 'offline_queue' ? 'state_offline_queue' :
                    state == 'offline_process' ? 'state_offline_process' :
                    state == 'closed_by_operator' ? 'state_closed_by_operator' :
                    state == 'closed' ? 'state_idle' :
                    state == 'invitation' ? 'state_chat_invitation' : 'state_chatting' ;
            }
        } else {
            sessionPanelClass = session.invitationState == 'showing' || session.invitationState == 'showing-auto' || session.invitationState == 'showing-by-ulr-param' ?
                'state_invitation' : 'state_idle';
        }

        webimJQuery('.session_panel')
            .removeClass('state_idle').removeClass('state_invitation').removeClass('state_queue').removeClass('state_chatting').removeClass('state_closed_by_operator')
            .removeClass('state_chatting_with_other').removeClass('state_offline_queue').removeClass('state_offline_process').removeClass('state_offline_process_by_other').removeClass('state_chat_invitation')
            .addClass(sessionPanelClass);

        if (!session.visitor.fields.email && !session.pushToken) {
            webimJQuery('.session_panel').addClass('responding_not_available');
        } else {
            webimJQuery('.session_panel').removeClass('responding_not_available');
        }
        if (session.pushToken) {
            webimJQuery('.session_panel').addClass('session_has_pushtoken');
        } else {
            webimJQuery('.session_panel').removeClass('session_has_pushtoken');
        }

        var label = '';
        var message = '';
        switch (session.invitationState) {
            case 'showing':
                label = resources.operator.label.showing;
                message = session.invitation.message;
                break;
            case 'showing-auto':
                label = resources.operator.label.showing_auto;
                message = session.invitation.message;
                break;
            case 'idle-after-chat':
                label = resources.operator.label.idle_after_chat;
                break;
        }
        webimJQuery('.session_panel .session_state_label').text(label);
        webimJQuery('.session_panel .invitation_text').text(message);

        webimJQuery('.chat_panel .dialog .current_chat').html('');
        webimJQuery('.chat_panel .dialog .previous_chat').remove();

        if (session.local.previousChats) {
            for (var chatIdx in session.local.previousChats) {
                this.addPreviousChat(session.local.previousChats[chatIdx]);
            }
        }
        if (session.chat) {
            for (var i in session.chat.messages) {
                this.doAddMessage(session.chat.messages[i], false,  webimJQuery('.chat_panel .dialog .current_chat'), true);
            }
            //TODO move to some method
            for ( var i in session.local.unconfirmedMessages) if (session.local.unconfirmedMessages.hasOwnProperty(i)) {
                var unconfirmedMsg = session.local.unconfirmedMessages[i];
                var msgElement = webimJQuery('#' + unconfirmedMsg.clientSideId);
                if (msgElement.length) {
                    if (unconfirmedMsg.pendingChange) {
                        this.setMessageStatus(msgElement, 'unconfirmed');
                        if (unconfirmedMsg.pendingChange.deleted) {
                            webimJQuery(msgElement).addClass('deleting');
                        } else {
                            webimJQuery('.message_text', msgElement).html(webimTools.prepareChatMessageHtml(unconfirmedMsg.pendingChange.text));
                        }
                    }
                } else {
                    if (!unconfirmedMsg.pendingChange.deleted) {
                        this.addUnconfirmedMessageDiv(unconfirmedMsg.pendingChange.text, unconfirmedMsg.clientSideId);
                    }
                }
            }

            if (session.chat.state == 'closed') {
             webimJQuery('.chat_panel .dialog .previous_chats_line').css('display', 'block');
            }
            this.doSetVisitorTyping(session.chat.visitorTyping);
            this.setVisitorMessageDraft(session.id, session.chat.visitorMessageDraft);
        }

        webimJQuery('.dialog .no_chat_to_load').css('display', this.selectedSession.local.hasAnotherPrevChatToLoad ? 'none' : 'block');

        if (session.local.previousChats.length == 0) {
            webimJQuery('.chat_panel .dialog .previous_chats_line').css('display', 'none');
        }

        var disableMessageControls = session.chat && session.chat.offline && !session.visitor.fields.email && !session.pushToken;
        webimJQuery('.chat_panel .chat_message_textarea').attr('disabled', disableMessageControls ? 'true' : null);

        this.updatePrevChatsCount(session);
        this.doSetChatId(session);

        this.setVisitorId(session);

        webimJQuery('.dialog #prev_chats_count').attr('href', '/webim/operator/history.php?show_empty=1&q=' + session.visitor.id);

        this.updateVisitorContactInfo(session.visitor);

        var geo = session.ipInfo.geo;
        if (geo != null) {
            webimJQuery('.visit_info_panel #visit_location').text((geo.city ? geo.city + ', ' : '') + geo.country_name)
                    .attr('href', geo.latitude && geo.longitude ? 'http://maps.google.com/maps?q=' + geo.latitude + ', ' + geo.longitude : '');
        } else {
            webimJQuery('.visit_info_panel #visit_location').text('').attr('href', '');
        }
        webimJQuery('.visit_info_panel #visit_host').text(typeof session.ipInfo.host != 'undefined' && session.ipInfo.host ? session.ipInfo.host : '');
        webimJQuery('.visit_info_panel #visit_ip_addr').text(session.ip);
        webimJQuery('.visit_info_panel #visit_whois_link').attr('href', 'https://www.nic.ru/whois/?query=' + session.ip);

        this.updateVisitorBrowserInfo(session);

        var landingInfo = session.landingInfo;
        var landingPage = landingInfo.landingPage;

        if (landingPage.url) {
            webimJQuery('.visit_info_panel #visit_landing_page').html('<a id="visit_landing_page_url" href="#" target="_blank" rel="nofollow noopener" class="hide_if_empty"></a>');
            webimJQuery('.visit_info_panel #visit_landing_page_url').attr('href', landingPage.url).text(landingPage.title);
        } else if (landingPage.title) {
            webimJQuery('.visit_info_panel #visit_landing_page').html('<span id="visit_landing_page_title" class="hide_if_empty"></span>');
            webimJQuery('.visit_info_panel #visit_landing_page_title').text(landingPage.title);
        }

        if (landingPage.referer) {
            var refererElement = webimJQuery('.visit_info_panel #visit_referer').attr('href', landingPage.referer);
            if (landingInfo.search) {
                var html = '<img src="/webim/images/icons/' + landingInfo.search.engine + '.ico"> <span></span>';
                refererElement.html(html);
                webimJQuery('span', refererElement).text(landingInfo.search.search_text);
            } else {
                refererElement.text(webimTools.cutString(landingPage.decodedReferer, 70));
            }
        } else {
            var refererElement = webimJQuery('.visit_info_panel #visit_referer').attr('href', '').text('');
        }
        webimJQuery('.visit_info_panel #visit_referer');

        var visitMarks = '';
        for (var prop in landingInfo.marks) {
            visitMarks += (visitMarks.length > 0 ? ', ' : '') + landingInfo.marks[prop];
        }
        webimJQuery('.visit_info_panel #visit_referer_marks').text(visitMarks);

        this.updateOnSiteTotalTime(session.onSite);

        this.updateVisitDetailsTable(session);

        webimJQuery('.visit_info_panel #visited_pages').html('');

        for (var i in session.pages) {
            this.doAddPage(session.pages[i]);
        }
        this.updateVisitedPagesDivs();

        if (this.isChatTabSelected()) {
            webimJQuery('.session_panel').css('display', 'block');
            webimJQuery('.session_panel textarea:visible:first').focus();
        }

        this.updateDialogOuterBottom();

        var draft = this.selectedSession.local.messageDraft;

        if (draft) {
            if (draft.messageClientSideId) {
                this.updateEditingModeStatus(true, draft.messageClientSideId);
            }
            webimJQuery('.session_panel textarea:visible').val(draft.text);
            this.selectedSession.local.messageDraft = null;
        } else if (!session.chat) {
            webimJQuery('.session_panel textarea:visible').val(webimJQuery('#answer_templates_popup li a').first().data('answerText'));
        }
        this.highlightErrorsInMessage();
        this.updateEmptySpaceDivHeight();
        this.scrollDown(false);
        this.updateOperatorHints(this.selectedSession.id);
        if (visitorListData.idToOperator[wm.operatorId]['roles'] == 'admin' && session.chat) {
            webimJQuery('.operator_note').show();
        } else if (visitorListData.idToOperator[wm.operatorId]['roles'] == 'admin'){
            webimJQuery('.operator_note').hide();
        }
        this.updateIdentificationFields(this.selectedSession.visitor);
    },

    updateDialogOuterBottom: function() {
        webimJQuery('.chat_panel .dialog_outer').css('bottom', webimJQuery('.chat_panel .input_panel').outerHeight() + 5);
    },

    updateEmptySpaceDivHeight: function() {
        if (this.selectedSession) {
            var emptyDiv = webimJQuery('.dialog .empty_space_div');
            var height = webimJQuery('.dialog').height() - webimJQuery('.dialog ' + (this.selectedSession.local.previousChats ? '.previous_chats_line' : '.no_chat_to_load')).outerHeight(true) - webimJQuery('.dialog .current_chat').outerHeight(true);
            height = height < 0 ? 0 : height;
            emptyDiv.css('height', height);
        }
    },

    updatePrevChatsCount: function(session) {
        counts = session.prevChatsCount;

        all_chats = counts['all_chats'];
        this.updateSessionItemInvitationInfo(webimJQuery('.visit_session.' + session.id), session);
    },

    updateVisitorNumber: function(session) {
        var number = session.visitorNumber === null ? '' : '[' + session.visitorNumber + ']';
        webimJQuery('.visitor_number', webimJQuery('.visit_session.' + session.id)).text(number);
    },

    checkIfVisitorNameIsDefault: function(name) {
        for (var lang in resources.default_visitor_names) {
            if (name == resources.default_visitor_names[lang]) {
                return true;
            }
        }
        return false;
    },

    updateVisitorContactInfo: function(visitor) {
        webimJQuery('.visit_info_panel .visitor_contact_info_table .hide_if_empty').text('');
        var empty = true;
        for (var fieldName in visitor.fields) {

            if (visitor.fields[fieldName] == null) {
                continue
            }

            var wrp = webimJQuery('.visit_info_panel #visitor_' + fieldName);
            if (!wrp.length) {
                continue;
            }

            var value = visitor.fields[fieldName];
            if (fieldName == 'name' && (this.checkIfVisitorNameIsDefault(value))) {
                value = '';
            }

            if (fieldName == 'id') {
                this.updateVisitorCrmUrl(value);
            }

            if (value != '') {
                empty = false;
            }

            wrp.html(webimTools.escapeHtml(value).replace('\n', '<br>'));
            if (fieldName == 'email') {
                wrp.attr('href', 'mailto:' + visitor.fields[fieldName]);
            }
            if (fieldName == 'profile_url' || fieldName == 'site_url') {
                wrp.attr('href', visitor.fields[fieldName]).attr('target', '_blank').attr('rel', 'nofollow noopener');
            }
        }

        if (visitor.channelUserId) {
            webimJQuery('.visit_info_panel #visitor_channel_user_id').text(visitor.channelUserId);


            if (visitor.channelType == 'vk') {
                var url = 'https://vk.com/' + (visitor.channelUserName ? visitor.channelUserName : ('id'+visitor.channelUserId));
                webimJQuery('#visitor_vk_profile_url').attr('href', url).text(url).attr('target', '_blank').attr('rel', 'nofollow noopener');
            }

            if (visitor.channelType == 'telegram') {
                if (visitor.channelUserName) {
                    webimJQuery('#visitor_telegram_profile_url').attr('href', 'https://telegram.me/' + visitor.channelUserName).attr('target', '_blank').attr('rel', 'nofollow noopener').text(visitor.channelUserName);
                }
            }
        }

        if (empty) {
            /* Если информации нет, скрываем таблицу и показываем только кнопку "Внести информацию..." */
            webimJQuery('#visitor_contact_info_div > .visit-info-block-wrapper').hide();
            webimJQuery('#visitor_contact_info_div > a.insert_visitor_fields').show();
            webimJQuery('#visitor_contact_info_div > a.update_visitor_fields').hide();
        } else {
            /* Иначе показываем таблицу с информацией и показываем только кнопку "Изменить информацию..." */
            webimJQuery('#visitor_contact_info_div > .visit-info-block-wrapper').show();
            webimJQuery('#visitor_contact_info_div > a.insert_visitor_fields').hide();
            webimJQuery('#visitor_contact_info_div > a.update_visitor_fields').show();
        }
        webimJQuery('.visit_details_table #vip_visitor').attr('checked', webimJQuery.inArray("vip", visitor.tags) != -1);
        this.updateVisitDetailsTable();
    },

    updateVisitorCrmUrl: function(id) {
        var template = wm.accountConfig.crm_url_template ? wm.accountConfig.crm_url_template : null;
        if (template && template.indexOf('{id}') > -1) {
            var crm_url = template.replace('{id}', id);
            webimJQuery('.visit_info_panel #visitor_crm_url').text(crm_url).attr('href', crm_url);
        }
    },

    updateOnSiteTotalTime: function(onSite) {
        var totalTimeSpan = webimJQuery('.visit_info_panel #visit_total_time');
        if (onSite.value) {
            totalTimeSpan.addClass('updatable_time');
            var fake_ts = onSite.lastComeBackTs - onSite.cumulatedOnSiteTime;
            totalTimeSpan.text(webimTools.getTimeSince(fake_ts));
            totalTimeSpan.get()[0].ts = fake_ts;
        } else {
            totalTimeSpan.removeClass('updatable_time');
            totalTimeSpan.text(webimTools.formatTimeInterval(onSite.cumulatedOnSiteTime));
            totalTimeSpan.get()[0].ts = null;
        }
    },

    updateVisitDetailsTable: function(session) {
        webimJQuery('.visit_info_panel table tr').show();
        webimJQuery('.hide_if_empty:empty').parents('.visit_info_panel table tr').hide();

        if (session && session.chat && session.chat.offline) {
            webimJQuery('#visit_total_time').parents('.visit_details_table tr').hide();
        }
    },

    browserIcons: {
        'Firefox' : '/webim/images/icons/firefox.ico',
        'Chrome' : '/webim/images/icons/chrome.png',
        'Yandex Browser' : '/webim/images/icons/yandex-browser.png',
        'Opera' : '/webim/images/icons/opera.ico',
        'Safari' : '/webim/images/icons/safari.png',
        'IE' : '/webim/images/icons/ie.png',
        'Edge' : '/webim/images/icons/ie.png',
        'Opera Mini' : '/webim/images/icons/opera_mini.png',
        'Chromium' : '/webim/images/icons/chromium.png'
    },

    platformIcons: {
        'Linux' : '/webim/images/icons/linux.png',
        'Ubuntu' : '/webim/images/icons/ubuntu.ico',
        'Fedora' : '/webim/images/icons/fedora.png',
        'MacOSX' : '/webim/images/icons/mac.gif',
        'Mac OS X' : '/webim/images/icons/mac.gif',
        'win' : '/webim/images/icons/windows.png',
        'Windows' : '/webim/images/icons/windows.png',
        'Android' : '/webim/images/icons/android.png',
        'JAVA' : '/webim/images/icons/java.png',
        'iOS' : '/webim/images/icons/ios.png'
    },

    getBrowserInfo: function(session) {
        var browser = '';
        if (session.browser) {
            browser =  session.browser.name + ((session.browser.version[0] != 0 || session.browser.version[1] != 0) ?
                ' ' + session.browser.version[0] + "." + session.browser.version[1] : '');
        }
        return {
            browser: browser,
            browserIconSrc: session.browser ? this.getIconPathFromArrayByStringWithIconName(session.browser.name, this.browserIcons, '/webim/images/icons/none.png') : '/webim/images/icons/none.png',
            platform: session.browser ? session.browser.platform /* + ' ' + session.browser.version[0] + "." + session.browser.version[1]*/ : '',
            platformIconSrc: session.browser ? this.getIconPathFromArrayByStringWithIconName(session.browser.platform, this.platformIcons, '/webim/images/icons/none.png') : '/webim/images/icons/none.png'
        }
    },

    updateVisitorBrowserInfo: function(session) {
        if (!this.selectedSession || session.id != this.selectedSession.id) {
            return;
        }
        var bi = this.getBrowserInfo(session);
        webimJQuery('.visit_info_panel #visit_browser_icon').attr('src', bi.browserIconSrc).attr('alt', bi.browser);
        webimJQuery('.visit_info_panel #visit_browser').text(bi.browser);
        webimJQuery('.visit_info_panel #visit_platform_icon').attr('src', bi.platformIconSrc).attr('alt', bi.platform);
        webimJQuery('.visit_info_panel #visit_platform').text(bi.platform);

        this.updateVisitDetailsTable();
    },

    getIconPathFromArrayByStringWithIconName: function(stringWithName, iconPaths, defaultPath) {
        var path = defaultPath;
        if(stringWithName) {
            for (var iconName in iconPaths) {
                var iconNameReg = new RegExp(iconName, 'i')
                if (stringWithName.match(iconNameReg)) {
                    path = iconPaths[iconName];
                    break;
                }
            }
        }
        return path;
    },

    setCurrentPage: function(sessionId, page) {
        webimJQuery('.visit_session.' + sessionId + ' .current_page').css('display', page ? 'block' : 'none');
        webimJQuery('.visit_session.' + sessionId + ' .visitor_not_on_site').css('display', !page ? 'block' : 'none');
        if (page) {
            webimJQuery('.visit_session.' + sessionId + ' .current_page a').attr('href', page.url).attr('title', page.title);
            webimJQuery('.visit_session.' + sessionId + ' .current_page span').text(webimTools.cutString(page.title, 30)).attr('title', page.title);
            webimJQuery('.visit_session.' + sessionId + ' .current_page a').css('display', page.url ? 'inline' : 'none');
            if (page.highPriority) {
                webimJQuery('.visit_session.' + sessionId).addClass('high_priority');
            } else {
                if (!this.isHighPriorityVisitor(sessionId)) {
                    webimJQuery('.visit_session.' + sessionId).removeClass('high_priority');
                }
            }
        }
    },

    isHighPriorityVisitor: function(sessionId) {
        var session = visitorListData.idToVisitSession[sessionId];
        if (session) {
            return session.visitor.fields.high_priority && session.visitor.fields.high_priority == "1";
        } else {
            return false;
        }

    },

    addPage: function(page) {
        if (this.isSelected(page.sessionId)) {
            this.doAddPage(page);
            this.updateVisitedPagesDivs();
        }
    },

    delPage: function(sessionId, pageId) {
        if (this.isSelected(sessionId)) {
            webimJQuery('.visit_info_panel #visited_pages .' + pageId).remove();
            this.updateVisitedPagesDivs();
        }
    },
    updateVisitedPagesDivs: function() {
        var noPages = ! webimJQuery('.visit_info_panel #visited_pages > div').length;
        webimJQuery('.visit_info_panel #visited_pages_container').css('display', noPages ? 'none': 'block');
        webimJQuery('.visit_info_panel #no_visited_pages').css('display', noPages && !(this.selectedSession.chat && this.selectedSession.chat.offline) ? 'block' : 'none');
    },

    doAddPage: function(page) {
        var pageElement = this.visitedPageElementTemplate.clone();
        pageElement.addClass(page.id);
        pageElement.data('page-id', page.id);
        webimJQuery('.visited_page_title', pageElement).text(page.title);
        if (!page.url) {
            webimJQuery('.teleport', pageElement).css('display', 'none');
            webimJQuery('.visited_page_separator', pageElement).css('display', 'none');
        } else {
            webimJQuery('.visited_page_url', pageElement).attr('href', page.url).text(webimTools.cutString(page.url, 70));
        }
        webimJQuery('.visited_page_time', pageElement).text(webimTools.getTimeSince(page.creationTs))
                .get()[0].ts = page.creationTs;
        webimJQuery('.webim-js-teleport-show-block', pageElement).click(this.showTeleportBlock.bind(this));
        webimJQuery('.hints_container').click(this.selectOperatorHint);
        webimJQuery('.webim-js-teleport-block', pageElement).attr('page-id', page.id).hide();
        webimJQuery('.webim-js-teleport-redirect', pageElement)
            .click(this.teleportVisitorAction.bind(this));
        webimJQuery('.webim-js-teleport-block input[name="teleport_url"]', pageElement).keypress(function(event) {
                if(event.which == '13'){
                    this.teleportVisitorAction(event);
                }
            }.bind(this));
        webimJQuery('.webim-js-teleport-close-block', pageElement).click(this.hideTeleportBlock.bind(this));
        webimJQuery('.visit_info_panel #visited_pages').prepend(pageElement);
    },

    selectOperatorHint: function(e){
        if (! webimJQuery(e.target).hasClass('hint')){
            return;
        } else {
            webimJQuery('.chat_message_textarea').val(webimJQuery(e.target).text());
            webimJQuery('.chat_message_textarea').focus();
        }
    },

    removeVisitSession: function(id) {
        webimJQuery('.visit_session.' + id).remove();
        if (this.isSelected(id)) {
          this.selectSession(null);
        }
        this.updateSessionCounts();
    },

    clear: function() {
      webimJQuery('[data-widget="visitors-list"] [data-block="session-items-container"]').empty()
      webimJQuery("#visitors_list .visit_session_subsection").remove();
      webimJQuery('#visitors_list .visit_session_section').remove();
      this.updateSessionCounts();
      this.selectSession(null);
    },

    updateVisitor: function(sessionId, visitor, auth) {
        webimJQuery('.visit_session.' + sessionId + ' .visitor_name').text(visitor.fields.name);
        this.setVisitorPicture(webimJQuery('.visit_session.' + sessionId + ' .visitor_icon'), visitor, 30);
        if (this.isHighPriorityVisitor(sessionId)) {
            webimJQuery('.visit_session.' + sessionId).addClass('high_priority');
        }
        if (this.isSelected(sessionId)) {
            this.updateVisitorContactInfo(visitor);
            if (auth) {
                this.updateChatAndInfoPanel();
            }
        }
        this.updateVisitorPreviousChatLabel(sessionId);
        if (this.selectedSession && this.selectedSession.id == sessionId) {
            this.updateIdentificationFields(visitor);
        }
    },

    updateIdentificationFields: function (visitor) {
        var IdentCont = webimJQuery('#identification-container');
        var IdentBody = webimJQuery('#identification');

        if (!visitor.unservedFields) {
            webimJQuery(IdentCont).hide();
            return
        }

        var identificationFields = visitor.unservedFields;
        IdentBody.empty();
        for (var fieldKey in identificationFields) {
            if (identificationFields.hasOwnProperty(fieldKey)) {
                var tr = jQuery('<tr/>');
                var td = jQuery('<td/>', {
                    id: fieldKey+'_key',
                    text: resources.chat.overlay.identification[fieldKey]
                });
                tr.append(td);
                td = jQuery('<td/>', {
                    id: fieldKey+'_value',
                    text: identificationFields[fieldKey]
                });
                tr.append(td);
                IdentBody.append(tr);
            }
        }
        webimJQuery(IdentCont).show();
    },

    requestIdentificationKK: function() {
        onlineSupport.sendAction('request_identification', {session_id: this.selectedSession.id, identification_type: 'identification-kk'}, true);
        return false;
    },

    requestIdentificationKNPK: function() {
        onlineSupport.sendAction('request_identification', {session_id: this.selectedSession.id, identification_type: 'identification-knpk'}, true);
        return false;
    },

    onVipStatusChange: function(e) {
      var isVip = webimJQuery(e.target).attr("checked");
      onlineSupport.sendAction('set_tags',
          {'session_id': this.selectedSession.id, 'tags': isVip ? webimJQuery.toJSON(['vip']) :webimJQuery.toJSON([])},
          {
              availableOffline: true
          },
          {
              onErrorCallback: function(responseData) {
                                    webimJQuery(e.target).attr("checked", !isVip);
                                    alerts.showSimpleAlert(resources.alert.server_error);
                                }.bind(this),

              checkResponse: onlineSupport.resultIsOkResponseDataChecker,

              onOkCallback:   function(responseData) {
                                  alerts.showSimpleAlert(resources.alert.vip_status_changed);
                              }
          });
    },

    setVisitorTyping: function(sessionId, value) {
        if(this.isSelected(sessionId)) {
            this.doSetVisitorTyping(value);
        }
    },

    doSetVisitorTyping: function(value) {
        if (value) {
            webimJQuery('#visitor_typing img').show();
        } else {
            webimJQuery('#visitor_typing img').hide();
        }
    },

    setChatId: function(session) {
        if (this.isSelected(session.id)) {
            this.doSetChatId(session);
        }
    },

    doSetChatId: function(session) {
        if (session.chat && session.chat.id) {
            webimJQuery('.visit_info_panel #current_chat_id').attr('href', '/webim/operator/threadprocessor.php?threadid=' + session.chat.id).text(session.chat.id);
            webimJQuery('.visit_info_panel #current_chat_id_div').css('display',  'block' );
        } else {
            webimJQuery('.visit_info_panel #current_chat_id_div').css('display',  'none' );
        }
    },

    setVisitorId: function(session) {
        if (session.visitor && session.visitor.id) {
            webimJQuery('.visit_info_panel #current_visitor_id').attr('href', '/webim/operator/history.php?q=' + session.visitor.id).text(session.visitor.id);
            webimJQuery('.visit_info_panel #current_visitor_id_div').css('display',  'block' );
        }
        else {
            webimJQuery('.visit_info_panel #current_visitor_id_div').css('display',  'none' );
        }
    },

    setVisitorMessageDraft: function(sessionId, draft) {
      if (this.isSelected(sessionId)) {
        webimJQuery('#visitor_draft').text(webimTools.tailString(draft, 50)).attr('title', draft);
        webimJQuery('#visitor_typing_outer span').css('display', draft ? 'inline' : 'none');
      }
    },

    updateTime: function() {
        var elements = webimJQuery(".updatable_time").get();
        for (var i in elements) {
            var e = elements[i];
            webimJQuery(e).html(webimTools.getTimeSince(e.ts));
        }
    },

    addMessage: function(message) {
        if (this.isSelected(message.sessionId)) {
            var msgElement = webimJQuery('#' + message.clientSideId);
            if (message.kind == 'operator' && message.clientSideId && message.authorId == wm.operatorId && msgElement.length) {
//                this.confirmMessage(message.clientSideId);
            } else {
                this.doAddMessage(message, this.isChatScrolledToBottom(), webimJQuery('.chat_panel .dialog .current_chat'), true);
                this.updateEmptySpaceDivHeight();
            }
        }

        if (message.kind == 'visitor') {
            var element = webimJQuery('.visit_session.' + message.sessionId);
            this.setLastMessage(element, message);
        } else if (message.kind == 'operator') {
            var element = webimJQuery('.visit_session.' + message.sessionId);
            this.setLastMessage(element, message);
        }
    },

    deleteMessage: function(sessionId, clientSideId) {
        if (this.isSelected(sessionId)) {
            webimJQuery('.author_message#'+clientSideId).fadeOut(400, function() {
                webimJQuery('.author_message#'+clientSideId).remove();
                this.updateEmptySpaceDivHeight();
            }.bind(this));
        }

        this.setLastMessageForSession(sessionId);
    },

    editMessage: function(msg, sessionId) {
        if (this.isSelected(sessionId)) {
            var msgElement = webimJQuery('#' + msg.clientSideId);
            if (webimJQuery(msgElement).hasClass('unconfirmed')) {
                return;
            }
            if (msg.kind == 'action_request') {
                this.prepareActionRequestMessage(msg, msgElement);
            } else {
                webimJQuery('.message_text', msgElement).html(webimTools.prepareChatMessageHtml(msg.text));
            }
        }


        this.setLastMessageForSession(sessionId);

    },

    getLastMessage: function(chat) {
        var result = null;
        if (chat) {
            for (var i = chat.messages.length - 1; i >= 0; i--) {
                m = chat.messages[i];
                if (m) {
                    if (m.kind == 'visitor') {
                        result = m;
                        break;
                    } else if (m.kind == 'operator') {
                        result = m;
                        break;
                    }
                }
            }
        }
        return result;
    },

    setLastMessage: function(sessionItemElement, message) {
        webimJQuery('.visitor_message_icon', sessionItemElement).css('display', message && message.kind == 'visitor' ? 'block' : 'none');
        webimJQuery('.operator_message_icon', sessionItemElement).css('display', message && message.kind == 'operator' ? 'block' : 'none');
        var text = '';
        if (message) {
            text = webimTools.escapeHtml(message.text);
            if (message.data && message.data.markdowns) {
                for (var i in message.data.markdowns) {
                    text = webimTools.replaceMarkdownWithText(message.data.markdowns[i], text, webimTools.markdownRegExps[message.data.markdowns[i]]);
                }
            }
        }
        webimJQuery('.last_author_message div', sessionItemElement).html(message ? webimTools.replaceEmojiWithImage(webimTools.cutString(text, 70)) : '').attr('title', text);
    },

    setLastMessageForSession: function(sessionId) {
        var session = visitorListData.idToVisitSession[sessionId];
        var sessionItemElement = webimJQuery('.visit_session.' + sessionId);
        this.setLastMessage(sessionItemElement, this.getLastMessage(session.chat))
    },

    updateSessionDepartment: function(session) {
        var itemElement = webimJQuery('.visit_session.' + session.id);
        this.setSessionDepartment(itemElement, session);
        if (session == this.selectedSession) {
            this.prompter.initAnswers(session.departmentKey);
        }
    },

    setSessionDepartment: function(sessionItemElement, session) {
        webimJQuery('.department', sessionItemElement).text(session.shownDepartmentName);
    },

    setCurrentOperatorName: function(sessionItemElement, operator) {
//        webimJQuery('.current_operator', sessionItemElement).text(operator ? operator.fullname : '');
        var imgWrp = webimJQuery('.operator_avatar', sessionItemElement);
        this.setOperatorAvatarAsBackground(imgWrp, operator, 30);
        imgWrp.attr('title', operator ? visitorListData.idToOperator[operator.id].fullname : '');
        if (operator) {
            sessionItemElement.addClass('operator-assigned');
        } else {
            sessionItemElement.removeClass('operator-assigned');
        }
    },

    setOperatorAvatarAsBackground: function(img, operator, size) {
        var sizeSuffix = '-' + size + 'x' + size;
        var url;

        if (operator && operator.avatar) {
            var idx = operator.avatar.lastIndexOf('.');
            url = operator.avatar.substr(0, idx) + sizeSuffix + operator.avatar.substr(idx);
        } else {
            url = '/webim/images/default-operator-avatar' + sizeSuffix + '.gif';
        }
        img.css('background-image', 'url(' + url + ')');
    },

    setVisitorPicture: function(wrp, visitor, size) {
        if ('avatar_url' in visitor.fields) {
            wrp.attr('src', '/webim/images/free.gif')
                .addClass('visitor_avatar')
                .css('background', '#fff url(' + visitor.fields['avatar_url'] + ') no-repeat center')
                .css('background-size', 'cover');
        } else {
            wrp.css('background', visitor.icon.color)
                .attr('src', '/webim/images/vicons/' + (visitor.banned ? 'banned' : visitor.icon.shape)  + '-' + size + 'x' + size + '.png');
            if (visitor.banned) {
                wrp.attr('title', resources.system.icon.blocked_visitor);
            }
        }
    },

    updateSessionActualTime: function(session) {
        this.updateSessionActualTime_(webimJQuery('.visit_session.' + session.id), session);
    },

    isChattingWithOperatorTimerVisible: function(session) {
        return wm.accountConfig["chatting_timer"] && session.chat && session.chat.state == 'chatting' &&
            (session.chat.operator.id == wm.operatorId || visitorListData.idToOperator[wm.operatorId]["roles"] != "operator")
    },

    updateActualTimerPosition : function(wrp, session) {
        if (this.isChattingWithOperatorTimerVisible(session)) {
            wrp.css('top', '26px');
        } else {
            if(wm.accountConfig.section_table_view) {
                wrp.css('top', '2px');
            } else {
                wrp.css('top', '3px');
            }
        }
    },

    updateChattingWithOperatorTimer: function(sessionItemElement, session) {
        if (this.isChattingWithOperatorTimerVisible(session)){
            var wrp = webimJQuery('.operator_chatting_time', sessionItemElement);
            var ts = (session.chat.lastOperatorAssignedTs > session.chat.stateModifiedTs ? session.chat.lastOperatorAssignedTs : session.chat.stateModifiedTs);
            wrp.css('display', 'inline')
                .text(webimTools.getTimeSince(ts))
                .get()[0].ts = ts;
        } else {
            var wrp = webimJQuery('.operator_chatting_time', sessionItemElement);
            wrp.css('display', 'none');
        }
        this.updateActualTimerPosition(webimJQuery('.actual_time', sessionItemElement), session);
    },

    updateSessionActualTime_: function(sessionItemElement, session) {
        var actualTime = session.actualTime;
        var wrp = webimJQuery('.actual_time', sessionItemElement);
        wrp.css('display', actualTime ? 'inline' : 'none');
        if (actualTime) {
            this.updateActualTimerPosition(wrp, session);
            if(wm.accountConfig.section_table_view) {
                wrp.attr('title', actualTime.title)
                    .text(webimTools.getTimeSince(actualTime.ts))
                    .css('color', '(255, 255, 255)')
                    .css('background-color', '(0, 0, 0)')
                    .get()[0].ts = actualTime.ts;
            }
            else {
                wrp.attr('title', actualTime.title)
                    .text(webimTools.getTimeSince(actualTime.ts))
                    .css('color', actualTime.color)
                    .css('background-color', actualTime.bgColor ? actualTime.bgColor : 'inherit')
                    .get()[0].ts = actualTime.ts;
            }
        }
    },

    scrollDown: function(animate) {
        var dialog = webimJQuery('.dialog_outer');
        if (animate) {
            this.scrollDownAnimationRunning = true;
            dialog.stop().animate({ scrollTop: dialog.prop("scrollHeight") }, 'slow', function() {
                this.scrollDownAnimationRunning = false;
            }.bind(this));
            //dialog.scrollTop(dialog[0].scrollHeight);
        } else {
            dialog.scrollTop(dialog.prop("scrollHeight"));
            //dialog.scrollTop(dialog[0].scrollHeight);
        }
    },

    doAddMessage: function(message, scrollDown, chatDivWrp, currentChat) {
        var authorMessage = message.kind == 'visitor' || message.kind == 'file_visitor' || message.kind == 'operator' || message.kind == 'cont_req' || message.kind == 'file_operator' || message.kind == 'operator_note';

        var messageElement = null;

        if (authorMessage) {
            messageElement = this.authorMessageTemplate.clone();
        } else if (message.kind == 'action_request') {
            messageElement = this.actionRequestMessageTemplates[message.data['subKind']].clone();
        } else {
            messageElement = this.systemMessageTemplate.clone();
        }

        messageElement.addClass('kind_' + message.kind);

        if (message.data && message.data['subKind']) {
            messageElement.addClass('sub-kind-' + message.data['subKind']);
        }

        var messageText;
        if (message.kind == 'contacts') {
            var visitor = webimJQuery.evalJSON(message.text);
            messageText = resources.system.visitor_contacts;
            var first = true;
            for (var fieldName in visitor) {
               if (visitor[fieldName]) {
                 messageText += (first ? ' ' : ', ') + resources.visitor_fields[fieldName] + ': ' + webimTools.escapeHtml(visitor[fieldName]);
                 first = false;
               }
            }
        } else if (message.kind == 'file_operator') {
            var fileData = webimJQuery.evalJSON(message.text);
            var fileUrl = '/l/o/download/' + fileData.guid + '/' +  encodeURIComponent(fileData.filename);
            var linkContent = fileUrl.match(/\.(png|jpg|jpeg|gif)$/i)
                ? '<img class="webim_chat_image_preview" src="'+fileUrl+'?thumb=web">'
                : webimTools.escapeHtml(fileData.filename);
            messageText = resources.system.file_sent_by_visitor + ' <a href="' + fileUrl + '" class="webim_download" target="_blank">' + linkContent + '</a>';
        } else if (message.kind == 'file_visitor') {
            var fileData = webimJQuery.evalJSON(message.text);
            var fileUrl = '/l/o/download/' + fileData.guid + '/' + encodeURIComponent(fileData.filename);
            var linkContent = fileUrl.match(/\.(png|jpg|jpeg|gif)$/i)
                ? '<img class="webim_chat_image_preview" src="'+fileUrl+'?thumb=web">'
                : webimTools.escapeHtml(fileData.filename);
            messageText = resources.system.file_sent_by_visitor + ' <a href="' + fileUrl + '" class="webim_download" target="_blank">' + linkContent + '</a>';
        } else if (message.kind == 'action_request') {
            // TODO customization of action_request message somewhere...
            messageElement = this.prepareActionRequestMessage(message, messageElement);
        } else {
            messageText = webimTools.prepareChatMessageHtml(message.text, message.data);
        }
        if (messageText) {
            webimJQuery(".message_text", messageElement).html(messageText);
        }

        if (message.kind == 'operator_note') {
            var icon = "<img class='webim_chat_note_image' src='/webim/images/icons/note.png' alt='note'>";
            webimJQuery(".message_header", messageElement).prepend(webimJQuery(icon));
        }
//        webimJQuery(".message_text", messageElement).html(webimTools.prepareChatMessageHtml(message.text));

        if (authorMessage) {
            webimJQuery(".author_name", messageElement).text(message.name);
            if (message.kind == 'visitor' || message.kind == 'file_visitor') {
                this.setVisitorPicture(webimJQuery(".author_icon img", messageElement), this.selectedSession.visitor, 40);
            } else {
                webimJQuery(".author_icon img", messageElement).remove();
                this.setOperatorAvatarAsBackground(webimJQuery(".author_icon", messageElement), visitorListData.idToOperator[message.authorId], 40);
            }
        }
        webimJQuery(".message_time", messageElement).text(webimTools.formatTime(message.ts));

        chatDivWrp.append(messageElement);

        if (currentChat) {
            if (message.clientSideId) {
                messageElement.attr('id', message.clientSideId);
            }

            if (message.kind == 'operator') {
                messageElement.attr('op-id', message.authorId);
                if (message.authorId == wm.operatorId) {
                    messageElement.addClass('confirmed');
                    this.bindMessageActionHandlers(messageElement);
                }
            }
        }

        webimJQuery.colorbox && webimJQuery('a.webim_chat_image_preview_link').colorbox({
            rel: '.webim_chat_image_preview',
            width: "600px",
            title: function(){
              var url = webimJQuery(this).attr('href');
              return '<a href="' + url + '" target="_blank" rel="nofollow noopener">' + resources.image_open_text + '</a>';
            }
          }
        );

        if (scrollDown && message.kind != 'info' && message.kind != 'for_operator') {
            this.scrollDown(true);
        }
    },

    prepareActionRequestMessage: function(message, element) {
        if (message.data['subKind'] == 'buttons') {
            this.prepareButtonsActionRequestMessage(message, element);
        }
        return element;
    },

    prepareButtonsActionRequestMessage: function (message, element) {
        switch (message.data['state']) {
            case 'pending':
            case 'completed':
                webimJQuery('.message_text', element).text(message.text);
                break;
            case 'ignored':
                webimJQuery('.message_text', element).text(resources.chat.custom_action_request.buttons.ignored);
                break;
        }
    },

    setChat: function(sessionId, chat) {
        this.updateChatState(sessionId);
        var itemElement = webimJQuery('.visit_session.' + sessionId);
        this.setLastMessage(itemElement, this.getLastMessage(chat));
        this.setCurrentOperatorName(itemElement, chat ? chat.operator : null);
    },

    setChatOperator: function(sessionId, operator) {
        this.updateChatState(sessionId);
        var itemElement = webimJQuery('.visit_session.' + sessionId);
        this.setCurrentOperatorName(itemElement, operator);
        this.sendChatReadByOperator(this.selectedSession);
        if (this.selectedSession && this.selectedSession.id == sessionId) {
            if (operator && operator.id == wm.operatorId && this.operatorTypingManager.typing) {
                onlineSupport.sendAction('operator_typing', {session_id: this.selectedSession.id, typing: true}, {availableOffline: true});
            }
        }
    },

    updateChatState: function(sessionId) {
        if (this.isVisitorListPanelSelected() && this.isSelected(sessionId)) {
         this.updateChatAndInfoPanel();
        }
        var session = visitorListData.idToVisitSession[sessionId];
        this.updateVisitorPreviousChatLabel(sessionId);
        this.updateChattingWithOperatorTimer(webimJQuery('.visit_session.' + session.id), session);

    },

    checkIfItNeedsAccept: function() {
        var chat = this.selectedSession.chat;
        if (chat && (chat.state == 'queue' || chat.state == 'offline_queue' || chat.operator && chat.operator.id != wm.operatorId) &&
                webimJQuery('.chat_panel .chat_message_textarea').val().length && webimJQuery('#start_typing_tip').css('display') != 'none') {
            this.accept(false);
        }
    },

    accept: function(forceConfirm) {
        var assignedToAnotherOperator = this.selectedSession.chat.operator && this.selectedSession.chat.operator.id != wm.operatorId;

        if (forceConfirm || assignedToAnotherOperator) {
            webimJQuery('.chat_panel .chat_message_textarea').blur();
            if (!wm.accountConfig.chat_intercept) {
                alerts.showSimpleAlert(resources.alert.chat_intercept);
                return;
            }

            if (alerts.isShown()) {
                return
            }

            alerts.showSimpleConfirm(resources.alert.chat_intercept_confirm, function() {
                webimJQuery('.chat_panel .chat_message_textarea').focus();
                this.sendAcceptVisitorAction(true);
            }.bind(this));
        } else {
           this.sendAcceptVisitorAction(false);
        }
        return false;
    },

    sendAcceptVisitorAction: function(confirmed) {
        webimJQuery('#start_typing_tip').css('display', 'none');

        var availableOffline = wm.accountConfig.auto_assign;
        onlineSupport.sendAction('accept_visitor', {'session_id': this.selectedSession.id, 'confirmed': confirmed},
            {
                availableOffline: availableOffline
            },
            {
                onErrorCallback: function(responseData) {
                                        var response = webimJQuery.evalJSON(responseData);
                                        if ('error' in response && response.error == 'confirmation_required') {
                                            this.accept(true);
                                        }
                                    }.webimBind(this),

                checkResponse: onlineSupport.resultIsOkResponseDataChecker
            });
    },

    onSendMessage: function(event) {
        if (this.useSpellChecker) {
            (!wm.accountConfig.disable_spell_check && (webimTools.storage.get('WEBIM_SPELL_CHECK_AUTO', true) || wm.accountConfig.spell_check_force))// && useSpellChecker)
                ? this.checkSpelling()
                : this.sendMessage(event);
        } else {
            this.sendMessage(event);
        }
    },

    sendMessage: function(e) {
        var messageText = webimJQuery('.chat_panel .chat_message_textarea').val();
        webimJQuery(".chat_message_textarea").attr('disabled', false);

        var chat = this.selectedSession.chat;
        if (!messageText.length || chat && chat.operator && chat.operator.id != wm.operatorId) {
            return false;
        }
        if (messageText.length > 32000) { //33000 characters long message can't fit into db field (if every character is 2-byte character)
            alert(resources.alert.max_text_length);
            return false;
        }
        webimJQuery('.chat_panel .chat_message_textarea').val('').trigger('send_message');

        var clientSideId = webimTools.guid();

        visitorListUI.addUnconfirmedMessageDiv(messageText, clientSideId);
        this.selectedSession.sendMessage(messageText, clientSideId);

        this.operatorTypingManager.setNotTyping();
        return false;
    },

        setMessageStatus: function(msgElement, newStatus) {
            webimJQuery(msgElement).removeClass('confirmed');
            webimJQuery(msgElement).removeClass('unconfirmed');
            webimJQuery(msgElement).addClass(newStatus);
    },

    addUnconfirmedMessageDiv: function(text, clientId) {
        var messageElement = this.authorMessageTemplate.clone();

        messageElement.addClass('kind_operator');
        messageElement.attr('id', clientId);
        messageElement.attr('op-id', wm.operatorId);

        this.setMessageStatus(messageElement, 'unconfirmed');

        var operator = visitorListData.idToOperator[wm.operatorId];
        webimJQuery(".message_text", messageElement).html(webimTools.prepareChatMessageHtml(text, {'markdowns': webimTools.checkMarkdowns(text)}));
        webimJQuery(".author_name", messageElement).text(operator.fullname);

        webimJQuery(".author_icon img", messageElement).remove();
        this.setOperatorAvatarAsBackground(webimJQuery(".author_icon", messageElement), operator, 40);

        webimJQuery(".message_time", messageElement).text(webimTools.formatTime(new Date() / 1000));
        webimJQuery(".chat_panel .current_chat").append(messageElement);

        this.bindMessageActionHandlers(messageElement);

        this.updateEmptySpaceDivHeight();

        this.scrollDown(true);

    },

    confirmMessage: function(clientId) {
        var msgElement = webimJQuery('.author_message#' + clientId);
        this.setMessageStatus(msgElement,'confirmed');
    },

    deleteUnconfirmedMessage: function(clientId, sessionId) {
        if (this.selectedSession.id == sessionId) {
            var msgElement = webimJQuery('#' + clientId);
            webimJQuery(msgElement).hide();
        }
    },

    rollbackMessageToConfirmedState: function(clientId, sessionId, confirmedState) {
       if (this.selectedSession.id == sessionId) {
            var msgElement = webimJQuery('#' + clientId);
            if (!confirmedState) {
                this.deleteUnconfirmedMessage(clientId, sessionId);
            } else {
                webimJQuery('.message_text', msgElement).html(webimTools.prepareChatMessageHtml(confirmedState.text));
            }
           this.setMessageStatus(msgElement, 'confirmed');
       }
    },

    bindMessageActionHandlers: function(msgElement) {
        webimJQuery(msgElement).hover(
            function() {
                if (this.isMessageCanBeEdit()) {
                    webimJQuery(".message_actions", msgElement).stop(true,true).fadeIn();
                }
        }.bind(this),
            function() {
                webimJQuery(".message_actions", msgElement).stop(true,true).fadeOut();
            }.bind(this));

        webimJQuery(".edit", msgElement).click(this.startEditMode.bind(this));
        webimJQuery(".delete", msgElement).click(this.onDeleteMessage.bind(this));

        webimJQuery(".edit_chat_message", msgElement).click(this.onEditMessage.bind(this));
        webimJQuery(".cancel_editing_message", msgElement).click(this.cancelEditing.bind(this));
    },

    startEditMode: function(click, element) {
        if (!wm.accountConfig['message_editing']) {
            return;
        }
        if (click) {
            var msgElement = webimJQuery(click.target).parents()[click.target.tagName == "A" ? 3 : 4];
        } else if (element) {
            var msgElement = element;
        } else {
            return;
        }
        var clientSideId = webimJQuery(msgElement).attr('id');
        var text = webimJQuery('.message_text', msgElement).text();
        this.updateEditingModeStatus(true, clientSideId);

        webimJQuery('.chat_panel .chat_message_textarea').val(text);
        webimJQuery('.chat_panel .chat_message_textarea').focus();
        if (click) {
            click.preventDefault();
        }
    },

    onEditMessage: function(e) {
        if (!this.messageEditing.active || !this.messageEditing.msgId) {
            return;
        }
        var msgElement = webimJQuery('.author_message#' + this.messageEditing.msgId);
        var oldText =  webimJQuery('.message_text', msgElement).text();
        var newText = webimJQuery('.chat_panel .chat_message_textarea').val();

        if (newText != oldText) {
            this.setMessageStatus(msgElement, 'unconfirmed');
            this.selectedSession.editMessage(newText, this.messageEditing.msgId);
            webimJQuery('.message_text', msgElement).html(webimTools.prepareChatMessageHtml(newText));
        }

        this.cancelEditing();
        e.preventDefault();
    },

    cancelEditing: function() {
        this.updateEditingModeStatus(false);
        webimJQuery('.chat_panel .chat_message_textarea').val('');

    },

    onDeleteMessage: function(e) {
        var msgElement = webimJQuery(e.target).parents()[e.target.tagName == "A" ? 3 : 4];
        this.setMessageStatus(msgElement, 'unconfirmed');
        webimJQuery(msgElement).addClass('deleting');

        var clientSideId = webimJQuery(msgElement).attr('id');

        var msgText = webimJQuery('.message_text', msgElement).text();
        this.selectedSession.deleteMessage(msgText, clientSideId);
        e.preventDefault();
    },

    updateEditingModeStatus: function(status, clientSideId) {
        if (this.messageEditing.active = status) {
            this.messageEditing.msgId = clientSideId;
            webimJQuery('.chat-mode.buttons_line').hide();
            webimJQuery('.template-and-spellcheck-line .answer_templates').hide();
            webimJQuery('.edit-mode.buttons_line').show();
        } else {
            this.messageEditing.msgId = null;
            webimJQuery('.chat-mode.buttons_line').show();
            webimJQuery('.template-and-spellcheck-line .answer_templates').show();
            webimJQuery('.edit-mode.buttons_line').hide();
        }
    },

    isCobrowsingTabSelected: function() {
            return webimJQuery('.show_cobrowsing_tab').hasClass('selected') && !webimJQuery('.operator_chat_selector').hasClass('selected');
    },


    isChatTabSelected: function() {
            return webimJQuery('.show_chat_and_info_tab').hasClass('selected') && !webimJQuery('.operator_chat_selector').hasClass('selected');
    },

    selectTab: function(tabName) {
        webimJQuery('.chat_cobrowsing_selector > *').each(function(i, e) {
            webimJQuery(e).removeClass('selected');
        });
        webimJQuery('.chat_cobrowsing_selector .show_'+ tabName +'_tab').addClass('selected');


        if (tabName == 'chat_and_info') {
            this.sendChatReadByOperator(this.selectedSession);
        }

        this.updateMainPanel();
        return false;
    },

    updateCobrowsingPanel: function() {
      if (this.selectedSession) {
          webimJQuery('.cb_view').hide();
          if (this.selectedSession.chat && this.selectedSession.chat.offline) {
              webimJQuery('.close_cobrowsing_button').hide();
              webimJQuery('.cb_view.offline_chat').show();
          } else {
              if (this.selectedSession.cobrowsingSession) {
                  if (wm.operatorId == this.selectedSession.cobrowsingSession.operatorId) {
                      this.updateCobrowsingPanelByState();
                  } else {
                      if (this.selectedSession.cobrowsingSession.state != 'disconnected') {
                          webimJQuery('.close_cobrowsing_button').hide();
                          webimJQuery('.cb_view.another_operator_cobrowsing').show();
                      } else if (visitorListData.sessionWithAliveCobrowsingId) {
                          webimJQuery('.close_cobrowsing_button').hide();
                          webimJQuery('.cb_view.another_active_cobrowsing').show();
                      } else {
                          webimJQuery('.close_cobrowsing_button').hide();
                          webimJQuery('.cb_view.not_connected').show();
                      }
                  }
              } else {
                  if (visitorListData.sessionWithAliveCobrowsingId) {
                      webimJQuery('.close_cobrowsing_button').hide();
                      webimJQuery('.cb_view.another_active_cobrowsing').show();
                  } else {
                      webimJQuery('.close_cobrowsing_button').hide();
                      webimJQuery('.cb_view.not_connected').show();
                  }
              }
          }
      }
    },

    updateCobrowsingPanelByState: function () {
        var state = this.selectedSession.cobrowsingSession.state;
        var reason = this.selectedSession.cobrowsingSession.lastStateReason;
        if (state == 'disconnected' && reason) {
            webimJQuery('.close_cobrowsing_button').hide();
            webimJQuery('.cb_view.' + reason).show();

        } else {
            webimJQuery('.cb_view.' + state).show();
            webimJQuery('.close_cobrowsing_button').show();
        }
    },

    onShowCurrentCobrowsingButton: function() {
        if (visitorListData.sessionWithAliveCobrowsingId) {
            this.selectSessionById(visitorListData.sessionWithAliveCobrowsingId);
            if (visitorListData.cobrowsingWindow && visitorListData.cobrowsingWindow.window) {
                visitorListData.cobrowsingWindow.window.focus();
            } else {
                visitorListData.cobrowsingWindow = null;
                this.updateCobrowsingWindow(this.selectedSession.cobrowsingSession);
            }
        }
        return false;
    },

    stopCobrowsing: function() {
        onlineSupport.sendAction('stop_cobrowsing', {session_id: visitorListData.sessionWithAliveCobrowsingId});
        return false;
    },

    startCobrowsing: function() {
        if (visitorListData.sessionWithAliveCobrowsingId) {
            onlineSupport.sendAction('stop_cobrowsing', {session_id: visitorListData.sessionWithAliveCobrowsingId});
        }
        onlineSupport.sendAction('start_cobrowsing', {session_id: this.selectedSession.id});
        return false;
    },

    updateCobrowsingWindow: function(cobrowsingSession) {
        if (cobrowsingSession.url.indexOf('#') != -1) {
            cobrowsingSession.url = cobrowsingSession.url.substring(0, cobrowsingSession.url.indexOf('#'));
        }
        visitorListData.cobrowsingWindow = window.open(cobrowsingSession.url + "#webimcobrowsing" + cobrowsingSession.id, 'cobrowsing_window', "");
    },

    showVisitorListPanel: function() {
        webimJQuery('.visitors_list_selector').removeClass('selected').addClass('selected');
        webimJQuery('.operator_chat_selector').removeClass('selected');
        this.updateMainPanel();
    },

    isVisitorListPanelSelected: function() {
        return webimJQuery('.visitors_list_selector').hasClass('selected');
    },

    isOperatorsChatPanelSelected: function() {
        return webimJQuery('.operator_chat_selector').hasClass('selected');
    },

    showOperatorsChatPanel: function() {
        webimJQuery('.visitors_list_selector').removeClass('selected');
        webimJQuery('.operator_chat_selector').removeClass('selected').addClass('selected');
        this.updateMainPanel();
    },

    showZendeskPopup: function(e) {
      webimJQuery('#zendesk_ticket_popup .ticket_subject').val(this.getFirstVisitorMessage());
      if (this.selectedSession.visitor.fields.email) {
        this.showPopup('#zendesk_ticket_popup', e.currentTarget);
      } else {
          if (confirm(resources.alert.contacts_req_for_ticket)) {
              this.requestContacts(e);
          } else {
              this.showPopup('#zendesk_ticket_popup', e.currentTarget);
          }
      }
    },

    showFormRequestPopup: function(e) {
        this.showPopup('#form_request_popup', e.currentTarget);
    },

    getFirstVisitorMessage: function() {
      var firstVisitorMessage = '';
      if (this.selectedSession && this.selectedSession.chat) {
        var messages = this.selectedSession.chat.messages;

        for (var i in this.selectedSession.chat.messages) {
            var message = messages[i];
            if (message.kind == 'visitor') {
                firstVisitorMessage = message.text;
                break;
            }
        }
      }
      return firstVisitorMessage;
    },

    createZendeskTicket: function() {
      var subject = webimJQuery('.zendesk_ticket_popup .ticket_subject').val();
      var description = webimJQuery('.zendesk_ticket_popup .ticket_description').val();
      onlineSupport.sendAction('create_zendesk_ticket', {session_id: this.selectedSession.id, ticket_data: webimJQuery.toJSON({subject: subject, description: description})}, {availableOffline: true});
      webimJQuery('.zendesk_ticket_popup .ticket_description').val('');
      this.hidePopups();
    },


    sendChatReadByOperator: function(session) {
        if (session &&
                !idle.idle &&
                session == this.selectedSession &&
                session.chat && session.chat.operator && session.chat.operator.id == wm.operatorId &&
                session.chat.unreadByOperatorSinceTs && this.isChatScrolledToBottom() && this.isVisitorListPanelSelected() && this.isChatTabSelected()) {
            onlineSupport.sendAction('set_chat_read_by_operator', {session_id: session.id}, {availableOffline: true});
        }
    },

    closeChat: function(e, blocking, onChatClosedCallback) {
        var providedVisitorId = this.selectedSession.visitor.fields.id;
        var chatClosedByOperatorEventParams = {
            'webimVisitorId': this.selectedSession.visitor.id,
            'providedVisitorId': providedVisitorId ? providedVisitorId : null,
            'chatId': this.selectedSession.chat.id,
            'siebelId': this.selectedSession.getvisitorCustomField('siebelId'),
            'channelId': this.selectedSession.visitor.channelId,
            'channelType': this.selectedSession.visitor.channelType,
            'channelUserId': this.selectedSession.visitor.channelUserId,
            'channelUserName': this.selectedSession.visitor.channelUserName
        };

        if (blocking === undefined) {
            blocking = false;
        }
        var target = e ? e.currentTarget : webimJQuery('.close_chat_button');

        onlineSupport.sendAction('close_chat',
            {session_id: this.selectedSession.id},
            {availableOffline: true},
            {
                onErrorCallback: function (responseData) {
                                    try {
                                        var response = webimJQuery.evalJSON(responseData);
                                        if ('result' in response) {
                                            if (response.result == 'category_has_to_be_set') {
                                                visitorListUI.showCategoryPopup(e, target, blocking, function() {this.closeChat(e, blocking, onChatClosedCallback);}.webimBind(this));
                                            } else if (response.result == 'operator_has_to_be_assigned') {
                                                this.fillManualOperatorAssignPopup(response.operators_in_chat);
                                                this.showManualOperatorAssignPopup(e, target, blocking, function() {this.closeChat(e, blocking, onChatClosedCallback); this.hidePopups();}.webimBind(this));
                                            }
                                        }
                                    } catch (e) {}
                                    return false;
                                 }.webimBind(this),
                checkResponse: onlineSupport.resultIsOkResponseDataChecker,
                onOkCallback: function(responseData) {
                                    postMessageToParent({'event': 'chatClosedByOperator', 'params': chatClosedByOperatorEventParams});
                                    if (onChatClosedCallback) {
                                        onChatClosedCallback();
                                    }
                                }.webimBind(this)
            }
        );
        return false;
    },

    onScrollHandler: function() {
        var scrl = webimJQuery('.dialog_outer').scrollTop();
        var session = this.selectedSession;
        if (session) {
            if (!this.isChatScrolledToBottom()) {
                if (!this.scrollDownAnimationRunning) {
                    webimJQuery('.dialog_outer .button.scroll_down' + (session.chat && session.chat.unreadByOperatorSinceTs ? '.new_message' : '.to_current_chat')).fadeIn();
                }
            } else {
                if (session.chat && session.chat.unreadByOperatorSinceTs) {
                    this.sendChatReadByOperator(session);
                }
                webimJQuery('.dialog_outer .button.scroll_down').stop(true, true).fadeOut();
            }
            if (scrl == 0 && session.local.hasAnotherPrevChatToLoad && !session.local.prevChatLoadError && webimJQuery('.dialog_outer')[0].scrollHeight > webimJQuery('.dialog_outer').height()) {
                webimJQuery('.dialog .throbber').css('display', 'block');
                session.loadPrevChat();
            }
        }
    },

    isChatScrolledToBottom: function() {
        var chat = webimJQuery('.dialog_outer');
        return chat.prop('scrollHeight') - chat.scrollTop() - chat.height() - webimJQuery('.empty_space_div', chat).height() < 30;
    },

    setUnreadMessageButtonText: function(session) {
        webimJQuery('.dialog_outer .button.scroll_down.new_message').text(session.chat.operator && wm.operatorId != session.chat.operator.id ?
                                                                          resources.system.chat.button.unread_by_operator + ' ' + webimTools.cutString(visitorListData.idToOperator[session.chat.operator.id].fullname, 15) + ' ⇓' :
                                                                          resources.system.chat.button.new_message);
    },

    showUnreadMessageButton: function(session) {
        if (session == this.selectedSession) {
          this.setUnreadMessageButtonText(session);
          if (webimJQuery('.dialog_outer .button' + (session.chat.unreadByOperatorSinceTs ? '.to_current_chat' :'.new_message')).css('display') == 'block') {
              webimJQuery('.dialog_outer .button.scroll_down').fadeOut();
              if (!this.isChatScrolledToBottom()) {
                  webimJQuery('.dialog_outer .button.scroll_down' + (!session.chat.unreadByOperatorSinceTs ? '.to_current_chat' :'.new_message')).fadeIn();
              }
          }
        }
    },
    updateChatPanelAfterErrorOnLoadingPrevChat: function() {
        webimJQuery('.dialog .throbber').css('display', 'none');
        webimJQuery('.dialog .chat_load_error').css('display', 'block');
    },

    reloadPrevChat: function() {
        webimJQuery('.dialog .chat_load_error').css('display', 'none');
        webimJQuery('.dialog .throbber').css('display', 'block');
        this.selectedSession.local.prevChatLoadError = false;
        this.selectedSession.loadPrevChat();
    },

    updateChatPanelAfterLoadingPrevChat: function(response) {
        if (response) {
            this.addPreviousChat(response)
        }
        if (this.selectedSession.local.previousChats.length) {
            webimJQuery('.chat_panel .dialog .previous_chats_line').css('display', 'block');
        }
        webimJQuery('.dialog .throbber').css('display', 'none');
        webimJQuery('.dialog .no_chat_to_load').css('display', this.selectedSession.local.hasAnotherPrevChatToLoad ? 'none' : 'block');
    },

    addPreviousChat: function(chat) {

      var chatElement = this.previousChatTemplate.clone();

      webimJQuery('.chat_title span', chatElement).text(webimTools.formatTime(chat.creationTs) + ': ' + resources.system.chat.previous_title);
      if (chat.id) {
          webimJQuery('.chat_title a', chatElement).attr('href','/webim/operator/threadprocessor.php?threadid=' + chat.id).text(chat.id);
          chatElement.attr('id', 'prev_chat_' + chat.id);
      }

      for (var messageIdx in chat.messages) {
          var message = chat.messages[messageIdx];
          if ((message.kind == 'operator' || message.kind == 'file_operator' || message.kind == 'cont_req') && message.authorId in visitorListData.idToOperator) {
              message.name = visitorListData.idToOperator[message.authorId].fullname;
          }
          this.doAddMessage(message, false,  webimJQuery(chatElement));
      }
      webimJQuery('.dialog .previous_chats').prepend(chatElement);
      webimJQuery('.dialog_outer').scrollTop(webimJQuery('.dialog_outer').scrollTop() + webimJQuery('.dialog .previous_chats .previous_chat#prev_chat_' + chat.id).outerHeight(true) - webimJQuery('.dialog .throbber').outerHeight(true));
    },


    inviteVisitor: function(e) {
        var messageText = webimJQuery('.chat_panel .invitation_textarea').val();
        webimJQuery('.chat_panel .invitation_textarea').val('');
        onlineSupport.sendAction('invite_visitor', {session_id: this.selectedSession.id, message: messageText},
            {
                availableOffline: false,
                numberOfRetries: 3
            },
            {
                onErrorCallback:   function() {
                                        alert(resources.alert.text_sending_error + messageText);
                                        var wrp = webimJQuery('.chat_panel .invitation_textarea');
                                        wrp.val(messageText + ' ' + wrp.val());
                                    },
                checkResponse:  function(responseData) {
                                    try {
                                        var response = webimJQuery.evalJSON(responseData);
                                        if ('result' in response && response.result == 'ok') {
                                            return true;
                                        }
                                        if ('error' in response) {
                                            if (response.error == 'operator_cant_start_chat_with_visitor_from_another_department' ||
                                                response.error == 'visitor_starting_chat_from_his_side' ||
                                                response.error == 'another_operator_in_chat') {
                                                alerts.showSimpleAlert(resources.alert[response.error]);
                                                return true;
                                            }
                                        }
                                    } catch (e) {}
                                    return false;
                                 }
            });
        return false;
    },

    requestContacts: function(e) {
        onlineSupport.sendAction('request_contacts', {session_id: this.selectedSession.id}, {availableOffline: true});
        return false;
    },

    onCheckSpellingLinkClick: function(e) {
            webimSpeller.checkSpelling(webimJQuery(".chat_message_textarea"), function(result) {
                if(result) {
                    alert(result);
                }
            });
    },

    onCheckSpellingAutoCheckboxChanged: function(e) {
        webimTools.storage.set('WEBIM_SPELL_CHECK_AUTO', e.currentTarget.checked);
        if (!e.currentTarget.checked) {
            this.removePunctuationErrorsHighlight();
        }
        // else {
            // this.checkPunctuation();
        // }
    },

	checkSpelling: function() {
        webimJQuery(".chat_message_textarea").attr('disabled', true);
        webimSpeller.checkSpelling(webimJQuery(".chat_message_textarea"), function() {
            this.sendMessage();
            webimJQuery(".chat_message_textarea").focus();
        }.bind(this));
	},

    removePunctuationErrorsHighlight: function() {
        webimJQuery('.chat_message_textarea').highlightTextarea('destroy').focus();
    },

    highlightErrorsInMessage: function() {
        if (!webimTools.storage.get('WEBIM_SPELL_CHECK_AUTO', true) && !wm.accountConfig.spell_check_force) {
            return;
        }

        this.removePunctuationErrorsHighlight();

        var data = visitorListData.idToVisitSession[this.selectedSession.id].local.punctuationErrors;
        if (!data || !data.length) {
            return;
        }

        var _ranges = [];
        for (var i = 0; i < data.length; i++) {

            _ranges.push({
                color: '#DAEBEF',
                start: data[i][0],
                length: data[i][1] - data[i][0] - 1
            });
            _ranges.push({
                color: '#FF0000',
                start: data[i][1] - 1,
                length: 1
            });
        }
        webimJQuery('.chat_message_textarea').highlightTextarea({
            ranges: _ranges
        }).focus();
    },

    // checkPunctuation: function() {
    //     if (wm.accountConfig.disable_spell_check || !webimTools.storage.get('WEBIM_SPELL_CHECK_AUTO', true) && !wm.accountConfig.spell_check_force) {
    //         return;
    //     }
    //
    //     if (!this.punctuationChecking.currentRequestSessionId) {
    //         this.punctuationChecking.needRecheck = false;
    //         this.punctuationChecking.currentRequestSessionId = this.selectedSession.id;
    //         var message = webimJQuery(".chat_message_textarea").val();
    //         var onRequestFinished = function() {
    //             this.punctuationChecking.currentRequestSessionId = null;
    //             if (this.punctuationChecking.needRecheck == true) {
    //                 this.checkPunctuation();
    //             }
    //         }.bind(this);
    //
    //         webimSpeller.checkPunctuation(message,
    //             function(data){
    //                 visitorListData.idToVisitSession[this.punctuationChecking.currentRequestSessionId].local.punctuationErrors = data;
    //                 this.highlightErrorsInMessage();
    //                 onRequestFinished();
    //             }.bind(this),
    //             onRequestFinished);
    //     } else {
    //         this.punctuationChecking.needRecheck = true;
    //     }
    // },

    banVisitor: function() {
        if (confirm(resources.alert.visitor_ban)) {
            onlineSupport.sendAction('ban_visitor', {session_id:this.selectedSession.id}, {availableOffline: true});
        }
        return false;
    },

    setChatCategory: function(e) {
        var category = webimJQuery(e.target).data('category');
        var subcategory = webimJQuery(e.target).data('subcategory');
        onlineSupport.sendAction('set_category', {session_id: this.selectedSession.id, category: category, subcategory: subcategory},
                                 {availableOffline: true}, {onOkCallback: this.onCategorySetCallback});
        return false;
    },

    hidePopups: function() {
        if (webimJQuery('#check_spelling_div').css('display') == 'block') {
            webimJQuery(".chat_message_textarea").attr('disabled', false);
            webimJQuery(".chat_message_textarea").focus();
        }
        webimJQuery('.popup').hide();
        webimJQuery('#popup_glass_pane').hide();
        webimJQuery('#blocker_popup_glass_pane').hide();
    },

    showCheckSpellingPopup: function (url, popupSelector) {
        webimJQuery(popupSelector).html('<iframe style="width: 100%; height: 100%;" id="check_spelling_iframe" name="spell_check_iframe">');
        webimJQuery('iframe#check_spelling_iframe').attr("src", url);
        var target = webimJQuery('.chat_message_textarea').get(0);
        this.showPopup(popupSelector, target);
        if (wm.accountConfig.spelling_pass_button_autofocus_and_pass_all) {
            webimJQuery('iframe#check_spelling_iframe')[0].onload = function () {
                setTimeout(function timeout() {
                    if (webimJQuery('iframe#check_spelling_iframe').contents().find('[name="ignoreAll"]').attr('disabled')) {
                        setTimeout(timeout, 100);
                    } else {
                        webimJQuery('iframe#check_spelling_iframe').contents().find('[name="ignoreAll"]').focus();
                    }
                }, 100);
            }
        }
    },
    showPopup: function(popupSelector, target, blocking, at_target) {
        if (blocking == true) {
            webimJQuery('#blocker_popup_glass_pane').show();
        } else {
            webimJQuery('#popup_glass_pane').show();
        }
        webimJQuery(popupSelector).show();

        if (blocking == true) {
            webimJQuery(popupSelector).attr('tabindex', '1'); // without this .focus() not work
            webimJQuery(popupSelector).focus();
        }

        var targetPosition = webimJQuery(target).offset();
        var popupWrp = webimJQuery(popupSelector);

        if (at_target) {
            popupWrp.css({'top': targetPosition.top, 'left': targetPosition.left});
        } else {
            popupWrp.css(targetPosition.top - 51 > popupWrp.height()
                ? {'bottom': webimJQuery(window).height() - targetPosition.top + 3, 'top': ''}
                : {'top': webimJQuery('div#menu').height() + 3, 'bottom': ''});
            popupWrp.css({'left': targetPosition.left});
        }
    },

    showCategoryPopup: function(event, target, blocking, onCategorySetCallback) {
        this.onCategorySetCallback = onCategorySetCallback;

        webimJQuery('#set_category_popup a').removeClass('selected');
        var chat = this.selectedSession.chat;
        var selector = '#set_category_popup a[data-category="' + chat.category + '"]';
        selector += chat.subcategory ? '[data-subcategory="' + chat.subcategory + '"]' : ':first';
        webimJQuery(selector).addClass('selected');

        if (webimJQuery(target).is(webimJQuery('.close_chat_button'))) {
            webimJQuery('.category-selector .chat-closed').show();
        } else {
            webimJQuery('.category-selector .chat-closed').hide();
        }
        this.showPopup('#set_category_popup', target || event.target, blocking, false);
        webimJQuery('.category-selector-container').show();
    },

    showManualOperatorAssignPopup: function(event, target, blocking, onOperatorAssignCallback) {
        this.onOperatorAssignCallback = onOperatorAssignCallback;
        this.showPopup('#manual_operator_assign_popup', target || event.target, blocking);
    },

    hideCategoryPopup: function(operatorIds) {
        webimJQuery('.category-selector-container').hide();
    },

    fillManualOperatorAssignPopup: function(operatorIds) {
        var operatorListWrapper = webimJQuery('#manual_operator_assign_popup ul.operators_list');
        operatorListWrapper.empty();
        for (var idx in operatorIds) {
            var operatorId = operatorIds[idx];
            if (operatorId in visitorListData.idToOperator) {
                var operator = visitorListData.idToOperator[operatorId];
                var operatorTemplate = this.operatorToAssignTemplate.clone();
                webimJQuery('a', operatorTemplate).text(operator.fullname).attr('href', '#').data('operator-id', operatorId).click(this.manuallyAssignChatToOperator.bind(this));
                operatorListWrapper.append(operatorTemplate);
            }
        }

    },

    manuallyAssignChatToOperator: function(e) {
        var operatorId = webimJQuery(e.currentTarget).data('operator-id');
        onlineSupport.sendAction('manually_assign_operator', {session_id: this.selectedSession.id, operator_id: operatorId},
            {
                availableOffline: true
            },
            {
                onOkCallback: this.onOperatorAssignCallback
            });
    },

    sendOperatorNoteMessage: function() {
        if (webimJQuery('.operator_note_content').val().length > 0) {
            onlineSupport.sendAction('operator_note',
                {session_id: this.selectedSession.id, message: webimJQuery('.operator_note_content').val(), 'operator_id': wm.operatorId},
                {availableOffline: true, numberOfRetries: 2},
                {
                    onErrorCallback: function (e) {
                        var error;
                        switch (webimJQuery.evalJSON(e).result){
                            case 'chat_not_owned':
                                error = resources.alert.operator_note_chat_not_owned_error;
                                break;
                            case 'no_session_chat':
                            default:
                                error = resources.alert.operator_note_no_session_chat_error;
                                break;
                        }
                        alert(error);
                    },
                    onOkCallback: function(responseData) {
                        this.hidePopups();
                    }.bind(this)
                });
        }
    },

    addHyperlink: function () {
        var value = '[' + webimJQuery('[data-type-hyperlink="name"]').val() + ']' + '(' + webimJQuery('[data-type-hyperlink="content"]').val() + ')';
        webimTools.insertAtCaret(webimJQuery('.chat_message_textarea')[0], value);
        this.hidePopups();
    },

    showSendChatToOperatorEmailPopup: function (event) {
        event && event.preventDefault();
        this.showPopup('#email_chat_to_operator_frame', event.currentTarget);
        webimJQuery('#email_chat_to_operator_frame')
            .css('max-height', webimJQuery(event.currentTarget).offset().top - 25)
            .css('overflow-y', 'auto');

        var operatorList = webimJQuery('#email_chat_operator_list');
        operatorList.html('');
        var createOnClickHandler = function(operatorId) {
            return function() {
                onlineSupport.sendAction('send_chat_to_operator_email',
                    {
                        'session_id': this.selectedSession.id,
                        'target_operator_id': operatorId
                    },
                    {
                       availableOffline: true
                    });
                this.hidePopups();
                return false;
            }.bind(this);
        }.bind(this);

        var operatorsArray = visitorListData.getOperatorsSortedByName();
        var operator;
        for (var idx in operatorsArray) {
            operator = operatorsArray[idx];
            var item = this.emailChatOperatorListItem.clone();
            webimJQuery('a', item).text(operator['fullname']).click(createOnClickHandler(operator['id']));
            operatorList.append(item);
        }
    },

    cleanRedirectVisitorPopup: function() {
        webimJQuery('#redirect_visitor_operators_list').html('');
        webimJQuery('#redirect_visitor_departments_list').html('');
        webimJQuery('#redirect_visitor_locales_list').html('');
        webimJQuery('#operators_search_field').val('');
    },

    showOperatorNotePopup: function(event) {
        webimJQuery('#operator_note_popup .operator_note_content').val('');
        this.showPopup(webimJQuery('#operator_note_popup'), event.currentTarget);
        var popupWidth = webimJQuery('#operator_note_popup').width();
        if (popupWidth < 400) { // for TCS design TODO some common solution for this kind of kostbIli
            var newLeft = webimJQuery('#operator_note_popup').position().left - (400 - popupWidth);
            webimJQuery('#operator_note_popup').css('left', newLeft + 'px');
        }
        webimJQuery('#operator_note_popup .operator_note_content').focus();
    },

    showAddHyperlinkPopup: function(event) {
        webimJQuery('[data-type-hyperlink="name"]').val('');
        webimJQuery('[data-type-hyperlink="content"]').val('');
        this.showPopup(webimJQuery('[data-type="add_hyperlink_popup"]'), event.currentTarget);
        webimJQuery('[data-type-hyperlink="name"]').focus();
    },

    showRedirectVisitorPopup: function(event) {
        this.showPopup('#redirect_visitor_popup_frame', event.currentTarget);
        webimJQuery('#redirect_visitor_popup_frame')
            .css('max-height', webimJQuery(event.currentTarget).offset().top - 150)
            .css('overflow-y', 'auto');

        this.cleanRedirectVisitorPopup();

        var onClickHandler = function(itemType, id) {
            return function () {
                onlineSupport.sendAction('redirect_visitor',
                    {
                        'session_id': this.selectedSession.id,
                        'redirect_type': itemType,
                        'redirect_id': id
                    },
                    {
                        availableOffline: true
                    },
                    {
                        onErrorCallback: function(responseData) {
                                            var response = webimJQuery.evalJSON(responseData);
                                            if (response && response['result'] && response['result'] == 'offline') {
                                                alert(resources.alert.redirect_target_offline);
                                            }
                                        }.bind(this)
                    });
                this.hidePopups();
                webimJQuery('#operators_search_field').val('');
                return false;
                }.bind(this);
        }.bind(this);

        webimJQuery('.redirect_visitor_popup').addClass('loading').removeClass('loaded');
        var request = wm.ajax.request(
            "/l/o/online-operators.php",
            {},
            function(responseData) {
                this.cleanRedirectVisitorPopup();

                for (var itemType in responseData) {
                    for (var i in responseData[itemType]) {
                        var item = responseData[itemType][i];
                        var template = this.redirectVisitorListItem.clone();
                        var text = '';
                        var id = '';
                        switch (itemType) {
                            case 'operators':
                                text = item.fullname + ' (' + resources.operator_status[item.status] + ')';
                                id = item.id;
                                break;
                            case 'departments':
                                text = item.name + ' (' + resources.operator_status[item.status] + ')';
                                id = item.key;
                                break;
                            case 'locales':
                                text = item != this.selectedSession.lang ? item : '';
                                id = item;
                                break;
                        }
                        webimJQuery('a', template).text(text).click(onClickHandler(itemType, id));
                        if (text) {
                            webimJQuery('#redirect_visitor_' + itemType + '_list').append(template);
                            webimJQuery('#operators_search_field').focus();
                            this.filterOperatorList('');
                        }
                    }
                }
                webimJQuery('.redirect_visitor_list_container').each(function(i, e) {
                    webimJQuery(e).css('display', webimJQuery('a', e).length ? 'block' : 'none');
                });
                webimJQuery('.redirect_visitor_popup').addClass('loaded').removeClass('loading');
            }.bind(this),
            function() {},
            null,
            null,
            {type: 'GET'});
        return false;
    },

    setNoUsersPanelShown: function(value)  {
        webimJQuery('.no_visitors_available').css('display', value ? 'block' : 'none');
    },

    setOperatorInOfflineModePanelShown: function(value) {
        if (value) {
            webimJQuery('.session_panel').hide();
            webimJQuery('.operator_chat_and_info_panel').hide();
        }
        webimJQuery('.operator_offline_mode').css('display', value ? 'block' : 'none');
    },

    setChooseVisitorPanelShown: function(value)  {
        var totalAlive = 0;
        for (var p in visitorListData.idToVisitSession) {
            visitorListData.idToVisitSession[p].alive && totalAlive++;
        }
        if (!totalAlive && value == true) {
            value = false;
        }
        webimJQuery('.choose_visitor').css('display', value && this.isVisitorListPanelSelected() ? 'block' : 'none');
    },

    uploadFileStart: function(filename)  {
        onlineSupport.sendAction('upload_file_start_message', {session_id: this.selectedSession.id, filename: filename}, {availableOffline: true, numberOfRetries: 3});
        return false;
    },

    findSessionByVisitorNumber: function(number, wrpInput) {
        if (!number) {
            wrpInput.css({'border-color': '', 'outline-color': ''});
            return;
        }
        for (var sessionId in visitorListData.idToVisitSession) {
            var session = visitorListData.idToVisitSession[sessionId];
            var visitorNumber = session.visitorNumber;
            if (visitorNumber !== null && visitorNumber.toString().toLowerCase() == number.toString().toLowerCase()) {
                this.selectSession(session);
                wrpInput.css({'border-color': 'green', 'outline-color': 'green'});
                return;
            }
        }
        wrpInput.css({'border-color': 'red', 'outline-color': 'red'});
    },

    showTeleportBlock: function(event) {
        var pageId = webimJQuery(event.currentTarget).closest('.visited_page').data('page-id');
        webimJQuery(event.currentTarget).parents().find('.webim-js-teleport-block[page-id="' + pageId + '"]').show();
        webimJQuery(event.currentTarget).parents().find('.webim-js-teleport-block[page-id="' + pageId + '"]').find('input[name="teleport_url"]').focus();
    },

    hideTeleportBlock: function(event) {
        var wrpBlock = webimJQuery(event.currentTarget).parents('.webim-js-teleport-block');
        wrpBlock.find('input[name="teleport_url"]').val('');
        wrpBlock.hide();
    },

    teleportVisitorAction: function(event) {
        var wrpBlock = webimJQuery(event.currentTarget).parents('.webim-js-teleport-block');
        var url = wrpBlock.find('input[name="teleport_url"]').val();
        if (url && url.indexOf('http') != 0 && url.indexOf('ftp') != 0) {
            url = 'http://' + url;
        }
        if (url && url.match(webimTools.urlRegExp)) {
            onlineSupport.sendAction('teleport_visitor', {
                session_id: this.selectedSession.id,
                page_id: wrpBlock.attr('page-id'),
                url: url
            });
            this.hideTeleportBlock(event);
        } else {
            alert(resources.errors.teleport.url_not_valid);
        }
    },

    onSessionIdsToCloseSetChanged: function () {
        var sessionIds = Object.keys(visitorListData.sessionIdsToCloseSet);
        var firstSesssionIdToClose = sessionIds[0] || null;
        if (firstSesssionIdToClose == this.blockingCloseSessionId) {
            return;
        }

        if (this.blockingCloseSessionId) {
            this.hidePopups();
            this.blockingCloseSessionId = null;
        }

        if (firstSesssionIdToClose) {
            this.blockingCloseSessionId = firstSesssionIdToClose;
            this.selectSessionById(firstSesssionIdToClose);
            this.closeChat(null, true, function () {
                visitorListData.setSessionIdToClose(firstSesssionIdToClose, false);
                this.onSessionIdsToCloseSetChanged();
            }.webimBind(this));
        }
    },

    assignOverlimitChat: function () {
        var button = webimJQuery('#visitors_list .assign_overlimit_chat');
        if (button.hasClass('enabled')) {
            button.removeClass('enabled');
            onlineSupport.sendAction('assign_overlimit_chat', {}, {availableOffline: false});
        }
    },

    fileUpload: {
        uploader: null,

        init: function () {
            if (!this.uploader) {
                this.uploader = jQuery('.js-upload-file-select')
                    .fileupload({
                        url: '/l/o/action.php?action=upload_file',
                        dataType: 'json',
                        dropZone: jQuery('.js-upload-file-area'),
                        paramName: 'file',
                        maxFileSize: 10 * 1024 * 1024
                    })
                    .on('fileuploadprocessalways', function (e, data) {
                        if (data.files.error) {
                            data.abort();
                        }else {
                            data.submit();
                        }
                    })
                    .on('fileuploadadd', this.filesAddedHandler.webimBind(this))
                    .on('fileuploadsend', this.beforeUploadHandler.webimBind(this))
                    .on('fileuploadfail', this.errorHandler.webimBind(this));
            }
        },

        filesAddedHandler: function (up, data) {
            data.url = '/l/o/action.php?action=upload_file&session_id=' + visitorListUI.selectedSession.id;
            data.formAcceptCharset = 'UTF-8';
            visitorListUI.uploadFileStart(data.files[0].name);
        },

        beforeUploadHandler: function (up, data) {
            data.headers = {'Accept-Charset': 'UTF-8'};
        },

        errorHandler: function (up, data) {
            var message = 'Unknown';
            if (data.errorThrown == 'abort') { // файл не прошел внутренние проверки
                switch (data.files[0].error) {
                    case data.i18n('acceptFileTypes'):
                        if (wm.accountConfig.allowed_upload_file_types) {
                            message = webimTools.parseResource(resources.chat.error_message.file_uploading_wrong_type, {allowed_types: wm.accountConfig.allowed_upload_file_types});
                        } else {
                            message = resources.chat.error_message.file_uploading_restricted_type;
                        }
                        break;
                    case data.i18n('maxFileSize'):
                        message = resources.alert.file_size_error;
                        break;
                    case data.i18n('minFileSize'):
                    case data.i18n('uploadedBytes'):
                    case data.i18n('maxNumberOfFiles'):
                    default:
                        message = resources.alert.unknown_file_error;
                }
            } else {
                message = resources.alert.unknown_file_error;
            }
            alert(message);
        }
    },

    prompter: {
        suggestions: [],
        predefinedAnswers: {},
        sortedAnswers: {},
        inputWrapper: null,
        answersWrapper: null,
        suggestionsWrapper: null,
        suggestionsLimit: 5,
        answersPopupWrapper: null,
        parentAnswerTemplate: null,
        childAnswerTemplate: null,

        init: function(departmentKey) {
            this.parentAnswerTemplate = webimJQuery(".chat_panel #answer_templates_popup ul.lev-1 li.parent").remove().removeClass('parent');
            this.childAnswerTemplate = webimJQuery(".chat_panel #answer_templates_popup ul.lev-1 li.child").remove().removeClass('child');

            this.answersPopupWrapper = webimJQuery('.chat_panel #answer_templates_popup ul.lev-1');
            this.inputWrapper = webimJQuery('.invitation_textarea, .chat_message_textarea');
            this.inputWrapper.keydown(function(event) {
                this.inputKeydownHandler(event);
            }.bind(this));

            webimJQuery('.chat_panel .answer_templates').click(webimTools.createEventHandler(this.clickPredefinedAnswersPopupHandler));
            webimJQuery('.chat_panel .add_answer_template').click(function(event) {
                this.clickAddPredefinedAnswerHandler(event);
            }.bind(this));

            this.getPredefinedAnwers(departmentKey);

            keep_same_size_as_message_field = function(){
                var target = webimJQuery('.chat_message_textarea');
                var newWidth = target.outerWidth() - 2;
                var targetPosition = target.offset();
                popup = webimJQuery('#answer_templates_popup').width(newWidth);
                popup.css(targetPosition.top - 51 > popup.height()
                    ? {'bottom': webimJQuery(window).height() - targetPosition.top + 3, 'top': ''}
                    : {'top': webimJQuery('div#menu').height() + 3, 'bottom': ''});
                popup.css({'left': targetPosition.left});
            };
            webimJQuery(window).resize(keep_same_size_as_message_field);
            /* setTimeout(keep_same_size_as_message_field, 200); */
            /* далее следует костыль, поскольку в Firefox setTimeout работает криво */
            setInterval(keep_same_size_as_message_field, 1500);
        },

        getPredefinedAnwers: function(departmentKey) {
            wm.ajax.request(
                '/operator/answers.php',
                {
                    type: 'all'
                },
                function(responseData) {
                    this.predefinedAnswers = responseData;
                    this.initAnswers(departmentKey);
                }.bind(this),
                null, null, null,
                {type: 'GET'});
        },

        initAnswers: function (departmentKey) {
            if (!visitorListUI.selectedSession || !this.predefinedAnswers) {
                return
            }

            this.filterAnswers(departmentKey);

            this.answersPopupWrapper.empty();

            this.fillPredefinedAnswersPopup(this.sortedAnswers[visitorListUI.selectedSession.lang], 1, this.answersPopupWrapper);

            webimJQuery('.chat_panel #answer_templates_popup li a').click(function(event) {
                this.clickPredefinedAnswerHandler(event);
            }.bind(this));

            makeLists('.chat_panel #answer_templates_popup');

            this.answersWrapper = webimJQuery('#answer_templates_popup li a');
            this.initSuggestions();
        },

        fillPredefinedAnswersPopup: function(answers, level, element) {
            if (!answers) {
                return;
            }

            answers.forEach( function(answer) {
                if (answer.section) {
                    var answerSectionHash = MD5(answer.section);
                    if (webimJQuery('[answer-section="' + answerSectionHash + '"]').length  == 0) {
                        var section = this.childAnswerTemplate.clone();
                        webimJQuery(section)
                            .attr('answer-section', answerSectionHash)
                            .addClass('has-child-list')
                            .find('span').addClass('glyphicon-menu-right');
                        webimJQuery('div', section)
                            .append(answer.section)
                        element.append(section);
                    } else {
                        var section = webimJQuery('[answer-section="' + answerSectionHash + '"]')[0];
                    }
                    this.addAnswer(answer, 2, webimJQuery('ul.lev-2', section));
                } else {
                    this.addAnswer(answer, level, element);
                }
            }.webimBind(this));
            webimJQuery('.lev-2.webim-js-list-wrapper').show();
            webimJQuery('.webim-js-list-item').show();
        },

        addAnswer: function (answer, level, element) {
            var answerElement = this.parentAnswerTemplate.clone().addClass('lev-' + level);
            webimJQuery('a', answerElement).text(answer.name ? answer.name : answer.text).data('answerText', answer.text);
            element.append(answerElement);
        },

        sortAnswers: function (answers) {
            for (var lang in answers) {
                if (!this.sortedAnswers[lang]) {
                    this.sortedAnswers[lang] = [];
                }
                for (var idx in answers[lang]) {
                    var answer = answers[lang][idx];
                    this.sortedAnswers[lang].push(answer);
                    }
                }
            },

        filterAnswers: function (departmentKey) {
            this.sortedAnswers = {};
            this.sortAnswers(this.predefinedAnswers['operator']);
            this.sortAnswers(this.predefinedAnswers['account']);

            if (wm.accountConfig.visitor_dep_answers) {
                if (departmentKey && this.predefinedAnswers['departments'] && departmentKey in this.predefinedAnswers['departments']) {
                    this.sortAnswers(this.predefinedAnswers['departments'][departmentKey]);
                }
            } else {
                for (var departmentKey in this.predefinedAnswers['departments']) if (this.predefinedAnswers['departments'].hasOwnProperty(departmentKey)) {
                    this.sortAnswers(this.predefinedAnswers['departments'][departmentKey]);
                }
            }
        },

        initSuggestions: function() {
            this.suggestions = [];
            this.answersWrapper.each(function(index, el) {
                var elWrapper = webimJQuery(el);
                if (elWrapper.data('answerText')) {
                    this.suggestions.push(elWrapper.data('answerText'));
                }
            }.bind(this));
            this.suggestions.sort();
        },

        inputKeydownHandler: function(event) {
            switch(event.keyCode) {
                case 38: //Up
                    if (this.suggestionsWrapper) {
                        this.selectSuggestionTo('prev');
                        this.useCurrentSuggestion(webimJQuery(event.currentTarget));
                        event.preventDefault();
                    }
                    break;
                case 40: //Down
                    if (this.suggestionsWrapper) {
                        this.selectSuggestionTo('next');
                        this.useCurrentSuggestion(webimJQuery(event.currentTarget));
                        event.preventDefault();
                    }
                    break;
                case 9: //Tab
                    if (this.suggestionsWrapper) {
                        this.useCurrentSuggestion(webimJQuery(event.currentTarget));
                        this.removeSuggetsionsPopup();
                        event.preventDefault();
                    }
                    break;
                case 13: //Enter
                    this.removeSuggetsionsPopup();
                    break;
                default:
                    setTimeout(function() {
                        this.updateSuggestionsPopup(webimJQuery(event.currentTarget));
                    }.bind(this), 0)
            }

        },

        updateSuggestionsPopup: function(inputWrapper) {
            this.removeSuggetsionsPopup();
            var needle = inputWrapper.val();
            var suggestions = this.findSuggestionsByStr(needle);
            if (suggestions.length > 0) {
                this.suggestionsWrapper = this.getSuggestionsPopup(suggestions);
                inputWrapper.after(this.suggestionsWrapper);
                webimJQuery(document).one('click', this.removeSuggetsionsPopup.bind(this));
            }
        },

        findSuggestionsByStr: function(str) {
            var result = [];
            if (str && str.length >= 2) {
                for (var i = 0; i < this.suggestions.length && result.length <= this.suggestionsLimit; i++) {
                    if (this.suggestions[i].toLowerCase().indexOf(str.toLowerCase()) > -1) {
                        result.push(this.suggestions[i]);
                    }
                }
            }
            return result;
        },

        getSuggestionsPopup: function(suggestions) {
            var popupWrapper = webimJQuery('<ul class="suggestions"></ul>');
            for (var i = 0; i < suggestions.length; i++) {
                popupWrapper.append('<li>' + webimTools.escapeHtml(suggestions[i]) + '</li>');
            }
            popupWrapper.find('li').first().addClass('current');
            popupWrapper.find('li')
                .mouseenter(function(event) {
                    popupWrapper.find('li').removeClass('current');
                    webimJQuery(event.currentTarget).addClass('current');
                }.bind(this))
                .click(function(event) {
                    if (webimJQuery(event.currentTarget).hasClass('current')) {
                        this.useCurrentSuggestion(popupWrapper.parent().prev());
                        this.removeSuggetsionsPopup();
                    }
                }.bind(this));

            return webimJQuery('<div class="popup suggestions-popup"/>').append(popupWrapper);
        },

        selectSuggestionTo: function(way) {
            if (this.suggestionsWrapper && this.suggestionsWrapper.find('li').size() > 1) {
                var currentWrapper = this.suggestionsWrapper.find('.current');
                if (way.toLowerCase() == 'prev') {
                    var nextWrapper = currentWrapper.prev().size() > 0 ? currentWrapper.prev() : currentWrapper.siblings().last();
                } else {
                    var nextWrapper = currentWrapper.next().size() > 0 ? currentWrapper.next() : currentWrapper.siblings().first();
                }
                currentWrapper.removeClass('current');
                nextWrapper.addClass('current');
            }
        },

        useCurrentSuggestion: function(inputWrapper) {
            if (this.suggestionsWrapper) {
                inputWrapper.filter(':visible').val(this.suggestionsWrapper.find('.current').text());
            }
        },

        removeSuggetsionsPopup: function() {
            if (this.suggestionsWrapper) {
                this.suggestionsWrapper.remove();
                this.suggestionsWrapper = null;
            }
        },

        clickPredefinedAnswersPopupHandler: function(event) {
            visitorListUI.showPopup('#answer_templates_popup', '.chat_message_textarea');
        },

        clickPredefinedAnswerHandler: function(event) {
            visitorListUI.hidePopups();
            var text = webimJQuery(event.currentTarget).data('answerText');
            this.inputWrapper.filter(':visible').val(text).focus();
            visitorListUI.checkIfItNeedsAccept();
            event.preventDefault();
        },

        clickAddPredefinedAnswerHandler: function(event) {
            visitorListUI.hidePopups();
            var newAnswer = {name: "",text: webimJQuery.trim(this.inputWrapper.filter(':visible').val()), section: ""};

            if (!newAnswer.text) {
                alert(resources['chat']['window']['predefined']['add_answer_action']['error']);
                return
            }

            var lang = visitorListUI.selectedSession ? visitorListUI.selectedSession.lang : 'ru';
            wm.ajax.request(
                '/operator/answers.php',
                {
                    lang: lang,
                    type: 'in_chat_operator',
                    id: wm.operatorId ,
                    answer: webimJQuery.toJSON(newAnswer)},
                function(responseData) {
                    if (typeof responseData == 'undefined') {
                        alert(resources['chat']['window']['predefined']['add_answer_action']['error']);
                    } else if (responseData['result'] && responseData['result'] == 'ok') {
                        this.getPredefinedAnwers(visitorListUI.selectedSession ? visitorListUI.selectedSession.departmentKey : "");
                        this.answersWrapper = webimJQuery('#answer_templates_popup li a');
                        this.initSuggestions();
                        alert(resources['chat']['window']['predefined']['add_answer_action']['success']);
                    }
                }.bind(this),
                function() {
                    alert(resources['chat']['window']['predefined']['add_answer_action']['error']);
                }.bind(this), null, null,
                {type: 'POST'});

            event.preventDefault();
        }
    },

    cobrowsingNotifications: {

        show: function(reason, session) {
            if (window.Notification) {
                if ('avatar_url' in session.visitor.fields) {
                    var notificationIconUrl = wm.fullBaseUrl + session.visitor.fields['avatar_url'];
                } else {
                    var notificationIconUrl = session.visitor.icon ? wm.fullBaseUrl + '/image-robot/get-icon.php?height=40&width=40&bgcolor=' + encodeURIComponent(session.visitor.icon.color) + '&shape=' + encodeURIComponent(session.visitor.icon.shape) : '';
                }

                var n = new window.Notification(resources.service.name, {
                    body: resources.cobrowsing.notification[reason],
                    icon: notificationIconUrl
                });

                n.onclick = function(event) {
                    window.focus();
                    event.target.close();
                    this.onNotificationClick(session.id);
                }.bind(this);
            }
        },

        onNotificationClick: function(sessionId) {
            visitorListUI.selectSessionById(sessionId);
            visitorListUI.selectTab('cobrowsing');
        }
    },

    visitorFieldsUpdater: {
        show: function(e) {
            e.preventDefault();
            if (!visitorListUI.selectedSession || !visitorListUI.selectedSession.visitor) {
                return;
            }

            webimJQuery('.visitor-fields-updater .buttons .button').show();
            webimJQuery('.visitor-fields-updater .buttons .loading').hide();

            webimJQuery('.visitor-fields-updater input').each(function(i, e) {
                webimJQuery(e).val('');
            });
            if ('opFields' in visitorListUI.selectedSession.visitor) {
                 for (var field in visitorListUI.selectedSession.visitor['opFields']) {
                    webimJQuery("[field-type='" + field + "']", ".visitor-fields-updater").val(visitorListUI.selectedSession.visitor['opFields'][field]);
                }
            }
            webimJQuery('.visitor-fields-updater-container').show();
        },

        cancel: function() {
            webimJQuery('.visitor-fields-updater input').each(function(i, e) {
                webimJQuery(e).val('');
            });
            webimJQuery(".visitor-fields-updater-container").hide();

        },

        update: function() {
            var fields = {};
            webimJQuery('.visitor-fields-updater input').each(function(i, e) {
                if (webimJQuery(e).val()) {
                    fields[webimJQuery(e).attr('field-type')] = webimJQuery(e).val();
                }
            });

            /* webimJQuery('.visitor-fields-updater .buttons .button').hide(); */
            webimJQuery('.visitor-fields-updater .buttons .button').prop('disabled', true);
            webimJQuery('.visitor-fields-updater .buttons .loading').show();

            onlineSupport.sendAction('update_visitor_fields', {session_id: visitorListUI.selectedSession.id, fields: webimJQuery.toJSON(fields)},
                {
                    availableOffline: true
                },
                {
                    onErrorCallback:   function() {
                                        webimJQuery('.visitor-fields-updater .buttons .button').prop('disabled', false);
                                        webimJQuery('.visitor-fields-updater .buttons .loading').hide();
                                    },
                    onOkCallback: function() {
                                        webimJQuery(".visitor-fields-updater-container").hide();
                                        webimJQuery('.visitor-fields-updater .buttons .button').prop('disabled', false);
                                    }
                });
            }
    }

};

operatorsChat = {
    onlineOperatorTemplate: null,
    messageTemplate: null,
    operatorSystemMessageTemplate: null,
    noMoreMessagesPanelTemplate: null,
    throbberTemplate: null,
    dayLineTemplate: null,
    unreadMessagesCounter: 0,
    lastNotification: null,

    noMoreMessages: null,
    loadPrevMsgsRequest: null,

    init: function() {
        this.onlineOperatorTemplate = webimJQuery('.operator_chat_and_info_panel .online_operator').remove();
        this.messageTemplate = webimJQuery('.operator_chat_and_info_panel .operator_message').remove();
        this.operatorSystemMessageTemplate = webimJQuery('.operator_chat_and_info_panel .operator_system_message').remove();
        this.noMoreMessagesPanelTemplate = webimJQuery('.operator_chat_and_info_panel .no_more_messages').remove();
        this.throbberTemplate = webimJQuery('.operator_chat_and_info_panel .throbber').remove();
        this.dayLineTemplate = webimJQuery('.operator_chat_and_info_panel .operator_chat_dayline').remove();

        if (webimJQuery.cookie('WEBIM_OP_CHAT_NOTIFICATIONS') == null || webimJQuery.cookie('WEBIM_OP_CHAT_NOTIFICATIONS') == '1') {
            webimJQuery('.operators_info_panel #operator_notifications_button').attr('checked', true);
            webimJQuery.cookie('WEBIM_OP_CHAT_NOTIFICATIONS', '1');
        }

        webimJQuery('#operator_notifications_button').click(this.onNotificationButtonClick.bind(this));

        webimJQuery('.visitors_list_selector').show();
        webimJQuery('.operator_chat_selector').show();

        webimJQuery('.visitors_list_selector').click(function(e) {
            visitorListUI.showVisitorListPanel();
            e.preventDefault();
        }.bind(this));
        webimJQuery('.operator_chat_selector').click(function(e) {
            visitorListUI.showOperatorsChatPanel();
            e.preventDefault();
        }.bind(this));

        webimJQuery('.send_operator_chat_message').click(function(e) {
            this.sendMessage();
            e.preventDefault();
        }.bind(this));

        webimJQuery('#operator_chat_message_textarea').keypress(function(e) {
            if (e.which == '13' && !e.shiftKey) {
                this.sendMessage();
                e.preventDefault();
            }
        }.bind(this));
    },

    isNotificationsEnabled: function() {
      return webimJQuery.cookie('WEBIM_OP_CHAT_NOTIFICATIONS') == '1';
    },

    onNotificationButtonClick: function() {
        webimJQuery.cookie('WEBIM_OP_CHAT_NOTIFICATIONS', webimJQuery('#operator_notifications_button').is(':checked') ? '1' : '0');
    },

    initOperatorChat: function(operatorChat) {
        if (webimJQuery('.operator_chat_panel').length == 0) {
            return;
        }

        this.noMoreMessages = operatorChat['noMoreMessages'];
        for (var id in visitorListData.idToOperator) {
            var o = visitorListData.idToOperator[id];
            this.updateOperatorStatus(id, o.status);
        }
        this.addMessagePack(operatorChat['messages']);
        this.updateNoMoreMessagesPanel();
        webimJQuery('.operator_chat').scroll(this.onScrollHandler.bind(this));
    },

    updateOperatorChatReady: function() {
        if (onlineSupport.connectionEstablished) {
            webimJQuery('#operator_chat_message_textarea').attr('disabled', false);
            webimJQuery('.send_operator_chat_message').show();
        } else {
            webimJQuery('#operator_chat_message_textarea').attr('disabled', true);
            webimJQuery('.send_operator_chat_message').hide();
        }
    },


    onScrollHandler: function() {
        var scrl = webimJQuery('.operator_chat').scrollTop();
        if (scrl == 0 && !this.noMoreMessages && !this.loadPrevMsgsRequest) {
            this.loadPreviousMessages();
        }
    },


    loadPreviousMessages: function() {
        webimJQuery('.operator_chat').prepend(this.throbberTemplate);
        this.loadPrevMsgsRequest = wm.ajax.request("/l/o/get-operator-chat-history", {
                'action': 'load_operator_chat_messages',
                'operator_chat_id': 0,
                'first_message_uid': webimJQuery('.operator_chat .operator_message:eq(0)').attr('id')},
            function(responseData) {
                var response = webimJQuery.evalJSON(responseData);
                this.noMoreMessages = response['no_more_messages'];

                this.addMessagePack(response['messages']);

                webimJQuery('.operator_chat .throbber').remove();

                this.updateNoMoreMessagesPanel();
                this.loadPrevMsgsRequest = null;
            }.bind(this),
            null, null, null,
            {type: 'GET', dataType: 'text'});
    },

    updateNoMoreMessagesPanel: function() {
        if (this.noMoreMessages) {
            this.addDayLine(0);
            webimJQuery('.operator_chat').prepend(this.noMoreMessagesPanelTemplate);
        }
    },

    reset: function() {
        webimJQuery('.operator_chat .confirmed').each(function(i, e) {
            webimJQuery(e).remove()
        }.bind(this));
        webimJQuery('.operators_info_panel .operators_list').html('');
        if (this.lastNotification) {
            this.lastNotification.close();
            this.unreadMessagesCounter = 0;
            this.updateNewMessageCounter();

        }
        this.noMoreMessages = false;
    },

    isOperatorChatScrolledToBottom: function() {
        var chat = webimJQuery('.operator_chat');
        return chat.prop('scrollHeight') - chat.scrollTop() - chat.height() < 20;
    },

    sendMessage: function() {
        var messageText = webimJQuery('#operator_chat_message_textarea').val();
        if (messageText.length > 0) {
            var guid = webimTools.guid();
            var message = {
                kind: 'operator',
                text: messageText,
                uid: guid,
                operator_id: wm.operatorId,
                operator_name: visitorListData.idToOperator[wm.operatorId]['fullname'],
                ts: new Date() / 1000
            };

            this.addUnconfirmedMessage(message);

            this.sendNewMessageRequest(0, messageText, guid);

            webimJQuery('#operator_chat_message_textarea').val('');
        }
    },

    sendNewMessageRequest: function(chatId, text, uid) {
        onlineSupport.sendAction('operator_chat_message',
            {'operator_chat_id': 0, message: text, uid: uid},
            {
                availableOffline: true,
                numberOfRetries: 3
            },
            {
                onErrorCallback:  function(responsedata) {
                                        this.setMessageNotDelivered(uid);
                                    }.bind(this)
            }
           );

    },

    setMessageNotDelivered: function(uid) {
        webimJQuery('#' + uid).removeClass('unconfirmed');
        webimJQuery('#' + uid).addClass('undelivered');
    },

    addUnconfirmedMessage: function(msg) {
        this.doAddMessage(msg);
        webimJQuery('#' + msg.uid).removeClass('confirmed').addClass('unconfirmed');
        webimJQuery('.operator_message_dtm', '#' + msg.uid).css({opacity: 0});
        webimJQuery('#retry', '#' + msg.uid).click(function() {
            this.retryHandler(msg.uid);
        }.bind(this));
    },

    retryHandler: function(uid) {
        webimJQuery('#' + uid).removeClass('undelivered');
        webimJQuery('#' + uid).addClass('unconfirmed');
        this.sendNewMessageRequest(0, webimJQuery('#' + uid + ' .operator_message_text').text(), uid);

    },

    confirmMessage: function(msg) {
        var msgDiv = webimJQuery('#' + msg.uid);
        if (msgDiv) {
            webimJQuery(msgDiv).removeClass('unconfirmed').addClass('confirmed');
            webimJQuery('.operator_message_dtm', msgDiv).text(" "+ webimTools.getFormattedTimefromTimestamp(msg.ts) + " ");
            webimJQuery('.operator_message_dtm', msgDiv).css({opacity: 1});
        } else {
            this.doAddMessage(msg);
        }
    },

    addMessage: function(msg, animate) {
        if (webimJQuery('#' +msg.uid).hasClass('unconfirmed')) {
            this.confirmMessage(msg);
        } else {
            if (msg.kind == 'operator') {
                this.doAddMessage(msg, animate);
            } else if (msg.kind == 'system') {
                this.addSystemMessage(msg, animate)
            }
        }
    },

    doAddMessage: function(msg, animate) {
        var messageDiv = this.prepareMessage(msg);
        this.addDayLine(msg.ts, true);
        webimJQuery('.operator_chat').append(messageDiv);
        webimJQuery(messageDiv).show();
        this.scrollDown(false);
        if (visitorListUI.isVisitorListPanelSelected()) {
            this.unreadMessagesCounter++;
            this.updateNewMessageCounter();
            this.showNewMessageNotification(msg);
        }
    },

    updateNewMessageCounter: function() {
        webimJQuery('.operator_chat_selector .new_message_counter').text(this.unreadMessagesCounter);
        webimJQuery('.operator_chat_selector .new_message_counter').toggle(this.unreadMessagesCounter > 0);
    },

    prepareMessage: function(msg) {
        var messageDiv = this.messageTemplate.clone();
        webimJQuery('.operator_message_dtm', messageDiv).text(" "+ webimTools.getFormattedTimefromTimestamp(msg.ts) + " ");
        webimJQuery('.operator_message_name', messageDiv).text(msg.operator_name);
        webimJQuery('.operator_message_text', messageDiv).html(webimTools.prepareChatMessageHtml(msg.text));
        messageDiv.addClass('operator_' + msg.operator_id).addClass('confirmed');
        messageDiv.attr('id', msg.uid);
        messageDiv.attr('msg_ts', msg.ts);
        if (msg.operator_id == wm.operatorId) {
            webimJQuery(messageDiv).css('color', 'rgb(0, 94, 179)');
        }
        return messageDiv;
    },

    prepareSystemMessage:function(msg) {
        var systemMessageDiv = this.operatorSystemMessageTemplate.clone();
        webimJQuery(systemMessageDiv).text("["+ webimTools.getFormattedTimefromTimestamp(msg.ts) + "]: " + msg.text);
        systemMessageDiv.addClass('0_' + msg.ts);
        return systemMessageDiv;
    },

    addMessagePack: function(messages, scrollBottom) {
        var first_uid = webimJQuery('.operator_chat .operator_message:eq(0)').attr('id');
        messages.reverse();
        for (var msg_idx in messages) {
            var msg = messages[msg_idx];
            if (msg.kind == 'operator') {
                var messageDiv = this.prepareMessage(msg);
                this.addDayLine(msg.ts);
                webimJQuery('.operator_chat').prepend(messageDiv);
                webimJQuery(messageDiv).fadeIn("slow");

            } else if (msg.kind == 'system') {
                var systemMessageDiv = this.prepareSystemMessage(msg);
                webimJQuery('.operator_chat').prepend(systemMessageDiv);
                webimJQuery(systemMessageDiv).show();
            }
        }
        if (first_uid) {
            webimJQuery('.operator_chat').scrollTo('#' + first_uid);
        }
    },

    addDayLine: function(ts, reverse) {
        if (reverse) {
            var last_ts = webimJQuery('.operator_message:last').attr('msg_ts');
        } else {
            var last_ts = webimJQuery('.operator_message:first').attr('msg_ts');
        }
        if (last_ts) {
            var diffDays = Math.round(Math.abs(last_ts - ts) / (3600 * 24));
            if(diffDays > 0) {
                var dayLineDiv = this.dayLineTemplate.clone();
                webimJQuery('.operator_chat_dayline_title', dayLineDiv).text(webimTools.formatDate(reverse ? ts : last_ts));
                if (reverse) {
                    webimJQuery('.operator_chat').append(dayLineDiv);
                } else {
                    webimJQuery('.operator_chat').prepend(dayLineDiv);
                }
            }
        }
    },

    addSystemMessage: function(msg, animate) {
        var systemMessageDiv = this.prepareSystemMessage(msg);
        webimJQuery('.operator_chat').append(systemMessageDiv);
        this.scrollDown(animate);
    },



    scrollDown: function(animate) {
        var dialog = webimJQuery('.operator_chat_outer');
        if (animate) {
            dialog.stop().animate({ scrollTop: dialog.prop("scrollHeight") }, 'slow', function() {
            }.bind(this));
        } else {
            dialog.scrollTop(dialog.prop("scrollHeight"));
        }
    },

    updateOperatorStatus: function(operatorId, status) {
        var color = status == 'online' ? 'green' :
            status == 'offline' ? 'rgb(131, 131, 131)' : '#f0ad4e';
        webimJQuery('.operators_list .online_operator.operator_' + operatorId + ' .operator_status')
            .text(resources.operator_status[status]).css('color', color);
    },

    addOperator: function(operatorId) {
        if (webimJQuery('.operators_list .online_operator.operator_' + operatorId).length == 0) {
            var operator = visitorListData.idToOperator[operatorId];
            var operatorDiv = this.onlineOperatorTemplate.clone();
            operatorDiv.addClass('operator_' + operator.id);
            webimJQuery('.operator_avatar', operatorDiv).attr('src', operator.avatar ? operator.avatar: wm.fullBaseUrl + '/images/default-operator-avatar-40x40.v2.png');
            webimJQuery('.operator_fullname', operatorDiv).text(operator.fullname);
            webimJQuery(operatorDiv).click(function(e) {
                var currentMessage = webimJQuery('#operator_chat_message_textarea').val();
                webimJQuery('#operator_chat_message_textarea').val(operator.fullname +', ' + currentMessage);
                webimJQuery('#operator_chat_message_textarea').focus();
                e.preventDefault();
            });
            webimJQuery('.operators_info_panel .operators_list').append(operatorDiv);
        }

    },

    showNewMessageNotification: function(msg) {
        if (window.Notification && this.isNotificationsEnabled()) {
            var operator = visitorListData.idToOperator[msg.operator_id];
            if (operator.avatar) {
                var notificationIconUrl = wm.fullBaseUrl + operator.avatar;
            } else {
                var notificationIconUrl = wm.fullBaseUrl + '/images/default-operator-avatar-40x40.v2.png';
            }
            var text = msg.text;
            if (this.lastNotification) {
                this.lastNotification.close();
            }
            var n = new window.Notification(msg.operator_name, {
                body: text,
                icon: notificationIconUrl
            });

            this.lastNotification = n;

            n.onclick = function(event) {
                window.focus();
                event.target.close();
                this.onNotificationClick(msg.chat_id);
            }.bind(this);
        }
    },

    onNotificationClick: function(chat_id) {
        visitorListUI.showOperatorsChatPanel();
        this.scrollDown(true);
    }
};

timeShiftDetector = {

    interval: 5000,
    lastCheckTs: null,

    init: function() {
        this.__setTimeout();

        if (wm.accountConfig.operator_websockets && window.WebSocket) {
            return;
        }

        setInterval(function() {
            if (onlineSupport.status != 'offline') {
                this.updateTimeDelta(null);
            }
        }.bind(this), 2 * 60 * 1000);
    },

    __setTimeout: function() {
        setTimeout(this.check.webimBind(this), this.interval);
    },

    check: function() {
        var ts = new Date().getTime();
        if (this.lastCheckTs) {
            var diff = ts - (this.lastCheckTs + this.interval);
            if (diff > 5000 || diff < -5000) {
                this.updateTimeDelta(1000);
                this.report(diff);
            }
        }
        this.lastCheckTs = ts;
        this.__setTimeout();
    },

    updateTimeDelta: function(errorTimeout) {
        wm.ajax.request(
            "/l/o/current-ts",
            {},
            function (responseData) {
                webimTools.timeDelta = new Date().getTime() - responseData.currentTs * 1000;
            }.bind(this),
            function () {
                if (!errorTimeout) {
                    return;
                }
                setTimeout(function() {
                    this.updateTimeDelta(errorTimeout < 60000 ? errorTimeout * 2 : errorTimeout);
                }.bind(this), errorTimeout);
            }.bind(this),
            null, null, {type: 'GET'});
    },

    report: function(tsShift) {
        var error = "Time shift detected: " + tsShift + " " + onlineSupport.getDeviceId();
        if (wm.ajax) {
            wm.ajax.request(
                "/l/o/js-error.php",
                {error: error},
                function (responseData) {}.bind(this),
                null, null, null,
                {type: 'POST', dataType: 'text'});
        }
    }
};

localSessionStorager = {
    idToSessionLocal: {},

    store: function() {
        for (var sessionId in visitorListData.idToVisitSession) if (visitorListData.idToVisitSession.hasOwnProperty(sessionId)) {
            this.idToSessionLocal[sessionId] = visitorListData.idToVisitSession[sessionId].local;
        }

    },

    restore: function(session) {
        if (this.idToSessionLocal.hasOwnProperty(session.id)) {
            session.local.messageDraft = this.idToSessionLocal[session.id].messageDraft;
            session.local.unconfirmedMessages = this.idToSessionLocal[session.id].unconfirmedMessages;
            this.idToSessionLocal[session.id] = null;
            delete  this.idToSessionLocal[session.id];
        }
    }
};


webimJQuery(document).ready(function() {
  try {
      visitorListUI.init();
      operatorsChat.init();
      timeShiftDetector.init();
  } catch(e) {
      webimTools.handleException(e);
  }
});

