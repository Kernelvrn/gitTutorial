/**
 * Created with JetBrains PhpStorm.
 * User: andrew
 * Date: 18/06/15
 * Time: 19:33
 * To change this template use File | Settings | File Templates.
 */
valueEditor = {
    currentRow : null,
    currentData: null,
    valueEditorWrp: null,
    isHidden: false,


    init: function(){
        this.valueEditorWrp = webimJQuery('#value_editor').remove();

    },

    showBase: function(row, rowData) {
        this.hide();
        this.currentRow = row;
        this.currentData = rowData;
        this.valueEditorWrp.addClass(this.currentData.type);
        webimJQuery('.value-cell',row).append(this.valueEditorWrp);
        webimJQuery('.value-cell .value',row).hide();
        webimJQuery('.value_control:visible', this.valueEditorWrp).val(rowData.value);

        webimJQuery('button',this.valueEditorWrp).click(
            function(event) {
                event.preventDefault();
                var newValue = webimJQuery('.value_control:visible', this.valueEditorWrp).val();
                var params =  {
                        'mode': mode,
                        'tariff_setting': this.currentData.key,
                        'type': this.currentData.type,
                        'value':newValue
                    };

                if (typeof tariffKey != 'undefined') {
                    params['tariffKey'] = tariffKey;
                }

                wm.ajax.request(
                    "/l/a/tariff-editor",
                    params,
                    function(responseData) {
                        if (responseData.result == 'ok') {
                            this.currentData.value = newValue;
                            this.hide();
                            alert('Done!')
                        } else {
                            this.onSetError(responseData);
                        }
                    }.bind(this),
                    this.onSetError.bind(this),
                    null, null,
                    {type: 'POST'}
                );

            }.bind(this)
        );
        this.isHidden = false;
    },

    hide: function() {
        if (this.isHidden) {
            return;
        }
        if (!this.currentData && !this.currentRow) {
            return;
        }
        this.valueEditorWrp.remove();
        this.valueEditorWrp.removeClass(this.currentData.type);
        webimJQuery('.value-cell div',this.currentRow).show().text(this.currentData.value);
        this.isHidden = true;
    },

    onSetError: function(responseData) {
        if (responseData.error && responseData.error == 'read-only') {
            alert('Read only setting.')
        } else {
            alert('error connecting or editing');
        }
    }
};

tariffConfig = {

    init: function() {
        valueEditor.init();
        data = tariffSettings;

        table = webimJQuery('#tariff_settings_table');
        tpl = webimJQuery('#tariff_settings_table tbody tr').remove();
        tableUtils.fillTableWithData(table, tpl, data, null,
            function(row, rowData) {
                webimJQuery('.value', row).click(
                    function (event) {
                        event.preventDefault();
                        valueEditor.showBase(row, rowData)}.bind(this)
                );
            }.bind(this));

        if (typeof tariffDescriptor != 'undefined') {
            for (var descName in tariffDescriptor) if (tariffDescriptor.hasOwnProperty(descName)) {
                webimJQuery('.tariff_descriptor input.tariff_' + descName).val(tariffDescriptor[descName]);
            }
            webimJQuery('.tariff_descriptor a.save').click(function(e) {
                var descSetting = webimJQuery(e.target).attr('desc-setting');
                var newValue = webimJQuery('.tariff_descriptor input.tariff_' + descSetting).val();
                wm.ajax.request(
                    "/l/a/tariff-editor",
                    {
                        'mode': mode,
                        'descriptor_setting': descSetting,
                        'value':newValue,
                        'tariffKey': tariffKey
                    },
                    function(responseData) {
                        if (responseData.result == 'ok') {
                            alert('Done!')
                        } else {
                            valueEditor.onSetError(responseData);
                        }
                    }.bind(this),
                    valueEditor.onSetError.bind(this),
                    null, null,
                    {type: 'POST'}
                );

            }.bind(this))
        }

    }
};
setTimeout( tariffConfig.init.bind(tariffConfig), 0 );