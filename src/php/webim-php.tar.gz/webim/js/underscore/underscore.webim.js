(function() {
    this._.mixin({
        capitalize: function(string) {
            return string.charAt(0).toUpperCase() + string.substring(1);
        },

        replaceMarkdown: function(type, text, regex) {
            if (type == 'hyperlink') {
                text = text.replace(regex, function (match, p1, p2) {
                    return '<a href="' + p2 + '" target="_blank" rel="nofollow noopener">' + p1 + '</a>';
                });
            }
            return text;
        },

        /**
         * Готовит текст для вывода в html: эскейпим теги и парсим ссылки.
         * @param {string} [text]
         * @returns {string}
         */
        prepareForHtml: function(text) {
            text = text || '';
            var urlRegExp = new RegExp('((href="|)(ht|f)tp[s]?):\/\/([a-zA-Zа-яё0-9-_]+)+([.][a-zA-Zа-яё0-9-_]+)+([a-zа-яё0-9-.,@?!*)(^=%&;:_\/~+#]*[a-zа-яё0-9-@?!*^=%&;\/~+#])?', 'gi');
            var markdownRegExps = {
                hyperlink: /\[(.*?)\]\((.*?)\)/g
            };
            var preparedText = this.escape(text);
            for (var markdownType in markdownRegExps) if (markdownRegExps.hasOwnProperty(markdownType)) {
                preparedText = this.replaceMarkdown(markdownType, preparedText, markdownRegExps[markdownType]);
            }

            if (text.indexOf('<script') < 0) {
                preparedText = preparedText.replace(urlRegExp, function(url) {
                    if (url.indexOf("href=") == 0) {
                        return url;
                    }
                    var decodedUrl = decodeURI(url);
                    var linkContent = decodedUrl.length > 30 ? decodedUrl.substr(0, 27) + '...' : decodedUrl;
                    return '<a href="' + url + '" target="_blank" rel="nofollow noopener">' + linkContent + '</a>';
                }.bind(this));
            }
            return preparedText
                .replace(/\b([0-9a-z][\-0-9a-z_]*\.)*([0-9a-z][\-0-9a-z_]*)@(([0-9a-z][\-0-9a-z]*\.)+[a-z]{2,6}|([0-9а-яё][\-0-9а-яё]*\.)+рф)(?=[^а-яёa-z0-9]|$)/gi, '<a href="mailto:$&">$&</a>')
                .replace(/(?:\r\n|\r|\n)/g, '<br />');
        }
    });
}.call(this));