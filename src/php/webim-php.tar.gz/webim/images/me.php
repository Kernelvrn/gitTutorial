<?php
require_once '../classes/class.images.php';

$locale = isset($_GET['locale']) ? $_GET['locale'] : Resources::getCurrentLocale();
$theme = isset($_GET['theme']) ? $_GET['theme'] : Browser::getCurrentTheme();
$image = 'me';

echo Images::get($image, $locale, $theme);